# ELMOS Language Packs Batch 91–95

Contains 60 Skills and five individual Batch ZIPs.
