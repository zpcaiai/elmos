package io.elmos.legacy;

import io.elmos.legacy.boot.LegacyMvcConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Import;

@SpringBootApplication(scanBasePackages = {"io.elmos.legacy.service", "io.elmos.legacy.web"})
@Import(LegacyMvcConfiguration.class)
public class LegacyMvcApplication extends SpringBootServletInitializer {
    public static void main(String[] args) { SpringApplication.run(LegacyMvcApplication.class, args); }
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) { return application.sources(LegacyMvcApplication.class); }
}
