package io.elmos.legacy.boot;

import io.elmos.legacy.web.RequestAuditInterceptor;
import jakarta.servlet.DispatcherType;
import java.util.EnumSet;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.validation.Validator;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
public class LegacyMvcConfiguration implements WebMvcConfigurer {
    @Bean(name = "validator") public LocalValidatorFactoryBean validator() { return new LocalValidatorFactoryBean(); }
    @Override public Validator getValidator() { return validator(); }
    @Bean public RequestAuditInterceptor requestAuditInterceptor() { return new RequestAuditInterceptor(); }
    @Override public void addInterceptors(InterceptorRegistry registry) { registry.addInterceptor(requestAuditInterceptor()).addPathPatterns("/api/**"); }
    @Override public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) { configurer.enable(); }
    @Override public void addResourceHandlers(ResourceHandlerRegistry registry) { registry.addResourceHandler("/assets/**").addResourceLocations("/assets/").setCachePeriod(3600); }
    @Bean public InternalResourceViewResolver internalResourceViewResolver() {
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        resolver.setPrefix("/WEB-INF/views/"); resolver.setSuffix(".jsp"); resolver.setOrder(10); return resolver;
    }
    @Bean public FilterRegistrationBean<CharacterEncodingFilter> characterEncodingFilter() {
        CharacterEncodingFilter filter = new CharacterEncodingFilter(); filter.setEncoding("UTF-8"); filter.setForceEncoding(true);
        FilterRegistrationBean<CharacterEncodingFilter> registration = new FilterRegistrationBean<>(filter);
        registration.setName("characterEncodingFilter"); registration.setUrlPatterns(java.util.List.of("/*"));
        registration.setDispatcherTypes(EnumSet.of(DispatcherType.REQUEST, DispatcherType.ERROR));
        registration.setOrder(Ordered.HIGHEST_PRECEDENCE); return registration;
    }
}
