package io.elmos.legacy.web;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;

public class LegacyOrderForm {
    @NotBlank
    private String customerId;

    @Positive
    private long amountCents;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public long getAmountCents() {
        return amountCents;
    }

    public void setAmountCents(long amountCents) {
        this.amountCents = amountCents;
    }
}
