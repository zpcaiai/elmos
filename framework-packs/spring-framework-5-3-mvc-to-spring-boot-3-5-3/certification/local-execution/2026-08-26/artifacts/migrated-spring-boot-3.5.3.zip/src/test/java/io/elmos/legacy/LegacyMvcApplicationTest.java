package io.elmos.legacy;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class LegacyMvcApplicationTest {
    @Autowired MockMvc mvc;
    @Test void bootsWithApiInterceptor() throws Exception {
        mvc.perform(get("/api/orders/42")).andExpect(status().isOk()).andExpect(header().string("X-Legacy-Audit", "GET /api/orders/42")).andExpect(jsonPath("$.currency").value("CNY"));
    }
    @Test void keepsJspRouteOutsideApiInterceptor() throws Exception {
        mvc.perform(get("/orders")).andExpect(status().isOk()).andExpect(view().name("orders/list")).andExpect(header().doesNotExist("X-Legacy-Audit"));
    }
    @Test void exposesOnlyHealthOutsideApiInterceptor() throws Exception {
        mvc.perform(get("/actuator/health")).andExpect(status().isOk()).andExpect(jsonPath("$.status").value("UP")).andExpect(header().doesNotExist("X-Legacy-Audit"));
        mvc.perform(get("/actuator/env")).andExpect(status().isNotFound()).andExpect(header().doesNotExist("X-Legacy-Audit"));
    }
}
