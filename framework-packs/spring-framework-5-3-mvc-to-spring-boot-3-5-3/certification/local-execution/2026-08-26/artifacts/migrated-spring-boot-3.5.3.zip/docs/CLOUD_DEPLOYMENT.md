# Spring Boot 3.5.3 云端部署平台与推荐步骤

当前状态：`CONFIGURATION_REQUIRED`；外部执行证据：`NOT_RUN`；
生产交付状态：`NOT_RUN`。本文不会授权或执行任何云端变更。

## 平台选择

| 平台 | 建议 | 适用场景 |
|---|---|---|
| Google Cloud Run | **推荐** | 无状态 HTTP API，减少单服务集群运维 |
| Azure Container Apps | 可选 | 已使用 Azure Managed Identity、Key Vault 和 Azure Database |
| AWS ECS on Fargate | 可选 | 已使用 ECR、IAM、VPC、ALB 和 RDS |
| GKE / EKS / AKS | 条件选择 | 已有 Kubernetes 平台团队和准入、观测、升级能力 |

Vercel 适合单独的 Next.js 前端，不作为该 Spring Boot 后端的默认平台。

## 推荐平台：Google Cloud Run

### 必填配置

- Cloud 项目、区域、计费和数据驻留负责人。
- 专用运行时 Service Account，不得授予 Owner/Editor。
- Artifact Registry 仓库和精确镜像摘要 `sha256:...`。
- CPU、内存、并发、最小/最大实例、ingress 和调用者。
- Secret Manager 的 Secret 名称与不可变版本，禁止使用 `latest`。
- 数据库连接、迁移/回滚、告警、预算、DNS 和清理负责人。

### 详细步骤

1. 登录受控账号，确认项目、区域、计费、数据驻留和部署授权。
2. 启用 Cloud Run、Artifact Registry、Secret Manager；使用数据库时再启用
   Cloud SQL Admin API。
3. 创建区域性 Artifact Registry 和专用运行时 Service Account，仅授予实际需要的角色。
4. 从仓库根目录使用 `deploy/cloud-run/Dockerfile` 构建并推送镜像，
   从远端读取 `sha256`；后续部署只使用摘要。
5. Secret 只通过 Secret Manager 文件挂载，固定版本，不进入环境变量值、日志或仓库。
6. 部署时默认私有：`--no-allow-unauthenticated`，并设置专用身份、
   `SERVER_ADDRESS=0.0.0.0`、`SERVER_PORT=8080`、CPU、内存、并发和实例上限。
7. PostgreSQL 建议使用同区域 Cloud SQL for PostgreSQL 或经批准的外部托管库；
   设置连接池与实例上限，先完成迁移和回滚演练。
8. 从有权限的调用方执行健康、认证负例和业务冒烟；保存修订、摘要、配置与日志证据。
9. 回滚时把流量切回上一不可变修订；清理时删除失败修订、镜像、未使用 Secret、
   数据库和网络资源并复核账单。

### 命令模板

```bash
export CLOUD_PROJECT_ID="REQUIRED"
export CLOUD_REGION="REQUIRED"
export ARTIFACT_REPOSITORY="REQUIRED"
export SERVICE_NAME="REQUIRED"
export RUNTIME_SERVICE_ACCOUNT="REQUIRED"
export IMAGE_NAME="REQUIRED"

gcloud config set project "$CLOUD_PROJECT_ID"
gcloud services enable run.googleapis.com artifactregistry.googleapis.com   secretmanager.googleapis.com
gcloud artifacts repositories create "$ARTIFACT_REPOSITORY"   --repository-format=docker --location="$CLOUD_REGION"

IMAGE_URI="$CLOUD_REGION-docker.pkg.dev/$CLOUD_PROJECT_ID/$ARTIFACT_REPOSITORY/$IMAGE_NAME"
docker build --file deploy/cloud-run/Dockerfile --tag "$IMAGE_URI:candidate" .
docker push "$IMAGE_URI:candidate"
IMAGE_DIGEST="$(gcloud artifacts docker images describe "$IMAGE_URI:candidate"   --format='value(image_summary.digest)')"
test -n "$IMAGE_DIGEST"

gcloud run deploy "$SERVICE_NAME"   --region="$CLOUD_REGION"   --image="$IMAGE_URI@$IMAGE_DIGEST"   --service-account="$RUNTIME_SERVICE_ACCOUNT"   --port=8080 --cpu=REQUIRED --memory=REQUIRED   --concurrency=REQUIRED --min=REQUIRED --max=REQUIRED   --set-env-vars=SERVER_ADDRESS=0.0.0.0,SERVER_PORT=8080   --no-allow-unauthenticated
```

数据库 Secret 挂载示例：
`--update-secrets=/run/secrets/database-url=database-url:REQUIRED_VERSION`。
应用必须读取文件路径，不能把 Secret 明文放入命令或环境变量。
