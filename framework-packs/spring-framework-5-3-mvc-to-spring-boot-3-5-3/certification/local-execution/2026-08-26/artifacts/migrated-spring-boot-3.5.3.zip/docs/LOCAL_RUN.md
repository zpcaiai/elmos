# Spring Boot 3.5.3 本地运行与验证

精确路线：`spring-framework-5.3-mvc-maven-to-boot-3.5.3-java-21`

- 声明源约束：spring-mvc `exact:5.3.39`，版本匹配：`EXACT`，Java 11，maven
- 精确目标：Spring Boot 3.5.3，Java 21
- 启动产物：executable Spring Boot WAR（传统 Spring MVC 路线不得退化为普通 JAR）
- 路线工程证据：PASSED_LOCAL；这不是客户、生产或认证证据

```bash
set -eu
java -version
mvn -B -ntp verify
ARTIFACT_CANDIDATES="$(find target -maxdepth 1 -type f -name '*.war'   ! -name '*.original' ! -name 'original-*' -print)"
test -n "$ARTIFACT_CANDIDATES"
test "$(printf '%s\n' "$ARTIFACT_CANDIDATES" | wc -l | tr -d ' ')" -eq 1
ARTIFACT_PATH="$(pwd)/$ARTIFACT_CANDIDATES"
WAR_CHECK_DIR="$(mktemp -d)"
trap 'rm -rf "$WAR_CHECK_DIR"' EXIT
jar tf "$ARTIFACT_PATH" > "$WAR_CHECK_DIR/entries.txt"
test "$(grep -Fxc 'org/springframework/boot/loader/launch/WarLauncher.class'   "$WAR_CHECK_DIR/entries.txt")" -eq 1
(cd "$WAR_CHECK_DIR" && jar xf "$ARTIFACT_PATH" META-INF/MANIFEST.MF)
tr -d '\r' < "$WAR_CHECK_DIR/META-INF/MANIFEST.MF" > "$WAR_CHECK_DIR/manifest.txt"
test "$(grep -Fxc 'Main-Class: org.springframework.boot.loader.launch.WarLauncher'   "$WAR_CHECK_DIR/manifest.txt")" -eq 1
test "$(grep -Fxc 'Spring-Boot-Version: 3.5.3'   "$WAR_CHECK_DIR/manifest.txt")" -eq 1
test "$(grep -Ec '^Start-Class: [^[:space:]].*$'   "$WAR_CHECK_DIR/manifest.txt")" -eq 1

SERVER_ADDRESS=127.0.0.1 MANAGEMENT_SERVER_ADDRESS=127.0.0.1   SERVER_PORT=8080 MANAGEMENT_SERVER_PORT=8080 java -jar "$ARTIFACT_PATH"
```

在另一终端对声明的健康端点执行回环检查。安全身份与授权、数据库结构和数据、
事务隔离/回滚、Kafka/Rabbit/JMS 交付语义、缓存、定时任务和外部系统仍须按
FCM obligations 独立验证；未执行的域保持 `NOT_RUN`。
