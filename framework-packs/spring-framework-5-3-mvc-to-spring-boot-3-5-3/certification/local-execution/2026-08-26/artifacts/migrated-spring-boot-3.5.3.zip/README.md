# Migrated Spring Boot project
## ELMOS 本地运行与云部署交接

- [`docs/LOCAL_RUN.md`](docs/LOCAL_RUN.md)：精确软硬件配置、验证、启动和健康检查。
- [`docs/CLOUD_DEPLOYMENT.md`](docs/CLOUD_DEPLOYMENT.md)：可选云平台和推荐 Cloud Run 步骤。
- [`deploy/cloud-run/deployment-profile.json`](deploy/cloud-run/deployment-profile.json)：
  机器可读、默认失败关闭的云配置清单。

云端执行、恢复和认证证据仍为 `NOT_RUN`。
