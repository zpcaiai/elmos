# Changelog

## 1.0.0 — 2026-08-19

- Initial release.
- Added 22 implementation Skills and 719 stable tasks.
- Added phase roadmap G0-G9 and topological dependency order.
- Added JSON schemas, templates, examples, installer, uninstaller, validators, smoke tests, and package checks.
- Added autonomous system wall-clock ETA contract separated from human-equivalent effort.
- Added conservative production-readiness claim boundary.
