#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$ROOT/scripts/validate_skill_bundle.py" "$ROOT"
python3 "$ROOT/scripts/validate_json_schemas.py" "$ROOT"
bash -n "$ROOT/install.sh" "$ROOT/uninstall.sh" "$ROOT/verify.sh" "$ROOT/scripts/smoke-test.sh" "$ROOT/scripts/package.sh"
python3 -m unittest discover -s "$ROOT/tests" -v
echo "PASS: eLMOS Infrastructure Foundation Skills bundle"
