from __future__ import annotations
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class InstallerTests(unittest.TestCase):
    def test_dry_run_does_not_create_target(self):
        with tempfile.TemporaryDirectory() as td:
            target = Path(td)/"not-created"
            result = subprocess.run([str(ROOT/"install.sh"), str(target), "--profile", "all", "--dry-run"],
                                    text=True, capture_output=True)
            self.assertEqual(0, result.returncode, result.stderr)
            self.assertFalse(target.exists())

    def test_install_refuses_overwrite_without_force(self):
        with tempfile.TemporaryDirectory() as td:
            target = Path(td)/"target"
            subprocess.run([str(ROOT/"install.sh"), str(target), "--profile", "universal"], check=True,
                           text=True, capture_output=True)
            result = subprocess.run([str(ROOT/"install.sh"), str(target), "--profile", "universal"],
                                    text=True, capture_output=True)
            self.assertNotEqual(0, result.returncode)
            self.assertIn("Refusing to overwrite", result.stderr)

if __name__ == "__main__":
    unittest.main()
