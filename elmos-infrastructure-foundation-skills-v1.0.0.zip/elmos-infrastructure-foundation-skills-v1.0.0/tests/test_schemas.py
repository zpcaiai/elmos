from __future__ import annotations
import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

ROOT = Path(__file__).resolve().parents[1]

class SchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schemas = {}
        for path in (ROOT/"schemas").glob("*.schema.json"):
            cls.schemas[path.name] = json.loads(path.read_text(encoding="utf-8"))
        cls.registry = Registry().with_resources(
            (schema["$id"], Resource.from_contents(schema))
            for schema in cls.schemas.values() if "$id" in schema
        )

    def test_schemas_are_valid(self):
        for name, schema in self.schemas.items():
            with self.subTest(name=name):
                Draft202012Validator.check_schema(schema)

    def test_fixtures_validate(self):
        fixture_dir = ROOT/"tests/fixtures"
        mapping = json.loads((fixture_dir/"fixture-map.json").read_text(encoding="utf-8"))
        for fixture_name, schema_name in mapping.items():
            with self.subTest(fixture=fixture_name):
                instance = json.loads((fixture_dir/fixture_name).read_text(encoding="utf-8"))
                schema = self.schemas[schema_name]
                Draft202012Validator(schema, registry=self.registry, format_checker=FormatChecker()).validate(instance)

    def test_rejects_invalid_digest(self):
        schema = self.schemas["digest.schema.json"]
        invalid = {"algorithm":"sha256","hex":"not-a-digest","size_bytes":-1}
        errors = list(Draft202012Validator(schema).iter_errors(invalid))
        self.assertGreaterEqual(len(errors), 1)

    def test_rejects_runtime_human_delay_mixed_into_system_contract(self):
        schema = self.schemas["runtime-estimate.schema.json"]
        instance = json.loads((ROOT/"tests/fixtures/runtime-estimate.json").read_text(encoding="utf-8"))
        instance["human_in_loop_delay"]["excluded_from_system_runtime"] = False
        errors = list(Draft202012Validator(schema, registry=self.registry).iter_errors(instance))
        self.assertTrue(errors)

if __name__ == "__main__":
    unittest.main()
