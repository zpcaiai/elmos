from __future__ import annotations
import json
import re
import unittest
from collections import defaultdict, deque
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class BundleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = json.loads((ROOT / "skill-manifest.json").read_text(encoding="utf-8"))
        cls.catalog = json.loads((ROOT / "docs/task-catalog.json").read_text(encoding="utf-8"))

    def test_counts_and_unique_names(self):
        self.assertEqual(self.manifest["skill_count"], len(self.manifest["skills"]))
        self.assertEqual(self.manifest["task_count"], len(self.catalog["tasks"]))
        names = [x["name"] for x in self.manifest["skills"]]
        self.assertEqual(len(names), len(set(names)))
        ids = [x["id"] for x in self.catalog["tasks"]]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertTrue(all(re.fullmatch(r"ELMOS-[A-Z]+-\d{3}", x) for x in ids))

    def test_skill_files_and_task_coverage(self):
        catalog_ids = {x["id"] for x in self.catalog["tasks"]}
        found = set()
        required = ["## Objective", "## Implementation checklist", "## Validation", "## Definition of done"]
        for skill in self.manifest["skills"]:
            path = ROOT / skill["path"]
            self.assertTrue(path.is_file(), path)
            text = path.read_text(encoding="utf-8")
            for heading in required:
                self.assertIn(heading, text)
            ids = re.findall(r"`(ELMOS-[A-Z]+-\d{3})`", text)
            self.assertEqual(skill["task_count"], len(ids))
            found.update(ids)
        self.assertEqual(catalog_ids, found)

    def test_dependency_graph_and_order(self):
        names = {x["name"] for x in self.manifest["skills"]}
        indegree = {x: 0 for x in names}
        graph = defaultdict(list)
        for skill in self.manifest["skills"]:
            for dep in skill["dependencies"]:
                self.assertIn(dep, names)
                graph[dep].append(skill["name"])
                indegree[skill["name"]] += 1
        queue = deque(sorted(x for x,v in indegree.items() if v == 0))
        order = []
        while queue:
            x = queue.popleft()
            order.append(x)
            for y in sorted(graph[x]):
                indegree[y] -= 1
                if indegree[y] == 0:
                    queue.append(y)
        self.assertEqual(len(names), len(order))
        self.assertEqual(self.manifest["topological_order"], order)

    def test_production_claim_boundary(self):
        self.assertIn("does not prove", self.manifest["production_claim"].lower())
        self.assertIn("static", (ROOT/"README.md").read_text(encoding="utf-8").lower())
        gate = (ROOT/".agents/skills/elmos-production-readiness-gate/SKILL.md").read_text(encoding="utf-8")
        self.assertIn("Static bundle validation", gate)

    def test_runtime_estimate_separation(self):
        doc = (ROOT/"docs/RUNTIME-ESTIMATION.md").read_text(encoding="utf-8")
        self.assertIn("Autonomous system wall-clock runtime", doc)
        self.assertIn("Human-equivalent effort", doc)
        schema = json.loads((ROOT/"schemas/runtime-estimate.schema.json").read_text(encoding="utf-8"))
        self.assertIn("system_runtime", schema["properties"])
        self.assertIn("human_equivalent", schema["properties"])

if __name__ == "__main__":
    unittest.main()
