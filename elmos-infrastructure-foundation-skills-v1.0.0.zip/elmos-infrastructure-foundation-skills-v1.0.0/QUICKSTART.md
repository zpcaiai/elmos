# Quick Start

## 1. Validate this bundle

```bash
./verify.sh
```

## 2. Preview installation

```bash
./install.sh /path/to/elmos --profile all --dry-run
```

## 3. Install

```bash
./install.sh /path/to/elmos --profile all
```

## 4. Start the agent

Use the program orchestrator:

```text
Use $elmos-infrastructure-program-orchestrator.
Inspect this repository, map current implementation to the installed eLMOS infrastructure task catalog,
select the smallest dependency-resolved P0 vertical slice, create a durable implementation plan,
implement it with tests, telemetry, audit and rollback, then report:
1) autonomous system wall-clock runtime,
2) human-equivalent effort separately,
3) executed evidence and residual risks.
Do not claim production readiness from static scaffolding.
```

For the first billable path:

```text
Use $elmos-java-migration-production-loop and the dependent Skills.
Implement the narrow GitHub App -> private runner -> immutable snapshot -> baseline ->
OpenRewrite -> compile/test -> bounded repair -> PR/checks -> signed offline Evidence Pack loop.
```

## 5. Track work

Copy and update:

```bash
cp templates/IMPLEMENTATION-PLAN.yaml implementation-plan.yaml
cp templates/TASK-REPORT.md task-report.md
```

Machine-readable backlog:

```text
docs/task-catalog.json
docs/TASK-MATRIX.csv
```

## 6. Production claim

Only invoke `$elmos-production-readiness-gate` after actual integration, failure, security, restore, benchmark, and pilot evidence exists.
