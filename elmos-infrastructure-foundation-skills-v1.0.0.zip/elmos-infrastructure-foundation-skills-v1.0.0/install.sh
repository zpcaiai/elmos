#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="1.0.0"
PROFILE="universal"
FORCE=0
DRY_RUN=0

usage() {
  cat <<'EOF'
Usage: ./install.sh <target-repository> [--profile universal|claude|codex|all] [--force] [--dry-run]
EOF
}

if [[ $# -lt 1 ]]; then usage; exit 2; fi
TARGET="$1"; shift
while [[ $# -gt 0 ]]; do
  case "$1" in
    --profile) PROFILE="${2:-}"; shift 2 ;;
    --force) FORCE=1; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage; exit 2 ;;
  esac
done
case "$PROFILE" in universal|claude|codex|all) ;; *) echo "Invalid profile: $PROFILE" >&2; exit 2;; esac

mkdir_cmd() { if [[ "$DRY_RUN" -eq 1 ]]; then echo "mkdir -p $1"; else mkdir -p "$1"; fi; }
copy_dir() {
  local src="$1" dst="$2"
  if [[ -e "$dst" && "$FORCE" -ne 1 ]]; then
    echo "Refusing to overwrite: $dst (use --force)" >&2
    exit 3
  fi
  if [[ "$DRY_RUN" -eq 1 ]]; then echo "copy $src -> $dst"; return; fi
  rm -rf "$dst"
  mkdir -p "$(dirname "$dst")"
  cp -R "$src" "$dst"
}
copy_file() {
  local src="$1" dst="$2"
  if [[ -e "$dst" && "$FORCE" -ne 1 ]]; then
    echo "Refusing to overwrite: $dst (use --force)" >&2
    exit 3
  fi
  if [[ "$DRY_RUN" -eq 1 ]]; then echo "copy $src -> $dst"; return; fi
  mkdir -p "$(dirname "$dst")"
  cp "$src" "$dst"
}

if [[ "$DRY_RUN" -eq 1 ]]; then
  case "$TARGET" in /*) ;; *) TARGET="$(pwd)/$TARGET" ;; esac
else
  mkdir -p "$TARGET"
  TARGET="$(cd "$TARGET" && pwd)"
fi
DESTS=()
[[ "$PROFILE" == "universal" || "$PROFILE" == "all" ]] && DESTS+=("$TARGET/.agents/skills")
[[ "$PROFILE" == "claude" || "$PROFILE" == "all" ]] && DESTS+=("$TARGET/.claude/skills")
[[ "$PROFILE" == "codex" || "$PROFILE" == "all" ]] && DESTS+=("$TARGET/.codex/skills")

# Preflight all conflicts before copying.
for base in "${DESTS[@]}"; do
  for src in "$ROOT"/.agents/skills/*; do
    dst="$base/$(basename "$src")"
    if [[ -e "$dst" && "$FORCE" -ne 1 ]]; then
      echo "Refusing to overwrite: $dst (use --force)" >&2
      exit 3
    fi
  done
done
for pair in \
  "$ROOT/docs|$TARGET/docs/elmos-infrastructure-foundation" \
  "$ROOT/schemas|$TARGET/schemas/elmos-infrastructure-foundation" \
  "$ROOT/templates|$TARGET/templates/elmos-infrastructure-foundation" \
  "$ROOT/scripts|$TARGET/scripts/elmos-infrastructure-foundation" \
  "$ROOT/plans|$TARGET/plans/elmos-infrastructure-foundation"; do
  dst="${pair#*|}"
  if [[ -e "$dst" && "$FORCE" -ne 1 ]]; then
    echo "Refusing to overwrite: $dst (use --force)" >&2
    exit 3
  fi
done

for base in "${DESTS[@]}"; do
  mkdir_cmd "$base"
  for src in "$ROOT"/.agents/skills/*; do
    copy_dir "$src" "$base/$(basename "$src")"
  done
done
copy_dir "$ROOT/docs" "$TARGET/docs/elmos-infrastructure-foundation"
copy_dir "$ROOT/schemas" "$TARGET/schemas/elmos-infrastructure-foundation"
copy_dir "$ROOT/templates" "$TARGET/templates/elmos-infrastructure-foundation"
copy_dir "$ROOT/scripts" "$TARGET/scripts/elmos-infrastructure-foundation"
copy_dir "$ROOT/plans" "$TARGET/plans/elmos-infrastructure-foundation"
copy_file "$ROOT/skill-manifest.json" "$TARGET/docs/elmos-infrastructure-foundation/skill-manifest.json"
copy_file "$ROOT/README.md" "$TARGET/docs/elmos-infrastructure-foundation/README.md"

if [[ "$DRY_RUN" -eq 0 ]]; then
  cat > "$TARGET/.elmos-infrastructure-foundation-install.json" <<EOF
{"package":"elmos-infrastructure-foundation-skills","version":"$VERSION","profile":"$PROFILE"}
EOF
fi
echo "Installed eLMOS Infrastructure Foundation Skills v$VERSION using profile $PROFILE"
