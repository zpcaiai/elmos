#!/usr/bin/env bash
set -euo pipefail
PROFILE="universal"
DRY_RUN=0
usage() { echo "Usage: ./uninstall.sh <target-repository> [--profile universal|claude|codex|all] [--dry-run]"; }
if [[ $# -lt 1 ]]; then usage; exit 2; fi
TARGET="$1"; shift
while [[ $# -gt 0 ]]; do
  case "$1" in
    --profile) PROFILE="${2:-}"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done
case "$PROFILE" in universal|claude|codex|all) ;; *) echo "Invalid profile" >&2; exit 2;; esac
TARGET="$(cd "$TARGET" && pwd)"
remove_path() { if [[ "$DRY_RUN" -eq 1 ]]; then echo "remove $1"; else rm -rf "$1"; fi; }
DESTS=()
[[ "$PROFILE" == "universal" || "$PROFILE" == "all" ]] && DESTS+=("$TARGET/.agents/skills")
[[ "$PROFILE" == "claude" || "$PROFILE" == "all" ]] && DESTS+=("$TARGET/.claude/skills")
[[ "$PROFILE" == "codex" || "$PROFILE" == "all" ]] && DESTS+=("$TARGET/.codex/skills")
for base in "${DESTS[@]}"; do
  while IFS= read -r name; do
    [[ -n "$name" ]] && remove_path "$base/$name"
  done < <(python3 - "$TARGET/docs/elmos-infrastructure-foundation/skill-manifest.json" <<'PY'
import json, sys
from pathlib import Path
p=Path(sys.argv[1])
if p.exists():
    for x in json.loads(p.read_text())["skills"]:
        print(x["name"])
else:
    # Known package prefix fallback; list only exact directories matching package naming.
    for name in [
        "elmos-infrastructure-program-orchestrator",
        "elmos-architecture-contract-governance",
        "elmos-identity-tenant-security",
        "elmos-temporal-task-reliability",
        "elmos-repository-snapshot-workspace",
        "elmos-content-addressed-cache",
        "elmos-staging-snapshot-promotion",
        "elmos-reproducible-toolchain",
        "elmos-incremental-semantic-index",
        "elmos-runner-scheduler-execution",
        "elmos-secure-sandbox-runtime",
        "elmos-semantic-ir-compiler-platform",
        "elmos-model-gateway-agent-runtime",
        "elmos-verification-fabric",
        "elmos-evidence-pack-offline-verification",
        "elmos-policy-supply-chain-signing",
        "elmos-observability-finops",
        "elmos-progressive-delivery",
        "elmos-backup-recovery-replay",
        "elmos-scale-benchmark-certification",
        "elmos-java-migration-production-loop",
        "elmos-production-readiness-gate",
    ]:
        print(name)
PY
)
done
remove_path "$TARGET/docs/elmos-infrastructure-foundation"
remove_path "$TARGET/schemas/elmos-infrastructure-foundation"
remove_path "$TARGET/templates/elmos-infrastructure-foundation"
remove_path "$TARGET/scripts/elmos-infrastructure-foundation"
remove_path "$TARGET/plans/elmos-infrastructure-foundation"
remove_path "$TARGET/.elmos-infrastructure-foundation-install.json"
echo "Removed eLMOS Infrastructure Foundation Skills profile $PROFILE"
