# Wiring into the elmos root Makefile

Batches 97 and later do not use `Makefile.batchNN` fragments. Add a group-level target to the repository
root `Makefile`, matching the existing `batch97-104-skills` pattern:

```make
.PHONY: batch105-152-skills batch105-152-install
batch105-152-skills:
	cd elmos-codex-skills-batch105-152-complete && ./validate.sh

batch105-152-install:
	cd elmos-codex-skills-batch105-152-complete && ./install.sh $(HOME)/.codex/skills
```

`validate.sh` prefers a system `python3` that already provides `jsonschema>=4.23` and falls back to `uv`
when it does not.

Validation establishes `statically_validated` only. It never returns `certified`.
