"""P1 convergence registry — decision record ADR-MIG-P1-01 … ADR-MIG-P1-07.

The adversarial review found six capability families modelled two to five times across
Batch 1–8, plus a seventh (retry budget) whose authority lived entirely in the then
unimplemented range. Each family is converged here: exactly one Skill is the authority,
the richest field set from the duplicate definitions is merged into it, and every other
member becomes a domain view that may specialise but may never redefine the state machine
or relax an invariant.

All seven authorities and all of their views are now implemented; `planned` is retained as
the provenance record of which source Skill numbers each family absorbed. A family may set
`authority_present` to False while its authority Skill has not been emitted yet: its views
still carry the view clause and the capability-closure requirement, and the build does not
demand a Skill that does not exist. No family currently uses that escape hatch.
"""

AUTHORITY_CLAUSE = (
    "This Skill is the sole authority for the {family} model; its schema, state machine and "
    "invariants may not be redefined by any other Skill."
)

VIEW_CLAUSE = (
    "This Skill is a domain view of the {family} model owned by {authority}; it may add "
    "collection points and domain thresholds but may not redefine that schema or relax its "
    "invariants, and the owning Skill must be present in the loaded capability closure whenever "
    "this one is selected."
)

CONVERGENCE = {
    "ADR-MIG-P1-01": {
        "family": "messaging semantics",
        "authority": "unified-messaging-ir",
        "merged_from": [
            "Skill 7 (message semantics verification)",
            "Skill 520 (unified message delivery IR)",
        ],
        "merged_fields": [
            "Message identity, key, partition, timestamp, producer and consumer identity are "
            "recorded alongside delivery, acknowledgement and ordering semantics.",
            "Inbox deduplication state and offset commit position are part of this model, not a "
            "separate one.",
        ],
        "views": [
            "message-semantics-verifier",
            "transactional-messaging-verifier",
            "framework-messaging-adapter-pack",
            "messaging-behavior-test-generator",
            "infrastructure-message-delivery-view",
            "producer-semantic-verifier",
            "consumer-semantic-verifier",
            "message-ordering-verifier",
            "delivery-guarantee-verifier",
            "acknowledgement-semantic-verifier",
            "message-retry-and-dead-letter-verifier",
            "consumer-rebalance-verifier",
            "transactional-producer-verifier",
            "outbox-and-inbox-verifier",
            "messaging-backpressure-verifier",
            "infrastructure-messaging-test-generator",
            "message-based-rpc-verifier",
        ],
        "planned": [520, 521, 522, 524, 525, 526, 527, 528, 529, 531, 532, 533, 534, 535, 536, 537],
    },
    "ADR-MIG-P1-02": {
        "family": "serialization",
        "authority": "serialization-semantic-ir",
        "merged_from": [
            "Skill 89 (data contract IR)",
            "Skill 361 (serialization library mapping)",
            "Skill 629 (unified serialization IR)",
        ],
        "merged_fields": [
            "Wire name, field presence, ordering, polymorphic discriminator, reference preservation, "
            "compression and schema version are all part of this model.",
            "Field presence uses the six-state absence model and never a boolean present flag.",
        ],
        "views": [
            "data-contract-ir-builder",
            "serialization-mutation-pack",
            "serialization-library-mapper",
            "message-serialization-verifier",
            "cache-serialization-verifier",
            "communication-serialization-view",
            "field-presence-verifier",
            "json-semantic-pack",
            "xml-semantic-pack",
            "protobuf-semantic-pack",
            "avro-semantic-pack",
            "messagepack-and-cbor-pack",
            "custom-binary-protocol-pack",
            "polymorphic-serialization-verifier",
            "numeric-serialization-verifier",
            "date-and-duration-serialization-verifier",
            "binary-data-serialization-verifier",
            "serialization-resource-limit-verifier",
            "serialization-differential-harness",
            "schema-evolution-mutation-pack",
        ],
        "planned": [361, 492, 523, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642],
    },
    "ADR-MIG-P1-03": {
        "family": "context propagation",
        "authority": "framework-context-propagation-ir",
        "merged_from": [
            "Skill 452 (infrastructure context and cancellation)",
            "Skill 602 (communication context)",
            "Skill 719 (distributed context propagation)",
        ],
        "merged_fields": [
            "Each context field declares who creates it, who propagates it, who may mutate it, which "
            "call types it reaches, whether a background task inherits it, and when it is cleared.",
            "A background task never inherits an end-user authority implicitly.",
        ],
        "views": [
            "infrastructure-context-cancellation-view",
            "communication-context-view",
            "cancellation-propagation-verifier",
            "distributed-context-propagation-verifier",
        ],
        "planned": [452, 602, 706, 719, 260],
    },
    "ADR-MIG-P1-04": {
        "family": "shadow side-effect isolation",
        "authority": "shadow-side-effect-firewall",
        "merged_from": [
            "Skill 425 (replacement shadow validation)",
            "Skill 586-591 (infrastructure shadow)",
            "Skill 750-754 (communication shadow)",
        ],
        "merged_fields": [
            "Every shadow mechanism in any layer declares which of the six interception modes it uses.",
            "Real dual-write requires a separate written approval and is never a default mode.",
        ],
        "views": [
            "shadow-deployment-planner",
            "shadow-state-write-simulator",
            "shadow-differential-analyzer",
            "shadow-coverage-analyzer",
            "effect-intent-recorder",
            "replacement-shadow-validation",
            "infrastructure-shadow-driver",
            "database-shadow-write-comparator",
            "cache-dual-read-monitor",
            "search-dual-index-verifier",
            "object-storage-dual-write-verifier",
            "messaging-shadow-consumer",
            "gateway-canary-and-shadow-verifier",
            "api-shadow-traffic-replicator",
            "rpc-shadow-caller",
            "schema-shadow-decoder",
            "gateway-shadow-route-verifier",
            "mesh-shadow-policy-verifier",
        ],
        "planned": [425, 586, 587, 588, 589, 590, 591, 750, 751, 752, 753, 754],
    },
    "ADR-MIG-P1-05": {
        "family": "certification evidence custody",
        "authority": "certification-evidence-vault",
        "merged_from": [
            "Skill 178 (path evidence bundle)",
            "Skill 427 (replacement evidence vault)",
            "Skill 609 (communication evidence recorder)",
        ],
        "merged_fields": [
            "One content-addressed vault holds evidence for every object type; the object type is a "
            "parameter, not a reason for a second vault.",
            "Pack versions, toolchain fingerprints and layer levels are stored with every bundle.",
        ],
        "views": [
            "path-evidence-bundle",
            "replacement-evidence-vault",
            "communication-evidence-recorder",
        ],
        "planned": [427, 609],
    },
    "ADR-MIG-P1-06": {
        "family": "certification revocation",
        "authority": "certification-revocation-monitor",
        "merged_from": [
            "Skill 428 (replacement certification revocation)",
            "Skill 763 (communication certification revocation)",
        ],
        "merged_fields": [
            "One revocation engine watches the causal inputs of every certification object type and "
            "emits the same four states.",
            "Recovery from a downgraded state requires new evidence; an approval alone never restores it.",
        ],
        "views": [
            "replacement-certification-revocation-monitor",
            "communication-certification-revocation",
        ],
        "planned": [428, 763],
    },
    "ADR-MIG-P1-07": {
        "family": "retry budget",
        # Skill 707 landed in Segment 3 (Batch 149), so the authority is present and the
        # `authority_present` escape hatch is no longer engaged for this family. The flag
        # remains supported for any future family whose authority is written after its views.
        "authority": "distributed-retry-budget-authority",
        "authority_present": True,
        "merged_from": [
            "Skill 453 (infrastructure retry)",
            "Skill 707 (distributed retry budget)",
        ],
        "merged_fields": [
            "Gateway, mesh, driver and application retry configuration all reference one shared budget document.",
            "Measured retry amplification above the declared ceiling blocks promotion regardless of success rate.",
        ],
        "views": [
            "infrastructure-retry-ir",
            "deadlock-and-serialization-retry-verifier",
            "gateway-retry-verifier",
            "mesh-retry-interaction-verifier",
            "distributed-call-amplification-detector",
            "distributed-retry-storm-test",
        ],
        "planned": [453, 681, 694, 707, 722, 743],
    },
}

# P1-4 from the review: the retry budget authority lives entirely in the unimplemented
# range, so it is recorded here for the Skill 327-764 generator rather than applied now.
RETRY_BUDGET_AUTHORITY = {
    "family": "retry budget",
    "authority_planned": 707,
    "views_planned": [453, 681, 694, 743, 722],
    "rule": (
        "Gateway, mesh, driver and application retry configuration must reference one shared budget "
        "document; measured amplification above the declared ceiling blocks promotion."
    ),
}


def authority_slugs():
    return {
        entry["authority"]
        for entry in CONVERGENCE.values()
        if entry.get("authority_present", True)
    }


def view_slug_map():
    mapping = {}
    for adr, entry in CONVERGENCE.items():
        for slug in entry["views"]:
            mapping[slug] = (adr, entry["family"], entry["authority"])
    return mapping


def authority_slug_map():
    return {
        entry["authority"]: (adr, entry["family"], entry["merged_fields"])
        for adr, entry in CONVERGENCE.items()
        if entry.get("authority_present", True)
    }


def pending_authorities():
    """Families whose authority Skill has not been emitted yet."""
    return {
        adr: entry["authority"]
        for adr, entry in CONVERGENCE.items()
        if not entry.get("authority_present", True)
    }
