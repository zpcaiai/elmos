"""Regenerate an interim package with the current data and patched scripts."""
import sys, importlib
from pathlib import Path
sys.path.insert(0, "gen")
target, last, openb = sys.argv[1], int(sys.argv[2]), (None if sys.argv[3] == "none" else int(sys.argv[3]))
g = importlib.import_module("generate")
g.PACKAGE = target
g.ROOT = Path(target).resolve()
g.BATCH_NUMBERS = list(range(105, last + 1))
g.OPEN_BATCH = openb
raise SystemExit(g.main())
