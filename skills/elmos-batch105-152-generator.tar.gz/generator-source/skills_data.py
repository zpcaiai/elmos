"""Skill definitions for the ELMOS Batch 105-114 polyglot migration assurance package.

Each entry is:
    (slug, title, objective, keywords, outputs, required_checks, negative_tests)

`outputs` lists the three Skill-specific artifacts; `evidence_bundle.json` and
`completion_report.md` are appended by the generator.
"""

BATCHES = {
    105: {
        "title": "Source Baseline and Differential Verification Pack",
        "why": "Moves ELMOS from trusting a converted repository to treating the frozen source system as the executable specification.",
        "purpose": "freeze the source system as an immutable executable specification and prove target behaviour through deterministic dual-run differential execution across responses, persistent state, side effects, timing and concurrency.",
        "tooling": ["source baseline freezer", "differential harness", "side-effect recorder", "deterministic environment injector"],
    },
    106: {
        "title": "Adversarial Verification and Shadow Enablement Pack",
        "why": "Moves ELMOS from a self-reported conversion result to an adversarially attacked, objectively arbitrated release decision.",
        "purpose": "prove the verification suite can kill real conversion defects, force every difference to a terminal classification, keep the builder and the attacker separate, and prepare an isolated production shadow whose side effects cannot escape.",
        "tooling": ["fault injection runner", "mutation orchestrator", "difference classifier", "shadow side-effect firewall"],
    },
    107: {
        "title": "Progressive Traffic Migration and Rollback Pack",
        "why": "Moves ELMOS from a single cutover event to a sliced, single-writer, automatically reversible traffic migration.",
        "purpose": "decompose the legacy system into independently migratable strangler units and move real traffic in controlled slices with stable routing, single-writer ownership, dual-read verification and a rehearsed automatic rollback at every stage.",
        "tooling": ["strangler boundary designer", "traffic slice controller", "single-writer enforcer", "rollback drill harness"],
    },
    108: {
        "title": "Certification Pipeline and Legacy Retirement Pack",
        "why": "Moves ELMOS from an informal correctness percentage to a scoped, revocable, evidence-bound certification ladder.",
        "purpose": "operate the E1 through E5 certification pipeline, reconcile data and side effects after every stage, preserve auditable evidence, revoke certification when causal inputs change, and retire the legacy system only after its hidden dependencies are drained.",
        "tooling": ["certification pipeline runner", "reconciliation engine", "evidence vault", "legacy drain monitor"],
    },
    109: {
        "title": "Migration Governance and Semantic Inventory Pack",
        "why": "Moves ELMOS from scattered migration decisions to a governed control tower backed by a complete repository semantic inventory.",
        "purpose": "govern the migration with a single control tower, privacy and cost guards, incident handling and an auditable decision journal, then open the semantic phase by inventorying every module, symbol, entrypoint and type in the source repository.",
        "tooling": ["migration control tower", "privacy and cost guard", "repository semantic inventory", "unified symbol identity builder"],
    },
    110: {
        "title": "Semantic IR Core and Language Frontend Pack",
        "why": "Moves ELMOS from syntax-level translation to a language-neutral semantic intermediate representation extracted by compiler-grade frontends.",
        "purpose": "build the lifetime, effect, state, concurrency, ordering, transaction, framework, metaprogramming, data-contract and platform layers of the unified Semantic IR, and extract them faithfully from six of the nine supported source languages.",
        "tooling": ["semantic IR builder", "compiler frontend adapters", "runtime trace collector", "ABI and layout inspector"],
    },
    111: {
        "title": "Language Backend and Directional Path Pack",
        "why": "Moves ELMOS from a single generic code generator to nine validating target backends bound to seventy-two asymmetric directional path profiles.",
        "purpose": "extract Semantic IR from the three native source languages, plan and validate target-side semantics for all nine target languages, and register the seventy-two directional paths with their capability vectors, semantic gaps and certification ceilings.",
        "tooling": ["target semantic planner", "target backend validators", "directional path registry", "language capability vector"],
    },
    112: {
        "title": "Type, Memory and Concurrency Mapping Pack",
        "why": "Moves ELMOS from name-level type mapping to verified scalar, collection, ownership, lifetime and concurrency semantics across every directional path.",
        "purpose": "verify that scalar precision, string encoding, collection semantics, enum forward compatibility, callback lifetime, ownership model, deterministic cleanup, native memory safety and concurrency model survive each directional conversion.",
        "tooling": ["type mapping verifier", "ownership planner", "native sanitizer adapter", "concurrency model translator"],
    },
    113: {
        "title": "Dynamic Behavior, Framework and Normalization Pack",
        "why": "Moves ELMOS from guessing at dynamic and framework behaviour to capturing it at runtime and normalizing it for honest comparison.",
        "purpose": "capture runtime-only dynamic behaviour, freeze it into migratable registries, map framework lifecycle and ORM semantics across ecosystems, and normalize cross-language values, identities, errors, traces and crashes without concealing real defects.",
        "tooling": ["dynamic runtime trace collector", "framework capability matcher", "ORM semantic verifier", "cross-language normalizer"],
    },
    114: {
        "title": "Specialized Testing, Mutation and IR Verification Pack",
        "why": "Moves ELMOS from generic test generation to path-specific attack suites and bidirectional Semantic IR equivalence proof.",
        "purpose": "generate path-specific fault injection, mutation, matrix and ceiling artifacts, reconstruct Semantic IR from generated target code, and detect both semantic loss and unauthorized semantic expansion before any certification claim.",
        "tooling": ["directional mutation library", "path matrix compiler", "target IR reconstructor", "semantic loss detector"],
    },
}

SKILLS = {}

SKILLS[105] = [
    (
        "source-system-freeze",
        "Source System Freeze",
        "Freeze the source commit, dependency closure, toolchain, runtime, database schema and configuration into an immutable reproducible baseline",
        ["commit pinning", "dependency lock", "reproducible build", "image digest"],
        ["source_baseline.json", "dependency_lock_report.json", "reproducibility_report.md"],
        [
            "Two independent builds of the same commit produce identical artifact digests.",
            "No floating version range or `latest` image reference remains in the closure.",
            "Database schema, migrations and default configuration are exported and hashed.",
        ],
        [
            "an uncommitted or dirty working tree presented as a baseline",
            "an unpinned transitive dependency or mutable base image",
            "a build whose output digest changes between identical runs",
        ],
    ),
    (
        "executable-specification-capture",
        "Executable Specification Capture",
        "Convert observed source behaviour into immutable scenario fixtures binding input, environment, initial state, output, final state, side effects and timing",
        ["scenario capture", "fixture immutability", "observable output", "initial state reconstruction"],
        ["scenario_library.json", "fixture_index.json", "capture_coverage.md"],
        [
            "Every identified entrypoint has normal, boundary, error and concurrent scenarios.",
            "The initial state of each scenario is fully reconstructable from the fixture.",
            "Captured scenarios replay deterministically against the frozen source baseline.",
        ],
        [
            "a scenario whose initial state cannot be reconstructed",
            "a side effect that the capture harness cannot observe",
            "source behaviour that does not reproduce across repeated captures",
        ],
    ),
    (
        "behavioral-boundary-definition",
        "Behavioral Boundary Definition",
        "Declare for every observable field whether equivalence is exact, tolerant, normalized, unordered or relational",
        ["equivalence profile", "tolerance policy", "normalization rule", "relational identity"],
        ["equivalence_profile.json", "comparison_rules.json", "boundary_rationale.md"],
        [
            "Monetary, permission, status, error-code and count fields are compared exactly.",
            "Sequences with business ordering are never declared unordered collections.",
            "Identifier normalization preserves every declared reference relationship.",
        ],
        [
            "a floating-point tolerance applied to a monetary field",
            "a blanket identifier suppression that also hides reference breakage",
            "an ordered event sequence compared as an unordered set",
        ],
    ),
    (
        "differential-execution-harness",
        "Differential Execution Harness",
        "Execute source and target on identical inputs and initial state and diff every declared observable channel",
        ["dual run", "channel capture", "structured diff", "minimal reproduction"],
        ["differential_run.json", "difference_report.json", "minimal_repro.md"],
        [
            "Both systems start from byte-identical initial state and injected environment.",
            "Every declared observable channel is captured on both sides of the run.",
            "Each mismatch is reduced to a minimal reproducible scenario before reporting.",
        ],
        [
            "a target self-test result substituted for a differential run",
            "a declared observable channel that was never captured",
            "a reported difference that cannot be reproduced from the stored fixture",
        ],
    ),
    (
        "side-effect-capture",
        "Side Effect Capture",
        "Capture database, cache, message, external call, file and device effects that a return value alone cannot reveal",
        ["effect interception", "call counting", "ordering capture", "idempotency key"],
        ["side_effect_log.json", "effect_ordering.json", "capture_gap_report.md"],
        [
            "Call counts, arguments and headers are recorded for every effect class.",
            "Each effect records its position relative to transaction commit and response.",
            "Payment, messaging and notification effects are intent-captured, never executed.",
        ],
        [
            "a real payment or notification executed during capture",
            "a duplicated external call that the counter did not record",
            "an effect recorded without its transaction phase",
        ],
    ),
    (
        "database-state-differ",
        "Database State Differ",
        "Compare final rows, write sets, transaction traces and SQL behaviour between source and target",
        ["write set", "transaction trace", "isolation level", "generated identifier"],
        ["db_state_diff.json", "write_set_diff.json", "transaction_trace_diff.md"],
        [
            "Final table contents match under the declared equivalence profile.",
            "Commit, rollback and savepoint decisions match for every scenario.",
            "Decimal precision, timestamp resolution and null semantics are preserved.",
        ],
        [
            "a source rollback paired with a target commit",
            "a null value written as an empty string by an ORM default",
            "a decimal silently truncated by target type mapping",
        ],
    ),
    (
        "message-semantics-verifier",
        "Message Semantics Verifier",
        "Verify publish, consume, acknowledgement, retry, ordering and dead-letter semantics against the source",
        ["publish count", "ack timing", "dead letter", "outbox recovery"],
        ["message_semantics_diff.json", "delivery_trace.json", "ordering_report.md"],
        [
            "Publish and consume counts match exactly for every scenario.",
            "Acknowledgement occurs at the same transaction phase as in the source.",
            "Duplicate delivery does not produce duplicate business state.",
        ],
        [
            "a message published after its transaction rolled back",
            "an acknowledgement moved from after commit to before commit",
            "an ordering constraint relaxed without an approved decision record",
        ],
    ),
    (
        "external-call-intent-verifier",
        "External Call Intent Verifier",
        "Compare outbound endpoint, payload, headers, timeout, retry policy, idempotency key and error mapping",
        ["endpoint parity", "retry policy", "idempotency key", "error mapping"],
        ["external_call_diff.json", "retry_policy_report.json", "error_mapping_matrix.md"],
        [
            "Call counts and monetary arguments match exactly.",
            "Idempotency keys are byte-identical for equivalent business operations.",
            "Host, trace and token differences are normalized without hiding payload changes.",
        ],
        [
            "a duplicate charge issued after a failed first attempt",
            "a mutated or regenerated idempotency key",
            "a default request parameter changed by the target client library",
        ],
    ),
    (
        "deterministic-environment-injector",
        "Deterministic Environment Injector",
        "Inject identical clock, timezone, randomness, identifier sequences, scheduling and dependency responses into both systems",
        ["clock injection", "seeded randomness", "identifier sequence", "scheduling script"],
        ["environment_profile.json", "injection_report.json", "determinism_audit.md"],
        [
            "No direct system clock, randomness or hostname call survives in either system.",
            "Repeated runs of the same scenario produce byte-identical observable output.",
            "Concurrency scenarios replay from a recorded, reproducible schedule.",
        ],
        [
            "an unintercepted DNS lookup or network egress",
            "a test outcome that depends on execution order",
            "a concurrency result that does not reproduce from its recorded schedule",
        ],
    ),
    (
        "differential-normalizer",
        "Differential Normalizer",
        "Remove non-semantic differences from a differential result without concealing a real defect",
        ["field ordering", "identifier mapping", "tolerance window", "noise filter"],
        ["normalization_rules.json", "normalized_diff.json", "suppression_audit.md"],
        [
            "Every suppression rule names the semantic property it claims to preserve.",
            "Identifier remapping preserves referential integrity across the whole payload.",
            "Monetary, count, error-type and row-count fields are never suppressed.",
        ],
        [
            "a global identifier suppression rule",
            "an array treated as unordered without a declared identity key",
            "a database row-count difference removed by normalization",
        ],
    ),
    (
        "original-test-migration",
        "Original Test Migration",
        "Migrate every existing source test without deleting, skipping or weakening an assertion",
        ["assertion parity", "fixture parity", "mock parity", "skip accounting"],
        ["test_migration_map.json", "assertion_parity_report.json", "migration_risk_log.md"],
        [
            "Every source assertion maps to a target assertion of equal or greater strength.",
            "Mock behaviour, fixtures and time or randomness pinning are preserved.",
            "Every skipped, removed or weakened test produces a migration risk record.",
        ],
        [
            "a failing assertion relaxed into a smoke check",
            "a hard-to-migrate test deleted without a risk record",
            "an exception assertion reduced to asserting that no exception was raised",
        ],
    ),
    (
        "production-traffic-replay",
        "Production Traffic Replay",
        "Replay redacted historical production requests offline against both systems to surface undocumented behaviour",
        ["redaction", "request correlation", "dependency stubbing", "difference clustering"],
        ["replay_corpus.json", "replay_diff_report.json", "extracted_regressions.md"],
        [
            "Credentials and personal data are removed before any replay executes.",
            "Each replayed request is paired with a reconstructed initial state.",
            "Long-tail, malformed and historical-incident requests are represented.",
        ],
        [
            "a replay executed against real production dependencies",
            "a corpus restricted to high-frequency happy paths",
            "an unredacted payload retained inside evidence",
        ],
    ),
    (
        "property-test-generator",
        "Property Test Generator",
        "Derive invariant-based tests from business rules independently of both the source and the target implementation",
        ["domain invariant", "input generator", "shrinker", "minimal counterexample"],
        ["property_suite.json", "generator_spec.json", "counterexample_log.md"],
        [
            "Properties are derived from business rules, not restated from either implementation.",
            "Every failing property shrinks to a minimal counterexample.",
            "Conservation, idempotency, authorization and state-machine properties are covered.",
        ],
        [
            "a property restated from target source code",
            "a failing property that does not shrink",
            "a property that both systems satisfy trivially for every input",
        ],
    ),
    (
        "boundary-and-fuzz-test-generator",
        "Boundary and Fuzz Test Generator",
        "Generate extreme, malformed, temporal and concurrent inputs across the declared input space",
        ["extreme value", "malformed payload", "temporal boundary", "concurrency boundary"],
        ["fuzz_corpus.json", "boundary_matrix.json", "crash_triage.md"],
        [
            "Numeric, string, unicode, collection and temporal boundaries are covered.",
            "Daylight-saving, leap-day, month-end and clock-rollback cases are generated.",
            "Every crash or hang is captured with a replayable seed.",
        ],
        [
            "a corpus that never reaches an error handling path",
            "a seed that cannot reproduce its recorded failure",
            "a boundary case excluded from the gate without an approval record",
        ],
    ),
    (
        "mutation-test-orchestrator",
        "Mutation Test Orchestrator",
        "Prove the verification suite detects real conversion defects by injecting known fault classes into the target",
        ["mutation operator", "survivor analysis", "critical module threshold", "kill rate"],
        ["mutation_run.json", "survivor_report.json", "operator_coverage.md"],
        [
            "Critical modules reach the declared mutation score threshold.",
            "No mutant affecting money, permission, transaction or effect count survives.",
            "Operators cover the fault classes specific to the active language path.",
        ],
        [
            "a mutation score inflated by trivial operators",
            "a surviving critical mutant declared equivalent without proof",
            "a mutation run scoped only to already well-covered code",
        ],
    ),
    (
        "controlled-concurrency-explorer",
        "Controlled Concurrency Explorer",
        "Drive thread, coroutine and task scheduling deterministically to expose races that ordinary tests cannot trigger",
        ["schedule script", "interleaving exploration", "lost update", "deadlock detection"],
        ["schedule_scripts.json", "concurrency_diff.json", "race_repro.md"],
        [
            "Interleavings replay deterministically from a recorded schedule.",
            "Lock and transaction traces are compared, not only final state.",
            "Cancellation, timeout and retry races are explored explicitly.",
        ],
        [
            "a race that reproduces only by chance",
            "a deadlock masked by an automatic retry",
            "a duplicated side effect under concurrent submission",
        ],
    ),
]

SKILLS[106] = [
    (
        "fault-injection-runner",
        "Fault Injection Runner",
        "Verify behavioural equivalence under dependency failure, timeout, crash and partial execution",
        ["injection point", "partial execution", "compensation", "residual state"],
        ["fault_injection_plan.json", "fault_run_results.json", "recovery_report.md"],
        [
            "Faults are injected before and after every declared side effect.",
            "Idempotency holds across the retry that follows each injected fault.",
            "No permanent intermediate state remains after recovery completes.",
        ],
        [
            "a duplicate charge produced by a post-commit failure",
            "a message lost or a phantom message emitted during recovery",
            "an intermediate state that survives the declared compensation",
        ],
    ),
    (
        "critical-invariant-verifier",
        "Critical Invariant Verifier",
        "Enforce one hundred percent verification of monetary, authorization, tenancy, state-machine and idempotency invariants",
        ["conservation invariant", "authorization invariant", "state machine invariant", "idempotency invariant"],
        ["invariant_catalog.json", "invariant_run_results.json", "violation_report.md"],
        [
            "Total value conservation holds across every successful and failed operation.",
            "A reduced permission set never yields an increased capability.",
            "Terminal states are never reopened without an explicit recovery event.",
        ],
        [
            "a tolerance or allowance configured for a critical invariant",
            "a cross-tenant read or write that the suite did not flag",
            "an illegal state transition accepted by the target",
        ],
    ),
    (
        "release-gate-evaluator",
        "Release Gate Evaluator",
        "Decide with machine-executable rules whether a module may advance to the next verification stage",
        ["gate rule", "threshold policy", "non-averaging", "blocking condition"],
        ["release_gate_policy.json", "gate_evaluation.json", "gate_decision.md"],
        [
            "Critical dimensions are evaluated independently and never averaged together.",
            "Money, permission, transaction and effect-count gates require a full pass.",
            "Every gate decision names the exact evidence records that satisfied it.",
        ],
        [
            "a weighted average that hides a failed critical dimension",
            "a gate passed with a stale or missing evidence reference",
            "a threshold lowered after the results were already known",
        ],
    ),
    (
        "difference-classifier",
        "Difference Classifier",
        "Assign every observed difference a terminal classification and forbid an unresolved difference from reaching a release decision",
        ["classification taxonomy", "root cause", "approval record", "regression capture"],
        ["difference_classification.json", "classification_audit.json", "unresolved_register.md"],
        [
            "Every difference carries a terminal category, an owner and an approver.",
            "Each accepted difference is bound to a new permanent regression test.",
            "The unresolved difference count is zero before any promotion is evaluated.",
        ],
        [
            "a difference closed as probably harmless",
            "an intentional change accepted without a named business approver",
            "a source defect classification asserted without corroborating evidence",
        ],
    ),
    (
        "migration-builder-role-guard",
        "Migration Builder Role Guard",
        "Constrain the building agent to construction, diagnosis and repair while forbidding it from adjudicating its own correctness",
        ["role separation", "repair provenance", "prohibited action", "decision record"],
        ["builder_action_log.json", "repair_provenance.json", "builder_decision_record.md"],
        [
            "Every repair cites the failing evidence record that motivated it.",
            "The builder never authors or edits a gate result or certification state.",
            "Every behavioural change made during repair produces a decision record.",
        ],
        [
            "the builder declaring the migration correct",
            "a failing test deleted, skipped or weakened during repair",
            "a business behaviour changed without a recorded decision",
        ],
    ),
    (
        "adversarial-verifier-role",
        "Adversarial Verifier Role",
        "Operate an independent attacker that assumes hidden non-equivalence and refuses the builder conclusions",
        ["independent attacker", "attack path", "minimal counterexample", "blocking recommendation"],
        ["attack_plan.json", "counterexample_set.json", "attack_findings.md"],
        [
            "The attacker consumes only artifacts and evidence, never builder assurances.",
            "Every finding ships a minimal reproducible counterexample.",
            "Findings recommend concrete new tests and mutation operators.",
        ],
        [
            "an attack plan derived from the builder own summary",
            "a finding without a reproducible counterexample",
            "an attacker and builder sharing a single identity or run context",
        ],
    ),
    (
        "objective-tool-arbiter",
        "Objective Tool Arbiter",
        "Ensure final evidence originates from deterministic tools rather than any model judgement",
        ["deterministic arbiter", "tool provenance", "tamper evidence", "reproducible measurement"],
        ["arbiter_registry.json", "tool_evidence_index.json", "arbitration_report.md"],
        [
            "Every blocking result traces to a named tool, version and exit code.",
            "Model output is recorded as analysis and never as an authoritative verdict.",
            "Arbiter measurements reproduce from the recorded environment fingerprint.",
        ],
        [
            "a model assertion recorded as a passing verdict",
            "a tool result without version, environment or exit code",
            "an arbitration outcome that does not reproduce",
        ],
    ),
    (
        "evidence-level-assessor",
        "Evidence Level Assessor",
        "Assign a module a bounded evidence level instead of an unqualified correctness percentage",
        ["evidence ladder", "scoped claim", "claim wording", "ceiling enforcement"],
        ["evidence_level_assessment.json", "claim_boundary.json", "assessment_rationale.md"],
        [
            "The assigned level names the exact evidence that supports it.",
            "The published claim is bounded by input space, environment and time scope.",
            "The assigned level never exceeds the directional path certification ceiling.",
        ],
        [
            "a claim of absolute equivalence for arbitrary future inputs",
            "an evidence level promoted without the mandatory fresh evidence",
            "a percentage score published in place of a scoped level",
        ],
    ),
    (
        "migration-risk-ledger",
        "Migration Risk Ledger",
        "Maintain every open migration risk with severity, mitigation, owner and release-blocking status",
        ["risk record", "unsupported feature", "mitigation", "formal acceptance"],
        ["risk_ledger.json", "blocking_risk_report.json", "risk_acceptance_log.md"],
        [
            "Every unsupported feature and unresolved dynamic behaviour has a risk record.",
            "Release-blocking risks are closed or formally accepted before promotion.",
            "Each acceptance names an authorized approver and an expiry date.",
        ],
        [
            "an unsupported language feature discovered outside the ledger",
            "a release-blocking risk silently downgraded",
            "a risk acceptance without an approver or expiry",
        ],
    ),
    (
        "shadow-deployment-planner",
        "Shadow Deployment Planner",
        "Plan a production shadow run in which the source remains authoritative and the target cannot affect real outcomes",
        ["shadow boundary", "replication point", "authority declaration", "shutdown condition"],
        ["shadow_plan.json", "shadow_topology.json", "shadow_runbook.md"],
        [
            "The source system remains the sole authority for responses and writes.",
            "Every target side-effect class has a declared isolation mechanism.",
            "Shadow failure cannot degrade or delay the source request path.",
        ],
        [
            "a target side effect that cannot be deterministically intercepted",
            "a shadow request that can enlist in a source transaction",
            "shadow evidence that cannot be correlated to its originating request",
        ],
    ),
    (
        "traffic-replication-gateway",
        "Traffic Replication Gateway",
        "Replicate real production requests to the shadow target while fully isolating the source request path",
        ["asynchronous replication", "stable hash sampling", "backpressure", "circuit breaker"],
        ["replication_config.json", "replication_evidence.json", "isolation_report.md"],
        [
            "Replication is asynchronous and shares no bounded pool with the source path.",
            "Sampling uses a stable hash so an entity stays in one cohort over time.",
            "Business headers, tenancy, locale and idempotency keys are preserved.",
        ],
        [
            "a shadow failure that surfaces in a user-visible response",
            "random per-request sampling that splits one entity across cohorts",
            "a replicated request whose authentication token was not substituted",
        ],
    ),
    (
        "production-data-replica-manager",
        "Production Data Replica Manager",
        "Provide the shadow target a sufficiently current data view without granting it production write access",
        ["read replica", "snapshot clone", "change data capture", "replication lag"],
        ["replica_topology.json", "replica_consistency.json", "replica_gap_report.md"],
        [
            "The target database identity holds no production write privilege.",
            "Replication lag stays inside the declared business tolerance.",
            "Schema digests, triggers and required tables match the production source.",
        ],
        [
            "a target credential that can write to production",
            "a missing table or unsynchronized trigger in the replica",
            "a redaction rule that changes a business decision",
        ],
    ),
    (
        "shadow-side-effect-firewall",
        "Shadow Side-Effect Firewall",
        "Prevent the shadow target from producing any real external effect and convert each attempt into a comparable intent record",
        ["deny mode", "record only mode", "topic rewrite", "dual layer protection"],
        ["firewall_rules.json", "interception_log.json", "escape_audit.md"],
        [
            "Every irreversible effect class is denied or intent-captured deterministically.",
            "Application-level substitution is backed by credential or network denial.",
            "Message topics and storage buckets are rewritten to shadow namespaces.",
        ],
        [
            "the target holding a production payment or messaging credential",
            "an effect escaping through a dynamically constructed endpoint",
            "a production topic reachable from the shadow target",
        ],
    ),
    (
        "effect-intent-recorder",
        "Effect Intent Recorder",
        "Convert an unexecuted shadow side effect into standardized evidence comparable with the real source effect",
        ["intent schema", "sequence position", "transaction phase", "retry policy"],
        ["effect_intent_log.json", "intent_comparison.json", "intent_schema_report.md"],
        [
            "Each intent records operation, arguments, sequence and transaction phase.",
            "Idempotency keys and retry policies are captured verbatim.",
            "Intents are compared against real source effects, never skipped as unexecuted.",
        ],
        [
            "an intent omitted because it was not really executed",
            "an intent missing its ordering or transaction phase",
            "an intent whose destination is not proven equivalent to the source target",
        ],
    ),
    (
        "shadow-state-write-simulator",
        "Shadow State Write Simulator",
        "Let the shadow target execute its full write path while confining the writes to an isolated store",
        ["write isolation", "schema rewrite", "tenant rewrite", "post-commit hook"],
        ["write_isolation_config.json", "shadow_write_set.json", "isolation_risk_report.md"],
        [
            "Isolated writes reproduce the full write set, constraints and generated identifiers.",
            "Post-commit hooks, outbox rows and cache invalidations are exercised or declared missing.",
            "Critical write flows use an isolated store rather than transaction rollback alone.",
        ],
        [
            "a rollback-only strategy used for a flow with post-commit behaviour",
            "an isolated write that leaked into a production schema or tenant",
            "an asynchronous task started before the simulated transaction unwound",
        ],
    ),
    (
        "shadow-differential-analyzer",
        "Shadow Differential Analyzer",
        "Normalize and diff live shadow results in real time across request, entity, session, window and statistical levels",
        ["real-time diff", "entity-level consistency", "risk scoring", "immediate alert"],
        ["shadow_diff_stream.json", "diff_aggregation.json", "alert_policy.md"],
        [
            "Request, entity, session, window and statistical levels are all evaluated.",
            "Monetary, authorization, tenancy and effect-count differences alert immediately.",
            "Each alert carries a correlation identifier back to the original request.",
        ],
        [
            "an aggregate pass rate that conceals a critical per-request difference",
            "an event ordering inversion reported as equivalent",
            "an alert that cannot be traced to its originating production request",
        ],
    ),
]

SKILLS[107] = [
    (
        "shadow-coverage-analyzer",
        "Shadow Coverage Analyzer",
        "Prove that shadow traffic actually covered the business input space rather than accumulating request volume",
        ["scenario coverage", "state transition coverage", "long tail", "uncovered register"],
        ["coverage_matrix.json", "uncovered_scenarios.json", "coverage_rationale.md"],
        [
            "Critical APIs, business scenarios and state transitions reach full coverage.",
            "Every historical severe incident scenario is represented in the traffic.",
            "The uncovered critical scenario count is zero before promotion.",
        ],
        [
            "a request count presented as proof of coverage",
            "a corpus dominated by a single read endpoint",
            "a known exception path never exercised by shadow traffic",
        ],
    ),
    (
        "shadow-performance-profiler",
        "Shadow Performance Profiler",
        "Compare source and target latency, throughput and resource behaviour under real production input",
        ["latency percentile", "resource accounting", "warm state parity", "cost attribution"],
        ["performance_baseline.json", "regression_report.json", "fairness_notes.md"],
        [
            "Both systems are measured under identical input, data state and warm-up.",
            "Suppressed external effects are compensated with equivalent latency simulation.",
            "Compute, database and dependency time are attributed separately.",
        ],
        [
            "a target advantage caused only by suppressed side effects",
            "a comparison across mismatched instance classes",
            "a percentile computed over a window the source never served",
        ],
    ),
    (
        "strangler-boundary-designer",
        "Strangler Boundary Designer",
        "Decompose the legacy system into units that can be migrated, verified, sliced and rolled back independently",
        ["migratable unit", "entrypoint definition", "rollback complexity", "data ownership"],
        ["strangler_units.json", "boundary_analysis.json", "sequencing_rationale.md"],
        [
            "Every unit declares explicit entrypoints and data ownership.",
            "No unit leaves the old and new systems writing one state without coordination.",
            "Rollback for each unit avoids irreversible data recovery.",
        ],
        [
            "a unit without a definable entrypoint",
            "two systems writing the same aggregate without an ownership rule",
            "a dependency cycle that no proposed boundary can cut",
        ],
    ),
    (
        "migration-dependency-graph-builder",
        "Migration Dependency Graph Builder",
        "Build the module dependency graph that determines a safe migration order",
        ["topological order", "hidden coupling", "parallel group", "migration island"],
        ["dependency_graph.json", "migration_order.json", "coupling_report.md"],
        [
            "Synchronous, asynchronous, data and transaction edges are all modelled.",
            "Shared-table writes and cross-module transactions are surfaced explicitly.",
            "Cycles are reported with the compatibility layer required to cut them.",
        ],
        [
            "a hidden shared-table write missing from the graph",
            "a legacy callback edge omitted from the ordering",
            "a proposed order that violates a transaction dependency",
        ],
    ),
    (
        "compatibility-facade-generator",
        "Compatibility Facade Generator",
        "Generate a stable adapter so existing callers need not migrate at the same time as the implementation",
        ["field mapping", "error translation", "version adapter", "retirement condition"],
        ["facade_spec.json", "mapping_matrix.json", "facade_debt_record.md"],
        [
            "Field mapping, default values and error codes round-trip without loss.",
            "Null, enum, pagination, timestamp and idempotency semantics are preserved.",
            "Each facade records its callers, usage volume and planned retirement date.",
        ],
        [
            "a field silently dropped by the facade",
            "an error code collapsed into a generic failure",
            "a facade created without a retirement condition",
        ],
    ),
    (
        "traffic-slice-controller",
        "Traffic Slice Controller",
        "Move real traffic from source to target in controlled, stable, reversible slices",
        ["slice dimension", "sticky routing", "eligibility rule", "stage progression"],
        ["slice_config.json", "routing_decisions.json", "slice_stability_report.md"],
        [
            "Routing is stable so one business entity does not oscillate between systems.",
            "Session, cache and asynchronous consumer ownership follow the slice.",
            "Scheduled jobs cannot execute twice across the two systems.",
        ],
        [
            "a per-request random route that splits one entity",
            "a scheduled job running in both systems during a slice",
            "a routing rule that does not survive a rollback",
        ],
    ),
    (
        "read-traffic-canary",
        "Read Traffic Canary",
        "Migrate read-only traffic first and prove the target truly performs no side effect",
        ["read parity", "permission filtering", "data freshness", "hidden effect"],
        ["read_canary_config.json", "read_parity_report.json", "hidden_effect_audit.md"],
        [
            "Responses, pagination, ordering and permission filtering match the source.",
            "Side-effect capture confirms the read path writes nothing observable.",
            "Data freshness stays inside the declared consistency window.",
        ],
        [
            "a read path that refreshes a cache or access timestamp",
            "a cross-tenant record exposed by a relaxed filter",
            "a read that triggers a billed downstream call",
        ],
    ),
    (
        "write-traffic-canary",
        "Write Traffic Canary",
        "Switch a low percentage of real write traffic while guaranteeing no effect is executed twice",
        ["authoritative writer", "cross-system idempotency", "dual write risk", "entry precondition"],
        ["write_canary_config.json", "write_parity_report.json", "duplication_audit.md"],
        [
            "Exactly one system is the authoritative writer for each request.",
            "Idempotency keys, outbox rows and message emission are unified across systems.",
            "Target writes remain readable by the source for the whole rollback window.",
        ],
        [
            "a dual-write configuration on a monetary or inventory flow",
            "a message emitted once by each system for one request",
            "a target write format the source cannot parse",
        ],
    ),
    (
        "single-writer-ownership-enforcer",
        "Single-Writer Ownership Enforcer",
        "Guarantee that each business entity or data domain has exactly one authoritative writer during migration",
        ["ownership granularity", "bucket assignment", "mutual rejection", "lease enforcement"],
        ["ownership_map.json", "enforcement_config.json", "ownership_violation_log.md"],
        [
            "Each system rejects writes for entities owned by the other.",
            "Ownership is enforced at routing, credential and application layers.",
            "Configuration divergence between nodes cannot open a dual-write window.",
        ],
        [
            "a window in which both systems may write one entity",
            "a retry that reaches the non-owning system and succeeds",
            "a manual administrative write that bypasses ownership",
        ],
    ),
    (
        "dual-read-consistency-monitor",
        "Dual-Read Consistency Monitor",
        "Read both systems during read migration and separate legitimate replication lag from real defects",
        ["oracle read", "consistency model", "lag tolerance", "false positive control"],
        ["dual_read_config.json", "consistency_findings.json", "lag_policy.md"],
        [
            "The declared consistency model and maximum lag are explicit and bounded.",
            "Permission filtering, ordering and aggregate computation are compared.",
            "Read-your-write visibility is verified after a target write.",
        ],
        [
            "replication lag reported as a business defect",
            "a tolerance widened until real defects disappear",
            "an empty result treated as equivalent to a filtered result",
        ],
    ),
    (
        "feature-flag-migration-controller",
        "Feature Flag Migration Controller",
        "Route between source and target through auditable, instantly reversible feature flags",
        ["flag rule", "sticky evaluation", "change audit", "emergency disable"],
        ["flag_definitions.json", "flag_change_audit.json", "flag_hygiene_report.md"],
        [
            "Every flag has an owner, an expiry and a bound metric.",
            "One request evaluates a flag once and reuses the decision.",
            "Flag service failure resolves to the safe source-authoritative default.",
        ],
        [
            "conflicting flag rules producing an undefined route",
            "a request that flips implementation mid-execution",
            "a flag service outage that routes traffic to the target by default",
        ],
    ),
    (
        "canary-cohort-selector",
        "Canary Cohort Selector",
        "Select a representative but risk-bounded first cohort of real tenants or users",
        ["cohort tiering", "representativeness", "exclusion rule", "reachability"],
        ["cohort_definition.json", "representativeness_report.json", "exclusion_rationale.md"],
        [
            "The cohort spans simple and complex tenants, not only the easiest ones.",
            "Regulated and high-value flows are explicitly excluded and recorded.",
            "Cohort members are reachable and their data is recoverable.",
        ],
        [
            "a cohort composed only of trivially simple tenants",
            "a regulated tenant included without approval",
            "a cohort whose data cannot be restored after a rollback",
        ],
    ),
    (
        "automated-rollback-policy-engine",
        "Automated Rollback Policy Engine",
        "Decide automatically from explicit metrics whether to freeze expansion, reduce traffic or fully roll back",
        ["rollback tier", "trigger condition", "zero tolerance", "automatic action"],
        ["rollback_policy.json", "trigger_evaluations.json", "policy_rationale.md"],
        [
            "Monetary, authorization, tenancy and duplicate-effect failures trigger full rollback.",
            "No critical failure class is configured with a tolerated occurrence count.",
            "Every trigger evaluation records the metric window and evidence used.",
        ],
        [
            "a tolerance count configured for duplicate payment",
            "a rollback trigger disabled during a promotion window",
            "an automatic action that fires without recording its evidence",
        ],
    ),
    (
        "rollback-executor",
        "Rollback Executor",
        "Execute an approved rollback safely without abandoning in-flight work that already produced external effects",
        ["ordered rollback", "in-flight policy", "evidence preservation", "reconciliation trigger"],
        ["rollback_runbook.json", "rollback_result.json", "affected_entities.md"],
        [
            "Traffic, consumers, scheduled jobs and write credentials are stopped in order.",
            "In-flight requests follow a declared completion, cancellation or compensation policy.",
            "Incident evidence is preserved before any cleanup begins.",
        ],
        [
            "an in-flight request terminated after a partial external effect",
            "a target consumer left running after rollback",
            "a rollback that discards the evidence needed to diagnose it",
        ],
    ),
    (
        "rollback-readiness-validator",
        "Rollback Readiness Validator",
        "Prove the rollback path actually works before any real traffic is switched",
        ["rehearsal scenario", "propagation time", "legacy capacity", "credential revocation"],
        ["rollback_drill_plan.json", "drill_results.json", "readiness_gap_report.md"],
        [
            "At least one production-equivalent rollback drill has completed.",
            "Route reversal and configuration propagation times are measured.",
            "The legacy system retains the capacity to absorb full traffic.",
        ],
        [
            "a rollback plan that exists only as documentation",
            "a drill that skipped the partial-write recovery scenario",
            "a configuration change that did not reach every routing node",
        ],
    ),
    (
        "backward-data-compatibility-verifier",
        "Backward Data Compatibility Verifier",
        "Guarantee the legacy system can still read and process everything the target writes",
        ["expand contract", "schema compatibility", "irreversible migration", "rollback safety"],
        ["compatibility_report.json", "incompatible_fields.json", "expand_contract_plan.md"],
        [
            "The legacy system parses every field the target writes.",
            "No required legacy field, enum value or key format was changed or reused.",
            "No irreversible data migration executes while rollback remains possible.",
        ],
        [
            "a status value the legacy system cannot interpret",
            "a reused enum ordinal with new meaning",
            "an irreversible compaction executed inside the rollback window",
        ],
    ),
]

SKILLS[108] = [
    (
        "schema-evolution-gate",
        "Schema Evolution Gate",
        "Govern database and message schema change so both systems remain operable throughout the migration",
        ["additive first", "consumer ordering", "online migration", "unknown field policy"],
        ["schema_change_plan.json", "compatibility_matrix.json", "evolution_gate_report.md"],
        [
            "Changes are additive and nullable first, with defaults that are explainable.",
            "Consumer and producer upgrade order is declared and enforced.",
            "Index and DDL operations avoid unacceptable locking windows.",
        ],
        [
            "a producer removing a field before consumers upgrade",
            "an irreversible migration without a recovery plan",
            "a consumer that crashes on an unknown enum value",
        ],
    ),
    (
        "data-reconciliation-engine",
        "Data Reconciliation Engine",
        "Reconcile source and target data and side effects after shadow, canary and rollback stages",
        ["row reconciliation", "balance reconciliation", "event reconciliation", "window strategy"],
        ["reconciliation_plan.json", "reconciliation_results.json", "mismatch_register.md"],
        [
            "Row, field, aggregate, balance, event and invariant levels are all reconciled.",
            "Accounting-style conservation checks close for every reconciled window.",
            "The unresolved mismatch count is zero before promotion is evaluated.",
        ],
        [
            "a reconciliation that only compares record counts",
            "a mismatch closed without a root cause",
            "a window whose conservation identity does not balance",
        ],
    ),
    (
        "production-diff-triage",
        "Production Diff Triage",
        "Cluster, prioritize and assign the differences observed during shadow and canary stages",
        ["difference clustering", "priority assignment", "root cause hypothesis", "task routing"],
        ["diff_clusters.json", "triage_assignments.json", "triage_summary.md"],
        [
            "Clusters carry an affected request count and an affected entity count.",
            "Monetary, authorization, tenancy and duplicate-effect clusters are top priority.",
            "Every cluster is routed to a named repair task and an independent review task.",
        ],
        [
            "a high-severity cluster reduced in priority to unblock a schedule",
            "a cluster without a minimal reproducible example",
            "a cluster left unassigned across a promotion boundary",
        ],
    ),
    (
        "canary-promotion-evaluator",
        "Canary Promotion Evaluator",
        "Decide whether the current traffic stage may advance to the next percentage",
        ["promotion gate", "minimum duration", "minimum volume", "objective trigger"],
        ["promotion_gate.json", "promotion_evaluation.json", "promotion_decision.md"],
        [
            "Minimum duration and minimum request volume are both satisfied.",
            "Unexplained differences, invariant failures and open reconciliations are zero.",
            "Rollback readiness is re-verified before the promotion decision is issued.",
        ],
        [
            "a promotion driven by schedule pressure rather than evidence",
            "a promotion issued while a reconciliation mismatch remains open",
            "a stage promoted before its minimum soak window elapsed",
        ],
    ),
    (
        "stage-soak-controller",
        "Stage Soak Controller",
        "Hold each traffic stage long enough to cover daily, weekly and rare periodic behaviour",
        ["soak window", "periodic job", "leak detection", "restart observation"],
        ["soak_policy.json", "soak_status.json", "soak_observations.md"],
        [
            "At least one traffic peak, one trough and one restart are observed.",
            "At least one full scheduled-job cycle executes inside the window.",
            "Memory, connection and file handle growth are stable across the window.",
        ],
        [
            "a stage promoted before a nightly batch cycle ran",
            "a memory growth trend excused as noise",
            "a soak window that never included a deployment or restart",
        ],
    ),
    (
        "e1-build-and-startup-certification",
        "E1 Build and Startup Certification",
        "Certify that the target builds, deploys, starts, health-checks and shuts down cleanly",
        ["build reproducibility", "deployable artifact", "health check", "graceful shutdown"],
        ["e1_certification.json", "startup_evidence.json", "e1_report.md"],
        [
            "Both the source baseline and the target build reproducibly.",
            "Configuration loads, migrations apply and health checks pass.",
            "Startup, readiness and graceful shutdown are all observed.",
        ],
        [
            "a build that succeeds only on one developer machine",
            "a health check that passes while a critical module failed to load",
            "an E1 claim presented as evidence of business correctness",
        ],
    ),
    (
        "e2-contract-certification",
        "E2 Contract Certification",
        "Certify that migrated original tests and all external contracts pass completely",
        ["original test parity", "contract test", "schema compatibility", "approved skip"],
        ["e2_certification.json", "contract_results.json", "e2_report.md"],
        [
            "Original and migrated tests pass without weakened assertions.",
            "API, database, message, configuration and error-code contracts are compatible.",
            "Every skipped critical test carries a recorded approval.",
        ],
        [
            "a suite that passes because assertions were relaxed",
            "a contract test disabled to unblock the gate",
            "an E2 claim treated as covering gaps the source tests never had",
        ],
    ),
    (
        "e3-behavioral-certification",
        "E3 Behavioral Certification",
        "Certify independent behavioural verification through differential, property, fuzz, replay and mutation evidence",
        ["differential evidence", "property evidence", "mutation threshold", "unexplained difference"],
        ["e3_certification.json", "behavioral_evidence_index.json", "e3_report.md"],
        [
            "Unexplained differences are zero and critical invariants fully pass.",
            "Critical mutation score meets threshold with no surviving critical mutant.",
            "Historical production traffic replay is included in the evidence set.",
        ],
        [
            "an E3 claim resting only on the target own test suite",
            "a mutation threshold met by excluding critical modules",
            "a difference reclassified rather than resolved to reach the threshold",
        ],
    ),
    (
        "e4-production-engineering-certification",
        "E4 Production Engineering Certification",
        "Certify concurrency, fault tolerance, performance, platform and rollback readiness for production entry",
        ["concurrency evidence", "fault injection evidence", "performance baseline", "rollback drill"],
        ["e4_certification.json", "engineering_evidence_index.json", "e4_report.md"],
        [
            "Concurrency exploration, fault injection and soak testing all pass.",
            "Performance and resource regressions stay inside declared budgets.",
            "A rollback drill and side-effect isolation verification have completed.",
        ],
        [
            "a performance baseline measured without production-like data volume",
            "a fault injection suite that never targeted post-commit failure",
            "an E4 claim without target platform verification",
        ],
    ),
    (
        "e5-production-confidence-certification",
        "E5 Production Confidence Certification",
        "Certify high-confidence equivalence under real production input and completed progressive traffic migration",
        ["shadow evidence", "canary completion", "stability window", "bounded claim"],
        ["e5_certification.json", "production_evidence_index.json", "e5_report.md"],
        [
            "All declared canary stages completed with zero unexplained differences.",
            "Duplicate side effects and unresolved reconciliations are zero.",
            "The published claim is explicitly bounded by scope, environment and time.",
        ],
        [
            "a claim of absolute equivalence for arbitrary inputs and schedules",
            "an E5 claim issued before the declared stability window elapsed",
            "an E5 claim while the legacy system can no longer be restored",
        ],
    ),
    (
        "certification-evidence-vault",
        "Certification Evidence Vault",
        "Preserve the complete auditable evidence behind every certification rather than only its final score",
        ["content addressing", "tamper evidence", "release binding", "retention policy"],
        ["evidence_bundle_index.json", "vault_integrity_report.json", "retention_policy.md"],
        [
            "Every evidence record is content-addressed, timestamped and version-bound.",
            "Evidence links to its exact release, environment and tool versions.",
            "Stored evidence can be re-executed or independently re-verified.",
        ],
        [
            "a certification retaining only a summary score",
            "an evidence record that can be altered without detection",
            "an evidence bundle that cannot be tied to a specific release",
        ],
    ),
    (
        "certification-revocation-monitor",
        "Certification Revocation Monitor",
        "Re-evaluate whether an existing certification still holds after code, dependency, runtime or environment change",
        ["causal input change", "revalidation scope", "partial validity", "revocation trigger"],
        ["revocation_watchlist.json", "certification_status.json", "revalidation_plan.md"],
        [
            "Every causal input of a certification is watched for change.",
            "A changed causal input downgrades the status rather than leaving it valid.",
            "The required re-check set is derived from what actually changed.",
        ],
        [
            "a certification treated as permanent after a runtime upgrade",
            "a dependency bump that did not trigger revalidation",
            "a status left valid while its evidence went stale",
        ],
    ),
    (
        "legacy-dependency-drain-monitor",
        "Legacy Dependency Drain Monitor",
        "Detect remaining hidden callers of the legacy system after full traffic cutover",
        ["residual caller", "call attribution", "administrative script", "third party callback"],
        ["legacy_call_inventory.json", "caller_attribution.json", "drain_status.md"],
        [
            "API, database, message, job, script and manual access paths are all monitored.",
            "Every remaining call is attributed to a named caller and purpose.",
            "The unexplained production call count is zero before shutdown.",
        ],
        [
            "a reporting job still querying the legacy database",
            "an administrative repair script with undocumented legacy access",
            "a third-party callback still routed to the legacy endpoint",
        ],
    ),
    (
        "legacy-system-freeze-mode",
        "Legacy System Freeze Mode",
        "Convert the legacy system to a read-only, standby, emergency or archived posture once the target is authoritative",
        ["posture selection", "credential revocation", "standby readiness", "archive retention"],
        ["freeze_mode_config.json", "revocation_evidence.json", "restart_runbook.md"],
        [
            "Write permissions, consumers and scheduled jobs are all disabled and verified.",
            "External side-effect credentials are revoked from the legacy system.",
            "The emergency restart procedure is documented and rehearsed.",
        ],
        [
            "a legacy consumer left subscribed after freeze",
            "a legacy credential that can still trigger an external effect",
            "a standby posture whose restart path was never tested",
        ],
    ),
    (
        "legacy-retirement-gate",
        "Legacy Retirement Gate",
        "Decide whether the legacy system may be formally retired",
        ["retirement condition", "observation period", "approval set", "historical access"],
        ["retirement_gate.json", "retirement_evidence.json", "retirement_decision.md"],
        [
            "The target holds a current E5 certification with stable full traffic.",
            "No unexplained legacy dependency and no message backlog remain.",
            "Business, operations and security owners have each approved.",
        ],
        [
            "retirement approved while an unexplained legacy call remains",
            "retirement without archived source code and build environment",
            "retirement before the declared observation period ended",
        ],
    ),
    (
        "migration-kill-switch",
        "Migration Kill Switch",
        "Provide an emergency termination path faster and more privileged than the normal release process",
        ["emergency authority", "propagation measurement", "independent control plane", "drill cadence"],
        ["kill_switch_config.json", "activation_evidence.json", "kill_switch_drill.md"],
        [
            "Activation does not depend on the target system remaining healthy.",
            "Propagation time is measured and bounded, not assumed.",
            "Activation is auditable and requires elevated or dual authorization.",
        ],
        [
            "a kill switch that depends on a single control plane",
            "a kill switch never exercised in a drill",
            "an activation path slower than the normal deployment pipeline",
        ],
    ),
]

SKILLS[109] = [
    (
        "migration-control-tower",
        "Migration Control Tower",
        "Provide one governed console for migration state, evidence, risk and control actions across every module",
        ["module state model", "evidence surface", "control action", "authorization boundary"],
        ["control_tower_state.json", "module_state_map.json", "control_action_log.md"],
        [
            "Every module has exactly one current state in the declared state model.",
            "Displayed certification levels reflect current, non-stale evidence.",
            "Every control action is authenticated, authorized and audited.",
        ],
        [
            "a module state advanced without its underlying evidence",
            "a control action executed without an audit record",
            "a dashboard level that outlived the evidence supporting it",
        ],
    ),
    (
        "shadow-privacy-and-compliance-guard",
        "Shadow Privacy and Compliance Guard",
        "Ensure production traffic replication and shadow data use satisfy privacy, security and regulatory obligations",
        ["data classification", "residency control", "retention limit", "deletion capability"],
        ["privacy_assessment.json", "redaction_policy.json", "compliance_findings.md"],
        [
            "Personal, payment and health data are classified before replication.",
            "Cross-region movement and third-party processing are explicitly authorized.",
            "Deletion requests can be executed against shadow stores and evidence.",
        ],
        [
            "sensitive production data entering a shadow environment unapproved",
            "a shadow log containing a plaintext credential",
            "a shadow store from which a deletion request cannot be satisfied",
        ],
    ),
    (
        "shadow-cost-guard",
        "Shadow Cost Guard",
        "Bound the cost of dual-system operation without weakening critical observation",
        ["tiered sampling", "evidence compression", "tail sampling", "budget alert"],
        ["cost_model.json", "sampling_policy.json", "cost_guard_report.md"],
        [
            "High-risk scenarios remain fully sampled while low-value traffic is reduced.",
            "Cost reduction never removes critical invariant or side-effect observation.",
            "Budget alerts fire before a hard spending limit is reached.",
        ],
        [
            "a sampling reduction that dropped a critical business scenario",
            "a retention cut that discarded severe-difference traces",
            "a cost optimization applied without recording what stopped being observed",
        ],
    ),
    (
        "production-migration-incident-manager",
        "Production Migration Incident Manager",
        "Contain, diagnose and close a migration incident with evidence preservation and mandatory regression capture",
        ["containment order", "evidence preservation", "state reconciliation", "closure criteria"],
        ["incident_record.json", "containment_timeline.json", "incident_closure.md"],
        [
            "Expansion is frozen before diagnosis begins.",
            "Evidence is preserved before any repair or cleanup mutates state.",
            "Closure requires a new regression test and a re-run certification.",
        ],
        [
            "an incident closed without a regression test",
            "state reconciled before the evidence was captured",
            "traffic expansion resumed while the root cause was unknown",
        ],
    ),
    (
        "migration-decision-journal",
        "Migration Decision Journal",
        "Record every consequential migration decision so accepted differences remain explainable later",
        ["decision record", "option analysis", "approver identity", "review date"],
        ["decision_journal.json", "decision_index.json", "review_schedule.md"],
        [
            "Each record states source behaviour, target behaviour and the accepted delta.",
            "Each accepted behavioural change names an authorized approver.",
            "Each record binds to a regression test and a scheduled review date.",
        ],
        [
            "a behavioural change with no decision record",
            "a decision approved by the agent that proposed it",
            "an accepted difference with no regression test",
        ],
    ),
    (
        "production-cutover-orchestrator",
        "Production Cutover Orchestrator",
        "Orchestrate the full path from engineering certification through shadow, canary, full traffic and legacy retirement",
        ["stage machine", "gate sequencing", "freeze and reduce paths", "global blocking condition"],
        ["cutover_state_machine.json", "stage_transitions.json", "cutover_runbook.md"],
        [
            "Every stage transition is gated by objective evidence.",
            "Freeze, reduce, rollback and blocked paths are reachable from every stage.",
            "Global blocking conditions halt progression regardless of stage.",
        ],
        [
            "a stage skipped to accelerate the schedule",
            "a transition executed while a global blocking condition held",
            "a stage machine that cannot express a partial rollback",
        ],
    ),
    (
        "repository-semantic-inventory",
        "Repository Semantic Inventory",
        "Inventory every module, entrypoint, generated artifact and implicit registration in the source repository",
        ["module inventory", "implicit entrypoint", "generated code", "native library"],
        ["repository_inventory.json", "entrypoint_index.json", "inventory_gap_report.md"],
        [
            "Every runtime entrypoint is located in the repository or explicitly flagged.",
            "Generated code is traced to its generator and inputs.",
            "Dynamic registration sites are enumerated rather than assumed absent.",
        ],
        [
            "generated code with no identifiable generator",
            "a production module absent from the repository",
            "a runtime entrypoint that static analysis could not locate",
        ],
    ),
    (
        "unified-symbol-identity-builder",
        "Unified Symbol Identity Builder",
        "Assign every symbol a stable identity that survives cross-file, cross-module and cross-language conversion",
        ["stable identity", "overload disambiguation", "partial declaration", "generated symbol"],
        ["symbol_table.json", "identity_collisions.json", "identity_policy.md"],
        [
            "Identity includes module, qualified name, kind, generic arity and signature.",
            "Overloads, extensions, categories and partial declarations stay distinct.",
            "Macro and generator produced symbols remain traceable to their origin.",
        ],
        [
            "two distinct overloads merged into one target symbol",
            "one source type expanded into multiple unrelated target types",
            "an extension or category method dropped during identity assignment",
        ],
    ),
    (
        "structural-ir-builder",
        "Structural IR Builder",
        "Represent modules, types, callables and dependency relationships in a language-neutral structural graph",
        ["module graph", "dependency direction", "public surface", "boundary preservation"],
        ["structural_ir.json", "dependency_edges.json", "structure_diff.md"],
        [
            "Every public symbol has a corresponding target representation or a waiver.",
            "Dependency direction is preserved and no cycle is introduced accidentally.",
            "Entrypoint counts match between source and target structural graphs.",
        ],
        [
            "an inverted dependency edge introduced by the target design",
            "a public API silently removed from the target surface",
            "a module boundary dissolved without an approved decision",
        ],
    ),
    (
        "type-semantic-ir-builder",
        "Type Semantic IR Builder",
        "Map nine language type systems onto shared type semantics rather than recording type names",
        ["semantic category", "numeric width", "precision and scale", "overflow behaviour"],
        ["type_semantic_ir.json", "numeric_profile.json", "type_mapping_risks.md"],
        [
            "Numeric width, signedness, overflow and precision are recorded per type.",
            "Decimal, arbitrary precision and rounding requirements are explicit.",
            "Nullability and optionality are separated from the base type category.",
        ],
        [
            "an arbitrary precision decimal mapped to a binary floating point type",
            "an unbounded integer mapped to a fixed width without an overflow guard",
            "a nullable constraint lost during type mapping",
        ],
    ),
    (
        "value-and-identity-ir-builder",
        "Value and Identity IR Builder",
        "Record whether each type carries value or reference semantics and what a copy operation means to the business",
        ["value semantics", "reference identity", "copy on write", "shared mutation"],
        ["identity_semantics.json", "copy_semantics_matrix.json", "identity_risk_report.md"],
        [
            "Shared mutation expectations are recorded for every mutable aggregate.",
            "Copy, clone, move and copy-on-write behaviour is distinguished explicitly.",
            "Object identity requirements are separated from structural equality.",
        ],
        [
            "a shared mutable reference object converted to a copied value type",
            "a copy-on-write buffer converted into an eager deep copy",
            "a move-only resource converted into a freely shared reference",
        ],
    ),
    (
        "nullability-and-absence-ir-builder",
        "Nullability and Absence IR Builder",
        "Distinguish the different meanings of absent, null, undefined, empty, zero and uninitialized across languages",
        ["absence state", "missing versus null", "zero value", "uninitialized memory"],
        ["absence_semantics.json", "absence_state_matrix.json", "absence_risk_report.md"],
        [
            "Missing field, explicit null, present empty and present value stay distinct.",
            "Zero values and optional absence are never conflated.",
            "Serialization round-trips preserve the exact absence state.",
        ],
        [
            "a missing field and an explicit null collapsed into one state",
            "a zero value interpreted as absence",
            "an undefined value serialized as null without an approved decision",
        ],
    ),
    (
        "generic-and-polymorphism-ir-builder",
        "Generic and Polymorphism IR Builder",
        "Represent generics, templates, traits, protocols and dynamic dispatch in one polymorphism model",
        ["type erasure", "monomorphization", "dispatch model", "default implementation"],
        ["polymorphism_ir.json", "dispatch_matrix.json", "polymorphism_gaps.md"],
        [
            "Erased, reified and monomorphized generics are distinguished explicitly.",
            "Variance, associated types and existentials are recorded where present.",
            "Method resolution order and default implementations are captured.",
        ],
        [
            "a reified generic converted to an erased one without a runtime guard",
            "an associated-type protocol mapped to a plain interface",
            "an overload resolution difference hidden by a single target method",
        ],
    ),
    (
        "control-flow-ir-builder",
        "Control Flow IR Builder",
        "Capture the real execution structure of each callable in a language-neutral control flow graph",
        ["exception edge", "cleanup edge", "suspension point", "lazy evaluation"],
        ["control_flow_ir.json", "edge_inventory.json", "flow_semantics_notes.md"],
        [
            "Exception, cleanup, cancellation and timeout edges are modelled explicitly.",
            "Laziness and evaluation timing are recorded, not assumed eager.",
            "Every asynchronous suspension point is represented as a node.",
        ],
        [
            "a lazy pipeline converted into eager evaluation",
            "a cleanup edge omitted from the flow graph",
            "a suspension point that changed the observable ordering",
        ],
    ),
    (
        "expression-evaluation-order-ir",
        "Expression Evaluation Order IR",
        "Preserve the evaluation order inside expressions wherever it can affect an observable side effect",
        ["argument order", "short circuit", "implicit conversion", "macro re-evaluation"],
        ["evaluation_order_ir.json", "side_effecting_expressions.json", "order_risk_report.md"],
        [
            "Argument evaluation order is recorded wherever an argument has an effect.",
            "Short-circuit boundaries and implicit conversions are captured.",
            "Macro arguments that may be evaluated more than once are flagged.",
        ],
        [
            "a macro treated as a pure function despite repeated evaluation",
            "a side-effecting property getter reordered by the target",
            "an implicit conversion that changed a comparison result",
        ],
    ),
    (
        "error-semantic-ir-builder",
        "Error Semantic IR Builder",
        "Unify exceptions, error returns, panics, native crashes and process exits into one error model",
        ["error category", "retryability", "cleanup guarantee", "boundary conversion"],
        ["error_semantic_ir.json", "error_mapping_matrix.json", "error_model_gaps.md"],
        [
            "Every error records category, retryability, rollback effect and cleanup.",
            "Catch scope and boundary conversion points are explicit.",
            "The public API error representation is preserved across the conversion.",
        ],
        [
            "a checked exception converted into an ignorable error value",
            "a panic allowed to cross a foreign function boundary",
            "an error hierarchy flattened so callers can no longer discriminate",
        ],
    ),
]

SKILLS[110] = [
    (
        "resource-lifetime-ir-builder",
        "Resource Lifetime IR Builder",
        "Unify garbage collection, reference counting, automatic reference counting, scope-bound ownership and manual management",
        ["ownership model", "transfer point", "release point", "cycle risk"],
        ["lifetime_ir.json", "ownership_graph.json", "lifetime_risk_report.md"],
        [
            "Creation, transfer, sharing, borrowing and release points are all recorded.",
            "Release under exception, cancellation and shutdown paths is captured.",
            "Reference cycles and cross-thread sharing constraints are identified.",
        ],
        [
            "a resource whose release point cannot be determined",
            "a reference cycle introduced by the target ownership plan",
            "a handle released while another owner still holds it",
        ],
    ),
    (
        "side-effect-ir-builder",
        "Side-Effect IR Builder",
        "Promote every externally observable behaviour to a first-class node in the intermediate representation",
        ["effect node", "ordering constraint", "transaction phase", "compensation"],
        ["side_effect_ir.json", "effect_ordering_constraints.json", "effect_inventory.md"],
        [
            "Each effect records its resource, condition, ordering and transaction phase.",
            "Idempotency, retry and timeout attributes are attached to every effect.",
            "Compensating actions are declared for every reversible effect.",
        ],
        [
            "an effect represented only as an ordinary function call",
            "an effect without a declared transaction phase",
            "a reversible effect with no compensating action",
        ],
    ),
    (
        "state-mutation-ir-builder",
        "State Mutation IR Builder",
        "Record read and write sets over object, global, request, database, cache and registry state",
        ["read set", "write set", "scope classification", "state invariant"],
        ["state_mutation_ir.json", "read_write_sets.json", "state_invariants.md"],
        [
            "Read and write sets are recorded per operation, not per module.",
            "Global, thread-local and request-scoped state are distinguished.",
            "Invariants over mutated state are attached to the operation.",
        ],
        [
            "a hidden global mutation missing from the write set",
            "a thread-local converted to shared process state",
            "a state invariant that the target no longer enforces",
        ],
    ),
    (
        "concurrency-semantic-ir-builder",
        "Concurrency Semantic IR Builder",
        "Represent threads, coroutines, actors, goroutines and event loops in one concurrency model",
        ["execution unit", "synchronization primitive", "happens-before", "thread affinity"],
        ["concurrency_ir.json", "synchronization_graph.json", "concurrency_gaps.md"],
        [
            "Shared state, lock scope and happens-before relationships are explicit.",
            "Thread affinity and main-thread requirements are recorded.",
            "Cancellation, timeout and backpressure semantics are captured.",
        ],
        [
            "an await placed inside a lock scope without justification",
            "a main-thread requirement dropped during conversion",
            "a memory ordering constraint weakened without proof",
        ],
    ),
    (
        "scheduling-and-ordering-ir-builder",
        "Scheduling and Ordering IR Builder",
        "Preserve business ordering constraints between events independently of any thread implementation",
        ["strict ordering", "eventual ordering", "commutativity", "delivery guarantee"],
        ["ordering_ir.json", "ordering_constraints.json", "ordering_rationale.md"],
        [
            "Strict, eventual, commutative and independent relations are distinguished.",
            "Commit-before-publish and response-before-ack relations are explicit.",
            "At-most-once and at-least-once guarantees are recorded per event.",
        ],
        [
            "a strict ordering relaxed to eventual without approval",
            "a publish reordered ahead of its commit",
            "a delivery guarantee changed during conversion",
        ],
    ),
    (
        "transaction-semantic-ir-builder",
        "Transaction Semantic IR Builder",
        "Unify local, database and distributed transaction semantics across frameworks",
        ["propagation", "isolation", "post-commit hook", "saga compensation"],
        ["transaction_ir.json", "propagation_matrix.json", "transaction_gaps.md"],
        [
            "Begin, commit, rollback, savepoint, isolation and propagation are recorded.",
            "Post-commit hooks, outbox rows and saga steps are modelled explicitly.",
            "Cross-resource boundaries are identified and their guarantees stated.",
        ],
        [
            "a declarative transaction boundary lost during conversion",
            "a post-commit hook silently moved inside the transaction",
            "a nested propagation rule flattened into a single transaction",
        ],
    ),
    (
        "framework-lifecycle-ir-builder",
        "Framework Lifecycle IR Builder",
        "Convert implicit framework lifecycle behaviour into explicit ordered semantics",
        ["lifecycle phase", "middleware order", "scope resolution", "shutdown sequence"],
        ["framework_lifecycle_ir.json", "phase_ordering.json", "lifecycle_gaps.md"],
        [
            "Startup, request, transaction, serialization and shutdown phases are ordered.",
            "Object scope and injection lifetime are recorded per component.",
            "Graceful shutdown and in-flight request handling are captured.",
        ],
        [
            "a request-scoped component converted to a process singleton",
            "an authentication filter reordered after validation",
            "a graceful shutdown path lost during conversion",
        ],
    ),
    (
        "reflection-and-metaprogramming-ir",
        "Reflection and Metaprogramming IR",
        "Record compile-time and runtime generation so implicit wiring becomes inspectable",
        ["generation phase", "runtime discovery", "runtime mutation", "unresolved behaviour"],
        ["metaprogramming_ir.json", "generation_sites.json", "unresolved_dynamic.md"],
        [
            "Each site is classified by the phase at which generation occurs.",
            "Runtime discovery and runtime mutation are separated from static generation.",
            "Unresolved dynamic behaviour is registered as a blocking risk.",
        ],
        [
            "a runtime registration recovered only by guesswork",
            "a generated proxy whose behaviour was never inspected",
            "runtime mutation treated as if it were compile-time generation",
        ],
    ),
    (
        "data-contract-ir-builder",
        "Data Contract IR Builder",
        "Unify API, message, file and database data contracts into one comparable model",
        ["field semantics", "unknown field policy", "coercion rule", "protocol version"],
        ["data_contract_ir.json", "contract_matrix.json", "contract_gaps.md"],
        [
            "Field name, alias, type, nullability, default and ordering are recorded.",
            "Unknown field and unknown enum handling are explicit per contract.",
            "Coercion and validation rules are captured rather than inferred.",
        ],
        [
            "an unknown field policy changed from ignore to reject",
            "a custom serializer behaviour lost during conversion",
            "a field ordering dependency that the target does not preserve",
        ],
    ),
    (
        "platform-and-abi-ir-builder",
        "Platform and ABI IR Builder",
        "Record the operating system, architecture, linkage and binary compatibility requirements of the migration",
        ["calling convention", "data layout", "symbol visibility", "runtime library"],
        ["platform_ir.json", "abi_profile.json", "platform_constraints.md"],
        [
            "Pointer width, alignment, padding and endianness are recorded.",
            "Calling convention, name mangling and symbol visibility are captured.",
            "Static and dynamic linkage requirements are explicit per artifact.",
        ],
        [
            "a struct layout assumption that differs across architectures",
            "an exception unwinding path crossing an incompatible boundary",
            "a symbol visibility change that breaks dynamic loading",
        ],
    ),
    (
        "java-semantic-frontend",
        "Java Semantic Frontend",
        "Extract Semantic IR from Java source, bytecode, build metadata and framework configuration",
        ["type erasure", "annotation processing", "proxy behaviour", "persistence context"],
        ["java_semantic_ir.json", "java_frontend_evidence.json", "java_extraction_gaps.md"],
        [
            "Checked exceptions, erasure and wildcard bounds are recorded faithfully.",
            "Reflection, annotation scanning and proxy generation sites are enumerated.",
            "Persistence context, transaction proxying and lifecycle hooks are captured.",
        ],
        [
            "a reflective registration missing from the extracted IR",
            "an aspect-generated behaviour attributed to the plain method",
            "a persistence lazy-loading boundary lost during extraction",
        ],
    ),
    (
        "python-semantic-frontend",
        "Python Semantic Frontend",
        "Extract Semantic IR from Python source, annotations, bytecode and runtime type traces",
        ["dynamic type inference", "monkey patch", "import side effect", "confidence labelling"],
        ["python_semantic_ir.json", "runtime_type_trace.json", "python_inference_report.md"],
        [
            "Every inferred type carries a confidence value and its supporting evidence.",
            "Monkey patching, descriptors and metaclass behaviour are enumerated.",
            "Import-time side effects and module singletons are recorded.",
        ],
        [
            "an inferred type presented as a determined fact",
            "a monkey patch discovered only after conversion",
            "an import side effect omitted from the extracted IR",
        ],
    ),
    (
        "csharp-semantic-frontend",
        "CSharp Semantic Frontend",
        "Extract Semantic IR from C# source, assemblies, attributes and framework configuration",
        ["nullable reference", "value type boxing", "expression tree", "tracking context"],
        ["csharp_semantic_ir.json", "csharp_frontend_evidence.json", "csharp_extraction_gaps.md"],
        [
            "Nullable reference annotations and value type semantics are recorded.",
            "Delegates, events, properties and indexers are distinguished explicitly.",
            "Asynchronous context, cancellation and disposal patterns are captured.",
        ],
        [
            "a struct copy semantic recorded as a reference",
            "an expression tree treated as an ordinary lambda",
            "a disposal contract lost during extraction",
        ],
    ),
    (
        "rust-semantic-frontend",
        "Rust Semantic Frontend",
        "Extract Semantic IR from Rust source including the constraints the compiler has already proven",
        ["ownership constraint", "lifetime bound", "send and sync", "macro expansion"],
        ["rust_semantic_ir.json", "proven_constraints.json", "rust_extraction_gaps.md"],
        [
            "Borrow, lifetime, exhaustiveness and non-null constraints are preserved as facts.",
            "Cross-thread send and sync bounds are recorded per type.",
            "Macro expansion and conditional compilation results are captured.",
        ],
        [
            "a compiler-proven constraint dropped from the IR",
            "an unsafe block recorded without its safety justification",
            "a conditional compilation branch omitted from extraction",
        ],
    ),
    (
        "go-semantic-frontend",
        "Go Semantic Frontend",
        "Extract Semantic IR from Go source including interface satisfaction, zero values and concurrency structure",
        ["method set", "nil interface", "zero value", "context propagation"],
        ["go_semantic_ir.json", "go_frontend_evidence.json", "go_extraction_gaps.md"],
        [
            "Value and pointer receiver method sets are distinguished.",
            "Nil interface and typed nil semantics are recorded separately.",
            "Channel, select, defer and context cancellation structure is captured.",
        ],
        [
            "a typed nil recorded as an absent value",
            "a deferred cleanup omitted from the flow graph",
            "a foreign pointer rule violation missing from the IR",
        ],
    ),
    (
        "typescript-semantic-frontend",
        "TypeScript Semantic Frontend",
        "Extract Semantic IR from TypeScript source and its Node runtime behaviour",
        ["type erasure", "event loop ordering", "numeric range", "runtime property"],
        ["typescript_semantic_ir.json", "runtime_shape_trace.json", "typescript_gaps.md"],
        [
            "Static types are marked as erased and separated from runtime shape.",
            "Undefined, null and missing property states are distinguished.",
            "Microtask, timer and stream ordering behaviour is recorded.",
        ],
        [
            "a static type recorded as a runtime guarantee",
            "a numeric value beyond the safe integer range treated as exact",
            "a dynamic property added at runtime that the IR never captured",
        ],
    ),
]

SKILLS[111] = [
    (
        "cplusplus-semantic-frontend",
        "CPlusPlus Semantic Frontend",
        "Extract Semantic IR from C++ source including preprocessor expansion, ownership and undefined behaviour risk",
        ["template instantiation", "preprocessor expansion", "undefined behaviour", "atomic ordering"],
        ["cplusplus_semantic_ir.json", "undefined_behaviour_findings.json", "cplusplus_gaps.md"],
        [
            "Analysis runs on preprocessor-expanded source, not raw text.",
            "Copy, move, destructor and smart pointer ownership are recorded per type.",
            "Sanitizer findings are attached to the extracted representation.",
        ],
        [
            "source behaviour that depends on undefined behaviour",
            "a raw pointer whose ownership cannot be determined",
            "a macro expansion whose side effects were not analysed",
        ],
    ),
    (
        "objectivec-semantic-frontend",
        "ObjectiveC Semantic Frontend",
        "Extract Semantic IR from Objective-C source and the runtime behaviour that source alone cannot reveal",
        ["message dispatch", "method swizzling", "key value observing", "autorelease scope"],
        ["objectivec_semantic_ir.json", "runtime_dispatch_trace.json", "objectivec_gaps.md"],
        [
            "Selector resolution, forwarding and swizzling are captured from runtime traces.",
            "Automatic reference counting ownership qualifiers are recorded per reference.",
            "Key value observing relationships and associated objects are enumerated.",
        ],
        [
            "a swizzled implementation attributed to the original method",
            "a dynamic selector that static analysis could not enumerate",
            "an associated object key discovered only after conversion",
        ],
    ),
    (
        "swift-semantic-frontend",
        "Swift Semantic Frontend",
        "Extract Semantic IR from Swift source including value semantics, isolation and macro-generated behaviour",
        ["copy on write", "actor isolation", "macro expansion", "bridging boundary"],
        ["swift_semantic_ir.json", "isolation_model.json", "swift_gaps.md"],
        [
            "Value semantics and copy-on-write buffers are distinguished from references.",
            "Actor isolation, global actors and sendability bounds are recorded.",
            "Macro, property wrapper and result builder expansion is captured.",
        ],
        [
            "an actor isolation boundary omitted from the IR",
            "a macro-generated member missing from the symbol table",
            "a bridged collection copy recorded as a shared reference",
        ],
    ),
    (
        "target-semantic-planning",
        "Target Semantic Planning",
        "Decide before code generation how every source semantic will be realized in the target language",
        ["mapping decision", "ownership decision", "error decision", "unsupported declaration"],
        ["target_plan.json", "mapping_decisions.json", "planning_rationale.md"],
        [
            "Every source semantic has an explicit mapping decision or an unsupported record.",
            "Ownership, error and concurrency models are decided before generation begins.",
            "Library and framework replacements are named with their behavioural deltas.",
        ],
        [
            "a plan produced by translating files one at a time",
            "a mapping decision without a recorded rationale",
            "an unsupported feature discovered only during generation",
        ],
    ),
    (
        "java-target-backend-validator",
        "Java Target Backend Validator",
        "Validate that generated Java preserves the source constraints rather than relaxing them",
        ["exception fidelity", "resource management", "concurrency bounds", "framework scope"],
        ["java_target_validation.json", "constraint_relaxations.json", "java_backend_report.md"],
        [
            "Resource release uses deterministic constructs rather than finalization.",
            "Error values are not silently converted into nulls.",
            "Thread and connection pools are bounded and component scopes are correct.",
        ],
        [
            "a stateful component registered as a singleton",
            "a resource released only by garbage collection",
            "an unbounded thread creation path in generated code",
        ],
    ),
    (
        "python-target-backend-validator",
        "Python Target Backend Validator",
        "Validate that generated Python retains type, error and concurrency constraints from a stricter source",
        ["runtime validation", "mutable default", "error specificity", "event loop safety"],
        ["python_target_validation.json", "constraint_relaxations.json", "python_backend_report.md"],
        [
            "Type constraints survive as runtime validation, not only as annotations.",
            "No mutable default argument or shared mutable module state is introduced.",
            "Blocking work is kept off the event loop.",
        ],
        [
            "structured types degraded into untyped dictionaries",
            "a specific error hierarchy collapsed into a base exception",
            "a source concurrency safety constraint left unenforced",
        ],
    ),
    (
        "csharp-target-backend-validator",
        "CSharp Target Backend Validator",
        "Validate that generated C# preserves nullability, disposal, cancellation and serialization contracts",
        ["nullable annotation", "disposal contract", "cancellation flow", "decimal fidelity"],
        ["csharp_target_validation.json", "constraint_relaxations.json", "csharp_backend_report.md"],
        [
            "Nullable reference annotations reflect the source nullability model.",
            "Disposal and safe handle usage match the source cleanup guarantees.",
            "Cancellation tokens propagate through every asynchronous path.",
        ],
        [
            "a decimal quantity generated as a binary floating point type",
            "a disposal contract left unimplemented",
            "a cancellation token accepted but never observed",
        ],
    ),
    (
        "rust-target-backend-validator",
        "Rust Target Backend Validator",
        "Validate that generated Rust does not buy compilation success with unsafe or panicking shortcuts",
        ["ownership justification", "panic boundary", "lock discipline", "unsafe review"],
        ["rust_target_validation.json", "unsafe_inventory.json", "rust_backend_report.md"],
        [
            "Every unsafe block carries a written safety justification.",
            "No lock is held across an await point without an approved rationale.",
            "Panics cannot cross a foreign function interface boundary.",
        ],
        [
            "an unwrap introduced to satisfy the compiler",
            "excess cloning used to bypass an ownership problem",
            "a send or sync marker asserted without proof",
        ],
    ),
    (
        "go-target-backend-validator",
        "Go Target Backend Validator",
        "Validate that generated Go handles zero values, errors, cancellation and goroutine lifetime correctly",
        ["error handling", "zero value safety", "goroutine lifetime", "race freedom"],
        ["go_target_validation.json", "constraint_relaxations.json", "go_backend_report.md"],
        [
            "Every returned error is inspected or explicitly and visibly discarded.",
            "Goroutines have a termination path and are covered by race detection.",
            "Context cancellation propagates through the full call chain.",
        ],
        [
            "a zero value used where the source expressed absence",
            "a goroutine with no termination path",
            "a nil interface comparison that changed behaviour",
        ],
    ),
    (
        "typescript-target-backend-validator",
        "TypeScript Target Backend Validator",
        "Validate that generated TypeScript enforces at runtime what the source enforced statically",
        ["runtime schema validation", "numeric safety", "rejection handling", "loop responsiveness"],
        ["typescript_target_validation.json", "constraint_relaxations.json", "typescript_backend_report.md"],
        [
            "External inputs are validated at runtime, not only typed statically.",
            "Monetary and large integer values avoid the double precision number type.",
            "Every promise rejection path is handled explicitly.",
        ],
        [
            "a static type presented as a runtime guarantee",
            "a monetary value represented as a floating point number",
            "a synchronous computation that blocks the event loop",
        ],
    ),
    (
        "cplusplus-target-backend-validator",
        "CPlusPlus Target Backend Validator",
        "Validate that generated C++ is memory safe, layout correct and free of undefined behaviour",
        ["sanitizer gate", "ownership clarity", "bounds safety", "build flag parity"],
        ["cplusplus_target_validation.json", "sanitizer_results.json", "cplusplus_backend_report.md"],
        [
            "Address and undefined behaviour sanitizers pass on the required scope.",
            "Thread sanitizer passes on every declared critical concurrency scenario.",
            "No raw pointer remains whose ownership is unexplained.",
        ],
        [
            "a functional pass accompanied by a sanitizer memory error",
            "an integer overflow or out-of-bounds access in generated code",
            "a destructor path that leaks a resource under exception unwinding",
        ],
    ),
    (
        "objectivec-target-backend-validator",
        "ObjectiveC Target Backend Validator",
        "Validate that generated Objective-C respects reference counting, threading and runtime contracts",
        ["retain cycle", "autorelease scope", "main queue affinity", "bridging ownership"],
        ["objectivec_target_validation.json", "reference_graph.json", "objectivec_backend_report.md"],
        [
            "Block and delegate capture graphs contain no unintended retain cycle.",
            "Main-thread-only interfaces are invoked only from the main queue.",
            "Bridging transfers state ownership explicitly in both directions.",
        ],
        [
            "an unsafe unretained reference introduced during generation",
            "an autoreleased object escaping its pool",
            "a main-queue interface called from a worker thread",
        ],
    ),
    (
        "swift-target-backend-validator",
        "Swift Target Backend Validator",
        "Validate that generated Swift preserves optionality, isolation, reference identity and continuation safety",
        ["forced unwrap", "actor reentrancy", "continuation safety", "reference identity"],
        ["swift_target_validation.json", "isolation_violations.json", "swift_backend_report.md"],
        [
            "Forced unwrapping is absent or individually justified.",
            "Non-sendable values never cross an actor boundary.",
            "Every continuation is resumed exactly once on all paths.",
        ],
        [
            "a shared reference object converted into a value struct",
            "a continuation resumed twice or never resumed",
            "an actor reentrancy assumption that changed ordering",
        ],
    ),
    (
        "directional-path-registry",
        "Directional Path Registry",
        "Register each of the seventy-two directional paths with its support level, adapters and certification ceiling",
        ["path identity", "support level", "required adapter", "certification ceiling"],
        ["path_registry.json", "path_support_levels.json", "registry_policy.md"],
        [
            "A path from one language to another is registered separately from its reverse.",
            "Each path declares its required adapters and runtime evidence obligations.",
            "Each path declares a certification ceiling that gates promotion.",
        ],
        [
            "a bidirectional language pair registered as one symmetric entry",
            "a support level asserted without adapter coverage",
            "a certification claim exceeding the registered ceiling",
        ],
    ),
    (
        "language-capability-vector",
        "Language Capability Vector",
        "Describe each language with a machine-readable capability vector so semantic gaps can be derived automatically",
        ["memory model", "typing model", "error model", "metaprogramming capability"],
        ["capability_vectors.json", "capability_schema.json", "capability_notes.md"],
        [
            "Memory, typing, error, concurrency and metaprogramming axes are all populated.",
            "Vectors are versioned against a specific language and runtime release.",
            "Every axis value maps to an observable, testable behaviour.",
        ],
        [
            "a capability axis left unpopulated but treated as absent",
            "a vector applied across incompatible runtime versions",
            "an axis whose value cannot be tested for",
        ],
    ),
    (
        "directional-semantic-gap-analyzer",
        "Directional Semantic Gap Analyzer",
        "Derive the ordered list of semantic gaps that a specific source to target direction must close",
        ["gap derivation", "asymmetric analysis", "constraint tightening", "constraint loosening"],
        ["semantic_gaps.json", "gap_severity.json", "gap_analysis.md"],
        [
            "Gaps are derived from capability vectors rather than authored by hand.",
            "Loosening gaps require preserving the source constraint by other means.",
            "Tightening gaps require proving the new constraint matches real behaviour.",
        ],
        [
            "a gap list reused unchanged for the reverse direction",
            "a loosening gap closed without a compensating control",
            "a tightening gap closed by assumption rather than evidence",
        ],
    ),
]

SKILLS[112] = [
    (
        "directional-rule-pack-generator",
        "Directional Rule Pack Generator",
        "Generate the path-specific rule pack that governs mapping, linting, testing and mutation for one direction",
        ["rule pack", "path lint", "test template", "trace requirement"],
        ["rule_pack.json", "rule_provenance.json", "rule_pack_report.md"],
        [
            "Every rule traces to a specific derived semantic gap.",
            "The pack declares its required runtime trace evidence.",
            "Mapping, lint, test and mutation rules are versioned together.",
        ],
        [
            "a rule pack shared across both directions of a language pair",
            "a rule with no traceable originating gap",
            "a pack whose lint and mutation rules disagree",
        ],
    ),
    (
        "path-risk-scorer",
        "Path Risk Scorer",
        "Score the migration risk of a specific repository on a specific directional path from the features it actually uses",
        ["feature usage", "risk driver", "evidence availability", "score provenance"],
        ["risk_score.json", "risk_drivers.json", "risk_scoring_notes.md"],
        [
            "Scores are computed from measured feature usage, not from language reputation.",
            "Each driver names the code sites that produced it.",
            "Missing test coverage and missing production traffic raise the score.",
        ],
        [
            "a risk score computed without inspecting the repository",
            "a critical driver omitted because it was hard to measure",
            "a score used to justify skipping a mandatory verification stage",
        ],
    ),
    (
        "scalar-mapping-verifier",
        "Scalar Mapping Verifier",
        "Verify integer width, signedness, overflow, precision and platform-dependent scalar mapping",
        ["integer width", "overflow behaviour", "decimal precision", "platform scalar"],
        ["scalar_mapping.json", "overflow_findings.json", "scalar_report.md"],
        [
            "Monetary quantities never map to a binary floating point type without approval.",
            "Overflow behaviour is preserved or guarded explicitly.",
            "Platform-dependent integer widths are pinned per target architecture.",
        ],
        [
            "an arbitrary precision integer truncated to a fixed width",
            "a decimal quantity mapped to a double precision float",
            "a silent wraparound where the source raised an error",
        ],
    ),
    (
        "string-and-unicode-mapping-verifier",
        "String and Unicode Mapping Verifier",
        "Verify encoding, indexing, normalization and locale behaviour across string representations",
        ["encoding model", "index semantics", "normalization form", "locale sensitivity"],
        ["string_mapping.json", "encoding_findings.json", "unicode_report.md"],
        [
            "Byte, code unit, code point and grapheme indexing are distinguished.",
            "Normalization form and case folding behaviour are preserved.",
            "Invalid byte sequences produce the same outcome as in the source.",
        ],
        [
            "a length computed in a different unit than the source used",
            "a substring operation that splits a grapheme cluster",
            "an invalid sequence silently replaced instead of rejected",
        ],
    ),
    (
        "collection-semantic-verifier",
        "Collection Semantic Verifier",
        "Verify ordering, equality, mutability, laziness and view semantics of converted collections",
        ["insertion order", "hash equality", "view versus copy", "iterator invalidation"],
        ["collection_mapping.json", "collection_findings.json", "collection_report.md"],
        [
            "Insertion order, duplicate handling and null element policy are preserved.",
            "View and copy semantics are preserved for shared buffers.",
            "Lazy sequences remain lazy unless a decision record approves eagerness.",
        ],
        [
            "a shared view converted into an independent copy",
            "an ordered map converted to an unordered one",
            "an iterator invalidation rule that the target no longer enforces",
        ],
    ),
    (
        "enum-and-union-mapping-verifier",
        "Enum and Union Mapping Verifier",
        "Verify enumeration, tagged union, unknown value and exhaustiveness handling",
        ["associated value", "unknown value", "forward compatibility", "exhaustive match"],
        ["enum_mapping.json", "unknown_value_policy.json", "enum_report.md"],
        [
            "Unknown enumeration values follow the same policy as the source.",
            "Associated values survive conversion without flattening.",
            "Exhaustiveness guarantees are preserved or replaced with runtime guards.",
        ],
        [
            "an unknown enumeration value that crashes the target",
            "an enumeration serialized by ordinal instead of by name",
            "an exhaustive match replaced by a silent default branch",
        ],
    ),
    (
        "function-and-callback-mapping-verifier",
        "Function and Callback Mapping Verifier",
        "Verify closure capture, callback ownership, invocation count and thread affinity",
        ["capture semantics", "callback ownership", "invocation count", "thread affinity"],
        ["callback_mapping.json", "capture_graph.json", "callback_report.md"],
        [
            "Capture by value and by reference are distinguished and preserved.",
            "Single-invocation and multi-invocation callbacks stay distinct.",
            "Callback lifetime outlives every path that may invoke it.",
        ],
        [
            "a callback invoked more times than the source invoked it",
            "a captured reference released before the callback ran",
            "a callback delivered on a thread the source never used",
        ],
    ),
    (
        "gc-to-ownership-planner",
        "GC to Ownership Planner",
        "Plan explicit ownership for each object when migrating from a managed runtime to a scope-bound language",
        ["escape analysis", "owner selection", "sharing requirement", "identity requirement"],
        ["ownership_plan.json", "escape_analysis.json", "ownership_rationale.md"],
        [
            "Ownership choices are justified by object graph and concurrency evidence.",
            "Shared mutable objects retain their sharing semantics or gain a decision record.",
            "Object identity requirements are preserved where the source relied on them.",
        ],
        [
            "an ownership decision inferred from a variable name",
            "a shared object converted to an independent copy per holder",
            "an ownership plan that introduces a reference cycle",
        ],
    ),
    (
        "ownership-to-gc-constraint-preserver",
        "Ownership to GC Constraint Preserver",
        "Preserve source ownership and safety constraints when the target language does not enforce them",
        ["single owner design", "explicit close", "thread confinement", "static rule"],
        ["constraint_preservation_plan.json", "enforcement_rules.json", "preservation_report.md"],
        [
            "Every relaxed compile-time constraint gains a design or lint replacement.",
            "Deterministic release becomes an explicit close or scope construct.",
            "Thread confinement constraints are enforced by assertion or analysis.",
        ],
        [
            "a move-only value converted into a freely shared reference",
            "a cross-thread safety bound left entirely unenforced",
            "an exhaustiveness guarantee dropped without a runtime guard",
        ],
    ),
    (
        "arc-bridge-verifier",
        "ARC Bridge Verifier",
        "Verify automatic reference counting ownership across every bridged boundary",
        ["ownership qualifier", "bridging transfer", "retain cycle", "pool boundary"],
        ["arc_bridge_report.json", "reference_graph.json", "bridge_findings.md"],
        [
            "Strong, weak and unowned qualifiers are preserved across the bridge.",
            "Bridging transfer direction is explicit for every crossing.",
            "Autorelease pool boundaries enclose every batched allocation path.",
        ],
        [
            "an object released while a foreign runtime still holds it",
            "a bridging transfer that leaks or double releases",
            "a retain cycle created by a bridged callback",
        ],
    ),
    (
        "raii-and-deterministic-cleanup-verifier",
        "RAII and Deterministic Cleanup Verifier",
        "Verify that deterministic resource release survives conversion in both directions",
        ["scope-bound release", "explicit disposal", "exception path cleanup", "release ordering"],
        ["cleanup_mapping.json", "release_order_diff.json", "cleanup_report.md"],
        [
            "Deterministic release is never converted into collector-dependent release.",
            "Release ordering between dependent resources is preserved.",
            "Cleanup runs on exception, cancellation and shutdown paths.",
        ],
        [
            "a database connection released only by garbage collection",
            "a release order inversion between dependent resources",
            "a cleanup path skipped during cancellation",
        ],
    ),
    (
        "native-memory-safety-gate",
        "Native Memory Safety Gate",
        "Gate any migration touching native code on zero memory safety and undefined behaviour findings",
        ["sanitizer coverage", "foreign boundary ownership", "leak threshold", "zero tolerance"],
        ["memory_safety_gate.json", "sanitizer_evidence.json", "safety_gate_report.md"],
        [
            "Use-after-free, double free, out-of-bounds and data race findings are zero.",
            "Every foreign function boundary has resolved pointer ownership.",
            "Sanitizer coverage spans the declared critical scenario set.",
        ],
        [
            "a functional pass accompanied by an unresolved sanitizer finding",
            "a foreign boundary whose pointer ownership is undocumented",
            "a leak dismissed without a measured bound",
        ],
    ),
    (
        "concurrency-model-translator",
        "Concurrency Model Translator",
        "Translate between thread, task, actor, goroutine and event loop models while recording what changes",
        ["model mapping", "preserved semantics", "changed semantics", "fairness delta"],
        ["concurrency_translation.json", "semantic_deltas.json", "translation_report.md"],
        [
            "The translation records both preserved and changed semantics explicitly.",
            "Scheduling fairness, backpressure and resource model differences are named.",
            "Cancellation propagation is mapped end to end.",
        ],
        [
            "a translation that claims full semantic preservation",
            "a backpressure mechanism silently removed",
            "a cancellation path that stops propagating at a boundary",
        ],
    ),
    (
        "memory-model-verifier",
        "Memory Model Verifier",
        "Verify visibility, atomicity and happens-before guarantees across the two language memory models",
        ["atomic ordering", "safe publication", "visibility guarantee", "double checked pattern"],
        ["memory_model_report.json", "ordering_findings.json", "memory_model_notes.md"],
        [
            "Atomic memory ordering is preserved or strengthened, never weakened silently.",
            "Safe publication of shared objects is proven, not assumed.",
            "Data race findings from dynamic analysis are zero.",
        ],
        [
            "an atomic operation downgraded to a plain variable access",
            "a double-checked initialization pattern that lost its barrier",
            "a visibility guarantee assumed from a different memory model",
        ],
    ),
    (
        "async-ordering-verifier",
        "Async Ordering Verifier",
        "Verify callback ordering, cancellation, timeout and error propagation across asynchronous runtimes",
        ["callback ordering", "task cancellation", "error propagation", "task leak"],
        ["async_ordering_report.json", "ordering_findings.json", "async_notes.md"],
        [
            "Observable callback ordering matches the source under equivalent load.",
            "Cancellation and timeout propagate through every awaited boundary.",
            "No orphaned task or unobserved rejection remains after a run.",
        ],
        [
            "a microtask ordering change that altered observable behaviour",
            "a task that outlives its cancelled parent",
            "an unhandled rejection that terminates the process",
        ],
    ),
    (
        "actor-and-isolation-verifier",
        "Actor and Isolation Verifier",
        "Verify actor state isolation, reentrancy and sendability across every path involving isolated concurrency",
        ["actor isolation", "reentrancy window", "sendability", "cross boundary call"],
        ["isolation_report.json", "isolation_violations.json", "isolation_notes.md"],
        [
            "Isolated state is never reachable from outside its isolation domain.",
            "Reentrancy windows are identified and their invariants are re-checked.",
            "Non-sendable values never cross an isolation boundary.",
        ],
        [
            "an isolation guarantee lost when calling into another language",
            "an invariant broken across a reentrancy suspension point",
            "a non-sendable value shared across an isolation boundary",
        ],
    ),
]

SKILLS[113] = [
    (
        "dynamic-runtime-trace-collector",
        "Dynamic Runtime Trace Collector",
        "Capture the runtime types, dispatch decisions and registrations that static analysis cannot determine",
        ["runtime type", "dynamic dispatch", "registration site", "object shape"],
        ["runtime_trace.json", "dynamic_site_index.json", "trace_coverage.md"],
        [
            "Traces are collected from both test and production-representative execution.",
            "Every dynamic site records the concrete resolutions actually observed.",
            "Trace coverage against the dynamic site inventory is reported explicitly.",
        ],
        [
            "a dynamic site with no observed resolution presented as unused",
            "a trace collected only from a narrow test path",
            "a runtime type recorded without its originating call site",
        ],
    ),
    (
        "dynamic-behavior-freezer",
        "Dynamic Behavior Freezer",
        "Freeze observed dynamic behaviour into an explicit registry or generated code that can be migrated",
        ["explicit registry", "generated dispatch", "coverage boundary", "residual dynamism"],
        ["frozen_registry.json", "generation_plan.json", "freeze_boundary.md"],
        [
            "Every frozen entry names the traces that justified it.",
            "Behaviour outside the observed set fails closed rather than silently defaulting.",
            "Residual dynamism that cannot be frozen is registered as a risk.",
        ],
        [
            "a registry that silently defaults for an unobserved key",
            "a frozen entry with no supporting trace",
            "residual dynamism omitted from the risk ledger",
        ],
    ),
    (
        "unsupported-dynamic-feature-detector",
        "Unsupported Dynamic Feature Detector",
        "Classify each dynamic feature as expandable, traceable, adaptable, manual or unsupported",
        ["feature classification", "resolution path", "severity assignment", "manual escalation"],
        ["unsupported_features.json", "feature_classification.json", "escalation_list.md"],
        [
            "Every dynamic feature receives exactly one terminal classification.",
            "Unsupported and manual classifications create release-blocking risks.",
            "Classification decisions cite the trace or analysis that produced them.",
        ],
        [
            "an unsupported feature classified as adaptable without a working adapter",
            "a feature left unclassified across a promotion boundary",
            "a critical feature downgraded in severity to unblock a gate",
        ],
    ),
    (
        "framework-inventory-and-version-resolver",
        "Framework Inventory and Version Resolver",
        "Identify the frameworks, versions, modules and plugins the repository actually uses",
        ["framework detection", "version pinning", "module usage", "plugin inventory"],
        ["framework_inventory.json", "version_resolution.json", "framework_notes.md"],
        [
            "Framework identity includes exact version and enabled module set.",
            "Plugins and starters that change lifecycle behaviour are enumerated.",
            "Declared and effectively loaded frameworks are reconciled.",
        ],
        [
            "a framework mapped by language convention rather than detection",
            "a plugin that alters lifecycle omitted from the inventory",
            "a version range recorded instead of the resolved version",
        ],
    ),
    (
        "framework-capability-matcher",
        "Framework Capability Matcher",
        "Match source and target framework capabilities and classify each as direct, adapted or redesigned",
        ["capability dimension", "direct mapping", "adapter required", "redesign required"],
        ["framework_mapping.json", "capability_matrix.json", "framework_gaps.md"],
        [
            "Routing, injection, lifecycle, validation, transaction and shutdown are all compared.",
            "Adapter and redesign classifications carry an owner and an estimate.",
            "Similar component names are not treated as equivalent behaviour.",
        ],
        [
            "a capability marked direct because the component names match",
            "a redesign requirement recorded as a simple adapter",
            "an unmatched capability omitted from the gap list",
        ],
    ),
    (
        "framework-execution-order-verifier",
        "Framework Execution Order Verifier",
        "Verify that middleware, filter, guard, validation, transaction and serialization order is preserved",
        ["middleware order", "filter chain", "interceptor position", "handler ordering"],
        ["execution_order_diff.json", "chain_traces.json", "order_findings.md"],
        [
            "The observed request chain order is compared, not the declared configuration.",
            "Authentication and authorization remain ahead of business handling.",
            "Exception handler and serialization position are preserved.",
        ],
        [
            "an authorization filter that moved after validation",
            "a transaction boundary that now opens before authentication",
            "an exception handler that no longer sees the original error",
        ],
    ),
    (
        "orm-semantic-mapping-verifier",
        "ORM Semantic Mapping Verifier",
        "Verify identity map, tracking, lazy loading, cascade, flush and query translation semantics",
        ["change tracking", "lazy loading", "cascade behaviour", "query translation"],
        ["orm_mapping.json", "orm_findings.json", "orm_report.md"],
        [
            "Identity map, dirty checking and flush timing are compared behaviourally.",
            "Cascade, orphan removal and lock behaviour are preserved.",
            "Query translation avoids silent client-side evaluation.",
        ],
        [
            "a lazy association eagerly loaded in the target",
            "a flush that now occurs at a different transaction point",
            "a query silently evaluated in memory instead of in the database",
        ],
    ),
    (
        "cross-language-value-normalizer",
        "Cross-Language Value Normalizer",
        "Normalize numeric, temporal, textual and binary representations without hiding a real value difference",
        ["numeric representation", "temporal representation", "binary encoding", "lossless rule"],
        ["value_normalization_rules.json", "normalization_evidence.json", "normalizer_audit.md"],
        [
            "Decimal values are compared as exact decimal strings, not as floats.",
            "Temporal values are compared with explicit timezone and precision rules.",
            "Every normalization is lossless with respect to the compared property.",
        ],
        [
            "a decimal compared after conversion to a floating point type",
            "a timezone dropped during temporal normalization",
            "a normalization that changes the ordering of compared values",
        ],
    ),
    (
        "identity-relationship-normalizer",
        "Identity Relationship Normalizer",
        "Allow generated identifiers to differ while proving every relationship between them is preserved",
        ["identifier mapping", "referential integrity", "cardinality check", "correlation preservation"],
        ["identity_map.json", "relationship_verification.json", "identity_audit.md"],
        [
            "Every mapped identifier preserves its referential relationships.",
            "One-to-one and one-to-many cardinality is verified after remapping.",
            "Message, trace and idempotency correlations survive the mapping.",
        ],
        [
            "an identifier mapping that breaks a foreign key relationship",
            "a cardinality change concealed by identifier normalization",
            "an idempotency key correlation lost during remapping",
        ],
    ),
    (
        "exception-and-error-normalizer",
        "Exception and Error Normalizer",
        "Normalize nine different error representations into one comparable model without losing discrimination",
        ["error category", "cause chain", "stack normalization", "discrimination preservation"],
        ["error_normalization_rules.json", "normalized_errors.json", "error_audit.md"],
        [
            "Distinct source error types remain distinguishable after normalization.",
            "Cause chains are preserved rather than flattened.",
            "Stack path normalization does not remove the originating frame.",
        ],
        [
            "two distinct error types normalized into one category",
            "a cause chain flattened into a single message",
            "an error code dropped during normalization",
        ],
    ),
    (
        "concurrency-trace-normalizer",
        "Concurrency Trace Normalizer",
        "Ignore non-semantic scheduling identity while preserving every business-critical ordering relation",
        ["identity suppression", "ordering preservation", "lock relation", "final state"],
        ["concurrency_normalization_rules.json", "normalized_traces.json", "trace_audit.md"],
        [
            "Thread, task and executor identity differences are suppressed.",
            "Commit-before-publish and lock protection relations are preserved.",
            "Final state and acknowledgement ordering are compared exactly.",
        ],
        [
            "an ordering relation removed together with thread identity",
            "a lock protection relation lost during normalization",
            "an acknowledgement ordering difference suppressed as noise",
        ],
    ),
    (
        "native-crash-normalizer",
        "Native Crash Normalizer",
        "Normalize crashes, panics, fatal errors and aborts from every runtime into one comparable category model",
        ["crash category", "phase attribution", "pre-crash state", "symbolication"],
        ["crash_normalization.json", "normalized_crashes.json", "crash_audit.md"],
        [
            "Each crash is assigned exactly one normalized category.",
            "The observable state immediately before the crash is captured.",
            "Source and target crash locations are both symbolicated.",
        ],
        [
            "a memory safety crash normalized as a generic failure",
            "a crash recorded without its pre-crash observable state",
            "a target crash where the source returned an error",
        ],
    ),
    (
        "directional-contract-test-generator",
        "Directional Contract Test Generator",
        "Generate contract tests targeting the specific semantic gaps of one directional path",
        ["gap-driven test", "path template library", "contract assertion", "template versioning"],
        ["contract_test_suite.json", "gap_coverage.json", "test_generation_report.md"],
        [
            "Every derived semantic gap produces at least one contract test.",
            "Templates are maintained per direction, not per language pair.",
            "Generated tests fail against a deliberately broken reference implementation.",
        ],
        [
            "a gap with no generated contract test",
            "a template reused unchanged for the reverse direction",
            "a generated test that passes against a known-broken implementation",
        ],
    ),
    (
        "directional-property-test-generator",
        "Directional Property Test Generator",
        "Generate path-specific property tests over type, state, resource, transaction and concurrency invariants",
        ["path invariant", "resource property", "concurrency property", "counterexample quality"],
        ["directional_property_suite.json", "invariant_coverage.json", "property_report.md"],
        [
            "Properties cover the invariants that this direction is most likely to break.",
            "Resource release and use-after-release properties are included where relevant.",
            "Every failure produces a shrunk, replayable counterexample.",
        ],
        [
            "a property suite identical across unrelated directional paths",
            "a resource property omitted on a path that changes ownership model",
            "a counterexample that cannot be replayed",
        ],
    ),
    (
        "directional-fuzz-dictionary-builder",
        "Directional Fuzz Dictionary Builder",
        "Build the fuzz input dictionary specific to the failure modes of one directional path",
        ["path-specific input", "boundary dictionary", "protocol edge", "dictionary provenance"],
        ["fuzz_dictionary.json", "dictionary_provenance.json", "dictionary_report.md"],
        [
            "Dictionary entries target the concrete gaps of the active direction.",
            "Absence, numeric range and encoding edge cases are represented.",
            "Every entry records the failure mode it is designed to trigger.",
        ],
        [
            "a generic dictionary applied to a path with unique failure modes",
            "an entry with no stated target failure mode",
            "a dictionary that never reaches the path-specific gap",
        ],
    ),
    (
        "directional-concurrency-scenario-generator",
        "Directional Concurrency Scenario Generator",
        "Generate concurrency scenarios that exercise the specific model translation of one directional path",
        ["model translation scenario", "scheduling script", "cancellation scenario", "backpressure scenario"],
        ["concurrency_scenarios.json", "scenario_schedules.json", "scenario_report.md"],
        [
            "Scenarios exercise the exact concurrency model translation in use.",
            "Cancellation, timeout and backpressure paths each have a scenario.",
            "Every scenario replays deterministically from its recorded schedule.",
        ],
        [
            "a scenario set that never exercises the translated primitive",
            "a cancellation path with no generated scenario",
            "a scenario that cannot be replayed deterministically",
        ],
    ),
]

SKILLS[114] = [
    (
        "directional-fault-injection-generator",
        "Directional Fault Injection Generator",
        "Generate fault injections aimed at the runtime-specific failure points of one directional path",
        ["runtime specific fault", "cleanup path fault", "boundary fault", "injection provenance"],
        ["fault_scenarios.json", "injection_points.json", "fault_generation_report.md"],
        [
            "Injection points target the cleanup, boundary and isolation constructs in use.",
            "Foreign function and runtime boundary faults are included where relevant.",
            "Each scenario records the failure mode it is designed to expose.",
        ],
        [
            "a fault suite that never targets the cleanup construct in use",
            "an injection point with no stated target failure mode",
            "a boundary fault omitted on a path that crosses runtimes",
        ],
    ),
    (
        "directional-mutation-library",
        "Directional Mutation Library",
        "Maintain path-specific mutation operators rather than relying on generic arithmetic mutation",
        ["path operator", "operator provenance", "kill expectation", "library versioning"],
        ["mutation_library.json", "operator_catalog.json", "library_report.md"],
        [
            "Operators encode the concrete failure modes of the active direction.",
            "Each operator declares which test class is expected to kill it.",
            "Operator libraries are versioned alongside their rule pack.",
        ],
        [
            "a generic operator set applied to a path with unique failure modes",
            "an operator that no existing test class can kill",
            "a library version that drifted from its rule pack",
        ],
    ),
    (
        "lifetime-mutation-pack",
        "Lifetime Mutation Pack",
        "Inject resource lifetime faults to prove the suite detects premature, delayed, missing and duplicated release",
        ["premature release", "delayed release", "strength inversion", "escape mutation"],
        ["lifetime_mutations.json", "lifetime_survivors.json", "lifetime_mutation_report.md"],
        [
            "Premature, delayed, missing and duplicated release are all exercised.",
            "Reference strength inversions are included where the model supports them.",
            "No lifetime mutant affecting a critical resource survives.",
        ],
        [
            "a premature release mutant that no test detects",
            "a reference strength inversion that survives undetected",
            "a scope cleanup removal that the suite does not catch",
        ],
    ),
    (
        "concurrency-mutation-pack",
        "Concurrency Mutation Pack",
        "Inject synchronization faults to prove the suite detects races, ordering loss and isolation loss",
        ["lock removal", "ordering weakening", "isolation removal", "await under lock"],
        ["concurrency_mutations.json", "concurrency_survivors.json", "concurrency_mutation_report.md"],
        [
            "Lock removal, scope change and memory ordering weakening are all exercised.",
            "Isolation removal and unawaited task mutants are included.",
            "No concurrency mutant affecting a critical invariant survives.",
        ],
        [
            "a removed lock that the suite does not detect",
            "a weakened memory ordering that survives undetected",
            "a cancellation propagation removal that no test catches",
        ],
    ),
    (
        "serialization-mutation-pack",
        "Serialization Mutation Pack",
        "Inject data contract faults to prove the suite detects absence, precision, encoding and ordering regressions",
        ["absence mutation", "precision mutation", "encoding mutation", "unknown value mutation"],
        ["serialization_mutations.json", "serialization_survivors.json", "serialization_mutation_report.md"],
        [
            "Missing versus null, precision loss and encoding changes are all exercised.",
            "Unknown field and unknown enumeration handling mutants are included.",
            "No serialization mutant affecting a monetary or identity field survives.",
        ],
        [
            "a decimal to float mutation that the suite does not detect",
            "a missing-to-null mutation that survives undetected",
            "a timezone loss mutation that no test catches",
        ],
    ),
    (
        "framework-mutation-pack",
        "Framework Mutation Pack",
        "Inject framework configuration faults to prove the suite detects lifecycle and ordering regressions",
        ["scope mutation", "order mutation", "transaction mutation", "shutdown mutation"],
        ["framework_mutations.json", "framework_survivors.json", "framework_mutation_report.md"],
        [
            "Component scope, chain order and transaction boundary mutants are exercised.",
            "Validation removal and duplicate job registration mutants are included.",
            "No framework mutant affecting authorization or transactions survives.",
        ],
        [
            "a removed validation step that the suite does not detect",
            "a component scope swap that survives undetected",
            "a duplicated background job registration that no test catches",
        ],
    ),
    (
        "path-matrix-compiler",
        "Path Matrix Compiler",
        "Compile the complete matrix of directional paths with difficulty, evidence requirements and unsupported features",
        ["matrix generation", "difficulty dimension", "evidence requirement", "matrix provenance"],
        ["path_matrix.json", "matrix_dimensions.json", "matrix_report.md"],
        [
            "Every registered directional path appears exactly once in the matrix.",
            "Structural, type, lifetime, concurrency and dynamic difficulty are separate axes.",
            "Runtime trace, shadow traffic and platform requirements are explicit per path.",
        ],
        [
            "a matrix row that averages independent difficulty axes",
            "a directional path missing from the compiled matrix",
            "an evidence requirement omitted for a high-difficulty path",
        ],
    ),
    (
        "default-path-difficulty-matrix",
        "Default Path Difficulty Matrix",
        "Assign each directional path a default difficulty tier with its baseline verification requirements",
        ["difficulty tier", "baseline requirement", "tier justification", "override control"],
        ["difficulty_tiers.json", "tier_requirements.json", "tier_rationale.md"],
        [
            "Tier assignment names the semantic gaps that drive it.",
            "Each tier declares its minimum verification and evidence requirements.",
            "Tier overrides require an approver and a recorded justification.",
        ],
        [
            "a tier lowered without closing the gaps that set it",
            "a tier assignment with no stated driving gap",
            "an override applied without an authorized approver",
        ],
    ),
    (
        "certification-ceiling-calculator",
        "Certification Ceiling Calculator",
        "Compute the highest certification level a path and repository combination may reach with the available evidence",
        ["ceiling computation", "evidence availability", "downgrade factor", "ceiling enforcement"],
        ["certification_ceiling.json", "downgrade_factors.json", "ceiling_rationale.md"],
        [
            "The ceiling reflects the evidence actually available, not the evidence planned.",
            "Unobservable dynamic behaviour lowers the ceiling explicitly.",
            "No certification may be issued above the computed ceiling.",
        ],
        [
            "a ceiling raised by assuming evidence that was never collected",
            "an unresolved dynamic behaviour that did not lower the ceiling",
            "a certification issued above the computed ceiling",
        ],
    ),
    (
        "ir-to-target-skeleton-generator",
        "IR to Target Skeleton Generator",
        "Generate the target structural skeleton before generating any implementation body",
        ["structure first", "interface skeleton", "contract skeleton", "test skeleton"],
        ["target_skeleton.json", "skeleton_manifest.json", "skeleton_report.md"],
        [
            "Modules, types, interfaces, contracts and test skeletons are generated first.",
            "Skeleton symbols map one to one onto their source symbol identities.",
            "No implementation body is generated before the skeleton is validated.",
        ],
        [
            "an implementation generated before the skeleton was validated",
            "a skeleton symbol with no source symbol identity",
            "a public interface missing from the generated skeleton",
        ],
    ),
    (
        "target-semantic-reconstruction",
        "Target Semantic Reconstruction",
        "Rebuild Semantic IR from the generated target code instead of assuming the plan was implemented",
        ["reverse extraction", "plan independence", "reconstruction fidelity", "frontend reuse"],
        ["target_semantic_ir.json", "reconstruction_evidence.json", "reconstruction_report.md"],
        [
            "The target representation is extracted by a frontend, not read from the plan.",
            "Reconstruction uses the same extraction rules as the source frontend.",
            "Reconstruction gaps are reported rather than filled from the plan.",
        ],
        [
            "a target representation copied from the generation plan",
            "a reconstruction gap silently filled with planned values",
            "an extraction that skipped generated or macro-produced code",
        ],
    ),
    (
        "ir-structural-equivalence-checker",
        "IR Structural Equivalence Checker",
        "Compare source and reconstructed target structure for symbol, module, entrypoint and dependency completeness",
        ["symbol completeness", "entrypoint parity", "dependency parity", "registration parity"],
        ["structural_equivalence.json", "structural_differences.json", "structural_report.md"],
        [
            "Every public source symbol has a target counterpart or an approved waiver.",
            "Entrypoint counts and framework registrations match.",
            "Dependency direction and module boundaries are preserved.",
        ],
        [
            "a public symbol missing from the target with no waiver",
            "a framework registration that did not survive generation",
            "a dependency inversion introduced during generation",
        ],
    ),
    (
        "ir-behavioral-equivalence-checker",
        "IR Behavioral Equivalence Checker",
        "Compare source and reconstructed target behaviour across input, output, state, effect, ordering and resources",
        ["behavioural comparison", "effect parity", "ordering parity", "resource parity"],
        ["behavioral_equivalence.json", "behavioral_differences.json", "behavioral_report.md"],
        [
            "Input, output, error, state, effect, ordering and resource axes are all compared.",
            "Transaction, concurrency and cancellation behaviour are included.",
            "Every difference is emitted for terminal classification.",
        ],
        [
            "a comparison restricted to return values",
            "an effect ordering difference reported as equivalent",
            "a difference emitted without a classification path",
        ],
    ),
    (
        "semantic-loss-detector",
        "Semantic Loss Detector",
        "Detect semantics present in the source representation that have no expression in the target",
        ["loss detection", "constraint loss", "guarantee loss", "severity assignment"],
        ["semantic_loss.json", "loss_severity.json", "loss_report.md"],
        [
            "Every source semantic feature is checked for a target expression.",
            "Constraint and guarantee losses are reported with severity.",
            "Critical losses block promotion until resolved or formally accepted.",
        ],
        [
            "a checked error contract lost with no compensating control",
            "a deterministic release guarantee lost during generation",
            "an isolation guarantee lost without a risk record",
        ],
    ),
    (
        "semantic-expansion-detector",
        "Semantic Expansion Detector",
        "Detect behaviour, permissions or capability the target gained that the source never had",
        ["surface expansion", "permission expansion", "effect expansion", "tolerance expansion"],
        ["semantic_expansion.json", "expansion_severity.json", "expansion_report.md"],
        [
            "New public interfaces and widened permissions are detected and reported.",
            "Increased retry counts and external call counts are flagged.",
            "Newly accepted inputs that the source rejected are reported.",
        ],
        [
            "a widened authorization scope introduced during generation",
            "an exception swallowed so the target accepts a rejected input",
            "an unknown enumeration value newly accepted by default",
        ],
    ),
    (
        "directional-migration-planner",
        "Directional Migration Planner",
        "Produce the end-to-end migration plan for one directional path from Semantic IR, gaps and risk score",
        ["plan derivation", "decision set", "adapter plan", "evidence plan"],
        ["migration_plan.json", "planning_decisions.json", "planning_report.md"],
        [
            "The plan is derived from the semantic representation, not from file order.",
            "Type, ownership, error, concurrency and framework decisions are all explicit.",
            "The plan names the runtime traces that must be collected before generation.",
        ],
        [
            "a plan produced by translating files one at a time",
            "a plan that omits the required runtime trace collection",
            "an unsupported feature absent from the plan risk section",
        ],
    ),
]


BATCHES.update({
    115: {
        "title": "Directional Pack Foundations and Repair Agent Roles",
        "why": "Moves ELMOS from ad hoc per-migration rules to versioned directional packs governed by separated repair and attack roles.",
        "purpose": "define the schema, common rule, mutation and test packs inherited by all seventy-two directional paths, gate them on mutation effectiveness and declared support level, and keep semantic repair separate from adversarial attack.",
        "tooling": ["directional pack schema", "common pack library", "mutation effectiveness gate", "path knowledge base"],
    },
    116: {
        "title": "Java and Python Source Directional Packs",
        "why": "Moves ELMOS from one generic Java or Python converter to eight independently governed outbound migration products per source language.",
        "purpose": "compile and enforce the rule, mutation and test packs for every directional path leaving Java and for the first half of the paths leaving Python, each with its own evidence bundle and certification ceiling.",
        "tooling": ["directional pack compiler", "path test coverage gate", "path evidence bundle", "runtime type tracer"],
    },
    117: {
        "title": "Python, C# and Rust Source Directional Packs",
        "why": "Moves ELMOS from assuming symmetry to treating each Python, C# and Rust outbound direction as its own verification product.",
        "purpose": "govern the remaining Python native-target paths, every path leaving C#, and the managed-target paths leaving Rust, preserving the constraints each source language already proved.",
        "tooling": ["directional pack compiler", "ownership constraint preserver", "native sanitizer adapter", "runtime type tracer"],
    },
    118: {
        "title": "Rust, Go and TypeScript Source Directional Packs",
        "why": "Moves ELMOS from generic concurrency translation to per-direction ownership, channel and event loop verification.",
        "purpose": "govern the remaining Rust native and Apple-platform paths, every path leaving Go, and the managed-target paths leaving TypeScript, with explicit absence, ownership and cancellation rules.",
        "tooling": ["directional pack compiler", "concurrency model translator", "race detection adapter", "runtime shape tracer"],
    },
    119: {
        "title": "TypeScript, C++ and Objective-C Source Directional Packs",
        "why": "Moves ELMOS from best-effort native and dynamic-runtime conversion to hard memory-safety and runtime-freezing gates.",
        "purpose": "govern the remaining TypeScript native and Apple-platform paths, every path leaving C++ under a zero undefined behaviour gate, and the managed-target paths leaving Objective-C under a runtime freezing requirement.",
        "tooling": ["directional pack compiler", "native sanitizer adapter", "Apple runtime trace adapter", "dynamic behavior freezer"],
    },
})


def path_pack(source_slug, source_name, target_slug, target_name, keywords, checks, mutations, ceiling):
    """Build a directional pack Skill entry."""
    slug = f"{source_slug}-to-{target_slug}-directional-pack"
    title = f"{source_name} to {target_name} Directional Pack"
    objective = (
        f"Govern the {source_name} to {target_name} migration with its own rule pack, mutation pack, "
        f"test pack and certification ceiling"
    )
    prefix = f"{source_slug}_to_{target_slug}".replace("-", "_")
    outputs = [
        f"{prefix}_rule_pack.json",
        f"{prefix}_mutation_pack.json",
        f"{prefix}_test_pack.json",
    ]
    return (slug, title, objective, keywords, outputs, [*checks, ceiling], mutations)


SKILLS[115] = [
    (
        "semantic-repair-agent",
        "Semantic Repair Agent",
        "Repair the target system strictly from intermediate representation differences, tool findings and runtime evidence",
        ["evidence-driven repair", "failure provenance", "bounded convergence", "decision capture"],
        ["repair_plan.json", "repair_provenance.json", "repair_log.md"],
        [
            "Every repair cites the compiler, analyzer, differential or sanitizer finding that motivated it.",
            "Repair attempts are bounded and escalate rather than looping indefinitely.",
            "Any behavioural change made during repair produces a decision record.",
        ],
        [
            "a repair that deletes, skips or weakens a failing test",
            "a repair applied without a cited failing finding",
            "an unbounded repair loop that never escalates",
        ],
    ),
    (
        "adversarial-attack-planner",
        "Adversarial Attack Planner",
        "Plan attacks against the semantic losses this specific directional path is most likely to produce",
        ["path-specific attack", "loss hypothesis", "attack prioritization", "independence"],
        ["attack_plan.json", "attack_hypotheses.json", "attack_priorities.md"],
        [
            "The plan targets the derived semantic gaps of the active direction.",
            "Hypotheses are formed from artifacts and evidence, not from builder summaries.",
            "Attack priority follows business risk, not implementation convenience.",
        ],
        [
            "an attack plan derived from the builder own conclusions",
            "a plan that ignores the highest-risk semantic gap",
            "an attack scoped only to code the builder already tested",
        ],
    ),
    (
        "minimal-counterexample-generator",
        "Minimal Counterexample Generator",
        "Reduce every discovered non-equivalence to the smallest reproducible input and environment",
        ["input reduction", "environment reduction", "schedule reduction", "reproducibility"],
        ["counterexample_set.json", "reduction_traces.json", "counterexample_report.md"],
        [
            "Each counterexample records input, environment, schedule and both observed results.",
            "Reduction preserves the failure while removing incidental structure.",
            "Every counterexample replays deterministically from its stored fixture.",
        ],
        [
            "a counterexample that does not reproduce from its fixture",
            "a reduction that changed the underlying failure",
            "a finding reported without a minimal reproducing case",
        ],
    ),
    (
        "path-support-declaration",
        "Path Support Declaration",
        "Declare for each directional path exactly which features are supported, partially supported or unsupported",
        ["support level", "supported feature set", "unsupported feature set", "declaration versioning"],
        ["support_declaration.json", "feature_support_matrix.json", "declaration_rationale.md"],
        [
            "Supported and unsupported feature sets are enumerated, not summarized.",
            "Support level is bound to a specific pack version and language release.",
            "No claim is made outside the declared supported subset.",
        ],
        [
            "a support level asserted without an enumerated feature set",
            "a claim covering a feature outside the declared subset",
            "a declaration reused across incompatible language versions",
        ],
    ),
    (
        "unsupported-feature-release-gate",
        "Unsupported Feature Release Gate",
        "Block release while any unresolved unsupported feature remains outside the risk ledger",
        ["unresolved counter", "severity gate", "degradation record", "follow-up plan"],
        ["unsupported_gate.json", "unresolved_features.json", "gate_decision.md"],
        [
            "Critical and high severity unresolved counts are both zero.",
            "Every accepted degradation carries approval, tests and documentation.",
            "Each remaining item has a named owner and a follow-up plan.",
        ],
        [
            "an unsupported feature discovered outside the ledger",
            "a critical unsupported item downgraded to pass the gate",
            "an accepted degradation without a regression test",
        ],
    ),
    (
        "path-knowledge-base",
        "Path Knowledge Base",
        "Accumulate per-path mappings, known errors, incidents, replacements and certification experience",
        ["known mapping", "known error", "incident history", "best practice"],
        ["path_knowledge_index.json", "known_error_catalog.json", "knowledge_notes.md"],
        [
            "Knowledge is stored per direction, not per language pair.",
            "Every entry records the evidence or incident that produced it.",
            "Superseded entries are versioned rather than silently overwritten.",
        ],
        [
            "knowledge shared between opposite directions without review",
            "an entry with no supporting evidence or incident",
            "a superseded mapping left active after a language upgrade",
        ],
    ),
    (
        "historical-failure-regression-builder",
        "Historical Failure Regression Builder",
        "Convert every discovered path defect into a permanent regression in that path suite",
        ["defect capture", "failure taxonomy", "permanent regression", "suite growth"],
        ["regression_additions.json", "failure_taxonomy.json", "regression_report.md"],
        [
            "Every confirmed defect produces a regression bound to its path.",
            "Regressions are classified by failure type for later analysis.",
            "Added regressions fail against the pre-fix implementation.",
        ],
        [
            "a fixed defect that produced no regression test",
            "a regression that passes against the pre-fix implementation",
            "a regression removed during later maintenance without approval",
        ],
    ),
    (
        "semantic-matrix-orchestrator",
        "Semantic Matrix Orchestrator",
        "Orchestrate the full semantic phase from repository inventory to certification handoff",
        ["phase sequencing", "trace gating", "profile selection", "certification handoff"],
        ["semantic_state_machine.json", "phase_transitions.json", "orchestration_runbook.md"],
        [
            "Runtime trace capture is required before generation when the path demands it.",
            "Target representation reconstruction precedes any equivalence claim.",
            "Certification handoff carries the exact earned state and its evidence.",
        ],
        [
            "generation started before required runtime traces were captured",
            "an equivalence claim made before target reconstruction",
            "a handoff that reports a state its evidence does not support",
        ],
    ),
    (
        "directional-pack-schema",
        "Directional Pack Schema",
        "Define the machine-readable schema every directional pack must satisfy",
        ["pack schema", "version binding", "rule completeness", "history binding"],
        ["directional_pack_schema.json", "pack_validation_report.json", "schema_notes.md"],
        [
            "Every pack declares path identity, version and source and target language ranges.",
            "Type, error, concurrency, lifetime, dependency and framework rules are all present.",
            "Certification ceiling, unsupported features and failure history are all bound to the pack.",
        ],
        [
            "a pack missing its certification ceiling",
            "a pack whose language version range is unbounded",
            "a pack with an empty unsupported feature section that was never analysed",
        ],
    ),
    (
        "common-rule-pack",
        "Common Rule Pack",
        "Maintain the baseline rules that all seventy-two directional paths inherit",
        ["baseline rule", "inheritance", "absence semantics", "numeric semantics"],
        ["common_rule_pack.json", "rule_inheritance_map.json", "common_rule_notes.md"],
        [
            "Symbol, module and public interface completeness rules apply to every path.",
            "Absence, numeric width, decimal, temporal and enumeration rules are inherited by default.",
            "A path may tighten an inherited rule but may not silently drop one.",
        ],
        [
            "a path that silently disables an inherited baseline rule",
            "a baseline rule with no corresponding verification",
            "an inherited rule overridden without a decision record",
        ],
    ),
    (
        "common-mutation-pack",
        "Common Mutation Pack",
        "Maintain the baseline mutation operators every path must survive",
        ["baseline operator", "boundary mutation", "effect mutation", "cleanup mutation"],
        ["common_mutation_pack.json", "operator_inheritance.json", "common_mutation_notes.md"],
        [
            "Boundary, logical, absence and default value operators are inherited by every path.",
            "Effect duplication, effect omission and idempotency key mutation are included.",
            "Cleanup, cancellation and permission check removal operators are included.",
        ],
        [
            "a path that excludes an inherited critical operator",
            "an operator that no inherited test class can kill",
            "a baseline operator disabled to raise a mutation score",
        ],
    ),
    (
        "common-test-pack",
        "Common Test Pack",
        "Maintain the ordered baseline test stages every path must execute",
        ["stage ordering", "baseline coverage", "stage completeness", "execution evidence"],
        ["common_test_pack.json", "stage_definitions.json", "common_test_notes.md"],
        [
            "Build, original test, contract, differential and property stages all execute.",
            "Fuzz, mutation, concurrency, fault injection and performance stages all execute.",
            "Platform, replay, shadow and progressive cutover stages are defined for every path.",
        ],
        [
            "a stage skipped without an approved waiver",
            "a stage marked complete without execution evidence",
            "a stage reordered so verification precedes its prerequisite",
        ],
    ),
    (
        "certification-ceiling-evaluator",
        "Certification Ceiling Evaluator",
        "Combine path risk, actual feature usage, dynamic coverage and evidence to set the achievable ceiling",
        ["combined evaluation", "usage weighting", "evidence weighting", "no fixed ceiling"],
        ["ceiling_evaluation.json", "evaluation_inputs.json", "evaluation_rationale.md"],
        [
            "The ceiling is computed from repository evidence, not from the language pair alone.",
            "Dynamic behaviour coverage and production traffic coverage both feed the result.",
            "The evaluation records every input that lowered the ceiling.",
        ],
        [
            "a fixed ceiling assigned from the language pair alone",
            "an evaluation that ignored measured dynamic coverage",
            "a ceiling raised by assuming uncollected evidence",
        ],
    ),
    (
        "unsupported-feature-downgrade",
        "Unsupported Feature Downgrade",
        "Automatically lower the certification ceiling when an unobservable or unfrozen behaviour is detected",
        ["automatic downgrade", "trigger condition", "downgrade audit", "restoration condition"],
        ["downgrade_triggers.json", "downgrade_events.json", "restoration_conditions.md"],
        [
            "Unfrozen dynamic generation, dispatch or patching triggers an automatic downgrade.",
            "Undetermined native ownership and unresolved undefined behaviour trigger a downgrade.",
            "Restoration requires new evidence, never an approval alone.",
        ],
        [
            "a downgrade trigger disabled to preserve a certification level",
            "a ceiling restored by approval without new evidence",
            "an unfrozen dynamic behaviour that produced no downgrade",
        ],
    ),
    (
        "rule-pack-versioning",
        "Rule Pack Versioning",
        "Version every directional pack and bind each certification to the exact version used",
        ["semantic versioning", "upgrade trigger", "certification binding", "migration notes"],
        ["pack_versions.json", "upgrade_log.json", "version_migration_notes.md"],
        [
            "Every certification names the exact pack version that produced it.",
            "Language, framework, compiler and incident-driven upgrades are all recorded.",
            "A pack upgrade re-evaluates the certifications bound to the previous version.",
        ],
        [
            "a certification that does not name its pack version",
            "a pack upgraded in place without a version change",
            "a language upgrade that produced no pack review",
        ],
    ),
    (
        "mutation-effectiveness-gate",
        "Mutation Effectiveness Gate",
        "Prove the path test suite kills the typical conversion errors of that specific direction",
        ["effectiveness threshold", "critical operator class", "survivor zero", "score provenance"],
        ["mutation_gate.json", "effectiveness_results.json", "gate_rationale.md"],
        [
            "Critical semantic, framework and concurrency operator classes are fully killed.",
            "The overall critical module score meets the declared threshold.",
            "Scores name the operator library version that produced them.",
        ],
        [
            "a threshold met by excluding critical operator classes",
            "a surviving critical mutant declared equivalent without proof",
            "a score reported without its operator library version",
        ],
    ),
]


def ceiling(static, runtime, production, extra=None):
    text = (
        f"Certification is capped at {static} on static evidence alone, {runtime} with runtime trace "
        f"evidence, and {production} only with production shadow evidence."
    )
    return text if extra is None else f"{text} {extra}"


SKILLS[116] = [
    (
        "path-test-coverage-gate",
        "Path Test Coverage Gate",
        "Gate a path on semantic coverage dimensions rather than on line coverage alone",
        ["type semantic coverage", "lifecycle coverage", "transaction state coverage", "production input coverage"],
        ["coverage_gate.json", "semantic_coverage.json", "coverage_gaps.md"],
        [
            "Type, error, lifetime, transaction and concurrency coverage are measured separately.",
            "Framework lifecycle and serialization state coverage are reported.",
            "Production input category coverage is measured against real traffic classes.",
        ],
        [
            "a gate passed on line coverage while semantic coverage is unmeasured",
            "a coverage dimension reported as complete without an enumerated denominator",
            "a production input class excluded from the coverage denominator",
        ],
    ),
    (
        "path-evidence-bundle",
        "Path Evidence Bundle",
        "Bind every path certification to the exact pack, toolchain and evidence versions that produced it",
        ["version binding", "toolchain fingerprint", "evidence index", "reproducibility"],
        ["path_evidence_bundle.json", "version_binding.json", "bundle_manifest.md"],
        [
            "Rule, mutation and test pack versions are all recorded.",
            "Compiler, runtime, framework and target platform versions are recorded.",
            "Source and target commits, differential results and mutation scores are bound together.",
        ],
        [
            "a bundle missing its mutation pack version",
            "a certification whose toolchain fingerprint cannot be reproduced",
            "an unsupported feature list omitted from the bundle",
        ],
    ),
    (
        "directional-pack-compiler",
        "Directional Pack Compiler",
        "Assemble the exact rule, mutation and test packs a specific repository and direction require",
        ["pack assembly", "feature-driven selection", "framework pack inclusion", "assembly provenance"],
        ["assembled_packs.json", "selection_rationale.json", "assembly_report.md"],
        [
            "Pack selection follows measured repository feature usage, not the path name alone.",
            "Framework and feature packs are included only when the repository uses them.",
            "The assembly records why each pack was included or excluded.",
        ],
        [
            "an identical pack set applied to every repository on a path",
            "a framework pack omitted although the repository uses that framework",
            "a pack included with no recorded justification",
        ],
    ),
    path_pack(
        "java", "Java", "python", "Python",
        ["typed contract preservation", "decimal fidelity", "lock to isolation mapping", "registry explicitation"],
        [
            "Declared Java types survive as runtime-validated Python models, not bare dictionaries.",
            "Decimal quantities map to arbitrary precision decimals, never to floats.",
            "Annotation scanning and proxy behaviour become an explicit registry.",
        ],
        [
            "a checked exception degraded into a silent none result",
            "a lock removed so shared module state becomes racy",
            "a lazy stream materialized early or a session closed too soon",
        ],
        ceiling("E3", "E4", "E5-C", "While any dynamic patch remains unfrozen the ceiling stays at E4."),
    ),
    path_pack(
        "java", "Java", "csharp", "C#",
        ["generic model shift", "exception contract", "tracking parity", "lifetime scope parity"],
        [
            "Erased generics map to runtime generics without losing variance constraints.",
            "Persistence tracking, flush timing and transaction propagation are preserved.",
            "Component scope maps singleton to singleton and request to scoped.",
        ],
        [
            "a checked exception contract removed from the target signature",
            "a scoped component promoted to a singleton",
            "an entity tracking mode changed so dirty checking no longer fires",
        ],
        ceiling("E4", "E4", "E5"),
    ),
    path_pack(
        "java", "Java", "rust", "Rust",
        ["object graph to ownership", "exception to result", "proxy explicitation", "send and sync proof"],
        [
            "Ownership choices are justified by object graph and concurrency evidence.",
            "Cross-thread bounds are proven from observed sharing, not assumed.",
            "Proxy-based transaction and aspect behaviour becomes explicit wiring.",
        ],
        [
            "a shared reference converted to a single-threaded counted pointer",
            "a transaction guard dropped before the work it protects completes",
            "a lock held across an await point in the generated runtime",
        ],
        ceiling("E3", "E4", "E5-C", "While ownership or reflection questions remain open the ceiling stays at E4."),
    ),
    path_pack(
        "java", "Java", "go", "Go",
        ["inheritance to composition", "exception to error", "cancellation propagation", "absence versus zero"],
        [
            "Every error return is inspected rather than discarded.",
            "Cancellation propagates from the request boundary to every dependency call.",
            "Absent values stay distinguishable from the target zero value.",
        ],
        [
            "a deferred rollback removed from a transaction path",
            "a spawned worker that the request never waits for",
            "a null value converted into a zero value that changes a decision",
        ],
        ceiling("E3", "E4", "E5"),
    ),
    path_pack(
        "java", "Java", "typescript", "TypeScript",
        ["runtime validation", "large integer safety", "context propagation", "promise ordering"],
        [
            "External inputs are validated at runtime, not merely typed.",
            "Large integers and decimals avoid the double precision number type.",
            "Request-scoped context survives every asynchronous boundary.",
        ],
        [
            "a runtime validator removed so an invalid payload is accepted",
            "a large integer or decimal narrowed to a floating point number",
            "an unawaited promise or an unhandled rejection",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "java", "Java", "cplusplus", "C++",
        ["managed to scope-bound ownership", "bounds safety", "exception boundary", "memory model mapping"],
        [
            "Address, undefined behaviour and thread sanitizers pass on the required scope.",
            "Array bounds and integer overflow behaviour are preserved or guarded.",
            "Exceptions never cross an incompatible binary boundary.",
        ],
        [
            "a shared pointer replaced by a raw pointer with unclear ownership",
            "a destructor cleanup step omitted from an exception path",
            "an atomic memory ordering weakened in the generated code",
        ],
        ceiling("E3", "E4", "E5-C", "While any unexplained undefined behaviour remains the ceiling stays at E3."),
    ),
    path_pack(
        "java", "Java", "objectivec", "Objective-C",
        ["reference counting mapping", "runtime registry", "error object mapping", "queue affinity"],
        [
            "Reflection and annotation registration becomes an explicit runtime registry.",
            "Main-queue-only interfaces are invoked only from the main queue.",
            "Error objects preserve the source error hierarchy and codes.",
        ],
        [
            "a strong or weak qualifier chosen incorrectly on a captured reference",
            "an autorelease pool removed from a batched allocation path",
            "an error object dropped so a failure returns as success",
        ],
        ceiling("E2", "E4", "E5-C", "While any dynamic selector remains unfrozen the ceiling stays at E4."),
    ),
    path_pack(
        "java", "Java", "swift", "Swift",
        ["reference identity preservation", "optional mapping", "isolation mapping", "deterministic cleanup"],
        [
            "Reference objects that rely on shared mutation are not converted to value types.",
            "Isolation replaces the source synchronization without changing observable ordering.",
            "Resource release remains deterministic rather than collector dependent.",
        ],
        [
            "a shared reference class converted into a copied value struct",
            "an isolation boundary removed so shared state becomes racy",
            "a decimal quantity converted to a binary floating point type",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "python", "Python", "java", "Java",
        ["runtime type inference", "patch freezing", "absence mapping", "import side effect capture"],
        [
            "Target types are derived from runtime traces with recorded confidence.",
            "Runtime patching and import-time registration are frozen into explicit wiring.",
            "Arbitrary precision integers are preserved rather than narrowed.",
        ],
        [
            "an inferred type narrowed beyond what the traces support",
            "an observed dynamic branch missing from the generated dispatch",
            "an arbitrary precision integer truncated to a fixed width",
        ],
        ceiling("E2", "E4", "E5-C", "While any dynamic behaviour cannot be frozen the ceiling stays at E4."),
    ),
    path_pack(
        "python", "Python", "csharp", "C#",
        ["runtime type inference", "nullable mapping", "disposal mapping", "large integer preservation"],
        [
            "Duck-typed contracts become explicit interfaces backed by trace evidence.",
            "Context managers map to deterministic disposal, not to finalization.",
            "Arbitrary precision integers and decimals are preserved exactly.",
        ],
        [
            "a dynamic escape hatch used in place of a resolved type",
            "a disposal contract omitted from a resource path",
            "a decimal quantity converted to a double precision float",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "python", "Python", "rust", "Rust",
        ["shape inference", "reference to ownership", "interpreter lock to bounds", "array view semantics"],
        [
            "Reference semantics are preserved through counted pointers where sharing was observed.",
            "Cross-thread bounds are derived from observed access, not assumed from the source.",
            "Array view and copy semantics survive numerical library conversion.",
        ],
        [
            "an absence branch removed from a generated option match",
            "a shared array view converted into an independent copy",
            "a cross-thread marker asserted without supporting evidence",
        ],
        ceiling("E2", "E3", "E5-C", "Without sufficient dynamic coverage the ceiling stays at E3."),
    ),
    path_pack(
        "python", "Python", "go", "Go",
        ["shape inference", "absence versus zero", "interpreter lock explicitation", "registry freezing"],
        [
            "Absent values remain distinguishable from the target zero value.",
            "Serialized execution assumptions are made explicit rather than inherited.",
            "Runtime imports and decorators become a static registry.",
        ],
        [
            "an absent value converted into a zero value that changes a decision",
            "an observed dynamic branch missing from the generated dispatch",
            "an arbitrary precision integer overflowing a fixed width",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "python", "Python", "typescript", "TypeScript",
        ["shape inference", "absence triage", "numeric range", "generator timing"],
        [
            "Runtime schema validation replaces the erased static types.",
            "Absent, null and undefined states remain distinguishable end to end.",
            "Generator and coroutine execution timing is preserved.",
        ],
        [
            "a runtime validator removed so an invalid payload is accepted",
            "an absence state merged with another absence state",
            "a rejected promise swallowed so a failure reports success",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
]

SKILLS[117] = [
    path_pack(
        "python", "Python", "cplusplus", "C++",
        ["dynamic freezing", "reference count boundary", "buffer layout", "interpreter lock boundary"],
        [
            "Reference counting across the native boundary is balanced and proven.",
            "Buffer stride, view and broadcast semantics survive the conversion.",
            "Address, undefined behaviour and thread sanitizers pass on the required scope.",
        ],
        [
            "a reference count increment removed or a decrement duplicated",
            "a buffer released while a view onto it is still live",
            "an interpreter lock released around code that requires it",
        ],
        ceiling("E2", "E4", "E5-C", "While any native extension behaviour is unknown the ceiling stays at E3."),
    ),
    path_pack(
        "python", "Python", "objectivec", "Objective-C",
        ["dual dynamic runtimes", "patch versus swizzle", "absence triage", "queue affinity"],
        [
            "Source patching and target runtime replacement are treated as distinct mechanisms.",
            "Absent, null placeholder and nil states remain distinguishable.",
            "Main-queue-only interfaces are invoked only from the main queue.",
        ],
        [
            "a patch scope mapped onto an incompatible runtime replacement scope",
            "an autoreleased object escaping its pool",
            "an error object dropped so a failure returns as success",
        ],
        ceiling("E2", "E4", "E5-C", "While any dynamic mutation remains unfrozen the ceiling stays at E4."),
    ),
    path_pack(
        "python", "Python", "swift", "Swift",
        ["shape inference", "reference identity", "isolation mapping", "array view semantics"],
        [
            "Shared mutable objects are not silently converted into value types.",
            "Serialized execution assumptions become explicit isolation.",
            "Array view and copy semantics survive numerical library conversion.",
        ],
        [
            "a shared reference object converted into a copied value struct",
            "a forced unwrap introduced where absence was observed",
            "a continuation resumed twice or never resumed",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "csharp", "C#", "java", "Java",
        ["generic model shift", "value type identity", "disposal mapping", "cancellation flow"],
        [
            "Value type copy semantics are preserved or an explicit decision is recorded.",
            "Disposal maps to deterministic closing, not to finalization.",
            "Cancellation propagates through every asynchronous boundary.",
        ],
        [
            "a value type converted to a shared reference object",
            "an event subscription never released",
            "a cancellation signal accepted but never observed",
        ],
        ceiling("E4", "E4", "E5"),
    ),
    path_pack(
        "csharp", "C#", "python", "Python",
        ["value semantics", "nullable mapping", "disposal mapping", "decimal fidelity"],
        [
            "Value type copy semantics are preserved by copying or immutable wrappers.",
            "Nullable annotations survive as runtime guards.",
            "Decimal quantities map to arbitrary precision decimals.",
        ],
        [
            "a value type shared instead of copied",
            "a context manager removed from a resource path",
            "a decimal quantity converted to a float",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "csharp", "C#", "rust", "Rust",
        ["object graph to ownership", "delegate to closure", "disposal to drop", "cancellation token"],
        [
            "Ownership choices are justified by observed sharing and concurrency.",
            "Disposal maps to scope-bound release with the same ordering.",
            "Cancellation propagates through every awaited boundary.",
        ],
        [
            "a shared reference converted to a single-threaded counted pointer",
            "a scope-bound release omitted from a resource path",
            "a lock held across an await point",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "csharp", "C#", "go", "Go",
        ["property explicitation", "exception to error", "cancellation to context", "disposal to defer"],
        [
            "Every error return is inspected rather than discarded.",
            "Request context propagates to every dependency call.",
            "Resource closing is deferred on every exit path.",
        ],
        [
            "a context replaced by a background context",
            "a resource close omitted from an error path",
            "a map shared across workers without synchronization",
        ],
        ceiling("E3", "E4", "E5"),
    ),
    path_pack(
        "csharp", "C#", "typescript", "TypeScript",
        ["runtime validation", "value identity", "cancellation signal", "decimal fidelity"],
        [
            "Runtime generics are replaced by explicit runtime validation.",
            "Value type copy semantics are preserved by copying or freezing.",
            "Cancellation maps to an abort signal that is actually observed.",
        ],
        [
            "a runtime validator removed so an invalid payload is accepted",
            "a decimal quantity converted to a floating point number",
            "an event listener that is never removed",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "csharp", "C#", "cplusplus", "C++",
        ["layout and marshalling", "delegate lifetime", "disposal to destructor", "calling convention"],
        [
            "Structure packing, alignment and calling convention are pinned per target.",
            "Callback lifetime outlives every path that can invoke it.",
            "Address, undefined behaviour and thread sanitizers pass on the required scope.",
        ],
        [
            "a structure packing change that misreads a native field",
            "a callback collected while native code still holds it",
            "an exception crossing an incompatible binary boundary",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "csharp", "C#", "objectivec", "Objective-C",
        ["delegate to block", "event to observer", "reference counting", "queue affinity"],
        [
            "Delegate and block lifetimes are explicit on both sides of the bridge.",
            "Observation notification counts match the source event counts.",
            "Main-queue-only interfaces are invoked only from the main queue.",
        ],
        [
            "a block retain cycle introduced by a captured reference",
            "an error object dropped so a failure returns as success",
            "a nullability annotation omitted so a value is implicitly optional",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "csharp", "C#", "swift", "Swift",
        ["value semantics", "closure lifetime", "isolation mapping", "deterministic cleanup"],
        [
            "Value copy semantics and copy-on-write behaviour are distinguished.",
            "Disposal maps to deterministic release rather than to collection.",
            "Cancellation semantics are preserved across the isolation model change.",
        ],
        [
            "a copy semantic change that alters shared mutation",
            "a closure retain cycle introduced during conversion",
            "a decimal quantity converted to a binary floating point type",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "rust", "Rust", "java", "Java",
        ["constraint preservation", "move discipline", "exhaustiveness", "deterministic cleanup"],
        [
            "Move semantics do not degrade into unrestricted sharing.",
            "Exhaustive matching is preserved or replaced by a runtime guard.",
            "Deterministic release becomes explicit closing, not finalization.",
        ],
        [
            "a moved value shared by two owners after conversion",
            "an exhaustive match given a silent default branch",
            "a cross-thread safety bound left entirely unenforced",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "rust", "Rust", "python", "Python",
        ["constraint preservation", "single owner design", "exhaustiveness", "thread confinement"],
        [
            "Ownership constraints survive as wrappers, guards or runtime assertions.",
            "Deterministic release becomes an explicit scope construct.",
            "Thread confinement constraints are enforced rather than assumed.",
        ],
        [
            "a resource whose release now depends on the collector",
            "shared mutable state widened beyond the source scope",
            "a copy restriction removed during conversion",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "rust", "Rust", "csharp", "C#",
        ["owner wrapper", "disposal mapping", "handle safety", "thread bound preservation"],
        [
            "Single ownership becomes an explicit owner type with deterministic disposal.",
            "Native handles use safe handle types rather than raw pointers.",
            "Cross-thread bounds survive as analyzable annotations.",
        ],
        [
            "a disposal call omitted from a resource path",
            "a safe handle replaced by a raw pointer",
            "a result error converted into a null return",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "rust", "Rust", "go", "Go",
        ["single writer design", "optional explicitation", "error mapping", "slice ownership"],
        [
            "Single ownership becomes an explicit single-writer design with closing.",
            "Optional values stay distinguishable from the target zero value.",
            "Slice lifetime and backing array ownership are explicit.",
        ],
        [
            "an absent value merged with the target zero value",
            "a close call omitted from a resource path",
            "a slice that outlives the buffer backing it",
        ],
        ceiling("E3", "E4", "E5"),
    ),
    path_pack(
        "rust", "Rust", "typescript", "TypeScript",
        ["immutable surface", "discriminated union", "explicit disposal", "large integer safety"],
        [
            "Ownership constraints survive as immutable interfaces and runtime guards.",
            "Algebraic enumerations map to discriminated unions with retained tags.",
            "Wide integers map to arbitrary precision values, not to numbers.",
        ],
        [
            "a union discriminator removed during conversion",
            "a wide integer narrowed to a double precision number",
            "an explicit disposal step omitted from a resource path",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
]

SKILLS[118] = [
    path_pack(
        "rust", "Rust", "cplusplus", "C++",
        ["pointer ownership mapping", "lifetime to reference", "variant mapping", "unsafe boundary"],
        [
            "Unique and shared ownership map to matching pointer types with the same release order.",
            "Borrow lifetimes are expressed as documented reference lifetimes and checked.",
            "Address, undefined behaviour and thread sanitizers pass on the required scope.",
        ],
        [
            "a unique owner converted into an unrestricted shared pointer",
            "a reference lifetime extended beyond its source scope",
            "an exception crossing a foreign function boundary",
        ],
        ceiling("E4", "E4", "E5-C"),
    ),
    path_pack(
        "rust", "Rust", "objectivec", "Objective-C",
        ["ownership to reference counting", "protocol mapping", "error object mapping", "queue affinity"],
        [
            "Ownership maps to strong and weak references with matching release order.",
            "Panics are contained and never cross a foreign function boundary.",
            "Main-queue-only interfaces are invoked only from the main queue.",
        ],
        [
            "a strong or weak qualifier chosen incorrectly on a captured reference",
            "an autoreleased object escaping its pool",
            "a cross-thread bound asserted for an object that does not satisfy it",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "rust", "Rust", "swift", "Swift",
        ["move to value semantics", "borrow to exclusivity", "enum parity", "sendability mapping"],
        [
            "Move semantics do not degrade into implicit copies with divergent identity.",
            "Exclusive access boundaries are preserved through the in-out conversion.",
            "Sendability bounds are derived from the source cross-thread bounds.",
        ],
        [
            "a move converted into an implicit copy that changes identity",
            "an exclusive access boundary lost during conversion",
            "a continuation resumed twice or never resumed",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "go", "Go", "java", "Java",
        ["receiver semantics", "absence versus zero", "error mapping", "channel to queue"],
        [
            "Value and pointer receiver copy semantics are preserved.",
            "Typed nil and zero values stay distinguishable from absence.",
            "Deferred cleanup maps to a construct that runs on every exit path.",
        ],
        [
            "a typed nil interface comparison that changes behaviour",
            "a deferred cleanup step omitted during conversion",
            "a cancellation signal that stops propagating at a boundary",
        ],
        ceiling("E3", "E4", "E5"),
    ),
    path_pack(
        "go", "Go", "python", "Python",
        ["receiver copy semantics", "absence mapping", "error mapping", "integer width"],
        [
            "Value receiver copy semantics are preserved rather than shared.",
            "Zero values and absence remain distinguishable.",
            "Fixed integer width behaviour is preserved or explicitly guarded.",
        ],
        [
            "a value copy converted into a shared mutable object",
            "an error swallowed so a failure reports success",
            "a channel ordering guarantee lost during conversion",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "go", "Go", "csharp", "C#",
        ["receiver semantics", "absence mapping", "channel mapping", "cancellation mapping"],
        [
            "Value and reference selection preserves the source copy semantics.",
            "Zero values and nullable absence stay distinguishable.",
            "Channel completion and cancellation semantics are preserved.",
        ],
        [
            "a channel completion signal omitted during conversion",
            "a disposal call omitted from a resource path",
            "a shared map mutated concurrently without synchronization",
        ],
        ceiling("E3", "E4", "E5"),
    ),
    path_pack(
        "go", "Go", "rust", "Rust",
        ["absence to option", "error to result", "deferred cleanup to drop", "slice ownership"],
        [
            "Absent values map to explicit optional types rather than to defaults.",
            "Deferred cleanup maps to scope-bound release with the same ordering.",
            "Slice ownership and lifetime are explicit after conversion.",
        ],
        [
            "an optional branch removed from a generated match",
            "a lock held across an await point",
            "a channel close semantic that diverges from the source",
        ],
        ceiling("E3", "E4", "E5"),
    ),
    path_pack(
        "go", "Go", "typescript", "TypeScript",
        ["absence mapping", "wide integer safety", "cancellation signal", "backpressure preservation"],
        [
            "Zero values, null and undefined all remain distinguishable.",
            "Wide integers map to arbitrary precision values, not to numbers.",
            "Stream backpressure behaviour is preserved.",
        ],
        [
            "a wide integer narrowed to a double precision number",
            "a runtime validator removed so an invalid payload is accepted",
            "a stream backpressure mechanism removed during conversion",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "go", "Go", "cplusplus", "C++",
        ["managed to scope-bound release", "foreign pointer rules", "slice to buffer", "text encoding"],
        [
            "Foreign pointer retention rules are respected in both directions.",
            "Buffer ownership is explicit for every slice crossing the boundary.",
            "Address and thread sanitizers pass on the required scope.",
        ],
        [
            "a managed pointer retained by native code beyond its permitted window",
            "a buffer released while a view onto it is still live",
            "a blocking call that stalls the source scheduler",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "go", "Go", "objectivec", "Objective-C",
        ["bridge ownership", "absence triage", "queue affinity", "error object mapping"],
        [
            "Foreign pointer retention across the bridge follows the declared rules.",
            "Main-queue-only interfaces are invoked only from the main queue.",
            "Typed nil, nil and null placeholder states stay distinguishable.",
        ],
        [
            "a managed pointer stored across the bridge beyond its permitted window",
            "an autorelease pool omitted from a batched allocation path",
            "an error object dropped so a failure returns as success",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "go", "Go", "swift", "Swift",
        ["receiver to value semantics", "absence mapping", "channel to stream", "cancellation mapping"],
        [
            "Value and reference selection preserves the source copy semantics.",
            "Zero values map to an explicit default or an optional, never to both.",
            "Cancellation propagates through every task boundary.",
        ],
        [
            "a zero value and an optional absence merged into one state",
            "a channel close signal lost during stream conversion",
            "a reference cycle introduced by a captured closure",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "typescript", "TypeScript", "java", "Java",
        ["erasure compensation", "union to hierarchy", "absence triage", "numeric widening"],
        [
            "Erased static types are backed by runtime evidence before conversion.",
            "Union members map to a closed hierarchy with no dropped branch.",
            "Missing, null and undefined states remain distinguishable.",
        ],
        [
            "a union branch missing from the generated hierarchy",
            "an undefined state merged with a null state",
            "a number narrowed past the safe integer range",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "typescript", "TypeScript", "python", "Python",
        ["erasure compensation", "absence triage", "numeric mapping", "stream backpressure"],
        [
            "Runtime validation replaces the erased static types.",
            "Missing, null and undefined states remain distinguishable.",
            "Stream backpressure and decorator ordering are preserved.",
        ],
        [
            "an undefined state merged with a null state",
            "a wide integer converted to a floating point value",
            "an awaited call omitted so a failure escapes unobserved",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "typescript", "TypeScript", "csharp", "C#",
        ["union to record hierarchy", "presence wrapper", "cancellation mapping", "numeric typing"],
        [
            "Absence uses an explicit presence wrapper, not a single nullable value.",
            "Numbers map to explicitly chosen runtime types with recorded rationale.",
            "Abort signals map to cancellation tokens that are actually observed.",
        ],
        [
            "a missing state and a null state merged into one nullable",
            "a runtime validator removed so an invalid payload is accepted",
            "a cancellation token accepted but never observed",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "typescript", "TypeScript", "rust", "Rust",
        ["shape to struct", "dynamic elimination", "absence to option", "runtime to async model"],
        [
            "Unconstrained dynamic types are eliminated or isolated behind a boundary.",
            "Missing, null and undefined map to distinct explicit states.",
            "Event loop ordering is preserved through the asynchronous runtime change.",
        ],
        [
            "two distinct absence states merged into one option",
            "a number narrowed so a large value silently truncates",
            "a lock held across an await point",
        ],
        ceiling("E2", "E4", "E5-C", "While any proxy behaviour remains unfrozen the ceiling stays at E4."),
    ),
    path_pack(
        "typescript", "TypeScript", "go", "Go",
        ["shape to struct", "absence versus zero", "numeric typing", "cancellation mapping"],
        [
            "Dynamic shapes become explicit structures backed by runtime evidence.",
            "Absent values remain distinguishable from the target zero value.",
            "Abort semantics map to a context that is actually observed.",
        ],
        [
            "an absent value converted into a zero value that changes a decision",
            "a number that overflows the chosen fixed width",
            "a spawned worker that the request never waits for",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
]

SKILLS[119] = [
    path_pack(
        "typescript", "TypeScript", "cplusplus", "C++",
        ["dynamic object freezing", "numeric safety", "native object lifetime", "loop ordering"],
        [
            "Dynamic object shapes are frozen from runtime evidence before generation.",
            "Native object lifetime across the runtime boundary is explicit and balanced.",
            "Address and thread sanitizers pass on the required scope.",
        ],
        [
            "a wide integer truncated during native conversion",
            "a runtime object collected while native code still holds it",
            "a microtask ordering change that alters observable behaviour",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "typescript", "TypeScript", "objectivec", "Objective-C",
        ["dynamic runtime divergence", "absence triage", "boxed number semantics", "queue affinity"],
        [
            "Prototype-based dynamism and message forwarding are treated as distinct mechanisms.",
            "Boxed boolean and numeric values stay distinguishable after bridging.",
            "Main-queue-only interfaces are invoked only from the main queue.",
        ],
        [
            "an undefined state and a nil state merged into one",
            "a boxed boolean read as a numeric value",
            "an object bridge that loses reference identity",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "typescript", "TypeScript", "swift", "Swift",
        ["union to enum", "presence modelling", "reference identity", "isolation ordering"],
        [
            "Absence uses an explicit presence enumeration, not a single optional.",
            "Reference-shared objects are not silently converted into value types.",
            "Observable ordering survives the event loop to isolation conversion.",
        ],
        [
            "a shared reference object converted into a copied value struct",
            "two distinct absence states merged into one optional",
            "a forced unwrap introduced where absence was observed",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "cplusplus", "C++", "java", "Java",
        ["scope-bound to managed release", "copy and move semantics", "fixed width integers", "memory model"],
        [
            "Unexplained undefined behaviour in the source baseline is zero.",
            "Deterministic release becomes explicit closing, not finalization.",
            "Unsigned and fixed width integer behaviour is preserved or guarded.",
        ],
        [
            "a destructor side effect omitted during conversion",
            "a move converted into unrestricted sharing",
            "an atomic constraint removed from the generated code",
        ],
        ceiling("E3", "E4", "E5-C", "While the source retains unexplained undefined behaviour the ceiling stays at E3."),
    ),
    path_pack(
        "cplusplus", "C++", "python", "Python",
        ["native object wrapper", "buffer lifetime", "interpreter lock", "callback lifetime"],
        [
            "Native object lifetime is owned by an explicit wrapper with deterministic release.",
            "Buffer views never outlive the memory backing them.",
            "Address sanitizer passes on the required native scope.",
        ],
        [
            "a native object released while a wrapper still references it",
            "a buffer view that outlives its backing allocation",
            "a callback invoked after its owning object was destroyed",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "cplusplus", "C++", "csharp", "C#",
        ["layout and marshalling", "handle safety", "destructor to disposal", "calling convention"],
        [
            "Structure packing, alignment and calling convention are pinned per target.",
            "Native handles use safe handle types with deterministic release.",
            "Text encoding conversions are lossless in both directions.",
        ],
        [
            "a structure packing change that misreads a native field",
            "a native exception crossing the managed boundary",
            "a callback collected while native code still holds it",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "cplusplus", "C++", "rust", "Rust",
        ["pointer to ownership", "reference lifetime", "union to enum", "unsafe minimization"],
        [
            "Unique, shared and weak pointers map to matching ownership types.",
            "Every generated unsafe region carries a written safety justification.",
            "Source and target sanitizers both pass on the required scope.",
        ],
        [
            "an unsafe region widened beyond the source requirement",
            "a unique owner converted into an unrestricted shared owner",
            "an atomic memory ordering weakened during conversion",
        ],
        ceiling("E4", "E4", "E5-C"),
    ),
    path_pack(
        "cplusplus", "C++", "go", "Go",
        ["scope-bound to explicit close", "foreign pointer rules", "buffer ownership", "integer semantics"],
        [
            "Foreign pointer retention rules are respected in both directions.",
            "Buffer ownership is explicit for every slice crossing the boundary.",
            "Address and thread sanitizers pass on the required scope.",
        ],
        [
            "a slice referencing an already released native buffer",
            "a close call omitted from an error path",
            "an unsigned value reinterpreted with the wrong sign",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "cplusplus", "C++", "typescript", "TypeScript",
        ["opaque handle", "numeric safety", "buffer view semantics", "callback lifetime"],
        [
            "Native resources are exposed as opaque handles with explicit disposal.",
            "Wide integers map to arbitrary precision values, not to numbers.",
            "Buffer copy and view semantics are preserved across the boundary.",
        ],
        [
            "a handle disposal step omitted from an error path",
            "a wide integer narrowed to a double precision number",
            "a native callback invoked more times than the source invoked it",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "cplusplus", "C++", "objectivec", "Objective-C",
        ["dual ownership models", "destructor and deallocation order", "block versus lambda", "text encoding"],
        [
            "Scope-bound release and reference counting interoperate with a declared order.",
            "Bridging ownership transfer is explicit at every crossing.",
            "Address and thread sanitizers pass on the required scope.",
        ],
        [
            "a destructor that never runs because ownership crossed the bridge",
            "a reference cycle formed across the two ownership models",
            "an autorelease pool omitted from a batched allocation path",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "cplusplus", "C++", "swift", "Swift",
        ["value and reference selection", "copy and move semantics", "pointer lifetime", "isolation mapping"],
        [
            "Unique ownership does not silently become shared strong ownership.",
            "Copy, move and copy-on-write behaviour are distinguished explicitly.",
            "Source sanitizers and target concurrency checks both pass.",
        ],
        [
            "a unique owner converted into an unrestricted strong reference",
            "an unknown enumeration value that traps the target",
            "a pointer used beyond the lifetime of its allocation",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "objectivec", "Objective-C", "java", "Java",
        ["dispatch explicitation", "runtime freezing", "reference counting to collection", "observation parity"],
        [
            "Selector dispatch and runtime replacement are frozen into explicit strategies.",
            "Weak reference semantics survive the collection model change.",
            "Observation notification counts match the source.",
        ],
        [
            "a selector branch missing from the generated dispatch",
            "a runtime replacement that was never frozen",
            "an error object dropped so a failure returns as success",
        ],
        ceiling("E2", "E4", "E5-C", "While any dynamic replacement remains unfrozen the ceiling stays at E4."),
    ),
    path_pack(
        "objectivec", "Objective-C", "python", "Python",
        ["dual dynamic runtimes", "observation mapping", "reference cycle behaviour", "absence triage"],
        [
            "Runtime replacement and source-level patching are treated as distinct mechanisms.",
            "Reference cycle collection differences are recorded, not assumed equivalent.",
            "Nil, null placeholder and none states stay distinguishable.",
        ],
        [
            "a runtime replacement mapped onto an incompatible patch scope",
            "an observation event dropped during conversion",
            "a callback invoked more times than the source invoked it",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "objectivec", "Objective-C", "csharp", "C#",
        ["dispatch registry", "block to delegate", "observation to event", "queue to context"],
        [
            "Selector dispatch becomes an explicit method or delegate registry.",
            "Delegate lifetime is explicit so no callback is collected prematurely.",
            "Main-queue affinity maps to an equivalent synchronization context.",
        ],
        [
            "a delegate collected while native code still holds it",
            "a runtime replacement that was never frozen",
            "a deterministic release converted into finalization",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "objectivec", "Objective-C", "rust", "Rust",
        ["dispatch registry", "reference counting to ownership", "absence to option", "panic containment"],
        [
            "Dynamic dispatch is frozen into an explicit registry before generation.",
            "Strong and weak references map to matching ownership with the same release order.",
            "Panics are contained and never cross a foreign function boundary.",
        ],
        [
            "a cross-thread marker asserted for an object that does not satisfy it",
            "an autoreleased object released before its last use",
            "a runtime replacement missing from the generated registry",
        ],
        ceiling("E2", "E4", "E5-C", "While the runtime is not fully frozen the ceiling stays at E4."),
    ),
    path_pack(
        "objectivec", "Objective-C", "go", "Go",
        ["dispatch registry", "bridge ownership", "absence triage", "queue affinity"],
        [
            "Dynamic dispatch becomes an explicit interface and registry.",
            "Object retention across the bridge follows the declared pointer rules.",
            "Main-queue-only interfaces are invoked only from the main queue.",
        ],
        [
            "a bridged object retained beyond its permitted window",
            "a typed nil comparison that changes behaviour",
            "an observation event dropped during conversion",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
]


BATCHES[120] = {
    "title": "Apple Source Directional Packs and Framework Semantic Core",
    "why": "Moves ELMOS from a code-level Apple-platform port to frozen runtime dispatch, and opens the framework layer with an explicit lifecycle and pipeline representation.",
    "purpose": "close the remaining Objective-C and Swift outbound directional paths, then establish the framework inventory, lifecycle, request pipeline, dependency injection and configuration layers that all framework mapping depends on.",
    "tooling": ["directional pack compiler", "Apple runtime trace adapter", "framework lifecycle extractor", "request pipeline recorder"],
}

SKILLS[120] = [
    path_pack(
        "objectivec", "Objective-C", "typescript", "TypeScript",
        ["dispatch registry", "absence triage", "observation to event", "bridge identity"],
        [
            "Selector dispatch and runtime replacement become explicit plugin registration.",
            "Nil, null placeholder, null and undefined all remain distinguishable.",
            "Observation event counts match the source notification counts.",
        ],
        [
            "an object bridge that loses reference identity",
            "a callback invoked more times than the source invoked it",
            "a main-thread constraint removed during conversion",
        ],
        ceiling("E2", "E4", "E5-C"),
    ),
    path_pack(
        "objectivec", "Objective-C", "cplusplus", "C++",
        ["dispatch to virtual", "reference counting to scope-bound release", "block to callable", "text encoding"],
        [
            "Reference cycles are not merely relocated into the target ownership model.",
            "Autorelease timing differences are recorded rather than assumed equivalent.",
            "Address and thread sanitizers pass on the required scope.",
        ],
        [
            "a reference cycle recreated in the target shared ownership model",
            "a selector signature mismatch introduced during conversion",
            "a destruction order inversion between dependent objects",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "objectivec", "Objective-C", "swift", "Swift",
        ["nullability completion", "protocol bridging", "error to throws", "isolation adoption"],
        [
            "Every bridged interface declares complete nullability rather than implicit optionality.",
            "Observation continues to work only on interfaces that remain dynamically dispatched.",
            "Main-actor requirements replace the source main-queue requirements exactly.",
        ],
        [
            "an interface exposed as implicitly optional",
            "an observation marker omitted so notifications stop firing",
            "an error object mapping that loses its code or domain",
        ],
        ceiling("E4", "E4", "E5"),
    ),
    path_pack(
        "swift", "Swift", "java", "Java",
        ["value semantics preservation", "enum to hierarchy", "isolation to synchronization", "deterministic cleanup"],
        [
            "Copy-on-write buffers do not become shared mutable objects.",
            "Enumeration associated values map to a closed hierarchy without flattening.",
            "Deterministic release becomes explicit closing, not finalization.",
        ],
        [
            "a value struct converted into a shared reference object",
            "an isolation boundary removed so shared state becomes racy",
            "a decimal quantity converted to a binary floating point type",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "swift", "Swift", "python", "Python",
        ["value semantics preservation", "enum tagging", "isolation to serialization", "deterministic cleanup"],
        [
            "Value semantics survive as copies or immutable wrappers.",
            "Enumeration discriminators are preserved in the generated model.",
            "Release remains deterministic rather than collector dependent.",
        ],
        [
            "a value struct converted into a shared mutable object",
            "an isolation guarantee removed without a compensating lock",
            "a decimal quantity converted to a float",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "swift", "Swift", "csharp", "C#",
        ["value semantics", "enum to record hierarchy", "closure lifetime", "disposal mapping"],
        [
            "Copy-on-write and eager copy behaviour are distinguished explicitly.",
            "Enumeration associated values map to a closed record hierarchy.",
            "Deterministic release maps to disposal, not to finalization.",
        ],
        [
            "an enumeration match given a silent default branch",
            "a disposal call omitted from a resource path",
            "an isolation boundary removed during conversion",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "swift", "Swift", "rust", "Rust",
        ["reference counting to ownership", "copy on write", "sendability to thread bounds", "borrow mapping"],
        [
            "Reference-counted classes map to ownership justified by observed sharing.",
            "Copy-on-write behaviour becomes neither a deep copy nor unrestricted sharing.",
            "Sendability bounds map to matching cross-thread bounds.",
        ],
        [
            "a copy-on-write buffer converted into an eager deep copy",
            "a cross-thread bound asserted without supporting evidence",
            "a scope-bound release omitted from a resource path",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "swift", "Swift", "go", "Go",
        ["value semantics", "optional versus zero", "isolation to single writer", "deterministic cleanup"],
        [
            "Value structs are copied rather than shared after conversion.",
            "Optional absence stays distinguishable from the target zero value.",
            "Isolated state becomes a single-writer design with the same serialization.",
        ],
        [
            "an optional absence merged with the target zero value",
            "a single-writer guarantee broken by an added worker",
            "a close call omitted from a resource path",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "swift", "Swift", "typescript", "TypeScript",
        ["value semantics", "enum to discriminated union", "presence modelling", "isolation to serialization"],
        [
            "Value structs map to copied or frozen objects, not to shared references.",
            "Enumeration discriminators survive the union conversion.",
            "Serialized isolation behaviour is preserved by an explicit executor.",
        ],
        [
            "a union discriminator removed during conversion",
            "a decimal quantity converted to a floating point number",
            "an isolation serialization guarantee lost during conversion",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "swift", "Swift", "cplusplus", "C++",
        ["value and reference selection", "copy on write", "reference counting to scope-bound release", "isolation mapping"],
        [
            "Copy-on-write semantics are neither eagerly copied nor silently shared.",
            "Reference counting maps to matching ownership with the same release order.",
            "Address and thread sanitizers pass on the required scope.",
        ],
        [
            "a reference-counted object converted into unrestricted shared ownership",
            "a destructor step omitted from an error path",
            "an exception crossing an incompatible binary boundary",
        ],
        ceiling("E3", "E4", "E5-C"),
    ),
    path_pack(
        "swift", "Swift", "objectivec", "Objective-C",
        ["wrapper generation", "nullability completion", "error to error object", "isolation to queue"],
        [
            "Types that cannot be exposed directly gain an explicit wrapper.",
            "Optionality is exported as complete nullability, never as implicit optional.",
            "Actor isolation becomes an explicit queue or serialized entry point.",
        ],
        [
            "an interface exposed as implicitly optional",
            "an associated-type protocol erased incorrectly during bridging",
            "a collection bridge that forces an unchecked type conversion",
        ],
        ceiling("E4", "E4", "E5"),
    ),
    (
        "framework-inventory-builder",
        "Framework Inventory Builder",
        "Identify every framework, extension, plugin, version boundary and implicit capability the repository uses",
        ["framework detection", "plugin enumeration", "implicit capability", "version boundary"],
        ["framework_inventory.json", "implicit_capability_index.json", "inventory_gaps.md"],
        [
            "Web, injection, persistence, messaging, security, validation and observability components are all detected.",
            "Automatic scanning, startup loading, runtime registration and code generation sites are enumerated.",
            "Declared build versions are reconciled against the versions actually loaded at runtime.",
        ],
        [
            "a production framework component absent from the build files",
            "a plugin loaded at runtime that cannot be enumerated",
            "a generated artifact whose generator cannot be traced",
        ],
    ),
    (
        "unified-framework-lifecycle-ir",
        "Unified Framework Lifecycle IR",
        "Represent process startup, request handling and shutdown lifecycle uniformly across framework families",
        ["lifecycle phase", "dependency availability", "permitted effect", "shutdown ordering"],
        ["framework_lifecycle_ir.json", "phase_registry.json", "lifecycle_notes.md"],
        [
            "Every phase records its execution context, available dependencies and permitted effects.",
            "Ordering, concurrency limits, timeouts and cancellation are recorded per phase.",
            "Resource release is bound to a specific shutdown phase.",
        ],
        [
            "a phase whose permitted effects were never determined",
            "a startup step that reports ready before its dependency is available",
            "a shutdown phase with no defined resource release",
        ],
    ),
    (
        "request-pipeline-ir-builder",
        "Request Pipeline IR Builder",
        "Record the complete ordered execution path a request takes through the framework",
        ["stage ordering", "short circuit", "scope boundary", "commit relative position"],
        ["request_pipeline_ir.json", "stage_ordering.json", "pipeline_notes.md"],
        [
            "The observed stage order is recorded, not the declared registration order.",
            "Short-circuit behaviour and exception propagation are captured per stage.",
            "Each stage records its position relative to transaction commit.",
        ],
        [
            "a pipeline recorded from configuration rather than from execution",
            "an authorization stage that moved after business handling",
            "a stage executed twice without that repetition being recorded",
        ],
    ),
    (
        "dependency-injection-semantic-ir",
        "Dependency Injection Semantic IR",
        "Represent registration, resolution, scope and destruction uniformly across injection containers",
        ["scope model", "creation timing", "destruction timing", "proxy generation"],
        ["di_semantic_ir.json", "scope_model.json", "di_risk_report.md"],
        [
            "Every component records its scope, creation timing and destruction timing.",
            "Proxy generation, laziness and circular dependency tolerance are recorded.",
            "Components that hold request state are identified explicitly.",
        ],
        [
            "a request-scoped component promoted to a process singleton",
            "a component holding request state registered as shared",
            "a dependency cache behaviour lost during conversion",
        ],
    ),
    (
        "configuration-semantic-ir",
        "Configuration Semantic IR",
        "Represent configuration sources, precedence, conversion, refresh and secret handling uniformly",
        ["source precedence", "type conversion", "missing behaviour", "secret handling"],
        ["configuration_ir.json", "precedence_matrix.json", "configuration_risks.md"],
        [
            "Source precedence, type conversion and missing-value behaviour are all recorded.",
            "Hot reload behaviour and startup failure rules are explicit.",
            "Sensitive fields are marked and excluded from logs and evidence.",
        ],
        [
            "a configuration the source would reject being accepted by the target",
            "a missing value defaulted to zero or to an empty string",
            "a secret value written into a log or an evidence record",
        ],
    ),
]


BATCHES.update({
    121: {
        "title": "Framework Semantic Frontends Pack",
        "why": "Moves ELMOS from matching controller names to reconstructing what each framework family actually does implicitly.",
        "purpose": "complete the binding, serialization, error pipeline and context propagation layers of the Framework IR, then extract that representation faithfully from every supported framework family including its proxies, scans, conventions and defaults.",
        "tooling": ["framework semantic frontend", "request pipeline recorder", "container introspection adapter", "framework runtime tracer"],
    },
    122: {
        "title": "Cross-Framework Mapping Pack",
        "why": "Moves ELMOS from assuming two frameworks are interchangeable to classifying every capability as direct, adapted, reimplemented or unsupported.",
        "purpose": "compare source and target framework capability vectors, classify every gap, record each mapping decision with its equivalence claim, and govern the major cross-framework migration routes between managed, native and Apple ecosystems.",
        "tooling": ["framework capability vector", "framework gap analyzer", "mapping decision recorder", "framework differential harness"],
    },
    123: {
        "title": "Persistence and Messaging Semantic Pack",
        "why": "Moves ELMOS from comparing final rows to comparing tracking, flush, lock, acknowledgement and delivery semantics.",
        "purpose": "unify object-relational and messaging semantics across every supported stack, verify tracking, flush, cascade, lock, acknowledgement, outbox and delivery guarantees survive conversion, and open the authentication and authorization model.",
        "tooling": ["ORM semantic verifier", "messaging semantic verifier", "transactional messaging harness", "background job mapper"],
    },
    124: {
        "title": "Security, Lifecycle and Framework Test Pack",
        "why": "Moves ELMOS from trusting that a security filter exists to proving it runs first, denies by default and leaves no state behind.",
        "purpose": "verify authentication and authorization behaviour across every framework family, prove startup ordering, graceful shutdown, request scope containment and resource release, and generate the framework-level contract, stress and mutation suites that make those claims falsifiable.",
        "tooling": ["security differential harness", "lifecycle verifier", "scope leak detector", "framework mutation library"],
    },
    125: {
        "title": "Framework Performance and Certification Gate Pack",
        "why": "Moves ELMOS from a framework port that looks right to a framework migration gated on measured performance and staged evidence.",
        "purpose": "compare framework-level performance and resource behaviour under real configuration, and operate the E2 through E5 framework certification gates and the orchestrator that sequences them.",
        "tooling": ["framework performance harness", "framework certification gates", "framework mapping orchestrator", "evidence vault"],
    },
})

SKILLS[121] = [
    (
        "validation-and-binding-ir",
        "Validation and Binding IR",
        "Represent request parsing, field binding, type coercion and validation as one ordered model",
        ["binding stage", "coercion rule", "absence triage", "fail-fast policy"],
        ["validation_ir.json", "binding_stages.json", "validation_gaps.md"],
        [
            "Missing, null, empty, wrong type, wrong format and business-invalid states stay distinct.",
            "Error codes, field paths, error counts and fail-fast behaviour are all recorded.",
            "Default injection is recorded as occurring before or after validation.",
        ],
        [
            "a missing field and an explicit null collapsed into one error",
            "a default injected before validation so an invalid input becomes valid",
            "an unknown field accepted where the source rejected it",
        ],
    ),
    (
        "serialization-semantic-ir",
        "Serialization Semantic IR",
        "Represent response, message and persistence serialization behaviour uniformly",
        ["inclusion policy", "polymorphic discriminator", "temporal precision", "unknown field policy"],
        ["serialization_ir.json", "field_policy_matrix.json", "serialization_gaps.md"],
        [
            "Inclusion, null, missing and default policies are recorded per field.",
            "Polymorphic discriminators, reference loops and custom converters are captured.",
            "Temporal precision, timezone and decimal representation are explicit.",
        ],
        [
            "a null field omitted where the source emitted it",
            "a temporal value losing sub-second precision or timezone",
            "an unknown enumeration value that traps the deserializer",
        ],
    ),
    (
        "framework-error-pipeline-ir",
        "Framework Error Pipeline IR",
        "Represent where errors are raised, caught, translated, logged and turned into responses",
        ["capture layer", "status mapping", "rollback linkage", "exposure control"],
        ["error_pipeline_ir.json", "status_mapping.json", "error_pipeline_gaps.md"],
        [
            "Each error records its capture layer, status, business code and response body.",
            "Whether an error triggers rollback is recorded explicitly.",
            "Internal details that must never reach a client are marked.",
        ],
        [
            "a client error returned as a server error",
            "an error that no longer triggers the rollback it triggered in the source",
            "an internal stack trace exposed in a response body",
        ],
    ),
    (
        "framework-context-propagation-ir",
        "Framework Context Propagation IR",
        "Represent how request identity, tenancy, deadline and cancellation cross asynchronous boundaries",
        ["context content", "propagation boundary", "inheritance policy", "lifetime bound"],
        ["context_propagation_ir.json", "boundary_map.json", "propagation_gaps.md"],
        [
            "Tenancy, identity, locale, deadline and trace context are all tracked.",
            "Every asynchronous boundary records what it propagates and what it drops.",
            "Context lifetime is bound so nothing survives the request that created it.",
        ],
        [
            "a tenant identifier lost across an asynchronous call",
            "a background task inheriting a user authority it should not have",
            "a request context still referenced after the response was sent",
        ],
    ),
    (
        "spring-framework-semantic-pack",
        "Spring Framework Semantic Pack",
        "Extract the implicit component, proxy, transaction and security behaviour of the Spring family",
        ["component scan", "proxy interception", "transaction propagation", "security filter chain"],
        ["spring_framework_ir.json", "proxy_inventory.json", "spring_extraction_gaps.md"],
        [
            "Whether a bean is reached through a proxy is determined, not assumed.",
            "Declarative transactions are verified to actually take effect at runtime.",
            "Security filters are verified to run before the handler they protect.",
        ],
        [
            "a self-invocation that bypasses the declarative transaction proxy",
            "a request-scoped bean promoted to a singleton",
            "a blocking call introduced into a reactive pipeline",
        ],
    ),
    (
        "aspnet-core-semantic-pack",
        "ASP.NET Core Semantic Pack",
        "Extract middleware ordering, service lifetime, binding and hosted service behaviour",
        ["middleware ordering", "service lifetime", "endpoint routing", "hosted service"],
        ["aspnet_framework_ir.json", "middleware_order.json", "aspnet_extraction_gaps.md"],
        [
            "Middleware position relative to routing and authentication is recorded from execution.",
            "Scoped services are verified not to escape into background work.",
            "Cancellation tokens are verified to reach every dependency call.",
        ],
        [
            "a scoped database context captured by a singleton",
            "an authentication middleware registered after routing",
            "a hosted service registered twice so it runs concurrently",
        ],
    ),
    (
        "fastapi-semantic-pack",
        "FastAPI Semantic Pack",
        "Extract dependency graph, caching, cleanup ordering and asynchronous endpoint behaviour",
        ["dependency graph", "dependency cache", "generator cleanup", "lifespan"],
        ["fastapi_framework_ir.json", "dependency_graph.json", "fastapi_extraction_gaps.md"],
        [
            "Dependency execution and cleanup ordering are recorded from real execution.",
            "Generator dependency cleanup is verified on both success and exception paths.",
            "Synchronous endpoints are verified to run off the event loop.",
        ],
        [
            "a generator dependency whose cleanup never runs on the error path",
            "a blocking call executed directly on the event loop",
            "a background task that runs before the response is sent",
        ],
    ),
    (
        "django-semantic-pack",
        "Django Semantic Pack",
        "Extract middleware ordering, query laziness, signal behaviour and request-level transaction policy",
        ["middleware ordering", "query laziness", "model signal", "request atomicity"],
        ["django_framework_ir.json", "signal_inventory.json", "django_extraction_gaps.md"],
        [
            "Query evaluation timing is recorded rather than assumed.",
            "Model signal registration and firing counts are captured.",
            "Request-level transaction policy and its boundary are explicit.",
        ],
        [
            "a lazy query evaluated earlier than in the source",
            "a model signal that fires twice after conversion",
            "a cross-site request protection step lost during conversion",
        ],
    ),
    (
        "axum-semantic-pack",
        "Axum Semantic Pack",
        "Extract layer ordering, extractor behaviour, shared state ownership and cancellation semantics",
        ["layer ordering", "extractor consumption", "state ownership", "graceful shutdown"],
        ["axum_framework_ir.json", "layer_order.json", "axum_extraction_gaps.md"],
        [
            "Nested router and layer ordering is recorded from execution.",
            "Body-consuming extractors are verified to run exactly once.",
            "Shared state is verified to use a thread-safe shared owner.",
        ],
        [
            "a request body extracted twice in one pipeline",
            "a lock held across an await point inside a handler",
            "a shutdown path that does not drain in-flight requests",
        ],
    ),
    (
        "actix-web-semantic-pack",
        "Actix Web Semantic Pack",
        "Extract worker model, shared application data construction and actor mailbox behaviour",
        ["worker model", "application data scope", "actor mailbox", "middleware wrapping"],
        ["actix_framework_ir.json", "worker_state_map.json", "actix_extraction_gaps.md"],
        [
            "Whether shared state is constructed once or per worker is determined explicitly.",
            "Middleware wrapping order is recorded from execution, not registration.",
            "Actor mailbox capacity and backpressure behaviour are captured.",
        ],
        [
            "a shared resource reconstructed once per worker",
            "a non-thread-safe value shared across workers",
            "a websocket connection whose resources are never released",
        ],
    ),
    (
        "go-web-framework-semantic-pack",
        "Go Web Framework Semantic Pack",
        "Extract router, middleware ordering, context injection and response writer behaviour",
        ["middleware ordering", "context injection", "body consumption", "pooled object reuse"],
        ["go_framework_ir.json", "middleware_order.json", "go_framework_gaps.md"],
        [
            "Request context is verified to reach every database and dependency call.",
            "Body consumption points are recorded so no reader is drained twice.",
            "Server and handler timeouts are explicit rather than defaulted.",
        ],
        [
            "a request context replaced by a background context",
            "a worker still reading the request context after the response was sent",
            "a pooled request object retained across requests",
        ],
    ),
    (
        "nestjs-semantic-pack",
        "NestJS Semantic Pack",
        "Extract module wiring, provider scope, and the real guard, pipe, interceptor and filter ordering",
        ["provider scope", "execution ordering", "decorator metadata", "dynamic module"],
        ["nestjs_framework_ir.json", "execution_order.json", "nestjs_extraction_gaps.md"],
        [
            "Execution order is rebuilt from the actual version and registrations, not assumed.",
            "Provider scope, circular modules and forward references are captured.",
            "Transformation and validation behaviour is recorded per route.",
        ],
        [
            "a request-scoped provider promoted to a singleton",
            "a global validation step removed so unvalidated input reaches a handler",
            "an interceptor that executes twice for one request",
        ],
    ),
    (
        "cplusplus-web-framework-semantic-pack",
        "CPlusPlus Web Framework Semantic Pack",
        "Extract routing, handler lifetime, buffer ownership and connection lifecycle from native web stacks",
        ["handler lifetime", "buffer ownership", "static registration", "connection lifecycle"],
        ["cplusplus_framework_ir.json", "buffer_ownership_map.json", "cplusplus_framework_gaps.md"],
        [
            "Handler object lifetime covers every asynchronous callback that can run.",
            "Buffers stay alive until the asynchronous send that reads them completes.",
            "Address, undefined behaviour and thread sanitizers pass on the required scope.",
        ],
        [
            "a callback capturing a reference that is already destroyed",
            "a buffer released before the asynchronous send completes",
            "an exception escaping across an asynchronous boundary",
        ],
    ),
    (
        "vapor-semantic-pack",
        "Vapor Semantic Pack",
        "Extract application service scope, request storage, event loop affinity and persistence transaction behaviour",
        ["request storage", "event loop affinity", "transaction closure", "content coding"],
        ["vapor_framework_ir.json", "request_storage_map.json", "vapor_extraction_gaps.md"],
        [
            "Request-scoped storage is verified not to escape the request.",
            "Event loop affinity is preserved across the asynchronous bridge.",
            "Transaction closures are verified to enclose the whole unit of work.",
        ],
        [
            "a request object retained in application-level storage",
            "a database connection never returned to the pool",
            "a token verification step removed during conversion",
        ],
    ),
    (
        "swiftnio-and-hummingbird-semantic-pack",
        "SwiftNIO and Hummingbird Semantic Pack",
        "Extract channel pipeline ordering, buffer index discipline, backpressure and shutdown drain behaviour",
        ["channel pipeline", "buffer index discipline", "backpressure", "loop affinity"],
        ["swiftnio_framework_ir.json", "pipeline_handlers.json", "swiftnio_extraction_gaps.md"],
        [
            "Channel handler ordering and inbound and outbound event flow are recorded.",
            "Buffer reader and writer indices are preserved exactly across conversion.",
            "Callbacks are verified to run on their owning event loop.",
        ],
        [
            "a buffer index mismanaged so a frame is misread",
            "a backpressure mechanism removed during conversion",
            "a shutdown that closes channels without draining them",
        ],
    ),
    (
        "objectivec-legacy-service-semantic-pack",
        "ObjectiveC Legacy Service Semantic Pack",
        "Extract run loop, queue, delegate, observation and cross-process interface behaviour from legacy Apple services",
        ["run loop", "delegate lifetime", "cross-process interface", "secure coding"],
        ["objectivec_service_ir.json", "callback_thread_map.json", "objectivec_service_gaps.md"],
        [
            "Delegate lifetime and the thread each callback runs on are recorded.",
            "Cross-process interface argument classes and secure coding rules are captured.",
            "Observation registration and removal are paired for every observer.",
        ],
        [
            "an observer never removed so notifications fire after teardown",
            "a cross-process interface accepting an unchecked argument class",
            "a callback delivered on a thread the source never used",
        ],
    ),
]

SKILLS[122] = [
    (
        "framework-capability-vector-builder",
        "Framework Capability Vector Builder",
        "Describe each framework with a machine-readable capability vector so gaps can be derived automatically",
        ["capability axis", "scope support", "interception support", "async model"],
        ["framework_capability_vectors.json", "capability_schema.json", "capability_notes.md"],
        [
            "Routing, injection, scope, interception, transaction and async axes are populated.",
            "Vectors are versioned against a specific framework release.",
            "Every axis value maps to an observable, testable behaviour.",
        ],
        [
            "a capability axis left unpopulated but treated as absent",
            "a vector reused across incompatible framework major versions",
            "an axis whose value cannot be tested for",
        ],
    ),
    (
        "framework-gap-analyzer",
        "Framework Gap Analyzer",
        "Classify every source framework capability as direct, adapted, reimplemented, redesigned or unsupported",
        ["gap classification", "adapter requirement", "redesign requirement", "unsupported record"],
        ["framework_gap_analysis.json", "gap_classification.json", "gap_report.md"],
        [
            "Every source capability receives exactly one terminal classification.",
            "Redesign and unsupported classifications create release-blocking risks.",
            "Classification cites the capability vector difference that produced it.",
        ],
        [
            "a capability marked direct because the component names match",
            "a redesign requirement recorded as a simple adapter",
            "a capability silently dropped instead of being classified",
        ],
    ),
    (
        "framework-mapping-decision-recorder",
        "Framework Mapping Decision Recorder",
        "Record for every framework mapping decision whether it is fully equivalent and what it costs",
        ["equivalence claim", "adapter description", "failure behaviour", "certification impact"],
        ["framework_decisions.json", "equivalence_claims.json", "decision_report.md"],
        [
            "Each decision states source behaviour, target implementation and equivalence claim.",
            "Failure behaviour and performance impact are recorded per decision.",
            "Each decision names its regression test and its certification impact.",
        ],
        [
            "a decision claiming equivalence with no supporting test",
            "an adapter whose failure behaviour was never determined",
            "a decision that silently lowers the certification ceiling",
        ],
    ),
    (
        "spring-to-aspnet-core-mapping-pack",
        "Spring to ASP.NET Core Mapping Pack",
        "Map Spring components, proxies, transactions, security and persistence onto ASP.NET Core equivalents",
        ["scope mapping", "proxy to filter", "transaction wrapper", "tracking parity"],
        ["spring_to_aspnet_mapping.json", "adapter_inventory.json", "mapping_report.md"],
        [
            "Singleton, request and prototype scopes map to the correct target lifetimes.",
            "Declarative transaction behaviour survives as an explicit unit of work.",
            "Middleware and filter ordering reproduces the source pipeline order.",
        ],
        [
            "a self-invocation transaction behaviour lost during mapping",
            "a scoped component promoted to a singleton",
            "an authentication scheme selection that differs from the source",
        ],
    ),
    (
        "aspnet-core-to-spring-mapping-pack",
        "ASP.NET Core to Spring Mapping Pack",
        "Map ASP.NET Core lifetimes, binding, policies and persistence onto Spring equivalents",
        ["lifetime mapping", "policy mapping", "binding parity", "tracking parity"],
        ["aspnet_to_spring_mapping.json", "adapter_inventory.json", "mapping_report.md"],
        [
            "Scoped persistence context maps to an equivalent request-bound context.",
            "Authorization policies map without weakening any requirement.",
            "Minimal endpoint binding rules are reproduced exactly.",
        ],
        [
            "a scoped persistence context promoted to a singleton",
            "a middleware short circuit that no longer terminates the pipeline",
            "a query previously translated to the database now evaluated in memory",
        ],
    ),
    (
        "spring-aspnet-to-fastapi-mapping-pack",
        "Spring and ASP.NET to FastAPI Mapping Pack",
        "Make container, aspect and transaction behaviour explicit when moving onto a dependency-function framework",
        ["dependency graph", "explicit transaction", "auth dependency", "blocking isolation"],
        ["managed_to_fastapi_mapping.json", "dependency_plan.json", "mapping_report.md"],
        [
            "Container scopes become explicit dependencies with matching lifetimes.",
            "Transaction boundaries become explicit wrappers around the same unit of work.",
            "Processor-bound work is isolated from the event loop.",
        ],
        [
            "every service converted into a module-level singleton",
            "a transaction boundary lost during conversion",
            "a decimal quantity converted to a float",
        ],
    ),
    (
        "fastapi-django-to-managed-mapping-pack",
        "FastAPI and Django to Managed Framework Mapping Pack",
        "Freeze dynamic wiring and query laziness when moving onto a container-based managed framework",
        ["dynamic freezing", "decorator expansion", "ordering parity", "query laziness"],
        ["python_to_managed_mapping.json", "frozen_wiring.json", "mapping_report.md"],
        [
            "Decorator and dependency ordering is reproduced from observed execution.",
            "Query evaluation timing and signal firing counts are preserved.",
            "Session and cross-site protection behaviour is preserved.",
        ],
        [
            "a runtime registration that was never frozen",
            "a lazy query evaluated earlier after conversion",
            "a coercion rule that now accepts input the source rejected",
        ],
    ),
    (
        "managed-to-axum-actix-mapping-pack",
        "Managed Framework to Axum and Actix Mapping Pack",
        "Convert container, aspect and transaction behaviour into explicit state, layers and transaction objects",
        ["explicit wiring", "layer mapping", "request extension", "typed error response"],
        ["managed_to_rust_mapping.json", "layer_plan.json", "mapping_report.md"],
        [
            "Container wiring becomes explicit constructor wiring and shared state.",
            "Request scope becomes a request extension with the same lifetime.",
            "Layer ordering reproduces the source pipeline order exactly.",
        ],
        [
            "a lock held across an await point in a generated handler",
            "a request body extractor that consumes the body twice",
            "a shutdown path that does not drain in-flight requests",
        ],
    ),
    (
        "managed-to-go-mapping-pack",
        "Managed Framework to Go Mapping Pack",
        "Convert implicit container, aspect and transaction behaviour into explicit Go wiring",
        ["explicit wiring", "error branch completeness", "context propagation", "worker lifetime"],
        ["managed_to_go_mapping.json", "wiring_plan.json", "mapping_report.md"],
        [
            "Every error branch present in the source is present after conversion.",
            "Request context reaches every dependency and database call.",
            "Connection pool sizing and timeouts are explicit, not defaulted.",
        ],
        [
            "a spawned worker that outlives its request context",
            "an absent value converted into a zero value that changes a decision",
            "a transaction rollback path removed during conversion",
        ],
    ),
    (
        "managed-to-nestjs-mapping-pack",
        "Managed Framework to NestJS Mapping Pack",
        "Convert managed container and aspect behaviour into modules, providers, guards, pipes and interceptors",
        ["module wiring", "provider scope", "execution ordering", "runtime validation"],
        ["managed_to_nestjs_mapping.json", "provider_plan.json", "mapping_report.md"],
        [
            "Provider scope reproduces the source component lifetime.",
            "Guard, pipe, interceptor and filter ordering reproduces the source pipeline.",
            "Static types are backed by runtime validation at every external boundary.",
        ],
        [
            "a request-scoped provider promoted to a singleton",
            "a decimal quantity converted to a floating point number",
            "a transaction callback lost during conversion",
        ],
    ),
    (
        "nestjs-to-managed-mapping-pack",
        "NestJS to Managed Framework Mapping Pack",
        "Expand decorator metadata and dynamic modules into explicit managed framework wiring",
        ["metadata expansion", "dynamic module", "ordering parity", "async context"],
        ["nestjs_to_managed_mapping.json", "expanded_metadata.json", "mapping_report.md"],
        [
            "Decorator metadata is expanded into explicit registrations before generation.",
            "Dynamic modules and forward references are resolved to concrete wiring.",
            "Asynchronous context storage maps to an equivalent request context.",
        ],
        [
            "a dynamic module registration that was never expanded",
            "an execution order assumed from documentation rather than observed",
            "a transformation step removed so unvalidated input reaches a handler",
        ],
    ),
    (
        "go-to-axum-actix-mapping-pack",
        "Go to Axum and Actix Mapping Pack",
        "Map goroutines, channels, contexts and middleware onto tasks, channels, cancellation and layers",
        ["task mapping", "channel mapping", "cancellation mapping", "middleware mapping"],
        ["go_to_rust_mapping.json", "concurrency_plan.json", "mapping_report.md"],
        [
            "Task and channel lifetimes are bounded with no leak on any exit path.",
            "Cancellation deadlines propagate through every awaited boundary.",
            "Cross-thread bounds are proven rather than assumed.",
        ],
        [
            "a task that outlives its cancelled parent",
            "a lock held across an await point",
            "a channel close semantic that diverges from the source",
        ],
    ),
    (
        "nestjs-to-go-rust-mapping-pack",
        "NestJS to Go and Rust Mapping Pack",
        "Convert event loop, dynamic provider and validation behaviour into statically wired services",
        ["loop to task model", "provider freezing", "runtime validation", "backpressure parity"],
        ["nestjs_to_native_mapping.json", "frozen_providers.json", "mapping_report.md"],
        [
            "Observable ordering survives the event loop to task model conversion.",
            "Dynamic providers are frozen into explicit wiring before generation.",
            "Stream backpressure behaviour is preserved end to end.",
        ],
        [
            "a microtask ordering change that alters observable behaviour",
            "a wide integer or decimal narrowed during conversion",
            "an asynchronous context value lost across a boundary",
        ],
    ),
    (
        "managed-to-cplusplus-web-mapping-pack",
        "Managed Framework to CPlusPlus Web Mapping Pack",
        "Rebuild injection, routing, validation, error handling and lifecycle explicitly on a native web stack",
        ["explicit rebuild", "buffer ownership", "callback lifetime", "shutdown sequencing"],
        ["managed_to_cplusplus_mapping.json", "rebuild_plan.json", "mapping_report.md"],
        [
            "Injection, routing, validation, error pipeline and shutdown are all rebuilt explicitly.",
            "Buffer and callback lifetimes cover every asynchronous path.",
            "Address, undefined behaviour and thread sanitizers pass on the required scope.",
        ],
        [
            "a framework capability assumed present rather than rebuilt",
            "a buffer released before the asynchronous send completes",
            "a shutdown that leaves native handles open",
        ],
    ),
    (
        "cplusplus-web-to-managed-mapping-pack",
        "CPlusPlus Web to Managed Framework Mapping Pack",
        "Convert scope-bound native resource and protocol handling into explicit managed lifecycle",
        ["explicit close", "pointer ownership", "protocol reconstruction", "plugin explicitation"],
        ["cplusplus_to_managed_mapping.json", "resource_plan.json", "mapping_report.md"],
        [
            "Scope-bound release becomes explicit closing, never finalization.",
            "Custom binary protocol framing is reproduced exactly.",
            "Static initialization and plugin loading become explicit registration.",
        ],
        [
            "a native resource whose release now depends on the collector",
            "a zero-copy buffer converted into a copy that changes throughput guarantees",
            "a plugin registration that was never made explicit",
        ],
    ),
    (
        "vapor-swiftnio-cross-framework-mapping-pack",
        "Vapor and SwiftNIO Cross-Framework Mapping Pack",
        "Map Apple server framework semantics onto and off other framework families without flattening them",
        ["event loop semantics", "buffer index discipline", "isolation preservation", "reference counting"],
        ["swift_cross_framework_mapping.json", "loop_semantics_map.json", "mapping_report.md"],
        [
            "Event loop semantics are not flattened into an ordinary thread pool.",
            "Buffer reader and writer index discipline is preserved exactly.",
            "Isolation is not degraded into unsynchronized shared access.",
        ],
        [
            "an event loop model mapped onto a generic thread pool",
            "a reference-counted resource whose release depends on a collector",
            "a buffer index discipline lost during conversion",
        ],
    ),
]

SKILLS[123] = [
    (
        "unified-orm-semantic-ir",
        "Unified ORM Semantic IR",
        "Represent entity state, tracking, flush, cascade and locking uniformly across persistence stacks",
        ["entity state model", "change tracking", "flush timing", "lock semantics"],
        ["orm_semantic_ir.json", "entity_state_model.json", "orm_semantic_gaps.md"],
        [
            "Transient, managed, dirty, detached and expired states are all represented.",
            "Identity map, dirty checking, flush and cascade behaviour are recorded per stack.",
            "Optimistic and pessimistic locking behaviour is captured explicitly.",
        ],
        [
            "an implicit tracking capability lost without an explicit replacement",
            "a flush point that moved relative to the transaction boundary",
            "a cascade rule dropped during conversion",
        ],
    ),
    (
        "jpa-hibernate-persistence-pack",
        "JPA and Hibernate Persistence Pack",
        "Extract persistence context, proxy, lazy loading, cascade and flush semantics from the Java stack",
        ["persistence context", "lazy proxy", "flush mode", "version conflict"],
        ["jpa_persistence_ir.json", "lazy_boundary_map.json", "jpa_gaps.md"],
        [
            "Entity identity within a persistence context is preserved.",
            "Lazy boundaries and fetch strategies are recorded rather than assumed.",
            "Version fields and optimistic conflict behaviour are captured.",
        ],
        [
            "a lazy association converted to eager loading",
            "an orphan removal rule dropped during conversion",
            "a detached entity silently reattached by the target",
        ],
    ),
    (
        "ef-core-persistence-pack",
        "EF Core Persistence Pack",
        "Extract context scope, change tracker, navigation fixup and query translation semantics",
        ["context scope", "tracking mode", "navigation fixup", "query translation"],
        ["ef_persistence_ir.json", "translation_map.json", "ef_gaps.md"],
        [
            "Context scope and tracking mode are recorded per operation.",
            "Value converters, owned entities and concurrency tokens are captured.",
            "Queries translated to the database are distinguished from in-memory evaluation.",
        ],
        [
            "a tracking mode change so dirty checking no longer fires",
            "a query silently evaluated in memory after conversion",
            "a concurrency token dropped during conversion",
        ],
    ),
    (
        "python-orm-persistence-pack",
        "Python ORM Persistence Pack",
        "Extract session, autoflush, expiry, laziness and signal semantics from Python persistence stacks",
        ["session lifecycle", "autoflush", "expire on commit", "manager and signal"],
        ["python_persistence_ir.json", "session_lifecycle.json", "python_orm_gaps.md"],
        [
            "Session boundaries, autoflush and expiry behaviour are recorded.",
            "Custom managers, overridden save behaviour and signals are captured.",
            "Query evaluation timing is recorded rather than assumed.",
        ],
        [
            "an overridden save behaviour lost during conversion",
            "a soft delete manager omitted so deleted rows become visible",
            "a signal that fires a different number of times after conversion",
        ],
    ),
    (
        "rust-persistence-pack",
        "Rust Persistence Pack",
        "Verify transaction object lifetime, compile-time query checking and type mapping in Rust persistence",
        ["transaction lifetime", "compile-time query", "connection lifetime", "type mapping"],
        ["rust_persistence_ir.json", "transaction_lifetimes.json", "rust_persistence_gaps.md"],
        [
            "The absence of implicit tracking is compensated by an explicit unit of work.",
            "Transaction object lifetime encloses the whole unit of work.",
            "Decimal, temporal and enumeration mappings are lossless.",
        ],
        [
            "a transaction guard dropped before its work completes",
            "a connection never returned to the pool on an error path",
            "a decimal column mapped to a floating point type",
        ],
    ),
    (
        "go-persistence-pack",
        "Go Persistence Pack",
        "Verify pool, context, transaction, zero value and association semantics in Go persistence",
        ["connection pool", "context propagation", "zero value update", "association loading"],
        ["go_persistence_ir.json", "pool_configuration.json", "go_persistence_gaps.md"],
        [
            "Request context reaches every query and transaction.",
            "Zero value update semantics are explicit so unintended columns are not written.",
            "Null handling, decimal and temporal mappings are lossless.",
        ],
        [
            "a zero value written over a column the source left untouched",
            "a rollback path omitted on an error branch",
            "a connection pool exhausted because rows were never closed",
        ],
    ),
    (
        "node-orm-persistence-pack",
        "Node ORM Persistence Pack",
        "Verify transaction callbacks, absence handling, numeric fidelity and relation loading in Node persistence",
        ["transaction callback", "undefined versus null", "numeric fidelity", "relation loading"],
        ["node_persistence_ir.json", "transaction_scopes.json", "node_persistence_gaps.md"],
        [
            "Undefined and null field semantics are distinguished in every write path.",
            "Decimal and wide integer columns avoid the double precision number type.",
            "Transaction callbacks enclose the whole unit of work.",
        ],
        [
            "an undefined field silently writing null to a column",
            "a decimal column read through a floating point number",
            "a transaction callback that does not cover a nested write",
        ],
    ),
    (
        "cplusplus-persistence-pack",
        "CPlusPlus Persistence Pack",
        "Verify scope-bound transactions, statement lifetime and row buffer ownership in native persistence",
        ["scope-bound transaction", "statement lifetime", "row buffer ownership", "thread safety"],
        ["cplusplus_persistence_ir.json", "buffer_ownership.json", "cplusplus_persistence_gaps.md"],
        [
            "Transaction objects roll back deterministically on every exception path.",
            "Row string and binary buffers stay valid for their whole use.",
            "Connection objects are not shared across threads without synchronization.",
        ],
        [
            "a row buffer read after the statement was released",
            "a transaction that commits on an exception path",
            "a connection shared across threads without synchronization",
        ],
    ),
    (
        "swift-persistence-pack",
        "Swift Persistence Pack",
        "Verify model property wrappers, relations, transactions and loop bridging in Swift persistence",
        ["property wrapper model", "relation loading", "transaction closure", "loop bridging"],
        ["swift_persistence_ir.json", "relation_map.json", "swift_persistence_gaps.md"],
        [
            "Transaction closures enclose the whole unit of work.",
            "Decimal, temporal and enumeration mappings are lossless.",
            "Database handles remain bound to their owning event loop.",
        ],
        [
            "a soft delete filter omitted so deleted rows become visible",
            "a decimal column mapped to a binary floating point type",
            "a database handle used from the wrong event loop",
        ],
    ),
    (
        "orm-cross-mapping-verifier",
        "ORM Cross-Mapping Verifier",
        "Compare source and target persistence behaviour beyond final row contents",
        ["tracking parity", "statement parity", "lock parity", "semantic loss record"],
        ["orm_cross_mapping.json", "statement_diff.json", "orm_semantic_loss.md"],
        [
            "Statement count, ordering and lock acquisition are compared, not only final rows.",
            "Flush timing and intermediate visible state are compared.",
            "Every implicit capability lost is explicitly implemented or recorded.",
        ],
        [
            "identical final rows accepted as proof of identical behaviour",
            "an implicit relationship fixup lost with no replacement",
            "an added query pattern that multiplies statement count",
        ],
    ),
    (
        "unified-messaging-ir",
        "Unified Messaging IR",
        "Represent broker, topic, delivery, acknowledgement and ordering semantics uniformly",
        ["delivery guarantee", "ack semantics", "ordering constraint", "outbox and inbox"],
        ["messaging_ir.json", "delivery_semantics.json", "messaging_gaps.md"],
        [
            "Producer, consumer, group, partition and ordering semantics are all recorded.",
            "Acknowledgement timing relative to commit is explicit.",
            "Delivery guarantee and idempotency strategy are recorded per flow.",
        ],
        [
            "a delivery guarantee changed during conversion",
            "an acknowledgement moved relative to the transaction commit",
            "an ordering constraint dropped without an approved decision",
        ],
    ),
    (
        "framework-messaging-adapter-pack",
        "Framework Messaging Adapter Pack",
        "Verify acknowledgement mode, prefetch, concurrency, rebalance and shutdown across messaging clients",
        ["ack mode", "prefetch and concurrency", "rebalance behaviour", "consumer shutdown"],
        ["messaging_adapter_ir.json", "consumer_configuration.json", "messaging_adapter_gaps.md"],
        [
            "Automatic and manual acknowledgement modes are preserved exactly.",
            "Prefetch, consumer concurrency and partition assignment are explicit.",
            "Shutdown drains or safely abandons in-flight messages.",
        ],
        [
            "an automatic acknowledgement replacing a manual one",
            "a consumer concurrency change that breaks per-key ordering",
            "a shutdown that drops an unacknowledged message",
        ],
    ),
    (
        "transactional-messaging-verifier",
        "Transactional Messaging Verifier",
        "Verify the commit, publish, acknowledge and outbox ordering that makes messaging safe",
        ["commit before publish", "outbox visibility", "idempotent consumer", "dead letter path"],
        ["transactional_messaging.json", "ordering_evidence.json", "messaging_risk_report.md"],
        [
            "Business writes commit before the corresponding message becomes publishable.",
            "Duplicate delivery does not produce duplicate business state.",
            "Dead letter routing is reachable and observable.",
        ],
        [
            "a message published before its transaction commits",
            "an acknowledgement issued before processing completes",
            "a retry that regenerates the idempotency key",
        ],
    ),
    (
        "background-job-mapping-pack",
        "Background Job Mapping Pack",
        "Verify scheduling, locking, retry, cancellation and recovery semantics of background work",
        ["single execution", "distributed lock", "retry and timeout", "job context"],
        ["background_job_ir.json", "scheduling_map.json", "background_job_gaps.md"],
        [
            "Single-instance jobs are prevented from running concurrently across replicas.",
            "Retry, timeout, cancellation and checkpoint behaviour are preserved.",
            "Job context carries tenancy without inheriting user authority.",
        ],
        [
            "a scheduled job executing twice across replicas",
            "a background job inheriting an end-user authority",
            "a job that cannot resume after a mid-run restart",
        ],
    ),
    (
        "authentication-semantic-ir",
        "Authentication Semantic IR",
        "Represent credential source, verification, expiry, rotation and failure response uniformly",
        ["credential source", "token verification", "key rotation", "failure response"],
        ["authentication_ir.json", "verification_rules.json", "authentication_gaps.md"],
        [
            "Issuer, audience, algorithm, clock skew and expiry rules are all recorded.",
            "Key rotation and revocation behaviour are explicit.",
            "Cookie attributes and failure responses are captured verbatim.",
        ],
        [
            "an audience or issuer check dropped during conversion",
            "a clock skew tolerance widened without approval",
            "a secure cookie attribute removed during conversion",
        ],
    ),
    (
        "authorization-semantic-ir",
        "Authorization Semantic IR",
        "Represent role, permission, policy, tenancy and resource ownership decisions uniformly",
        ["policy model", "tenancy scope", "resource ownership", "default deny"],
        ["authorization_ir.json", "policy_matrix.json", "authorization_gaps.md"],
        [
            "Reducing a permission never increases an observable capability.",
            "An unauthorized request produces no persistent or external effect.",
            "Cross-tenant access counts are zero under every tested scenario.",
        ],
        [
            "a target default that permits where the source denied",
            "an unauthorized request that still wrote state",
            "a tenancy filter removed from a query path",
        ],
    ),
]

SKILLS[124] = [
    (
        "spring-security-mapping-pack",
        "Spring Security Mapping Pack",
        "Extract and map filter chain, method security, session and token behaviour from the Spring security stack",
        ["filter chain order", "method security", "session policy", "entry point handling"],
        ["spring_security_ir.json", "filter_chain_order.json", "spring_security_gaps.md"],
        [
            "Security filters are verified to run before the handlers they protect.",
            "Method-level security is verified to take effect through the proxy path.",
            "Cross-site protection, origin policy and session policy are preserved.",
        ],
        [
            "a security filter reordered after business handling",
            "a method-level security annotation that no longer takes effect",
            "a security context leaking between requests",
        ],
    ),
    (
        "aspnet-security-mapping-pack",
        "ASP.NET Security Mapping Pack",
        "Extract and map scheme selection, policy requirements, claim transformation and cookie behaviour",
        ["scheme selection", "policy requirement", "claim transformation", "resource authorization"],
        ["aspnet_security_ir.json", "policy_map.json", "aspnet_security_gaps.md"],
        [
            "Default and per-endpoint scheme selection is preserved exactly.",
            "Every policy requirement survives conversion without weakening.",
            "Authorization middleware position relative to routing is preserved.",
        ],
        [
            "an authorization middleware omitted from the pipeline",
            "an audience validation switched off during conversion",
            "a cookie security attribute removed during conversion",
        ],
    ),
    (
        "python-framework-security-pack",
        "Python Framework Security Pack",
        "Recover dependency-based and backend-based security wiring into explicit target enforcement",
        ["dependency auth", "authentication backend", "session and csrf", "host validation"],
        ["python_security_ir.json", "auth_wiring.json", "python_security_gaps.md"],
        [
            "Dependency and decorator based authentication is recovered explicitly.",
            "Backend ordering, session and cross-site protection are preserved.",
            "Permission and group checks survive conversion without weakening.",
        ],
        [
            "an authentication dependency that was never made explicit",
            "a cross-site protection step lost during conversion",
            "a host validation rule relaxed during conversion",
        ],
    ),
    (
        "cross-language-security-pack",
        "Cross-Language Security Pack",
        "Verify authentication and authorization placement and behaviour on native and Apple target stacks",
        ["enforcement placement", "token verification", "tenancy filter", "transport security"],
        ["cross_language_security_ir.json", "enforcement_placement.json", "security_gaps.md"],
        [
            "Enforcement runs before business handling on every route.",
            "Key rotation, expiry and audience checks are all active.",
            "Transport security verification is never disabled to make a test pass.",
        ],
        [
            "an authorization layer placed after the handler it protects",
            "a wildcard origin policy introduced during conversion",
            "a certificate verification step disabled in generated code",
        ],
    ),
    (
        "security-differential-harness",
        "Security Differential Harness",
        "Compare every observable channel between source and target for each security scenario",
        ["scenario matrix", "channel comparison", "effect verification", "audit parity"],
        ["security_differential.json", "scenario_matrix.json", "security_findings.md"],
        [
            "Status, body, headers, logs, audit records and database changes are all compared.",
            "Unauthenticated, expired, wrong issuer, wrong audience and revoked cases are covered.",
            "Cross-tenant and wrong-owner scenarios produce no persistent effect.",
        ],
        [
            "a denied request that still produced a side effect",
            "a permission revocation that takes effect later than in the source",
            "an audit record missing for a denied request",
        ],
    ),
    (
        "startup-order-verifier",
        "Startup Order Verifier",
        "Verify that dependencies become available before the service reports itself ready",
        ["startup ordering", "migration gating", "readiness accuracy", "warmup"],
        ["startup_order.json", "readiness_evidence.json", "startup_gaps.md"],
        [
            "Configuration, migrations and pools initialize before listeners accept traffic.",
            "Readiness reports false until every critical dependency is available.",
            "Consumers and scheduled jobs do not start before their dependencies exist.",
        ],
        [
            "a readiness signal raised before a critical dependency is available",
            "a message consumer started before migrations completed",
            "a listener accepting traffic before key material is loaded",
        ],
    ),
    (
        "graceful-shutdown-verifier",
        "Graceful Shutdown Verifier",
        "Verify that shutdown drains traffic, work, messages and resources in the declared order",
        ["drain ordering", "in-flight completion", "message safety", "flush guarantees"],
        ["shutdown_sequence.json", "drain_evidence.json", "shutdown_gaps.md"],
        [
            "Readiness turns false before in-flight requests are drained.",
            "In-flight messages are completed or safely abandoned without loss.",
            "Outbox, logs and traces are flushed before the process exits.",
        ],
        [
            "an unacknowledged message dropped during shutdown",
            "a shutdown that exits before in-flight transactions finish",
            "a native handle or connection left open after shutdown",
        ],
    ),
    (
        "request-scope-leak-detector",
        "Request Scope Leak Detector",
        "Detect request-scoped objects captured by longer-lived owners",
        ["scope capture", "context escape", "session escape", "writer escape"],
        ["scope_leak_findings.json", "capture_graph.json", "leak_report.md"],
        [
            "Request, user context and persistence session capture by singletons is detected.",
            "Response writers and request objects are verified not to escape the request.",
            "Transactions are verified not to span requests.",
        ],
        [
            "a request object retained by a process-lifetime component",
            "a persistence session reused across requests",
            "a user context promoted into global state",
        ],
    ),
    (
        "framework-resource-leak-detector",
        "Framework Resource Leak Detector",
        "Detect connections, tasks, subscriptions, observers and native handles that are never released",
        ["connection leak", "task leak", "subscription leak", "native handle leak"],
        ["resource_leak_findings.json", "resource_inventory.json", "leak_report.md"],
        [
            "Database, HTTP and broker connections return to their pools on every path.",
            "Tasks, workers, listeners and observers are released on teardown.",
            "Native buffers, event loops and file handles are released deterministically.",
        ],
        [
            "a connection never returned to the pool on an error path",
            "an observer or subscription never removed",
            "a task or worker that outlives its owning scope",
        ],
    ),
    (
        "framework-contract-test-generator",
        "Framework Contract Test Generator",
        "Generate framework-level contract tests that run against both systems and diff the results",
        ["route contract", "binding contract", "error contract", "lifecycle contract"],
        ["framework_contract_suite.json", "contract_coverage.json", "generation_report.md"],
        [
            "Route, binding, validation, error, serialization and auth contracts are all generated.",
            "Every generated test executes against both systems under the same environment.",
            "Results are normalized before comparison without hiding real differences.",
        ],
        [
            "a generated test that runs against only one system",
            "a contract dimension with no generated coverage",
            "a normalization rule that hides a status code difference",
        ],
    ),
    (
        "middleware-ordering-test-generator",
        "Middleware Ordering Test Generator",
        "Generate minimal observable components that reveal the true pipeline order on both systems",
        ["observable probe", "event sequence", "short circuit detection", "transaction phase"],
        ["ordering_test_suite.json", "event_sequences.json", "ordering_findings.md"],
        [
            "Each probe records entry, exit, error, status, context and transaction phase.",
            "Event sequences are compared, not registration configuration.",
            "Short-circuit and repeated execution are both detected.",
        ],
        [
            "an ordering claim based on configuration rather than execution",
            "a component that executes twice without detection",
            "a short circuit that no longer terminates the pipeline",
        ],
    ),
    (
        "di-scope-stress-test",
        "DI Scope Stress Test",
        "Stress component scope under concurrency, cancellation, restart and multi-tenant load",
        ["instance counting", "shared state detection", "context contamination", "destruction verification"],
        ["scope_stress_suite.json", "instance_counts.json", "scope_findings.md"],
        [
            "Instance counts per scope are measured under concurrent load.",
            "Context contamination between concurrent tenants is zero.",
            "Components are verified to be destroyed at their declared phase.",
        ],
        [
            "a request-scoped component shared between concurrent requests",
            "a tenant context observed inside another tenant request",
            "a component that is never destroyed under sustained load",
        ],
    ),
    (
        "orm-behavior-test-generator",
        "ORM Behavior Test Generator",
        "Generate persistence behaviour tests covering tracking, laziness, conflict and rollback paths",
        ["tracking scenario", "conflict scenario", "rollback scenario", "statement counting"],
        ["orm_test_suite.json", "scenario_matrix.json", "orm_test_report.md"],
        [
            "Repeated query identity, detach and reattach, and lazy loading are covered.",
            "Concurrent update, version conflict and rollback paths are covered.",
            "Statement counts are asserted so query multiplication is detected.",
        ],
        [
            "a suite that asserts only final row contents",
            "a version conflict path with no generated test",
            "a query multiplication regression that no test detects",
        ],
    ),
    (
        "messaging-behavior-test-generator",
        "Messaging Behavior Test Generator",
        "Generate messaging tests covering duplication, reordering, failure, rebalance and recovery",
        ["duplicate delivery", "reordering", "failure path", "recovery path"],
        ["messaging_test_suite.json", "scenario_matrix.json", "messaging_test_report.md"],
        [
            "Duplicate, out-of-order and failed delivery scenarios are all generated.",
            "Acknowledgement failure, crash and rebalance scenarios are covered.",
            "Outbox recovery and dead letter routing are exercised.",
        ],
        [
            "a duplicate delivery scenario absent from the suite",
            "a crash-during-processing scenario with no generated test",
            "an outbox recovery path that no test exercises",
        ],
    ),
    (
        "security-mutation-pack",
        "Security Mutation Pack",
        "Prove the suite detects removal or weakening of any authentication or authorization control",
        ["control removal", "claim weakening", "transport weakening", "audit removal"],
        ["security_mutations.json", "security_survivors.json", "security_mutation_report.md"],
        [
            "Authentication, authorization, tenancy and audit removal mutants are all exercised.",
            "Token algorithm, issuer, audience and expiry mutants are included.",
            "The surviving critical security mutant count is zero.",
        ],
        [
            "an authorization check removal that no test detects",
            "an expiry validation removal that survives undetected",
            "an audit log removal that no test catches",
        ],
    ),
    (
        "framework-lifecycle-mutation-pack",
        "Framework Lifecycle Mutation Pack",
        "Prove the suite detects scope, ordering, readiness and cleanup regressions",
        ["scope mutation", "ordering mutation", "readiness mutation", "cleanup mutation"],
        ["lifecycle_mutations.json", "lifecycle_survivors.json", "lifecycle_mutation_report.md"],
        [
            "Scope swap, ordering change and readiness advancement mutants are exercised.",
            "Request cleanup, context propagation and resource close removal are exercised.",
            "No lifecycle mutant affecting tenancy or transactions survives.",
        ],
        [
            "a middleware reordering that no test detects",
            "a premature readiness signal that survives undetected",
            "a duplicated background job registration that no test catches",
        ],
    ),
]

SKILLS[125] = [
    (
        "framework-performance-differential-pack",
        "Framework Performance Differential Pack",
        "Compare framework-level latency, throughput and resource behaviour under real configuration",
        ["stage attribution", "real configuration", "pool parity", "loop and allocator behaviour"],
        ["framework_performance.json", "stage_attribution.json", "performance_findings.md"],
        [
            "Routing, binding, validation, serialization, injection and persistence cost are attributed separately.",
            "Both systems run with real pools, real transport security and real serialization settings.",
            "Startup and shutdown duration are measured, not only steady-state latency.",
        ],
        [
            "a comparison run with target defaults instead of source-equivalent settings",
            "a throughput gain produced by a smaller connection pool",
            "a latency figure measured without real transport security",
        ],
    ),
    (
        "framework-e2-gate",
        "Framework E2 Gate",
        "Gate the framework migration on complete route, contract and error surface parity",
        ["route parity", "contract parity", "error contract", "test migration"],
        ["framework_e2_gate.json", "parity_results.json", "e2_gate_report.md"],
        [
            "Every source route exists with an identical externally visible contract.",
            "Validation and error contracts match, including codes and field paths.",
            "Original framework tests are migrated without weakened assertions.",
        ],
        [
            "a route missing from the target surface",
            "an error contract that returns a different status for the same input",
            "a migrated test whose assertion was relaxed",
        ],
    ),
    (
        "framework-e3-gate",
        "Framework E3 Gate",
        "Gate the framework migration on pipeline, scope, persistence, messaging and security differential evidence",
        ["pipeline differential", "scope evidence", "persistence differential", "security differential"],
        ["framework_e3_gate.json", "differential_results.json", "e3_gate_report.md"],
        [
            "Pipeline ordering, scope, persistence and messaging differentials all pass.",
            "Framework-specific mutation packs meet their thresholds with no critical survivor.",
            "The unexplained framework difference count is zero.",
        ],
        [
            "a pipeline ordering difference left unexplained",
            "a persistence behaviour difference accepted without a decision record",
            "a security differential scenario that was never executed",
        ],
    ),
    (
        "framework-e4-gate",
        "Framework E4 Gate",
        "Gate the framework migration on concurrency, fault, resource, platform and performance evidence",
        ["concurrency evidence", "fault evidence", "resource evidence", "performance threshold"],
        ["framework_e4_gate.json", "engineering_results.json", "e4_gate_report.md"],
        [
            "Concurrency, fault injection and resource leak checks all pass.",
            "Real database, real broker and target platform runs are included.",
            "Graceful shutdown, security testing and performance thresholds all pass.",
        ],
        [
            "a performance threshold met only against a mocked dependency",
            "a resource leak accepted without a measured bound",
            "a native sanitizer finding left unresolved",
        ],
    ),
    (
        "framework-e5-gate",
        "Framework E5 Gate",
        "Gate the framework migration on production shadow coverage, reconciliation and rollback evidence",
        ["shadow coverage", "critical scenario coverage", "reconciliation", "rollback evidence"],
        ["framework_e5_gate.json", "production_results.json", "e5_gate_report.md"],
        [
            "Critical routes, permission, transaction and messaging scenarios are fully covered.",
            "Data reconciliation and automatic rollback evidence are both present.",
            "The unsupported framework feature count is zero.",
        ],
        [
            "an E5 claim while a critical permission scenario is uncovered",
            "an E5 claim with an unresolved reconciliation mismatch",
            "an E5 claim while an unsupported framework feature remains open",
        ],
    ),
    (
        "framework-mapping-orchestrator",
        "Framework Mapping Orchestrator",
        "Sequence the framework migration from inventory through representation, mapping, generation and certification",
        ["phase sequencing", "reconstruction gating", "gate sequencing", "blocking condition"],
        ["framework_state_machine.json", "phase_transitions.json", "orchestration_runbook.md"],
        [
            "Every source framework layer is represented before a target framework is selected.",
            "Target framework representation is reconstructed before any equivalence claim.",
            "Security, tenancy, transaction and messaging differences block certification.",
        ],
        [
            "a target framework selected before the source pipeline was reconstructed",
            "an equivalence claim made before target reconstruction",
            "a certification issued while a tenancy difference remains open",
        ],
    ),
]


# =============================================================================
# Segment 1 — Skill 327-432 : dependency semantics, standard library capability
# ontology, replacement certification, native/ABI, licence governance and
# supply-chain security.
# =============================================================================

BATCHES[125] = {
    "title": "Framework Certification Gates and Dependency Discovery Pack",
    "why": "Closes the framework layer with measured performance and staged gates, then opens the dependency layer by discovering what the repository actually depends on and actually uses.",
    "purpose": "compare framework performance under real configuration, operate the FW-E2 through FW-E5 gates and their orchestrator, then inventory every direct, transitive, build-time and runtime dependency together with the exact API surface and capabilities the repository really consumes.",
    "tooling": ["framework performance harness", "framework certification gates", "dependency inventory scanner", "dependency knowledge graph"],
}

BATCHES.update({
    126: {
        "title": "Dependency Closure and Ecosystem Pack",
        "why": "Moves ELMOS from a declared manifest to a reproducible, conflict-free closure across nine packaging ecosystems.",
        "purpose": "build the transitive closure, resolve version and implementation conflicts, trace generated code provenance, score migration risk, and govern each of the nine packaging ecosystems with its own lockfile integrity and hermetic cache rules.",
        "tooling": ["transitive closure builder", "ecosystem package adapters", "lockfile integrity verifier", "hermetic dependency cache"],
    },
    127: {
        "title": "Standard Library Capability and Candidate Discovery Pack",
        "why": "Moves ELMOS from mapping standard library function names to mapping capabilities with their real runtime semantics.",
        "purpose": "classify standard library capabilities into one ontology, verify collection, string, filesystem, network, concurrency, temporal, numeric, serialization, regex, cryptographic, process, compression and telemetry semantics across languages, then discover and score candidate replacements without implying equivalence.",
        "tooling": ["capability ontology", "standard library mappers", "candidate discovery index", "similarity scorer"],
    },
    128: {
        "title": "Replacement Compatibility and Native Boundary Pack",
        "why": "Moves ELMOS from library substitution to proven API, behavioural, format, concurrency and operational compatibility across a native boundary.",
        "purpose": "verify that a candidate replacement matches the source library in interface, behaviour, data format, concurrency model and operational model, generate the isolating adapter, decide between substitution, wrapping, porting and rewriting, and pin every native and cross-compilation contract.",
        "tooling": ["replacement compatibility verifiers", "dependency adapter generator", "FFI ownership contract builder", "ABI inspection adapter"],
    },
    129: {
        "title": "Native Platform and Licence Governance Pack",
        "why": "Moves ELMOS from ignoring system libraries and licences to treating both as release-blocking production inputs.",
        "purpose": "govern system libraries, platform frameworks, accelerators, cryptographic providers, database drivers and container runtimes, sandbox untrusted native code, and operate licence discovery, compatibility, copyleft propagation, attribution, restriction, patent and change monitoring up to a fail-closed licence gate.",
        "tooling": ["system library mapper", "native sandbox runner", "licence discovery scanner", "licence compatibility graph"],
    },
    130: {
        "title": "Supply Chain Security Pack",
        "why": "Moves ELMOS from absence of known vulnerabilities to positive supply-chain evidence: provenance, signatures, reproducibility and isolation.",
        "purpose": "produce the software bill of materials and build provenance, verify signatures and checksums, detect typosquatting, dependency confusion, publisher change and malicious install scripts, enforce build isolation and hermetic reproducible builds, and operate a fail-closed dependency security gate with incident response.",
        "tooling": ["SBOM generator", "provenance recorder", "build isolation enforcer", "reproducible build verifier"],
    },
    131: {
        "title": "Replacement Certification Pack",
        "why": "Moves ELMOS from trusting a replacement library because the whole repository migration passed to certifying each critical replacement independently.",
        "purpose": "operate the DR0 through DR5 replacement certification ladder with its own contract, differential, property, fuzz, mutation, sandbox, performance, chaos and shadow evidence, its own vault, revocation monitor and multi-role approval, and register the cross-language capability families that candidates are drawn from.",
        "tooling": ["replacement differential harness", "replacement mutation library", "replacement security sandbox", "DR certification pipeline"],
    },
})

SKILLS[125] = list(SKILLS[125]) + [
    (
        "dependency-inventory-builder",
        "Dependency Inventory Builder",
        "Discover every direct, transitive, build-time and runtime dependency the repository resolves",
        ["transitive discovery", "build plugin", "runtime plugin", "system package"],
        ["dependency_inventory.json", "discovery_sources.json", "inventory_gaps.md"],
        [
            "Package manifests, lockfiles, imports, linker arguments and runtime load records are all consulted.",
            "Native libraries, code generators, container base images and operating system packages are enumerated.",
            "The unresolved dependency count is zero before the closure is built.",
        ],
        [
            "a production runtime dependency absent from the inventory",
            "a binary artifact whose origin cannot be established",
            "a dependency version that drifts at runtime",
        ],
    ),
    (
        "unified-dependency-knowledge-graph",
        "Unified Dependency Knowledge Graph",
        "Store packages, modules, symbols, capabilities, versions and platform requirements in one graph",
        ["capability subgraph", "replacement relation", "platform relation", "vulnerability relation"],
        ["dependency_graph.json", "capability_edges.json", "graph_notes.md"],
        [
            "Comparison is made on capability subgraphs rather than on package names.",
            "Native library, licence, vulnerability and platform edges are all modelled.",
            "Replacement and partial-replacement relations are distinguished explicitly.",
        ],
        [
            "two packages treated as equivalent because their names match",
            "a capability edge asserted without a verified implementation",
            "a platform requirement missing from a native package node",
        ],
    ),
    (
        "dependency-reachability-analyzer",
        "Dependency Reachability Analyzer",
        "Separate an installed package from the subset of its capabilities the business actually reaches",
        ["symbol reachability", "reflection reachability", "test-only usage", "build-only usage"],
        ["reachability_report.json", "used_subset.json", "reachability_notes.md"],
        [
            "Runtime, build-time, test-only and platform-only usage are counted separately.",
            "Reflectively reached symbols and registered serialization types are included.",
            "The used subset is complete even though it is smaller than the package surface.",
        ],
        [
            "a reflectively reached symbol omitted from the used subset",
            "a plugin loaded only in production counted as unused",
            "a package declared removable while a runtime path still reaches it",
        ],
    ),
    (
        "dependency-api-surface-extractor",
        "Dependency API Surface Extractor",
        "Extract the exact external interface the source system consumes from each dependency",
        ["symbol extraction", "configuration key", "generated code", "annotation surface"],
        ["used_api_surface.json", "surface_evidence.json", "surface_gaps.md"],
        [
            "Types, callables, generics, annotations, callbacks and events are all captured.",
            "Configuration keys and environment variables consumed by the dependency are captured.",
            "Generated code and serialization annotations are attributed to their generator.",
        ],
        [
            "a consumed configuration key missing from the surface",
            "a callback contract omitted from the extraction",
            "a generated symbol attributed to hand-written code",
        ],
    ),
    (
        "dependency-behavioral-capability-model",
        "Dependency Behavioral Capability Model",
        "Describe what a dependency actually does at runtime rather than only its function signatures",
        ["async model", "resource ownership", "default configuration", "platform limit"],
        ["capability_model.json", "behavioural_attributes.json", "capability_notes.md"],
        [
            "Blocking, laziness, caching, retry, timeout and cancellation behaviour are recorded.",
            "Resource ownership, initialization timing and shutdown behaviour are explicit.",
            "Default configuration values that affect business behaviour are captured verbatim.",
        ],
        [
            "an asynchronous claim asserted without observed behaviour",
            "a default retry or timeout value left undocumented",
            "a single-use response stream modelled as re-readable",
        ],
    ),
    (
        "dependency-version-constraint-ir",
        "Dependency Version Constraint IR",
        "Unify version constraint semantics across nine packaging ecosystems",
        ["constraint form", "resolved version", "transitive conflict", "environment divergence"],
        ["version_constraint_ir.json", "resolution_comparison.json", "constraint_risks.md"],
        [
            "Declared, locked and actually resolved versions are recorded separately.",
            "Transitive conflicts and dependency overrides are surfaced explicitly.",
            "Resolution differences between environments are reported rather than averaged.",
        ],
        [
            "a floating or prerelease constraint on a critical dependency",
            "a resolved version that differs between developer and CI environments",
            "a binary downloaded at build time without a pinned version",
        ],
    ),
    (
        "build-toolchain-dependency-ir",
        "Build Toolchain Dependency IR",
        "Record the behaviour the build toolchain itself introduces into the artifact",
        ["compiler and linker", "code generator", "build script", "host sensitivity"],
        ["toolchain_ir.json", "generator_inventory.json", "toolchain_risks.md"],
        [
            "Compilers, linkers, plugins, generators and build scripts are all pinned by version.",
            "Build steps that access the network or read secrets are identified.",
            "Build output that varies with the host environment is reported as non-hermetic.",
        ],
        [
            "a build script that downloads an unpinned binary",
            "generated code that differs with the host environment",
            "a build step that reads a production secret",
        ],
    ),
    (
        "runtime-dynamic-dependency-loader",
        "Runtime Dynamic Dependency Loader",
        "Capture the dependencies that only appear when the system is running",
        ["dynamic load site", "conditional load", "trace evidence", "plugin discovery"],
        ["runtime_dependency_log.json", "load_site_index.json", "dynamic_gaps.md"],
        [
            "Every dynamic load site records the condition under which it fires.",
            "Evidence comes from production or production-representative traces.",
            "Load sites with no observed resolution are reported, never assumed unused.",
        ],
        [
            "a plugin loaded only for one payment method and never traced",
            "a dynamically loaded module absent from the inventory",
            "a load site declared unused on the strength of test traces alone",
        ],
    ),
    (
        "dependency-configuration-contract-builder",
        "Dependency Configuration Contract Builder",
        "Record the configuration, defaults and environment each dependency requires",
        ["required key", "default value", "secret field", "unknown key policy"],
        ["configuration_contract.json", "default_comparison.json", "configuration_risks.md"],
        [
            "Required, optional, default and secret configuration keys are all distinguished.",
            "Target library defaults are compared against source library defaults field by field.",
            "Unknown configuration handling matches the source behaviour.",
        ],
        [
            "a target default that silently changes business behaviour",
            "a secret configuration value written into logs",
            "an unknown configuration key ignored where the source rejected it",
        ],
    ),
    (
        "dependency-feature-flag-analyzer",
        "Dependency Feature Flag Analyzer",
        "Resolve the optional features actually enabled inside packages and at the package manager layer",
        ["enabled feature", "default feature", "mutually exclusive feature", "provider selection"],
        ["feature_resolution.json", "feature_matrix.json", "feature_risks.md"],
        [
            "Enabled, default and platform-conditional features are resolved to a concrete set.",
            "Mutually exclusive and security-relevant features are identified.",
            "Transport security and serialization provider selection is explicit.",
        ],
        [
            "a feature unified across a workspace so it becomes unexpectedly enabled",
            "a default feature that pulls in an unwanted native dependency",
            "a transport security provider selected implicitly",
        ],
    ),
]

SKILLS[126] = [
    (
        "transitive-dependency-closure-builder",
        "Transitive Dependency Closure Builder",
        "Build the complete transitive closure including duplicates, shading and linkage decisions",
        ["duplicate version", "shading", "vendoring", "linkage decision"],
        ["dependency_closure.json", "duplicate_report.json", "closure_notes.md"],
        [
            "Multiple coexisting versions, hoisting and vendoring are all represented.",
            "Static and dynamic linkage decisions are recorded per native dependency.",
            "Optional and peer dependency resolution outcomes are explicit.",
        ],
        [
            "a shaded dependency whose vulnerabilities cannot be matched",
            "a duplicated version silently resolved at load order",
            "an optional native package missing on a target platform",
        ],
    ),
    (
        "dependency-conflict-resolver",
        "Dependency Conflict Resolver",
        "Identify version and implementation conflicts in the source and target ecosystems",
        ["version conflict", "ABI conflict", "provider conflict", "symbol conflict"],
        ["conflict_report.json", "resolution_plan.json", "conflict_risks.md"],
        [
            "Version, binary interface, runtime and provider conflicts are classified separately.",
            "Global allocator, logging and transport security provider conflicts are detected.",
            "Native symbol and runtime category conflicts are reported with their sites.",
        ],
        [
            "two transport security implementations linked into one artifact",
            "a native symbol collision resolved by link order",
            "a logging provider conflict that silently drops records",
        ],
    ),
    (
        "generated-code-provenance-tracker",
        "Generated Code Provenance Tracker",
        "Trace every generated artifact to its generator, inputs and parameters",
        ["generator version", "input schema", "output digest", "regeneration"],
        ["generated_provenance.json", "regeneration_report.json", "provenance_gaps.md"],
        [
            "Generator version, input schema, parameters and output digest are all recorded.",
            "Hand modification of generated output is detected and reported.",
            "Regeneration from recorded inputs reproduces the same output.",
        ],
        [
            "generated code that cannot be reproduced from its recorded inputs",
            "a hand-edited generated file presented as generated",
            "a generator version absent from the provenance record",
        ],
    ),
    (
        "dependency-migration-risk-scorer",
        "Dependency Migration Risk Scorer",
        "Score each dependency for migration risk from its measured usage and constraints",
        ["usage scale", "native constraint", "maintenance state", "replacement maturity"],
        ["dependency_risk.json", "risk_drivers.json", "risk_notes.md"],
        [
            "Scores are computed from the measured used subset, not from package size.",
            "Native-only, licence-unknown and unmaintained states raise the score explicitly.",
            "Each driver names the code sites or records that produced it.",
        ],
        [
            "a critical driver omitted because it was hard to measure",
            "a risk score computed without inspecting actual usage",
            "a score used to justify skipping replacement certification",
        ],
    ),
    (
        "java-package-ecosystem-pack",
        "Java Package Ecosystem Pack",
        "Govern Maven and Gradle resolution, scopes, plugins and packaging decisions",
        ["dependency management", "scope and exclusion", "shaded artifact", "resolution divergence"],
        ["java_ecosystem_report.json", "resolution_comparison.json", "java_ecosystem_risks.md"],
        [
            "Managed versions, scopes, exclusions and platform constraints are resolved concretely.",
            "Annotation processors and build plugins are pinned and reproducible.",
            "Class path and module path ordering effects are recorded.",
        ],
        [
            "a compile-only dependency missing at runtime",
            "a test dependency reaching the production artifact",
            "a shaded dependency that hides a vulnerable version",
        ],
    ),
    (
        "python-package-ecosystem-pack",
        "Python Package Ecosystem Pack",
        "Govern Python resolution across wheels, source builds, markers and native extensions",
        ["platform and ABI tag", "build isolation", "index origin", "native wheel"],
        ["python_ecosystem_report.json", "wheel_matrix.json", "python_ecosystem_risks.md"],
        [
            "Interpreter version, platform tag and binary interface tag are all pinned.",
            "Index origin and artifact hashes are verified for every resolved package.",
            "Source builds are reproducible or explicitly declared non-hermetic.",
        ],
        [
            "a source build whose output differs between machines",
            "an install hook that executes arbitrary code",
            "a private package shadowed by a public one",
        ],
    ),
    (
        "dotnet-package-ecosystem-pack",
        "DotNet Package Ecosystem Pack",
        "Govern package resolution, target frameworks, runtime identifiers and generators",
        ["target framework", "runtime identifier", "source generator", "native asset"],
        ["dotnet_ecosystem_report.json", "asset_selection.json", "dotnet_ecosystem_risks.md"],
        [
            "Target framework and runtime identifier selection are recorded per asset.",
            "Analyzers and source generators are pinned and verified to run.",
            "Native assets are present for every declared target platform.",
        ],
        [
            "a different assembly selected because the target framework changed",
            "a native library omitted for one runtime identifier",
            "a source generator that silently did not run",
        ],
    ),
    (
        "cargo-package-ecosystem-pack",
        "Cargo Package Ecosystem Pack",
        "Govern crate resolution, feature unification, build scripts and macro expansion",
        ["feature unification", "build script", "procedural macro", "pinned revision"],
        ["cargo_ecosystem_report.json", "feature_resolution.json", "cargo_ecosystem_risks.md"],
        [
            "Feature unification results are computed, not assumed from the manifest.",
            "Build scripts and procedural macros are inventoried with what they execute.",
            "Repository dependencies are pinned to an exact revision.",
        ],
        [
            "feature unification enabling a feature no crate asked for",
            "a build script invoking an external command at build time",
            "a repository dependency without a pinned revision",
        ],
    ),
    (
        "go-module-ecosystem-pack",
        "Go Module Ecosystem Pack",
        "Govern module resolution, replacement directives, vendoring and native interoperation",
        ["minimal version selection", "replace directive", "vendor divergence", "build tag"],
        ["go_ecosystem_report.json", "resolution_comparison.json", "go_ecosystem_risks.md"],
        [
            "Resolved versions, replacements, exclusions and retractions are recorded.",
            "Vendored and module-resolved builds are compared for divergence.",
            "Build tags that change the dependency graph are enumerated.",
        ],
        [
            "a replacement directive that exists only on a developer machine",
            "a vendored tree that resolves differently from the module graph",
            "a native system library missing from the build environment",
        ],
    ),
    (
        "node-package-ecosystem-pack",
        "Node Package Ecosystem Pack",
        "Govern Node resolution across hoisting, peer dependencies, module formats and install scripts",
        ["hoisting divergence", "peer resolution", "module format", "install script"],
        ["node_ecosystem_report.json", "resolution_comparison.json", "node_ecosystem_risks.md"],
        [
            "Hoisting and peer resolution outcomes are compared across package managers.",
            "Module format and conditional export resolution are recorded per entry point.",
            "Install scripts are inventoried with what they execute.",
        ],
        [
            "a lockfile rewritten by a different package manager",
            "an install script that downloads and executes code",
            "a type package whose version diverges from its runtime package",
        ],
    ),
    (
        "cplusplus-dependency-ecosystem-pack",
        "CPlusPlus Dependency Ecosystem Pack",
        "Govern native dependency resolution, binary interface consistency and link decisions",
        ["standard library choice", "build type consistency", "link order", "system package"],
        ["cplusplus_ecosystem_report.json", "abi_matrix.json", "cplusplus_ecosystem_risks.md"],
        [
            "Compiler, standard library, build type and compile flags are consistent across the closure.",
            "Static and dynamic linkage of the same library is detected and resolved.",
            "System package versions are pinned or declared non-reproducible.",
        ],
        [
            "debug and release objects with incompatible binary interfaces linked together",
            "two standard library implementations in one artifact",
            "a source fetch pointing at an unpinned branch",
        ],
    ),
    (
        "objectivec-dependency-ecosystem-pack",
        "ObjectiveC Dependency Ecosystem Pack",
        "Govern Apple dependency resolution, framework embedding and category linkage",
        ["deployment target", "framework embedding", "category linkage", "binary framework"],
        ["objectivec_ecosystem_report.json", "framework_matrix.json", "objectivec_ecosystem_risks.md"],
        [
            "Deployment target, architecture set and module map are verified per dependency.",
            "Category linkage flags are present so category methods are not stripped.",
            "Frameworks required at runtime are actually embedded and signed.",
        ],
        [
            "a category silently not linked so its methods disappear",
            "a framework required at runtime but never embedded",
            "a binary framework whose contents cannot be audited",
        ],
    ),
    (
        "swift-package-ecosystem-pack",
        "Swift Package Ecosystem Pack",
        "Govern Swift package resolution, plugins, macros, binary targets and module stability",
        ["binary target", "package plugin", "macro version", "module stability"],
        ["swift_ecosystem_report.json", "target_matrix.json", "swift_ecosystem_risks.md"],
        [
            "Platform, toolchain and module interface requirements are pinned per target.",
            "Package plugins and macros are inventoried with what they execute.",
            "Apple and Linux implementation differences are recorded per dependency.",
        ],
        [
            "a binary target whose source cannot be audited",
            "a macro version incompatible with the pinned toolchain",
            "a module interface that breaks across a toolchain upgrade",
        ],
    ),
    (
        "cross-language-workspace-resolver",
        "Cross-Language Workspace Resolver",
        "Resolve a repository that contains several language ecosystems at once",
        ["build ordering", "shared schema", "internal publication", "release synchronisation"],
        ["workspace_graph.json", "build_order.json", "workspace_risks.md"],
        [
            "Cross-language build ordering and shared schema generation are explicit.",
            "Internal package publication and version synchronisation are recorded.",
            "Cycles across language boundaries are detected and reported.",
        ],
        [
            "a generated schema consumed before its generator has run",
            "an internal package version that diverges between ecosystems",
            "a cross-language cycle hidden by a cached artifact",
        ],
    ),
    (
        "lockfile-integrity-verifier",
        "Lockfile Integrity Verifier",
        "Guarantee that dependency resolution is deterministic and auditable",
        ["lock presence", "manifest agreement", "hash completeness", "build immutability"],
        ["lockfile_integrity.json", "hash_verification.json", "integrity_findings.md"],
        [
            "Every lockfile is committed, agrees with its manifest and carries complete hashes.",
            "Resolution is identical across machines and continuous integration runs.",
            "Production builds never upgrade a dependency implicitly.",
        ],
        [
            "a lockfile modified during the build",
            "a critical dependency without a pinned version",
            "a production build tracking a floating branch",
        ],
    ),
    (
        "hermetic-dependency-cache-builder",
        "Hermetic Dependency Cache Builder",
        "Build an offline, repeatable dependency cache that survives upstream change",
        ["artifact mirroring", "source archive", "signature retention", "historical rebuild"],
        ["dependency_cache_manifest.json", "cache_integrity.json", "cache_notes.md"],
        [
            "Packages, source archives, native binaries, compilers and generators are all cached.",
            "Signatures, licences and checksums are retained alongside every artifact.",
            "A historical version can be rebuilt from the cache with no network access.",
        ],
        [
            "a build that still reaches the network despite a populated cache",
            "a cached artifact whose signature was not retained",
            "an upstream deletion that breaks a historical rebuild",
        ],
    ),
]

SKILLS[127] = [
    (
        "standard-library-capability-ontology",
        "Standard Library Capability Ontology",
        "Classify standard library functionality by capability instead of by function name",
        ["capability taxonomy", "cross-language class", "capability identity", "ontology versioning"],
        ["capability_ontology.json", "capability_index.json", "ontology_notes.md"],
        [
            "Every capability class has an observable, testable definition.",
            "Capabilities are identified independently of any one language spelling.",
            "The ontology is versioned so a capability meaning never changes silently.",
        ],
        [
            "two capabilities merged because their function names match",
            "a capability defined without a testable behaviour",
            "an ontology change applied without a version bump",
        ],
    ),
    (
        "collection-standard-library-mapper",
        "Collection Standard Library Mapper",
        "Verify ordering, equality, mutability, view and thread-safety semantics of mapped collections",
        ["insertion order", "key equality", "view versus copy", "iterator invalidation"],
        ["collection_capability_map.json", "collection_findings.json", "collection_notes.md"],
        [
            "Ordering, duplicate handling and null element policy are preserved per collection.",
            "View and copy semantics of shared buffers are preserved.",
            "Thread-safety and iterator invalidation guarantees are recorded, not assumed.",
        ],
        [
            "an ordered map replaced by an unordered one",
            "a shared view replaced by an independent copy",
            "a concurrent collection replaced by an unsynchronized one",
        ],
    ),
    (
        "string-and-unicode-library-mapper",
        "String and Unicode Library Mapper",
        "Verify encoding, indexing, normalization and locale behaviour across string libraries",
        ["index unit", "normalization form", "case folding", "invalid sequence"],
        ["string_capability_map.json", "encoding_findings.json", "string_notes.md"],
        [
            "Byte, code unit, code point and grapheme indexing are distinguished per operation.",
            "Normalization form, case folding and locale sensitivity are preserved.",
            "Invalid sequence handling matches the source outcome exactly.",
        ],
        [
            "a length computed in a different unit than the source used",
            "an invalid sequence replaced where the source rejected it",
            "a locale-sensitive comparison replaced by a byte comparison",
        ],
    ),
    (
        "filesystem-and-io-library-mapper",
        "Filesystem and IO Library Mapper",
        "Verify path, permission, atomicity, buffering and close semantics across filesystem libraries",
        ["path semantics", "atomic rename", "buffering", "close behaviour"],
        ["filesystem_capability_map.json", "io_findings.json", "filesystem_notes.md"],
        [
            "Case sensitivity, symbolic link and permission behaviour are recorded per platform.",
            "Atomic rename, file locking and temporary file guarantees are preserved.",
            "Buffering, flush and close behaviour on the error path is verified.",
        ],
        [
            "an atomic rename replaced by a copy and delete",
            "a buffered write that is not flushed on the error path",
            "a directory traversal that follows a symbolic link the source refused",
        ],
    ),
    (
        "network-and-tls-library-mapper",
        "Network and TLS Library Mapper",
        "Verify connection, timeout, retry, streaming and certificate validation behaviour across clients",
        ["connection pool", "certificate validation", "redirect policy", "streaming body"],
        ["network_capability_map.json", "tls_findings.json", "network_notes.md"],
        [
            "Certificate and hostname validation remain strict after the substitution.",
            "Timeout, retry, redirect, proxy and connection pool behaviour match the source.",
            "Request cancellation reaches the socket and releases the connection.",
        ],
        [
            "certificate validation disabled by a target default",
            "automatic retry introduced where the source had none",
            "a cancelled request whose connection is never released",
        ],
    ),
    (
        "concurrency-standard-library-mapper",
        "Concurrency Standard Library Mapper",
        "Verify that a concurrency primitive substitution preserves parallelism, ordering and cancellation",
        ["parallelism preservation", "scheduling fairness", "memory visibility", "cancellation semantics"],
        ["concurrency_capability_map.json", "concurrency_deltas.json", "concurrency_notes.md"],
        [
            "The mapping records whether concurrency is preserved, serialized or widened.",
            "Memory visibility and happens-before guarantees are preserved or strengthened.",
            "Cancellation semantics and thread-local behaviour are preserved.",
        ],
        [
            "a parallel operation silently serialized by the target primitive",
            "a memory visibility guarantee weakened by the substitution",
            "a cancellation signal that stops propagating at the primitive",
        ],
    ),
    (
        "date-and-time-library-mapper",
        "Date and Time Library Mapper",
        "Verify instant, local, zoned, duration and calendar semantics across temporal libraries",
        ["temporal category", "timezone database", "precision", "monotonic clock"],
        ["temporal_capability_map.json", "temporal_findings.json", "temporal_notes.md"],
        [
            "Instant, local date-time, zoned date-time, duration and calendar period stay distinct.",
            "Timezone database version, daylight rules and precision are pinned.",
            "Monotonic and wall clock uses are distinguished per call site.",
        ],
        [
            "an instant and a local date-time treated as interchangeable",
            "a sub-second precision truncated by the target library",
            "a duration compared using a wall clock across a daylight transition",
        ],
    ),
    (
        "decimal-and-numeric-library-mapper",
        "Decimal and Numeric Library Mapper",
        "Verify precision, scale, rounding and overflow behaviour of numeric substitutions",
        ["arbitrary precision", "scale and rounding", "overflow behaviour", "special value"],
        ["numeric_capability_map.json", "numeric_findings.json", "numeric_notes.md"],
        [
            "Monetary and accounting values preserve precision, scale and rounding mode.",
            "Overflow behaviour is preserved or explicitly guarded.",
            "Not-a-number, infinity and negative zero handling are preserved.",
        ],
        [
            "a monetary value routed through a binary floating point type",
            "a rounding mode changed by the target library default",
            "a silent wraparound where the source raised an error",
        ],
    ),
    (
        "serialization-library-mapper",
        "Serialization Library Mapper",
        "Verify that a serialization library substitution preserves the declared wire contract",
        ["unknown field policy", "polymorphic handling", "numeric fidelity", "version compatibility"],
        ["serialization_capability_map.json", "serialization_findings.json", "serialization_notes.md"],
        [
            "Unknown field, unknown enumeration and absence handling match the source.",
            "Polymorphic type resolution and reference preservation are preserved.",
            "Old data remains readable and new data remains readable by the old library.",
        ],
        [
            "an unknown field rejected where the source ignored it",
            "a decimal or wide integer losing fidelity through the new library",
            "a polymorphic payload resolved to a different concrete type",
        ],
    ),
    (
        "regex-and-text-processing-mapper",
        "Regex and Text Processing Mapper",
        "Verify pattern dialect, matching semantics and complexity behaviour across engines",
        ["dialect difference", "named group", "unicode class", "backtracking risk"],
        ["regex_capability_map.json", "pattern_findings.json", "regex_notes.md"],
        [
            "Every migrated pattern produces identical matches on the recorded corpus.",
            "Dialect features absent in the target engine are rewritten, not approximated.",
            "Patterns with catastrophic backtracking risk are identified and bounded.",
        ],
        [
            "a pattern whose match set changed silently after the substitution",
            "a lookbehind or named group approximated by a weaker construct",
            "an unbounded pattern that stalls on adversarial input",
        ],
    ),
    (
        "random-and-cryptographic-primitive-mapper",
        "Random and Cryptographic Primitive Mapper",
        "Verify that random and cryptographic substitutions preserve strength, format and compatibility",
        ["randomness class", "algorithm identity", "key and encoding format", "derivation parameters"],
        ["crypto_capability_map.json", "primitive_findings.json", "crypto_notes.md"],
        [
            "Cryptographically secure randomness is never replaced by ordinary randomness.",
            "Algorithm, mode, padding, initialization vector and nonce handling are unchanged.",
            "Key formats, signature encodings and derivation parameters remain compatible.",
        ],
        [
            "a secure random source replaced by a general purpose generator",
            "a signature encoding change that breaks historical verification",
            "a key derivation parameter changed during the substitution",
        ],
    ),
    (
        "process-and-environment-library-mapper",
        "Process and Environment Library Mapper",
        "Verify process spawning, argument escaping, signal and cleanup semantics",
        ["argument escaping", "signal handling", "exit code", "child cleanup"],
        ["process_capability_map.json", "process_findings.json", "process_notes.md"],
        [
            "Arguments are passed structurally rather than through a shell where possible.",
            "Signal handling, exit code and stream capture semantics are preserved.",
            "Child processes are reaped on every exit path including timeout.",
        ],
        [
            "an argument interpolated into a shell string",
            "an orphaned child process left after a timeout",
            "an exit code collapsed so failure reads as success",
        ],
    ),
    (
        "compression-and-archive-mapper",
        "Compression and Archive Mapper",
        "Verify format, level, metadata and resource limit behaviour of compression substitutions",
        ["format identity", "streaming", "path traversal", "resource limit"],
        ["compression_capability_map.json", "archive_findings.json", "compression_notes.md"],
        [
            "Existing archives remain readable and new archives remain readable by the old library.",
            "File metadata, checksums and streaming behaviour are preserved.",
            "Extraction refuses traversal paths and enforces an expansion limit.",
        ],
        [
            "an archive entry extracted outside its destination directory",
            "an expansion bomb accepted because no limit was configured",
            "file metadata dropped during re-archiving",
        ],
    ),
    (
        "logging-and-telemetry-library-mapper",
        "Logging and Telemetry Library Mapper",
        "Verify level, structure, context, redaction and flush behaviour of telemetry substitutions",
        ["structured field", "context correlation", "redaction", "flush on shutdown"],
        ["telemetry_capability_map.json", "telemetry_findings.json", "telemetry_notes.md"],
        [
            "Trace, tenant and request correlation survive the substitution.",
            "Sensitive field redaction is preserved and verified against real payloads.",
            "Buffered records are flushed on shutdown and on abnormal termination.",
        ],
        [
            "a sensitive field newly written in clear text",
            "a trace broken so records can no longer be correlated",
            "buffered records lost when the process crashes",
        ],
    ),
    (
        "replacement-candidate-discoverer",
        "Replacement Candidate Discoverer",
        "Find candidate implementations in the target ecosystem for a required capability",
        ["capability search", "candidate source", "uncertified default", "coverage estimate"],
        ["replacement_candidates.json", "candidate_sources.json", "discovery_notes.md"],
        [
            "Candidates are found by capability subgraph, not by name similarity.",
            "Standard library, ecosystem, vendor, internal and adapter options are all considered.",
            "Every candidate starts in an uncertified state regardless of popularity.",
        ],
        [
            "a candidate presented as equivalent on discovery alone",
            "a search that matched package names rather than capabilities",
            "a candidate marked certified without any evidence",
        ],
    ),
    (
        "replacement-semantic-similarity-scorer",
        "Replacement Semantic Similarity Scorer",
        "Score candidates across capability dimensions without averaging critical requirements away",
        ["dimension scoring", "non-averaging", "mandatory dimension", "score provenance"],
        ["candidate_scores.json", "dimension_matrix.json", "scoring_notes.md"],
        [
            "Mandatory dimensions must pass fully and are never compensated by other scores.",
            "Interface, behaviour, error, concurrency, format, platform and licence axes are separate.",
            "Every score names the evidence that produced it.",
        ],
        [
            "a weighted average that hides a failed mandatory dimension",
            "documentation quality compensating for a missing idempotency guarantee",
            "a score asserted without evidence",
        ],
    ),
]

SKILLS[128] = [
    (
        "replacement-api-compatibility-verifier",
        "Replacement API Compatibility Verifier",
        "Classify how closely a candidate interface matches the consumed source interface",
        ["signature parity", "nullability", "extension point", "classification outcome"],
        ["api_compatibility.json", "signature_diff.json", "api_notes.md"],
        [
            "Parameters, return values, generics, callbacks, defaults and nullability are compared.",
            "Lifecycle, configuration and extension points are compared, not just call signatures.",
            "Each surface receives one terminal classification from drop-in to unsuitable.",
        ],
        [
            "an overload set collapsed so a call becomes ambiguous",
            "a default parameter value changed by the candidate",
            "an extension point lost with no adapter recorded",
        ],
    ),
    (
        "replacement-behavioral-compatibility-verifier",
        "Replacement Behavioral Compatibility Verifier",
        "Run source and candidate libraries under identical conditions and diff every observable",
        ["identical conditions", "observable diff", "effect parity", "timing parity"],
        ["behavioral_compatibility.json", "library_diff.json", "behavioural_notes.md"],
        [
            "Both libraries run with the same input, configuration, dependency responses and clock.",
            "Return values, errors, retries, external calls, resources and ordering are compared.",
            "Differences are emitted for terminal classification, never silently tolerated.",
        ],
        [
            "a comparison run with different default configuration on each side",
            "an extra external call made by the candidate",
            "a difference recorded without a classification path",
        ],
    ),
    (
        "replacement-data-format-compatibility-verifier",
        "Replacement Data Format Compatibility Verifier",
        "Prove that historical and future data remain readable across the library substitution",
        ["old data readability", "new data readability", "signature verification", "archive access"],
        ["format_compatibility.json", "roundtrip_matrix.json", "format_notes.md"],
        [
            "Data written by the old library is read correctly by the new one and vice versa.",
            "Tokens, cookies, cached values and encrypted payloads remain verifiable.",
            "Historical archives remain readable after the substitution.",
        ],
        [
            "an existing cached value that the new library cannot decode",
            "a signature that no longer verifies after the substitution",
            "a historical archive rendered unreadable",
        ],
    ),
    (
        "replacement-concurrency-model-verifier",
        "Replacement Concurrency Model Verifier",
        "Verify that the candidate concurrency model actually matches the source model",
        ["thread safety class", "callback thread", "backpressure", "reentrancy"],
        ["concurrency_compatibility.json", "model_deltas.json", "concurrency_notes.md"],
        [
            "Thread safety, reentrancy and isolation class are established by test, not by documentation.",
            "Callback delivery thread and cancellation behaviour are compared.",
            "Connection pooling and backpressure semantics are compared.",
        ],
        [
            "an asynchronous claim that resolves to a blocking implementation",
            "a callback delivered on a thread the source never used",
            "a backpressure mechanism absent from the candidate",
        ],
    ),
    (
        "replacement-operational-model-verifier",
        "Replacement Operational Model Verifier",
        "Verify initialization, health, reload, shutdown and recovery behaviour of the candidate",
        ["initialization", "health and metric", "reload", "failure recovery"],
        ["operational_compatibility.json", "lifecycle_deltas.json", "operational_notes.md"],
        [
            "Initialization order, configuration reload and shutdown behaviour are compared.",
            "Health, metric and log surfaces required by operations are preserved.",
            "Failure recovery, retry and circuit behaviour are compared under injected faults.",
        ],
        [
            "a candidate that cannot be shut down without dropping in-flight work",
            "a metric surface lost so an existing alert stops firing",
            "a recovery path that requires a process restart",
        ],
    ),
    (
        "dependency-adapter-generator",
        "Dependency Adapter Generator",
        "Generate one isolating adapter so replacement differences do not leak into business code",
        ["central isolation", "error translation", "context forwarding", "fallback path"],
        ["adapter_spec.json", "adapter_contract.json", "adapter_notes.md"],
        [
            "Business code never handles candidate-specific differences directly.",
            "Parameter, error, format, context, timeout and cancellation translation live in the adapter.",
            "Metrics and traces cross the adapter without losing correlation.",
        ],
        [
            "candidate-specific handling scattered through business code",
            "an adapter that swallows an error class the source surfaced",
            "an adapter that drops the request context",
        ],
    ),
    (
        "composite-replacement-planner",
        "Composite Replacement Planner",
        "Compose several target libraries when no single candidate covers the source capability",
        ["capability decomposition", "component composition", "interaction risk", "combined contract"],
        ["composite_plan.json", "component_map.json", "composition_risks.md"],
        [
            "The source capability is decomposed and every part is assigned an owner component.",
            "Component interaction is verified as a whole, not only per component.",
            "The combined contract is stated as one surface for the adapter to implement.",
        ],
        [
            "components that each pass alone but conflict when combined",
            "a capability part left with no assigned component",
            "a composite declared equivalent from per-component results only",
        ],
    ),
    (
        "source-porting-decision-skill",
        "Source Porting Decision Skill",
        "Decide between ecosystem substitution, wrapping, foreign calls, porting and rewriting",
        ["option comparison", "licence constraint", "maintenance cost", "long-term target"],
        ["porting_decision.json", "option_analysis.json", "decision_notes.md"],
        [
            "Licence, source scale, native dependency, performance and maintenance cost are all weighed.",
            "Continuing to call the source library through a foreign boundary is treated as a real option.",
            "The decision records who approved it and when it is reviewed.",
        ],
        [
            "a rewrite chosen without evaluating a wrapper",
            "a port chosen without checking the source licence",
            "a decision recorded without an owner or review date",
        ],
    ),
    (
        "dependency-maintenance-health-analyzer",
        "Dependency Maintenance Health Analyzer",
        "Assess maintenance health as a risk signal, never as evidence of correctness",
        ["release cadence", "security responsiveness", "maintainer concentration", "compatibility policy"],
        ["maintenance_health.json", "health_signals.json", "health_notes.md"],
        [
            "Health is reported as a risk signal and never substitutes for behavioural evidence.",
            "Release cadence, security response, maintainer count and test posture are recorded.",
            "Platform support and compatibility policy are recorded per candidate.",
        ],
        [
            "a healthy project accepted without behavioural verification",
            "an unmaintained project accepted because its interface matched",
            "a single-maintainer critical dependency with no contingency",
        ],
    ),
    (
        "dependency-abandonment-detector",
        "Dependency Abandonment Detector",
        "Detect abandonment and trigger the containment plan before it becomes an incident",
        ["release silence", "archival", "unpatched advisory", "containment plan"],
        ["abandonment_findings.json", "containment_plan.json", "abandonment_notes.md"],
        [
            "Release silence, archival, build failure and unpatched advisories are all monitored.",
            "Every abandoned dependency gains a pinned version and a containment plan.",
            "A retirement plan with an owner and a date is recorded.",
        ],
        [
            "an archived dependency still floating on a version range",
            "an unpatched advisory with no containment action",
            "an abandoned dependency with no retirement plan",
        ],
    ),
    (
        "vendor-lock-in-analyzer",
        "Vendor Lock-in Analyzer",
        "Quantify replacement cost and define the exit path for proprietary dependencies",
        ["proprietary surface", "data portability", "abstraction boundary", "exit path"],
        ["lock_in_analysis.json", "exit_path.json", "lock_in_notes.md"],
        [
            "Proprietary protocol, format, runtime and identity coupling are all identified.",
            "Data export capability is verified, not assumed from documentation.",
            "An abstraction boundary and a tested exit path are recorded.",
        ],
        [
            "a proprietary format with no verified export path",
            "a dependency that cannot be exercised outside the vendor environment",
            "an exit path documented but never tested",
        ],
    ),
    (
        "commercial-dependency-governance",
        "Commercial Dependency Governance",
        "Govern paid, closed-source and vendor-supported dependencies against their contract terms",
        ["deployment limit", "seat and instance limit", "redistribution", "termination clause"],
        ["commercial_inventory.json", "term_constraints.json", "governance_notes.md"],
        [
            "Deployment, instance, seat and redistribution limits are recorded per component.",
            "Production and test entitlements are distinguished explicitly.",
            "Legal conclusions are attributed to qualified reviewers, never inferred by the system.",
        ],
        [
            "a production deployment exceeding a licensed instance count",
            "a legal conclusion asserted without a qualified reviewer",
            "a redistribution that the contract does not permit",
        ],
    ),
    (
        "native-dependency-inventory",
        "Native Dependency Inventory",
        "Inventory every native artifact and cross-language boundary in the closure",
        ["shared and static library", "language bridge", "artifact origin", "platform variant"],
        ["native_inventory.json", "boundary_index.json", "native_gaps.md"],
        [
            "Shared libraries, static archives, bundled frameworks and extensions are all listed.",
            "Every cross-language boundary is identified with its bridging mechanism.",
            "Each native artifact records its origin, platform variants and signature state.",
        ],
        [
            "a native artifact whose origin cannot be established",
            "a language bridge missing from the boundary index",
            "a platform variant absent for a declared target",
        ],
    ),
    (
        "ffi-ownership-contract-builder",
        "FFI Ownership Contract Builder",
        "Declare allocation, release, borrowing and threading rules for every cross-language parameter",
        ["allocation owner", "release function", "storage permission", "callback lifetime"],
        ["ffi_contracts.json", "ownership_matrix.json", "ffi_risks.md"],
        [
            "Every parameter declares who allocates, who releases and whether the callee may store it.",
            "Buffer length, string encoding, nullability and error convention are explicit.",
            "Callback invocation count, lifetime and threading constraints are declared.",
        ],
        [
            "a buffer stored by the callee although the contract forbids it",
            "a returned handle with no declared release function",
            "a callback invoked after its owning object was destroyed",
        ],
    ),
    (
        "abi-compatibility-verifier",
        "ABI Compatibility Verifier",
        "Verify binary interface agreement across compilers, architectures and runtime libraries",
        ["calling convention", "layout and alignment", "symbol resolution", "exception boundary"],
        ["abi_verification.json", "layout_matrix.json", "abi_findings.md"],
        [
            "Calling convention, name mangling, layout, alignment and padding are all verified.",
            "Enumeration width, vtable layout and pointer width are verified per target.",
            "Runtime library and compiler versions are pinned across the boundary.",
        ],
        [
            "a structure layout that differs between the two sides of a boundary",
            "an exception propagating across an incompatible binary boundary",
            "a symbol resolved from a different runtime library than expected",
        ],
    ),
    (
        "cross-compilation-dependency-verifier",
        "Cross-Compilation Dependency Verifier",
        "Verify that every dependency actually builds and runs on each declared target platform",
        ["target matrix", "toolchain availability", "system header", "signing requirement"],
        ["cross_compilation_matrix.json", "platform_findings.json", "cross_compilation_notes.md"],
        [
            "Every declared target platform has a verified artifact for every native dependency.",
            "Toolchain, linker, system header and runtime availability are verified per target.",
            "Code signing and platform entitlement requirements are satisfied per target.",
        ],
        [
            "a target platform with no verified native artifact",
            "a build that succeeds only on the developer architecture",
            "a signing requirement discovered after release packaging",
        ],
    ),
]

SKILLS[129] = [
    (
        "system-library-mapping-pack",
        "System Library Mapping Pack",
        "Govern operating system libraries that never enter a package lockfile but shape production behaviour",
        ["system provided library", "version reproducibility", "behaviour drift", "container pinning"],
        ["system_library_inventory.json", "version_pinning.json", "system_library_risks.md"],
        [
            "Transport security, cryptographic, compression and database client system libraries are inventoried.",
            "Every system library version is pinned through the container or image definition.",
            "Behaviour that differs across distributions is recorded per target image.",
        ],
        [
            "a system library that determines production behaviour but is absent from any manifest",
            "a base image update that silently changes a cryptographic default",
            "a distribution-specific behaviour discovered only in production",
        ],
    ),
    (
        "apple-framework-bridge-pack",
        "Apple Framework Bridge Pack",
        "Govern Apple platform framework use, ownership and availability across versions",
        ["platform availability", "queue affinity", "core ownership", "entitlement"],
        ["apple_framework_inventory.json", "availability_matrix.json", "apple_framework_risks.md"],
        [
            "Framework availability is verified against the declared deployment target.",
            "Main-queue-only interfaces and reference counting ownership rules are recorded.",
            "Entitlement and code signing requirements are satisfied for every framework used.",
        ],
        [
            "an interface unavailable on the declared deployment target",
            "a core object leaked because bridging ownership was unclear",
            "a framework requiring an entitlement that was never requested",
        ],
    ),
    (
        "accelerator-dependency-pack",
        "Accelerator Dependency Pack",
        "Govern graphics and accelerator runtimes, drivers, determinism and fallback",
        ["driver and runtime", "memory ownership", "determinism", "fallback path"],
        ["accelerator_inventory.json", "determinism_report.json", "accelerator_risks.md"],
        [
            "Hardware, driver and runtime versions are pinned per deployment target.",
            "Device memory ownership and transfer boundaries are explicit.",
            "A verified fallback path exists for environments without the accelerator.",
        ],
        [
            "a numeric result that changes with driver version",
            "device memory freed while a kernel still references it",
            "an accelerator requirement with no verified fallback",
        ],
    ),
    (
        "native-cryptography-provider-pack",
        "Native Cryptography Provider Pack",
        "Verify that a cryptographic provider substitution preserves algorithms, keys and historical data",
        ["algorithm identity", "key compatibility", "hardware module", "zeroization"],
        ["crypto_provider_report.json", "compatibility_matrix.json", "crypto_provider_risks.md"],
        [
            "Algorithm, mode, padding, initialization vector and nonce handling are unchanged.",
            "Existing keys, certificates and signatures remain usable and verifiable.",
            "Key material zeroization and hardware module behaviour are verified.",
        ],
        [
            "an existing signature that no longer verifies",
            "a key format the new provider cannot load",
            "key material left in memory after use",
        ],
    ),
    (
        "native-database-driver-pack",
        "Native Database Driver Pack",
        "Verify protocol, type, pooling and cancellation behaviour of a native driver substitution",
        ["wire protocol", "type mapping", "prepared statement", "failover"],
        ["driver_report.json", "type_mapping_matrix.json", "driver_risks.md"],
        [
            "Protocol version, transport security and authentication negotiation are verified.",
            "Decimal, temporal, null and text encoding mappings are lossless.",
            "Connection pooling, cancellation and failover behaviour match the source driver.",
        ],
        [
            "a decimal column read through a floating point type",
            "a cancelled query that continues on the server",
            "an automatic driver retry on a non-idempotent statement",
        ],
    ),
    (
        "container-and-runtime-dependency-pack",
        "Container and Runtime Dependency Pack",
        "Govern base image, operating system package, certificate, locale and runtime content",
        ["base image pinning", "certificate store", "timezone data", "least privilege"],
        ["container_inventory.json", "image_digest_pinning.json", "container_risks.md"],
        [
            "Base image and operating system packages are pinned by digest, not by tag.",
            "Certificate store, timezone data and locale content are present and current.",
            "The image runs as a non-root user with no unnecessary tooling.",
        ],
        [
            "a base image referenced by a mutable tag",
            "a missing certificate store that breaks transport security",
            "missing timezone data that silently shifts temporal results",
        ],
    ),
    (
        "native-dependency-sandbox-runner",
        "Native Dependency Sandbox Runner",
        "Run untrusted or closed-source native dependencies under enforced restriction",
        ["network restriction", "filesystem restriction", "syscall restriction", "resource bound"],
        ["sandbox_profile.json", "observed_behaviour.json", "sandbox_findings.md"],
        [
            "Network, filesystem, process, secret and system call access are all restricted by default.",
            "Processor, memory and time bounds are enforced and observed.",
            "Every attempted access outside the profile is recorded as a finding.",
        ],
        [
            "an unexpected outbound connection from a closed-source component",
            "a component reading a secret outside its declared profile",
            "a sandbox profile so wide it grants the whole default environment",
        ],
    ),
    (
        "license-discovery-scanner",
        "License Discovery Scanner",
        "Discover declared and detected licenses across the whole closure including generated code",
        ["declared license", "detected license", "dual license", "file level divergence"],
        ["license_inventory.json", "declaration_conflicts.json", "license_gaps.md"],
        [
            "Package metadata, source headers, notice files and binary metadata are all scanned.",
            "Declared and detected licenses are compared and conflicts reported.",
            "Generated code, transitive packages and system libraries are all covered.",
        ],
        [
            "a declared license that contradicts the file headers",
            "a transitive package with no identifiable license",
            "generated code whose license was never determined",
        ],
    ),
    (
        "license-compatibility-graph",
        "License Compatibility Graph",
        "Evaluate configured compatibility policy across source, target and dependency licenses",
        ["license class", "policy evaluation", "conflict path", "reviewer attribution"],
        ["license_compatibility.json", "conflict_paths.json", "compatibility_notes.md"],
        [
            "Permissive, weak copyleft, strong copyleft, network copyleft and proprietary classes are distinguished.",
            "The system evaluates configured policy only and never asserts a legal conclusion.",
            "Every conflict names the exact dependency path that produced it.",
        ],
        [
            "a legal conclusion asserted without a qualified reviewer",
            "an unknown license silently treated as permissive",
            "a conflict reported without its dependency path",
        ],
    ),
    (
        "copyleft-propagation-analyzer",
        "Copyleft Propagation Analyzer",
        "Analyse how linkage and distribution shape source disclosure obligations",
        ["linkage form", "distribution form", "service deployment", "obligation record"],
        ["propagation_analysis.json", "obligation_record.json", "propagation_notes.md"],
        [
            "Static linkage, dynamic linkage, source merging, process boundary and service deployment are distinguished.",
            "Every identified obligation is recorded for qualified review rather than auto-resolved.",
            "Plugin and generated code paths are analysed, not only direct dependencies.",
        ],
        [
            "a static link treated as equivalent to a process boundary",
            "an obligation resolved by the system without review",
            "a plugin boundary omitted from the analysis",
        ],
    ),
    (
        "attribution-and-notice-builder",
        "Attribution and Notice Builder",
        "Generate the third-party license, notice and attribution artifacts a release requires",
        ["notice generation", "copyright collection", "in-product disclosure", "container report"],
        ["attribution_manifest.json", "notice_bundle.json", "attribution_notes.md"],
        [
            "Every dependency requiring attribution appears in the generated notice.",
            "Copyright statements are collected verbatim rather than summarized.",
            "Container and distribution packages carry their own license report.",
        ],
        [
            "a dependency requiring attribution missing from the notice",
            "a copyright statement paraphrased rather than reproduced",
            "a container image shipped without its license report",
        ],
    ),
    (
        "commercial-use-restriction-detector",
        "Commercial Use Restriction Detector",
        "Detect field, scale, deployment and competition restrictions in dependency terms",
        ["field restriction", "scale restriction", "service restriction", "territory restriction"],
        ["restriction_findings.json", "restriction_matrix.json", "restriction_notes.md"],
        [
            "Non-commercial, field-of-use, user count and deployment count restrictions are detected.",
            "Cloud service and competing product restrictions are surfaced explicitly.",
            "Every finding is routed to qualified review with its exact clause reference.",
        ],
        [
            "a non-commercial dependency reaching a commercial deployment",
            "a scale restriction discovered after the deployment exceeded it",
            "a restriction finding closed without a clause reference",
        ],
    ),
    (
        "patent-and-additional-terms-tracker",
        "Patent and Additional Terms Tracker",
        "Record patent grants, terminations, trademark and additional terms attached to dependencies",
        ["patent grant", "termination clause", "trademark term", "vendor addendum"],
        ["additional_terms.json", "high_risk_clauses.json", "terms_notes.md"],
        [
            "Patent grant and termination clauses are recorded verbatim per dependency.",
            "Trademark, contributor agreement and vendor addendum terms are captured.",
            "High-risk clauses raise a review gate rather than a warning.",
        ],
        [
            "a patent termination clause discovered after adoption",
            "a vendor addendum absent from the terms record",
            "a high-risk clause recorded as a warning with no gate",
        ],
    ),
    (
        "source-offer-obligation-manager",
        "Source Offer Obligation Manager",
        "Preserve the exact material required when a source or build offer must be honoured",
        ["corresponding source", "build material", "offer text", "retention period"],
        ["source_offer_bundle.json", "material_manifest.json", "offer_notes.md"],
        [
            "Corresponding source, patches, build scripts, toolchain and licenses are all retained.",
            "Retained material rebuilds the shipped artifact from the recorded inputs.",
            "The offer text and its retention period are recorded with the release.",
        ],
        [
            "retained source that cannot rebuild the shipped artifact",
            "a patch applied at build time but absent from the bundle",
            "an offer whose retention period has silently expired",
        ],
    ),
    (
        "license-change-monitor",
        "License Change Monitor",
        "Detect license and ownership change when a dependency is upgraded or transferred",
        ["version license delta", "ownership transfer", "closure transition", "dual license election"],
        ["license_change_events.json", "change_impact.json", "change_notes.md"],
        [
            "Every upgrade compares the new license against the recorded one.",
            "Package ownership transfer and commercial term change raise an event.",
            "A dual license election is recorded so it is not re-decided silently.",
        ],
        [
            "an upgrade that silently changed the license class",
            "an open component replaced by a closed binary",
            "a dual license election changed without a record",
        ],
    ),
    (
        "license-release-gate",
        "License Release Gate",
        "Block release while any license obligation or restriction remains unresolved",
        ["unknown license", "prohibited license", "missing notice", "unresolved restriction"],
        ["license_gate.json", "gate_evaluation.json", "license_gate_report.md"],
        [
            "Unknown critical licenses, prohibited licenses and missing notices are all zero.",
            "Unresolved commercial restrictions are zero before release.",
            "Every waiver names a qualified reviewer and an expiry date.",
        ],
        [
            "an unknown license on a critical dependency at release time",
            "a prohibited license waived without a qualified reviewer",
            "a notice requirement satisfied after the artifact shipped",
        ],
    ),
]

SKILLS[130] = [
    (
        "sbom-generator",
        "SBOM Generator",
        "Produce a machine-readable bill of materials covering the whole shipped closure",
        ["component identity", "relationship graph", "native and container coverage", "format conformance"],
        ["sbom.json", "sbom_coverage.json", "sbom_notes.md"],
        [
            "Package name, version, hash, origin, license and relationships are recorded per component.",
            "Native binaries, container layers, build tools and generated artifacts are all covered.",
            "The bill of materials is regenerated deterministically from the recorded inputs.",
        ],
        [
            "a shipped native binary missing from the bill of materials",
            "a container layer omitted from the component list",
            "a bill of materials that cannot be regenerated identically",
        ],
    ),
    (
        "build-provenance-recorder",
        "Build Provenance Recorder",
        "Record who built what, from which inputs, in which environment, with which toolchain",
        ["input binding", "builder identity", "environment fingerprint", "artifact binding"],
        ["build_provenance.json", "input_binding.json", "provenance_notes.md"],
        [
            "Source commit, dependency lock, build parameters and toolchain are all bound to the artifact.",
            "Builder identity, environment fingerprint and signing identity are recorded.",
            "Provenance is emitted for every artifact, not only for release candidates.",
        ],
        [
            "an artifact with no recorded build inputs",
            "a provenance record whose builder identity cannot be verified",
            "a release artifact built outside the recorded environment",
        ],
    ),
    (
        "package-signature-verifier",
        "Package Signature Verifier",
        "Verify package, container and native artifact signatures and publisher identity",
        ["signature verification", "certificate chain", "publisher identity", "unsigned fallback"],
        ["signature_verification.json", "publisher_registry.json", "signature_findings.md"],
        [
            "Every signed artifact is verified against a trusted certificate chain.",
            "Publisher identity changes are detected and raised as events.",
            "Ecosystems without signing rely on recorded hashes, trusted mirrors and provenance instead.",
        ],
        [
            "a signature accepted without validating its chain",
            "an unsigned native binary accepted into a release",
            "a publisher change accepted without review",
        ],
    ),
    (
        "artifact-integrity-gate",
        "Artifact Integrity Gate",
        "Bind download, cache, build input and build output hashes into one verified chain",
        ["hash chain", "mirror consistency", "input output binding", "cache verification"],
        ["integrity_chain.json", "hash_verification.json", "integrity_findings.md"],
        [
            "Lockfile, download, cache and artifact hashes all agree.",
            "Mirror content is verified against the upstream recorded hash.",
            "Build outputs are bound to the exact verified inputs that produced them.",
        ],
        [
            "a mirrored artifact whose hash differs from upstream",
            "a cached artifact accepted without hash verification",
            "a build output with no binding to its inputs",
        ],
    ),
    (
        "typosquatting-detector",
        "Typosquatting Detector",
        "Detect package names crafted to resemble a legitimate dependency",
        ["name distance", "separator variation", "publisher similarity", "low adoption signal"],
        ["typosquat_findings.json", "similarity_scores.json", "typosquat_notes.md"],
        [
            "Spelling distance, case, separator and homoglyph variations are all evaluated.",
            "Newly published low-adoption packages resembling known names are flagged.",
            "Every finding names the legitimate package it resembles.",
        ],
        [
            "a newly added dependency one character from a well-known package",
            "a separator variant accepted without review",
            "a finding raised without naming the resembled package",
        ],
    ),
    (
        "dependency-confusion-guard",
        "Dependency Confusion Guard",
        "Prevent a public package from shadowing an internal one",
        ["namespace reservation", "index precedence", "source allowlist", "resolution pinning"],
        ["confusion_guard_config.json", "resolution_audit.json", "confusion_findings.md"],
        [
            "Internal namespaces are reserved and public resolution for them is denied.",
            "Index precedence is explicit and public sources cannot override internal packages.",
            "Every resolved package records which configured source served it.",
        ],
        [
            "an internal package resolved from a public index",
            "an index precedence that depends on resolution order",
            "a resolved package with no recorded source",
        ],
    ),
    (
        "publisher-change-monitor",
        "Publisher Change Monitor",
        "Monitor maintainer, ownership and publishing behaviour change on adopted dependencies",
        ["maintainer change", "ownership transfer", "publishing anomaly", "script introduction"],
        ["publisher_events.json", "behaviour_baseline.json", "publisher_notes.md"],
        [
            "Maintainer set, ownership and publishing key changes all raise events.",
            "A newly introduced install script or native binary raises an event.",
            "Unusual release bursts are compared against the recorded baseline.",
        ],
        [
            "an install script introduced in a patch release",
            "an ownership transfer that no one reviewed",
            "a native binary origin changed between releases",
        ],
    ),
    (
        "vulnerability-correlator",
        "Vulnerability Correlator",
        "Correlate advisories to the exact version, path, reachable symbol and exposure",
        ["path correlation", "reachability", "exposure surface", "mitigation state"],
        ["vulnerability_correlation.json", "reachability_evidence.json", "vulnerability_notes.md"],
        [
            "Every advisory is bound to the resolved version and its dependency path.",
            "Priority combines severity with reachability, exposure and mitigation state.",
            "Reachability claims cite the analysis or trace that produced them.",
        ],
        [
            "an advisory dismissed as unreachable without evidence",
            "a shaded dependency whose advisories were never matched",
            "priority assigned on severity alone while an exposed path exists",
        ],
    ),
    (
        "malicious-install-script-detector",
        "Malicious Install Script Detector",
        "Detect install and build hooks that download, execute, read secrets or mutate source",
        ["hook inventory", "network access", "secret access", "source mutation"],
        ["install_script_findings.json", "hook_inventory.json", "script_notes.md"],
        [
            "Install hooks, build scripts and build phases across all ecosystems are inventoried.",
            "Network access, secret reads, process execution and source mutation are detected.",
            "A newly introduced hook blocks adoption until it is reviewed.",
        ],
        [
            "a post-install hook that fetches and runs a remote script",
            "a build script reading an environment secret",
            "a build step modifying files in the source tree",
        ],
    ),
    (
        "build-isolation-enforcer",
        "Build Isolation Enforcer",
        "Deny secrets, network and privilege to the dependency build phase by default",
        ["secret denial", "network restriction", "read-only source", "output allowlist"],
        ["isolation_profile.json", "isolation_evidence.json", "isolation_findings.md"],
        [
            "The build phase holds no production secret and no broader network access than declared.",
            "Source is mounted read-only and outputs are restricted to an allowlist.",
            "The build runs as an unprivileged user with enforced resource limits.",
        ],
        [
            "a build phase that can read a production secret",
            "a build step writing outside its declared output paths",
            "a build running with unnecessary privilege",
        ],
    ),
    (
        "hermetic-build-verifier",
        "Hermetic Build Verifier",
        "Verify that a build depends only on its declared inputs",
        ["declared input closure", "clock independence", "host independence", "environment declaration"],
        ["hermeticity_report.json", "undeclared_inputs.json", "hermeticity_notes.md"],
        [
            "Output depends only on source, locked dependencies, toolchain, configuration and platform.",
            "The build does not read the clock, the network or undeclared host files.",
            "Every environment variable that affects output is declared.",
        ],
        [
            "a build embedding the current timestamp into its output",
            "a build reading a file from the developer home directory",
            "an undeclared environment variable that changes the artifact",
        ],
    ),
    (
        "secret-exposure-scanner",
        "Secret Exposure Scanner",
        "Detect credentials leaked into build outputs, artifacts and evidence",
        ["artifact scanning", "log scanning", "layer scanning", "evidence scanning"],
        ["secret_findings.json", "scan_coverage.json", "secret_notes.md"],
        [
            "Package configuration, build logs, lockfiles and generated code are all scanned.",
            "Container layers, native binary strings and source maps are scanned.",
            "Evidence bundles and test fixtures are scanned before publication.",
        ],
        [
            "a credential embedded in a container layer",
            "a token written into a build log retained as evidence",
            "a secret present in a source map shipped to clients",
        ],
    ),
    (
        "reproducible-build-verifier",
        "Reproducible Build Verifier",
        "Rebuild from identical inputs in isolation and compare every produced artifact",
        ["repeat build", "artifact comparison", "nondeterminism normalization", "critical module scope"],
        ["reproducibility_report.json", "difference_analysis.json", "reproducibility_notes.md"],
        [
            "Repeat builds from identical inputs produce identical artifact digests.",
            "Bill of materials, symbols, package content and container layers are all compared.",
            "Every normalized non-deterministic field is declared and justified.",
        ],
        [
            "an artifact digest that changes between identical builds",
            "a non-deterministic field normalized without justification",
            "a critical module excluded from the reproducibility requirement",
        ],
    ),
    (
        "trusted-mirror-and-quarantine-manager",
        "Trusted Mirror and Quarantine Manager",
        "Operate an internal mirror with review, approval, quarantine and emergency revocation",
        ["mirror ingestion", "version approval", "quarantine", "emergency revocation"],
        ["mirror_registry.json", "quarantine_log.json", "mirror_notes.md"],
        [
            "Every mirrored version records its origin proof and approval state.",
            "A suspected malicious package can be quarantined without breaking historical builds.",
            "Emergency revocation propagates to build environments in a measured time.",
        ],
        [
            "a package served from the mirror without an approval record",
            "a quarantine action that breaks reproducible historical builds",
            "a revocation whose propagation time was never measured",
        ],
    ),
    (
        "dependency-security-policy-gate",
        "Dependency Security Policy Gate",
        "Block release while any supply-chain condition remains unresolved",
        ["unsigned artifact", "unresolved advisory", "unapproved source", "reproducibility requirement"],
        ["security_gate.json", "gate_evaluation.json", "security_gate_report.md"],
        [
            "Unsigned native binaries, unresolved critical advisories and unapproved sources are all zero.",
            "Malicious install scripts and unknown publishers are zero.",
            "Reproducible build is required for every critical module.",
        ],
        [
            "a critical advisory waived without a compensating control",
            "an unapproved registry serving a production dependency",
            "a critical module released without reproducibility evidence",
        ],
    ),
    (
        "dependency-incident-response",
        "Dependency Incident Response",
        "Contain, trace, replace and re-verify after a malicious or high-risk dependency is found",
        ["build freeze", "path tracing", "credential revocation", "historical sweep"],
        ["incident_record.json", "impact_paths.json", "incident_closure.md"],
        [
            "Builds and releases are frozen before any remediation begins.",
            "Every dependency path and every affected artifact is traced and listed.",
            "Credentials exposed to the compromised component are revoked and rotated.",
        ],
        [
            "remediation started before the build was frozen",
            "an affected historical artifact left unswept",
            "an incident closed without a new permanent policy rule",
        ],
    ),
]

SKILLS[131] = [
    (
        "replacement-certification-profile",
        "Replacement Certification Profile",
        "Record the exact scope in which a replacement library is certified",
        ["scope binding", "used capability subset", "adapter identity", "unsupported capability"],
        ["replacement_profile.json", "scope_binding.json", "profile_notes.md"],
        [
            "Source package, source version, target package and target version are all bound.",
            "The certified scope names the used capability subset, not the whole library.",
            "Unsupported capabilities and required adapters are listed explicitly.",
        ],
        [
            "a certification claimed for capabilities outside the tested subset",
            "a profile without a pinned target version",
            "an unsupported capability omitted from the profile",
        ],
    ),
    (
        "replacement-contract-test-generator",
        "Replacement Contract Test Generator",
        "Generate contract tests from the actually consumed interface of the source library",
        ["surface derived test", "boundary input", "resource path", "configuration variation"],
        ["replacement_contract_suite.json", "surface_coverage.json", "generation_notes.md"],
        [
            "Tests are derived from the extracted used surface, not from the library documentation.",
            "Normal, boundary, error, timeout, cancellation and resource paths are all generated.",
            "Generated tests fail against a deliberately broken candidate.",
        ],
        [
            "a consumed surface member with no generated test",
            "a suite derived from documentation rather than measured usage",
            "a generated test that passes against a known-broken candidate",
        ],
    ),
    (
        "replacement-differential-harness",
        "Replacement Differential Harness",
        "Run source and candidate libraries side by side on identical inputs and diff all channels",
        ["side by side execution", "channel comparison", "resource comparison", "timing comparison"],
        ["replacement_differential.json", "channel_diff.json", "differential_notes.md"],
        [
            "Both libraries execute under the same injected clock, randomness and dependency responses.",
            "Return values, errors, external calls, resources and ordering are all compared.",
            "Every difference is emitted for terminal classification.",
        ],
        [
            "a comparison run with different configuration on each side",
            "an extra or missing external call left unreported",
            "a difference recorded with no classification path",
        ],
    ),
    (
        "replacement-property-and-fuzz-pack",
        "Replacement Property and Fuzz Pack",
        "Assert capability invariants and fuzz the candidate across its consumed surface",
        ["capability invariant", "roundtrip property", "adversarial input", "shrunk counterexample"],
        ["replacement_property_suite.json", "fuzz_corpus.json", "property_notes.md"],
        [
            "Invariants are derived from the capability model, not from either implementation.",
            "Encode and decode roundtrip, resource release and cancellation properties are included.",
            "Every failure shrinks to a minimal replayable counterexample.",
        ],
        [
            "a transport security downgrade that no property detects",
            "a cancelled operation that continues reading",
            "a request body replayed where replay is not permitted",
        ],
    ),
    (
        "replacement-mutation-pack",
        "Replacement Mutation Pack",
        "Prove the replacement suite detects configuration and behaviour regressions",
        ["default mutation", "policy mutation", "resource mutation", "constraint removal"],
        ["replacement_mutations.json", "survivor_report.json", "mutation_notes.md"],
        [
            "Timeout removal, retry introduction and validation disabling mutants are all exercised.",
            "Stream materialization, buffer view and close omission mutants are included.",
            "No mutant affecting transport security, money or idempotency survives.",
        ],
        [
            "a certificate validation removal that no test detects",
            "an introduced automatic retry that survives undetected",
            "a missing close that no test catches",
        ],
    ),
    (
        "replacement-security-sandbox",
        "Replacement Security Sandbox",
        "Exercise a candidate under restriction and record every access it attempts",
        ["restricted execution", "attempted access", "install phase observation", "egress detection"],
        ["candidate_sandbox_report.json", "attempted_access.json", "sandbox_findings.md"],
        [
            "Network, filesystem, process, secret and system call access are restricted and observed.",
            "Install and build phases are observed, not only runtime.",
            "Any unexpected outbound connection or data transfer blocks adoption.",
        ],
        [
            "a candidate contacting an undeclared endpoint",
            "a candidate reading a credential outside its profile",
            "an install phase observed only after adoption",
        ],
    ),
    (
        "replacement-performance-benchmark",
        "Replacement Performance Benchmark",
        "Benchmark the candidate on the consumed capabilities at real data scale",
        ["capability scoped benchmark", "real data scale", "resource accounting", "fair configuration"],
        ["replacement_benchmark.json", "resource_accounting.json", "benchmark_notes.md"],
        [
            "Benchmarks cover the consumed capabilities at production-representative data scale.",
            "Latency, throughput, memory, allocation, processor and connection use are all measured.",
            "Both libraries run with source-equivalent configuration, not target defaults.",
        ],
        [
            "a throughput gain produced by a weaker default configuration",
            "a benchmark run at a data scale production never sees",
            "a performance result used to excuse a semantic difference",
        ],
    ),
    (
        "replacement-failure-and-chaos-test",
        "Replacement Failure and Chaos Test",
        "Inject dependency, network, resource and native failure into the candidate",
        ["network fault", "partial response", "resource pressure", "native fault"],
        ["replacement_chaos_results.json", "injection_points.json", "chaos_notes.md"],
        [
            "Timeout, reset, partial response, name resolution and certificate faults are all injected.",
            "Disk, memory and thread pressure faults are injected.",
            "Native crash and resource leak behaviour is observed under fault.",
        ],
        [
            "a partial response accepted as a complete one",
            "a native fault that leaves the process in an undefined state",
            "a resource leak that appears only under injected pressure",
        ],
    ),
    (
        "replacement-shadow-validation",
        "Replacement Shadow Validation",
        "Run the candidate against real production input while the source library stays authoritative",
        ["authoritative source", "intent comparison", "isolated execution", "irreversible effect denial"],
        ["replacement_shadow_report.json", "intent_comparison.json", "shadow_notes.md"],
        [
            "The source library remains authoritative and the candidate result is discarded.",
            "Call intent, return value, error, retry and resource use are compared.",
            "Payment, messaging and notification capabilities never execute for real in the candidate.",
        ],
        [
            "a candidate producing a real irreversible effect during shadow",
            "a shadow result that cannot be correlated to its production input",
            "a shadow run that shares a connection pool with the authoritative path",
        ],
    ),
    (
        "replacement-certification-levels",
        "Replacement Certification Levels",
        "Operate the DR0 through DR5 replacement certification ladder",
        ["level definition", "evidence per level", "ladder isolation", "critical replacement rule"],
        ["dr_certification.json", "level_evidence.json", "dr_notes.md"],
        [
            "Each level names the exact evidence that promotes into it.",
            "DR levels are reported separately and never quoted as a core E level.",
            "A critical replacement is certified independently of the repository migration.",
        ],
        [
            "a critical replacement passed through on the repository certification",
            "a DR level quoted as a core certification level",
            "a level promoted without the evidence it names",
        ],
    ),
    (
        "replacement-evidence-vault",
        "Replacement Evidence Vault",
        "Preserve the complete evidence set behind every replacement certification",
        ["surface record", "differential record", "supply chain record", "approval record"],
        ["replacement_evidence_index.json", "vault_integrity.json", "evidence_notes.md"],
        [
            "Surface, capability model, differential, mutation, performance and sandbox results are all retained.",
            "License, bill of materials, provenance and native platform results are retained.",
            "Every record is content-addressed and bound to its pack and toolchain versions.",
        ],
        [
            "a certification retaining only a summary verdict",
            "an evidence record that cannot be tied to a target version",
            "an approval record missing from the bundle",
        ],
    ),
    (
        "replacement-certification-revocation-monitor",
        "Replacement Certification Revocation Monitor",
        "Downgrade a replacement certification when any of its causal inputs changes",
        ["upgrade trigger", "license trigger", "interface trigger", "usage trigger"],
        ["replacement_revocation.json", "trigger_events.json", "revocation_notes.md"],
        [
            "Dependency upgrade, license change, publisher change and advisory all trigger re-evaluation.",
            "Newly consumed interface members trigger re-evaluation of the certified subset.",
            "Recovery requires new evidence and never an approval alone.",
        ],
        [
            "a patch upgrade that did not trigger re-evaluation",
            "a newly consumed interface member outside the certified subset",
            "a certification restored by approval without new evidence",
        ],
    ),
    (
        "replacement-approval-workflow",
        "Replacement Approval Workflow",
        "Require multi-role approval before a critical replacement is adopted",
        ["role set", "separation of duty", "approval record", "critical threshold"],
        ["approval_workflow.json", "approval_records.json", "workflow_notes.md"],
        [
            "Migration, architecture, security, license and operations roles are all represented.",
            "A critical replacement is never approved by a single identity or by a model.",
            "Every approval names an identity, a scope and an expiry.",
        ],
        [
            "a critical replacement approved by the agent that proposed it",
            "an approval recorded without a scope",
            "a security role omitted from a cryptographic replacement",
        ],
    ),
    (
        "capability-family-registry",
        "Capability Family Registry",
        "Register the cross-language capability families that candidates are drawn from",
        ["family definition", "per-language candidates", "uncertified default", "family versioning"],
        ["capability_families.json", "family_candidates.json", "registry_notes.md"],
        [
            "Every family has an observable definition independent of any one language.",
            "Candidate entries for all nine languages start in an uncertified state.",
            "Registry entries are versioned so a family meaning never changes silently.",
        ],
        [
            "a candidate listed as equivalent because it appears in the same family",
            "a family whose definition depends on one language spelling",
            "a registry change applied without a version bump",
        ],
    ),
    (
        "serialization-candidate-matrix",
        "Serialization Candidate Matrix",
        "Record serialization candidates per language with their real contract behaviour",
        ["candidate class", "presence handling", "numeric fidelity", "compatibility mode"],
        ["serialization_candidates.json", "candidate_behaviour.json", "matrix_notes.md"],
        [
            "Each candidate records absence handling, numeric fidelity and unknown field policy.",
            "Polymorphic support and schema compatibility mode are recorded per candidate.",
            "Membership in the matrix implies knowledge, never equivalence.",
        ],
        [
            "two candidates in one row treated as interchangeable",
            "a candidate whose absence handling was never determined",
            "a matrix entry presented as a certification",
        ],
    ),
    (
        "http-client-candidate-matrix",
        "HTTP Client Candidate Matrix",
        "Record request client candidates per language with their transport and policy behaviour",
        ["synchrony model", "certificate policy", "retry and timeout default", "native dependency"],
        ["http_client_candidates.json", "candidate_behaviour.json", "matrix_notes.md"],
        [
            "Each candidate records streaming, certificate validation, proxy and pooling behaviour.",
            "Default retry, timeout, redirect and cancellation behaviour are recorded verbatim.",
            "Native dependency and platform support are recorded per candidate.",
        ],
        [
            "a candidate whose default retry behaviour was never determined",
            "a candidate that cannot cancel an in-flight request",
            "a matrix entry presented as a certification",
        ],
    ),
]


# =============================================================================
# Segment 2 — Skill 433-592 : dependency certification gates, then the whole
# infrastructure layer — drivers, protocol commands, data types, relational
# transactions, cache, search, object storage, messaging, fault injection,
# mutation, test generation, performance, security and infrastructure shadow.
# =============================================================================

BATCHES.update({
    132: {
        "title": "Dependency Certification Gates and Infrastructure Discovery Pack",
        "why": "Closes the dependency layer with its own mutation library and DEP-E ladder, then opens the infrastructure layer by discovering what the repository actually connects to.",
        "purpose": "record the remaining dependency candidate matrices, mutate version drift, configuration defaults, native ABI, supply chain and licence facts, operate the DEP-E2 through DEP-E5 gates and their orchestrator, then inventory every external infrastructure resource together with its driver and protocol behaviour.",
        "tooling": ["dependency candidate matrices", "dependency mutation packs", "DEP-E gate runner", "infrastructure inventory scanner"],
    },
    133: {
        "title": "Infrastructure Protocol, Lifecycle and Data Type Pack",
        "why": "Moves ELMOS from comparing driver return values to comparing protocol commands, connection lifecycles and the exact type fidelity underneath them.",
        "purpose": "lower every driver call to a protocol command, model the full connection lifecycle and pool semantics, normalise infrastructure failures into one taxonomy, and verify integer, decimal, temporal, textual, binary, document, enum and identifier fidelity across nine languages and every backend.",
        "tooling": ["protocol command IR", "connection lifecycle model", "failure normalizer", "data type fidelity verifiers"],
    },
})

SKILLS[132] = [
    (
        "database-access-candidate-matrix",
        "Database Access Candidate Matrix",
        "Record database access candidates per language with their real access-layer semantics",
        ["access layer class", "generated SQL", "change tracking", "connection ownership"],
        ["db_access_candidates.json", "candidate_behaviour.json", "matrix_notes.md"],
        [
            "Each candidate is classified as ORM, query builder, raw SQL, native driver, async driver or migration tool.",
            "Generated SQL, change tracking, identity map, lazy loading and transaction ownership are recorded per candidate.",
            "Replacing an ORM with direct SQL access voids every inherited tracking and flush guarantee until it is re-proved.",
        ],
        [
            "an ORM replaced by raw SQL while tracking behaviour is still claimed as unchanged",
            "a candidate whose generated SQL was never captured",
            "a candidate whose connection ownership model was never determined",
        ],
    ),
    (
        "messaging-client-candidate-matrix",
        "Messaging Client Candidate Matrix",
        "Record messaging client candidates per language with their delivery and consumption semantics",
        ["broker support", "delivery guarantee", "consumer group model", "transaction support"],
        ["messaging_candidates.json", "candidate_behaviour.json", "matrix_notes.md"],
        [
            "Each candidate records broker, delivery guarantee, acknowledgement, retry, partition and rebalance behaviour.",
            "Transaction, outbox, schema registry and backpressure support are recorded per candidate.",
            "Broker-level guarantees are recorded separately from client-level guarantees and never merged.",
        ],
        [
            "a client credited with a guarantee that only the broker provides",
            "a candidate whose rebalance behaviour was never determined",
            "a matrix entry presented as a certification",
        ],
    ),
    (
        "cryptography-candidate-matrix",
        "Cryptography Candidate Matrix",
        "Record cryptographic candidates per language under a mandatory expert approval gate",
        ["algorithm coverage", "key compatibility", "native provider", "expert approval"],
        ["crypto_candidates.json", "approval_record.json", "matrix_notes.md"],
        [
            "A cryptographic replacement requires named expert approval, algorithm compatibility tests and historical data tests.",
            "Key format, key derivation and native provider compatibility are proved before any equivalence claim.",
            "No generated or model-designed algorithm, mode or padding scheme is ever admitted as a candidate.",
        ],
        [
            "a cryptographic replacement approved without a named security reviewer",
            "a candidate that cannot read data encrypted by the source implementation",
            "a novel algorithm or mode introduced by the conversion tool",
        ],
    ),
    (
        "version-drift-mutation-pack",
        "Version Drift Mutation Pack",
        "Mutate dependency versions and sources so drift detection is proved rather than assumed",
        ["minor bump", "major bump", "lockfile removal", "package source switch"],
        ["version_drift_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations include a minor bump, a major bump, lockfile removal, transitive version replacement and default feature activation.",
            "Package source switching and native artifact replacement are mutated separately from version numbers.",
            "Every mutation that changes observable behaviour must be caught by the dependency test suite.",
        ],
        [
            "a major version bump that no test detects",
            "a lockfile removal that still produces a green build",
            "a package source switch that no supply-chain check reports",
        ],
    ),
    (
        "configuration-default-mutation-pack",
        "Configuration Default Mutation Pack",
        "Mutate implicit configuration defaults so silent behaviour changes are proved detectable",
        ["timeout default", "retry default", "TLS verification", "pool sizing"],
        ["config_default_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations change timeout, retry count, TLS verification, cache enablement and unknown-field policy defaults.",
            "Connection pool size, timezone and logging level mutations are included because each changes observable behaviour.",
            "Disabling TLS verification must be caught by a security check and never only by a functional test.",
        ],
        [
            "retry silently changed from zero to three without a test failing",
            "TLS verification disabled while the suite still reports success",
            "a timezone default change that no temporal test detects",
        ],
    ),
    (
        "native-abi-mutation-pack",
        "Native ABI Mutation Pack",
        "Mutate native ABI facts so binary-level incompatibility is proved detectable",
        ["struct packing", "calling convention", "enum width", "allocator change"],
        ["abi_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations change struct packing, calling convention, enum width and exported symbol names.",
            "Runtime library, architecture, debug and release mixing, and allocator mutations are included.",
            "An ABI mutation that produces memory corruption must be caught by a sanitizer-instrumented run.",
        ],
        [
            "a struct packing change that produces silently wrong field values",
            "a debug and release mix that no build check rejects",
            "an allocator mismatch detected only in production",
        ],
    ),
    (
        "supply-chain-mutation-pack",
        "Supply Chain Mutation Pack",
        "Mutate supply chain facts so provenance and integrity checks are proved effective",
        ["source substitution", "hash change", "maintainer change", "signature invalidation"],
        ["supply_chain_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations replace the package source, change the artifact hash and change the recorded maintainer.",
            "A newly added install script, a replaced native binary and a new transitive dependency are each mutated separately.",
            "An invalidated signature must fail the build closed rather than emit a warning.",
        ],
        [
            "an artifact hash change that the lockfile check does not reject",
            "a newly added install script that no review step surfaces",
            "an invalid signature downgraded to a warning",
        ],
    ),
    (
        "license-mutation-pack",
        "License Mutation Pack",
        "Mutate licence facts so obligation detection is proved rather than trusted",
        ["copyleft transition", "notice obligation", "commercial restriction", "source offer"],
        ["license_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations move a permissive licence to copyleft, add a notice obligation and add a commercial restriction.",
            "Network copyleft introduction and closed-binary substitution for an open implementation are mutated separately.",
            "Removing source-offer material must fail the licence gate closed.",
        ],
        [
            "a copyleft transition that the licence gate does not block",
            "a new notice obligation absent from the generated notice file",
            "a closed binary substituted for an open implementation without review",
        ],
    ),
    (
        "dependency-e2-gate",
        "Dependency E2 Gate",
        "Gate the dependency layer at discovery and declared-surface completeness",
        ["discovery completeness", "lockfile consistency", "API surface", "baseline licence scan"],
        ["dep_e2_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "Every direct and transitive dependency is discovered and the lockfile is internally consistent.",
            "The used API surface is complete and every candidate replacement covers it.",
            "No unknown critical dependency remains and the baseline licence scan has completed.",
        ],
        [
            "a gate pass while a critical dependency is still unidentified",
            "a gate pass with an inconsistent lockfile",
            "a gate pass while part of the used API surface is uncovered",
        ],
    ),
    (
        "dependency-e3-gate",
        "Dependency E3 Gate",
        "Gate the dependency layer at contract differential and mutation evidence",
        ["contract differential", "data format", "error mapping", "closure completeness"],
        ["dep_e3_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "Replacement contract differential, data format and error mapping evidence are all present.",
            "Configuration differential and dependency mutation packs have run with no surviving mutant.",
            "The transitive closure is complete and no unexplained behaviour difference remains open.",
        ],
        [
            "a gate pass with a surviving dependency mutant",
            "a gate pass while an unexplained error mapping difference is open",
            "a gate pass on an incomplete transitive closure",
        ],
    ),
    (
        "dependency-e4-gate",
        "Dependency E4 Gate",
        "Gate the dependency layer at performance, platform, native and supply-chain evidence",
        ["performance evidence", "native ABI", "supply chain", "reproducible build"],
        ["dep_e4_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "Performance, concurrency and fault evidence are present on the real target platform.",
            "Native ABI verification, supply-chain security evidence, the licence gate and the SBOM are all complete.",
            "The build is reproducible and no resource leak remains unexplained.",
        ],
        [
            "a gate pass without native ABI evidence for a native dependency",
            "a gate pass on a build that is not reproducible",
            "a gate pass while a resource leak remains unexplained",
        ],
    ),
    (
        "dependency-e5-gate",
        "Dependency E5 Gate",
        "Gate the dependency layer at production shadow and sustained stability evidence",
        ["DR5 critical coverage", "production shadow", "sustained stability", "revocation state"],
        ["dep_e5_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "Every critical replacement carries a DR5 certification and production shadow evidence from real inputs.",
            "Sustained stable operation is measured over the declared window with no unexplained difference.",
            "No critical vulnerability, no blocking licence finding and no revoked certification is present.",
        ],
        [
            "a gate pass while a critical replacement sits below DR5",
            "a gate pass on a certification that has already been revoked",
            "a gate pass with a blocking licence finding still open",
        ],
    ),
    (
        "dependency-migration-orchestrator",
        "Dependency Migration Orchestrator",
        "Sequence the dependency migration from discovery through replacement certification and gates",
        ["phase sequencing", "risk gating", "capability closure", "blocking condition"],
        ["dependency_state_machine.json", "phase_transitions.json", "orchestration_runbook.md"],
        [
            "Discovery, transitive graph, used API extraction, capability model and risk scoring complete before candidate selection.",
            "No replacement advances past contract differential until its capability closure is proved complete.",
            "A critical dependency without DR5 evidence blocks the dependency layer regardless of other progress.",
        ],
        [
            "a candidate selected before the used API surface was extracted",
            "a replacement certified before its capability closure was proved",
            "a dependency layer level published while a critical replacement is uncertified",
        ],
    ),
    (
        "infrastructure-inventory-builder",
        "Infrastructure Inventory Builder",
        "Discover every external infrastructure resource the repository and production actually use",
        ["resource discovery", "endpoint resolution", "driver identification", "unresolved endpoint"],
        ["infrastructure_inventory.json", "endpoint_resolution.json", "inventory_notes.md"],
        [
            "Databases, replicas, shards, caches, search clusters, object storage, messaging and schema registries are all enumerated.",
            "Discovery draws on build dependencies, configuration, environment, containers, orchestration manifests, runtime traces and production logs.",
            "A production connection target absent from the inventory blocks the infrastructure layer closed.",
        ],
        [
            "a production endpoint reached at runtime but missing from the inventory",
            "a dynamic DNS or proxy target that could not be traced",
            "a driver or native client library whose version and origin are unknown",
        ],
    ),
    (
        "unified-infrastructure-resource-ir",
        "Unified Infrastructure Resource IR",
        "Describe every external infrastructure resource in one vendor-neutral representation",
        ["resource identity", "topology", "consistency model", "authentication and encryption"],
        ["infrastructure_resource_ir.json", "topology_model.json", "ir_notes.md"],
        [
            "Each resource records type, vendor, protocol, version, endpoint, region, replication, sharding and consistency.",
            "Authentication, encryption, driver, pool, timeout, retry and failover behaviour are part of the resource record.",
            "Read and write consistency are recorded separately because they are frequently different.",
        ],
        [
            "a resource whose protocol version was never determined",
            "read consistency inferred from write consistency",
            "a replica set recorded without its lag tolerance",
        ],
    ),
    (
        "driver-semantic-inventory",
        "Driver Semantic Inventory",
        "Extract the default and explicit behaviour of every source-side infrastructure driver",
        ["driver version", "default value", "synchrony model", "type mapping"],
        ["driver_inventory.json", "driver_defaults.json", "inventory_notes.md"],
        [
            "Driver name, version, protocol version, synchrony, thread safety and connection model are recorded verbatim.",
            "Default timeout, retry, auto-commit, prepare behaviour, type mapping, error types, cancellation and failover are captured per driver.",
            "Two drivers reaching the same server are never assumed to share a default.",
        ],
        [
            "a target driver default assumed equal to the source driver default",
            "a driver whose auto-commit behaviour was never determined",
            "a driver whose decimal and temporal mappings were never captured",
        ],
    ),
]

SKILLS[133] = [
    (
        "protocol-command-ir-builder",
        "Protocol Command IR Builder",
        "Lower every driver call to the protocol-level command sequence it actually issues",
        ["command lowering", "command sequence", "protocol vocabulary", "sequence equivalence"],
        ["protocol_command_ir.json", "command_sequences.json", "ir_notes.md"],
        [
            "Database commands cover connect, authenticate, prepare, bind, execute, fetch, begin, commit, rollback, cancel and close.",
            "Cache, search and messaging command vocabularies are modelled with the same fidelity as the database vocabulary.",
            "Equivalence is claimed on the command sequence, not on the returned value alone.",
        ],
        [
            "two drivers judged equivalent while issuing different command sequences",
            "a client-side prepare treated as a server-side prepare",
            "a pipelined command batch flattened into one logical command",
        ],
    ),
    (
        "connection-lifecycle-ir",
        "Connection Lifecycle IR",
        "Model a connection from name resolution through release with every timeout it passes",
        ["lifecycle stage", "stage timeout", "session reset", "leak detection"],
        ["connection_lifecycle_ir.json", "stage_timeouts.json", "lifecycle_notes.md"],
        [
            "Stages cover DNS, TCP connect, TLS, authentication, session initialisation, pool checkout, execution, reset, return and close.",
            "DNS, connect, TLS, authentication, idle and maximum-lifetime timeouts are recorded independently per stage.",
            "Session reset, broken connection removal and shutdown drain behaviour are proved, not assumed.",
        ],
        [
            "one aggregate timeout substituted for the per-stage timeouts",
            "a session variable surviving a pool return",
            "a broken connection returned to the pool and reused",
        ],
    ),
    (
        "connection-pool-semantic-verifier",
        "Connection Pool Semantic Verifier",
        "Verify pool sizing, fairness, leak detection and cancellation-time return behaviour",
        ["pool sizing", "acquisition fairness", "leak detection", "cancellation return"],
        ["pool_semantics.json", "pool_differential.json", "verifier_notes.md"],
        [
            "Minimum size, maximum size, acquisition timeout, idle timeout, maximum lifetime and validation are compared explicitly.",
            "Queue fairness, leak detection, fail-fast and backpressure behaviour are measured under saturation.",
            "A cancelled request must return its connection to the pool in every language.",
        ],
        [
            "a pool migrated to a language where no maximum size is configured",
            "a connection leaked on the exception path",
            "an awaited operation abandoned without awaiting, leaking its connection",
        ],
    ),
    (
        "infrastructure-context-cancellation-view",
        "Infrastructure Context and Cancellation View",
        "Project the context propagation model onto deadlines and cancellation at the infrastructure boundary",
        ["deadline propagation", "server-side cancellation", "post-cancel state", "resource release"],
        ["infrastructure_context_view.json", "cancellation_outcomes.json", "view_notes.md"],
        [
            "Request deadline, driver timeout and server-side timeout are recorded separately and reconciled.",
            "Query, socket, transaction, consumption and upload cancellation outcomes are each measured, not inferred.",
            "Post-cancellation resource state is verified: whether the query still runs, the transaction rolled back and the connection is reusable.",
        ],
        [
            "a cancelled query still executing on the server",
            "a cancelled upload leaving orphaned parts behind",
            "a cancelled consumption that still acknowledged the message",
        ],
    ),
    (
        "infrastructure-retry-ir",
        "Infrastructure Retry IR",
        "Model which layer retries, under what condition and with what idempotency protection",
        ["retry layer", "retry condition", "backoff and jitter", "idempotency key"],
        ["infrastructure_retry_ir.json", "retry_amplification.json", "ir_notes.md"],
        [
            "The retrying layer, condition, maximum attempts, backoff, jitter and node reselection are recorded per operation.",
            "Whether the idempotency key is preserved, the transaction rebuilt and the request body replayable is recorded explicitly.",
            "Non-idempotent payments, unknown commit outcomes, unprotected writes, partially sent streams and unreplayable messages are never retried automatically.",
        ],
        [
            "an unknown commit outcome retried blindly",
            "a driver retry stacked on an application retry without a shared budget",
            "a retry that regenerates its idempotency key",
        ],
    ),
    (
        "infrastructure-failure-taxonomy",
        "Infrastructure Failure Taxonomy",
        "Classify every infrastructure failure into one enumerated cross-vendor taxonomy",
        ["failure class", "retryability", "transaction state", "partial success"],
        ["failure_taxonomy.json", "classification_rules.json", "taxonomy_notes.md"],
        [
            "The taxonomy enumerates connection, authentication, capacity, timeout, contention, topology, integrity and quota failure classes.",
            "Unknown commit result, partial write and replica lag are distinct classes and never merged with a generic error.",
            "Every class declares retryability, transaction state implication and whether partial success is possible.",
        ],
        [
            "an unknown commit result classified as a plain timeout",
            "a serialization failure merged with a deadlock",
            "a rate limit classified as a server error and retried immediately",
        ],
    ),
    (
        "infrastructure-error-normalizer",
        "Infrastructure Error Normalizer",
        "Normalise nine languages of driver errors into the taxonomy without losing evidence",
        ["error normalisation", "vendor code", "cause chain", "state preservation"],
        ["error_normalization_map.json", "normalized_errors.json", "normalizer_notes.md"],
        [
            "Java, .NET, Python, Rust, Go, Node, native, Foundation and Swift driver errors all map into one taxonomy.",
            "Vendor code, SQL state, HTTP status, protocol code and server node identity are preserved after normalisation.",
            "Retryability, transaction state, partial success and the cause chain survive normalisation intact.",
        ],
        [
            "an exception hierarchy flattened to a single error type",
            "a vendor error code discarded during normalisation",
            "a transaction state lost when the error crossed a language boundary",
        ],
    ),
    (
        "cross-infrastructure-data-type-ir",
        "Cross-Infrastructure Data Type IR",
        "Enumerate the full external data type space independently of any one backend",
        ["type category", "range and precision", "nullability", "vendor spelling"],
        ["data_type_ir.json", "type_capability_matrix.json", "ir_notes.md"],
        [
            "The type space covers integers of every width and signedness, arbitrary integers, decimal, float, boolean, string and binary.",
            "Identifier, temporal, duration, interval, enum, document, array, range, geospatial, vector and null types are all enumerated.",
            "A vendor spelling never defines a type; the observable range, precision and ordering do.",
        ],
        [
            "two vendor types treated as identical because they share a name",
            "an unsigned column mapped to a signed language type without a range check",
            "a type admitted to the IR without its ordering semantics",
        ],
    ),
    (
        "integer-mapping-verifier",
        "Integer Mapping Verifier",
        "Verify integer width, signedness and overflow behaviour end to end",
        ["bit width", "signedness", "overflow behaviour", "safe integer range"],
        ["integer_mapping.json", "boundary_results.json", "verifier_notes.md"],
        [
            "Column width, driver return type, language type and serialised form are compared for every integer column.",
            "Maximum, minimum, above thirty-two bits, above fifty-three bits, negative and unsigned upper-bound values are all tested.",
            "Auto-increment overflow and unsigned database types are verified explicitly rather than assumed representable.",
        ],
        [
            "a sixty-four bit identifier silently truncated by a language safe-integer limit",
            "an unsigned upper-bound value mapped to a negative signed value",
            "an auto-increment overflow that produces a duplicate key",
        ],
    ),
    (
        "decimal-and-monetary-type-verifier",
        "Decimal and Monetary Type Verifier",
        "Verify decimal precision, scale and rounding without any binary floating-point path",
        ["precision and scale", "rounding mode", "aggregate fidelity", "float prohibition"],
        ["decimal_mapping.json", "rounding_results.json", "verifier_notes.md"],
        [
            "Precision, scale, rounding mode, trailing zero and negative zero behaviour are compared across driver, parameter and serialised forms.",
            "Aggregate results, comparisons and index ordering are verified for decimal columns, not only single-value reads.",
            "A monetary value never passes through a binary floating-point type in any language on any path.",
        ],
        [
            "a monetary amount converted to a double-precision float in transit",
            "a rounding mode difference that changes a total",
            "a trailing zero difference that changes an equality comparison",
        ],
    ),
    (
        "date-time-and-timezone-verifier",
        "Date, Time and Timezone Verifier",
        "Verify temporal fidelity across database, session, driver and language timezone layers",
        ["timezone layer", "precision truncation", "DST boundary", "sentinel date"],
        ["temporal_mapping.json", "boundary_results.json", "verifier_notes.md"],
        [
            "Database, session, server, driver and language timezone settings are recorded separately and reconciled.",
            "Timestamp with and without timezone, precision, monotonic time and calendar interval semantics are compared explicitly.",
            "Duplicated and skipped DST instants, month ends, leap years, UTC day boundaries and precision truncation are all tested.",
        ],
        [
            "a timestamp read back in a different timezone than it was written",
            "a microsecond value truncated to milliseconds without a decision record",
            "a sentinel infinity or zero date that the target type cannot represent",
        ],
    ),
    (
        "string-collation-and-encoding-verifier",
        "String, Collation and Encoding Verifier",
        "Verify encoding, collation and comparison semantics for every text column",
        ["encoding", "collation", "case and accent sensitivity", "length semantics"],
        ["string_semantics.json", "collation_results.json", "verifier_notes.md"],
        [
            "Database encoding, collation, case sensitivity, accent sensitivity and normalisation form are recorded per column.",
            "Length measured in bytes and in characters are distinguished, and trailing space and null byte handling are compared.",
            "Sort order, unique constraint outcome, pattern matching and case-insensitive comparison are compared, not just round-trip equality.",
        ],
        [
            "a unique constraint that accepts a duplicate after the collation changed",
            "a length limit measured in characters on one side and bytes on the other",
            "an invalid byte sequence silently replaced during a round trip",
        ],
    ),
    (
        "binary-and-large-object-verifier",
        "Binary and Large Object Verifier",
        "Verify binary and large object handling including streaming and buffer ownership",
        ["buffer ownership", "streaming read", "size limit", "resource close"],
        ["binary_semantics.json", "streaming_results.json", "verifier_notes.md"],
        [
            "Byte array, large binary and large text handling are compared including maximum size and chunk boundaries.",
            "Buffer ownership and lifetime are proved for every language so no borrowed buffer is reused after release.",
            "Partial read, resume, transaction scope, memory materialisation and explicit close behaviour are all verified.",
        ],
        [
            "a large object fully materialised in memory on the target side",
            "a buffer reused after the driver reclaimed it",
            "a large object handle left open after the transaction ended",
        ],
    ),
    (
        "json-and-document-type-verifier",
        "JSON and Document Type Verifier",
        "Verify document type fidelity including key order, numbers and absence semantics",
        ["key ordering", "numeric fidelity", "absence semantics", "query operator"],
        ["document_semantics.json", "document_results.json", "verifier_notes.md"],
        [
            "Text and binary document column variants are distinguished, and key order preservation is recorded per variant.",
            "Number, decimal, missing key, explicit null, array order and duplicate key handling are compared explicitly.",
            "Index behaviour, query semantics, update operators and the driver object model are verified, not only value round trips.",
        ],
        [
            "a document whose key order changed and broke a downstream signature",
            "a decimal value degraded to a double inside a document",
            "an explicit null read back as a missing key",
        ],
    ),
    (
        "enum-and-unknown-value-verifier",
        "Enum and Unknown Value Verifier",
        "Verify enum representation and forward-compatible handling of unknown values",
        ["representation", "unknown value", "forward compatibility", "migration path"],
        ["enum_semantics.json", "unknown_value_results.json", "verifier_notes.md"],
        [
            "Database enum, string enum and numeric enum representations are recorded separately with their case handling.",
            "Unknown value behaviour is defined explicitly: rejected, preserved or mapped, and never silently defaulted.",
            "Enum migration is proved compatible with readers and writers on both sides during the transition window.",
        ],
        [
            "an unknown enum value silently coerced to the first variant",
            "an enum migration that breaks an old reader",
            "a generated enum type whose ordinal values differ from the source",
        ],
    ),
    (
        "uuid-and-identifier-verifier",
        "UUID and Identifier Verifier",
        "Verify identifier representation, byte order and sort behaviour across systems",
        ["storage form", "byte order", "generation site", "sort order"],
        ["identifier_semantics.json", "identifier_results.json", "verifier_notes.md"],
        [
            "Binary and text storage forms, byte order, case and hyphenation are recorded per identifier column.",
            "Version, generation site and index behaviour are recorded, and generation site changes require a decision record.",
            "Sort order and cross-service serialised form are compared because a storage change can reorder existing rows.",
        ],
        [
            "an identifier whose byte order changed and reordered an index",
            "an identifier generated on the server on one side and the client on the other",
            "an identifier serialised in a different case across a service boundary",
        ],
    ),
]

BATCHES.update({
    134: {
        "title": "Relational Transaction and Query Semantics Pack",
        "why": "Moves ELMOS from running the same SQL to proving the same transactional, locking and result semantics underneath it.",
        "purpose": "model the relational transaction state machine, verify isolation, auto-commit, savepoint, locking and retry semantics, then prove prepared statement, batch, affected-row, generated-key, dialect, ordering, pagination and migration behaviour on both sides.",
        "tooling": ["transaction state machine", "isolation anomaly harness", "dialect mapping verifier", "migration verifier"],
    },
    135: {
        "title": "Vendor Database and Cache Semantics Pack",
        "why": "Moves ELMOS from a generic database abstraction to per-vendor semantics and then into the cache layer with its own consistency model.",
        "purpose": "carry vendor-specific relational, document and distributed database semantics into the differential, then model the cache layer end to end — key contracts, expiration, serialization, atomicity, stampede protection and consistency strategy.",
        "tooling": ["vendor database packs", "distributed consistency harness", "cache semantic IR", "stampede and atomicity harness"],
    },
})

SKILLS[134] = [
    (
        "array-range-and-composite-type-verifier",
        "Array, Range and Composite Type Verifier",
        "Verify structured column types including arrays, ranges and composites",
        ["dimensionality", "boundary inclusivity", "empty versus null", "custom codec"],
        ["structured_type_semantics.json", "structured_results.json", "verifier_notes.md"],
        [
            "Array, range, composite, tuple and multidimensional array mappings are recorded per language.",
            "Empty and null are distinguished for every structured type, and boundary inclusivity is recorded per range.",
            "Custom codecs are inventoried because a missing codec turns a structured value into an opaque string.",
        ],
        [
            "an empty array read back as null",
            "an exclusive range boundary read back as inclusive",
            "a composite type degraded to its text representation",
        ],
    ),
    (
        "geospatial-and-vector-type-verifier",
        "Geospatial and Vector Type Verifier",
        "Verify geospatial and vector semantics including coordinate order and similarity metric",
        ["coordinate order", "spatial reference", "vector dimension", "similarity metric"],
        ["spatial_vector_semantics.json", "spatial_results.json", "verifier_notes.md"],
        [
            "Coordinate order, spatial reference identifier, unit and distance function are recorded per geospatial column.",
            "Vector dimension, element precision, normalisation and similarity metric are recorded per vector column.",
            "The driver binary format is captured because a coordinate order swap produces plausible but wrong results.",
        ],
        [
            "a latitude and longitude pair swapped by a coordinate order difference",
            "a distance computed in a different unit than the source system used",
            "a vector search whose similarity metric silently changed",
        ],
    ),
    (
        "unified-relational-transaction-ir",
        "Unified Relational Transaction IR",
        "Model the relational transaction as one explicit state machine with an unknown state",
        ["transaction state", "isolation declaration", "unknown outcome", "after-commit action"],
        ["transaction_ir.json", "state_machine.json", "ir_notes.md"],
        [
            "States cover idle, active, marked for rollback, committing, committed, rolling back, rolled back and unknown.",
            "Begin, auto-commit, isolation, read-only, deferrable, savepoint, lock and statement facts are recorded per transaction.",
            "Unknown is a first-class terminal state that requires reconciliation and is never collapsed into rolled back.",
        ],
        [
            "an unknown commit outcome recorded as rolled back",
            "an after-commit action executed before the commit was confirmed",
            "a transaction whose isolation level was never declared",
        ],
    ),
    (
        "isolation-level-semantic-verifier",
        "Isolation Level Semantic Verifier",
        "Verify what each isolation level actually prevents on each specific engine",
        ["anomaly coverage", "vendor divergence", "level naming", "measured guarantee"],
        ["isolation_semantics.json", "anomaly_results.json", "verifier_notes.md"],
        [
            "Dirty read, non-repeatable read, phantom, write skew, lost update, read skew and fractured read are each exercised.",
            "The measured guarantee is recorded per engine because identically named levels differ between engines.",
            "A level name is never accepted as evidence; only the measured anomaly set is.",
        ],
        [
            "an isolation level assumed equivalent because it shares a name",
            "write skew possible on the target while the source prevented it",
            "an isolation claim recorded without an anomaly test result",
        ],
    ),
    (
        "auto-commit-behavior-verifier",
        "Auto-Commit Behavior Verifier",
        "Verify implicit transaction boundaries and post-error transaction state",
        ["default mode", "implicit DDL commit", "post-error state", "pool return rollback"],
        ["autocommit_semantics.json", "autocommit_results.json", "verifier_notes.md"],
        [
            "The default auto-commit mode is measured per driver rather than read from documentation.",
            "Implicit commit on schema change, single-statement transaction scope and post-error transaction state are compared.",
            "Rollback before pool return is proved so no partial transaction is inherited by the next borrower.",
        ],
        [
            "a target driver that opens a transaction implicitly where the source did not",
            "a schema change that commits an in-flight transaction unexpectedly",
            "an aborted transaction inherited by the next pool borrower",
        ],
    ),
    (
        "savepoint-semantic-verifier",
        "Savepoint Semantic Verifier",
        "Verify nested transaction mapping onto savepoints and post-error continuation",
        ["nesting mapping", "savepoint naming", "release semantics", "post-error continuation"],
        ["savepoint_semantics.json", "savepoint_results.json", "verifier_notes.md"],
        [
            "Nested transaction constructs are mapped explicitly onto savepoint operations with their naming rules.",
            "Rollback to savepoint, release and post-error continuation are verified on both sides.",
            "Connection loss during a nested transaction is exercised because recovery differs by engine and driver.",
        ],
        [
            "a nested transaction that silently becomes a no-op",
            "a savepoint name collision inside a recursive call",
            "a transaction assumed continuable after an error that invalidated it",
        ],
    ),
    (
        "locking-semantic-verifier",
        "Locking Semantic Verifier",
        "Verify lock granularity, acquisition modifiers and release timing",
        ["lock granularity", "acquisition modifier", "lock timeout", "release timing"],
        ["locking_semantics.json", "locking_results.json", "verifier_notes.md"],
        [
            "Row, table, gap, predicate and advisory lock behaviour are compared per engine and per statement form.",
            "Explicit lock requests with no-wait and skip-locked modifiers are exercised, not only the default form.",
            "Lock timeout, deadlock detection and release timing are measured rather than assumed identical.",
        ],
        [
            "a gap lock present on one engine and absent on the other",
            "a skip-locked queue that starts returning already-claimed rows",
            "an advisory lock released at a different point in the transaction",
        ],
    ),
    (
        "deadlock-and-serialization-retry-verifier",
        "Deadlock and Serialization Retry Verifier",
        "Distinguish contention failures from network failures and retry them correctly",
        ["failure discrimination", "transaction rebuild", "idempotency preservation", "attempt bound"],
        ["contention_retry.json", "retry_results.json", "verifier_notes.md"],
        [
            "Deadlock victim, serialization failure, lock timeout, network failure and unknown commit are discriminated before any retry.",
            "A retry rebuilds the transaction, re-reads state and reuses the same business idempotency key.",
            "Attempts are bounded and every business invariant is re-checked after the final attempt.",
        ],
        [
            "a serialization failure retried without re-reading state",
            "an unknown commit outcome retried as if it were a deadlock",
            "an unbounded retry loop under sustained contention",
        ],
    ),
    (
        "prepared-statement-verifier",
        "Prepared Statement Verifier",
        "Verify statement preparation site, parameter typing and plan lifetime",
        ["preparation site", "parameter typing", "plan cache", "schema invalidation"],
        ["prepared_statement_semantics.json", "statement_results.json", "verifier_notes.md"],
        [
            "Client-side and server-side preparation are distinguished per driver and per statement.",
            "Parameter type inference, null typing and binary protocol usage are compared explicitly.",
            "Plan cache scope, connection binding, statement lifetime and schema-change invalidation are all verified.",
        ],
        [
            "a client-side prepare presented as a server-side prepare",
            "a null parameter whose inferred type differs between sides",
            "a cached plan surviving a schema change that invalidated it",
        ],
    ),
    (
        "batch-and-bulk-operation-verifier",
        "Batch and Bulk Operation Verifier",
        "Verify batch atomicity, partial success reporting and generated key correlation",
        ["batch atomicity", "partial success", "error position", "key correlation"],
        ["batch_semantics.json", "batch_results.json", "verifier_notes.md"],
        [
            "Batch atomicity is measured per driver rather than assumed, and partial success is reported item by item.",
            "Generated identifiers are correlated back to their input rows and the error position is preserved.",
            "Row counts, transaction scope, memory use, packet size limits, retry behaviour and ordering are all compared.",
        ],
        [
            "a partially applied batch reported as a total failure",
            "generated keys returned without a correlation to input rows",
            "a batch retried whole after some items already succeeded",
        ],
    ),
    (
        "affected-rows-semantic-verifier",
        "Affected Rows Semantic Verifier",
        "Verify what an affected-row count means on each engine and driver",
        ["matched versus changed", "upsert count", "trigger effect", "concurrency check"],
        ["affected_rows_semantics.json", "row_count_results.json", "verifier_notes.md"],
        [
            "Matched rows and changed rows are distinguished per engine because drivers report different ones by default.",
            "Insert, upsert, trigger and cascade contributions to the count are recorded separately.",
            "Any optimistic concurrency check built on a row count is re-proved against the target semantics.",
        ],
        [
            "an optimistic concurrency check broken by a matched versus changed difference",
            "an upsert count interpreted as an insert count",
            "a trigger-affected row counted on one side only",
        ],
    ),
    (
        "generated-key-verifier",
        "Generated Key Verifier",
        "Verify identifier generation, retrieval and post-rollback sequence behaviour",
        ["generation mechanism", "retrieval form", "batch key retrieval", "post-rollback gap"],
        ["generated_key_semantics.json", "key_results.json", "verifier_notes.md"],
        [
            "Sequence, identity, auto-increment, returning-clause and trigger-generated mechanisms are distinguished.",
            "Batch key retrieval and connection-scoped last-identifier calls are verified for correctness under concurrency.",
            "Post-rollback sequence gaps and identifier sort order are recorded because downstream systems often depend on both.",
        ],
        [
            "a connection-scoped last-identifier call used under a shared pool",
            "an identifier ordering assumption broken by a generation change",
            "a sequence gap after rollback treated as data loss",
        ],
    ),
    (
        "sql-dialect-mapping-verifier",
        "SQL Dialect Mapping Verifier",
        "Verify dialect translation for every construct the repository actually uses",
        ["identifier quoting", "upsert and merge", "window and CTE", "null comparison"],
        ["dialect_mapping.json", "dialect_results.json", "verifier_notes.md"],
        [
            "Identifier quoting, limit and offset, returning, upsert, merge, common table expression and window forms are mapped explicitly.",
            "Document operators, array operators, date functions, string concatenation and boolean handling are mapped per dialect.",
            "Null comparison and lock syntax are verified because their translation changes result sets silently.",
        ],
        [
            "an upsert translated into a form with different conflict semantics",
            "a case-folding difference in unquoted identifiers",
            "a null comparison whose truth value changed across dialects",
        ],
    ),
    (
        "query-result-ordering-verifier",
        "Query Result Ordering Verifier",
        "Prove that no result order is assumed without an explicit deterministic ordering",
        ["explicit ordering", "null ordering", "tie breaker", "plan sensitivity"],
        ["ordering_semantics.json", "ordering_results.json", "verifier_notes.md"],
        [
            "A query without an explicit ordering clause is never assumed to return a stable order on either side.",
            "Null ordering, collation-driven ordering and tie-breaker presence are recorded per query.",
            "Ordering is re-verified under parallel execution and after index changes because both can reorder results.",
        ],
        [
            "a page boundary that depends on an unspecified order",
            "a null-ordering difference that moves rows between pages",
            "a result order that changed after an index was added",
        ],
    ),
    (
        "pagination-semantic-verifier",
        "Pagination Semantic Verifier",
        "Verify pagination correctness under concurrent writes and cursor field changes",
        ["pagination strategy", "stable ordering", "duplicate and gap", "cursor encoding"],
        ["pagination_semantics.json", "pagination_results.json", "verifier_notes.md"],
        [
            "Offset, keyset and cursor pagination are distinguished and each carries its own stability requirement.",
            "Duplicate and missing rows are measured under concurrent insert, update and delete traffic.",
            "Null cursor fields and collation-sensitive cursor comparison are exercised explicitly.",
        ],
        [
            "a keyset cursor with a nullable field and no defined ordering for nulls",
            "rows duplicated across pages during concurrent writes",
            "a cursor encoding that is not portable across the two implementations",
        ],
    ),
    (
        "database-migration-verifier",
        "Database Migration Verifier",
        "Verify schema migration ordering, locking and online compatibility",
        ["migration ordering", "lock impact", "expand and contract", "rollback path"],
        ["migration_plan.json", "migration_results.json", "verifier_notes.md"],
        [
            "Migration ordering, transactional schema change support and lock impact are recorded per migration step.",
            "Backfill, default value, nullability, index, trigger and schema version changes are verified for online safety.",
            "Every migration follows expand and contract so old and new readers both work during the transition.",
        ],
        [
            "a migration that takes a blocking lock on a hot table",
            "a column dropped while an old reader is still deployed",
            "a migration with no verified rollback path",
        ],
    ),
]

SKILLS[135] = [
    (
        "postgresql-pack",
        "PostgreSQL Pack",
        "Carry PostgreSQL-specific capability and risk facts into the differential",
        ["MVCC behaviour", "rich type support", "session state", "replication mode"],
        ["postgresql_capabilities.json", "postgresql_risks.json", "pack_notes.md"],
        [
            "Multi-version concurrency behaviour, binary document type, array, range, enum and returning-clause semantics are recorded.",
            "Advisory locks, notification channels, extensions, generated columns, partial indexes and transactional schema change are covered.",
            "Search path, session timezone, extension version, prepared plan reuse, replica routing and large object handling are treated as risks.",
        ],
        [
            "a query whose result depends on an unpinned search path",
            "an enum migration that breaks a deployed reader",
            "a serializable retry loop absent on the target side",
        ],
    ),
    (
        "mysql-and-mariadb-pack",
        "MySQL and MariaDB Pack",
        "Carry MySQL family capability and risk facts into the differential",
        ["gap locking", "default isolation", "sentinel date", "affected row reporting"],
        ["mysql_capabilities.json", "mysql_risks.json", "pack_notes.md"],
        [
            "Storage engine behaviour, gap locking, auto-increment allocation and default isolation semantics are recorded.",
            "Sentinel zero dates, unsigned types, collation defaults and duplicate-key upsert semantics are covered.",
            "Implicit commit on schema change, read and write splitting and replication log dependence are treated as risks.",
        ],
        [
            "a gap lock absent after migrating to a different engine",
            "a zero date that the target type cannot represent",
            "an affected-row count interpreted with the wrong reporting mode",
        ],
    ),
    (
        "sql-server-pack",
        "SQL Server Pack",
        "Carry SQL Server capability and risk facts into the differential",
        ["temporal type family", "row versioning", "snapshot isolation", "multiple result sets"],
        ["sqlserver_capabilities.json", "sqlserver_risks.json", "pack_notes.md"],
        [
            "The distinct temporal type family, decimal handling, identity allocation and row-version columns are recorded.",
            "Snapshot isolation, multiple active result sets, table-valued parameters and lock hints are covered.",
            "Merge-statement risks, ambient transaction scope and stored procedure return semantics are recorded as risks.",
        ],
        [
            "a legacy temporal type mapped to a higher-precision type without a decision record",
            "a merge statement translated into a non-atomic sequence",
            "a stored procedure return value confused with its result set",
        ],
    ),
    (
        "oracle-pack",
        "Oracle Pack",
        "Carry Oracle capability and risk facts into the differential",
        ["empty string as null", "numeric model", "cursor handling", "locale settings"],
        ["oracle_capabilities.json", "oracle_risks.json", "pack_notes.md"],
        [
            "Empty string treated as null, the single numeric type model and date and timestamp distinctions are recorded.",
            "Sequences, triggers, packages, reference cursors, autonomous transactions and array binding are covered.",
            "Locale and national language settings are recorded because they change comparison, sorting and formatting.",
        ],
        [
            "an empty string that becomes null and breaks a not-null assumption",
            "a numeric value whose precision is unrepresentable on the target",
            "a reference cursor left open after the call returned",
        ],
    ),
    (
        "sqlite-pack",
        "SQLite Pack",
        "Carry embedded database capability and risk facts into the differential",
        ["single writer", "type affinity", "journal mode", "thread mode"],
        ["sqlite_capabilities.json", "sqlite_risks.json", "pack_notes.md"],
        [
            "File locking, single-writer concurrency, write-ahead journal mode and busy timeout behaviour are recorded.",
            "Type affinity, transaction mode, foreign key enforcement toggling and date storage conventions are covered.",
            "Thread mode and in-memory database scope are recorded because both change concurrency behaviour materially.",
        ],
        [
            "concurrent writers assumed supported after migration",
            "a foreign key constraint silently unenforced because enforcement was off",
            "a value stored under a different affinity than the source used",
        ],
    ),
    (
        "document-and-nosql-database-pack",
        "Document and NoSQL Database Pack",
        "Carry document, wide-column, key-value and time-series semantics into the differential",
        ["document identity", "absence semantics", "concern levels", "pagination token"],
        ["nosql_capabilities.json", "nosql_risks.json", "pack_notes.md"],
        [
            "Document identity, schema flexibility and the distinction between explicit null and missing are recorded.",
            "Update operators, single-document atomicity, multi-document transactions, read and write concern levels are covered.",
            "Consistency level, time-to-live behaviour, secondary index limits and pagination token semantics are recorded.",
        ],
        [
            "an explicit null and a missing field merged into one state",
            "a multi-document write assumed atomic",
            "a pagination token that is not portable between drivers",
        ],
    ),
    (
        "mongodb-semantic-pack",
        "MongoDB Semantic Pack",
        "Carry document database type and session semantics into the differential",
        ["binary type system", "decimal handling", "session and concern", "change stream"],
        ["mongodb_capabilities.json", "mongodb_risks.json", "pack_notes.md"],
        [
            "The binary type system, generated object identifiers, high-precision decimal and date handling are recorded.",
            "Update operators, array operators, sessions, read concern, write concern and retryable write behaviour are covered.",
            "Change stream resumption and shard key implications are recorded because both constrain the target design.",
        ],
        [
            "a high-precision decimal degraded to a double by the target driver",
            "a retryable write that is not idempotent at the business level",
            "a change stream resumed from a token the target driver cannot parse",
        ],
    ),
    (
        "distributed-database-consistency-pack",
        "Distributed Database Consistency Pack",
        "Carry distributed consistency guarantees into the differential explicitly",
        ["quorum model", "session guarantee", "clock uncertainty", "conflict resolution"],
        ["distributed_consistency.json", "consistency_results.json", "pack_notes.md"],
        [
            "Quorum, linearizable, eventual and session consistency modes are recorded per operation, not per cluster.",
            "Read-your-writes and monotonic read guarantees are proved by test rather than inherited from documentation.",
            "Clock uncertainty, leader election, replica lag, conflict resolution and cross-region transaction limits are recorded.",
        ],
        [
            "read-your-writes assumed after a driver or routing change",
            "a cross-region transaction assumed atomic",
            "a conflict resolution rule that differs from the source system",
        ],
    ),
    (
        "unified-cache-semantic-ir",
        "Unified Cache Semantic IR",
        "Describe cache behaviour in one representation covering policy, expiry and topology",
        ["key and value model", "expiry policy", "write policy", "topology"],
        ["cache_semantic_ir.json", "cache_policies.json", "ir_notes.md"],
        [
            "Key, value, time-to-live, expiry, eviction and consistency facts are recorded per cache namespace.",
            "Read policy, write policy, serialization form, atomic operations and locking are part of the record.",
            "Cluster topology and failover behaviour are recorded because both change correctness, not only performance.",
        ],
        [
            "a cache namespace with no declared consistency expectation",
            "an eviction policy discovered only after a production incident",
            "a cluster cache modelled as a single node",
        ],
    ),
    (
        "cache-key-contract-verifier",
        "Cache Key Contract Verifier",
        "Verify the cache key contract so a language change cannot silently invalidate or collide keys",
        ["key composition", "tenant isolation", "key version", "hash distribution"],
        ["cache_key_contract.json", "key_results.json", "verifier_notes.md"],
        [
            "Prefix, tenant component, version component, encoding and normalisation are declared per key family.",
            "Cluster hash tags and key length limits are recorded because both change slot distribution.",
            "Cross-tenant collision is proved impossible by construction rather than by convention.",
        ],
        [
            "a formatting change that misses every cached entry",
            "two tenants colliding on one key after normalisation changed",
            "old and new systems writing different keys for the same logical entry",
        ],
    ),
    (
        "ttl-and-expiration-verifier",
        "TTL and Expiration Verifier",
        "Verify expiration units, refresh behaviour and clock dependence",
        ["unit and base", "boundary value", "refresh trigger", "clock dependence"],
        ["expiration_semantics.json", "expiration_results.json", "verifier_notes.md"],
        [
            "Time units, absolute versus relative expiry and zero, negative and no-expiry values are all compared.",
            "Refresh on read, refresh on write and jitter behaviour are recorded per key family.",
            "Clock source, expiry event delivery and lazy deletion timing are verified because they change visible staleness.",
        ],
        [
            "a time-to-live unit change that extends expiry by three orders of magnitude",
            "a zero value meaning no expiry on one side and immediate expiry on the other",
            "refresh on read introduced where the source never refreshed",
        ],
    ),
    (
        "cache-serialization-verifier",
        "Cache Serialization Verifier",
        "Verify cached payload compatibility across the migration window",
        ["payload format", "version tag", "type fidelity", "cross-reader compatibility"],
        ["cache_serialization.json", "compatibility_results.json", "verifier_notes.md"],
        [
            "Payload format, compression, version tag and embedded class metadata are recorded per key family.",
            "Null, enum, decimal and temporal fidelity are verified through a full write and read cycle by both implementations.",
            "A language-private object format is only retained behind a compatibility adapter with a dated retirement plan.",
        ],
        [
            "a cached payload only the source language can deserialise",
            "an untagged payload format change that breaks a mixed deployment",
            "a decimal value degraded to a float inside a cached payload",
        ],
    ),
    (
        "cache-atomicity-verifier",
        "Cache Atomicity Verifier",
        "Verify conditional and multi-key atomic operations rather than assuming them",
        ["conditional set", "compare and swap", "multi-key atomicity", "expiry atomicity"],
        ["cache_atomicity.json", "atomicity_results.json", "verifier_notes.md"],
        [
            "Conditional set, compare and swap, and atomic increment behaviour are measured per implementation.",
            "Multi-key atomicity, scripted execution and transactional grouping are distinguished and never conflated.",
            "Whether a write and its expiry are applied atomically is verified, since a gap creates a persistent entry.",
        ],
        [
            "a compare and swap replaced by a plain set",
            "a pipeline treated as a transaction",
            "a write whose expiry was never applied after a partial failure",
        ],
    ),
    (
        "cache-stampede-verifier",
        "Cache Stampede Verifier",
        "Verify protection against correlated misses under real concurrency",
        ["single flight", "early refresh", "negative caching", "failure fallback"],
        ["stampede_protection.json", "stampede_results.json", "verifier_notes.md"],
        [
            "Single-flight, locking, probabilistic early refresh and serve-stale-while-revalidating strategies are recorded per key family.",
            "Jitter, negative caching and backpressure behaviour are measured under a synchronised expiry burst.",
            "Behaviour when the backing store fails is verified, including whether the failure is cached.",
        ],
        [
            "a synchronised expiry that sends every request to the backing store",
            "a missing negative cache that turns absent data into a hot query",
            "a backing store failure amplified by unbounded retry",
        ],
    ),
    (
        "cache-consistency-strategy-verifier",
        "Cache Consistency Strategy Verifier",
        "Verify the declared cache consistency strategy including its failure and race behaviour",
        ["strategy declaration", "write ordering", "invalidation path", "stale window"],
        ["cache_strategy.json", "strategy_results.json", "verifier_notes.md"],
        [
            "The strategy is declared explicitly as cache-aside, read-through, write-through, write-behind or refresh-ahead.",
            "Write ordering, invalidation, failure and retry paths are verified for the declared strategy, not a generic one.",
            "The maximum stale window is stated numerically and measured under concurrent write and invalidate traffic.",
        ],
        [
            "an invalidation that races a repopulating read and loses",
            "a write-behind buffer lost on shutdown",
            "a stale window that exceeds the declared bound",
        ],
    ),
    (
        "redis-semantic-pack",
        "Redis Semantic Pack",
        "Carry key-value server capability and risk facts into the differential",
        ["data structure coverage", "scripting and grouping", "cluster routing", "failover behaviour"],
        ["redis_capabilities.json", "redis_risks.json", "pack_notes.md"],
        [
            "String, hash, list, set, sorted set, stream and publish-subscribe semantics are recorded per usage site.",
            "Scripted execution, command grouping, pipelining, cluster slot routing and eviction policy are covered.",
            "Pipelining is recorded as not transactional and command grouping error handling is verified explicitly.",
        ],
        [
            "a pipeline relied upon for atomicity",
            "a multi-key command issued against a cluster without a shared slot",
            "a subscription silently lost after a reconnect",
        ],
    ),
]

BATCHES.update({
    136: {
        "title": "Distributed Locking, Search and Object Storage Entry Pack",
        "why": "Moves ELMOS from treating a keyed write as a lock and a search index as a database to modelling each with its own correctness rules.",
        "purpose": "prove distributed lock and cache failover safety, model the search layer from mapping and analysis through query, visibility, pagination, bulk and reindexing, then open the object storage layer with its resource model, key contract, metadata and consistency behaviour.",
        "tooling": ["distributed lock harness", "search semantic IR", "analyzer differential", "object storage IR"],
    },
    137: {
        "title": "Object Transfer and Messaging Semantics Pack",
        "why": "Moves ELMOS from single-shot object calls and broker feature lists to verified transfer, retention and delivery semantics.",
        "purpose": "verify multipart, streaming, versioning, authentication, compatibility, failure and retention behaviour for object storage, then project the messaging model onto the infrastructure layer and verify producer, consumer, serialization, ordering, delivery, acknowledgement, retry and rebalance semantics.",
        "tooling": ["multipart and streaming harness", "presigned credential verifier", "messaging differential", "rebalance harness"],
    },
})

SKILLS[136] = [
    (
        "distributed-lock-verifier",
        "Distributed Lock Verifier",
        "Verify distributed lock safety including ownership, fencing and partition behaviour",
        ["ownership token", "lease renewal", "fencing token", "partition safety"],
        ["distributed_lock_model.json", "lock_results.json", "verifier_notes.md"],
        [
            "Lock token, owner identity, lease duration and renewal path are recorded and verified per lock.",
            "A fencing token protects the guarded resource so a delayed holder cannot act after its lease expired.",
            "Setting an expiring key alone is never accepted as a reliable distributed lock.",
        ],
        [
            "a lock claimed reliable on the strength of an expiring key alone",
            "a lock released by a process that no longer owns it",
            "two holders acting simultaneously across a network partition",
        ],
    ),
    (
        "cache-failover-semantic-verifier",
        "Cache Failover Semantic Verifier",
        "Verify cache correctness across failover, promotion and reconnection",
        ["promotion behaviour", "write loss window", "reconnect path", "lock safety"],
        ["cache_failover.json", "failover_results.json", "verifier_notes.md"],
        [
            "Primary failure, replica promotion, stale read exposure and the write loss window are measured, not assumed.",
            "Client reconnection, command retry and partial pipeline success are verified during and after promotion.",
            "Lock safety across failover is proved because a promoted replica may not hold the lock state.",
        ],
        [
            "a lock that survives failover only in appearance",
            "a pipeline partially applied across a promotion",
            "an acknowledged write lost during promotion with no reconciliation",
        ],
    ),
    (
        "unified-search-semantic-ir",
        "Unified Search Semantic IR",
        "Describe search behaviour in one representation covering mapping, query and visibility",
        ["index model", "analysis chain", "query model", "visibility policy"],
        ["search_semantic_ir.json", "search_policies.json", "ir_notes.md"],
        [
            "Index, mapping, analyzer, tokenizer, document and routing facts are recorded per index.",
            "Refresh policy, query, score, sort, pagination, aggregation and alias facts are part of the record.",
            "Replica count and consistency behaviour are recorded because both change result completeness.",
        ],
        [
            "an index whose analysis chain was never captured",
            "a query modelled without its scoring configuration",
            "a visibility delay discovered only by a failing read-after-write test",
        ],
    ),
    (
        "search-mapping-verifier",
        "Search Mapping Verifier",
        "Verify field mapping decisions that silently change matching and aggregation",
        ["field type choice", "nested versus object", "dynamic mapping", "malformed handling"],
        ["search_mapping.json", "mapping_results.json", "verifier_notes.md"],
        [
            "Analysed text and exact keyword fields are distinguished for every field, with both recorded where both exist.",
            "Object, nested, flattened and vector field choices are compared because each changes query semantics.",
            "Null value handling, dynamic mapping, malformed tolerance, field limits and index options are recorded per field.",
        ],
        [
            "an analysed field used where an exact match was required",
            "a nested field flattened so cross-object matches become possible",
            "dynamic mapping creating fields the target index rejects",
        ],
    ),
    (
        "analyzer-and-tokenization-verifier",
        "Analyzer and Tokenization Verifier",
        "Verify the analysis chain token by token on both sides",
        ["token stream", "language rules", "synonym and stemming", "index versus search time"],
        ["analyzer_chain.json", "token_stream_results.json", "verifier_notes.md"],
        [
            "The full chain of tokenizer, case folding, stop words, stemming, synonyms and normalisation is compared token by token.",
            "Language-specific, edge n-gram, ideographic and Unicode handling are exercised with representative corpora.",
            "Index-time and search-time analyzers are compared separately because a mismatch between them is silent.",
        ],
        [
            "a stemming difference that changes which documents match",
            "a synonym set present at index time but absent at search time",
            "an ideographic tokenizer replaced by a whitespace tokenizer",
        ],
    ),
    (
        "search-query-semantic-verifier",
        "Search Query Semantic Verifier",
        "Compare query results on ranking and totals, not only on membership",
        ["query construct", "ranking comparison", "total hits", "aggregation parity"],
        ["search_query_semantics.json", "query_results.json", "verifier_notes.md"],
        [
            "Term, match, boolean, filter, range, prefix, wildcard, fuzzy, phrase, nested and vector constructs are all mapped.",
            "Comparison covers ordering, score, total hit count, pagination, highlighting and aggregation output.",
            "Minimum-should-match and function-score configuration are compared because both reshape the result set.",
        ],
        [
            "two queries judged equivalent on membership while ranking differs",
            "a total hit count that is exact on one side and approximate on the other",
            "an aggregation whose bucket boundaries changed",
        ],
    ),
    (
        "search-refresh-and-visibility-verifier",
        "Search Refresh and Visibility Verifier",
        "Verify indexing visibility delay and read-after-write behaviour",
        ["visibility delay", "refresh policy", "read after write", "forced refresh cost"],
        ["visibility_semantics.json", "visibility_results.json", "verifier_notes.md"],
        [
            "The near-real-time visibility delay is measured for both sides rather than assumed identical.",
            "Refresh policy and interval are recorded per write path, including bulk write paths.",
            "Read-after-write expectations are declared per use case and either satisfied or explicitly relaxed.",
        ],
        [
            "a read-after-write assumption that holds on one side only",
            "a forced refresh on every write introduced by the migration",
            "a replica serving a document the primary has not yet made visible",
        ],
    ),
    (
        "search-pagination-verifier",
        "Search Pagination Verifier",
        "Verify deep pagination correctness and context lifetime",
        ["pagination mode", "stable sort", "context lifetime", "score ties"],
        ["search_pagination.json", "pagination_results.json", "verifier_notes.md"],
        [
            "Offset, scrolling, search-after and point-in-time pagination modes are distinguished with their own guarantees.",
            "A stable tie-breaking sort is required for any cursor-based mode and verified under concurrent updates.",
            "Context creation, expiry and explicit close are verified so no reader context leaks.",
        ],
        [
            "a search-after cursor with no tie breaker",
            "a point-in-time context never closed",
            "documents skipped because an update moved them between pages",
        ],
    ),
    (
        "search-bulk-operation-verifier",
        "Search Bulk Operation Verifier",
        "Verify per-item bulk outcomes and safe retry of the failed subset",
        ["per-item outcome", "version conflict", "subset retry", "payload limit"],
        ["search_bulk_semantics.json", "bulk_results.json", "verifier_notes.md"],
        [
            "Every bulk response is inspected item by item and a partial success is never reported as a success.",
            "Version conflicts, retryable failures and permanent failures are discriminated before any retry.",
            "Only the failed subset is retried, with idempotent document identifiers and a payload size bound.",
        ],
        [
            "a bulk response checked only at the envelope level",
            "a whole bulk request retried after most items succeeded",
            "a version conflict retried until it overwrites a newer document",
        ],
    ),
    (
        "elasticsearch-and-opensearch-pack",
        "Elasticsearch and OpenSearch Pack",
        "Carry search engine capability and risk facts into the differential",
        ["template and alias", "lifecycle policy", "shard failure", "vector search"],
        ["search_engine_capabilities.json", "search_engine_risks.json", "pack_notes.md"],
        [
            "Mapping, analyzer, refresh, alias, index template and lifecycle policy facts are recorded per cluster.",
            "Bulk, scrolling, point-in-time, versioning and routing behaviour are covered with their version dependencies.",
            "Shard failure exposure, cluster health, security configuration and vector search support are recorded as risks.",
        ],
        [
            "an alias switch that leaves readers on the old index",
            "a routing value change that scatters previously colocated documents",
            "a vector search whose index parameters differ between clusters",
        ],
    ),
    (
        "search-failover-and-partial-result-verifier",
        "Search Failover and Partial Result Verifier",
        "Verify that incomplete search results are never presented as complete",
        ["shard availability", "partial result flag", "circuit breaker", "completeness exposure"],
        ["search_failover.json", "failover_results.json", "verifier_notes.md"],
        [
            "Shard unavailability, node relocation and timeout produce an explicit incompleteness signal on both sides.",
            "Circuit breaker trips and query cancellation are surfaced to the caller rather than silently absorbed.",
            "Result completeness is part of the response contract and compared in the differential.",
        ],
        [
            "a partial shard failure reported as a complete result",
            "a timed-out query returning whatever arrived without a flag",
            "a circuit breaker trip logged but not surfaced to the caller",
        ],
    ),
    (
        "search-reindexing-verifier",
        "Search Reindexing Verifier",
        "Verify reindexing correctness including dual write, alias switch and rollback",
        ["source and target parity", "dual write window", "alias switch", "progress and recovery"],
        ["reindex_plan.json", "reindex_results.json", "verifier_notes.md"],
        [
            "Source and target index parity is proved on documents, mapping and query results before any alias switch.",
            "The dual write window keeps both indexes current and its ordering guarantees are verified.",
            "Progress tracking, error recovery and a rehearsed rollback to the old alias target are required.",
        ],
        [
            "an alias switched before parity was proved",
            "a document written to the old index only during the dual write window",
            "a failed reindex with no path back to the previous index",
        ],
    ),
    (
        "unified-object-storage-ir",
        "Unified Object Storage IR",
        "Describe object storage behaviour in one vendor-neutral representation",
        ["container and key", "content and checksum", "encryption and retention", "storage class"],
        ["object_storage_ir.json", "storage_policies.json", "ir_notes.md"],
        [
            "Container, key, version, content, metadata, content type and checksum facts are recorded per object family.",
            "Encryption, retention, access control, region, storage class and lifecycle rules are part of the record.",
            "Multipart upload configuration is recorded per object family because part size changes checksum semantics.",
        ],
        [
            "an object family with no declared checksum expectation",
            "an encryption mode discovered only during a migration cutover",
            "a lifecycle rule that silently deletes objects the target still needs",
        ],
    ),
    (
        "object-key-semantic-verifier",
        "Object Key Semantic Verifier",
        "Verify object key encoding and normalisation so no key is silently rewritten",
        ["encoding", "normalisation", "separator handling", "reserved character"],
        ["object_key_contract.json", "key_results.json", "verifier_notes.md"],
        [
            "Path-like keys, percent encoding, Unicode normalisation and case handling are recorded per key family.",
            "Leading and trailing separator handling and prefix listing behaviour are compared explicitly.",
            "Key length limits and reserved characters are enforced before write rather than discovered on failure.",
        ],
        [
            "a key rewritten by a different normalisation form so the old object becomes unreachable",
            "a trailing separator that creates a distinct key on one side only",
            "a reserved character accepted on write and rejected on read",
        ],
    ),
    (
        "object-metadata-verifier",
        "Object Metadata Verifier",
        "Verify object metadata fidelity including header case and custom entries",
        ["standard header", "custom metadata", "case normalisation", "entity tag"],
        ["object_metadata.json", "metadata_results.json", "verifier_notes.md"],
        [
            "Content type, length, encoding, cache control and disposition headers are compared for every object family.",
            "Custom metadata keys are compared with their case normalisation rules recorded per implementation.",
            "Checksum and entity tag semantics are recorded because they differ between single and multipart uploads.",
        ],
        [
            "a custom metadata key whose case changed and broke a consumer",
            "a content type lost during the migration",
            "an entity tag treated as a content hash for a multipart object",
        ],
    ),
    (
        "object-consistency-verifier",
        "Object Consistency Verifier",
        "Verify read-after-write, listing and overwrite visibility guarantees",
        ["read after write", "list consistency", "overwrite visibility", "edge caching"],
        ["object_consistency.json", "consistency_results.json", "verifier_notes.md"],
        [
            "Read-after-write, listing, overwrite and delete visibility are each measured rather than inherited from documentation.",
            "Cross-region behaviour, versioning interaction and replication delay are recorded per bucket.",
            "Interaction with an edge cache is recorded because it can extend visibility delay well past the store's own.",
        ],
        [
            "a listing assumed to include an object that was just written",
            "an overwrite served stale by an edge cache",
            "a cross-region read assumed as consistent as a same-region read",
        ],
    ),
]

SKILLS[137] = [
    (
        "multipart-upload-verifier",
        "Multipart Upload Verifier",
        "Verify multipart upload correctness including orphan part cleanup",
        ["part sizing", "part checksum", "concurrent parts", "orphan cleanup"],
        ["multipart_semantics.json", "multipart_results.json", "verifier_notes.md"],
        [
            "Part size, part numbering, per-part checksum and upload identifier handling are compared explicitly.",
            "Concurrent part upload, retry of a single part and completion ordering are verified under injected failure.",
            "Abort and orphan part cleanup are proved so an interrupted upload never accrues cost or partial state.",
        ],
        [
            "an interrupted upload leaving parts that are never cleaned up",
            "a completion request that succeeds with parts in the wrong order",
            "a part retried without its original checksum",
        ],
    ),
    (
        "streaming-upload-and-download-verifier",
        "Streaming Upload and Download Verifier",
        "Verify streaming transfer including backpressure, resume and cancellation",
        ["backpressure", "range request", "resume", "resource close"],
        ["streaming_semantics.json", "streaming_results.json", "verifier_notes.md"],
        [
            "Buffering and backpressure behaviour are measured so a slow consumer cannot exhaust memory.",
            "Range requests, resume after interruption, chunked transfer and declared content length are compared.",
            "Cancellation and explicit close are verified so no stream or socket is left open on either path.",
        ],
        [
            "a download fully buffered in memory on the target side",
            "an interrupted download restarted from zero instead of resumed",
            "a cancelled stream leaving its connection open",
        ],
    ),
    (
        "object-versioning-and-delete-verifier",
        "Object Versioning and Delete Verifier",
        "Verify versioning, delete markers and permanent deletion semantics",
        ["version identity", "delete marker", "permanent delete", "retention interaction"],
        ["versioning_semantics.json", "versioning_results.json", "verifier_notes.md"],
        [
            "Version identifiers, delete markers and permanent deletion are distinguished in every code path.",
            "Restore, retention, legal hold and version listing behaviour are compared between implementations.",
            "Concurrent write behaviour and rollback to a previous version are verified explicitly.",
        ],
        [
            "a delete marker mistaken for a permanent deletion",
            "a permanent delete issued where the source only hid the object",
            "a retention lock bypassed by the target implementation",
        ],
    ),
    (
        "object-storage-authentication-verifier",
        "Object Storage Authentication Verifier",
        "Verify credential, signature and presigned URL semantics",
        ["credential source", "signature version", "presigned expiry", "addressing style"],
        ["object_auth_semantics.json", "auth_results.json", "verifier_notes.md"],
        [
            "Credential source, session token, assumed role and client certificate handling are recorded per client.",
            "Signature version, region binding, clock skew tolerance and addressing style are compared explicitly.",
            "Presigned URL scope and expiry are verified and no credential ever appears in a log or evidence bundle.",
        ],
        [
            "a presigned URL whose expiry lengthened after migration",
            "a signature version mismatch that only fails against one implementation",
            "a credential written into an evidence bundle",
        ],
    ),
    (
        "s3-compatible-storage-pack",
        "S3-Compatible Storage Pack",
        "Record which parts of a compatible API surface a given implementation truly honours",
        ["supported subset", "entity tag semantics", "error code parity", "listing pagination"],
        ["compatible_surface.json", "surface_gaps.json", "pack_notes.md"],
        [
            "The supported API subset is measured per implementation and recorded as a gap list, not a claim of parity.",
            "Entity tag semantics, multipart behaviour, presigned URLs, versioning and encryption support are verified individually.",
            "Compatibility with a protocol never implies behavioural identity with any particular implementation.",
        ],
        [
            "a compatible implementation assumed to match a reference implementation exactly",
            "an error code difference that breaks retry classification",
            "a listing pagination difference that silently truncates results",
        ],
    ),
    (
        "object-storage-failure-verifier",
        "Object Storage Failure Verifier",
        "Verify behaviour under transfer, quota, permission and visibility failures",
        ["transfer interruption", "checksum mismatch", "throttling", "eventual visibility"],
        ["object_failure_matrix.json", "failure_results.json", "verifier_notes.md"],
        [
            "Interrupted upload, partial upload and checksum mismatch are injected and their outcomes compared.",
            "Quota, permission, region redirect and throttling responses are classified into the failure taxonomy.",
            "Object-not-found under eventual visibility is distinguished from a genuine absence before any retry.",
        ],
        [
            "a checksum mismatch retried instead of surfaced",
            "a throttling response retried without backoff",
            "an eventually visible object treated as permanently missing",
        ],
    ),
    (
        "object-lifecycle-and-retention-verifier",
        "Object Lifecycle and Retention Verifier",
        "Verify lifecycle transitions, retention and archive restore behaviour",
        ["transition rule", "expiration rule", "retention mode", "archive restore"],
        ["lifecycle_rules.json", "lifecycle_results.json", "verifier_notes.md"],
        [
            "Transition, expiration, non-current version and multipart abort rules are compared rule by rule.",
            "Retention mode, legal hold and delete protection are verified before any bucket is used for authoritative data.",
            "Archive restore latency and cost are recorded because a transition can make data temporarily unreadable.",
        ],
        [
            "a lifecycle rule that expires objects the target still reads",
            "an archived object read on a synchronous path",
            "a retention mode weaker on the target than on the source",
        ],
    ),
    (
        "infrastructure-message-delivery-view",
        "Infrastructure Message Delivery View",
        "Project the messaging model onto broker and stream infrastructure",
        ["broker projection", "partition and offset", "delivery record", "inbox state"],
        ["message_delivery_view.json", "delivery_records.json", "view_notes.md"],
        [
            "Every broker, topic, queue, partition and consumer group is bound to the authoritative messaging record.",
            "Offset position, acknowledgement state and dead-letter routing are recorded per consumer group.",
            "Broker-specific fields extend the record and never replace an authoritative field.",
        ],
        [
            "a broker-specific delivery model competing with the authoritative record",
            "an offset position recorded outside the delivery record",
            "a consumer group whose acknowledgement state was never captured",
        ],
    ),
    (
        "producer-semantic-verifier",
        "Producer Semantic Verifier",
        "Verify producer acknowledgement, batching and shutdown semantics",
        ["acknowledgement level", "batching and buffering", "partition assignment", "shutdown flush"],
        ["producer_semantics.json", "producer_results.json", "verifier_notes.md"],
        [
            "Synchronous and asynchronous send, acknowledgement level, buffering, batching and compression are compared.",
            "Retry, idempotence, partition selection, key serialization, timeout and callback behaviour are verified.",
            "Shutdown flush is proved so no buffered message is lost when the process exits.",
        ],
        [
            "a buffered message lost because shutdown did not flush",
            "an acknowledgement level lowered during migration",
            "a partition assignment change that breaks per-key ordering",
        ],
    ),
    (
        "consumer-semantic-verifier",
        "Consumer Semantic Verifier",
        "Verify consumer prefetch, concurrency, acknowledgement and shutdown semantics",
        ["delivery mode", "prefetch and concurrency", "acknowledgement point", "shutdown drain"],
        ["consumer_semantics.json", "consumer_results.json", "verifier_notes.md"],
        [
            "Pull and push delivery, prefetch, batching, consumer group and partition assignment behaviour are compared.",
            "The acknowledgement point relative to side-effect completion is declared explicitly and verified.",
            "Concurrency, ordering, cancellation and shutdown drain behaviour are measured under load.",
        ],
        [
            "a message acknowledged before its side effect completed",
            "consumer concurrency raised so per-key ordering is lost",
            "in-flight messages dropped on shutdown without redelivery",
        ],
    ),
    (
        "message-serialization-verifier",
        "Message Serialization Verifier",
        "Verify message payload fidelity and schema compatibility on the wire",
        ["schema binding", "version negotiation", "unknown field policy", "envelope integrity"],
        ["message_serialization.json", "serialization_results.json", "verifier_notes.md"],
        [
            "Schema identity, version, content type and header fields are recorded for every message family.",
            "Null, decimal, temporal, enum and unknown field handling are verified through both producer and consumer.",
            "Compression, encryption and signature handling are verified so the envelope survives the migration intact.",
        ],
        [
            "an unknown field dropped by the target consumer",
            "a schema version absent from the message envelope",
            "a signature that the target consumer never validates",
        ],
    ),
    (
        "message-ordering-verifier",
        "Message Ordering Verifier",
        "Verify the declared ordering scope end to end under retry and rebalance",
        ["ordering scope", "retry impact", "concurrency impact", "rebalance impact"],
        ["ordering_semantics.json", "ordering_results.json", "verifier_notes.md"],
        [
            "The ordering scope is declared as global, partition, key, queue, per-consumer, best effort or none.",
            "Producer partitioning, batching and retry effects on ordering are measured, not assumed neutral.",
            "Consumer concurrency, requeue, dead-lettering and rebalance effects on ordering are exercised explicitly.",
        ],
        [
            "an ordering guarantee claimed at a wider scope than the broker provides",
            "a retry that reorders two messages sharing a key",
            "a requeue that moves a message behind newer messages",
        ],
    ),
    (
        "delivery-guarantee-verifier",
        "Delivery Guarantee Verifier",
        "Separate broker delivery guarantees from business side-effect guarantees",
        ["guarantee model", "broker versus effect", "deduplication scope", "effect idempotency"],
        ["delivery_guarantees.json", "guarantee_results.json", "verifier_notes.md"],
        [
            "At-most-once, at-least-once, effectively-once, transactional and best-effort models are declared per flow.",
            "A broker guarantee is never presented as a guarantee about irreversible business side effects.",
            "Deduplication scope and window are stated numerically and effect idempotency is proved independently.",
        ],
        [
            "an exactly-once broker feature quoted as a business exactly-once claim",
            "a deduplication window shorter than the maximum retry delay",
            "an irreversible side effect with no idempotency key",
        ],
    ),
    (
        "acknowledgement-semantic-verifier",
        "Acknowledgement Semantic Verifier",
        "Verify acknowledgement timing, batching and negative acknowledgement handling",
        ["ack timing", "batch ack", "negative ack", "commit synchrony"],
        ["ack_semantics.json", "ack_results.json", "verifier_notes.md"],
        [
            "Automatic, manual, pre-processing and post-processing acknowledgement modes are distinguished per consumer.",
            "Batch acknowledgement, negative acknowledgement, requeue and offset commit behaviour are compared.",
            "Commit synchrony and acknowledgement timeout are recorded because both change the duplicate window.",
        ],
        [
            "an automatic acknowledgement introduced where the source acknowledged manually",
            "a batch acknowledgement that commits an unprocessed message",
            "an acknowledgement timeout shorter than the processing time",
        ],
    ),
    (
        "message-retry-and-dead-letter-verifier",
        "Message Retry and Dead-Letter Verifier",
        "Verify retry topology, poison message handling and its ordering cost",
        ["retry topology", "backoff", "poison handling", "ordering cost"],
        ["retry_topology.json", "retry_results.json", "verifier_notes.md"],
        [
            "Immediate retry, delayed retry, retry topic and requeue paths are distinguished with their backoff policies.",
            "Maximum attempts, dead-letter routing and poison message handling are verified end to end.",
            "The ordering cost of every retry path is stated and the idempotency key is preserved across attempts.",
        ],
        [
            "a poison message retried without bound",
            "a retry path that silently breaks per-key ordering",
            "a dead-letter queue that no one consumes or monitors",
        ],
    ),
    (
        "consumer-rebalance-verifier",
        "Consumer Rebalance Verifier",
        "Verify rebalance correctness for in-flight work, offsets and local state",
        ["revocation handling", "offset commit", "in-flight work", "generation fencing"],
        ["rebalance_semantics.json", "rebalance_results.json", "verifier_notes.md"],
        [
            "Partition revocation, offset commit on revocation and in-flight message disposition are verified explicitly.",
            "Local state stores are flushed or discarded deterministically on reassignment.",
            "Duplicate and missing message counts are measured across a rebalance, and generation fencing is proved.",
        ],
        [
            "a revocation callback missing so offsets are never committed",
            "local state carried into a partition the consumer no longer owns",
            "a fenced consumer still committing offsets after reassignment",
        ],
    ),
]

BATCHES.update({
    138: {
        "title": "Broker Packs and Language Driver Pack",
        "why": "Moves ELMOS from generic messaging abstractions to per-broker semantics, then binds all of it to the concrete driver stack of each language.",
        "purpose": "verify transactional producers, outbox and inbox patterns and the specific semantics of five broker families, then record the infrastructure driver stack, concurrency model and known hazards for six of the nine supported languages.",
        "tooling": ["broker semantic packs", "outbox and inbox harness", "language driver inventories", "driver hazard registry"],
    },
    139: {
        "title": "Driver Mapping, Differential and Fault Injection Pack",
        "why": "Moves ELMOS from comparing outcomes on a healthy system to comparing protocol behaviour under injected infrastructure failure.",
        "purpose": "complete the remaining language driver packs, match driver capabilities and defaults, generate adapters, record every operation, run the dual-system differential, and inject the failure classes that produce unknown outcomes, partial success, lag, failover, partition and exhaustion.",
        "tooling": ["driver capability matcher", "infrastructure adapter generator", "operation recorder", "fault injection controller"],
    },
})

SKILLS[138] = [
    (
        "transactional-producer-verifier",
        "Transactional Producer Verifier",
        "Verify broker transaction semantics and their boundary with the application transaction",
        ["producer transaction", "offset transaction", "fencing and epoch", "unknown outcome"],
        ["transactional_producer.json", "transaction_results.json", "verifier_notes.md"],
        [
            "Producer transaction, offset transaction, fencing and epoch behaviour are verified under injected failure.",
            "Transaction timeout, abort, commit and retry paths are exercised including the unknown outcome branch.",
            "The broker transaction boundary and the application transaction boundary are declared separately and reconciled.",
        ],
        [
            "a broker transaction assumed to cover a database write",
            "an unknown transaction outcome retried without fencing",
            "a transaction identifier reused across two producer instances",
        ],
    ),
    (
        "outbox-and-inbox-verifier",
        "Outbox and Inbox Verifier",
        "Verify the outbox and inbox patterns that bridge state changes and messages",
        ["atomic outbox write", "publisher liveness", "inbox deduplication", "retention and replay"],
        ["outbox_inbox_model.json", "pattern_results.json", "verifier_notes.md"],
        [
            "Outbox rows are written in the same transaction as the state change they describe, verified by injected failure.",
            "Publisher locking, retry, state transitions, cleanup and duplicate emission are verified under concurrency.",
            "Inbox deduplication keys, transaction scope, retention window and replay behaviour are verified explicitly.",
        ],
        [
            "an outbox write committed separately from its state change",
            "two publishers emitting the same outbox row",
            "an inbox retention window shorter than the maximum redelivery delay",
        ],
    ),
    (
        "kafka-semantic-pack",
        "Kafka Semantic Pack",
        "Carry log-based streaming platform semantics into the differential",
        ["partition and key", "idempotent producer", "consumer group", "compaction"],
        ["kafka_capabilities.json", "kafka_risks.json", "pack_notes.md"],
        [
            "Partitioning, keying, acknowledgement level, idempotent producer and transaction behaviour are recorded per topic.",
            "Consumer group, offset management, rebalance protocol, retention and compaction facts are covered.",
            "Schema handling, batching and backpressure are recorded, and an end-to-end effect guarantee is never inferred from broker features.",
        ],
        [
            "a null key introduced so per-key ordering silently disappears",
            "idempotence disabled during migration",
            "a retention assumption that loses messages the consumer had not read",
        ],
    ),
    (
        "rabbitmq-and-amqp-pack",
        "RabbitMQ and AMQP Pack",
        "Carry exchange-based broker semantics into the differential",
        ["exchange and binding", "durability", "publisher confirm", "prefetch and requeue"],
        ["amqp_capabilities.json", "amqp_risks.json", "pack_notes.md"],
        [
            "Exchange type, binding, routing key, queue durability and message durability are recorded per flow.",
            "Publisher confirms, consumer acknowledgement, prefetch, requeue and dead-letter routing are verified.",
            "Priority, time-to-live, exclusive queues and connection recovery behaviour are recorded as risks.",
        ],
        [
            "publisher confirms disabled so acknowledged sends can be lost",
            "a requeue that returns a message to the head and blocks the queue",
            "a durable queue holding non-durable messages",
        ],
    ),
    (
        "pulsar-semantic-pack",
        "Pulsar Semantic Pack",
        "Carry subscription-based streaming platform semantics into the differential",
        ["subscription type", "cursor and redelivery", "deduplication", "tiered storage"],
        ["pulsar_capabilities.json", "pulsar_risks.json", "pack_notes.md"],
        [
            "Topic, partition, subscription type and cursor behaviour are recorded per consumer.",
            "Acknowledgement, negative acknowledgement, redelivery, deduplication and transaction facts are covered.",
            "Tiered storage, schema handling and key-shared ordering constraints are recorded as risks.",
        ],
        [
            "a subscription type change that alters ordering guarantees",
            "a key-shared subscription whose ordering assumption no longer holds",
            "a tiered storage read placed on a latency-sensitive path",
        ],
    ),
    (
        "nats-and-jetstream-pack",
        "NATS and JetStream Pack",
        "Carry lightweight messaging and stream persistence semantics into the differential",
        ["core versus persisted", "deliver policy", "subject wildcard", "replay"],
        ["nats_capabilities.json", "nats_risks.json", "pack_notes.md"],
        [
            "Core publish-subscribe and persisted stream behaviour are distinguished per flow rather than merged.",
            "Stream, consumer, acknowledgement, deliver policy, replay and retention facts are recorded.",
            "Subject wildcard semantics, deduplication window and pull versus push delivery are verified explicitly.",
        ],
        [
            "a core publish treated as durable",
            "a subject wildcard that matches more than the source pattern did",
            "a deliver policy change that replays already-processed messages",
        ],
    ),
    (
        "redis-streams-pack",
        "Redis Streams Pack",
        "Carry key-value stream semantics into the differential including pending entry recovery",
        ["stream identifier", "pending entries", "claim and autoclaim", "trimming"],
        ["redis_streams_capabilities.json", "redis_streams_risks.json", "pack_notes.md"],
        [
            "Stream identifiers, consumer group state and pending entry lists are recorded per stream.",
            "Acknowledgement, claim and automatic claim behaviour are verified so a crashed consumer's work is recovered.",
            "Trimming policy is recorded because it can discard entries a consumer has not yet processed.",
        ],
        [
            "a crashed consumer's pending entries never claimed",
            "a trim policy that discards unprocessed entries",
            "an idempotency assumption broken by a reclaimed entry",
        ],
    ),
    (
        "message-broker-failover-verifier",
        "Message Broker Failover Verifier",
        "Verify producer and consumer behaviour across broker failure and recovery",
        ["leader failover", "reconnect behaviour", "duplicate and loss", "confirm unknown"],
        ["broker_failover.json", "failover_results.json", "verifier_notes.md"],
        [
            "Leader failover, broker restart and network partition are injected and their outcomes compared.",
            "Producer and consumer reconnection, duplicate emission, message loss and offset lag are measured.",
            "Unknown confirm outcomes, rebalance storms and storage exhaustion are exercised as distinct scenarios.",
        ],
        [
            "an unknown publish confirm retried into a duplicate side effect",
            "a message loss window that no test measures",
            "a rebalance storm triggered by an aggressive session timeout",
        ],
    ),
    (
        "messaging-backpressure-verifier",
        "Messaging Backpressure Verifier",
        "Verify that overload degrades deliberately rather than by exhaustion",
        ["producer buffer bound", "consumer pacing", "rate limiting", "load shedding"],
        ["backpressure_model.json", "backpressure_results.json", "verifier_notes.md"],
        [
            "Producer buffer bounds, batching and blocking behaviour on a full buffer are measured, not assumed.",
            "Consumer prefetch, poll interval, queue depth and pause and resume behaviour are verified under sustained overload.",
            "Rate limiting and load shedding are explicit decisions with declared thresholds rather than emergent behaviour.",
        ],
        [
            "an unbounded producer buffer that exhausts memory under overload",
            "a consumer that keeps prefetching while its processing queue grows",
            "overload absorbed silently until the process is terminated",
        ],
    ),
    (
        "java-infrastructure-driver-pack",
        "Java Infrastructure Driver Pack",
        "Record the Java infrastructure driver stack, concurrency model and hazards",
        ["blocking and reactive", "pool and threading", "interruption", "exception hierarchy"],
        ["java_driver_inventory.json", "java_driver_hazards.json", "pack_notes.md"],
        [
            "Blocking and reactive database access stacks are recorded separately with their pool implementations.",
            "Thread interruption, lightweight thread interaction, transaction scope and reactive backpressure behaviour are verified.",
            "The checked exception hierarchy is preserved through normalisation rather than flattened.",
        ],
        [
            "a blocking access path converted to reactive without re-proving semantics",
            "a pool sized for platform threads reused with lightweight threads",
            "a driver-level automatic retry left enabled unnoticed",
        ],
    ),
    (
        "python-infrastructure-driver-pack",
        "Python Infrastructure Driver Pack",
        "Record the Python infrastructure driver stack, concurrency model and hazards",
        ["sync and async drivers", "context manager", "numeric fidelity", "native extension"],
        ["python_driver_inventory.json", "python_driver_hazards.json", "pack_notes.md"],
        [
            "Synchronous and asynchronous drivers are recorded separately with their pool and event loop interaction.",
            "Context manager based release, decimal and temporal fidelity and streaming generator behaviour are verified.",
            "Native extension thread safety and interpreter lock interaction are recorded per driver.",
        ],
        [
            "a synchronous driver blocking an asynchronous request handler",
            "a connection left open because no context manager scoped it",
            "a decimal value converted to a float by the driver",
        ],
    ),
    (
        "csharp-infrastructure-driver-pack",
        "CSharp Infrastructure Driver Pack",
        "Record the C# infrastructure driver stack, cancellation model and hazards",
        ["asynchronous IO", "cancellation token", "reader lifetime", "handle disposal"],
        ["csharp_driver_inventory.json", "csharp_driver_hazards.json", "pack_notes.md"],
        [
            "Asynchronous input and output paths, cancellation token propagation and reader lifetime are recorded per driver.",
            "Connection pool behaviour, ambient transaction scope and decimal and offset-aware temporal handling are verified.",
            "Native handle disposal is verified so no unmanaged resource outlives its owner.",
        ],
        [
            "a cancellation token accepted but never passed to the driver",
            "a reader left undisposed so its connection is not returned",
            "an ambient transaction enlisting a connection unexpectedly",
        ],
    ),
    (
        "rust-infrastructure-driver-pack",
        "Rust Infrastructure Driver Pack",
        "Record the Rust infrastructure driver stack, ownership model and hazards",
        ["async runtime", "connection ownership", "transaction lifetime", "feature flags"],
        ["rust_driver_inventory.json", "rust_driver_hazards.json", "pack_notes.md"],
        [
            "Async runtime, pool implementation, connection ownership and transaction lifetime are recorded per driver.",
            "Stream handling, future send bounds, cancellation behaviour and error types are verified explicitly.",
            "Decimal and temporal crate choices and transport feature flags are recorded because both change behaviour.",
        ],
        [
            "a transaction guard held across an await that starves the pool",
            "a transport feature flag omitted so encryption is silently absent",
            "a cancelled future dropping a connection mid-command",
        ],
    ),
    (
        "go-infrastructure-driver-pack",
        "Go Infrastructure Driver Pack",
        "Record the Go infrastructure driver stack, context model and hazards",
        ["pool abstraction", "context propagation", "result closing", "buffer lifetime"],
        ["go_driver_inventory.json", "go_driver_hazards.json", "pack_notes.md"],
        [
            "The standard pool abstraction, driver pool behaviour and context propagation are recorded per driver.",
            "Result set closing, transaction scope, null handling, temporal mapping and byte slice lifetime are verified.",
            "Driver-level automatic retry on a bad connection is recorded because it can duplicate a write.",
        ],
        [
            "a pool handle treated as a single connection",
            "a result set never closed so its connection is never returned",
            "a background context used where a request deadline was required",
        ],
    ),
    (
        "typescript-infrastructure-driver-pack",
        "TypeScript Infrastructure Driver Pack",
        "Record the Node infrastructure driver stack, numeric limits and hazards",
        ["event loop", "numeric limits", "null and undefined", "async context"],
        ["typescript_driver_inventory.json", "typescript_driver_hazards.json", "pack_notes.md"],
        [
            "Driver, pool, promise and stream behaviour are recorded together with event loop interaction.",
            "Large integer, decimal and temporal handling are verified against the safe integer limit.",
            "Null and undefined distinction, asynchronous context storage and unhandled rejection behaviour are verified.",
        ],
        [
            "a sixty-four bit identifier truncated by the safe integer limit",
            "a promise never awaited so its connection leaks",
            "undefined and null collapsed into one database value",
        ],
    ),
    (
        "cplusplus-infrastructure-driver-pack",
        "CPlusPlus Infrastructure Driver Pack",
        "Record the native infrastructure driver stack, ownership model and hazards",
        ["resource ownership", "buffer lifetime", "thread model", "sanitizer evidence"],
        ["cplusplus_driver_inventory.json", "cplusplus_driver_hazards.json", "pack_notes.md"],
        [
            "Native client libraries, scoped ownership, pointer and buffer lifetime and thread model are recorded per driver.",
            "Callback, coroutine, exception path, transport configuration and pool behaviour are verified.",
            "Address and thread sanitizer evidence is required for every native driver path, including shutdown.",
        ],
        [
            "a connection leaked on an exception path",
            "a buffer freed while the driver still references it",
            "a native driver used from a thread its documentation forbids",
        ],
    ),
]

SKILLS[139] = [
    (
        "objectivec-infrastructure-driver-pack",
        "Objective-C Infrastructure Driver Pack",
        "Record the Objective-C infrastructure driver stack, memory model and hazards",
        ["reference counting", "dispatch model", "error object", "bridged ownership"],
        ["objectivec_driver_inventory.json", "objectivec_driver_hazards.json", "pack_notes.md"],
        [
            "Foundation clients, wrapper layers, reference counting and autorelease pool behaviour are recorded per driver.",
            "Dispatch queue, run loop, delegate and block based completion behaviour are verified explicitly.",
            "Bridged native ownership rules are recorded so no object is over-released or leaked at the boundary.",
        ],
        [
            "a completion block retaining its owner and creating a cycle",
            "a bridged native handle released twice",
            "a blocking infrastructure call made on the main thread",
        ],
    ),
    (
        "swift-infrastructure-driver-pack",
        "Swift Infrastructure Driver Pack",
        "Record the Swift infrastructure driver stack, concurrency model and hazards",
        ["structured concurrency", "isolation and sendability", "buffer type", "platform difference"],
        ["swift_driver_inventory.json", "swift_driver_hazards.json", "pack_notes.md"],
        [
            "Structured concurrency and event loop based driver stacks are recorded separately with their pool behaviour.",
            "Actor isolation, sendability, buffer types, decimal and temporal handling and optionality are verified.",
            "Behaviour differences between Apple platforms and Linux are recorded per driver rather than assumed absent.",
        ],
        [
            "a blocking pool wait inside an event loop thread",
            "a non-sendable value crossing an isolation boundary",
            "a driver behaviour verified on one platform and assumed on the other",
        ],
    ),
    (
        "driver-capability-matcher",
        "Driver Capability Matcher",
        "Classify every source driver capability as direct, adapter-required or redesign-required",
        ["capability dimension", "direct mapping", "adapter requirement", "redesign requirement"],
        ["driver_mapping.json", "capability_gaps.json", "matcher_notes.md"],
        [
            "Protocol, synchrony, pool, transaction, cancellation, retry, streaming and batch dimensions are compared explicitly.",
            "Type mapping, failover, observability and platform support are compared as separate dimensions.",
            "Every capability lands in exactly one class of direct, adapter-required or redesign-required.",
        ],
        [
            "a capability marked direct without a differential result",
            "a thread-bound transaction context mapped without redesign",
            "an unmapped capability omitted from the gap list",
        ],
    ),
    (
        "driver-default-difference-detector",
        "Driver Default Difference Detector",
        "Detect and eliminate reliance on implicit driver defaults",
        ["default inventory", "explicit configuration", "difference report", "drift detection"],
        ["driver_defaults.json", "default_differences.json", "detector_notes.md"],
        [
            "Auto-commit, fetch size, batch size, pool size, timeout, retry, transport and compression defaults are inventoried per driver.",
            "Read preference, write concern, acknowledgement level, prefetch and refresh defaults are inventoried per driver.",
            "Every target default that matters is configured explicitly rather than inherited from the driver.",
        ],
        [
            "a target default assumed equal to the source default",
            "a security-relevant default left unconfigured",
            "a default change introduced by a driver upgrade and never detected",
        ],
    ),
    (
        "protocol-compatibility-verifier",
        "Protocol Compatibility Verifier",
        "Verify that two drivers actually negotiate compatible protocol features",
        ["protocol version", "feature negotiation", "transport mode", "fallback path"],
        ["protocol_compatibility.json", "negotiation_results.json", "verifier_notes.md"],
        [
            "Protocol version, extensions, binary and text mode and compression negotiation are compared per connection.",
            "Authentication mechanism, transport security and session feature negotiation are verified against the real server.",
            "Fallback paths are enumerated so a silent downgrade cannot pass as a successful negotiation.",
        ],
        [
            "a silent downgrade to an unencrypted transport",
            "a binary protocol path replaced by a text path with different type fidelity",
            "a server capability assumed present without negotiation evidence",
        ],
    ),
    (
        "infrastructure-adapter-generator",
        "Infrastructure Adapter Generator",
        "Generate the adapters that close recorded driver gaps rather than hiding them",
        ["adapter inventory", "gap traceability", "adapter test", "retirement plan"],
        ["generated_adapters.json", "adapter_tests.json", "generator_notes.md"],
        [
            "Error, type codec, context, retry, transaction, pool, tracing, metric and shutdown adapters are generated from recorded gaps.",
            "Every adapter traces to the specific gap it closes and carries its own differential test.",
            "An adapter that hides a gap instead of closing it is rejected and reported as an open gap.",
        ],
        [
            "an adapter that swallows an error class instead of mapping it",
            "an adapter with no traceable source gap",
            "an adapter shipped without a differential test",
        ],
    ),
    (
        "infrastructure-operation-recorder",
        "Infrastructure Operation Recorder",
        "Record every infrastructure operation at logical, driver and protocol level",
        ["three-level record", "parameter capture", "resource release", "secret redaction"],
        ["operation_records.json", "record_schema.json", "recorder_notes.md"],
        [
            "Each record links the logical operation, the driver call and the protocol commands it produced.",
            "Connection, transaction, parameters, result, error, duration, retry and resource release are captured per operation.",
            "Credentials and payload secrets are recorded as broker references only and never in plaintext.",
        ],
        [
            "a logical operation recorded without its protocol commands",
            "a resource release that no record confirms",
            "a connection string captured with its password in plaintext",
        ],
    ),
    (
        "infrastructure-differential-harness",
        "Infrastructure Differential Harness",
        "Run both systems from identical state, input and fault script and diff the protocol behaviour",
        ["identical initial state", "shared fault script", "protocol diff", "resource diff"],
        ["differential_plan.json", "differential_results.json", "harness_notes.md"],
        [
            "Both sides start from identical initial state and receive identical input and identical injected faults.",
            "Comparison covers command count, command order, transaction shape, lock behaviour, data, errors and retries.",
            "Connection use, resource release, performance and observable side effects are all part of the diff.",
        ],
        [
            "a differential run where only one side received the injected fault",
            "equivalence claimed while command counts differ by an order of magnitude",
            "a run compared on results while resource leaks were ignored",
        ],
    ),
    (
        "infrastructure-fault-injection-controller",
        "Infrastructure Fault Injection Controller",
        "Inject faults at every point in the infrastructure call path",
        ["injection point", "partial send", "mid-response failure", "reproducible schedule"],
        ["injection_points.json", "injection_schedule.json", "controller_notes.md"],
        [
            "Injection points cover name resolution, connect, transport security, authentication and pool checkout.",
            "Faults are injected before send, during a partial send, during server execution and during a partial response.",
            "Commit, acknowledgement, upload part, offset commit and close points each carry their own injection cases.",
        ],
        [
            "a fault injected only before the request was sent",
            "a commit-time fault never exercised",
            "an injection schedule that cannot be reproduced deterministically",
        ],
    ),
    (
        "unknown-commit-outcome-verifier",
        "Unknown Commit Outcome Verifier",
        "Verify behaviour when a commit result cannot be determined",
        ["outcome ambiguity", "business key query", "reconciliation path", "duplicate prevention"],
        ["unknown_commit_cases.json", "outcome_results.json", "verifier_notes.md"],
        [
            "A lost connection after commit leaves three possible states and all three are handled explicitly.",
            "Resolution uses a business idempotency key and an outcome query rather than a blind retry.",
            "Unresolved cases enter a named reconciliation path and never a silent success or silent failure.",
        ],
        [
            "an unknown commit outcome retried blindly and duplicating a side effect",
            "an unknown outcome recorded as failed with no reconciliation",
            "a resolution path with no business key to query on",
        ],
    ),
    (
        "partial-success-verifier",
        "Partial Success Verifier",
        "Verify per-item outcome reporting and safe subset retry for every batch surface",
        ["per-item outcome", "result correlation", "subset retry", "compensation path"],
        ["partial_success_cases.json", "partial_results.json", "verifier_notes.md"],
        [
            "Bulk database, bulk search, multipart upload, batch send, cache pipeline and multi-object delete all report per item.",
            "Results correlate to inputs by identity, not by position alone, so retry targets the correct subset.",
            "Compensation and final reconciliation paths exist for items that cannot be retried.",
        ],
        [
            "a partial success reported as a total success",
            "results correlated by position when the response reordered them",
            "an unretryable failed item with no compensation path",
        ],
    ),
    (
        "replica-lag-verifier",
        "Replica Lag Verifier",
        "Verify read routing correctness under measured replication lag",
        ["routing policy", "session guarantee", "staleness tolerance", "primary fallback"],
        ["replica_routing.json", "lag_results.json", "verifier_notes.md"],
        [
            "Read routing policy is declared per query and read-your-writes requirements are marked explicitly.",
            "Lag is measured rather than assumed bounded, and the declared staleness tolerance is stated numerically.",
            "Primary fallback and timeout behaviour are verified when lag exceeds tolerance.",
        ],
        [
            "a read-your-writes query routed to a lagging replica",
            "a staleness tolerance stated qualitatively rather than numerically",
            "a cache populated from a stale replica read",
        ],
    ),
    (
        "primary-failover-verifier",
        "Primary Failover Verifier",
        "Verify client behaviour across a primary failover",
        ["failover detection", "session loss", "read-only window", "write fencing"],
        ["primary_failover.json", "failover_results.json", "verifier_notes.md"],
        [
            "Failover detection latency, endpoint update propagation and connection reset behaviour are measured.",
            "Session state and prepared statement loss are verified, along with in-flight transaction disposition.",
            "The read-only window is measured and write fencing is proved so a demoted primary cannot accept writes.",
        ],
        [
            "a write accepted by a demoted primary",
            "a prepared statement reused after failover invalidated it",
            "a stale endpoint cached past the failover event",
        ],
    ),
    (
        "network-partition-verifier",
        "Network Partition Verifier",
        "Verify behaviour under partition including half-open connections and lease expiry",
        ["half-open detection", "duplicate send", "unacknowledged write", "lease expiry"],
        ["partition_cases.json", "partition_results.json", "verifier_notes.md"],
        [
            "Timeout behaviour, half-open connection detection and stale connection reuse are measured under partition.",
            "Duplicate sends and unacknowledged writes are counted rather than assumed absent.",
            "Lock lease expiry, consumer heartbeat loss, in-flight uploads and bulk writes are each exercised.",
        ],
        [
            "a half-open connection reused for a new command",
            "a lock believed held after its lease expired during a partition",
            "a consumer evicted by heartbeat loss while still processing",
        ],
    ),
    (
        "resource-exhaustion-verifier",
        "Resource Exhaustion Verifier",
        "Verify deliberate degradation under every exhaustion class",
        ["exhaustion class", "fail fast", "degradation path", "leak detection"],
        ["exhaustion_cases.json", "exhaustion_results.json", "verifier_notes.md"],
        [
            "Pool, thread, memory, disk, queue, rate limit, quota, file descriptor and connection limits are each exhausted deliberately.",
            "Backpressure, fail-fast, timeout and degradation behaviour are measured for every exhaustion class.",
            "Recovery is verified and no resource leak survives the exhaustion event.",
        ],
        [
            "pool exhaustion that queues without bound instead of failing fast",
            "a file descriptor leak surfacing only after sustained load",
            "a quota breach retried until the account is throttled",
        ],
    ),
    (
        "infrastructure-recovery-verifier",
        "Infrastructure Recovery Verifier",
        "Verify that every resource returns to a clean state after a fault",
        ["pool recovery", "transaction cleanup", "consumer rejoin", "residue cleanup"],
        ["recovery_checklist.json", "recovery_results.json", "verifier_notes.md"],
        [
            "Pool restoration, transaction cleanup, consumer group rejoin and offset correctness are verified after recovery.",
            "Upload residue, reader contexts and cache locks are all confirmed released or expired.",
            "Observability signals return to their baseline so a silent degraded state cannot persist.",
        ],
        [
            "a pool that never recovers its minimum size after a fault",
            "an orphaned upload part left after recovery",
            "a cache lock held indefinitely by a crashed holder",
        ],
    ),
]

BATCHES.update({
    140: {
        "title": "Infrastructure Mutation and Test Generation Pack",
        "why": "Moves ELMOS from trusting an infrastructure test suite to proving that suite can kill the specific defects a migration produces.",
        "purpose": "mutate database, cache, search, object storage, messaging and driver semantics so every guarantee is proved detectable, generate behaviour, concurrency and property tests for each infrastructure class, then open the performance differential for databases, caches and search.",
        "tooling": ["infrastructure mutation packs", "behaviour test generators", "property test generator", "performance differential harness"],
    },
    141: {
        "title": "Infrastructure Capacity, Security and Shadow Pack",
        "why": "Moves ELMOS from a functional infrastructure equivalence claim to one bounded by capacity, permission and production shadow evidence.",
        "purpose": "complete the object storage and messaging performance differentials, gate capacity regression, verify credentials and per-class authorisation, then run the infrastructure shadow — shadow driver, write comparator, dual read, dual index, dual write and shadow consumer — and plan the cutover.",
        "tooling": ["capacity regression gate", "infrastructure security verifiers", "infrastructure shadow driver", "cutover planner"],
    },
})

SKILLS[140] = [
    (
        "database-mutation-pack",
        "Database Mutation Pack",
        "Mutate transactional and type guarantees so database tests are proved effective",
        ["isolation weakening", "boundary removal", "numeric degradation", "unsafe retry"],
        ["database_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations lower isolation, enable auto-commit, remove rollback, advance commit and remove savepoints.",
            "Lock removal, exclusive-read removal, decimal to float conversion and timezone removal are mutated separately.",
            "Removing an affected-row check and retrying an unknown commit are included as mutations that must be caught.",
        ],
        [
            "an isolation downgrade that no test detects",
            "a decimal to float conversion that survives the suite",
            "an unknown commit retry that no test flags",
        ],
    ),
    (
        "cache-mutation-pack",
        "Cache Mutation Pack",
        "Mutate cache key, expiry and atomicity guarantees so cache tests are proved effective",
        ["key mutation", "expiry unit change", "atomicity downgrade", "invalidation removal"],
        ["cache_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations remove the key prefix, change the expiry unit and remove the expiry entirely.",
            "Compare and swap downgraded to a plain set, unvalidated lock tokens and removed invalidation are mutated.",
            "Write order changes, serialization version changes and cluster hash tag removal are included.",
        ],
        [
            "a key prefix removal that no isolation test catches",
            "a compare and swap downgrade that survives the suite",
            "an invalidation removal that no staleness test detects",
        ],
    ),
    (
        "search-mutation-pack",
        "Search Mutation Pack",
        "Mutate mapping, analysis and result handling so search tests are proved effective",
        ["field type mutation", "analyzer mutation", "visibility mutation", "partial result mutation"],
        ["search_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations switch analysed and exact field types and alter the analysis chain.",
            "Refresh removal, tie-breaker removal, ignored bulk item errors and changed cursor fields are mutated.",
            "Leaving a reader context open and treating a partial shard failure as success are included as mutations.",
        ],
        [
            "an analyzer change that no relevance test detects",
            "a removed tie breaker that no pagination test catches",
            "a partial shard failure treated as success and never flagged",
        ],
    ),
    (
        "object-storage-mutation-pack",
        "Object Storage Mutation Pack",
        "Mutate transfer, integrity and access guarantees so object storage tests are proved effective",
        ["checksum removal", "metadata removal", "cleanup removal", "credential scope change"],
        ["object_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations disable checksum verification, remove the content type and remove multipart abort cleanup.",
            "Part order changes, ignored version identifiers and lengthened presigned expiry are mutated separately.",
            "Disabled encryption, incorrect ranges and duplicate retry uploads are included as mutations.",
        ],
        [
            "a disabled checksum that no integrity test detects",
            "a lengthened presigned expiry that no security test flags",
            "an unaborted multipart upload that no cleanup test catches",
        ],
    ),
    (
        "messaging-mutation-pack",
        "Messaging Mutation Pack",
        "Mutate delivery, ordering and durability guarantees so messaging tests are proved effective",
        ["early acknowledgement", "key removal", "durability downgrade", "shutdown mutation"],
        ["messaging_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations acknowledge early, commit offsets early, remove the message key and change the partition.",
            "Disabled idempotence, disabled publisher confirms and changed prefetch are mutated separately.",
            "Removed dead-letter routing, changed retry idempotency keys and an unflushed shutdown are included.",
        ],
        [
            "an early acknowledgement that no loss test detects",
            "a removed message key that no ordering test catches",
            "an unflushed shutdown that survives the suite",
        ],
    ),
    (
        "driver-mutation-pack",
        "Driver Mutation Pack",
        "Mutate driver configuration so configuration-level regressions are proved detectable",
        ["timeout removal", "implicit retry", "pool bound removal", "transport downgrade"],
        ["driver_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations remove timeouts, enable implicit retry, remove the pool upper bound and stop propagating cancellation.",
            "Failing to return a connection, disabling transport verification and compressing the error hierarchy are mutated.",
            "Switching between binary and text protocol modes and removing session initialisation are included.",
        ],
        [
            "a removed timeout that no test detects",
            "a disabled transport verification that no security test flags",
            "a compressed error hierarchy that no retry classification test catches",
        ],
    ),
    (
        "database-behavior-test-generator",
        "Database Behavior Test Generator",
        "Generate the database behaviour tests the differential and mutation packs require",
        ["transaction scenarios", "type boundary cases", "contention cases", "failover cases"],
        ["database_tests.json", "generation_report.json", "generator_notes.md"],
        [
            "Generated tests cover transaction, isolation, deadlock, savepoint, locking and batch behaviour.",
            "Generated key, decimal, temporal, null, ordering and pagination cases are produced from the recorded type facts.",
            "Failover cases are generated from the recorded topology rather than from a generic template.",
        ],
        [
            "a generated suite with no isolation anomaly case",
            "a decimal test that never crosses a precision boundary",
            "a failover test generated for a topology the system does not have",
        ],
    ),
    (
        "cache-behavior-test-generator",
        "Cache Behavior Test Generator",
        "Generate the cache behaviour tests the differential and mutation packs require",
        ["expiry race", "atomic operation", "stampede burst", "cluster routing"],
        ["cache_tests.json", "generation_report.json", "generator_notes.md"],
        [
            "Generated tests cover expiry, expiry races, compare and swap, increment and locking behaviour.",
            "Stampede bursts, failover, cluster slot routing, serialization and invalidation cases are produced.",
            "Every generated case names the guarantee it protects so a passing suite is interpretable.",
        ],
        [
            "a generated suite with no expiry race case",
            "a cluster test that only exercises a single node",
            "a generated case with no named guarantee",
        ],
    ),
    (
        "search-behavior-test-generator",
        "Search Behavior Test Generator",
        "Generate the search behaviour tests the differential and mutation packs require",
        ["analysis cases", "ranking cases", "visibility cases", "reindex cases"],
        ["search_tests.json", "generation_report.json", "generator_notes.md"],
        [
            "Generated tests cover analysis, query construct, sort, score, visibility and bulk behaviour.",
            "Pagination, partial shard failure, reindexing and alias switch cases are produced from the recorded index facts.",
            "Ranking assertions compare order and score, not membership alone.",
        ],
        [
            "a generated suite that asserts membership only",
            "a visibility test with no read-after-write case",
            "an alias switch test with no rollback case",
        ],
    ),
    (
        "object-storage-behavior-test-generator",
        "Object Storage Behavior Test Generator",
        "Generate the object storage behaviour tests the differential and mutation packs require",
        ["transfer cases", "resume cases", "version cases", "failure cases"],
        ["object_tests.json", "generation_report.json", "generator_notes.md"],
        [
            "Generated tests cover single-shot transfer, multipart, range requests and resume behaviour.",
            "Version, delete, presigned access, checksum and encryption cases are produced from the recorded bucket facts.",
            "Failure cases include interruption, mismatch, throttling and eventual visibility.",
        ],
        [
            "a generated suite with no resume case",
            "a multipart test that never aborts an upload",
            "a presigned access test with no expiry case",
        ],
    ),
    (
        "infrastructure-messaging-test-generator",
        "Infrastructure Messaging Test Generator",
        "Generate the broker-level messaging tests the differential and mutation packs require",
        ["duplicate cases", "ordering cases", "rebalance cases", "failover cases"],
        ["messaging_tests.json", "generation_report.json", "generator_notes.md"],
        [
            "Generated tests cover duplicate delivery, ordering, retry, acknowledgement and dead-letter behaviour.",
            "Rebalance, offset, producer failure, consumer crash and broker failover cases are produced per broker family.",
            "Every case is bound to the delivery guarantee it protects rather than to a broker feature name.",
        ],
        [
            "a generated suite with no duplicate delivery case",
            "a rebalance test that never revokes a partition mid-processing",
            "a case bound to a broker feature instead of a guarantee",
        ],
    ),
    (
        "infrastructure-concurrency-test-generator",
        "Infrastructure Concurrency Test Generator",
        "Generate the concurrency scenarios that only fail under real contention",
        ["concurrent update", "read-write race", "same-object contention", "operation overlap"],
        ["concurrency_tests.json", "generation_report.json", "generator_notes.md"],
        [
            "Generated scenarios cover concurrent update, read and write races and cache invalidation races.",
            "Concurrent upload of one object and multiple consumers of one message are generated explicitly.",
            "Writes during reindexing and transactions during failover are generated as overlapping-operation scenarios.",
        ],
        [
            "a concurrency suite that runs every scenario single-threaded",
            "an invalidation race scenario with deterministic ordering",
            "a failover scenario with no concurrent transaction",
        ],
    ),
    (
        "infrastructure-property-test-generator",
        "Infrastructure Property Test Generator",
        "Generate invariant properties that must hold across both systems",
        ["conservation property", "no-partial-write property", "cache neutrality", "effect uniqueness"],
        ["property_definitions.json", "property_results.json", "generator_notes.md"],
        [
            "Database properties assert value conservation after success and no partial write after failure.",
            "Cache properties assert that a hit never changes authoritative data and an eviction never changes business state.",
            "Storage properties assert content identity under matching checksums and messaging properties assert one irreversible effect per message identity.",
        ],
        [
            "a property suite with no conservation property",
            "a cache property that permits a hit to mutate authoritative data",
            "a messaging property that permits two irreversible effects for one message identity",
        ],
    ),
    (
        "database-performance-differential-pack",
        "Database Performance Differential Pack",
        "Compare database performance on query shape as well as latency",
        ["latency distribution", "query count", "plan comparison", "transaction duration"],
        ["database_performance.json", "performance_diff.json", "pack_notes.md"],
        [
            "Query latency distribution, throughput, pool wait and lock wait are compared under identical load.",
            "Query count and execution plan are compared because a rewritten access layer often multiplies round trips.",
            "Fetch size, batch size, memory, processor, network and transaction duration are all compared.",
        ],
        [
            "an access layer change that multiplies query count while latency looks acceptable",
            "a transaction whose duration grew and now holds locks longer",
            "a performance comparison run under different data volumes",
        ],
    ),
    (
        "cache-performance-differential-pack",
        "Cache Performance Differential Pack",
        "Compare cache performance including hit rate and key distribution",
        ["hit rate", "tail latency", "key distribution", "serialization cost"],
        ["cache_performance.json", "performance_diff.json", "pack_notes.md"],
        [
            "Hit rate and miss rate are compared first because a key contract change destroys both silently.",
            "Median and tail latency, network round trips and pipelining efficiency are compared under identical load.",
            "Key distribution, hot key concentration, eviction rate and memory use are compared per namespace.",
        ],
        [
            "a hit rate drop attributed to load rather than a key change",
            "a hot key created by a hash tag change",
            "a serialization cost increase absorbed into the latency budget without notice",
        ],
    ),
    (
        "search-performance-differential-pack",
        "Search Performance Differential Pack",
        "Compare search indexing and query performance under identical corpora",
        ["indexing throughput", "query latency", "resource use", "segment behaviour"],
        ["search_performance.json", "performance_diff.json", "pack_notes.md"],
        [
            "Indexing throughput, refresh cost and bulk efficiency are compared with an identical corpus.",
            "Query latency, aggregation cost and vector search cost are compared with an identical query mix.",
            "Heap use, cache behaviour, segment counts and shard distribution are compared because each shifts latency.",
        ],
        [
            "a query mix that differs between the two measured sides",
            "an indexing throughput gain achieved by weakening visibility",
            "a latency comparison run against different segment counts",
        ],
    ),
]

SKILLS[141] = [
    (
        "object-storage-performance-differential-pack",
        "Object Storage Performance Differential Pack",
        "Compare object transfer performance including first byte and resume cost",
        ["transfer throughput", "first byte latency", "part sizing", "concurrency cost"],
        ["object_performance.json", "performance_diff.json", "pack_notes.md"],
        [
            "Upload and download throughput and time to first byte are compared under identical object size distributions.",
            "Part size, concurrency and memory use are compared because a part size change alters both cost and integrity semantics.",
            "Resume cost, cross-region latency and checksum overhead are compared explicitly.",
        ],
        [
            "a throughput gain achieved by disabling checksum verification",
            "a part size change that raises request count and cost unnoticed",
            "a comparison run against different object size distributions",
        ],
    ),
    (
        "messaging-performance-differential-pack",
        "Messaging Performance Differential Pack",
        "Compare messaging performance including consumer lag and acknowledgement cost",
        ["producer latency", "consumer lag", "batch and compression", "resource use"],
        ["messaging_performance.json", "performance_diff.json", "pack_notes.md"],
        [
            "Producer latency, throughput, batching and compression efficiency are compared under identical load.",
            "Consumer lag, acknowledgement cost, rebalance frequency and backpressure onset are compared explicitly.",
            "Memory, disk and network use are compared because a batching change moves cost between them.",
        ],
        [
            "a throughput gain achieved by lowering the acknowledgement level",
            "a consumer lag regression absorbed into a longer retention window",
            "a rebalance frequency increase attributed to load rather than configuration",
        ],
    ),
    (
        "capacity-regression-gate",
        "Capacity Regression Gate",
        "Gate promotion on declared numeric capacity budgets per infrastructure class",
        ["numeric budget", "per-class threshold", "measurement parity", "no offsetting"],
        ["capacity_gate.json", "gate_result.json", "gate_notes.md"],
        [
            "Every infrastructure class carries a numeric regression budget declared before measurement.",
            "Pool wait, query count, hit rate, consumer lag and transfer throughput budgets are evaluated independently.",
            "A performance improvement never offsets a semantic defect and never lifts a failed budget.",
        ],
        [
            "a budget declared after the measurement was taken",
            "a semantic defect waved through on the strength of a latency improvement",
            "a gate pass computed from measurements taken under different load",
        ],
    ),
    (
        "infrastructure-credential-verifier",
        "Infrastructure Credential Verifier",
        "Verify credential sourcing, scope, rotation and non-exposure",
        ["credential source", "least privilege", "rotation", "non-exposure"],
        ["credential_inventory.json", "credential_findings.json", "verifier_notes.md"],
        [
            "Every credential is sourced from a broker reference and never from a literal in code, configuration or image.",
            "Scope is least privilege per resource, and rotation and expiry behaviour are verified by test.",
            "No credential, connection string secret or presigned signature appears in any log or evidence bundle.",
        ],
        [
            "a credential literal committed in a configuration file",
            "a connection string with an embedded password written to a log",
            "a credential whose rotation has never been exercised",
        ],
    ),
    (
        "database-authorization-verifier",
        "Database Authorization Verifier",
        "Verify database permissions are least privilege and tenant-safe",
        ["role scope", "object permission", "row-level policy", "tenant isolation"],
        ["database_permissions.json", "permission_findings.json", "verifier_notes.md"],
        [
            "Role, schema, table, function and sequence permissions are enumerated and compared against least privilege.",
            "Row-level policies and read and write split routing are verified so no path bypasses them.",
            "Schema change privileges are separated from application privileges and tenant isolation is proved by test.",
        ],
        [
            "an application role holding schema change privileges",
            "a row-level policy bypassed by a direct query path",
            "a tenant boundary enforced only in application code",
        ],
    ),
    (
        "cache-security-verifier",
        "Cache Security Verifier",
        "Verify cache authentication, transport security and command restriction",
        ["authentication", "transport security", "command restriction", "tenant isolation"],
        ["cache_security.json", "security_findings.json", "verifier_notes.md"],
        [
            "Authentication and transport security are required on every cache connection and verified against the real server.",
            "Administrative and scripting commands are restricted and network exposure is confirmed closed by default.",
            "Key namespace tenant isolation, persistence configuration and backup handling are verified.",
        ],
        [
            "a cache reachable without authentication from the application network",
            "an administrative command available to an application credential",
            "a cache backup stored without encryption",
        ],
    ),
    (
        "search-security-verifier",
        "Search Security Verifier",
        "Verify search index, document and field level authorisation",
        ["index permission", "document level", "field level", "cross-cluster access"],
        ["search_security.json", "security_findings.json", "verifier_notes.md"],
        [
            "Index, document level and field level permissions are enumerated and verified by negative test.",
            "Transport security, API credential scope and snapshot access are verified per cluster.",
            "Scripted query capability and cross-cluster access are restricted and multitenancy boundaries are proved.",
        ],
        [
            "a field level restriction bypassed by an aggregation",
            "a scripted query capability available to an application credential",
            "a snapshot repository readable by an unrelated tenant",
        ],
    ),
    (
        "object-storage-security-verifier",
        "Object Storage Security Verifier",
        "Verify bucket policy, encryption and public access posture",
        ["bucket policy", "public access", "encryption and keys", "audit trail"],
        ["object_security.json", "security_findings.json", "verifier_notes.md"],
        [
            "Bucket policy and object access control are enumerated and public access is confirmed denied by default.",
            "Encryption at rest, key management, presigned URL scope and retention configuration are verified.",
            "Versioning, audit trail and cross-account access are verified so an unauthorised read leaves evidence.",
        ],
        [
            "a bucket that permits public listing",
            "a presigned URL with a scope wider than the operation needs",
            "a cross-account grant with no audit trail",
        ],
    ),
    (
        "messaging-security-verifier",
        "Messaging Security Verifier",
        "Verify broker authorisation, transport security and schema permissions",
        ["topic authorisation", "transport security", "schema permission", "cross-tenant isolation"],
        ["messaging_security.json", "security_findings.json", "verifier_notes.md"],
        [
            "Topic and queue authorisation is enumerated per producer and consumer identity and verified by negative test.",
            "Transport security and authentication mechanism are verified against the real broker.",
            "Schema registry permissions, administrative capability and cross-tenant isolation are verified explicitly.",
        ],
        [
            "a consumer able to read a topic outside its tenant",
            "a producer holding administrative capability on the broker",
            "a schema registry writable by an application credential",
        ],
    ),
    (
        "infrastructure-shadow-driver",
        "Infrastructure Shadow Driver",
        "Run the target infrastructure in an isolated mode while the source stays authoritative",
        ["isolation mode", "authoritative source", "shadow resource", "intent capture"],
        ["shadow_driver_config.json", "shadow_operations.json", "driver_notes.md"],
        [
            "The source infrastructure remains authoritative and the target executes only in a declared isolation mode.",
            "Read shadow, write intent, rollback-only transaction, shadow database, index, bucket and topic modes are each declared.",
            "Captured intents are written to an isolated store and never to an authoritative resource.",
        ],
        [
            "a shadow write reaching an authoritative resource",
            "a shadow mode selected implicitly rather than declared",
            "a shadow intent written into the production evidence path",
        ],
    ),
    (
        "database-shadow-write-comparator",
        "Database Shadow Write Comparator",
        "Compare shadow database writes against the authoritative ones without touching production",
        ["statement comparison", "write set comparison", "key correlation", "isolation guarantee"],
        ["shadow_write_diff.json", "comparison_results.json", "comparator_notes.md"],
        [
            "Statements, parameters, write sets, transaction shape and lock behaviour are compared statement by statement.",
            "Final state, generated key relationships, errors and performance are compared against the authoritative run.",
            "The target never writes to the authoritative database, enforced by credentials as well as by configuration.",
        ],
        [
            "a shadow comparison run against the authoritative database",
            "a write set compared on row counts only",
            "generated key relationships compared without correlating to input rows",
        ],
    ),
    (
        "cache-dual-read-monitor",
        "Cache Dual-Read Monitor",
        "Compare old and new cache behaviour without letting the namespaces interfere",
        ["namespace separation", "value comparison", "staleness comparison", "latency comparison"],
        ["dual_read_config.json", "dual_read_results.json", "monitor_notes.md"],
        [
            "Old and new cache namespaces are fully separated so neither can populate or invalidate the other.",
            "Hit and miss rates, values, expiry, serialized form and staleness are compared per key family.",
            "Latency is compared and any divergence is classified before the cutover proceeds.",
        ],
        [
            "old and new namespaces sharing a key so one pollutes the other",
            "a value difference recorded without classification",
            "a dual read that doubles authoritative backing store load unnoticed",
        ],
    ),
    (
        "search-dual-index-verifier",
        "Search Dual-Index Verifier",
        "Verify a dual-index window on documents, ranking and aggregation before the alias switch",
        ["dual write path", "document parity", "ranking parity", "aggregation parity"],
        ["dual_index_config.json", "dual_index_results.json", "verifier_notes.md"],
        [
            "Production writes reach both indexes and the ordering guarantees of the dual write path are verified.",
            "Documents, mapping, query results, sort order, score and aggregation output are compared per query family.",
            "Visibility timing and performance are compared and the alias switch is blocked until parity holds.",
        ],
        [
            "an alias switched while ranking parity was still open",
            "a write that reached only one of the two indexes",
            "an aggregation difference recorded but not classified",
        ],
    ),
    (
        "object-storage-dual-write-verifier",
        "Object Storage Dual-Write Verifier",
        "Verify object dual write only under proved idempotency and isolation",
        ["approval requirement", "content parity", "cost accounting", "residue cleanup"],
        ["dual_write_config.json", "dual_write_results.json", "verifier_notes.md"],
        [
            "Object dual write requires a separate written approval and proved idempotency before it is enabled.",
            "Content, checksum, metadata, version and encryption parity are verified for every dual-written object.",
            "Event emission, retry behaviour, cost and residue cleanup are accounted for and reported.",
        ],
        [
            "dual write enabled without a written approval",
            "a dual-written object whose checksum was never compared",
            "duplicate downstream events triggered by dual write",
        ],
    ),
    (
        "messaging-shadow-consumer",
        "Messaging Shadow Consumer",
        "Consume real messages in shadow without acknowledging authoritative progress",
        ["independent group", "no authoritative ack", "effect suppression", "result comparison"],
        ["shadow_consumer_config.json", "shadow_results.json", "consumer_notes.md"],
        [
            "The shadow consumer uses an independent consumer group and never commits the authoritative progress position.",
            "All side effects are suppressed and captured as intents in an isolated environment.",
            "Processing results are compared against the authoritative consumer per message identity.",
        ],
        [
            "a shadow consumer sharing the authoritative consumer group",
            "a shadow consumer producing a real side effect",
            "a shadow result compared in aggregate rather than per message identity",
        ],
    ),
    (
        "infrastructure-cutover-planner",
        "Infrastructure Cutover Planner",
        "Sequence the infrastructure cutover through reversible stages",
        ["stage sequence", "entry evidence", "reversibility", "drain step"],
        ["cutover_plan.json", "stage_gates.json", "planner_notes.md"],
        [
            "Stages run from offline snapshot and historical replay through read shadow, dual read and isolated write.",
            "Low-traffic single-write, ramp-up, authority transfer and old resource drain each carry their own entry evidence.",
            "Every stage is reversible until authority transfer, and the drain step is verified before decommissioning.",
        ],
        [
            "an authority transfer performed before the isolated write stage passed",
            "a stage entered without its declared entry evidence",
            "an old resource decommissioned before its drain was verified",
        ],
    ),
]


# =============================================================================
# Segment 3 — Skill 593-764 : the infrastructure INF-E ladder and orchestrator,
# then the whole communication layer — endpoints, transports, HTTP and REST,
# serialization, schema evolution, RPC, gateway, service mesh, distributed call
# semantics, communication shadow and the COM-E ladder.
# =============================================================================

BATCHES.update({
    142: {
        "title": "Infrastructure Certification Gates and Communication Discovery Pack",
        "why": "Closes the infrastructure layer with a reversible rollback plan and the INF-E ladder, then opens the communication layer by discovering every call surface the system actually exposes and consumes.",
        "purpose": "plan infrastructure rollback, operate the INF-E2 through INF-E5 gates and their orchestrator, then inventory every endpoint, transport, context field, side-effect class, call edge, protocol version and implicit default across the communication surface.",
        "tooling": ["infrastructure rollback planner", "INF-E gate runner", "communication surface scanner", "call dependency graph builder"],
    },
    143: {
        "title": "HTTP Request and Response Contract Pack",
        "why": "Moves ELMOS from assuming HTTP is a solved abstraction to proving every element of the request and response contract survives the port.",
        "purpose": "record communication evidence and detect semantic loss, then verify method semantics, path and routing, query parameters, headers, cookies, body binding, status mapping, negotiation, caching, conditional requests, redirects and compression.",
        "tooling": ["HTTP contract builder", "routing differential", "status mapping verifier", "cache and conditional harness"],
    },
})

SKILLS[142] = [
    (
        "infrastructure-rollback-planner",
        "Infrastructure Rollback Planner",
        "Plan a reversible path back from every infrastructure cutover stage",
        ["reversibility scope", "position and version state", "namespace restoration", "old driver availability"],
        ["rollback_plan.json", "rollback_drill_results.json", "planner_notes.md"],
        [
            "Data compatibility, consumer positions, object versions, index aliases and cache namespaces each carry a named rollback action.",
            "Schema, transaction, replication and backfill state are reversible or the stage is declared irreversible in advance.",
            "Old driver availability and message replay capability are verified before any stage that depends on them for rollback.",
        ],
        [
            "a cutover stage entered with no rehearsed rollback",
            "a rollback that cannot restore consumer positions",
            "an old driver removed while it is still the rollback path",
        ],
    ),
    (
        "infrastructure-e2-gate",
        "Infrastructure E2 Gate",
        "Gate the infrastructure layer at inventory and contract completeness",
        ["inventory completeness", "driver and protocol clarity", "type mapping", "configuration parity"],
        ["inf_e2_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "The resource inventory is complete and every driver and protocol version is explicitly identified.",
            "The data type mapping is complete and the baseline contract tests pass on both sides.",
            "Connection and configuration parity is proved and no unknown critical infrastructure dependency remains.",
        ],
        [
            "a gate pass while a production endpoint is absent from the inventory",
            "a gate pass with an unknown driver version",
            "a gate pass on an incomplete type mapping",
        ],
    ),
    (
        "infrastructure-e3-gate",
        "Infrastructure E3 Gate",
        "Gate the infrastructure layer at semantic differential and mutation evidence",
        ["transaction differential", "per-class semantics", "mutation survival", "unexplained difference"],
        ["inf_e3_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "Transaction and error differential evidence is present for every relational resource in use.",
            "Cache, search, object storage and messaging semantics each carry their own differential evidence.",
            "Every infrastructure mutation pack has run with no surviving mutant and no unexplained difference remains open.",
        ],
        [
            "a gate pass with a surviving infrastructure mutant",
            "a gate pass while an acknowledgement or position difference is open",
            "a gate pass with an unexplained error mapping difference",
        ],
    ),
    (
        "infrastructure-e4-gate",
        "Infrastructure E4 Gate",
        "Gate the infrastructure layer at concurrency, fault and platform evidence",
        ["concurrency evidence", "fault injection coverage", "real platform", "rollback drill"],
        ["inf_e4_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "Concurrency, fault injection, failover, replica lag and pool exhaustion evidence are all present.",
            "Native driver and real target platform evidence, security evidence and performance evidence are complete.",
            "No resource leak remains unexplained and the rollback drill has been executed successfully.",
        ],
        [
            "a gate pass without a fault injection run at commit time",
            "a gate pass on evidence gathered from a substitute platform",
            "a gate pass with no executed rollback drill",
        ],
    ),
    (
        "infrastructure-e5-gate",
        "Infrastructure E5 Gate",
        "Gate the infrastructure layer at production replay, shadow and reconciliation evidence",
        ["historical replay", "online shadow", "cross-class reconciliation", "unsupported feature count"],
        ["inf_e5_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "Production historical replay and online shadow evidence cover the real data type and failure distribution.",
            "Data, message, object checksum and search result reconciliation all close with zero unexplained residue.",
            "Automatic rollback is armed, sustained stable operation is measured and the unsupported feature count is zero.",
        ],
        [
            "a gate pass on replay that omits the production type distribution",
            "a gate pass with an open reconciliation residue",
            "a gate pass while an unsupported infrastructure feature is still in use",
        ],
    ),
    (
        "infrastructure-migration-orchestrator",
        "Infrastructure Migration Orchestrator",
        "Sequence the infrastructure migration from discovery through the INF-E ladder",
        ["phase sequencing", "IR prerequisites", "shadow gating", "blocking condition"],
        ["infrastructure_state_machine.json", "phase_transitions.json", "orchestration_runbook.md"],
        [
            "Discovery, driver and protocol inventory, data type, transaction, consistency, failure and retry representations complete before target mapping.",
            "No cutover stage is entered before its differential, mutation and fault evidence is present.",
            "An unresolved data type mapping or an unexplained transaction difference blocks the infrastructure layer regardless of other progress.",
        ],
        [
            "a target driver selected before the failure and retry representation existed",
            "a cutover stage entered without its differential evidence",
            "an infrastructure layer level published while a type mapping is unresolved",
        ],
    ),
    (
        "communication-surface-inventory",
        "Communication Surface Inventory",
        "Discover every inbound and outbound call surface the system exposes or consumes",
        ["surface discovery", "dynamic route enumeration", "outbound target", "gateway correspondence"],
        ["communication_inventory.json", "surface_sources.json", "inventory_notes.md"],
        [
            "Endpoints, service methods, graph operations, socket and event-stream surfaces, webhooks and callbacks are all enumerated.",
            "Discovery draws on source, interface definitions, route registration, annotations, runtime traces, gateway and mesh configuration and access logs.",
            "An undocumented production route, an unenumerable dynamic route or an unidentified outbound target blocks the layer closed.",
        ],
        [
            "a production route present in the access log but absent from the inventory",
            "a runtime-generated endpoint that cannot be enumerated",
            "a gateway route with no corresponding application route",
        ],
    ),
    (
        "unified-endpoint-ir",
        "Unified Endpoint IR",
        "Describe every call surface in one representation regardless of protocol",
        ["endpoint identity", "schema triple", "effect and idempotency", "version and deprecation"],
        ["endpoint_ir.json", "endpoint_index.json", "ir_notes.md"],
        [
            "Identity, protocol, operation, path, service and the request, response and error schema triple are recorded per endpoint.",
            "Streaming mode, authentication, authorisation, idempotency requirement, timeout, retry and rate limit are part of the record.",
            "Side effect class, transaction boundary, version and deprecation state are recorded because each constrains the port.",
        ],
        [
            "an endpoint recorded without its error schema",
            "an idempotency requirement discovered only after a duplicate charge",
            "a deprecated endpoint still carrying production traffic and unrecorded",
        ],
    ),
    (
        "transport-semantic-ir",
        "Transport Semantic IR",
        "Model transport behaviour separately from the application contract",
        ["connection model", "multiplexing", "flow control", "close semantics"],
        ["transport_ir.json", "transport_capabilities.json", "ir_notes.md"],
        [
            "Connection model, multiplexing, head-of-line behaviour, stream support and flow control are recorded per transport.",
            "Header, frame, compression, transport security, keep-alive and close behaviour are recorded per transport.",
            "Cancellation and half-close semantics are recorded because they differ sharply between protocol versions.",
        ],
        [
            "a multiplexed transport replaced by a serial one without a concurrency review",
            "a half-close semantic lost in the port",
            "flow control assumed present on a transport that lacks it",
        ],
    ),
    (
        "communication-context-view",
        "Communication Context View",
        "Project the context propagation model onto the call surface",
        ["context field set", "propagation reach", "mutation authority", "clearing point"],
        ["communication_context_view.json", "propagation_map.json", "view_notes.md"],
        [
            "Request identity, correlation, trace context, baggage, principal, service identity, tenant, locale and timezone fields are bound to the authoritative model.",
            "Deadline, cancellation, idempotency key, feature flag, routing hint and security claim fields are recorded with their propagation reach.",
            "Every field declares creator, propagator, permitted mutator, reachable call types, background inheritance and clearing point.",
        ],
        [
            "a security claim mutated by a service that does not own it",
            "a background task inheriting an end-user authority implicitly",
            "a context field never cleared after the request ended",
        ],
    ),
    (
        "communication-side-effect-ir",
        "Communication Side-Effect IR",
        "Classify every operation by the effect it produces, not by its verb",
        ["effect class", "idempotency scope", "duplicate response", "long-running operation"],
        ["side_effect_ir.json", "effect_classification.json", "ir_notes.md"],
        [
            "Every operation is classified as pure query, read with observable effect, idempotent write, non-idempotent write, external irreversible effect, subscription or long-running operation.",
            "Idempotency scope and the response returned to a duplicate request are declared for every idempotent write.",
            "A verb or method name never determines the class; the observed effect does.",
        ],
        [
            "an operation classified idempotent because of its method name",
            "an external irreversible effect classified as an ordinary write",
            "a duplicate request whose response contract was never declared",
        ],
    ),
    (
        "call-dependency-graph-builder",
        "Call Dependency Graph Builder",
        "Build the complete distributed call graph with edge policy attributes",
        ["node inventory", "edge attributes", "criticality", "policy annotation"],
        ["call_graph.json", "edge_attributes.json", "builder_notes.md"],
        [
            "Nodes cover gateways, services, methods, databases, caches, brokers, third parties, object stores and identity services.",
            "Each edge records synchrony, one-way or streaming nature, retry, timeout, fallback, circuit breaker and fan-out shape.",
            "Every edge is marked critical or optional because that flag drives partial failure and budget decisions.",
        ],
        [
            "an edge with no declared timeout",
            "a critical dependency modelled as optional",
            "a fan-out edge whose maximum concurrency was never recorded",
        ],
    ),
    (
        "protocol-version-inventory",
        "Protocol Version Inventory",
        "Record the protocol and schema versions actually in use, including old clients",
        ["server version", "negotiated version", "old client population", "deprecated traffic"],
        ["protocol_versions.json", "client_population.json", "inventory_notes.md"],
        [
            "Server, client and negotiated versions are recorded per endpoint together with content type and schema identity.",
            "Gateway version rewriting is recorded because it can mask a version mismatch from the application.",
            "The old client population and deprecated endpoint traffic are measured rather than assumed to be zero.",
        ],
        [
            "an old client population assumed empty without measurement",
            "a gateway rewrite masking a protocol version mismatch",
            "a deprecated endpoint removed while it still carries traffic",
        ],
    ),
    (
        "communication-default-behavior-detector",
        "Communication Default Behavior Detector",
        "Detect and freeze every implicit default that changes observable behaviour",
        ["default inventory", "explicit freezing", "coercion policy", "security default"],
        ["communication_defaults.json", "default_differences.json", "detector_notes.md"],
        [
            "Timeout, retry, redirect, compression, body limit, header limit and keep-alive defaults are inventoried per framework and client.",
            "Transport verification, unknown field policy, type coercion and error conversion defaults are inventoried explicitly.",
            "Every default that affects business behaviour is frozen in configuration rather than inherited from a library.",
        ],
        [
            "a client that retries by default where the source did not",
            "a type coercion default that silently accepts a malformed value",
            "transport verification left at a framework default",
        ],
    ),
    (
        "protocol-capability-matcher",
        "Protocol Capability Matcher",
        "Compare source and target protocol capability dimension by dimension",
        ["streaming modes", "metadata and trailer", "error detail", "platform support"],
        ["protocol_capability_map.json", "capability_gaps.json", "matcher_notes.md"],
        [
            "Unary, client streaming, server streaming and bidirectional streaming support are compared per protocol.",
            "Backpressure, cancellation, metadata, header, trailer and error detail carrying capacity are compared explicitly.",
            "Schema evolution support, client generation, browser reachability and native platform support are recorded as gaps where absent.",
        ],
        [
            "a bidirectional stream degraded to polling with no recorded gap",
            "an error detail payload dropped because the target protocol cannot carry it",
            "a trailer-carried result lost in the port",
        ],
    ),
    (
        "communication-risk-scorer",
        "Communication Risk Scorer",
        "Score each call surface so verification depth follows real risk",
        ["effect risk", "topology risk", "client risk", "score to depth"],
        ["communication_risk_scores.json", "scoring_rules.json", "scorer_notes.md"],
        [
            "Monetary effect, non-idempotent effect, cross-tenant reach and external irreversible effect raise the score.",
            "Streaming connections, long transactions, multi-layer retry, dynamic schema and high fan-out raise the score.",
            "Third-party dependence, latency sensitivity, old mobile client population and native clients raise the score, and score drives required evidence depth.",
        ],
        [
            "a payment endpoint scored the same as a health check",
            "a score that does not change the required evidence depth",
            "an old mobile client population omitted from scoring",
        ],
    ),
]

SKILLS[143] = [
    (
        "communication-evidence-recorder",
        "Communication Evidence Recorder",
        "Record communication evidence into the shared custody model",
        ["paired capture", "protocol metadata", "decision capture", "secret redaction"],
        ["communication_evidence.json", "evidence_index.json", "recorder_notes.md"],
        [
            "Source and target requests, schemas, headers, trailers, responses and errors are captured as a matched pair.",
            "Call graph position, retry, timeout, trace, side effect and performance data accompany every captured pair.",
            "Gateway and mesh routing decisions are captured, and credentials and payload secrets are redacted to broker references.",
        ],
        [
            "a captured response with no matching request",
            "a gateway decision absent from the evidence for a routing difference",
            "an authorisation header stored in plaintext in the evidence",
        ],
    ),
    (
        "communication-semantic-loss-detector",
        "Communication Semantic Loss Detector",
        "Detect the specific semantics a communication port silently drops",
        ["contract omission", "capability degradation", "layer drift", "false success"],
        ["semantic_loss_findings.json", "loss_taxonomy.json", "detector_notes.md"],
        [
            "Missing endpoints, missing error contracts, missing headers and missing idempotency declarations are detected mechanically.",
            "Streaming degradation, lost cancellation, changed unknown field behaviour and lost or added retry layers are detected explicitly.",
            "Lost authentication context, lost trailer information and a partial response judged successful are each reported as findings.",
        ],
        [
            "an error contract dropped and never reported",
            "a retry layer added by the target framework and never noticed",
            "a partial response counted as a success",
        ],
    ),
    (
        "http-request-contract-builder",
        "HTTP Request Contract Builder",
        "Record the full request contract including the elements frameworks hide",
        ["request element set", "encoding declaration", "client identity", "peer address semantics"],
        ["http_request_contract.json", "contract_index.json", "builder_notes.md"],
        [
            "Method, scheme, host, port, path, query, headers, cookies and body are recorded per endpoint.",
            "Content type, content encoding and transfer encoding are recorded separately because frameworks conflate them.",
            "Client certificate and peer address semantics are recorded because proxy layers change both.",
        ],
        [
            "a content encoding conflated with a transfer encoding",
            "a peer address read from an unvalidated forwarded header",
            "a client certificate requirement lost behind a proxy",
        ],
    ),
    (
        "http-method-semantic-verifier",
        "HTTP Method Semantic Verifier",
        "Verify per-method safety, idempotency and cacheability against real behaviour",
        ["safety", "measured idempotency", "cacheability", "body permissibility"],
        ["method_semantics.json", "method_results.json", "verifier_notes.md"],
        [
            "Safety, idempotency, cacheability, body permissibility and retry permissibility are recorded per method and endpoint.",
            "A method's conventional idempotency is never accepted as evidence that the business implementation is idempotent.",
            "Proxy and gateway handling and duplicate submission behaviour are measured for every mutating method.",
        ],
        [
            "an update method assumed idempotent because of its verb",
            "a method with a body on one side and no body on the other",
            "a mutating request cached by an intermediary",
        ],
    ),
    (
        "path-and-routing-verifier",
        "Path and Routing Verifier",
        "Verify path matching, encoding and route priority equivalence",
        ["path encoding", "trailing separator", "route priority", "duplicate rewrite"],
        ["routing_semantics.json", "routing_results.json", "verifier_notes.md"],
        [
            "Path parameters, percent encoding, trailing separators, case handling and empty segments are compared explicitly.",
            "Wildcards, route priority, version prefixes, rewriting and base paths are compared route by route.",
            "Gateway rewriting and application rewriting are reconciled so no path is rewritten twice.",
        ],
        [
            "an encoded separator decoded differently by the two implementations",
            "a trailing separator that triggers an automatic redirect on one side only",
            "a route priority change that shadows a previously reachable route",
        ],
    ),
    (
        "query-parameter-semantic-verifier",
        "Query Parameter Semantic Verifier",
        "Verify query parameter parsing including repeats, arrays and unknowns",
        ["absence versus empty", "repeated parameter", "array encoding", "unknown parameter"],
        ["query_semantics.json", "query_results.json", "verifier_notes.md"],
        [
            "Missing, empty and repeated parameters are distinguished and each carries a declared behaviour.",
            "Array encoding style, ordering significance and percent encoding are compared explicitly.",
            "Boolean, date, decimal and enum parsing and unknown parameter policy are verified rather than inherited.",
        ],
        [
            "a repeated parameter where one side takes the first and the other the last",
            "an empty parameter treated as absent on one side",
            "an unknown parameter silently accepted where it was previously rejected",
        ],
    ),
    (
        "http-header-contract-verifier",
        "HTTP Header Contract Verifier",
        "Verify header casing, duplication and trust boundaries",
        ["case handling", "duplicate merging", "forwarded trust", "custom header survival"],
        ["header_contract.json", "header_results.json", "verifier_notes.md"],
        [
            "Header case handling, duplicate headers and comma merging behaviour are compared implementation to implementation.",
            "Authentication, idempotency, trace, tenant, content, cache, range and conditional headers are each verified end to end.",
            "Forwarded headers are trusted only from a declared proxy hop and custom tracing headers are proved to survive the port.",
        ],
        [
            "two distinct headers merged into one comma-joined value",
            "a forwarded header trusted from an arbitrary client",
            "a custom tracing header dropped by the target framework",
        ],
    ),
    (
        "cookie-semantic-verifier",
        "Cookie Semantic Verifier",
        "Verify cookie attributes, protection and deletion behaviour",
        ["attribute parity", "security attributes", "signing and encryption", "deletion behaviour"],
        ["cookie_semantics.json", "cookie_results.json", "verifier_notes.md"],
        [
            "Name, domain, path, expiry, maximum age and partition attributes are compared cookie by cookie.",
            "Secure, script-inaccessible and cross-site attributes are verified as at least as strict as the source.",
            "Signing, encryption, session rotation and deletion behaviour are verified because a mismatch silently breaks logout.",
        ],
        [
            "a cross-site attribute relaxed during the port",
            "a session cookie that survives a rotation it should have invalidated",
            "a deletion that does not actually clear the cookie in the browser",
        ],
    ),
    (
        "http-body-binding-verifier",
        "HTTP Body Binding Verifier",
        "Verify body parsing including absence, size limits and re-readability",
        ["absent versus empty body", "length and chunking", "size limits", "re-readability"],
        ["body_binding.json", "body_results.json", "verifier_notes.md"],
        [
            "An empty body and a missing body are distinguished and each carries a declared behaviour.",
            "Content length, chunked transfer, compression, multipart, form and binary handling are compared explicitly.",
            "Maximum body size and whether the body can be read more than once are verified because retry and signing depend on both.",
        ],
        [
            "an empty body treated as a missing body",
            "a body that cannot be re-read, breaking signature verification",
            "a body size limit removed by the target framework",
        ],
    ),
    (
        "http-response-contract-verifier",
        "HTTP Response Contract Verifier",
        "Verify the response contract including empty responses and stream closure",
        ["status and headers", "empty response", "trailer", "stream closure"],
        ["response_contract.json", "response_results.json", "verifier_notes.md"],
        [
            "Status, headers, cookies, content type, body and content length are compared response by response.",
            "Compression, caching headers and trailers are compared because intermediaries treat each differently.",
            "Empty and no-content responses and stream closure behaviour are verified explicitly.",
        ],
        [
            "a no-content response that gains a body in the port",
            "a trailer-carried result dropped by the target framework",
            "a stream closed without signalling completion",
        ],
    ),
    (
        "http-status-mapping-verifier",
        "HTTP Status Mapping Verifier",
        "Verify status code mapping for the distinctions clients act on",
        ["success codes", "redirect codes", "client error distinctions", "server error distinctions"],
        ["status_mapping.json", "status_results.json", "verifier_notes.md"],
        [
            "Success, created, accepted and no-content codes are mapped and tested individually.",
            "Redirect codes are distinguished by whether they preserve the method and body.",
            "Authentication versus authorisation, malformed versus unprocessable, conflict versus precondition failure, and the gateway, unavailable and timeout distinctions are each verified with the retry-after header and error body.",
        ],
        [
            "an authorisation failure returned as an authentication failure",
            "a validation failure collapsed into a generic server error",
            "an unavailable response returned without a retry-after header",
        ],
    ),
    (
        "content-negotiation-verifier",
        "Content Negotiation Verifier",
        "Verify negotiation of format, language, charset and version",
        ["accept handling", "quality weighting", "default format", "unsupported media"],
        ["negotiation_semantics.json", "negotiation_results.json", "verifier_notes.md"],
        [
            "Accept and content type handling, quality weighting and default format selection are compared explicitly.",
            "Unsupported media handling, language and charset negotiation are verified rather than assumed identical.",
            "Versioned media types and response compression negotiation are verified because both change the returned payload.",
        ],
        [
            "a default format that differs between the two implementations",
            "an unsupported media type accepted instead of rejected",
            "a versioned media type ignored so an old client receives a new payload",
        ],
    ),
    (
        "http-caching-semantic-verifier",
        "HTTP Caching Semantic Verifier",
        "Verify cache directives including the authenticated response case",
        ["cache directives", "validators", "variance", "authenticated caching"],
        ["caching_semantics.json", "caching_results.json", "verifier_notes.md"],
        [
            "Cache directives, entity tags, modification timestamps and validation responses are compared per endpoint.",
            "Variance headers are compared because an omitted one lets an intermediary serve the wrong representation.",
            "Private and public directives and staleness allowances are verified, with authenticated responses never becoming shared-cacheable.",
        ],
        [
            "an authenticated response that becomes cacheable by a shared cache",
            "a missing variance header that serves one tenant another tenant's response",
            "a validator that changes on every request and defeats caching",
        ],
    ),
    (
        "conditional-request-verifier",
        "Conditional Request Verifier",
        "Verify conditional requests used for concurrency and validation",
        ["validator strength", "precondition failure", "not-modified path", "race behaviour"],
        ["conditional_semantics.json", "conditional_results.json", "verifier_notes.md"],
        [
            "Strong and weak validators are distinguished because only strong ones are safe for concurrency control.",
            "Precondition failure and not-modified responses are verified for update, cache validation and range use cases.",
            "Concurrent update races and retry behaviour under a failed precondition are exercised explicitly.",
        ],
        [
            "a weak validator used for optimistic concurrency",
            "a failed precondition returned as a generic client error",
            "a lost update because the validator was ignored on one side",
        ],
    ),
    (
        "http-redirect-verifier",
        "HTTP Redirect Verifier",
        "Verify redirect following including method, body and credential handling",
        ["method preservation", "body resend", "credential forwarding", "loop bound"],
        ["redirect_semantics.json", "redirect_results.json", "verifier_notes.md"],
        [
            "Whether the method is preserved and whether the body is resent are verified per redirect status code.",
            "Authorisation header and cookie forwarding across a redirect are verified, especially across origins.",
            "Redirect loops are bounded and the maximum hop count is compared between implementations.",
        ],
        [
            "an authorisation header forwarded to a different origin on redirect",
            "a mutating request converted to a safe one by a redirect",
            "an unbounded redirect loop in the target client",
        ],
    ),
    (
        "http-compression-verifier",
        "HTTP Compression Verifier",
        "Verify compression on both directions including decompression bounds",
        ["algorithm support", "request compression", "streaming interaction", "expansion bound"],
        ["compression_semantics.json", "compression_results.json", "verifier_notes.md"],
        [
            "Supported algorithms, size thresholds and negotiated selection are compared per endpoint.",
            "Request-side and response-side compression are verified separately, including their interaction with streaming and content length.",
            "A decompression expansion bound is enforced so a compressed payload cannot exhaust memory.",
        ],
        [
            "a compressed payload that expands without bound on decompression",
            "a response compressed twice by the application and the proxy",
            "compression that breaks streaming by buffering the whole response",
        ],
    ),
]

BATCHES.update({
    144: {
        "title": "REST Contract and Serialization Format Pack",
        "why": "Moves ELMOS from format-level round-trip checks to proving presence, numeric and polymorphic semantics survive every wire format in use.",
        "purpose": "verify streaming, idempotency, pagination and interface-definition fidelity for REST, then project the serialization model onto the wire and verify the six-state presence model, five format families, custom binary framing, polymorphism, numerics, temporal values and binary payloads.",
        "tooling": ["idempotency harness", "interface definition differential", "serialization format packs", "presence state harness"],
    },
    145: {
        "title": "Serialization Limits and Schema Evolution Pack",
        "why": "Moves ELMOS from a one-shot schema comparison to a governed evolution process bound to the real consumer population.",
        "purpose": "bound serialization resource use and run the serialization differential, then register every schema, classify compatibility direction, verify addition, removal, rename, type, enum, default, presence and reservation changes, and gate release on the real consumer inventory.",
        "tooling": ["serialization limit enforcer", "serialization differential harness", "schema registry", "compatibility gate"],
    },
})

SKILLS[144] = [
    (
        "http-streaming-verifier",
        "HTTP Streaming Verifier",
        "Verify streaming responses including errors after headers are sent",
        ["chunk and flush", "backpressure", "client disconnect", "error after headers"],
        ["http_streaming.json", "streaming_results.json", "verifier_notes.md"],
        [
            "Chunk boundaries, time to first byte and explicit flush behaviour are compared under identical load.",
            "Backpressure, client disconnect detection and cancellation propagation are measured rather than assumed.",
            "An error after headers are sent carries a declared signalling mechanism and never a silent truncation.",
        ],
        [
            "an error after headers that truncates the stream silently",
            "a client disconnect that leaves the server producing indefinitely",
            "a streaming response buffered whole by the target framework",
        ],
    ),
    (
        "rest-idempotency-verifier",
        "REST Idempotency Verifier",
        "Verify the idempotency key contract under duplication, concurrency and crash",
        ["key scope and retention", "request fingerprint", "concurrent duplicate", "in-progress response"],
        ["idempotency_contract.json", "idempotency_results.json", "verifier_notes.md"],
        [
            "Key scope, retention window, request fingerprinting and success and failure caching policies are declared per endpoint.",
            "Same key with the same request, same key with a different request, and concurrent identical requests are each tested.",
            "Server crash mid-operation, unknown commit outcome and key reuse after expiry are exercised explicitly.",
        ],
        [
            "the same key with a different body silently returning the first result",
            "two concurrent duplicates both producing an effect",
            "a retention window shorter than the client's maximum retry horizon",
        ],
    ),
    (
        "rest-pagination-contract-verifier",
        "REST Pagination Contract Verifier",
        "Verify the paging contract including token integrity and concurrent change",
        ["paging strategy", "stable ordering", "token integrity", "concurrent change"],
        ["pagination_contract.json", "pagination_results.json", "verifier_notes.md"],
        [
            "Page and size, offset and limit, and cursor strategies are distinguished with their own stability requirements.",
            "Sorting, tie breaking, total counts and filter interaction are compared page by page.",
            "Cursor tokens are signed with a declared expiry and validated so a client cannot forge a scan position.",
        ],
        [
            "an unsigned cursor token a client can modify to read other rows",
            "a page boundary that shifts under concurrent inserts",
            "an empty page returned before the real end of the result set",
        ],
    ),
    (
        "openapi-semantic-pack",
        "OpenAPI Semantic Pack",
        "Verify the interface definition against runtime behaviour rather than trusting it",
        ["definition to runtime parity", "composition keywords", "nullable versus missing", "identifier stability"],
        ["openapi_findings.json", "runtime_parity.json", "pack_notes.md"],
        [
            "Paths, operation identifiers, parameters, request bodies, responses, errors and security schemes are compared against runtime behaviour.",
            "Composition keywords, discriminators, nullability, required lists, defaults and examples are verified as generated clients interpret them.",
            "Nullable in the definition and missing on the wire are treated as different states, and operation identifier changes are flagged as client-breaking.",
        ],
        [
            "a definition that disagrees with the running service",
            "a nullable declaration used to mean an optional field",
            "an operation identifier renamed without a client migration",
        ],
    ),
    (
        "communication-serialization-view",
        "Communication Serialization View",
        "Project the serialization model onto the communication wire formats",
        ["wire format binding", "field ordering", "reference handling", "version carriage"],
        ["communication_serialization_view.json", "format_bindings.json", "view_notes.md"],
        [
            "Format, schema, field, wire name, type, presence, default and ordering facts bind to the authoritative serialization record.",
            "Polymorphism, reference preservation, enum, numeric, temporal and binary handling are recorded per format binding.",
            "Compression and schema version carriage are recorded because both change what the reader must do before decoding.",
        ],
        [
            "a wire format binding that redefines the presence model",
            "a schema version carried nowhere in the payload or its envelope",
            "a reference-preserving format ported to one that expands references",
        ],
    ),
    (
        "field-presence-verifier",
        "Field Presence Verifier",
        "Verify the six presence states survive every encoder and decoder",
        ["six-state distinction", "language absence mapping", "default injection", "round-trip fidelity"],
        ["presence_matrix.json", "presence_results.json", "verifier_notes.md"],
        [
            "Missing, explicit null, defaulted, empty, zero and present are distinguished at every encode and decode boundary.",
            "Each language's absence construct is mapped explicitly so no two states collapse into one.",
            "Merging any two states requires a decision record and a regression test that proves the merge is safe.",
        ],
        [
            "an undefined value encoded as an explicit null",
            "a wire default read back as a field the producer actually sent",
            "a zero value indistinguishable from a missing field",
        ],
    ),
    (
        "json-semantic-pack",
        "JSON Semantic Pack",
        "Verify text-format semantics the specification does not define",
        ["numeric limits", "key handling", "unicode validity", "unrepresentable types"],
        ["json_findings.json", "json_results.json", "pack_notes.md"],
        [
            "Number precision, large integers, decimals, duplicate keys and key ordering are compared parser to parser.",
            "Null versus missing, arrays, objects, unicode validity and invalid surrogate handling are verified explicitly.",
            "Large integers, decimals, non-finite values, temporal values and binary data each carry an explicit encoding contract.",
        ],
        [
            "a large integer that loses precision in a parser",
            "a duplicate key resolved differently by the two parsers",
            "a non-finite value emitted where the reader cannot parse it",
        ],
    ),
    (
        "xml-semantic-pack",
        "XML Semantic Pack",
        "Verify markup semantics and close the entity expansion attack surface",
        ["namespace handling", "ordering and whitespace", "mixed content", "entity safety"],
        ["xml_findings.json", "xml_results.json", "pack_notes.md"],
        [
            "Namespaces, prefixes, attributes, elements, ordering, empty elements, character data and entities are compared explicitly.",
            "Encoding, schema validation, mixed content and whitespace significance are verified rather than assumed identical.",
            "External entity resolution is disabled, entity expansion is bounded and nesting depth is capped on both sides.",
        ],
        [
            "an external entity resolved by the target parser",
            "an entity expansion that exhausts memory",
            "significant whitespace normalised away in the port",
        ],
    ),
    (
        "protobuf-semantic-pack",
        "Protobuf Semantic Pack",
        "Verify binary schema semantics including presence and unknown field retention",
        ["field numbering", "presence semantics", "unknown field retention", "reservation discipline"],
        ["protobuf_findings.json", "protobuf_results.json", "pack_notes.md"],
        [
            "Field numbers, wire types, presence, defaults, optional declarations, alternation groups and maps are compared explicitly.",
            "Packed encoding, enums, unknown field retention, reservations, services and well-known types are verified per generator.",
            "A field number is never reused, and a wire default is never read as evidence the producer set the field.",
        ],
        [
            "a field number reused for a different meaning",
            "an unknown field dropped by a target generator that should retain it",
            "a wire default interpreted as a value the producer sent",
        ],
    ),
    (
        "avro-semantic-pack",
        "Avro Semantic Pack",
        "Verify writer and reader schema resolution behaviour",
        ["writer reader resolution", "union and default", "alias handling", "registry policy"],
        ["avro_findings.json", "avro_results.json", "pack_notes.md"],
        [
            "Writer schema and reader schema resolution is verified with the real registry rather than with matching schemas.",
            "Unions, defaults, field ordering, aliases, logical types, enums and fixed types are compared explicitly.",
            "The registry compatibility mode is recorded and enforced because it decides which evolutions are accepted at write time.",
        ],
        [
            "a reader schema resolved against an unexpected writer schema",
            "a union branch order change that alters decoding",
            "a registry compatibility mode weaker than the declared policy",
        ],
    ),
    (
        "messagepack-and-cbor-pack",
        "MessagePack and CBOR Pack",
        "Verify compact binary format semantics across language codecs",
        ["integer width", "map key typing", "extension and tag", "cross-language codec"],
        ["compact_binary_findings.json", "compact_results.json", "pack_notes.md"],
        [
            "Integer width selection, map key typing, binary strings and floating point handling are compared codec to codec.",
            "Extension types and semantic tags are inventoried because they are the primary cross-language incompatibility source.",
            "Ordering significance, null handling, temporal encoding and custom types are verified through a cross-language round trip.",
        ],
        [
            "an extension type the target codec cannot decode",
            "a map key type change that reorders or collides entries",
            "a temporal tag interpreted with a different epoch",
        ],
    ),
    (
        "custom-binary-protocol-pack",
        "Custom Binary Protocol Pack",
        "Verify hand-rolled framing including partial frames and reassembly",
        ["framing", "endianness and alignment", "integrity check", "partial frame reassembly"],
        ["custom_protocol_findings.json", "protocol_results.json", "pack_notes.md"],
        [
            "Magic value, version, length prefix, endianness and alignment are recorded and verified byte by byte.",
            "Checksums, frame boundaries, field tags, optional fields, compression and encryption layers are verified explicitly.",
            "Partial frame arrival and stream reassembly are exercised because they are where hand-rolled parsers fail.",
        ],
        [
            "an endianness difference that produces plausible but wrong values",
            "a partial frame that desynchronises the stream parser",
            "a length prefix trusted without an upper bound",
        ],
    ),
    (
        "polymorphic-serialization-verifier",
        "Polymorphic Serialization Verifier",
        "Verify subtype dispatch without trusting client-supplied type names",
        ["discriminator", "subtype allowlist", "unknown subtype", "nested polymorphism"],
        ["polymorphism_contract.json", "polymorphism_results.json", "verifier_notes.md"],
        [
            "The discriminator mechanism and the mapping from discriminator value to subtype are declared explicitly per type.",
            "Subtypes resolve only through a closed allowlist; an arbitrary client-supplied type name is never used to select a type.",
            "Unknown subtype behaviour, default subtype selection, versioning and nested polymorphism are verified explicitly.",
        ],
        [
            "a deserializer that instantiates a type named by the client",
            "an unknown subtype silently mapped to a default",
            "a discriminator dropped so the subtype becomes unresolvable",
        ],
    ),
    (
        "numeric-serialization-verifier",
        "Numeric Serialization Verifier",
        "Verify numeric fidelity across every wire format and language pair",
        ["width and signedness", "decimal fidelity", "special values", "string encoded numbers"],
        ["numeric_serialization.json", "numeric_results.json", "verifier_notes.md"],
        [
            "Signed and unsigned widths, large integers, decimals and floating point values are round-tripped across every format in use.",
            "Exponent form, negative zero and non-finite values are tested explicitly because formats differ on all three.",
            "String-encoded numbers are declared where the format cannot carry the value natively, and the round trip is proved lossless.",
        ],
        [
            "a decimal degraded to a floating point value on the wire",
            "a large integer truncated by a language's native number type",
            "a negative zero that round-trips as a positive zero",
        ],
    ),
    (
        "date-and-duration-serialization-verifier",
        "Date and Duration Serialization Verifier",
        "Verify temporal encoding including precision, offset and sentinel values",
        ["encoding form", "precision", "offset carriage", "sentinel values"],
        ["temporal_serialization.json", "temporal_results.json", "verifier_notes.md"],
        [
            "Textual and epoch encodings are distinguished with their unit, and precision is declared rather than inferred.",
            "Timezone and offset carriage is verified because dropping an offset silently reinterprets an instant.",
            "Duration, period, date-only, null, minimum, maximum and daylight-boundary values are all round-tripped.",
        ],
        [
            "an epoch value whose unit differs between producer and consumer",
            "an offset dropped so a local time is read as a universal time",
            "a date-only value that acquires a time and a timezone in transit",
        ],
    ),
    (
        "binary-data-serialization-verifier",
        "Binary Data Serialization Verifier",
        "Verify binary payload encoding including padding and streaming",
        ["encoding variant", "padding", "length and checksum", "streaming path"],
        ["binary_serialization.json", "binary_results.json", "verifier_notes.md"],
        [
            "Raw bytes, standard and URL-safe text encodings and hexadecimal forms are distinguished per field.",
            "Padding presence, declared length and checksum handling are verified because decoders differ on all three.",
            "Streaming and memory behaviour are verified so a large payload is never fully materialised on the target side.",
        ],
        [
            "a URL-safe encoded value decoded with a standard decoder",
            "a padding difference that makes a decoder reject a valid payload",
            "a large binary payload fully materialised in memory",
        ],
    ),
]

SKILLS[145] = [
    (
        "serialization-resource-limit-verifier",
        "Serialization Resource Limit Verifier",
        "Bound every decoder resource so a payload cannot exhaust the process",
        ["size and depth bounds", "element count bounds", "recursion guard", "expansion bound"],
        ["serialization_limits.json", "limit_results.json", "verifier_notes.md"],
        [
            "Maximum body size, nesting depth, array length, string length and field count are declared and enforced per decoder.",
            "Recursive structures and compression expansion ratios are bounded so neither can exhaust memory or processor time.",
            "A limit breach produces a declared error response and never an unbounded allocation or a process termination.",
        ],
        [
            "a decoder with no nesting depth limit",
            "a compressed payload that expands past available memory",
            "a limit breach that terminates the process instead of returning an error",
        ],
    ),
    (
        "serialization-differential-harness",
        "Serialization Differential Harness",
        "Run encode, decode and cross-version round trips on both implementations",
        ["encode and decode parity", "cross-version matrix", "invalid input parity", "resource parity"],
        ["serialization_differential.json", "differential_results.json", "harness_notes.md"],
        [
            "Encode, decode and round-trip results are compared byte for byte or under a declared canonical form.",
            "Old writer to new reader and new writer to old reader are both run, not only the matched-version case.",
            "Invalid input, unknown field and unknown enum handling are compared, along with performance and resource use.",
        ],
        [
            "a differential run only on matched schema versions",
            "an invalid input accepted by one implementation and rejected by the other",
            "a canonical form assumed rather than declared",
        ],
    ),
    (
        "schema-registry-builder",
        "Schema Registry Builder",
        "Register every schema in the system with its owner, consumers and policy",
        ["schema identity", "ownership", "consumer binding", "compatibility policy"],
        ["schema_registry.json", "schema_index.json", "builder_notes.md"],
        [
            "Interface, binary, record, document, graph, database event, webhook and custom schemas are all registered in one place.",
            "Schema identity, version, owner, producers and consumers are recorded per entry.",
            "Compatibility policy, deprecation state, retention and release binding are recorded so evolution decisions are checkable.",
        ],
        [
            "a schema in production that is absent from the registry",
            "a schema with no recorded owner",
            "a compatibility policy declared nowhere and enforced nowhere",
        ],
    ),
    (
        "compatibility-direction-classifier",
        "Compatibility Direction Classifier",
        "Classify each change by direction and judge it against the real stack",
        ["backward", "forward", "full", "coordinated upgrade"],
        ["compatibility_classification.json", "classification_results.json", "classifier_notes.md"],
        [
            "Every change is classified as backward compatible, forward compatible, fully compatible or requiring coordinated upgrade.",
            "The judgement combines the schema, the concrete serialization implementation, business validation and the actual consumer set.",
            "A schema-level compatibility claim is never accepted alone when the serialization library or business validation narrows it.",
        ],
        [
            "a change judged compatible at schema level while the library rejects it",
            "a forward compatibility claim with no old reader to test against",
            "a coordinated upgrade classified as backward compatible",
        ],
    ),
    (
        "field-addition-verifier",
        "Field Addition Verifier",
        "Verify field additions against old readers and generated clients",
        ["optionality", "default injection", "old reader behaviour", "client regeneration"],
        ["field_addition.json", "addition_results.json", "verifier_notes.md"],
        [
            "Whether the new field is required or optional and how its default is supplied are declared before the change lands.",
            "Old reader behaviour and new writer behaviour are both tested against real historical payloads.",
            "A newly required field is treated as breaking unless the transport and every consumer have a proved default path.",
        ],
        [
            "a required field added and called backward compatible",
            "a new field whose business meaning is undefined for old data",
            "a generated client that fails to compile after the addition",
        ],
    ),
    (
        "field-removal-verifier",
        "Field Removal Verifier",
        "Verify field removals against every consumer and every historical store",
        ["consumer usage", "unknown field policy", "identifier reservation", "historical data"],
        ["field_removal.json", "removal_results.json", "verifier_notes.md"],
        [
            "Every consumer is checked for actual use of the field before removal, not only the ones known to the owning team.",
            "Unknown field retention policy and identifier reservation are applied so the slot can never be reused.",
            "Historical database rows, cached payloads and replayable messages are checked because all three outlive the schema.",
        ],
        [
            "a field removed while a batch consumer still reads it",
            "a removed field's identifier left unreserved",
            "a cached payload that becomes unreadable after removal",
        ],
    ),
    (
        "field-rename-verifier",
        "Field Rename Verifier",
        "Verify renames run as an expand and contract sequence, never as an overwrite",
        ["add new field", "dual read and write", "consumer migration", "old field removal"],
        ["field_rename_plan.json", "rename_results.json", "verifier_notes.md"],
        [
            "A rename is executed as add, dual read and write, consumer migration, stop old write and finally remove.",
            "Each stage is independently reversible and its exit condition is measured against real consumer traffic.",
            "The old field is never overwritten in place, because that breaks every reader that has not migrated.",
        ],
        [
            "a rename applied as an in-place overwrite",
            "an old field write stopped while consumers still read it",
            "a rename stage with no measured consumer migration",
        ],
    ),
    (
        "type-change-verifier",
        "Type Change Verifier",
        "Verify type changes for precision, overflow and historical readability",
        ["widening versus narrowing", "representation change", "overflow and precision", "historical readability"],
        ["type_change.json", "type_change_results.json", "verifier_notes.md"],
        [
            "Widening and narrowing are distinguished, and narrowing is treated as breaking unless every value is proved to fit.",
            "Text and numeric, integer width, floating point and decimal, enum and text, and object and array changes are each tested.",
            "Historical data readability is proved before the change lands, and any precision loss or overflow blocks it.",
        ],
        [
            "an integer width narrowing that overflows on existing data",
            "a decimal changed to a floating point type",
            "a type change that makes archived payloads unreadable",
        ],
    ),
    (
        "enum-evolution-verifier",
        "Enum Evolution Verifier",
        "Verify enum evolution against a declared unknown value policy",
        ["value addition", "value removal", "identifier reuse", "unknown value policy"],
        ["enum_evolution.json", "enum_results.json", "verifier_notes.md"],
        [
            "Additions, removals, renames and numeric identifier reuse are each classified before the change lands.",
            "Every consumer declares an explicit unknown value policy of reject, preserve or map, and it is verified by test.",
            "Exhaustive branching in generated clients and database enum types are checked because both break on new values.",
        ],
        [
            "a numeric enum identifier reused for a different meaning",
            "a consumer with no declared unknown value policy",
            "an exhaustive branch in a generated client that fails on a new value",
        ],
    ),
    (
        "default-value-evolution-verifier",
        "Default Value Evolution Verifier",
        "Verify default changes that alter behaviour without altering the schema",
        ["injection site", "layer attribution", "old data effect", "explicit versus default"],
        ["default_evolution.json", "default_results.json", "verifier_notes.md"],
        [
            "The site where each default is injected is identified as producer, serializer, consumer or domain layer.",
            "The effect of a default change on old data and on missing fields is measured, not reasoned about.",
            "An explicitly sent zero or null is distinguished from an injected default at every layer.",
        ],
        [
            "a default changed in the consumer and assumed harmless",
            "an explicit zero indistinguishable from an injected default",
            "a behaviour change shipped with no schema change and no review",
        ],
    ),
    (
        "presence-evolution-verifier",
        "Presence Evolution Verifier",
        "Verify migrations between presence models",
        ["presence model migration", "implicit default", "nullable transition", "alternation group"],
        ["presence_evolution.json", "presence_migration_results.json", "verifier_notes.md"],
        [
            "Migrations between no-presence, implicit default, optional, nullable and alternation group models are each classified.",
            "Every migration is tested against historical payloads with both the old and the new reader.",
            "A migration that makes two of the six presence states indistinguishable is blocked rather than documented.",
        ],
        [
            "a move to implicit default that erases the missing state",
            "a nullable transition that changes how old data reads",
            "an alternation group migration with no historical payload test",
        ],
    ),
    (
        "schema-reservation-verifier",
        "Schema Reservation Verifier",
        "Verify that retired identifiers and names can never be reused",
        ["numeric reservation", "name reservation", "alias registry", "deprecation marking"],
        ["reservation_registry.json", "reservation_results.json", "verifier_notes.md"],
        [
            "Retired field numbers, enum numbers, record aliases, deprecated graph fields and custom protocol tags are all reserved.",
            "The reservation registry is enforced at build time so a reuse fails the build rather than production.",
            "Database event field names are reserved on the same basis because replayed history carries them.",
        ],
        [
            "a retired field number reused in a later revision",
            "a reservation recorded in a comment rather than enforced",
            "an alias removed while archived data still uses it",
        ],
    ),
    (
        "consumer-inventory-and-impact-analyzer",
        "Consumer Inventory and Impact Analyzer",
        "Locate every consumer before judging any schema change safe",
        ["consumer discovery", "long-lived clients", "replay consumers", "unconfirmed population"],
        ["consumer_inventory.json", "impact_analysis.json", "analyzer_notes.md"],
        [
            "Services, mobile clients, browsers, third parties, data platforms, batch jobs, archive replay and offline tools are all enumerated.",
            "Long-lived and offline clients are counted from telemetry rather than assumed upgraded.",
            "When the full consumer population cannot be confirmed upgraded, the old schema is treated as still in use.",
        ],
        [
            "an old schema retired on the assumption that no one uses it",
            "an archive replay consumer omitted from the inventory",
            "a third-party consumer discovered only after the change shipped",
        ],
    ),
    (
        "schema-compatibility-test-generator",
        "Schema Compatibility Test Generator",
        "Generate the full writer and reader compatibility matrix from real fixtures",
        ["four-way matrix", "unknown handling", "absence cases", "historical fixtures"],
        ["compatibility_tests.json", "generation_report.json", "generator_notes.md"],
        [
            "Old writer to old reader, old to new, new to old and new to new cases are all generated for every change.",
            "Unknown field, unknown enum, missing, null and default cases are generated for each direction.",
            "Historical production payload fixtures are used as inputs rather than synthetic ones alone.",
        ],
        [
            "a matrix that omits the new writer to old reader direction",
            "compatibility tested only against synthetic payloads",
            "an unknown enum case absent from the generated suite",
        ],
    ),
    (
        "schema-migration-planner",
        "Schema Migration Planner",
        "Sequence schema change through reversible expand and contract stages",
        ["stage sequence", "dual read and write", "consumer migration", "reversibility"],
        ["schema_migration_plan.json", "stage_gates.json", "planner_notes.md"],
        [
            "Stages run expand, dual read, dual write, consumer migration, stop old write, observation and finally contract.",
            "Every stage declares its entry evidence and its exit measurement against real consumer traffic.",
            "Every stage is reversible, and the contract stage is entered only after the observation window closes clean.",
        ],
        [
            "a contract stage entered before consumer migration completed",
            "an observation window skipped because the change looked safe",
            "a stage with no defined reverse action",
        ],
    ),
    (
        "schema-compatibility-release-gate",
        "Schema Compatibility Release Gate",
        "Gate release on identified consumers and zero unresolved compatibility findings",
        ["consumer identification", "direction evidence", "reuse count", "historical payload result"],
        ["schema_gate.json", "gate_result.json", "gate_notes.md"],
        [
            "Every critical consumer is identified before the gate evaluates, and an unidentified consumer fails it closed.",
            "Backward compatibility evidence is required, and forward compatibility is required or explicitly approved with a named approver.",
            "Reused field numbers, unresolved unknown enum behaviour and historical payload failures must each be zero.",
        ],
        [
            "a gate pass with an unidentified critical consumer",
            "a forward compatibility waiver with no named approver",
            "a gate pass while a historical payload still fails to decode",
        ],
    ),
]

BATCHES.update({
    146: {
        "title": "RPC, Graph and Streaming Protocol Pack",
        "why": "Moves ELMOS from treating remote calls as function calls to proving status, deadline, streaming order and nullability semantics survive the port.",
        "purpose": "model the RPC method surface, verify binary RPC status, deadline, streaming and service evolution semantics, then verify graph nullability, resolver behaviour, query cost and subscriptions, and the socket, event-stream and message-based call surfaces.",
        "tooling": ["RPC method IR", "status mapping verifier", "streaming order harness", "graph cost analyser"],
    },
    147: {
        "title": "RPC Surface Closure and API Gateway Pack",
        "why": "Moves ELMOS from an application-only view of the contract to one that includes everything the gateway decides before the application sees the request.",
        "purpose": "close the RPC surface with reflection and custom protocol verification, then inventory the gateway, model its routing, and verify route equivalence, authentication, rate limiting, timeouts, retries, circuit breaking, transformations, cross-origin policy, protection limits, canary and shadow routing and observability.",
        "tooling": ["gateway inventory builder", "gateway routing IR", "route equivalence verifier", "gateway policy harness"],
    },
})

SKILLS[146] = [
    (
        "unified-rpc-method-ir",
        "Unified RPC Method IR",
        "Describe every remote method with its status, deadline and streaming contract",
        ["method identity", "streaming shape", "status contract", "metadata carriage"],
        ["rpc_method_ir.json", "method_index.json", "ir_notes.md"],
        [
            "Service, method, request, response and unary or streaming shape are recorded per method.",
            "Metadata, deadline, cancellation, status codes and error detail payloads are part of the record.",
            "Idempotency, retry policy, authentication and load balancing facts are recorded because each constrains the port.",
        ],
        [
            "a method recorded without its streaming shape",
            "an error detail payload absent from the method record",
            "a method with no declared deadline",
        ],
    ),
    (
        "grpc-semantic-pack",
        "gRPC Semantic Pack",
        "Verify binary RPC framework semantics across all four call shapes",
        ["four call shapes", "metadata and trailer", "flow control", "load balancing"],
        ["grpc_findings.json", "grpc_results.json", "pack_notes.md"],
        [
            "Unary, client streaming, server streaming and bidirectional streaming are each exercised, not only the unary shape.",
            "Metadata, trailers, status, deadline, cancellation and compression behaviour are compared implementation to implementation.",
            "Flow control, health checking, reflection and client-side load balancing are verified against the real target stack.",
        ],
        [
            "a bidirectional stream tested only in the unary direction",
            "a trailer-carried status detail lost by the target client",
            "client-side load balancing replaced by a single connection",
        ],
    ),
    (
        "grpc-status-mapping-verifier",
        "gRPC Status Mapping Verifier",
        "Verify that every status code survives the language boundary distinctly",
        ["full code coverage", "language exception mapping", "detail preservation", "retryability"],
        ["status_map.json", "status_map_results.json", "verifier_notes.md"],
        [
            "Every status code in the enumeration is exercised and mapped explicitly in every language pair in use.",
            "Language-specific exceptions are never all collapsed into a single internal status.",
            "Error detail payloads and the retryability implied by each status are preserved through the mapping.",
        ],
        [
            "every target exception mapped to the internal status",
            "a cancelled call reported as an unknown failure",
            "an error detail payload dropped during status mapping",
        ],
    ),
    (
        "grpc-deadline-and-cancellation-verifier",
        "gRPC Deadline and Cancellation Verifier",
        "Verify deadline propagation and what actually stops when a call is cancelled",
        ["deadline propagation", "downstream cancellation", "server continuation", "resource cleanup"],
        ["deadline_semantics.json", "cancellation_results.json", "verifier_notes.md"],
        [
            "Client deadline, server context and downstream propagation are verified as one continuous budget.",
            "Stream cancellation, transaction rollback and resource cleanup on cancellation are measured, not assumed.",
            "Whether the server continues executing after client cancellation is measured and declared per method.",
        ],
        [
            "a deadline that stops at the first hop and is not propagated",
            "a cancelled call whose server work continues to completion unnoticed",
            "a cancellation that leaves a transaction open",
        ],
    ),
    (
        "grpc-streaming-order-verifier",
        "gRPC Streaming Order Verifier",
        "Verify streaming ordering, half-close and error-after-start behaviour",
        ["message ordering", "half-close", "backpressure", "resumption"],
        ["streaming_order.json", "streaming_results.json", "verifier_notes.md"],
        [
            "Message ordering and half-close semantics are verified in both directions of a bidirectional stream.",
            "Backpressure, buffering and flow control behaviour are measured under a slow reader.",
            "Client cancellation, server error mid-stream, partial results and reconnection or resumption support are exercised explicitly.",
        ],
        [
            "a stream that reorders messages under backpressure",
            "a half-close that the target implementation ignores",
            "a mid-stream error indistinguishable from normal completion",
        ],
    ),
    (
        "protobuf-service-evolution-verifier",
        "Protobuf Service Evolution Verifier",
        "Verify service-level evolution beyond message-level compatibility",
        ["service and method naming", "message type change", "streaming shape change", "client regeneration"],
        ["service_evolution.json", "evolution_results.json", "verifier_notes.md"],
        [
            "Service renames, method renames and package changes are classified as breaking for existing clients.",
            "Request and response type changes are verified with the message-level compatibility matrix, not assumed safe.",
            "A streaming shape change is always breaking, and generated client compatibility is proved before release.",
        ],
        [
            "a method renamed with old clients still deployed",
            "a unary method converted to streaming without a version bump",
            "a package change that silently breaks every generated client",
        ],
    ),
    (
        "graphql-semantic-pack",
        "GraphQL Semantic Pack",
        "Verify graph schema and execution semantics against the real resolvers",
        ["schema surface", "operation types", "directive and deprecation", "execution behaviour"],
        ["graphql_findings.json", "graphql_results.json", "pack_notes.md"],
        [
            "Schema types, interfaces, unions, arguments, defaults, directives and deprecation markers are compared explicitly.",
            "Query, mutation and subscription operations are each exercised with their real resolver stack.",
            "Error shape, batching behaviour and complexity handling are verified because each differs between server implementations.",
        ],
        [
            "a union or interface resolved differently by the target server",
            "a directive silently ignored by the target implementation",
            "a deprecated field removed while clients still request it",
        ],
    ),
    (
        "graphql-nullability-verifier",
        "GraphQL Nullability Verifier",
        "Verify nullability and error bubbling map exactly onto target language types",
        ["field nullability", "list nullability", "element nullability", "error bubbling"],
        ["nullability_map.json", "nullability_results.json", "verifier_notes.md"],
        [
            "Nullable fields, non-null fields, nullable lists and nullable list elements are distinguished as four separate cases.",
            "Error bubbling behaviour is verified because a non-null field error nullifies its nearest nullable ancestor.",
            "The mapping to each target language's optional and null constructs is proved by test, not by convention.",
        ],
        [
            "a non-null field that becomes optional in the generated target type",
            "a nullable list conflated with a list of nullable elements",
            "an error that bubbles further than the source implementation bubbled it",
        ],
    ),
    (
        "graphql-resolver-behavior-verifier",
        "GraphQL Resolver Behavior Verifier",
        "Verify resolver execution order, batching and partial result semantics",
        ["resolution order", "batching", "partial result", "side effect scope"],
        ["resolver_behaviour.json", "resolver_results.json", "verifier_notes.md"],
        [
            "Resolver ordering, parent object propagation, context availability and authorisation checks are verified per field.",
            "Batching behaviour is verified so a port does not reintroduce per-element downstream calls.",
            "Partial results, error placement, transaction scope, side effects and cancellation are measured explicitly.",
        ],
        [
            "a batched loader lost in the port so downstream calls multiply",
            "an authorisation check that runs on the parent but not the field",
            "a mutation side effect executed during a partially failed operation",
        ],
    ),
    (
        "graphql-query-cost-verifier",
        "GraphQL Query Cost Verifier",
        "Bound query cost so a single operation cannot exhaust the service",
        ["depth and breadth limits", "complexity scoring", "alias and fragment expansion", "introspection policy"],
        ["query_cost_policy.json", "cost_results.json", "verifier_notes.md"],
        [
            "Depth, field count and complexity score limits are declared and enforced identically on both implementations.",
            "Alias multiplication, fragment expansion and batched operations are counted toward the cost rather than bypassing it.",
            "Introspection exposure, rate limiting and per-operation timeouts are declared per environment.",
        ],
        [
            "an aliased query that multiplies cost past the declared limit",
            "introspection left enabled in a production environment",
            "a complexity limit enforced on one implementation only",
        ],
    ),
    (
        "graphql-subscription-verifier",
        "GraphQL Subscription Verifier",
        "Verify subscription transport, authorisation lifetime and event delivery",
        ["transport and handshake", "authorisation refresh", "event ordering", "resource release"],
        ["subscription_semantics.json", "subscription_results.json", "verifier_notes.md"],
        [
            "Transport, connection authentication and reconnection behaviour are verified against the real client stack.",
            "Event ordering, filtering and backpressure behaviour are measured under a slow consumer.",
            "Authorisation is re-evaluated over the subscription lifetime and every resource is released on disconnect.",
        ],
        [
            "a subscription that keeps delivering after the principal's authorisation was revoked",
            "events reordered under backpressure",
            "a disconnected subscription whose server resources are never released",
        ],
    ),
    (
        "websocket-semantic-pack",
        "WebSocket Semantic Pack",
        "Verify socket handshake, framing, liveness and close semantics",
        ["handshake and subprotocol", "framing and fragmentation", "liveness", "close code"],
        ["websocket_findings.json", "websocket_results.json", "pack_notes.md"],
        [
            "Handshake, subprotocol negotiation and connection authentication are verified against the real client and proxy path.",
            "Text and binary framing, fragmentation, liveness probes and message ordering are compared explicitly.",
            "Close codes, reconnection, backpressure, session state and resource cleanup are verified on both sides.",
        ],
        [
            "a close code collapsed so the client cannot distinguish causes",
            "a fragmented message reassembled incorrectly",
            "a session whose server state survives the connection close",
        ],
    ),
    (
        "sse-semantic-pack",
        "SSE Semantic Pack",
        "Verify event stream identity, resumption and proxy interaction",
        ["event identity", "resumption", "heartbeat", "proxy buffering"],
        ["sse_findings.json", "sse_results.json", "pack_notes.md"],
        [
            "Event identifier, event type, data framing and retry hint are compared field by field.",
            "Resumption from the last delivered identifier is verified so no event is silently skipped.",
            "Heartbeat, proxy buffering, timeout, credential expiry and resource cleanup are verified along the real network path.",
        ],
        [
            "a resumption that skips events between the last identifier and reconnect",
            "a proxy that buffers the stream and destroys its latency",
            "a stream that continues after its credential expired",
        ],
    ),
    (
        "message-based-rpc-verifier",
        "Message-Based RPC Verifier",
        "Verify request and reply over a broker including late and orphan replies",
        ["correlation", "reply routing", "late reply", "orphan handling"],
        ["message_rpc_semantics.json", "message_rpc_results.json", "verifier_notes.md"],
        [
            "Request identifier, correlation identifier and reply destination are recorded and verified per flow.",
            "Timeout, duplicate request, late reply, missing reply and retry behaviour are each exercised explicitly.",
            "Consumer restart and orphan reply handling are verified so a stale reply never resolves a newer request.",
        ],
        [
            "a late reply matched to a newer request with the same correlation value",
            "a retried request whose two replies both get processed",
            "an orphan reply that accumulates without cleanup",
        ],
    ),
    (
        "rpc-client-generation-verifier",
        "RPC Client Generation Verifier",
        "Verify generated clients preserve the contract the schema declares",
        ["generated typing", "error surface", "policy defaults", "naming stability"],
        ["client_generation.json", "generation_results.json", "verifier_notes.md"],
        [
            "Generated types, nullability and enum handling are compared against the schema for every target language.",
            "Error surface, timeout, retry and authentication defaults injected by the generator are inspected and frozen explicitly.",
            "Package and method naming stability is verified because a rename breaks every consuming build.",
        ],
        [
            "a generator that injects a retry policy the source never had",
            "a nullable schema field generated as a non-optional type",
            "a generator upgrade that renames methods silently",
        ],
    ),
    (
        "rpc-interceptor-chain-verifier",
        "RPC Interceptor Chain Verifier",
        "Verify interceptor composition and ordering rather than presence alone",
        ["chain order", "authentication position", "error mapping position", "observability position"],
        ["interceptor_chain.json", "chain_results.json", "verifier_notes.md"],
        [
            "The full chain is recorded in order for both client and server on both implementations.",
            "Authentication and authorisation run before any business handler and before any caching interceptor.",
            "Retry, timeout, circuit breaking, error mapping and observability positions are compared because order changes behaviour.",
        ],
        [
            "an authorisation interceptor placed after a caching interceptor",
            "a retry interceptor placed inside the timeout it should respect",
            "an error mapping interceptor that runs before the error is enriched",
        ],
    ),
]

SKILLS[147] = [
    (
        "rpc-reflection-and-discovery-verifier",
        "RPC Reflection and Discovery Verifier",
        "Verify reflection and discovery exposure and its production posture",
        ["reflection exposure", "registry accuracy", "health surface", "production policy"],
        ["reflection_posture.json", "discovery_results.json", "verifier_notes.md"],
        [
            "Reflection exposure is inventoried per environment and disabled in production unless explicitly approved.",
            "Service registry contents, version data and health surfaces are verified as accurate against the running services.",
            "Dynamic client construction paths are verified for schema consistency and access control.",
        ],
        [
            "reflection left enabled on a production edge service",
            "a registry entry pointing at a service version that no longer exists",
            "a dynamic client that bypasses the interceptor chain",
        ],
    ),
    (
        "custom-rpc-protocol-verifier",
        "Custom RPC Protocol Verifier",
        "Verify hand-rolled remote call protocols end to end",
        ["framing and identity", "error coding", "stream support", "reconnect behaviour"],
        ["custom_rpc_semantics.json", "custom_rpc_results.json", "verifier_notes.md"],
        [
            "Framing, request identifier, method identifier, error code space, version and endianness are verified byte by byte.",
            "Compression, encryption, streaming and cancellation support are verified rather than assumed from the design document.",
            "Partial frames and reconnection are exercised because hand-rolled protocols usually lack a recovery path.",
        ],
        [
            "a request identifier that wraps and collides under load",
            "a partial frame that desynchronises the connection permanently",
            "a cancellation the protocol cannot express",
        ],
    ),
    (
        "gateway-inventory-builder",
        "Gateway Inventory Builder",
        "Inventory every decision the gateway makes before the application sees a request",
        ["route inventory", "policy inventory", "transformation inventory", "traffic split inventory"],
        ["gateway_inventory.json", "policy_inventory.json", "inventory_notes.md"],
        [
            "Routes, upstreams, rewrites, authentication, rate limits, timeouts, retries and circuit breakers are all enumerated.",
            "Caching, cross-origin policy, protection rules, body limits and header transformations are enumerated per route.",
            "Canary and shadow configuration, logging and tracing settings are enumerated because each changes observable behaviour.",
        ],
        [
            "a gateway route absent from the inventory",
            "a header transformation the application team does not know about",
            "a shadow rule discovered only after it produced a real effect",
        ],
    ),
    (
        "gateway-routing-ir",
        "Gateway Routing IR",
        "Describe gateway routing in one representation independent of vendor syntax",
        ["match criteria", "priority and weight", "rewrite and redirect", "fallback route"],
        ["gateway_routing_ir.json", "route_index.json", "ir_notes.md"],
        [
            "Host, path, method, header and query match criteria are recorded per route with their evaluation order.",
            "Weight, priority, rewrite, redirect, upstream and fallback are part of every route record.",
            "Version and tenant routing dimensions are recorded because they decide which population a change reaches.",
        ],
        [
            "two routes whose relative priority is undefined",
            "a rewrite recorded without its interaction with the application router",
            "a tenant routing rule absent from the representation",
        ],
    ),
    (
        "gateway-route-equivalence-verifier",
        "Gateway Route Equivalence Verifier",
        "Prove the new gateway routes the same requests to the same places",
        ["route coverage", "conflict detection", "match edge cases", "default behaviour"],
        ["route_equivalence.json", "equivalence_results.json", "verifier_notes.md"],
        [
            "Every source route has a target route and every target route has a source route, with the residual reported.",
            "Route conflicts, priority, wildcards, case handling, trailing separators and path decoding are compared explicitly.",
            "Header matching, weighting, default route and unmatched request behaviour are verified with real request samples.",
        ],
        [
            "a route reachable on the source gateway and unreachable on the target",
            "a wildcard that now shadows a more specific route",
            "an unmatched request that returns a different status than before",
        ],
    ),
    (
        "gateway-authentication-verifier",
        "Gateway Authentication Verifier",
        "Verify gateway authentication without letting it replace application authorisation",
        ["mechanism parity", "credential forwarding", "identity injection", "defence in depth"],
        ["gateway_auth.json", "auth_results.json", "verifier_notes.md"],
        [
            "Token, delegated authorisation, key, mutual transport and session mechanisms are compared mechanism by mechanism.",
            "Credential forwarding and injected identity headers are verified, and injected headers are stripped from inbound requests.",
            "Application authorisation is never removed because the gateway authenticates; both layers are proved present.",
        ],
        [
            "an application authorisation check removed after gateway authentication was added",
            "a client-supplied identity header trusted by the upstream service",
            "a token accepted by the gateway that the application would have rejected",
        ],
    ),
    (
        "gateway-rate-limit-verifier",
        "Gateway Rate Limit Verifier",
        "Verify rate limiting keys, windows and failure posture",
        ["limit key", "window algorithm", "distributed counting", "failure mode"],
        ["rate_limit_policy.json", "rate_limit_results.json", "verifier_notes.md"],
        [
            "The limit key is declared explicitly per route as principal, tenant, address, route or global.",
            "Window algorithm, burst allowance and distributed counter behaviour are verified under real concurrency.",
            "The failure mode when the counter store is unavailable is declared, and the response carries a retry-after signal.",
        ],
        [
            "a limit key change that merges two tenants into one bucket",
            "a counter store failure that silently disables rate limiting",
            "a limited response with no retry-after signal",
        ],
    ),
    (
        "gateway-timeout-verifier",
        "Gateway Timeout Verifier",
        "Verify gateway timeouts nest correctly inside the end-to-end budget",
        ["timeout layers", "budget nesting", "client disconnect", "upstream cancellation"],
        ["gateway_timeouts.json", "timeout_results.json", "verifier_notes.md"],
        [
            "Connect, request, response, idle, stream and upstream timeouts are recorded and compared individually.",
            "Gateway timeouts nest inside the caller deadline and leave time for cleanup and response writing.",
            "Client disconnect propagates to upstream cancellation rather than leaving the upstream running.",
        ],
        [
            "a gateway timeout longer than the client deadline",
            "a client disconnect that leaves the upstream call running",
            "a stream timeout that terminates a healthy long-lived connection",
        ],
    ),
    (
        "gateway-retry-verifier",
        "Gateway Retry Verifier",
        "Verify gateway retry conditions, replay safety and budget participation",
        ["retry conditions", "body replay", "idempotency requirement", "budget participation"],
        ["gateway_retry.json", "retry_results.json", "verifier_notes.md"],
        [
            "Retryable methods, statuses, connect failures, resets and timeouts are declared explicitly per route.",
            "Attempt count, backoff, per-attempt timeout and request body replay capability are verified.",
            "A non-idempotent request is never retried by default, and gateway attempts count against the shared budget.",
        ],
        [
            "a mutating request retried by a gateway default",
            "a retry whose request body could not be replayed",
            "gateway retries that do not count against the end-to-end budget",
        ],
    ),
    (
        "gateway-circuit-breaker-verifier",
        "Gateway Circuit Breaker Verifier",
        "Verify gateway circuit breaking thresholds, recovery and fallback",
        ["failure threshold", "state transitions", "recovery probing", "fallback response"],
        ["gateway_breaker.json", "breaker_results.json", "verifier_notes.md"],
        [
            "Failure thresholds, open and half-open transitions and recovery timing are compared configuration to configuration.",
            "Concurrency limits, queueing and per-upstream scoping are verified under sustained failure.",
            "Error classification and the fallback response are declared so a breaker never converts a failure into a false success.",
        ],
        [
            "a breaker that returns a success-shaped fallback for a failed call",
            "recovery probing that sends all queued traffic at once",
            "a breaker scoped globally where it should be per upstream",
        ],
    ),
    (
        "gateway-request-transformation-verifier",
        "Gateway Request Transformation Verifier",
        "Verify request transformations preserve signatures and declared lengths",
        ["path rewrite", "header mutation", "body transform", "signature integrity"],
        ["request_transform.json", "transform_results.json", "verifier_notes.md"],
        [
            "Path rewrites, header additions and removals, query changes and body transformations are compared rule by rule.",
            "Version translation and content type changes are verified against what the upstream actually expects.",
            "Any transformation that invalidates a request signature or a declared content length is blocked.",
        ],
        [
            "a body transformation that invalidates a request signature",
            "a header removal that strips the caller's tracing context",
            "a rewrite applied at both the gateway and the application",
        ],
    ),
    (
        "gateway-response-transformation-verifier",
        "Gateway Response Transformation Verifier",
        "Verify response transformations do not mask errors or leak internals",
        ["status rewrite", "error shape", "header and cookie", "cache interaction"],
        ["response_transform.json", "transform_results.json", "verifier_notes.md"],
        [
            "Status rewriting, header changes, body transformation and error shape changes are compared rule by rule.",
            "A gateway never rewrites a failure status into a success status, and internal detail is never leaked outward.",
            "Compression, caching, cookie and cross-origin header interactions with the transformation are verified explicitly.",
        ],
        [
            "an upstream failure rewritten as a success",
            "an internal stack trace leaked through the transformed error body",
            "a transformation that strips a caching directive the client depends on",
        ],
    ),
    (
        "gateway-cors-verifier",
        "Gateway CORS Verifier",
        "Verify cross-origin policy including preflight and credential interaction",
        ["origin policy", "preflight", "credential interaction", "variance"],
        ["cors_policy.json", "cors_results.json", "verifier_notes.md"],
        [
            "Allowed origins, methods and headers are compared against the source policy and never widened silently.",
            "Preflight handling, maximum age and error responses are verified against real browser behaviour.",
            "A wildcard origin is never combined with credentialed requests, and the variance header is set so caches do not cross origins.",
        ],
        [
            "a wildcard origin combined with credentialed requests",
            "an origin allowlist widened during the port",
            "a cached cross-origin response served to a different origin",
        ],
    ),
    (
        "gateway-waf-and-body-limit-verifier",
        "Gateway WAF and Body Limit Verifier",
        "Verify protection rules and size limits including their false positive cost",
        ["size limits", "structural limits", "rule coverage", "false positive rate"],
        ["protection_policy.json", "protection_results.json", "verifier_notes.md"],
        [
            "Request size, header size, upload size and structural depth limits are declared and enforced identically on both paths.",
            "Traversal, injection, rate and automated-client rules are compared rule by rule against the source configuration.",
            "The false positive rate is measured against real traffic and the rejection response and audit record are declared.",
        ],
        [
            "a body limit removed during the gateway migration",
            "a protection rule that rejects legitimate production traffic",
            "a rejection with no audit record",
        ],
    ),
    (
        "gateway-canary-and-shadow-verifier",
        "Gateway Canary and Shadow Verifier",
        "Verify traffic splitting stability and shadow isolation at the edge",
        ["bucket stability", "split dimension", "shadow isolation", "response authority"],
        ["canary_shadow_config.json", "split_results.json", "verifier_notes.md"],
        [
            "Bucket assignment is stable across requests for a given principal, tenant or resource and never randomised per request.",
            "The split dimension is declared explicitly and its population share is measured rather than assumed.",
            "Shadow traffic produces no authoritative effect and the shadow response is never returned to the caller.",
        ],
        [
            "a canary bucket that reassigns on every request",
            "a shadow route that reaches an authoritative upstream",
            "a shadow response returned to the client",
        ],
    ),
    (
        "gateway-observability-verifier",
        "Gateway Observability Verifier",
        "Verify the gateway emits enough evidence to explain any request",
        ["access record fields", "trace correlation", "retry visibility", "redaction"],
        ["gateway_observability.json", "observability_results.json", "verifier_notes.md"],
        [
            "Access records carry route identity, upstream, upstream time, status, retry count, principal and tenant.",
            "Trace context correlates the gateway decision with the upstream span so a routing difference is explainable.",
            "Sensitive fields are redacted and the sampling policy never drops the records needed for a failure investigation.",
        ],
        [
            "a retry that appears nowhere in the gateway record",
            "a sampling policy that discards all failed request records",
            "an authorisation header written into an access record",
        ],
    ),
]

BATCHES.update({
    148: {
        "title": "Gateway Mutation and Service Mesh Pack",
        "why": "Moves ELMOS from reading mesh configuration to proving the mesh's identity, authorisation, retry and timeout behaviour under test.",
        "purpose": "mutate gateway policy so edge regressions are proved detectable, then inventory the mesh, model its traffic policy, and verify mutual identity, authorisation, retry interaction, timeout nesting, load balancing, outlier ejection, circuit breaking, discovery, egress, telemetry, fault injection and sidecar resourcing.",
        "tooling": ["gateway mutation pack", "mesh inventory builder", "mesh policy IR", "mesh interaction harness"],
    },
    149: {
        "title": "Distributed Call Budget and Resilience Pack",
        "why": "Moves ELMOS from per-hop correctness to end-to-end budgets, because independently reasonable retry and timeout settings compose into outages.",
        "purpose": "allocate one deadline budget across the call chain, verify cancellation propagation, establish the retry budget authority, then verify hedging, coordinated circuit breaking, bulkheads, load shedding, fan-out, partial failure aggregation, distributed idempotency, transaction boundaries, sagas, fallbacks, discovery, context propagation and clock dependence.",
        "tooling": ["deadline budget planner", "retry budget authority", "fan-out harness", "saga verifier"],
    },
})

SKILLS[148] = [
    (
        "gateway-mutation-pack",
        "Gateway Mutation Pack",
        "Mutate gateway policy so edge regressions are proved detectable",
        ["route mutation", "policy removal", "limit relaxation", "shadow escalation"],
        ["gateway_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations change route priority, remove authentication and change the rate limit key.",
            "Removed timeouts, enabled retries, changed path rewrites and relaxed cross-origin policy are mutated separately.",
            "Removed body limits, a shadow route escalated to real traffic and removed header propagation are included as mutations.",
        ],
        [
            "a removed authentication rule that no test detects",
            "a shadow route escalated to real traffic without a test failing",
            "a relaxed cross-origin policy that survives the suite",
        ],
    ),
    (
        "service-mesh-inventory-builder",
        "Service Mesh Inventory Builder",
        "Inventory every mesh-level decision that sits between two services",
        ["proxy topology", "identity and trust", "traffic policy", "telemetry configuration"],
        ["mesh_inventory.json", "policy_inventory.json", "inventory_notes.md"],
        [
            "Sidecar or proxy topology, service identity and mutual transport configuration are enumerated per workload.",
            "Route policy, retry, timeout, circuit breaking, outlier detection, load balancing and locality settings are enumerated.",
            "Ingress, egress, authorisation, telemetry and fault injection configuration are enumerated because each changes behaviour.",
        ],
        [
            "a mesh retry policy the application team does not know about",
            "a fault injection rule present in a production namespace",
            "an egress rule absent from the inventory",
        ],
    ),
    (
        "mesh-traffic-policy-ir",
        "Mesh Traffic Policy IR",
        "Describe mesh traffic policy in one representation independent of vendor syntax",
        ["workload pair", "subset and weight", "policy attributes", "priority resolution"],
        ["mesh_policy_ir.json", "policy_index.json", "ir_notes.md"],
        [
            "Source workload, destination, port, protocol, subset, route and weight are recorded per policy.",
            "Timeout, retry, load balancing and transport security settings are recorded per policy rather than per cluster.",
            "Policy priority resolution is recorded explicitly so overlapping policies have a determinate outcome.",
        ],
        [
            "two overlapping policies with no determinate precedence",
            "a subset routing rule recorded without its weight",
            "a protocol assumed rather than declared per port",
        ],
    ),
    (
        "mesh-mtls-verifier",
        "Mesh mTLS Verifier",
        "Verify mutual transport identity end to end including its fallback posture",
        ["identity and trust domain", "certificate rotation", "peer validation", "plaintext fallback"],
        ["mtls_posture.json", "mtls_results.json", "verifier_notes.md"],
        [
            "Workload identity, certificate issuance and trust domain boundaries are verified against the real control plane.",
            "Certificate rotation is exercised under load so a rotation cannot drop in-flight connections.",
            "Enforcement mode is strict wherever the source was strict, and any plaintext fallback path is enumerated and closed.",
        ],
        [
            "a permissive mode left enabled after migration",
            "a rotation that resets every in-flight connection",
            "a peer accepted from outside the declared trust domain",
        ],
    ),
    (
        "mesh-authorization-verifier",
        "Mesh Authorization Verifier",
        "Verify mesh authorisation is default-deny and matches the source policy",
        ["identity-based rules", "path and method scope", "default deny", "policy precedence"],
        ["mesh_authz.json", "authz_results.json", "verifier_notes.md"],
        [
            "Source identity, destination, method, path, port and claim conditions are compared rule by rule with the source policy.",
            "The default action is deny, and any namespace without an explicit policy is reported rather than allowed.",
            "Policy precedence and audit records are verified so an allow decision is always explainable.",
        ],
        [
            "a namespace with no policy that defaults to allow",
            "a rule widened from a specific method to all methods",
            "an allow decision with no audit record",
        ],
    ),
    (
        "mesh-retry-interaction-verifier",
        "Mesh Retry Interaction Verifier",
        "Detect and bound the multiplication of retries across every layer",
        ["layer enumeration", "worst-case multiplication", "budget enforcement", "layer ownership"],
        ["retry_layers.json", "multiplication_results.json", "verifier_notes.md"],
        [
            "Client, library, gateway, mesh and in-service retry layers are enumerated per call path.",
            "The worst-case downstream attempt count is computed from the layer product and measured under injected failure.",
            "Exactly one layer owns retry for a given hop, and every layer draws from the shared budget.",
        ],
        [
            "three retry layers each configured for three attempts",
            "a mesh retry stacked on a library retry with no shared budget",
            "a worst-case attempt count that was never computed",
        ],
    ),
    (
        "mesh-timeout-interaction-verifier",
        "Mesh Timeout Interaction Verifier",
        "Verify that timeouts nest strictly from the outermost deadline inward",
        ["timeout layers", "strict nesting", "cleanup reserve", "per-attempt budget"],
        ["timeout_layers.json", "nesting_results.json", "verifier_notes.md"],
        [
            "Client deadline, gateway timeout, mesh route timeout, per-attempt timeout, server timeout and store timeout are recorded together.",
            "Each outer timeout strictly exceeds the sum of the inner operations it wraps and reserves cleanup time.",
            "A per-attempt timeout multiplied by the attempt count never exceeds the enclosing route timeout.",
        ],
        [
            "an inner timeout longer than the outer deadline",
            "retries whose total time exceeds the route timeout",
            "a deadline with no reserve for cleanup and response writing",
        ],
    ),
    (
        "mesh-load-balancing-verifier",
        "Mesh Load Balancing Verifier",
        "Verify load balancing including affinity and draining behaviour",
        ["algorithm parity", "hash affinity", "locality preference", "draining"],
        ["load_balancing.json", "balancing_results.json", "verifier_notes.md"],
        [
            "The balancing algorithm is compared explicitly because a change redistributes load and can create hot instances.",
            "Consistent hashing and session affinity are verified where the application depends on request stickiness.",
            "Locality preference, endpoint weighting, health status and draining behaviour are measured under a rolling update.",
        ],
        [
            "a consistent hash replaced by round robin, breaking affinity",
            "a draining endpoint that still receives new requests",
            "a locality preference that isolates a zone during a partial failure",
        ],
    ),
    (
        "mesh-outlier-detection-verifier",
        "Mesh Outlier Detection Verifier",
        "Verify ejection thresholds do not remove healthy capacity",
        ["error classification", "ejection bounds", "small cluster safety", "cold start"],
        ["outlier_policy.json", "outlier_results.json", "verifier_notes.md"],
        [
            "Error classification is verified so client-caused failures do not eject a healthy instance.",
            "Ejection duration, maximum ejection percentage and recovery behaviour are bounded and tested.",
            "Small cluster and cold start behaviour are exercised because both produce false ejections.",
        ],
        [
            "a client error that ejects a healthy instance",
            "an ejection percentage that can remove the whole cluster",
            "a cold-starting instance ejected before it warmed",
        ],
    ),
    (
        "mesh-circuit-breaker-verifier",
        "Mesh Circuit Breaker Verifier",
        "Verify mesh connection and request limits and their overflow behaviour",
        ["connection limits", "pending request limits", "per-destination scope", "overflow response"],
        ["mesh_breaker.json", "breaker_results.json", "verifier_notes.md"],
        [
            "Maximum connections, pending requests, active requests and retry budgets are compared against the source configuration.",
            "Connection pool and stream limits are verified per destination rather than globally.",
            "The overflow response is declared and distinguishable from an upstream failure by the caller.",
        ],
        [
            "an overflow response indistinguishable from an upstream error",
            "a limit configured globally where it should be per destination",
            "a limit raised during migration so overload reaches the upstream",
        ],
    ),
    (
        "mesh-service-discovery-verifier",
        "Mesh Service Discovery Verifier",
        "Verify endpoint discovery, readiness and stale endpoint removal",
        ["endpoint source", "readiness gating", "removal latency", "multi-cluster"],
        ["discovery_config.json", "discovery_results.json", "verifier_notes.md"],
        [
            "Endpoint source, name resolution and control plane propagation are verified against the running topology.",
            "Readiness gating and removal latency are measured so a terminating instance stops receiving traffic in time.",
            "Stale endpoint handling, multi-cluster resolution, version subsets and port mapping are verified explicitly.",
        ],
        [
            "a terminated instance still receiving traffic",
            "an instance receiving traffic before it is ready",
            "a version subset that resolves to endpoints of the wrong version",
        ],
    ),
    (
        "mesh-egress-policy-verifier",
        "Mesh Egress Policy Verifier",
        "Verify outbound traffic is allowlisted, encrypted and auditable",
        ["allowlist", "transport security", "bypass detection", "egress identity"],
        ["egress_policy.json", "egress_results.json", "verifier_notes.md"],
        [
            "Permitted external destinations are allowlisted and any destination outside the list is denied and reported.",
            "Transport security, server name indication and name resolution behaviour are verified for every external destination.",
            "Direct bypass paths that skip the proxy are enumerated and closed, and egress identity is auditable.",
        ],
        [
            "an application that reaches an external service bypassing the proxy",
            "an egress destination allowlisted with a wildcard",
            "an external call with no audit record of its identity",
        ],
    ),
    (
        "mesh-telemetry-propagation-verifier",
        "Mesh Telemetry Propagation Verifier",
        "Verify trace context survives every hop and carries no leaked data",
        ["header propagation", "span structure", "retry visibility", "tenant redaction"],
        ["telemetry_propagation.json", "propagation_results.json", "verifier_notes.md"],
        [
            "Trace headers and baggage propagate across gateway, proxy and application hops without a break.",
            "Client and server spans, retry spans, service names and route labels are present so a call path is reconstructable.",
            "Sampling preserves failure traces, and tenant and principal identifiers are redacted according to policy.",
        ],
        [
            "a trace broken at the proxy hop so the call path cannot be reconstructed",
            "retries invisible in the trace",
            "baggage carrying an identifier that policy forbids exporting",
        ],
    ),
    (
        "mesh-fault-injection-verifier",
        "Mesh Fault Injection Verifier",
        "Verify fault injection capability and prove it cannot leak into production",
        ["injection types", "scope targeting", "retry interaction", "production exclusion"],
        ["fault_injection_config.json", "injection_results.json", "verifier_notes.md"],
        [
            "Delay, abort, reset and disconnect injections are available and scoped by route, tenant and percentage.",
            "Injection is combined with retry configuration because that combination is where amplification appears.",
            "Production namespaces exclude injection rules by policy, and the exclusion is verified rather than assumed.",
        ],
        [
            "a fault injection rule reaching a production namespace",
            "an injected delay that triggers retries and multiplies load",
            "an injection scoped by percentage with no tenant bound",
        ],
    ),
    (
        "mesh-sidecar-resource-verifier",
        "Mesh Sidecar Resource Verifier",
        "Verify proxy resource sizing and its lifecycle interaction with the application",
        ["resource sizing", "connection and buffer", "startup ordering", "shutdown draining"],
        ["sidecar_resources.json", "resource_results.json", "verifier_notes.md"],
        [
            "Processor, memory, connection, buffer and file descriptor sizing are measured against real traffic rather than defaults.",
            "Startup ordering is verified so the application never sends traffic before the proxy is ready.",
            "Shutdown draining is verified so in-flight requests complete before the proxy exits, and proxy failure impact is measured.",
        ],
        [
            "an application that starts sending before its proxy is ready",
            "a proxy that exits while requests are still in flight",
            "a proxy memory limit reached under normal peak traffic",
        ],
    ),
    (
        "service-mesh-mutation-pack",
        "Service Mesh Mutation Pack",
        "Mutate mesh policy so mesh-level regressions are proved detectable",
        ["identity downgrade", "policy removal", "resilience mutation", "lifecycle mutation"],
        ["mesh_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations downgrade mutual transport to permissive and remove the default-deny authorisation policy.",
            "Raised retry counts, removed timeouts, changed load balancing and disabled outlier detection are mutated separately.",
            "Opened egress, removed trace headers, a fault policy leaked into production and a non-draining proxy are included.",
        ],
        [
            "a downgrade to permissive transport that no test detects",
            "a removed default-deny policy that survives the suite",
            "a fault policy in production that no test flags",
        ],
    ),
]

SKILLS[149] = [
    (
        "distributed-deadline-budget-planner",
        "Distributed Deadline Budget Planner",
        "Allocate one end-to-end deadline across every hop in the call chain",
        ["total budget", "per-hop allocation", "overhead reserve", "remaining deadline"],
        ["deadline_budget.json", "budget_results.json", "planner_notes.md"],
        [
            "A single user-facing budget is allocated explicitly across gateway, services, stores and response writing.",
            "Network overhead, retry allowance and fan-out concurrency are included in the allocation rather than added on top.",
            "Each hop reads the remaining deadline from the request rather than applying a fixed local timeout.",
        ],
        [
            "per-hop timeouts that sum beyond the user-facing budget",
            "a hop applying a fixed timeout regardless of remaining deadline",
            "a budget with no reserve for cleanup and response writing",
        ],
    ),
    (
        "cancellation-propagation-verifier",
        "Cancellation Propagation Verifier",
        "Verify what a cancellation actually stops at every layer",
        ["propagation reach", "effect-specific policy", "resource release", "reconciliation path"],
        ["cancellation_map.json", "cancellation_results.json", "verifier_notes.md"],
        [
            "Client disconnect, gateway, mesh, server, remote call, store, upload, background task and publish paths are each measured.",
            "A cancelled request does not imply a cancelled business operation; a committed payment completes or reconciles rather than aborting.",
            "Every cancellation path releases its resources and records its terminal state.",
        ],
        [
            "a cancelled request that leaves a committed payment unreconciled",
            "a client disconnect that never reaches the downstream call",
            "a cancellation that leaks a connection or an open stream",
        ],
    ),
    (
        "distributed-retry-budget-authority",
        "Distributed Retry Budget Authority",
        "Own the one retry budget every layer in the system draws from",
        ["shared budget document", "layer registration", "amplification ceiling", "storm prevention"],
        ["retry_budget.json", "amplification_measurements.json", "authority_notes.md"],
        [
            "Gateway, mesh, driver, library and application retry configuration all reference this one budget document.",
            "Every retrying layer is registered here with its attempt count, backoff, jitter and the hop it owns.",
            "Measured amplification above the declared ceiling blocks promotion regardless of success rate, and no approval lifts it.",
        ],
        [
            "a retry layer that does not draw from the shared budget",
            "an amplification ceiling declared but never measured",
            "a retry storm that the budget failed to bound",
        ],
    ),
    (
        "hedged-request-verifier",
        "Hedged Request Verifier",
        "Verify hedging is restricted to safe operations and cancels its losers",
        ["eligibility", "trigger threshold", "loser cancellation", "load amplification"],
        ["hedging_policy.json", "hedging_results.json", "verifier_notes.md"],
        [
            "Only read or proved-idempotent operations are eligible for hedging, and eligibility is declared per operation.",
            "The trigger threshold, response selection rule and losing-request cancellation are verified under real latency distributions.",
            "Load amplification and its tail latency benefit are both measured so the trade is explicit.",
        ],
        [
            "a hedged non-idempotent write producing two effects",
            "a losing request left running after the winner returned",
            "hedging that doubles load for no measured tail improvement",
        ],
    ),
    (
        "circuit-breaker-coordination-verifier",
        "Circuit Breaker Coordination Verifier",
        "Verify multiple circuit breakers do not amplify each other",
        ["breaker inventory", "error classification parity", "recovery staggering", "state amplification"],
        ["breaker_coordination.json", "coordination_results.json", "verifier_notes.md"],
        [
            "Every breaker on a call path is inventoried across client, gateway, mesh, service and dependency libraries.",
            "Error classification is consistent across breakers so one layer's retryable is not another's fatal.",
            "Recovery probing is staggered so all traffic does not resume simultaneously, and cross-layer amplification is measured.",
        ],
        [
            "three breakers on one path with inconsistent error classification",
            "a recovery storm when every breaker half-opens at once",
            "an open breaker whose fallback trips the next breaker",
        ],
    ),
    (
        "bulkhead-isolation-verifier",
        "Bulkhead Isolation Verifier",
        "Verify one dependency or tenant cannot exhaust shared capacity",
        ["isolation unit", "concurrency limit", "queue bound", "priority separation"],
        ["bulkhead_config.json", "isolation_results.json", "verifier_notes.md"],
        [
            "Thread pools, task pools, connection pools and concurrency limits are partitioned per dependency or per tenant.",
            "Queue depth is bounded per partition so a slow dependency cannot consume the whole request capacity.",
            "High and low priority traffic are separated and starvation is measured under sustained saturation of one partition.",
        ],
        [
            "one slow dependency consuming the entire shared pool",
            "a tenant able to starve every other tenant",
            "an unbounded queue in front of a saturated partition",
        ],
    ),
    (
        "distributed-load-shedding-verifier",
        "Distributed Load Shedding Verifier",
        "Verify overload is rejected deliberately with a usable signal",
        ["admission control", "rejection signal", "priority preservation", "downstream protection"],
        ["load_shedding_policy.json", "shedding_results.json", "verifier_notes.md"],
        [
            "The admission control threshold is declared numerically and measured rather than emerging from resource exhaustion.",
            "The rejection status and retry-after signal are declared so clients back off rather than retry immediately.",
            "Critical traffic and priority tenants are preserved under shedding, and downstream services are protected by it.",
        ],
        [
            "overload absorbed by queueing until the process fails",
            "a rejection with no retry-after signal that triggers immediate retry",
            "critical traffic shed before best-effort traffic",
        ],
    ),
    (
        "fan-out-call-verifier",
        "Fan-Out Call Verifier",
        "Verify concurrent downstream calls are bounded, cancellable and aggregated",
        ["concurrency bound", "overall versus per-call timeout", "partial failure", "sibling cancellation"],
        ["fan_out_config.json", "fan_out_results.json", "verifier_notes.md"],
        [
            "Maximum concurrency is bounded explicitly so a single request cannot saturate a downstream service.",
            "The overall timeout and per-call timeout are declared separately and both are enforced.",
            "Partial failure handling, sibling cancellation, result ordering and retry amplification are verified explicitly.",
        ],
        [
            "an unbounded fan-out that saturates a downstream service",
            "siblings left running after the aggregate already failed",
            "fan-out combined with per-call retry producing unmeasured amplification",
        ],
    ),
    (
        "partial-failure-aggregation-verifier",
        "Partial Failure Aggregation Verifier",
        "Verify partial results are represented honestly to the caller",
        ["aggregation strategy", "completeness signalling", "fallback provenance", "user visibility"],
        ["aggregation_policy.json", "aggregation_results.json", "verifier_notes.md"],
        [
            "The strategy is declared per operation as fail-all, best effort, quorum, partial response or fallback.",
            "Data completeness is signalled in the response so a caller can distinguish complete from partial data.",
            "Fallback provenance and staleness are carried with the data, and the audit record captures which parts failed.",
        ],
        [
            "a partial response returned as if it were complete",
            "stale fallback data returned with no staleness signal",
            "a failed component that appears nowhere in the audit record",
        ],
    ),
    (
        "distributed-idempotency-verifier",
        "Distributed Idempotency Verifier",
        "Verify one idempotency key survives every hop that can duplicate an effect",
        ["key generation", "key propagation", "key scope", "cross-boundary reuse"],
        ["distributed_idempotency.json", "idempotency_results.json", "verifier_notes.md"],
        [
            "Key generation site, propagation path, scope and storage are declared for every non-idempotent effect.",
            "The same key crosses service, message and external API boundaries rather than being regenerated per hop.",
            "Retry, expiry, compensation and concurrent duplicate behaviour are verified end to end.",
        ],
        [
            "a key regenerated at a service boundary",
            "an external API call retried without the original key",
            "two concurrent duplicates both reaching the external effect",
        ],
    ),
    (
        "distributed-transaction-boundary-verifier",
        "Distributed Transaction Boundary Verifier",
        "Verify what a local transaction actually covers once remote calls are involved",
        ["boundary declaration", "lock hold time", "remote failure handling", "irreversible effect"],
        ["transaction_boundary.json", "boundary_results.json", "verifier_notes.md"],
        [
            "Local transaction, remote call, message publication, outbox, saga and compensation boundaries are declared per operation.",
            "A remote call inside a database transaction declares its lock hold time, remote failure handling and duplicate risk.",
            "A rollback never claims to undo an external irreversible effect; that effect enters compensation or reconciliation.",
        ],
        [
            "a remote call inside a transaction holding locks for its full duration",
            "a rollback presented as undoing an external charge",
            "an unknown remote result with no reconciliation path",
        ],
    ),
    (
        "saga-semantic-verifier",
        "Saga Semantic Verifier",
        "Verify multi-step sagas including compensation and terminal states",
        ["step and state model", "compensation coverage", "idempotent steps", "terminal state"],
        ["saga_model.json", "saga_results.json", "verifier_notes.md"],
        [
            "Every step records its command, its emitted event, its compensation and its retry and timeout policy.",
            "Every step that produces an effect has a compensation, or is declared explicitly as a point of no return.",
            "Steps and compensations are idempotent, ordering is enforced, and every path reaches a declared terminal state.",
        ],
        [
            "a step with an effect and no compensation and no declared irreversibility",
            "a compensation that is not idempotent and double-refunds",
            "a saga that can stall with no terminal state and no manual path",
        ],
    ),
    (
        "fallback-semantic-verifier",
        "Fallback Semantic Verifier",
        "Verify fallbacks never convert a failure into a false success",
        ["fallback source", "staleness bound", "authorisation preservation", "observability"],
        ["fallback_policy.json", "fallback_results.json", "verifier_notes.md"],
        [
            "The data source and maximum staleness of every fallback are declared and measured.",
            "A fallback never converts an authorisation or authentication failure into a successful response.",
            "Tenant scoping is preserved on the fallback path and every fallback activation is observable.",
        ],
        [
            "a permission failure answered with a default success response",
            "a fallback that serves another tenant's cached data",
            "a fallback that fires silently with no signal or metric",
        ],
    ),
    (
        "service-discovery-verifier",
        "Service Discovery Verifier",
        "Verify application-level discovery, caching and failover behaviour",
        ["resolution source", "cache lifetime", "health gating", "cross-region failover"],
        ["service_discovery.json", "discovery_results.json", "verifier_notes.md"],
        [
            "Name resolution, registry lookup and static configuration paths are enumerated with their lifetimes.",
            "Client-side caching lifetime and stale endpoint handling are measured because they decide failover latency.",
            "Health and readiness gating, cross-region failover and protocol port selection are verified explicitly.",
        ],
        [
            "a client cache that outlives an endpoint by minutes",
            "a discovery result used without a health check",
            "a cross-region failover that has never been exercised",
        ],
    ),
    (
        "distributed-context-propagation-verifier",
        "Distributed Context Propagation Verifier",
        "Verify context reaches every hop that needs it and no hop that must not have it",
        ["field-by-field reach", "boundary stripping", "background inheritance", "audit completeness"],
        ["context_propagation.json", "propagation_results.json", "verifier_notes.md"],
        [
            "Trace, request identity, tenant, principal, service identity, locale and timezone fields are traced hop by hop.",
            "Deadline, idempotency key and feature flag fields are verified as reaching every hop that acts on them.",
            "Fields are stripped at the trust boundary they must not cross, and the audit trail is complete end to end.",
        ],
        [
            "a tenant identifier lost at the second hop",
            "an internal context field forwarded to a third party",
            "a background job inheriting the caller's principal implicitly",
        ],
    ),
    (
        "clock-and-timestamp-verifier",
        "Clock and Timestamp Verifier",
        "Verify every clock dependence including skew, expiry and ordering",
        ["skew tolerance", "expiry validation", "monotonic measurement", "cross-node ordering"],
        ["clock_dependencies.json", "clock_results.json", "verifier_notes.md"],
        [
            "Every clock dependence is inventoried: event timestamps, request timestamps, expiries, signatures and tokens.",
            "Skew tolerance is declared numerically and verified with a deliberately skewed node.",
            "Latency measurement uses a monotonic source, and cross-node ordering never relies on wall-clock comparison alone.",
        ],
        [
            "a token rejected because two nodes disagree by a second",
            "an elapsed-time measurement taken from a wall clock that stepped",
            "event ordering derived from timestamps produced on different nodes",
        ],
    ),
]

BATCHES.update({
    150: {
        "title": "Distributed Diagnosis and Language Communication Pack",
        "why": "Moves ELMOS from per-service correctness to explaining a distributed failure, then binds the whole communication layer to each language's concrete networking stack.",
        "purpose": "preserve error causality, detect call amplification and loops, verify graceful shutdown, record the communication stack and hazards of all nine languages, then generate contract tests, the cross-language client matrix and historical payload replay.",
        "tooling": ["causality chain recorder", "amplification detector", "language communication inventories", "contract test generator"],
    },
    151: {
        "title": "Communication Mutation, Fault and Shadow Entry Pack",
        "why": "Moves ELMOS from trusting a communication test suite to proving it kills the specific defects a port produces, then opens the communication shadow.",
        "purpose": "fuzz invalid payloads, mutate schema, HTTP, RPC, gateway and mesh behaviour, run retry storm, cancellation race and streaming fault tests, generate the compatibility and security matrices, compare communication performance, gate mutation effectiveness, and start shadow replication for requests, remote calls and schemas.",
        "tooling": ["payload fuzzer", "communication mutation packs", "retry storm harness", "shadow traffic replicator"],
    },
})

SKILLS[150] = [
    (
        "distributed-error-causality-verifier",
        "Distributed Error Causality Verifier",
        "Preserve the full causal chain from origin failure to user-facing error",
        ["origin attribution", "wrapping preservation", "layer attribution", "user-facing mapping"],
        ["causality_chains.json", "causality_results.json", "verifier_notes.md"],
        [
            "The originating service and original error are preserved through every wrapping layer.",
            "Retry attempts, gateway status rewrites and proxy resets are attributed to the layer that produced them.",
            "The user-facing error maps back to exactly one origin, and the trace identifier links them.",
        ],
        [
            "a proxy reset presented as an application error",
            "an origin error replaced rather than wrapped",
            "a user-facing error that cannot be traced to an origin",
        ],
    ),
    (
        "distributed-call-amplification-detector",
        "Distributed Call Amplification Detector",
        "Measure how many downstream attempts one logical request can produce",
        ["amplification sources", "worst-case count", "per-element calls", "risk classification"],
        ["call_amplification.json", "amplification_results.json", "detector_notes.md"],
        [
            "Retry, fan-out, cache miss, batch splitting, recursive call and per-element call sources are each measured.",
            "Gateway retries, mesh retries and message replay are included in the worst-case downstream attempt count.",
            "The measured worst case is compared against the declared retry budget ceiling and classified by risk.",
        ],
        [
            "a per-element downstream call introduced by the port",
            "a worst-case attempt count that was never computed",
            "an amplification measured below the ceiling only on the happy path",
        ],
    ),
    (
        "distributed-call-loop-detector",
        "Distributed Call Loop Detector",
        "Detect cycles across services, callbacks, gateways and message flows",
        ["service cycle", "callback cycle", "rewrite cycle", "reply cycle"],
        ["call_loops.json", "loop_results.json", "detector_notes.md"],
        [
            "Direct and indirect service cycles are detected from the call graph rather than from documentation.",
            "Fallbacks calling back into the origin, webhook cycles and gateway rewrite cycles are each detected.",
            "Request and reply message cycles and retry combined with redirect cycles are detected and bounded by hop count.",
        ],
        [
            "a fallback that calls back into the service that failed",
            "a gateway rewrite that routes a request to itself",
            "a webhook that triggers the event that produced it",
        ],
    ),
    (
        "distributed-graceful-shutdown-verifier",
        "Distributed Graceful Shutdown Verifier",
        "Verify shutdown drains in-flight work across every connection type",
        ["readiness withdrawal", "in-flight completion", "long-lived connections", "forced termination bound"],
        ["shutdown_sequence.json", "shutdown_results.json", "verifier_notes.md"],
        [
            "Readiness is withdrawn and new requests stop arriving before in-flight work is drained.",
            "In-flight remote calls, streams, sockets, event streams, consumers and callbacks each have a declared drain behaviour.",
            "Connection draining, trace flushing, a bounded drain timeout and a declared forced termination path are all verified.",
        ],
        [
            "readiness withdrawn after the process already stopped accepting",
            "a long-lived stream terminated without a close signal",
            "a drain with no timeout that blocks a rolling deployment",
        ],
    ),
    (
        "java-communication-pack",
        "Java Communication Pack",
        "Record the Java communication stack, binding behaviour and hazards",
        ["route binding", "serialization defaults", "async model", "context carriage"],
        ["java_communication.json", "java_communication_hazards.json", "pack_notes.md"],
        [
            "Annotation-driven routing, object mapping defaults and validation behaviour are recorded per framework.",
            "Checked exception surfaces, future-based and reactive stacks and their backpressure behaviour are recorded.",
            "Context carriage, generated stubs, message schema handling, HTTP client defaults, interceptors and lightweight threads are covered.",
        ],
        [
            "an object mapper default that silently accepts unknown fields",
            "a context carried in thread-local storage that a reactive port loses",
            "a checked exception hierarchy flattened at the boundary",
        ],
    ),
    (
        "python-communication-pack",
        "Python Communication Pack",
        "Record the Python communication stack, coercion behaviour and hazards",
        ["runtime validation", "coercion", "async context", "numeric fidelity"],
        ["python_communication.json", "python_communication_hazards.json", "pack_notes.md"],
        [
            "Runtime validation libraries and their coercion behaviour are recorded because coercion changes accepted inputs.",
            "Event loop, context variable propagation, generator streaming and exception surfaces are recorded per framework.",
            "Decimal and temporal fidelity, dynamic route registration and asynchronous remote call stacks are covered.",
        ],
        [
            "a validator that coerces a malformed string into a valid value",
            "a context variable lost across a thread pool boundary",
            "a decimal converted to a float by the response serializer",
        ],
    ),
    (
        "csharp-communication-pack",
        "CSharp Communication Pack",
        "Record the C# communication stack, binding behaviour and hazards",
        ["model binding", "nullable reference types", "cancellation carriage", "numeric and temporal types"],
        ["csharp_communication.json", "csharp_communication_hazards.json", "pack_notes.md"],
        [
            "Model binding, nullable reference type enforcement and serializer defaults are recorded per framework.",
            "Task-based asynchrony, cancellation token carriage and request context access are recorded explicitly.",
            "Generated remote call stubs, filters and middleware ordering, and offset-aware temporal and decimal handling are covered.",
        ],
        [
            "a nullable annotation that is not enforced at the boundary",
            "a cancellation token accepted and never forwarded downstream",
            "a middleware ordering change that moves authorisation after caching",
        ],
    ),
    (
        "rust-communication-pack",
        "Rust Communication Pack",
        "Record the Rust communication stack, ownership behaviour and hazards",
        ["extractor model", "result and option mapping", "layer composition", "await-safety"],
        ["rust_communication.json", "rust_communication_hazards.json", "pack_notes.md"],
        [
            "Serialization derivation, extractor behaviour and rejection mapping are recorded per framework.",
            "Result and option mapping to status codes, future send bounds and stream handling are recorded explicitly.",
            "Layer and middleware composition order, cancellation on drop, message type ownership and locks held across suspension points are covered.",
        ],
        [
            "a lock held across an await point that stalls the runtime",
            "an extractor rejection mapped to a different status than the source",
            "a dropped future cancelling a call that should have completed",
        ],
    ),
    (
        "go-communication-pack",
        "Go Communication Pack",
        "Record the Go communication stack, zero-value behaviour and hazards",
        ["struct tags", "zero value versus absence", "context propagation", "body lifecycle"],
        ["go_communication.json", "go_communication_hazards.json", "pack_notes.md"],
        [
            "Struct tags, zero-value semantics and pointer-based optionality are recorded because they decide presence handling.",
            "Context propagation, error wrapping, concurrency primitives and streaming behaviour are recorded per stack.",
            "Body closing, generated stubs, message schema handling and large integer encoding are covered explicitly.",
        ],
        [
            "a zero value indistinguishable from an absent field",
            "a response body never closed so connections leak",
            "a large integer encoded as a number a client cannot represent",
        ],
    ),
    (
        "typescript-communication-pack",
        "TypeScript Communication Pack",
        "Record the Node communication stack, absence handling and hazards",
        ["runtime validation", "undefined versus null", "numeric limits", "async context"],
        ["typescript_communication.json", "typescript_communication_hazards.json", "pack_notes.md"],
        [
            "Runtime validation is recorded separately from compile-time typing because only the former protects the boundary.",
            "Undefined and null distinction, large integer handling and numeric limits are recorded per serializer.",
            "Promise handling, asynchronous context storage, decorators, streaming, sockets and unhandled rejection behaviour are covered.",
        ],
        [
            "a compile-time type trusted as runtime validation",
            "undefined serialized as null and read back as an explicit null",
            "an unhandled rejection that silently drops a request",
        ],
    ),
    (
        "cplusplus-communication-pack",
        "CPlusPlus Communication Pack",
        "Record the native communication stack, buffer ownership and hazards",
        ["buffer ownership", "callback lifetime", "parser strictness", "sanitizer evidence"],
        ["cplusplus_communication.json", "cplusplus_communication_hazards.json", "pack_notes.md"],
        [
            "Buffer ownership, scoped release and pointer lifetime across callbacks and coroutines are recorded per stack.",
            "Parser strictness, string encoding assumptions, message schema handling and native remote call stacks are recorded.",
            "Exception paths, binary interface boundaries and streaming behaviour carry address and thread sanitizer evidence.",
        ],
        [
            "a response buffer freed while the transport is still writing it",
            "a callback outliving the object it captures",
            "a parser that accepts a malformed frame without bound",
        ],
    ),
    (
        "objectivec-communication-pack",
        "Objective-C Communication Pack",
        "Record the Objective-C communication stack, memory model and hazards",
        ["session model", "error objects", "null representation", "dispatch context"],
        ["objectivec_communication.json", "objectivec_communication_hazards.json", "pack_notes.md"],
        [
            "Networking session configuration, delegate and block-based completion and error object shape are recorded.",
            "Reference counting, autorelease pool behaviour, run loop and dispatch queue context are recorded explicitly.",
            "Explicit null representation in serialized payloads and bridged message schema handling are covered.",
        ],
        [
            "an explicit null sentinel that becomes an omitted field",
            "a completion block retaining its owner and leaking the request",
            "a network callback delivered on an unexpected queue",
        ],
    ),
    (
        "swift-communication-pack",
        "Swift Communication Pack",
        "Record the Swift communication stack, optionality and hazards",
        ["codable behaviour", "optionality", "concurrency isolation", "platform difference"],
        ["swift_communication.json", "swift_communication_hazards.json", "pack_notes.md"],
        [
            "Encoding and decoding behaviour, key strategies and optionality mapping are recorded per stack.",
            "Decimal and temporal handling, error throwing surfaces and buffer types are recorded explicitly.",
            "Structured concurrency, actor isolation, sendability, asynchronous sequences and platform differences are covered.",
        ],
        [
            "an optional that cannot distinguish missing from explicit null",
            "a decoding strategy that renames keys unexpectedly",
            "a behaviour verified on one platform and assumed on the other",
        ],
    ),
    (
        "api-contract-test-generator",
        "API Contract Test Generator",
        "Generate contract tests from the endpoint representation rather than by hand",
        ["surface coverage", "negative cases", "auth cases", "idempotency cases"],
        ["contract_tests.json", "generation_report.json", "generator_notes.md"],
        [
            "Generated tests cover method, path, query, header, cookie and body variations for every endpoint.",
            "Status, response shape, error contract and authentication and authorisation cases are generated per endpoint.",
            "Idempotency and pagination cases are generated wherever the endpoint representation declares them.",
        ],
        [
            "a generated suite with no error contract case",
            "an endpoint with an idempotency requirement and no duplicate test",
            "a suite generated from documentation rather than the endpoint representation",
        ],
    ),
    (
        "cross-language-client-matrix-test",
        "Cross-Language Client Matrix Test",
        "Test every client language against every server language actually in play",
        ["client server matrix", "encoding parity", "error parity", "stream parity"],
        ["client_matrix.json", "matrix_results.json", "test_notes.md"],
        [
            "Every client language in production is tested against every server language the migration produces.",
            "Encoding, null and absence handling, enum handling and error mapping are compared per cell of the matrix.",
            "Timeout, cancellation and streaming behaviour are compared per cell rather than only in the same-language cell.",
        ],
        [
            "a matrix tested only in the same-language cell",
            "a client language in production omitted from the matrix",
            "a cell that passes on encoding but was never tested for cancellation",
        ],
    ),
    (
        "historical-payload-replay",
        "Historical Payload Replay",
        "Replay real historical payloads through the new implementation",
        ["payload corpus", "coverage measurement", "decode parity", "error fixture coverage"],
        ["replay_corpus.json", "replay_results.json", "replay_notes.md"],
        [
            "The corpus draws from real historical requests, remote call payloads, webhooks, graph queries and mobile client payloads.",
            "Corpus coverage is measured against the production type and version distribution rather than assumed representative.",
            "Error fixtures are replayed alongside success fixtures, and every decode difference is classified.",
        ],
        [
            "a replay corpus containing only recent payloads",
            "an old client payload version absent from the corpus",
            "a decode difference recorded but never classified",
        ],
    ),
]

SKILLS[151] = [
    (
        "invalid-payload-fuzzer",
        "Invalid Payload Fuzzer",
        "Generate malformed inputs so rejection behaviour is proved equivalent",
        ["structural malformation", "type violation", "resource abuse", "transport malformation"],
        ["fuzz_corpus.json", "fuzz_results.json", "fuzzer_notes.md"],
        [
            "Missing fields, duplicate fields, nulls, wrong types, oversized numbers and invalid unicode are all generated.",
            "Unknown enums, deep nesting, oversized arrays and resource-abusive payloads are generated for every decoder.",
            "Corrupted frames, truncated streams and wrong content types are generated for every transport in use.",
        ],
        [
            "a malformed payload accepted by one implementation and rejected by the other",
            "a fuzz case that crashes the process instead of returning an error",
            "an invalid payload whose error response leaks internal detail",
        ],
    ),
    (
        "schema-evolution-mutation-pack",
        "Schema Evolution Mutation Pack",
        "Mutate schema changes so compatibility checks are proved effective",
        ["removal and addition", "identifier reuse", "type narrowing", "policy removal"],
        ["schema_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations remove a field, add a required field, change a field number and reuse an enum number.",
            "Changed defaults, narrowed integer widths and a nullable field made non-null are mutated separately.",
            "Rejecting unknown fields and removing a discriminator are included as mutations that must be caught.",
        ],
        [
            "a reused field number that the compatibility gate does not block",
            "a required field addition that passes the gate",
            "a removed discriminator that no polymorphism test detects",
        ],
    ),
    (
        "http-mutation-pack",
        "HTTP Mutation Pack",
        "Mutate HTTP behaviour so contract regressions are proved detectable",
        ["retry mutation", "status conflation", "header removal", "cookie relaxation"],
        ["http_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations enable automatic retry on a mutating method and conflate authentication with authorisation failures.",
            "A validation failure turned into a server error, removed headers and removed idempotency keys are mutated.",
            "Changed query defaults, a redirect that changes the method, a removed body limit and a relaxed cookie attribute are included.",
        ],
        [
            "an automatic retry on a mutating method that no test detects",
            "a removed idempotency key that survives the suite",
            "a relaxed cookie attribute that no security test flags",
        ],
    ),
    (
        "rpc-mutation-pack",
        "RPC Mutation Pack",
        "Mutate remote call behaviour so contract regressions are proved detectable",
        ["deadline mutation", "status collapse", "stream mutation", "schema mutation"],
        ["rpc_mutations.json", "mutation_results.json", "pack_notes.md"],
        [
            "Mutations stop propagating the deadline and ignore cancellation.",
            "Collapsing every status to internal, removing trailers and reordering stream messages are mutated separately.",
            "Removed flow control, enabled retry and a changed message field number are included as mutations.",
        ],
        [
            "a deadline that stops propagating and no test detects it",
            "every status collapsed to internal while the suite passes",
            "a stream reordering that no ordering test catches",
        ],
    ),
    (
        "gateway-mutation-test-runner",
        "Gateway Mutation Test Runner",
        "Prove the suite detects each gateway mutation class",
        ["auth bypass detection", "routing error detection", "amplification detection", "shadow escalation detection"],
        ["gateway_mutation_runs.json", "detection_results.json", "runner_notes.md"],
        [
            "The runner verifies the suite detects authentication bypass, wrong routing and retry amplification.",
            "Lost timeouts, disabled rate limiting and relaxed cross-origin policy must each be detected.",
            "Lost header propagation and a shadow route producing a real effect must each be detected and reported.",
        ],
        [
            "an authentication bypass mutation that survives",
            "a retry amplification mutation the suite does not catch",
            "a shadow escalation mutation that produces a real effect undetected",
        ],
    ),
    (
        "mesh-mutation-test-runner",
        "Mesh Mutation Test Runner",
        "Prove the suite detects each mesh mutation class",
        ["identity downgrade detection", "policy removal detection", "retry stacking detection", "trace break detection"],
        ["mesh_mutation_runs.json", "detection_results.json", "runner_notes.md"],
        [
            "The runner verifies the suite detects transport identity downgrade and authorisation policy removal.",
            "Stacked retries, conflicting timeouts and changed load balancing must each be detected.",
            "Stale endpoints, opened egress and a broken trace chain must each be detected and reported.",
        ],
        [
            "a transport identity downgrade that survives",
            "a stacked retry mutation the suite does not catch",
            "an opened egress rule detected by no test",
        ],
    ),
    (
        "distributed-retry-storm-test",
        "Distributed Retry Storm Test",
        "Reproduce a retry storm and measure recovery under the shared budget",
        ["degradation trigger", "simultaneous layers", "amplification measurement", "recovery time"],
        ["retry_storm_scenario.json", "storm_results.json", "test_notes.md"],
        [
            "A downstream slowdown and rising error rate are injected while gateway, mesh and client retry simultaneously.",
            "Total call amplification, pool exhaustion, queue growth and breaker activation are measured during the storm.",
            "Recovery time, backoff effectiveness, budget enforcement and load shedding behaviour are measured after the injection stops.",
        ],
        [
            "a storm that never recovers after the injection stops",
            "an amplification that exceeds the declared budget ceiling",
            "a storm test run with only one retry layer active",
        ],
    ),
    (
        "cancellation-race-test",
        "Cancellation Race Test",
        "Race cancellation against commit points to prove the policy holds",
        ["commit race", "publish race", "stream close race", "external effect race"],
        ["cancellation_races.json", "race_results.json", "test_notes.md"],
        [
            "Cancellation is raced against transaction commit, message publication and stream close.",
            "Cancellation is raced against a successful external payment so the reconciliation path is exercised.",
            "Every race outcome resolves under the declared cancellation policy rather than by whichever path won.",
        ],
        [
            "a cancellation racing a commit that leaves an unreconciled effect",
            "a message published after the request was cancelled with no record",
            "a race whose outcome depends on scheduling rather than on policy",
        ],
    ),
    (
        "streaming-fault-test",
        "Streaming Fault Test",
        "Inject faults into long-lived streams at every stage",
        ["mid-stream interruption", "ordering faults", "pacing faults", "credential expiry"],
        ["streaming_faults.json", "fault_results.json", "test_notes.md"],
        [
            "Mid-stream disconnection, half-close, reordering and duplicate frames are each injected.",
            "Backpressure with a slow client and with a slow server are exercised separately.",
            "Credential expiry mid-stream, proxy timeout and reconnection behaviour are injected and their outcomes compared.",
        ],
        [
            "a mid-stream disconnect that the client cannot distinguish from completion",
            "a stream that continues after its credential expired",
            "a reconnect that silently skips the frames lost during the gap",
        ],
    ),
    (
        "compatibility-matrix-test-generator",
        "Compatibility Matrix Test Generator",
        "Generate the complete producer and consumer version grid including every mixed population",
        ["full nine-cell grid", "direction coverage", "mixed population", "cell provenance"],
        ["compatibility_matrix.json", "matrix_results.json", "generator_notes.md"],
        [
            "Producer and consumer versions are each drawn from old, new and mixed, giving nine cells, and every cell is generated and run.",
            "The four pure cells carry their named meaning: old with old is the baseline, old with new proves backward compatibility, new with old proves forward compatibility and new with new proves the new behaviour.",
            "The five mixed cells carry theirs: a mixed producer population proves rolling deployment safety, a mixed consumer population proves production upgrade safety, and mixed with mixed proves the real intermediate state where neither side has finished rolling.",
            "No cell may be skipped by inference from another cell, and each cell records which population sample it drew from.",
        ],
        [
            "a grid that omits any of the nine cells",
            "a mixed-with-mixed cell inferred from the two single-mixed cells",
            "a rolling deployment assumed safe from the same-version result",
            "a forward compatibility cell with no old consumer to test against",
        ],
    ),
    (
        "distributed-security-test-generator",
        "Distributed Security Test Generator",
        "Generate the negative security cases the contract suite does not cover",
        ["credential cases", "identity cases", "replay cases", "forgery cases"],
        ["security_tests.json", "security_results.json", "generator_notes.md"],
        [
            "Missing token, expired token and altered claim cases are generated for every authenticated surface.",
            "Cross-tenant access, wrong service identity and transport identity failure cases are generated per call edge.",
            "Replay, signature tampering, forged forwarded headers, forged webhooks and callback hijack cases are generated.",
        ],
        [
            "a cross-tenant access case absent from the generated suite",
            "a forged forwarded header accepted by the target",
            "a webhook accepted without signature verification",
        ],
    ),
    (
        "communication-performance-differential-pack",
        "Communication Performance Differential Pack",
        "Compare communication performance across the whole path, not just the handler",
        ["latency distribution", "serialization and compression cost", "path overhead", "resource use"],
        ["communication_performance.json", "performance_diff.json", "pack_notes.md"],
        [
            "Request latency, time to first byte and stream throughput are compared under identical load and payload mix.",
            "Serialization, compression, transport security, gateway and mesh overhead are attributed separately.",
            "Retry cost, connection reuse, processor, memory and allocation behaviour are compared explicitly.",
        ],
        [
            "a latency comparison run with a different payload mix",
            "a throughput gain achieved by disabling transport security",
            "gateway and mesh overhead attributed to the application handler",
        ],
    ),
    (
        "communication-mutation-effectiveness-gate",
        "Communication Mutation Effectiveness Gate",
        "Gate promotion on the suite killing every critical communication mutant",
        ["critical mutation classes", "kill rate", "no partial credit", "surviving mutant report"],
        ["mutation_gate.json", "gate_result.json", "gate_notes.md"],
        [
            "Critical schema, authentication, retry, timeout and idempotency mutation classes must each reach a full kill rate.",
            "A surviving critical mutant blocks the gate and is reported with the specific defect it represents.",
            "A high overall kill rate never compensates for a surviving mutant in a critical class.",
        ],
        [
            "a surviving authentication mutant waved through on overall kill rate",
            "a mutation class declared critical but never run",
            "a gate pass computed from a partial mutation run",
        ],
    ),
    (
        "api-shadow-traffic-replicator",
        "API Shadow Traffic Replicator",
        "Replicate real requests to the target while the source stays authoritative",
        ["source authority", "response discard", "effect isolation", "credential substitution"],
        ["shadow_replication_config.json", "replication_results.json", "replicator_notes.md"],
        [
            "The source response is authoritative and the target response is discarded rather than returned to any caller.",
            "Target side effects are isolated by the declared interception mode and never reach an authoritative resource.",
            "Headers and context are preserved for fidelity while credentials are safely substituted for shadow-scoped ones.",
        ],
        [
            "a shadow response returned to a real caller",
            "a shadow request reaching an authoritative payment provider",
            "a production credential forwarded into the shadow environment",
        ],
    ),
    (
        "rpc-shadow-caller",
        "RPC Shadow Caller",
        "Shadow remote calls including their metadata and streaming shape",
        ["metadata parity", "deadline parity", "status and trailer parity", "streaming shadow"],
        ["rpc_shadow_config.json", "rpc_shadow_results.json", "caller_notes.md"],
        [
            "Metadata, deadline, request and response are compared per call between the authoritative and shadow paths.",
            "Status codes, error details and trailers are compared because those carry the result on this transport.",
            "Streaming calls use an independent shadow consumer rather than replicating a single call invocation.",
        ],
        [
            "a streaming call shadowed as if it were unary",
            "a shadow call whose deadline differs from the authoritative one",
            "a trailer difference that the comparison never inspects",
        ],
    ),
    (
        "schema-shadow-decoder",
        "Schema Shadow Decoder",
        "Decode live production payloads with both schemas to find real incompatibilities",
        ["dual decode", "decode failure", "semantic drift", "historical coverage"],
        ["shadow_decode_config.json", "decode_findings.json", "decoder_notes.md"],
        [
            "Every sampled production payload is decoded with both the old and the new schema and the results compared.",
            "Decode failures, lost fields, unknown enums, changed defaults and narrowed types are each reported as findings.",
            "Historical payload incompatibility is reported separately from live incompatibility because it needs a different remedy.",
        ],
        [
            "a decode failure counted as a sampling artefact",
            "a lost field detected but never classified",
            "shadow decoding run only on current-version payloads",
        ],
    ),
]

BATCHES.update({
    152: {
        "title": "Communication Cutover, Reconciliation and Certification Pack",
        "why": "Closes ELMOS by taking the communication layer from shadow evidence to a revocable, reconciled, rollback-armed production certification.",
        "purpose": "verify gateway and mesh shadow policy, control the API canary, monitor old client populations, plan communication rollback, reconcile both systems, operate the COM-E2 through COM-E5 gates, watch for revocation triggers and orchestrate the whole communication migration.",
        "tooling": ["canary controller", "client version monitor", "communication reconciliation engine", "COM-E gate runner"],
    },
})

SKILLS[152] = [
    (
        "gateway-shadow-route-verifier",
        "Gateway Shadow Route Verifier",
        "Verify shadow routing decisions at the edge without producing real effects",
        ["route hit parity", "policy intent parity", "upstream isolation", "shadow safety"],
        ["gateway_shadow_config.json", "shadow_route_results.json", "verifier_notes.md"],
        [
            "Route hits, rewrites and authentication outcomes are compared between the authoritative and shadow gateways.",
            "Rate limit intent, timeout and upstream selection are compared as decisions rather than as observed outcomes.",
            "The shadow gateway reaches only shadow upstreams, and header and trace propagation are compared explicitly.",
        ],
        [
            "a shadow route resolving to an authoritative upstream",
            "a rate limit actually enforced by the shadow gateway on real traffic",
            "a route hit difference recorded but never classified",
        ],
    ),
    (
        "mesh-shadow-policy-verifier",
        "Mesh Shadow Policy Verifier",
        "Verify shadow mesh policy decisions match the authoritative ones",
        ["subset routing", "identity and policy parity", "resilience parity", "observability parity"],
        ["mesh_shadow_config.json", "shadow_policy_results.json", "verifier_notes.md"],
        [
            "Subset routing, transport identity and authorisation decisions are compared decision by decision.",
            "Retry, timeout and load balancing behaviour are compared under identical injected conditions.",
            "Telemetry and egress behaviour are compared so the shadow mesh is proved to be a faithful model.",
        ],
        [
            "a shadow policy that permits a call the authoritative policy denies",
            "a shadow mesh with different retry settings than the target will run",
            "an egress difference between shadow and authoritative meshes",
        ],
    ),
    (
        "api-canary-controller",
        "API Canary Controller",
        "Advance production traffic through stable, reversible canary stages",
        ["stage sequence", "stable bucketing", "entry evidence", "automatic rollback"],
        ["canary_plan.json", "stage_results.json", "controller_notes.md"],
        [
            "Stages run internal clients, one percent read-only, low-risk tenants, one percent write, then five, twenty-five, fifty and one hundred percent.",
            "Bucketing is stable on tenant, principal, resource identity, client version or a fixed hash and never randomised per request.",
            "Each stage declares entry evidence and an automatic rollback trigger that fires without human intervention.",
        ],
        [
            "a write stage entered before the read-only stage closed clean",
            "a bucket that reassigns between two requests from the same principal",
            "a stage advanced manually past a failing rollback trigger",
        ],
    ),
    (
        "client-version-compatibility-monitor",
        "Client Version Compatibility Monitor",
        "Monitor the populations that cannot be upgraded on demand",
        ["population measurement", "long-lived connections", "third-party clients", "retirement gating"],
        ["client_populations.json", "compatibility_findings.json", "monitor_notes.md"],
        [
            "Old mobile versions, cached browser clients, third-party integrations and internal legacy services are counted continuously.",
            "Batch jobs, offline devices and long-lived connections are tracked because each can hold an old contract for weeks.",
            "No old contract is retired while its measured population is above the declared retirement threshold.",
        ],
        [
            "an old contract retired on an estimated rather than measured population",
            "an offline device population omitted from the count",
            "a long-lived connection still speaking a retired protocol version",
        ],
    ),
    (
        "communication-rollback-planner",
        "Communication Rollback Planner",
        "Plan a reversible path back for every communication cutover object",
        ["rollback objects", "payload reversibility", "consumer restoration", "connection draining"],
        ["communication_rollback_plan.json", "rollback_drill_results.json", "planner_notes.md"],
        [
            "Routes, gateway configuration, mesh policy, schemas, client packages, name resolution and discovery each carry a named rollback action.",
            "Whether an old service can read a new payload and an old client can process a new response is proved before the stage, not after.",
            "Field reversibility, message replayability, stream consumer restoration and connection draining are all verified.",
        ],
        [
            "a rollback that leaves old services unable to read payloads written during the new stage",
            "a schema change with no reverse migration",
            "a rollback plan that never drains long-lived connections",
        ],
    ),
    (
        "communication-reconciliation-engine",
        "Communication Reconciliation Engine",
        "Reconcile both systems on counts, effects and evidence completeness",
        ["volume reconciliation", "effect reconciliation", "evidence completeness", "residue classification"],
        ["reconciliation_plan.json", "reconciliation_results.json", "engine_notes.md"],
        [
            "Request counts, responses, errors, retries and downstream call counts are reconciled between the two systems.",
            "Side effects, stream events, webhooks, remote call statuses and schema decode outcomes are reconciled per operation.",
            "Trace completeness is reconciled, and every residue is classified rather than absorbed into a tolerance.",
        ],
        [
            "a residue absorbed into a tolerance band without classification",
            "a reconciliation that compares totals but not per-operation effects",
            "a missing trace treated as a sampling artefact without evidence",
        ],
    ),
    (
        "communication-e2-gate",
        "Communication E2 Gate",
        "Gate the communication layer at inventory and contract completeness",
        ["endpoint completeness", "contract consistency", "client generation", "baseline suite"],
        ["com_e2_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "The endpoint inventory is complete and every contract is consistent between definition and runtime.",
            "Every schema builds and every generated client compiles for every target language in use.",
            "Baseline serialization, error contract and authentication entry points pass, and the original test suite passes.",
        ],
        [
            "a gate pass with an undocumented production route",
            "a gate pass while a generated client fails to compile",
            "a gate pass with a definition that disagrees with the running service",
        ],
    ),
    (
        "communication-e3-gate",
        "Communication E3 Gate",
        "Gate the communication layer at differential and mutation evidence",
        ["contract differential", "compatibility matrix", "policy differential", "mutation survival"],
        ["com_e3_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "Source and target differential evidence is present for the endpoint surface and the remote call surface.",
            "The schema compatibility matrix is complete and idempotency, timeout and cancellation evidence is present.",
            "Gateway and mesh rule differentials are complete, every communication mutation pack has run with no surviving mutant, and no unexplained difference remains.",
        ],
        [
            "a gate pass with a surviving communication mutant",
            "a gate pass while a compatibility matrix cell is untested",
            "a gate pass with an unexplained status mapping difference",
        ],
    ),
    (
        "communication-e4-gate",
        "Communication E4 Gate",
        "Gate the communication layer at concurrency, fault and real-topology evidence",
        ["streaming and concurrency", "fault and storm coverage", "real gateway and mesh", "rollback drill"],
        ["com_e4_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "Concurrency, streaming, fault injection, retry storm and partial failure evidence are all present.",
            "Transport identity, security test, performance and resource leak evidence are complete on the real gateway and real mesh.",
            "The rollback drill has been executed and no resource leak remains unexplained.",
        ],
        [
            "a gate pass on evidence gathered without a real gateway in the path",
            "a gate pass with no retry storm result",
            "a gate pass with no executed rollback drill",
        ],
    ),
    (
        "communication-e5-gate",
        "Communication E5 Gate",
        "Gate the communication layer at production traffic, shadow and reconciliation evidence",
        ["historical traffic", "online shadow", "old client coverage", "zero effect difference"],
        ["com_e5_gate_result.json", "gate_evidence.json", "gate_notes.md"],
        [
            "Historical production traffic and online shadow evidence cover the real endpoint, version and client distribution.",
            "Old client coverage, critical schema evolution scenarios and gateway and mesh policy reconciliation are all complete.",
            "Critical side-effect differences are zero, long-lived stream behaviour is verified, automatic rollback is armed and unsupported protocol features are zero.",
        ],
        [
            "a gate pass on shadow evidence that omits the old client population",
            "a gate pass with a nonzero critical side-effect difference",
            "a gate pass while an unsupported protocol feature is still in use",
        ],
    ),
    (
        "communication-certification-revocation",
        "Communication Certification Revocation",
        "Watch the causal inputs of a communication certification and downgrade on change",
        ["trigger inventory", "state transitions", "scope of downgrade", "evidence-only recovery"],
        ["revocation_triggers.json", "revocation_state.json", "revocation_notes.md"],
        [
            "Schema, endpoint, generator, serialization library, gateway, mesh, transport security, retry policy and protocol version changes are all triggers.",
            "A new client, a new production payload shape or a new protocol version each trigger revalidation of the affected scope.",
            "States move through valid, partially valid, revalidation required and revoked, and recovery requires new evidence rather than an approval.",
        ],
        [
            "a serialization library upgrade that does not trigger revalidation",
            "a certification restored by approval without new evidence",
            "a gateway configuration change applied under an unchanged certification",
        ],
    ),
    (
        "communication-migration-orchestrator",
        "Communication Migration Orchestrator",
        "Sequence the communication migration from discovery through the COM-E ladder",
        ["phase sequencing", "IR prerequisites", "shadow and canary gating", "blocking condition"],
        ["communication_state_machine.json", "phase_transitions.json", "orchestration_runbook.md"],
        [
            "Discovery, endpoint and protocol inventory, schema and serialization, call graph and context, and gateway and mesh representations complete before target mapping.",
            "Contract and schema differential, remote call and streaming tests, gateway and mesh tests, distributed failure tests and mutation all precede shadow traffic.",
            "Shadow precedes canary, canary precedes authority transfer, and an unresolved schema compatibility finding blocks the layer regardless of other progress.",
        ],
        [
            "a canary stage entered before shadow evidence closed clean",
            "a target implementation started before the call graph and context representation existed",
            "a communication layer level published while a compatibility finding is open",
        ],
    ),
]


# =============================================================================
# P0 RULINGS — decision record ADR-MIG-P0-01 … ADR-MIG-P0-04
#
# The four P0 contradictions found in the adversarial review are settled here and
# applied programmatically to the Skill set built above. Applying them in data
# rather than prose means every generated Skill carries the ruling in its
# Required Checks, and the package validator enforces it.
# =============================================================================

# ADR-MIG-P0-01 / 02
#   The Batch 4 per-language-pair ceiling summary is VOID. A directional path's
#   ceiling is declared only inside its own pack. Hard caps are derived from one
#   uniform rule instead of a hand-maintained table, which removes the three
#   contradictory pairs and closes the Python <-> Swift gap.
#
#   Rule: a path carries hard_cap E3 while either side retains unexplained
#   undefined behaviour; otherwise hard_cap E4 while either side retains
#   non-enumerable runtime dynamism; otherwise no hard cap.
DYNAMIC_RUNTIME_LANGUAGES = {"python", "typescript", "objectivec"}
UNDEFINED_BEHAVIOUR_LANGUAGES = {"cplusplus"}

# ADR-MIG-P0-03
#   Seven parallel ladders compose by the short-plank rule. The four domain
#   ladders are renamed with domain prefixes so they can never be quoted as the
#   core ladder.
COMPOSITION_RULE = (
    "The module level is the minimum across core, directional path, FW-E, DEP-E, INF-E, COM-E and "
    "critical DR levels; a single layer level is never published on its own."
)

# ADR-MIG-P0-04
#   Cancellation expectations are decided by an explicit policy keyed on effect
#   reversibility, not re-interpreted per layer.
CANCELLATION_RULE = (
    "Cancellation outcome follows the declared cancellation policy: reversible effects abort and roll "
    "back, irreversible effects not yet started abort before start, irreversible effects in flight "
    "complete then reconcile, and unknown outcomes require reconciliation."
)


def _ceiling_with_ruling(source, target, production_level):
    """Rebuild a path ceiling sentence under ADR-MIG-P0-01/02."""
    pair = {source, target}
    undefined_behaviour = bool(pair & UNDEFINED_BEHAVIOUR_LANGUAGES)
    dynamic_runtime = bool(pair & DYNAMIC_RUNTIME_LANGUAGES)

    text = (
        f"Certification is capped at {production_level['static']} on static evidence alone, "
        f"{production_level['runtime']} with runtime trace evidence, and {production_level['production']} "
        f"only with production shadow evidence."
    )

    conditions_e3 = []
    if undefined_behaviour:
        conditions_e3.append("any unexplained undefined behaviour remains on either side")
    if dynamic_runtime:
        conditions_e3.append("dynamic-site trace coverage is incomplete")
    if conditions_e3:
        text += " A hard cap of E3 applies while " + " or ".join(conditions_e3) + "."
    if dynamic_runtime:
        text += (
            " A hard cap of E4 applies while enumerated dynamic behaviour is not frozen into an explicit "
            "registry."
        )
    if conditions_e3 or dynamic_runtime:
        text += " No approval can lift either cap; only new evidence can."
    text += " This pack is the only authority for its ceiling."
    return text


def _apply_p0_rulings():
    import re as _re

    cancellation_targets = {
        "side-effect-capture", "side-effect-ir-builder", "fault-injection-runner",
        "rollback-executor", "effect-intent-recorder", "async-ordering-verifier",
        "infrastructure-context-cancellation-view", "unknown-commit-outcome-verifier",
        "cancellation-propagation-verifier", "cancellation-race-test",
        "grpc-deadline-and-cancellation-verifier",
    }
    composition_targets = {
        "evidence-level-assessor", "certification-ceiling-calculator",
        "certification-ceiling-evaluator", "release-gate-evaluator",
        "canary-promotion-evaluator", "e5-production-confidence-certification",
    }
    domain_gate_prefix = {
        "framework-e2-gate": "FW-E2", "framework-e3-gate": "FW-E3",
        "framework-e4-gate": "FW-E4", "framework-e5-gate": "FW-E5",
        "dependency-e2-gate": "DEP-E2", "dependency-e3-gate": "DEP-E3",
        "dependency-e4-gate": "DEP-E4", "dependency-e5-gate": "DEP-E5",
        "infrastructure-e2-gate": "INF-E2", "infrastructure-e3-gate": "INF-E3",
        "infrastructure-e4-gate": "INF-E4", "infrastructure-e5-gate": "INF-E5",
        "communication-e2-gate": "COM-E2", "communication-e3-gate": "COM-E3",
        "communication-e4-gate": "COM-E4", "communication-e5-gate": "COM-E5",
    }

    for batch, entries in SKILLS.items():
        rebuilt = []
        for entry in entries:
            slug, title, objective, keywords, outputs, checks, negatives = entry
            checks = list(checks)

            if slug.endswith("-directional-pack"):
                core = slug[: -len("-directional-pack")]
                source, target = core.split("-to-")
                old = checks[-1]
                levels = _re.search(
                    r"capped at (E\d(?:-C)?) on static evidence alone, (E\d(?:-C)?) with runtime "
                    r"trace evidence, and (E\d(?:-C)?) only with production",
                    old,
                )
                checks[-1] = _ceiling_with_ruling(
                    source,
                    target,
                    {"static": levels.group(1), "runtime": levels.group(2), "production": levels.group(3)},
                )

            if slug in cancellation_targets:
                checks.append(CANCELLATION_RULE)
            if slug in composition_targets:
                checks.append(COMPOSITION_RULE)
            if slug in domain_gate_prefix:
                label = domain_gate_prefix[slug]
                checks.append(
                    f"This gate publishes {label} only; it is never reported as a core E level and never "
                    "substitutes for the composed module level."
                )

            rebuilt.append((slug, title, objective, keywords, outputs, tuple(checks), negatives))
        SKILLS[batch] = rebuilt


_apply_p0_rulings()


# =============================================================================
# P1 CONVERGENCE — decision record ADR-MIG-P1-01 … ADR-MIG-P1-07
#
# Seven capability families were modelled two to five times across Batch 1-8. The
# registry in convergence.py names one authority per family, merges the richest
# field set into it, and marks every other member as a domain view. Applied here
# so the relationship travels inside each generated Skill. The registry is
# fail-closed: an authority or view slug that names no emitted Skill aborts the
# build rather than silently dropping the clause.
# =============================================================================

from convergence import (  # noqa: E402
    AUTHORITY_CLAUSE,
    VIEW_CLAUSE,
    authority_slug_map,
    view_slug_map,
)


def _apply_p1_convergence():
    authorities = authority_slug_map()
    views = view_slug_map()
    seen_authorities = set()
    seen_views = set()

    # Absence semantics: upgrade the four-state model to the authoritative six states.
    absence_upgrade = (
        "Missing, explicit null, defaulted, empty, zero and present are six distinct states; merging "
        "any two requires a decision record and a regression test."
    )

    for batch, entries in SKILLS.items():
        rebuilt = []
        for entry in entries:
            slug, title, objective, keywords, outputs, checks, negatives = entry
            checks = list(checks)

            if slug in authorities:
                adr, family, merged = authorities[slug]
                checks.append(AUTHORITY_CLAUSE.format(family=family))
                checks.extend(merged)
                seen_authorities.add(slug)

            if slug in views:
                adr, family, authority = views[slug]
                checks.append(VIEW_CLAUSE.format(family=family, authority=f"`{authority}`"))
                seen_views.add(slug)

            if slug == "nullability-and-absence-ir-builder":
                checks.append(absence_upgrade)

            rebuilt.append((slug, title, objective, keywords, outputs, tuple(checks), negatives))
        SKILLS[batch] = rebuilt

    missing_authorities = set(authorities) - seen_authorities
    missing_views = set(views) - seen_views
    if missing_authorities or missing_views:
        raise SystemExit(
            f"convergence registry references unknown slugs: "
            f"authorities={sorted(missing_authorities)} views={sorted(missing_views)}"
        )


_apply_p1_convergence()
