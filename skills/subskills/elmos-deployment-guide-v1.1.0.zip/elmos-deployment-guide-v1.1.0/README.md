# Elmos 系统部署、CI/CD 与大型仓库运行数据库指南

**版本：** 1.1.0  
**适用架构：** Elmos 7+1 Commercial Skills Architecture  
**目标：** 从本地开发、单机 Pilot、Kubernetes Staging 到多租户商业生产环境，并为大型仓库项目生成/跨库转换提供可恢复、可裁决、可计费的 PostgreSQL 运行数据平面。

## 重要边界

本包是**可落地的部署蓝图、配置骨架与运维 Runbook**。上一版 Elmos 7+1 交付物是产品/工程 Skills 架构，并非已经发布的完整应用镜像，因此：

- `docker-compose.yml` 和 Helm Chart 中的 `elmos-*` 镜像名是稳定的部署合同占位符；
- 在 Elmos 各服务代码和 OCI 镜像实现后，这些模板可直接接入 CI/CD；
- Postgres、Redis、MinIO、Temporal、OpenTelemetry 等本地基础设施可独立启动；
- 生产环境应优先使用托管 Postgres、对象存储、Secret Manager 和受支持的 Temporal 部署，而不是照搬本地 Compose。

## 推荐阅读顺序

1. `DEPLOYMENT-GUIDE.md`：完整部署路径。
2. `docs/DEPLOYMENT-TOPOLOGY.md`：物理服务划分与数据流。
3. `docs/SECURITY-HARDENING.md`：多租户、凭据、沙箱和网络硬化。
4. `docs/OBSERVABILITY-RUNBOOK.md`：指标、日志、Trace、告警和排障。
5. `docs/BACKUP-RESTORE.md`：备份与恢复。
6. `docs/UPGRADE-ROLLBACK.md`：升级、数据库迁移和回滚。
7. `docs/ACCEPTANCE-CHECKLIST.md`：上线验收清单。
8. `BILL-OF-MATERIALS.md`：平台组件、镜像与节点池清单。
9. `DEPLOYMENT-ACCEPTANCE-CHECKLIST.md`：E1–E5 级别的生产验收总表。
10. `database/EXECUTIVE-SUMMARY.md`：大型仓库运行数据平面的决策摘要。
11. `docs/DATABASE-DESIGN-LARGE-REPOSITORY-RUNS.md`：136 张父表的完整运行数据模型。
12. `database/DB-1-MINIMUM-TABLE-SET.md`：首发最小强一致表集与分阶段启用边界。
13. `docs/DATABASE-TRANSACTION-AND-RECOVERY.md`：幂等、租约、fencing、Checkpoint 与恢复。
14. `docs/MERGE-INTO-ELMOS-MAIN-REPOSITORY.md`：合并到 Elmos 主仓库的 PR 顺序。
15. `docs/CI-CD-PIPELINE.md` 与 `docs/P05-DEPLOYMENT-COMPLETION-GATE.md`：发布与部署完成门。
16. `VALIDATION-REPORT.md`：已执行校验、未执行边界与生产阻断条件。

## 快速入口

```bash
cp .env.example .env
./scripts/preflight.sh
./scripts/bootstrap-local.sh infra
./scripts/healthcheck.sh
```

先迁移并验证数据库：

```bash
./scripts/bootstrap-local.sh db
# 或 make db
```

当 Elmos 应用镜像已经构建：

```bash
./scripts/bootstrap-local.sh app
```

Kubernetes：

```bash
helm upgrade --install elmos ./deploy/helm/elmos \
  --namespace elmos --create-namespace \
  -f deploy/environments/staging.values.yaml
```

## 部署模式

| 模式 | 适用范围 | 关键特征 |
|---|---|---|
| Local Compose | 开发、接口联调、演示 | 单机、非强隔离、基础设施容器化。 |
| Single-node Pilot | 内部试用、小客户 PoC | Linux 服务器、TLS、持久卷、有限并发。 |
| Kubernetes Staging | 集成测试、灰度、压测 | 托管数据层、多个 Worker Pool、OTel。 |
| Commercial Production | 多租户商业交付 | 多可用区、控制/执行平面分离、强沙箱、灾备。 |
| Customer VPC / Private | 机密源码、企业迁移 | 控制面与客户 Worker 分离，源码不离开客户环境。 |
| Air-gapped | 等保/涉密/离线 | 私有镜像仓库、离线模型、依赖镜像化、无公网。 |

## v1.1.0 新增

- 11 个 Flyway migration，覆盖 13 个业务 Schema、136 张父表、31 个事务函数和 8 个安全 Read Model；
- 大型仓库 File/Symbol/IR/Capability、项目生成与跨库转换、P05 Evidence/Gate；
- Job/Run/Task/Attempt、租约、fencing、Session/Event、Checkpoint、Side Effect；
- Model/Tool/Token/Cost/Revenue/Cache/机器 ETA；
- PostgreSQL 16/17 CI 矩阵、Migration Image、Helm Migration Hook 和 Deployment Gate Hook；
- 运维查询、数据库不变量、并发故障场景和独立 Skills Package。

## 校验

```bash
python3 scripts/validate_database_design.py
python3 scripts/validate_bundle.py
```
