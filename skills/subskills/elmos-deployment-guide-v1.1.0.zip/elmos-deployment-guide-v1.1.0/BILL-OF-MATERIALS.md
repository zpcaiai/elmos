# Elmos 部署 Bill of Materials

## 1. 必需平台组件

| 类别 | 组件 | 开发 | 生产 | 备注 |
|---|---|---:|---:|---|
| Container | Docker/Podman | 必需 | 构建侧 | 生产运行推荐 Kubernetes |
| Orchestrator | Kubernetes | 可选 | 必需（参考） | 需要支持 NetworkPolicy |
| Package | Helm | 可选 | 必需 | GitOps 可使用 Argo CD/Flux 等 |
| Database | PostgreSQL | 必需 | 必需 HA | 业务真相、台账、审计、outbox |
| Workflow | Temporal | 必需 | 必需 HA/Cloud | durable Job/Task/approval/retry |
| Cache | Redis/Valkey | 必需 | 推荐 HA | 不能成为唯一事实源 |
| Object | S3/MinIO | 必需 | 必需 | snapshot、artifact、evidence、deliverable |
| Secret | `.env`（仅本地） | 可用 | 禁止 | 生产使用 Secret Broker/KMS |
| Telemetry | OTel Collector | 必需 | 必需 HA | logs/metrics/traces pipeline |
| Identity | 本地账号 | 可选 | OIDC/SSO | 企业版增加 SCIM |
| Registry | 本地/公共 | 可选 | 私有 OCI | digest、SBOM、签名 |
| Sandbox | 普通容器 | 开发限定 | RuntimeClass/microVM | restricted 任务必须强隔离 |

## 2. Elmos 服务镜像（占位命名）

```text
elmos-web
elmos-api
elmos-migrate
elmos-workflow-compiler
elmos-scheduler
elmos-model-router
elmos-runtime-gateway
elmos-repository-intelligence
elmos-transformation
elmos-verifier
elmos-gate
elmos-rule-service
elmos-release-manager
elmos-worker-general
elmos-worker-jvm
elmos-worker-dotnet
elmos-worker-rust-cpp
elmos-worker-browser
elmos-worker-android
elmos-worker-windows
elmos-worker-gpu
```

所有生产镜像必须按 digest Pin，并提供：

- build source SHA
- base image digest
- SBOM
- signature/provenance
- vulnerability result
- supported workflow/schema range
- toolchain inventory

## 3. 推荐外部集成

- OIDC Identity Provider
- GitHub/GitLab/Bitbucket
- Linear/Jira/企业 Tracker
- Cloud KMS/Secret Manager/Vault
- SMTP/通知平台
- 支付与账单系统
- Model Provider/BYOK endpoints
- 企业 SIEM/APM
- 客户 VPC Connector

## 4. 集群节点池

| 节点池 | OS/硬件 | 任务 |
|---|---|---|
| `system` | Linux general | Control Plane、Gate、Router |
| `analysis` | Linux high-memory | Repository Graph/IR |
| `workers` | Linux CPU | 普通生成与工具执行 |
| `secure-workers` | Linux + Kata/gVisor/microVM | 机密/高风险执行 |
| `verification` | Linux isolated | 独立编译、测试、安全扫描 |
| `browser` | Linux large `/dev/shm` | Playwright/Browser/UI |
| `windows` | Windows | IIS/COM/MSBuild/Windows Service |
| `gpu` | NVIDIA/其他 GPU | AI/ML 工程与模型验证 |
| `macos` | 外部受控 runner | Xcode/iOS/macOS 构建 |

## 5. 大型仓库运行数据库资产

| 资产 | 数量/版本 | 用途 |
|---|---:|---|
| PostgreSQL Migration | 11（V001–V090） | 13 个业务 Schema 的完整创建与事务函数 |
| Parent Tables | 136 | 控制、执行、仓库智能、生成/转换、验证、计量、学习、部署 |
| Runtime Functions | 31 | 原子 Claim/Renew/Finish/Event/Checkpoint/P05/Deployment Gate |
| Security Read Models | 8 | UI、运营、P05 与部署状态查询 |
| Operator Queries | 30 | 槽位、Run、Lease、Checkpoint、Gap、财务、Gate、RLS |
| Database Invariants | 23 组 | 迁移后与部署后的系统不变量 |
| PostgreSQL CI Matrix | 16、17 | 空库迁移、checksum、invariant 与 schema inventory |

生产环境还需要：

- 连接池/PgBouncer（按事务角色和 RLS 语义评估）；
- WAL/PITR；
- 数据库审计与慢查询；
- 分区维护；
- CAS/Object Store；
- Read Replica 或分析专库；
- 独立 `migrator`、`gate`、`reconciler` 角色。
