# Elmos 生产安全硬化指南

## 1. 基线

- 控制面与执行面分离；普通 Control Pod 禁止 privileged、hostPath 和 Docker Socket。
- Namespace 采用 restricted Pod Security；只有专用 Sandbox Node Pool 可使用经过审批的 RuntimeClass。
- 默认 NetworkPolicy deny-all，再按服务开放最小流量。
- 所有服务非 root、只读 root filesystem、drop all capabilities、seccomp default。
- ServiceAccount 不自动挂载 Token，确需 K8s API 的 Controller 使用最小 RBAC。

## 2. Secret 边界

- 长期 Key 存 Vault/云 Secret Manager；应用只拿短期、最小 scope 凭据。
- Agent 子进程环境清理 `*_TOKEN`、`*_KEY`、云 CLI、GitHub/GitLab 别名和 kubeconfig。
- Host-side Tool 使用凭据并返回受限结果，不把原始 token 传给模型或 Worker shell。
- 日志、Trace、Tool Output、Artifact 上传前执行 Secret/PII 扫描。

## 3. 租户隔离

- 所有表和对象 metadata 带 `tenant_id`，API 层强制 subject/tenant 绑定。
- 推荐 Postgres RLS 作为纵深防御，但不能替代服务端授权。
- Cache key、queue subject、object prefix、metric label 和 workspace 路径均包含不可伪造 tenant scope。
- 跨租户测试纳入每次 Release Gate。

## 4. 沙箱

- `read-only`、`workspace-write`、`danger-full-access` 是显式策略，不允许自动升级。
- 后端必须报告 `full|partial` enforcement；强隔离任务遇到 partial 直接拒绝。
- 网络权限与文件权限分开；默认无公网，按域名/CIDR/协议临时开放。
- 限制 CPU、内存、PID、磁盘、文件数、网络字节和最长 wall-clock。
- 禁止共享宿主用户目录、SSH、Docker、Kubernetes、云凭据目录。

## 5. 供应链

- 依赖和基础镜像 Pin；生成 SBOM 和许可证清单。
- OCI 镜像签名和准入验证；禁止 mutable production tag。
- 扫描 Critical/High 漏洞、Secret、恶意包和 license policy。
- Worker 安装依赖时优先内部镜像源和 lockfile；公网包下载走代理并记录 hash。

## 6. OIDC 与权限

角色建议：

- Platform Admin
- Tenant Admin
- Project Admin
- Developer
- Reviewer/Approver
- Auditor
- Billing Operator
- Support Read-only

高风险策略、生产部署、数据导出、知识学习授权和证据豁免采用双人审批。

## 7. Kubernetes Checklist

- [ ] `runAsNonRoot: true`
- [ ] `readOnlyRootFilesystem: true`
- [ ] `allowPrivilegeEscalation: false`
- [ ] capabilities drop `ALL`
- [ ] seccomp `RuntimeDefault`
- [ ] NetworkPolicy default deny
- [ ] image digest/signature policy
- [ ] Secret via external provider
- [ ] mTLS or service mesh/private network
- [ ] audit logs to immutable destination
- [ ] egress proxy and DNS policy
- [ ] RuntimeClass for untrusted code

## 9. PostgreSQL 多租户与高价值函数硬化

- 所有租户父表启用 `ROW LEVEL SECURITY` 与 `FORCE ROW LEVEL SECURITY`；
- 连接事务必须设置 `SET LOCAL app.tenant_id`；
- 普通应用角色不拥有表，避免 owner 绕过 RLS；
- `row_security=off` 仅允许审计的迁移/平台任务；
- `SECURITY DEFINER` 函数固定 `search_path`，不接受动态标识符；
- `claim_account_slot`、Task Lease、Event Append、Checkpoint Seal、Side-effect Reservation、P05/Deployment Gate 等函数从 PUBLIC 撤销；
- Job/Run/Artifact/Evidence/Object key 必须携带相同 tenant scope；
- 大型批量导入使用租户绑定的 staging 表或 COPY 连接，不共享临时跨租户缓冲。

数据库安全验收：

```bash
python3 scripts/validate_database_design.py
psql "$ELMOS_DATABASE_URL" -v ON_ERROR_STOP=1 \
  -f database/tests/invariants.sql
```

还必须进行双连接并发测试：Tenant A 写入后 Tenant B 的普通应用角色查询必须得到零行，而不是依赖 API 层过滤。
