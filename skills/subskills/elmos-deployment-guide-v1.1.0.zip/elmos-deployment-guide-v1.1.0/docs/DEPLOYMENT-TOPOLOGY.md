# Elmos 部署拓扑与服务边界

## 1. 逻辑包到物理服务的映射

| 逻辑包 | 初期物理部署 | 规模化后 |
|---|---|---|
| P00 | Control API 内模块 | Control API + Release/Policy 服务 |
| P01 | Runtime Gateway | Runtime Gateway + Adapter/Sandbox Controller |
| P02 | Analyzer Worker | 多语言专用 Analyzer Pools |
| P03 | Transformer Worker | 按语言/框架的生成与迁移 Pools |
| P04 | Scheduler/Orchestrator | Sharded Scheduler + Worker Controller |
| P05 | Verifier Worker + Gate API | Verification Orchestrator + Specialized Pools |
| P06 | Model Router | Catalog/Policy/Execution 可分别扩展 |
| P07 | Offline Learning Worker | 独立受控数据域与批处理集群 |

## 2. 请求路径

```text
Client
 -> Ingress
 -> Control API: create Job + freeze revisions
 -> Scheduler: compile DAG + reserve budget
 -> Runtime Gateway: create Session/Run
 -> Worker Controller: create isolated Run environment
 -> Model Router: select eligible model/provider
 -> Analyzer/Transformer/Verifier
 -> Object Store: artifacts/evidence
 -> P05 Gate Decision
 -> Control API: release/handoff/completed
```

## 3. 关键网络区

- **Public Edge**：Ingress/WAF，仅暴露 Web/API。
- **Control Zone**：Control API、Scheduler、Runtime Gateway、Model Router。
- **Data Zone**：Postgres、Temporal、Redis、Object Store、Secret Manager。
- **Execution Zone**：不可信仓库与代码执行；默认不能直接访问 Data Zone。
- **Observability Zone**：Collector、Metrics/Logs/Traces；默认不保存原始源码和 Prompt。

## 4. 执行环境选择

| 风险 | 推荐运行时 |
|---|---|
| 只读仓库分析 | 非 root 容器 + read-only FS |
| 代码生成/普通测试 | gVisor/Kata Pod + workspace-write |
| 不可信依赖/高副作用 | 微 VM/Firecracker/Kata + egress proxy |
| 客户内网/机密代码 | 客户 VPC Runner，outbound-only mTLS |
| iOS/macOS | 专用 Mac Runner |
| Windows/.NET Framework | Windows Runner |

## 5. Artifact 与 Evidence 分桶

- `elmos-artifacts`：代码包、构建物、媒体和中间状态；允许生命周期清理。
- `elmos-evidence`：Gate 证据、签名、报告、差分快照；开启版本和 WORM。
- `elmos-session-artifacts`（可选）：大 Tool Output、压缩前历史和回放资产。

每个对象键应含 tenant/project/job/run 前缀，同时以内容 hash 做完整性检查；权限由 metadata ACL 决定，不能仅依赖可猜测路径。
