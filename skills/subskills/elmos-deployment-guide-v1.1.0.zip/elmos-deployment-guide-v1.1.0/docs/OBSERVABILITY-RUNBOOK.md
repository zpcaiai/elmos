# Elmos 可观测与运行 Runbook

## 1. 信号

### Metrics

- `elmos_job_total{state,type,tenant}`
- `elmos_job_duration_seconds`
- `elmos_queue_depth{pool,tenant}`
- `elmos_run_active{pool}`
- `elmos_run_recovery_total{reason}`
- `elmos_tool_duration_seconds{tool,outcome}`
- `elmos_model_request_total{provider,model,outcome}`
- `elmos_model_tokens_total{kind,provider,model}`
- `elmos_model_cost_usd_total{tenant,provider,model}`
- `elmos_gate_decision_total{decision,gate}`
- `elmos_unknown_gap_total{language,framework}`
- `elmos_sandbox_execution_total{mode,enforcement,outcome}`
- `elmos_evidence_integrity_failure_total`

### Logs

使用 JSON；固定字段：timestamp、severity、service、tenant/project/job/run/session/task/tool、correlation、causation、revision、error_code、retryable。

### Traces

主 Span：

```text
HTTP request
 -> workflow compile
 -> scheduler admission
 -> workspace prepare
 -> model route
 -> model call
 -> tool execution
 -> verification step
 -> evidence persist
 -> gate decision
```

## 2. Dashboard

1. Executive：Job 成功、Gate pass、交付时长、成本、毛利、SLA。
2. Operations：队列、active run、stall、retry、Temporal、DB、对象存储。
3. Conversion：能力覆盖、unknown gap、differential mismatch、repair rounds。
4. Model：route、fallback、cached tokens、Provider error、rate limit、cost。
5. Security：deny/approval、Secret finding、sandbox enforcement、跨租户。

## 3. 告警与动作

| 级别 | 条件 | 自动动作 |
|---|---|---|
| P0 | Gate bypass、证据篡改、跨租户、Secret 泄漏、无沙箱 | Kill switch；暂停新 Job；隔离相关 Run；保全审计。 |
| P1 | Scheduler/Temporal/DB 大面积失败、Worker 失联 | 暂停 admission；保持 reconciliation；切备用。 |
| P2 | 单 Provider 降级、成本/时延漂移 | Circuit break/fallback；限制并发。 |
| P3 | 文档/配置/知识过期 | 创建维护任务；不影响当前可信 Run。 |

## 4. 常见排障

### Job 长时间 `running`

1. 查询 Temporal Workflow 和 Postgres Job revision。
2. 查 Workspace Lease 是否过期。
3. 查最后 Session/Tool event 时间。
4. 查 Worker Pod/Runner 是否仍存活。
5. 不要直接重跑副作用步骤；先核对 idempotency settlement。

### Job 卡在 `verifying`

1. 查询 P05 plan 和最后一个 evidence ref。
2. 检查 Verifier Worker 资源与测试超时。
3. 验证 Evidence Bucket 可写且 hash 一致。
4. Gate 失败应产生 typed reason，禁止人工直接改 completed。

### Provider 大量失败

1. 查看 route decision、endpoint health 和 rate limit。
2. 激活 circuit breaker；只在隐私/能力硬约束满足时 fallback。
3. 不允许为恢复可用性而切到不符合 ZDR/地区/数据政策的 Provider。

### Redis 故障

Redis 只保存可重建缓存。应用应降级到 Postgres/Temporal 权威状态，恢复后重新填充，不能丢失 Job 或重复副作用。
