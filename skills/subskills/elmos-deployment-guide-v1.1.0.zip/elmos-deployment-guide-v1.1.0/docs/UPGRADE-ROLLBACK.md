# Elmos 升级与回滚指南

## 1. 兼容维度

每次 Release 必须检查：

- OpenAPI/JSON Schema/Protobuf 合同；
- 数据库 Schema；
- Session/Event format；
- Workflow/Policy format；
- Harness Adapter capability；
- Worker image/toolchain；
- Model/Provider Catalog；
- Transformation Rule 与 Evidence format。

## 2. 数据库 Expand/Contract

### Release N

- 新增 nullable 列/新表/索引；
- 应用读新旧并兼容旧数据；
- 必要时双写；
- 后台迁移历史数据。

### Release N+1

- 确认旧版本无流量；
- 切换新字段权威；
- 停止旧字段写入。

### Release N+2

- 删除旧字段/旧索引。

禁止在同一发布中先删列再部署新应用。

## 3. Canary

- 先内部租户和只读分析 Job；
- 再低风险生成 Job；
- 再转换与验证 Job；
- 最后生产副作用场景。

观察 Gate pass、unknown gap、repair rounds、Provider fallback、成本、P95 ETA 和安全告警。

## 4. 回滚触发

- Critical 安全或租户隔离问题；
- P05 bad pass / Gate bypass；
- Evidence 不可验证；
- Session/Run 不可恢复；
- 数据库/事件兼容错误；
- 质量或成本超出策略阈值。

## 5. 回滚步骤

1. 停止新 admission，保留 reconciliation。
2. 将 Feature Flag/Route/Rule 回到 last-known-good revision。
3. 回滚 Control Plane 镜像。
4. 回滚 Worker Controller；在跑 Worker 根据兼容矩阵决定继续、取消或重建。
5. 数据库只在确认向后不兼容时执行 restore；优先使用 expand migration 避免 DB 回滚。
6. 隔离新版本生成的 P07 rules 和可疑 Evidence。
7. 生成 Incident 与修复 Benchmark。

## 6. Session Format

未知 required event 必须拒绝，而不是忽略。升级前提供 upgrader 或明确版本拒绝；旧版本不得加载无法忠实解释的新 Session。

## 7. 数据库 Migration Gate

每次升级必须保存 `ops.migration_run`，绑定：

- Deployment；
- from/to schema version；
- migration manifest SHA-256；
- started/ended time；
- result artifact；
- status。

Migration 完成后先执行 `database/tests/invariants.sql`，再允许应用 Rollout。Deployment Gate 会检查 required migration 是否为 `succeeded` 或 `not_required`。

### 7.1 禁止修改已发布 Migration

已进入任何共享环境的 `V*.sql` 不得原地修改；修复必须新增后续 Migration。CI 的 Flyway checksum validate 必须阻断漂移。

### 7.2 长任务版本兼容

升级时仍可能存在运行数小时或数天的 Run。Release Manifest 必须声明：

- 支持读取的 Session/Event format；
- 支持的 Workflow/Policy revision；
- 支持的 database schema range；
- Worker image/toolchain compatibility；
- 旧 Checkpoint 是否可恢复。

不兼容 Run 应进入 `blocked` 或迁移流程，不能由新版本静默解释。
