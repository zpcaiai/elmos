# Elmos 备份与恢复指南

## 1. 备份对象

### Postgres

- PITR/WAL 持续归档；
- 每日全量快照；
- 迁移前手工恢复点；
- 定期从备份启动独立实例验证可恢复性。

### Object Store

- Artifact Bucket：版本控制与生命周期；
- Evidence Bucket：版本控制、跨区域复制、Object Lock/WORM；
- 保存对象 checksum、metadata 和 ACL 快照。

### Temporal

自托管时备份其 persistence/visibility 数据库和动态配置；业务领域仍以 Postgres 为准。恢复后执行 Workflow→Job 重对账。

### 配置与 Secret

- Workflow、Policy、Helm values、Schema、ADR 在 Git 中版本化；
- Secret Manager 使用供应商备份/复制能力；
- 不把明文 Secret 放进普通备份包。

## 2. 本地备份

```bash
./scripts/backup-local.sh ./backups
```

生成 Postgres dump 和对象存储目录镜像。仅用于开发/Pilot，不替代生产备份系统。

## 3. 恢复顺序

1. 冻结写流量和新 Job admission。
2. 恢复 Postgres 到目标时间。
3. 恢复/挂载 Artifact 与 Evidence。
4. 恢复 Temporal；无法恢复时以 Postgres 的非终态 Job 重建 Workflow。
5. 启动 Control Plane，只读模式执行一致性扫描。
6. 对账 Workspace Lease、Run、Session、Task、Outbox/Inbox。
7. 验证 Evidence hash、Release Manifest 和计费结算。
8. 先开放只读，再开放新 Job。

## 4. 恢复验收

- 终态 Job 不被重新调度；
- 非终态 Job 进入可解释的 resumed/retry/blocked；
- 同一 idempotency key 不重复副作用；
- Evidence 与 Release Artifact 可追溯；
- 审计序列没有静默缺口；
- 客户数据和租户 ACL 保持一致。

## 5. 演练频率

- 数据库恢复：至少季度；高等级 SLA 每月。
- Evidence 跨区域恢复：至少半年。
- 整站灾备和 Worker VPC 切换：至少半年。
- 每次重大 Schema/Session Format 升级前做专项演练。

## 6. 大型仓库运行数据恢复顺序

恢复时按依赖层级重建：

```text
Tenant/Account/Project/Job
→ Run/Stage/Task/Attempt/Lease
→ Event Cursor + Event Log
→ Artifact/Manifest/Checkpoint
→ Repository/IR/Capability indexes
→ Target Revision/Patch Set
→ Verification/Evidence/Gate
→ Side Effect/Outbox/Inbox
→ Usage/Cost/Revenue/ETA
```

恢复后必须执行：

```bash
psql "$ELMOS_DATABASE_URL" -v ON_ERROR_STOP=1 \
  -f database/tests/invariants.sql
```

然后针对每个非终态 Run：

1. 验证 `current_run_id`；
2. 回收过期 Lease 并增加 generation；
3. 选择最新 sealed Checkpoint；
4. 校验 Manifest 与 CAS hash；
5. 对 `UNKNOWN_RESULT` 外部副作用先重对账，禁止盲目重试；
6. 重新启动 Temporal Workflow 或恢复相应 Task Queue；
7. 重新计算 Progress、Budget、Cost 和 ETA；
8. 不复用已过期 Evidence 完成 P05。

### 6.1 CAS 与数据库一致性

数据库恢复点与对象存储版本可能不完全一致。以数据库引用为起点：

- DB 引用但 CAS 缺失：Artifact 标记不可用，阻断恢复/P05；
- CAS 存在但 DB 无引用：进入 orphan quarantine，等待保留期后 GC；
- Evidence Bucket 版本变化：按 `version_id + sha256` 校验，不使用“当前对象”替代历史证据。
