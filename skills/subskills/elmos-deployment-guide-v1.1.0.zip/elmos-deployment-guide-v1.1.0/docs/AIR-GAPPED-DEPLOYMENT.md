# Elmos 离线与私有化部署

## 1. 必备镜像

- 所有 Elmos 服务/Worker OCI 镜像；
- Postgres/Redis/Temporal/OTel 等依赖镜像；
- 语言工具链镜像：JDK、.NET、Rust、Go、Node、Python、C/C++；
- 浏览器镜像；
- 必需的 LSP、编译器、包缓存和模型运行时。

镜像通过离线介质进入私有 Registry，并保存 digest、签名和 SBOM。

## 2. 模型

- 使用本地 vLLM/SGLang/其他受控推理服务；
- P06 Catalog 仅登记内网 endpoint；
- 所有公网 Provider 默认 deny；
- 预加载模型、tokenizer、许可证和量化版本。

## 3. 依赖供应链

- 建立 Maven/NPM/PyPI/NuGet/Cargo/Go Proxy 镜像；
- Worker 禁止直接公网下载；
- Lockfile 与依赖 hash 是 Gate 的一部分；
- 新依赖通过离线审批和恶意包扫描。

## 4. 时间与证书

- 内部 NTP；
- 私有 CA；
- mTLS 证书自动轮换；
- 审计日志导出到不可变存储。

## 5. 更新

每个离线更新包包含镜像、Chart、migration、Schema、SBOM、签名、兼容矩阵和回滚包；进入环境前离线验证签名。
