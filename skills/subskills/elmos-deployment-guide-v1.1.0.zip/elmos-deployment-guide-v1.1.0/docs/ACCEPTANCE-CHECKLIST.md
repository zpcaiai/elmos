# Elmos 部署与商业上线验收清单

## 基础设施

- [ ] Postgres HA/PITR 已启用并做恢复演练。
- [ ] Temporal HA 与 namespace/task queue 已验证。
- [ ] Artifact/Evidence Bucket 分离，Evidence 有版本/WORM。
- [ ] Redis 故障不会造成事实丢失或副作用重复。
- [ ] OIDC、MFA、角色与双人审批生效。
- [ ] Secret Manager 与自动轮换生效。

## 服务

- [ ] 所有服务有 `/livez`、`/readyz`、`/metrics`、`/version`。
- [ ] Control API、Runtime Gateway、Model Router 多副本跨 AZ。
- [ ] Scheduler leader/shard lease 防止双调度。
- [ ] 数据库 migration 可重复、可锁定、可审计。
- [ ] 配置有 revision、last-known-good 和 kill switch。

## Worker

- [ ] 不可信代码不运行在控制面节点。
- [ ] Worker 非 root，资源限额和 wall-clock 生效。
- [ ] 沙箱报告 full/partial，强隔离任务 fail closed。
- [ ] 网络默认 deny，通过 egress proxy 放行。
- [ ] Linux、Windows、macOS、GPU Pool 权限和任务路由明确。
- [ ] Worker 崩溃、节点丢失和 Lease 接管演练通过。

## 数据与安全

- [ ] 每个数据对象有 tenant scope、classification、retention。
- [ ] Prompt/源码/Secret 不进入默认日志。
- [ ] 跨租户、路径穿越、Prompt injection、Secret 继承测试通过。
- [ ] OCI 签名、SBOM、漏洞、License、Secret Scan 通过。
- [ ] Audit/Evidence 完整性可验证。

## 功能闭环

- [ ] Repository Analysis Job 可生成 P02 artifacts。
- [ ] Transformation Job 可生成目标仓库与 migration artifacts。
- [ ] P05 在缺少证据时拒绝 completed。
- [ ] 失败生成 Repair Task 并有 no-progress/doom-loop 上限。
- [ ] idempotency key 阻止重复外部副作用。
- [ ] 人工 Review、Release、Rollback 路径可用。
- [ ] P07 只接收 verified + authorized 证据。

## 运维

- [ ] Dashboard 支持 tenant→job→run→session→tool→evidence 下钻。
- [ ] P0/P1 告警和自动暂停 admission 已演练。
- [ ] 备份、恢复、升级、回滚和灾备 Runbook 已值班演练。
- [ ] 成本、Token、机器 ETA 与实际偏差可监控。
