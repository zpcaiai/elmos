# Elmos 服务健康、指标与版本合同

所有 Web/API/Scheduler/Runtime/Router/Controller 服务必须实现相同的运维面。

## `/livez`

用途：判断进程是否仍能响应。

- 不访问数据库、Temporal、S3 或 Model Provider；
- 仅检查 event loop/thread/runtime 是否存活；
- 正常返回 HTTP 200；
- 进程不可继续服务时返回 500；
- 不返回 Secret、配置正文或用户数据。

示例：

```json
{"status":"live","service":"elmos-control-api"}
```

## `/readyz`

用途：判断实例是否可接收新流量或新任务。

至少验证：

- 启动初始化完成；
- 必需配置已加载；
- 当前数据库 Schema 在服务支持范围内；
- PostgreSQL 可执行只读探测；
- 服务所需 Temporal task queue/connection 可用；
- 必需对象存储 namespace 可访问；
- 当前 policy/workflow contract 可解析；
- Scheduler/Worker 在 drain 时返回非 ready。

不要把短暂不可用的非关键模型 Provider 作为所有服务的 readiness 硬依赖；Provider 可用性由 Model Router 与任务路由策略处理。

示例：

```json
{
  "status": "ready",
  "service": "elmos-control-api",
  "checks": {
    "database": "pass",
    "schema": "pass",
    "temporal": "pass",
    "object_store": "pass"
  }
}
```

## `/metrics`

Prometheus/OpenMetrics 输出，至少包括：

- HTTP request duration/error；
- DB pool wait/active connections；
- Job/Run/Task 状态；
- task claim/lease expiry/fencing rejection；
- checkpoint success/failure；
- P05 gate pass/fail/blocked；
- outbox backlog；
- side effect unknown result；
- model tokens/cost/cache hit；
- machine ETA error；
- deployment gate duration/result。

标签不得包含源码、Prompt、邮箱、Secret 或高基数全文。推荐标签：`tenant_tier`、`run_kind`、`task_type`、`worker_pool`、`model_family`、`result`。

## `/version`

必须返回不可变构建和兼容信息：

```json
{
  "service": "elmos-control-api",
  "version": "1.4.0",
  "git_sha": "0123456789abcdef",
  "image_digest": "sha256:...",
  "built_at": "2026-08-21T08:00:00Z",
  "database": {
    "current": "V090",
    "minimum_supported": "V080",
    "maximum_supported": "V090"
  },
  "contracts": {
    "api": "2026-08-01",
    "workflow": "1",
    "session_event": "1",
    "evidence": "1",
    "p05_gate_policy": "p05-completion-v1"
  }
}
```

`image_digest` 应由运行环境或构建注入，不能仅返回 tag。

## Probe 语义

- Startup Probe 使用 `/livez`，允许冷启动；
- Readiness Probe 使用 `/readyz`；
- Liveness Probe 使用 `/livez`；
- 优雅终止先进入 drain，使 `/readyz` 失败，再停止领取 Task，flush Event/Checkpoint 后退出。

## CI 合同测试

每个服务镜像启动后，CI 必须：

1. 调用四个端点；
2. 校验 JSON/metrics 格式；
3. 校验 `/version.git_sha` 与构建 SHA；
4. 校验 image digest/Release Manifest；
5. 模拟数据库不可用，确认 `/readyz` 失败但 `/livez` 仍成功；
6. 模拟 drain，确认不再接收新任务。
