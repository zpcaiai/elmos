# Elmos 容量规划

下列是初始规划值，不是已实测承诺；上线前必须以真实仓库 Benchmark 校准。

## 1. 控制面起步资源

| 服务 | 副本 | 单副本建议 |
|---|---:|---:|
| Web | 2–3 | 0.5–1 vCPU / 512 MiB–1 GiB |
| Control API | 3 | 2 vCPU / 4–8 GiB |
| Scheduler | 2–3 | 2 vCPU / 4 GiB |
| Runtime Gateway | 3 | 2–4 vCPU / 4–8 GiB |
| Model Router | 3 | 1–2 vCPU / 2–4 GiB |
| Worker Controller | 2 | 2 vCPU / 4 GiB |

## 2. Run Worker 起步资源

| Worker | 小型仓库 | 中大型仓库 |
|---|---:|---:|
| Analyzer | 2–4 vCPU / 4–8 GiB | 8 vCPU / 16–32 GiB |
| Transformer | 4 vCPU / 8 GiB | 8–16 vCPU / 16–32 GiB |
| Verifier | 4 vCPU / 8 GiB | 16 vCPU / 32–64 GiB |
| Browser | 2 vCPU / 4 GiB | 4 vCPU / 8 GiB |

为构建缓存、依赖和 workspace 预留 20–100 GB 临时盘。Java/Android/C++/大型 monorepo 可能更高。

## 3. 并发模型

```text
admitted concurrency
= min(global quota,
      tenant quota,
      project quota,
      worker pool slots,
      provider rate limit,
      cost envelope,
      verification capacity)
```

不应只按 CPU 扩容；模型速率、Token 预算、磁盘、对象存储和 P05 队列也可能成为瓶颈。

## 4. 数据容量

规划因子：

- 源仓库压缩大小；
- 每 Run workspace 放大倍数；
- 构建缓存；
- Session/Tool Output；
- Screenshot/video；
- Evidence retention；
- 每 Tenant 并发与保留期。

建议 Artifact 与 Evidence 分别计量和配额。Evidence 不能因普通 Artifact 生命周期策略被删除。

## 5. PostgreSQL 大型仓库容量规划

### 5.1 主要行数驱动

```text
repository_file ≈ source revision file count
symbol_record ≈ source symbols × parser coverage
capability ≈ business/runtime capabilities discovered
run_event ≈ task transitions + tool/model/result/checkpoint/gate facts
session_event ≈ model turns + chunks/results + context boundaries
verification_result ≈ test cases × attempts × target revisions
```

### 5.2 规模分层

| 规模 | 文件数 | Symbol 估计 | 建议 |
|---|---:|---:|---|
| S | <10k | <1M | 单 PostgreSQL，标准索引 |
| M | 10k–100k | 1M–10M | 16 Hash 分区、COPY 批量导入 |
| L | 100k–1M | 10M–100M | 高内存分析节点、Read Replica、按 Revision 归档 |
| XL | >1M | >100M | 分析专库/租户 shard，Graph/IR 只存 Shard Index |

### 5.3 数据库连接预算

控制面和 Worker 不应按 Pod 数直接放大连接：

```text
max_connections budget
= control API pool
+ scheduler/reconciler pool
+ gate/migrator reserve
+ worker write pool
+ operator reserve
```

大型批量写使用少量长连接和 `COPY`，不要为每个文件/符号开启事务。P05、租约和准入连接必须保留独立余量，不能被分析批量写耗尽。

### 5.4 WAL 与 Checkpoint

大规模 Repository/Symbol 导入会造成高 WAL：

- 分批提交；
- 控制单批 10k–100k 行并以实测调整；
- 监控 replication lag、WAL archive、checkpoint write time；
- 避免在高峰同时重建多个大索引；
- 将可重建的分析数据与高价值 Evidence/财务数据分开备份和保留。
