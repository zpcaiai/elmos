#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ELMOS_ENV_FILE:-$ROOT/.env}"
COMPOSE_FILE="$ROOT/deploy/local/docker-compose.yml"
DEST="${1:-$ROOT/backups}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$DEST/$STAMP"
mkdir -p "$OUT"

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T postgres \
  pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc > "$OUT/elmos-postgres.dump"

docker run --rm --network elmos-local_elmos-backend \
  -v "$OUT:/backup" "${MINIO_MC_IMAGE}" sh -ec \
  "mc alias set local http://minio:9000 '$MINIO_ROOT_USER' '$MINIO_ROOT_PASSWORD' && \
   mc mirror local/$S3_BUCKET_ARTIFACTS /backup/artifacts && \
   mc mirror local/$S3_BUCKET_EVIDENCE /backup/evidence"

sha256sum "$OUT/elmos-postgres.dump" > "$OUT/CHECKSUMS.sha256"
find "$OUT/artifacts" "$OUT/evidence" -type f -print0 2>/dev/null | sort -z | xargs -0 sha256sum >> "$OUT/CHECKSUMS.sha256" || true

echo "Local backup created: $OUT"
