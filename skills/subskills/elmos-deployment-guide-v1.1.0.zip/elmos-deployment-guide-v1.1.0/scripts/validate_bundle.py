#!/usr/bin/env python3
"""Validate the Elmos deployment/database delivery bundle."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml
from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parent.parent
ERRORS: list[str] = []

REQUIRED = [
    "README.md",
    "DEPLOYMENT-GUIDE.md",
    "DEPLOYMENT-MANIFEST.json",
    "DEPLOYMENT-ACCEPTANCE-CHECKLIST.md",
    "VALIDATION-REPORT.md",
    "BILL-OF-MATERIALS.md",
    ".env.example",
    ".github/workflows/database-ci.yml",
    ".github/workflows/elmos-ci-cd.example.yml",
    "deploy/local/docker-compose.yml",
    "deploy/helm/elmos/Chart.yaml",
    "deploy/helm/elmos/values.yaml",
    "deploy/helm/elmos/values.schema.json",
    "deploy/helm/elmos/templates/migrate-job.yaml",
    "deploy/helm/elmos/templates/deployment-gate-job.yaml",
    "deploy/migration-image/Dockerfile",
    "deploy/deployment-gate-image/Dockerfile",
    "deploy/deployment-gate-image/gate.py",
    "database/README.md",
    "database/EXECUTIVE-SUMMARY.md",
    "database/DB-1-MINIMUM-TABLE-SET.md",
    "database/roles/README.md",
    "database/roles/roles-and-grants.example.sql",
    "database/queries/role_hardening_check.sql",
    "database/TABLE-CATALOG.md",
    "database/queries/operator_queries.sql",
    "database/tests/invariants.sql",
    "database/tests/concurrency-scenarios.md",
    "database/schemas/large-run-read-model.schema.json",
    "database/examples/large-run-read-model.example.json",
    "docs/DATABASE-DESIGN-LARGE-REPOSITORY-RUNS.md",
    "docs/DATABASE-TRANSACTION-AND-RECOVERY.md",
    "docs/DATABASE-PARTITIONING-RETENTION.md",
    "docs/DATABASE-SECURITY-RLS.md",
    "docs/DATABASE-MIGRATION-OPERATIONS.md",
    "docs/MERGE-INTO-ELMOS-MAIN-REPOSITORY.md",
    "docs/CI-CD-PIPELINE.md",
    "docs/SERVICE-HEALTH-AND-VERSION-CONTRACT.md",
    "docs/P05-DEPLOYMENT-COMPLETION-GATE.md",
    "skills/large-repository-run-persistence/SKILL.md",
    "scripts/validate_database_design.py",
    "scripts/migrate-local.sh",
    "scripts/build-release-manifest.py",
    "scripts/check-deployment-gate.sh",
    "scripts/validate-service-contract.py",
]

PLAIN_YAML = [
    "deploy/local/docker-compose.yml",
    "deploy/local/otel-collector.yaml",
    "deploy/local/prometheus.yml",
    "deploy/helm/elmos/Chart.yaml",
    "deploy/helm/elmos/values.yaml",
    "deploy/environments/staging.values.yaml",
    "deploy/environments/production.values.yaml",
    "examples/external-secret.example.yaml",
    "examples/run-job.example.yaml",
    "examples/oidc-config.example.yaml",
    ".github/workflows/database-ci.yml",
    ".github/workflows/elmos-ci-cd.example.yml",
]

JSON_FILES = [
    "DEPLOYMENT-MANIFEST.json",
    "examples/version-response.example.json",
    "examples/deployment-gate-request.example.json",
    "database/schemas/large-run-read-model.schema.json",
    "database/examples/large-run-read-model.example.json",
    "deploy/helm/elmos/values.schema.json",
]


def deep_merge(base: Any, overlay: Any) -> Any:
    if isinstance(base, dict) and isinstance(overlay, dict):
        result = deepcopy(base)
        for key, value in overlay.items():
            result[key] = deep_merge(result[key], value) if key in result else deepcopy(value)
        return result
    return deepcopy(overlay)


for rel in REQUIRED:
    if not (ROOT / rel).is_file():
        ERRORS.append(f"missing {rel}")

for rel in PLAIN_YAML:
    path = ROOT / rel
    if not path.exists():
        continue
    try:
        documents = list(yaml.safe_load_all(path.read_text(encoding="utf-8")))
        if not documents:
            ERRORS.append(f"YAML empty {rel}")
    except Exception as exc:
        ERRORS.append(f"YAML invalid {rel}: {exc}")

for rel in JSON_FILES:
    path = ROOT / rel
    if not path.exists():
        continue
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        ERRORS.append(f"JSON invalid {rel}: {exc}")

try:
    values_schema = json.loads((ROOT / "deploy/helm/elmos/values.schema.json").read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(values_schema)
    validator = Draft202012Validator(values_schema)
    defaults = yaml.safe_load((ROOT / "deploy/helm/elmos/values.yaml").read_text(encoding="utf-8"))
    for name, values in [
        ("default", defaults),
        ("staging", deep_merge(defaults, yaml.safe_load((ROOT / "deploy/environments/staging.values.yaml").read_text(encoding="utf-8")))),
        ("production", deep_merge(defaults, yaml.safe_load((ROOT / "deploy/environments/production.values.yaml").read_text(encoding="utf-8")))),
    ]:
        for error in validator.iter_errors(values):
            ERRORS.append(f"Helm values invalid ({name}) at {list(error.path)}: {error.message}")
except Exception as exc:
    ERRORS.append(f"values schema validation failed: {exc}")

try:
    run_schema = json.loads((ROOT / "database/schemas/large-run-read-model.schema.json").read_text(encoding="utf-8"))
    run_example = json.loads((ROOT / "database/examples/large-run-read-model.example.json").read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(run_schema)
    errors = sorted(
        Draft202012Validator(run_schema, format_checker=FormatChecker()).iter_errors(run_example),
        key=lambda error: list(error.path),
    )
    for error in errors:
        ERRORS.append(f"large run example invalid at {list(error.path)}: {error.message}")
except Exception as exc:
    ERRORS.append(f"large run schema/example validation failed: {exc}")

for script in sorted((ROOT / "scripts").glob("*.sh")):
    proc = subprocess.run(["bash", "-n", str(script)], capture_output=True, text=True)
    if proc.returncode:
        ERRORS.append(f"shell invalid {script.name}: {proc.stderr.strip()}")

for script in sorted((ROOT / "scripts").glob("*.py")):
    proc = subprocess.run([sys.executable, "-m", "py_compile", str(script)], capture_output=True, text=True)
    if proc.returncode:
        ERRORS.append(f"python invalid {script.name}: {proc.stderr.strip()}")

for script in [ROOT / "deploy/deployment-gate-image/gate.py"]:
    if not script.exists():
        continue
    proc = subprocess.run([sys.executable, "-m", "py_compile", str(script)], capture_output=True, text=True)
    if proc.returncode:
        ERRORS.append(f"python invalid {script.relative_to(ROOT)}: {proc.stderr.strip()}")

skill = ROOT / "skills/large-repository-run-persistence/SKILL.md"
if skill.exists():
    text = skill.read_text(encoding="utf-8")
    match = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
    if not match:
        ERRORS.append("skill frontmatter missing")
    else:
        try:
            frontmatter = yaml.safe_load(match.group(1))
            if frontmatter.get("name") != "large-repository-run-persistence":
                ERRORS.append("skill name mismatch")
            if not frontmatter.get("description"):
                ERRORS.append("skill description missing")
        except Exception as exc:
            ERRORS.append(f"skill frontmatter invalid: {exc}")

# The templates are Go-template YAML and cannot be parsed by PyYAML directly.
for rel, tokens in {
    "deploy/helm/elmos/templates/migrate-job.yaml": ["pre-install,pre-upgrade", ".Values.migration.image", "activeDeadlineSeconds"],
    "deploy/helm/elmos/templates/deployment-gate-job.yaml": ["post-install,post-upgrade", "ELMOS_RELEASE_MANIFEST_SHA256", "ELMOS_REQUIRED_SCHEMA_VERSION", "ELMOS_DEPLOYMENT_GATE_POLICY_REVISION", "index .Values.components \"control-api\""],
    "deploy/helm/elmos/templates/deployments.yaml": ["/livez", "/readyz", "containerSecurityContext"],
}.items():
    path = ROOT / rel
    if not path.exists():
        continue
    text = path.read_text(encoding="utf-8")
    for token in tokens:
        if token not in text:
            ERRORS.append(f"Helm template {rel} missing contract token: {token}")

manifest_path = ROOT / "DEPLOYMENT-MANIFEST.json"
if manifest_path.exists():
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("version") != "1.1.0":
        ERRORS.append("deployment manifest version must be 1.1.0")

for rel, minimum_lines in {
    "docs/DATABASE-DESIGN-LARGE-REPOSITORY-RUNS.md": 800,
    "docs/DATABASE-TRANSACTION-AND-RECOVERY.md": 650,
    "database/TABLE-CATALOG.md": 220,
    "skills/large-repository-run-persistence/SKILL.md": 350,
}.items():
    path = ROOT / rel
    if path.exists() and len(path.read_text(encoding="utf-8").splitlines()) < minimum_lines:
        ERRORS.append(f"{rel} is unexpectedly incomplete")

proc = subprocess.run(
    [sys.executable, str(ROOT / "scripts/validate_database_design.py")],
    capture_output=True,
    text=True,
)
if proc.returncode:
    ERRORS.append("database design validator failed:\n" + proc.stdout + proc.stderr)

checksums = ROOT / "CHECKSUMS.sha256"
if checksums.exists() and checksums.read_text(encoding="utf-8").strip():
    for line in checksums.read_text(encoding="utf-8").splitlines():
        digest, rel = line.split("  ", 1)
        path = ROOT / rel
        if not path.exists():
            ERRORS.append(f"checksum target missing: {rel}")
            continue
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != digest:
            ERRORS.append(f"checksum mismatch: {rel}")

if ERRORS:
    print("VALIDATION FAILED")
    for item in ERRORS:
        print(f"- {item}")
    raise SystemExit(1)

files = [path for path in ROOT.rglob("*") if path.is_file() and "__pycache__" not in path.parts]
print("VALIDATION PASSED")
print(f"files={len(files)}")
print("database_contract=passed")
print("helm_values=default,staging,production")
print("large_run_example=passed")
