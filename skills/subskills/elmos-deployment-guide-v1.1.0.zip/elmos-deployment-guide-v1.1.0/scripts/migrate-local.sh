#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ELMOS_ENV_FILE:-$ROOT/.env}"
COMPOSE_FILE="$ROOT/deploy/local/docker-compose.yml"

[[ -f "$ENV_FILE" ]] || { echo "missing $ENV_FILE; copy .env.example to .env" >&2; exit 2; }

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

: "${POSTGRES_USER:?POSTGRES_USER is required}"
: "${POSTGRES_DB:?POSTGRES_DB is required}"
: "${FLYWAY_IMAGE:?FLYWAY_IMAGE is required}"

compose=(docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE")

"${compose[@]}" up -d postgres
"${compose[@]}" --profile db-tools run --rm migrate

# Run cross-tenant catalog/data invariants with the local PostgreSQL admin role.
# Production runs this through a dedicated, audited deployment-verifier role.
"${compose[@]}" exec -T postgres \
  psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" \
  < "$ROOT/database/tests/invariants.sql"

echo "Database migrations and invariants completed."
