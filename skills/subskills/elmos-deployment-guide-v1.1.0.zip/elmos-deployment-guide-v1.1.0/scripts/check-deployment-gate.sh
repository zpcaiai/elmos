#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "usage: $0 --environment ENV --release-manifest-sha SHA256" >&2
}

environment=""
manifest_sha=""
while (($#)); do
  case "$1" in
    --environment) environment="${2:-}"; shift 2 ;;
    --release-manifest-sha) manifest_sha="${2:-}"; shift 2 ;;
    *) usage; exit 2 ;;
  esac
done

[[ -n "$environment" && -n "$manifest_sha" ]] || { usage; exit 2; }
[[ "$manifest_sha" =~ ^[a-f0-9]{64}$ ]] || { echo "invalid manifest SHA-256" >&2; exit 2; }
: "${ELMOS_CONTROL_API_BASE_URL:?ELMOS_CONTROL_API_BASE_URL is required}"

headers=(-H 'Accept: application/json')
if [[ -n "${ELMOS_DEPLOYMENT_GATE_TOKEN:-}" ]]; then
  headers+=(-H "Authorization: Bearer ${ELMOS_DEPLOYMENT_GATE_TOKEN}")
fi

url="${ELMOS_CONTROL_API_BASE_URL%/}/api/v1/deployments/latest?environment=${environment}&release_manifest_sha256=${manifest_sha}"
response="$(curl --fail --silent --show-error --max-time 30 "${headers[@]}" "$url")"

ELMOS_GATE_RESPONSE="$response" python3 - "$environment" "$manifest_sha" <<'PY'
import json, os, sys
environment, expected_sha = sys.argv[1:3]
payload = json.loads(os.environ["ELMOS_GATE_RESPONSE"])
errors=[]
if payload.get('environment') != environment:
    errors.append(f"environment mismatch: {payload.get('environment')!r}")
if payload.get('release_manifest_sha256') != expected_sha:
    errors.append('release manifest SHA mismatch')
if payload.get('status') != 'healthy':
    errors.append(f"deployment status is {payload.get('status')!r}")
gate=payload.get('gate') or {}
if gate.get('decision') != 'pass':
    errors.append(f"gate decision is {gate.get('decision')!r}")
if errors:
    print('P05 DEPLOYMENT GATE FAILED', file=sys.stderr)
    for error in errors:
        print(f'- {error}', file=sys.stderr)
    raise SystemExit(1)
print('P05 DEPLOYMENT GATE PASSED')
print(json.dumps({
    'deployment_id': payload.get('id'),
    'gate_id': gate.get('id'),
    'evaluated_at': gate.get('evaluated_at'),
}, ensure_ascii=False))
PY
