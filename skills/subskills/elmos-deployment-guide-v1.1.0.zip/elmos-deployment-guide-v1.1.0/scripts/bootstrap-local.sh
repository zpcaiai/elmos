#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ELMOS_ENV_FILE:-$ROOT/.env}"
COMPOSE_FILE="$ROOT/deploy/local/docker-compose.yml"
MODE="${1:-infra}"

"$ROOT/scripts/preflight.sh"

case "$MODE" in
  infra)
    docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d \
      postgres redis minio minio-init temporal temporal-ui otel-collector prometheus grafana
    ;;
  db)
    "$ROOT/scripts/migrate-local.sh"
    ;;
  app)
    "$ROOT/scripts/migrate-local.sh"
    docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" --profile app up -d --remove-orphans
    ;;
  down)
    docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" --profile app down
    ;;
  reset)
    echo "This deletes all local Elmos data. Set ELMOS_CONFIRM_RESET=yes to continue."
    [[ "${ELMOS_CONFIRM_RESET:-}" == "yes" ]] || exit 2
    docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" --profile app down -v
    ;;
  *)
    echo "usage: $0 {infra|db|app|down|reset}" >&2
    exit 2
    ;;
esac
