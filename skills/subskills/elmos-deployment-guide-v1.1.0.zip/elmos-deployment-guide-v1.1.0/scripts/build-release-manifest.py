#!/usr/bin/env python3
"""Build an immutable Elmos release manifest from per-component digest files."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def find_digest(value: Any) -> str | None:
    if isinstance(value, str) and value.startswith("sha256:") and len(value) == 71:
        return value
    if isinstance(value, dict):
        for key in ("digest", "Digest", "image_digest", "containerimage.digest"):
            if key in value:
                found = find_digest(value[key])
                if found:
                    return found
        for child in value.values():
            found = find_digest(child)
            if found:
                return found
    if isinstance(value, list):
        for child in value:
            found = find_digest(child)
            if found:
                return found
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--git-sha", required=True)
    parser.add_argument("--image-registry", required=True)
    parser.add_argument("--image-tag", required=True)
    parser.add_argument("--database-schema", required=True)
    parser.add_argument("--gate-policy", required=True)
    parser.add_argument("--digests-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    if args.image_tag in {"latest", "stable", "dev-latest"}:
        raise SystemExit("mutable image tag is forbidden")
    if len(args.git_sha) < 12:
        raise SystemExit("git SHA is too short")

    components = []
    for path in sorted(args.digests_dir.glob("*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        digest = find_digest(payload)
        if not digest:
            raise SystemExit(f"no sha256 digest found in {path}")
        name = path.stem
        components.append(
            {
                "name": name,
                "image": f"{args.image_registry}/elmos-{name}",
                "tag": args.image_tag,
                "digest": digest,
            }
        )
    if not components:
        raise SystemExit("no component digest files found")

    manifest = {
        "format": "elmos.release-manifest/v1",
        "git_sha": args.git_sha,
        "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "database_schema": args.database_schema,
        "gate_policy_revision": args.gate_policy,
        "components": components,
        "contracts": {
            "workflow": "1",
            "session_event": "1",
            "evidence": "1",
            "health": "1",
        },
    }
    canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()
    manifest["manifest_sha256"] = hashlib.sha256(canonical).hexdigest()
    args.output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
