#!/usr/bin/env python3
"""Validate /livez, /readyz, /metrics and /version for one Elmos service."""
from __future__ import annotations

import argparse
import json
import urllib.request


def get(url: str) -> tuple[int, bytes, str]:
    with urllib.request.urlopen(url, timeout=10) as response:
        return response.status, response.read(), response.headers.get("content-type", "")


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("base_url")
    p.add_argument("--expected-git-sha")
    p.add_argument("--expected-schema")
    args = p.parse_args()
    base = args.base_url.rstrip("/")

    for path in ("/livez", "/readyz"):
        status, body, _ = get(base + path)
        if status != 200:
            raise SystemExit(f"{path} returned {status}")
        payload = json.loads(body)
        if payload.get("status") not in {"live", "ready", "ok"}:
            raise SystemExit(f"{path} has invalid status payload: {payload}")

    status, body, content_type = get(base + "/metrics")
    if status != 200 or not body.strip():
        raise SystemExit("/metrics is empty or unavailable")
    if "text" not in content_type and "openmetrics" not in content_type:
        raise SystemExit(f"/metrics content-type is unexpected: {content_type}")

    status, body, _ = get(base + "/version")
    payload = json.loads(body)
    for key in ("service", "version", "git_sha", "image_digest", "database", "contracts"):
        if key not in payload:
            raise SystemExit(f"/version missing {key}")
    if args.expected_git_sha and payload["git_sha"] != args.expected_git_sha:
        raise SystemExit("/version git_sha mismatch")
    if args.expected_schema and payload["database"].get("current") != args.expected_schema:
        raise SystemExit("/version database schema mismatch")
    print("SERVICE CONTRACT PASSED")


if __name__ == "__main__":
    main()
