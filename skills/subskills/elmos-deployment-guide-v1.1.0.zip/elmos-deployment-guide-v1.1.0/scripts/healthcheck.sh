#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ELMOS_ENV_FILE:-$ROOT/.env}"
COMPOSE_FILE="$ROOT/deploy/local/docker-compose.yml"

check_http() {
  local name="$1" url="$2"
  if curl -fsS --max-time 5 "$url" >/dev/null; then
    echo "OK   $name $url"
  else
    echo "FAIL $name $url" >&2
    return 1
  fi
}

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" --profile app ps

status=0
check_http "MinIO" "http://127.0.0.1:9000/minio/health/live" || status=1
check_http "Temporal UI" "http://127.0.0.1:8088" || status=1
check_http "Prometheus" "http://127.0.0.1:9090/-/healthy" || status=1
check_http "Grafana" "http://127.0.0.1:3000/api/health" || status=1

for spec in \
  "Control API|http://127.0.0.1:8080" \
  "Runtime Gateway|http://127.0.0.1:8081" \
  "Model Router|http://127.0.0.1:8082"; do
  name="${spec%%|*}"; base_url="${spec#*|}"
  if curl -fsS --max-time 2 "$base_url/livez" >/dev/null 2>&1; then
    if python3 "$ROOT/scripts/validate-service-contract.py" "$base_url"; then
      echo "OK   $name service contract"
    else
      echo "FAIL $name service contract" >&2
      status=1
    fi
  else
    echo "SKIP $name (application profile may not be running)" >&2
  fi
done

if curl -fsS --max-time 2 "http://127.0.0.1:3001" >/dev/null 2>&1; then
  echo "OK   Web http://127.0.0.1:3001"
else
  echo "SKIP Web (application profile may not be running)" >&2
fi

exit "$status"
