#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

python3 scripts/validate_database_design.py
python3 scripts/validate_bundle.py

if [[ -n "${ELMOS_CI_TEST_COMMAND:-}" ]]; then
  bash -lc "$ELMOS_CI_TEST_COMMAND"
  exit 0
fi

ran=0
if [[ -f package.json ]]; then
  if [[ -f pnpm-lock.yaml ]]; then pnpm install --frozen-lockfile && pnpm test; else npm ci && npm test; fi
  ran=1
fi
if [[ -f pyproject.toml ]]; then
  python3 -m pytest
  ran=1
fi
if [[ -f gradlew ]]; then
  ./gradlew test
  ran=1
fi
if [[ -f pom.xml ]]; then
  mvn -B test
  ran=1
fi
if [[ -f go.mod ]]; then
  go test ./...
  ran=1
fi
if [[ -f Cargo.toml ]]; then
  cargo test --workspace
  ran=1
fi

if [[ "$ran" -eq 0 ]]; then
  echo "No Elmos application test entrypoint detected; database/deployment contracts passed." >&2
  echo "Set ELMOS_CI_TEST_COMMAND in the main repository before production use." >&2
fi
