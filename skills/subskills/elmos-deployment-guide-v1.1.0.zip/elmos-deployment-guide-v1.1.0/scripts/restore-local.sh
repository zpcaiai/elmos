#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ELMOS_ENV_FILE:-$ROOT/.env}"
COMPOSE_FILE="$ROOT/deploy/local/docker-compose.yml"
SRC="${1:-}"
[[ -n "$SRC" && -f "$SRC/elmos-postgres.dump" ]] || { echo "usage: $0 <backup-directory>" >&2; exit 2; }
[[ "${ELMOS_CONFIRM_RESTORE:-}" == "yes" ]] || { echo "Set ELMOS_CONFIRM_RESTORE=yes to continue." >&2; exit 2; }

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

(cd "$SRC" && sha256sum -c CHECKSUMS.sha256)

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d postgres minio
cat "$SRC/elmos-postgres.dump" | docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T postgres \
  pg_restore -U "$POSTGRES_USER" -d "$POSTGRES_DB" --clean --if-exists

docker run --rm --network elmos-local_elmos-backend \
  -v "$SRC:/backup:ro" "${MINIO_MC_IMAGE}" sh -ec \
  "mc alias set local http://minio:9000 '$MINIO_ROOT_USER' '$MINIO_ROOT_PASSWORD' && \
   mc mirror /backup/artifacts local/$S3_BUCKET_ARTIFACTS && \
   mc mirror /backup/evidence local/$S3_BUCKET_EVIDENCE"

echo "Restore completed. Run scripts/healthcheck.sh and application reconciliation checks."
