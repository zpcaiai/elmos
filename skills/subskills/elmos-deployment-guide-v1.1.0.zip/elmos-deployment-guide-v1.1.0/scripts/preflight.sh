#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ELMOS_ENV_FILE:-$ROOT/.env}"
COMPOSE_FILE="$ROOT/deploy/local/docker-compose.yml"

fail() { echo "ERROR: $*" >&2; exit 1; }
warn() { echo "WARN:  $*" >&2; }
ok()   { echo "OK:    $*"; }

command -v docker >/dev/null 2>&1 || fail "docker is required"
docker compose version >/dev/null 2>&1 || fail "Docker Compose v2 is required"
[[ -f "$ENV_FILE" ]] || fail "missing $ENV_FILE; copy .env.example to .env"
[[ -f "$COMPOSE_FILE" ]] || fail "missing compose file"

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

for var in POSTGRES_PASSWORD MINIO_ROOT_PASSWORD DATABASE_URL TEMPORAL_ADDRESS S3_BUCKET_ARTIFACTS S3_BUCKET_EVIDENCE FLYWAY_IMAGE; do
  [[ -n "${!var:-}" ]] || fail "required variable $var is empty"
done

free_kb=$(df -Pk "$ROOT" | awk 'NR==2 {print $4}')
if [[ "${free_kb:-0}" -lt 20971520 ]]; then
  warn "less than 20 GiB free disk; repository builds may fail"
else
  ok "disk space looks usable"
fi

if grep -Eq '=.*:latest([[:space:]]|$)' "$ENV_FILE"; then
  warn "one or more local infrastructure images use :latest; acceptable for a demo only; pin digests before production"
fi

case "$(uname -s)" in
  Darwin)
    warn "macOS detected: local Docker is suitable for control-plane development, not full Linux sandbox or multi-tenant production"
    ;;
  Linux)
    ok "Linux host detected"
    ;;
  *) warn "untested host OS: $(uname -s)" ;;
esac

python3 "$ROOT/scripts/validate_database_design.py" >/dev/null
ok "database design contract is valid"

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" config >/dev/null
ok "compose configuration is valid"

echo "Preflight completed."
