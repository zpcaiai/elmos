{{- define "elmos.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "elmos.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "elmos.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "elmos.labels" -}}
app.kubernetes.io/name: {{ include "elmos.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "elmos.serviceAccountName" -}}
{{- if .Values.global.serviceAccountName -}}
{{- .Values.global.serviceAccountName -}}
{{- else if .Values.serviceAccount.create -}}
{{- include "elmos.fullname" . -}}
{{- else -}}
default
{{- end -}}
{{- end -}}
