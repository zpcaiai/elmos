#!/usr/bin/env python3
"""Thin P05 deployment-gate client.

The Control API owns health collection, Evidence persistence and the authoritative
ops.complete_deployment_with_gate() transaction. This client supplies the exact
Helm/release identity and fails the Kubernetes Job unless the returned decision
is pass and deployment status is healthy.
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
import urllib.error
import urllib.request


def required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise SystemExit(f"missing required environment variable: {name}")
    return value


def post_json(url: str, payload: dict[str, object], token: str | None) -> dict[str, object]:
    body = json.dumps(payload, separators=(",", ":")).encode()
    headers = {"content-type": "application/json", "accept": "application/json"}
    if token:
        headers["authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(request, timeout=60) as response:
        return json.loads(response.read())


def main() -> None:
    base_url = required("ELMOS_CONTROL_API_BASE_URL").rstrip("/")
    payload: dict[str, object] = {
        "environment": required("ELMOS_DEPLOYMENT_ENVIRONMENT"),
        "helm_release_name": required("ELMOS_HELM_RELEASE_NAME"),
        "helm_release_revision": int(required("ELMOS_HELM_RELEASE_REVISION")),
        "namespace": required("ELMOS_NAMESPACE"),
        "expected_image_tag": required("ELMOS_EXPECTED_IMAGE_TAG"),
        "release_manifest_sha256": required("ELMOS_RELEASE_MANIFEST_SHA256"),
        "required_schema_version": required("ELMOS_REQUIRED_SCHEMA_VERSION"),
        "gate_policy_revision": required("ELMOS_DEPLOYMENT_GATE_POLICY_REVISION"),
    }
    if not re.fullmatch(r"[0-9a-f]{64}", str(payload["release_manifest_sha256"])):
        raise SystemExit("ELMOS_RELEASE_MANIFEST_SHA256 must be 64 lowercase hex characters")

    token = os.getenv("ELMOS_DEPLOYMENT_GATE_TOKEN")
    url = base_url + "/api/v1/deployment-gates/verify-and-complete"
    deadline = time.monotonic() + int(os.getenv("ELMOS_DEPLOYMENT_GATE_TIMEOUT_SECONDS", "1500"))
    delay = 5.0
    last_error = ""

    while time.monotonic() < deadline:
        try:
            result = post_json(url, payload, token)
            state = str(result.get("status", ""))
            decision = str((result.get("gate") or {}).get("decision", ""))
            if state == "healthy" and decision == "pass":
                print(json.dumps(result, ensure_ascii=False))
                return
            if state in {"failed", "rolled_back", "cancelled"} or decision in {"fail", "blocked", "error"}:
                print(json.dumps(result, ensure_ascii=False), file=sys.stderr)
                raise SystemExit(1)
            last_error = f"deployment={state!r} gate={decision!r}"
        except urllib.error.HTTPError as exc:
            body = exc.read().decode(errors="replace")
            if 400 <= exc.code < 500 and exc.code not in {408, 409, 425, 429}:
                raise SystemExit(f"non-retryable gate error {exc.code}: {body}")
            last_error = f"HTTP {exc.code}: {body[:500]}"
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            last_error = str(exc)
        time.sleep(delay)
        delay = min(delay * 1.5, 30.0)

    raise SystemExit(f"deployment gate timed out: {last_error}")


if __name__ == "__main__":
    main()
