# Elmos Deployment Gate Image

这是一个最小、无第三方 Python 依赖的 P05 Deployment Gate 客户端。它不会自行伪造 Gate，而是将精确 Release/Helm/Schema 信息提交给 Control API，由 Control API：

1. 创建/定位 `ops.deployment`；
2. 收集服务健康和 `/version`；
3. 保存 `ops.service_health_snapshot` 和 `ops.deployment_check`；
4. 生成 deployment Evidence；
5. 写入 `ops.deployment_gate`；
6. 调用 `ops.complete_deployment_with_gate()`。

Gate 非 pass 或 Deployment 非 healthy 时，容器以非零退出。
