# Elmos 系统完整部署指南

## 1. 部署目标与原则

Elmos 的逻辑架构是 7+1，但物理部署不应从第一天拆成八个独立微服务。推荐先形成以下稳定进程边界：

1. **Web/Admin**：用户界面、任务视图、证据与成本展示。
2. **Control API（P00）**：Tenant、Project、Job、Workflow、Policy、Quota、Billing、Release。
3. **Scheduler/Orchestrator（P04）**：任务 DAG、重对账、并发、重试、租约与人审门。
4. **Runtime Gateway（P01）**：Session、Tool、Permission、Sandbox、Harness Adapter、SSE。
5. **Model Router（P06）**：硬约束、Provider 路由、成本、隐私、fallback、usage。
6. **Analyzer Worker（P02）**：仓库扫描、AST/LSP、Repository Graph、Semantic IR。
7. **Transform Worker（P03）**：项目生成、规则执行、代码发射、迁移资产。
8. **Verifier Worker（P05）**：编译、合同、差分、E2E、性能、安全、Evidence Gate。
9. **Learning Worker（P07，可选离线）**：只消费授权且 verified 的证据，不能影响当前任务完成裁决。

商业生产环境中，Worker 应尽量由 Worker Controller 创建**每 Run 独立的容器、Kubernetes Job、Kata/gVisor Pod 或微 VM**，而不是让不可信代码长期运行在共享 Worker 进程中。

### 不可破坏的不变量

- 只有 P05 Gate 能将 Job 置为 `completed`。
- Postgres 是控制状态与元数据的权威来源；Redis 不是事实来源。
- 大型代码、日志、Trace、媒体和 Evidence 存对象存储，数据库只存 hash、URI、ACL 和 revision。
- 长期 Secret 不注入 Agent；由 Secret Broker/host-side tool 使用短期凭据。
- 所有 Run 固定 `policy_revision`、`source_revision`、`workflow_revision` 和 `route_revision`。
- 任何无沙箱、跨租户、证据篡改或 Gate 绕过必须 fail closed。

---

## 2. 推荐生产拓扑

```text
Internet / Enterprise IdP
        |
   WAF / Load Balancer / Ingress
        |
  +-----+--------------------------+
  | Web/Admin                      |
  | Control API (P00)              |
  | Scheduler/Orchestrator (P04)   |   Control Plane Cluster
  | Runtime Gateway (P01)          |
  | Model Router (P06)             |
  +-----+--------------------------+
        | mTLS / private network
        |
  +-----+--------------------------+
  | Worker Controller              |
  | Analyzer Run Pods (P02)        |
  | Transform Run Pods (P03)       |   Execution Plane / Worker Clusters
  | Verifier Run Pods (P05)        |
  | Browser / Build / OS runners   |
  +-----+--------------------------+
        |
  Postgres / Temporal / Redis / Object Store / Secret Manager / OTel
```

对于机密企业客户，推荐让 Worker 位于客户 VPC，控制面仅接收：

- Job 元数据和状态；
- 内容寻址的 Evidence 摘要；
- 脱敏后的 usage、成本与健康指标；
- 经客户策略允许的 Artifact。

源码、完整 Prompt、构建中间文件和长期凭据不离开客户 VPC。

---

## 3. 基础设施组件

| 组件 | 责任 | 生产建议 |
|---|---|---|
| Postgres | Tenant/Project/Job/Policy、Session 元数据、Ledger、Outbox、审计 | 托管多可用区；PITR；独立只读副本。 |
| Temporal | 长任务、重试、定时器、暂停恢复、Workflow 状态 | 托管或官方支持的 HA 部署；不要把业务真相只放 Temporal。 |
| Redis | 限流、短缓存、瞬态协调 | Cluster/Sentinel；允许丢失后重建。 |
| S3/MinIO | Artifact、Evidence、Trace、媒体、代码包 | 版本控制；Evidence Bucket 开启 Object Lock/WORM。 |
| OIDC IdP | 用户、组织、SSO、MFA | Keycloak/企业 IdP/云 IAM，Control API 只信任签发者。 |
| Secret Manager | Provider、GitHub、云、数据库凭据 | Vault/KMS/云 Secret Manager；短期令牌和自动轮换。 |
| OTel Backend | Logs/Metrics/Traces | OTel Collector + 托管或自建后端。 |
| OCI Registry | Elmos 服务与 Worker 镜像 | 私有仓库、签名、SBOM、漏洞扫描和 immutable tag。 |

### 为什么同时使用 Postgres 与 Temporal

- Postgres 保存可审计的领域事实、revision、成本、Evidence 索引和幂等结算。
- Temporal 保存运行中的 durable control flow、timer、retry 和 signal。
- Workflow 每次状态推进都通过领域 API 事务更新 Postgres；Temporal 只是执行协调器，不是唯一事实来源。

---

## 4. 目录与镜像合同

推荐 Monorepo：

```text
apps/
  web/
  control-api/
  scheduler/
  runtime-gateway/
  model-router/
workers/
  analyzer/
  transformer/
  verifier/
  learning/
packages/
  contracts/
  domain/
  adapters/
  observability/
deploy/
  helm/
  local/
  environments/
migrations/
```

镜像命名：

```text
<registry>/elmos-web:<git-sha>
<registry>/elmos-control-api:<git-sha>
<registry>/elmos-scheduler:<git-sha>
<registry>/elmos-runtime-gateway:<git-sha>
<registry>/elmos-model-router:<git-sha>
<registry>/elmos-worker-analyzer:<git-sha>
<registry>/elmos-worker-transformer:<git-sha>
<registry>/elmos-worker-verifier:<git-sha>
<registry>/elmos-worker-learning:<git-sha>
<registry>/elmos-migrate:<git-sha>
```

生产环境禁止 `latest`。Chart 的 `appVersion` 只用于显示，真正部署必须使用不可变 tag 或 digest。

---

## 5. 核心配置

复制模板：

```bash
cp .env.example .env
```

配置分四类：

### 5.1 非敏感运行配置

- `ELMOS_ENV`
- `ELMOS_PUBLIC_BASE_URL`
- `ELMOS_LOG_LEVEL`
- `ELMOS_WORKSPACE_ROOT`
- `ELMOS_DEFAULT_SANDBOX_MODE`
- `ELMOS_DEFAULT_DATA_CLASSIFICATION`
- `ELMOS_MAX_CONCURRENT_RUNS`
- `ELMOS_MAX_CONCURRENT_RUNS_PER_TENANT`
- `ELMOS_OTEL_SERVICE_NAMESPACE`

放在 ConfigMap 或版本化配置服务中。

### 5.2 基础设施地址

- `DATABASE_URL`
- `REDIS_URL`
- `TEMPORAL_ADDRESS`
- `TEMPORAL_NAMESPACE`
- `S3_ENDPOINT`
- `S3_REGION`
- `S3_BUCKET_ARTIFACTS`
- `S3_BUCKET_EVIDENCE`
- `OTEL_EXPORTER_OTLP_ENDPOINT`

生产环境建议使用服务发现和 Secret 引用，不把完整凭据写入 Helm values。

### 5.3 身份与 Secret

- `OIDC_ISSUER_URL`
- `OIDC_CLIENT_ID`
- `OIDC_AUDIENCE`
- `S3_ACCESS_KEY_ID` / `S3_SECRET_ACCESS_KEY`
- Provider API keys
- GitHub App、GitLab、Jira、Linear 等 Tracker 凭据
- 数据库密码

必须通过 External Secrets/CSI/Vault Agent 等注入。Worker 不应继承不相关 Secret。

### 5.4 策略快照

运行前编译并冻结：

- Workflow Contract
- Permission Policy
- Model Routing Policy
- Completion Gate Policy
- Data/Retention Policy
- Feature Flag Snapshot

Run 内不得隐式读取已经变化的全局配置。

---

## 6. 本地开发部署

### 6.1 适用范围

适用于 API 联调、UI 开发、数据库迁移、事件流和低风险 Worker 调试。**不代表生产级沙箱或租户隔离**。

MacBook Air M3 可运行控制面和普通 Linux 容器，但以下场景应放到 Linux/专用 Runner：

- Landlock/bubblewrap 等 Linux 文件沙箱；
- 高并发构建、压力测试；
- Docker-in-Docker 或嵌套容器；
- 大型 Java/C++/Rust 全仓库转换；
- 多租户不可信代码。

Swift/iOS/Xcode 验证则应使用专用 macOS Runner；Windows 桌面/.NET Framework 场景使用 Windows Runner。

### 6.2 预检

```bash
./scripts/preflight.sh
```

检查内容：Docker/Compose、磁盘、端口、环境文件、镜像是否使用 `latest`、macOS 沙箱限制和必要变量。

### 6.3 启动基础设施

```bash
./scripts/bootstrap-local.sh infra
```

等价命令：

```bash
docker compose --env-file .env \
  -f deploy/local/docker-compose.yml \
  up -d postgres redis minio minio-init temporal temporal-ui \
        otel-collector prometheus grafana
```

默认入口：

| 服务 | 地址 |
|---|---|
| MinIO Console | `http://127.0.0.1:9001` |
| Temporal UI | `http://127.0.0.1:8088` |
| Prometheus | `http://127.0.0.1:9090` |
| Grafana | `http://127.0.0.1:3000` |

### 6.4 数据库迁移

本包已提供 Flyway Migration、PostgreSQL 不变量测试和本地执行脚本：

```bash
./scripts/bootstrap-local.sh db
# 等价：
./scripts/migrate-local.sh
```

该流程会：

1. 启动 PostgreSQL；
2. 顺序执行 `database/migrations/V*.sql`；
3. 校验 migration checksum；
4. 执行 `database/tests/invariants.sql`；
5. 失败时阻止应用启动。

生产 Migration 必须单实例、可审计、超时有界，使用数据库 advisory lock/Flyway history 防止并发迁移。

### 6.5 启动应用

```bash
./scripts/bootstrap-local.sh app
```

应用 Profile 包含 Control API、Scheduler、Runtime Gateway、Model Router、Web 和三个 Pilot Worker。

### 6.6 健康检查

```bash
./scripts/healthcheck.sh
```

每个 Elmos 服务应实现：

- `GET /livez`：进程存活；不访问外部依赖。
- `GET /readyz`：依赖和初始化可用；失败时从负载均衡摘除。
- `GET /metrics`：Prometheus/OTel 指标。
- `GET /version`：版本、commit、contract version、schema version。

---

## 7. 单机 Pilot 部署

### 7.1 最低建议

- Linux x86_64 或 arm64 服务器；
- 16 vCPU、64 GB RAM、500 GB NVMe 起步；
- 独立对象存储或至少 RAID/云盘；
- TLS、每日备份、受控公网出口；
- 不承诺强多租户隔离。

### 7.2 变化点

在本地 Compose 基础上：

1. 将 Postgres 数据目录放独立磁盘并启用备份。
2. MinIO 至少使用独立磁盘；Evidence Bucket 开启版本控制。
3. Nginx/Traefik/Caddy 提供 TLS 和请求大小限制。
4. 应用容器以非 root 用户运行。
5. Worker 使用独立 Docker network、CPU/内存/PID 限额。
6. 通过 egress proxy 控制 Agent 外网访问。
7. 禁止将 Docker Socket 直接挂给普通 Agent。
8. 限制 Pilot 为内部/单客户场景；商业多租户转 Kubernetes。

---

## 8. Kubernetes Staging 部署

### 8.1 前提

- Kubernetes 集群；
- Ingress Controller；
- StorageClass；
- 外部 Postgres、Temporal、Redis、S3；
- OIDC；
- Secret Manager/External Secrets；
- OTel Collector 或 OTLP Endpoint；
- 私有 OCI Registry。

### 8.2 创建 Namespace 与 Secret

开发/测试可使用：

```bash
kubectl create namespace elmos
kubectl -n elmos create secret generic elmos-runtime-secrets \
  --from-env-file=.env
```

生产禁止把整个 `.env` 作为一个长期 Secret；应按数据库、对象存储、OIDC、Provider、Tracker 拆分，并通过外部 Secret 系统同步。

### 8.3 安装 Chart

```bash
helm upgrade --install elmos ./deploy/helm/elmos \
  --namespace elmos --create-namespace \
  -f deploy/environments/staging.values.yaml \
  --set global.imageTag="$(git rev-parse --short HEAD)" \
  --atomic --timeout 15m
```

### 8.4 迁移

Chart 的 `migrate-job.yaml` 使用 Helm pre-upgrade/pre-install hook。生产发布流程必须：

1. 先执行兼容性检查；
2. 备份或确认 PITR；
3. 运行 expand-only migration；
4. 部署新读写兼容版本；
5. 验证；
6. 后续版本再 contract/删除旧列。

### 8.5 验证

```bash
kubectl -n elmos get pods,svc,ingress,hpa,pdb
kubectl -n elmos rollout status deploy/elmos-control-api --timeout=5m
kubectl -n elmos rollout status deploy/elmos-scheduler --timeout=5m
kubectl -n elmos logs deploy/elmos-control-api --tail=100
```

运行 Smoke Job：

- OIDC 登录；
- 创建 Project；
- 提交只读 Repository Analysis Job；
- 验证 P02 Artifact；
- 验证 P05 Gate 在缺少证据时拒绝 `completed`；
- 取消 Job 并确认 Worker 终止；
- 重启 Scheduler 并确认 Run 可恢复。

---

## 9. 商业生产部署

### 9.1 多可用区

- Control API、Runtime Gateway、Model Router：每个至少 3 副本，跨可用区反亲和。
- Scheduler：至少 2–3 副本，使用数据库/Temporal 的 leader/shard lease；单个 shard 只能有一个调度权威。
- Worker Controller：至少 2 副本；Run Pod 使用稳定 idempotency key。
- Postgres：多 AZ + PITR + 只读副本。
- Object Store：跨 AZ；Evidence Bucket 开启 WORM/对象锁。
- Redis：HA，但应用必须能够在 Redis 丢失后恢复。

### 9.2 控制面与执行面分离

- Control Plane 只运行受信服务，不编译客户代码。
- Execution Plane 按风险和 OS 划分独立 Node Pool/Cluster。
- Worker 通过 mTLS 和短期 Run Token 连接 Control Plane。
- Worker 默认 outbound-only；客户 VPC 模式不要求控制面入站访问客户网络。

### 9.3 Worker Pool

| Pool | 典型能力 | 隔离建议 |
|---|---|---|
| `linux-analysis` | AST、LSP、依赖扫描 | 普通非特权 Pod；只读源码。 |
| `linux-transform` | 代码生成、格式化、build | workspace-write；Kata/gVisor。 |
| `linux-verify` | 测试、差分、压力、安全 | 更高资源；独立 egress；Kata/微 VM。 |
| `browser` | Playwright/UI/截图/视频 | 独立 Browser Pod；无客户 Secret。 |
| `gpu` | 本地模型、视觉验证 | GPU Node Pool；严格配额。 |
| `windows` | C#/.NET/Windows 构建 | Windows 节点或外部 Runner。 |
| `macos` | Xcode/Swift/iOS | 外部 Mac Runner；不放标准 K8s Linux 集群。 |

### 9.4 自动扩缩容

- API 按 CPU、请求延迟和 in-flight 请求扩容。
- Worker Controller 按队列深度和可调度 Run 扩容。
- Run Pod 由任务调度产生，不直接依赖 HPA。
- 为每个 Tenant、Project、Worker Pool 设置并发、CPU 时、Token 和成本配额。
- 缩容前必须确认没有持有 Workspace Lease 或未结算副作用。

---

## 10. 数据库、事件与幂等

### 10.1 13 个商业业务 Schema

| Schema | 权威职责 |
|---|---|
| `core` | Tenant、Account、Project、Repository、Job、Revision、3 个账号并发槽 |
| `exec` | Run、Stage、Task DAG、Attempt、Lease、Session、Event、Workpad、Checkpoint |
| `artifact` | CAS Object、Artifact、Manifest、Staging、Archive |
| `analysis` | File、Module、Symbol、Dependency、Runtime Surface、Graph/IR、Capability |
| `generation` | Requirement Graph、Archetype、Architecture、Generation Plan、Generated File |
| `transform` | Transformation Plan/Unit、Rule Application、Target Revision、Patch Set |
| `verify` | Coverage、Test/Differential、Semantic Gap、Evidence、P05 Gate、Repair |
| `metering` | Model/Tool/Resource Usage、Budget、Cost、Revenue、ETA |
| `cache` | Cache Entry、Access、Invalidation 与节省量 |
| `integration` | Outbox/Inbox、External Side-effect、Compensation、Reconciliation |
| `learning` | 授权案例、Repair Trace、Rule Candidate/Release、Benchmark |
| `ops` | Release、Component、Deployment、Migration、Health、Deployment Gate |
| `audit` | append-only 安全与运营审计 |

PostgreSQL 是当前状态、关键事件、检查点、P05 和财务的权威；Temporal 是 durable control flow；大正文进入 CAS。完整设计见 `docs/DATABASE-DESIGN-LARGE-REPOSITORY-RUNS.md`。

### 10.2 Outbox/Inbox

每次领域状态更新与 Outbox 同一事务提交：

```text
BEGIN
  UPDATE job SET state='running', revision=revision+1 ...
  INSERT INTO outbox(event_id, aggregate_id, event_type, payload, ...)
COMMIT
```

消费者以 `event_id` 幂等；失败重试不会重复创建 Run、PR、支付、部署或删除动作。

### 10.3 Workspace Lease

每个 Workspace Lease 包含：

- `tenant_id/project_id/job_id/run_id`
- `source_revision`
- `worker_id`
- `lease_revision`
- `expires_at`
- `workspace_uri`
- `sandbox_enforcement`

Lease 超时只能触发重对账，不能直接假设旧 Worker 已停止；副作用结算后才允许接管。

---

## 11. Secret、权限与沙箱

生产默认：

```text
read-only
  -> workspace-write（代码生成/测试）
  -> network/db/deploy/delete 单独审批
  -> danger-full-access 默认禁止
```

执行前策略：

```text
platform hard deny
> regulation/organization
> tenant
> project
> agent role
> session temporary grant
```

Worker 只拿短期 Run Token。GitHub、云、数据库和模型长期 Key 由 host-side adapter 读取；子进程环境必须删除常见别名，并扫描 stdout/stderr/artifact 是否泄漏 Secret。

更完整要求见 `docs/SECURITY-HARDENING.md`。

---

## 12. 可观测与告警

每个请求和事件必须携带：

- `tenant_id`
- `project_id`
- `job_id`
- `run_id`
- `session_id`
- `task_id`
- `tool_call_id`
- `correlation_id`
- `causation_id`
- `policy_revision`
- `source_revision`

禁止将源码、Prompt、Secret 作为默认日志字段。保留 hash、分类、大小、token、route、时延和必要审计摘要。

P0 告警：

- P05 Gate 被绕过；
- Evidence hash/签名不一致；
- 跨租户访问；
- Secret 泄漏；
- 请求要求强沙箱但实际无沙箱/partial；
- 非授权生产副作用。

详细 Runbook 见 `docs/OBSERVABILITY-RUNBOOK.md`。

---

## 13. 备份与恢复

推荐目标（上线前按合同调整）：

| 数据 | RPO | RTO |
|---|---:|---:|
| Job/Policy/Billing/Audit | ≤ 5 分钟 | ≤ 30 分钟 |
| Session/Run/Workpad | ≤ 1 分钟 | ≤ 30 分钟 |
| Artifact | ≤ 15 分钟 | ≤ 2 小时 |
| Evidence/Certification | 接近 0；不可变复制 | ≤ 2 小时 |
| Redis Cache | 可丢失 | ≤ 15 分钟重建 |

恢复后必须执行一致性检查：Job 状态、Temporal Workflow、Workspace Lease、Artifact hash、Evidence Gate revision 和未结算副作用。

见 `docs/BACKUP-RESTORE.md`。

---

## 14. 升级与回滚

发布顺序：

1. 冻结 Artifact/Contract/Schema 版本；
2. 生成 SBOM、签名和漏洞报告；
3. 备份/PITR 检查；
4. expand migration；
5. 部署兼容的 Control Plane canary；
6. 部署 Worker canary；
7. 执行真实 Benchmark 和恢复演练；
8. 灰度租户；
9. 全量；
10. 后续版本 contract migration。

回滚不能只回滚镜像，还要处理：

- 数据库是否仍兼容旧版本；
- Session/Event format；
- Workflow/Policy revision；
- Worker 镜像与任务是否可恢复；
- 已经发出的副作用是否需要 compensation；
- P07 新规则是否需要 quarantine。

见 `docs/UPGRADE-ROLLBACK.md`。

---

## 15. CI/CD 推荐流水线

```text
lint/typecheck/unit
→ contract/schema compatibility
→ integration with Postgres/Temporal/S3
→ security/SBOM/license/secret scan
→ build OCI images
→ sign + push immutable digest
→ deploy ephemeral environment
→ P02/P03/P05 golden benchmark
→ migration dry-run
→ staging canary
→ manual production approval
→ production canary
→ automated SLO/Gate observation
→ promote or rollback
```

每个 Release Manifest 记录：commit、image digest、contract version、migration version、feature flag snapshot、Benchmark evidence、approver 和 rollback target。

本包提供 `.github/workflows/database-ci.yml` 和 `.github/workflows/elmos-ci-cd.example.yml`。Helm 的 pre-hook 负责 Migration，post-hook 负责收集健康/Evidence 并执行 P05 Deployment Gate；只有 `ops.complete_deployment_with_gate()` 成功才算部署完成。详见 `docs/CI-CD-PIPELINE.md`。

---

## 16. 上线验收

上线前至少证明：

- 一个只读分析 Job 可完成并生成 Repository Graph/Capability Ledger；
- 一个生成/转换 Job 可在隔离 Workspace 内执行；
- 缺失测试时 P05 拒绝 completed；
- Worker 崩溃后可恢复或产生明确 blocked；
- 同一个 idempotency key 不产生重复副作用；
- 跨租户、Secret、路径穿越、网络越权测试均 fail closed；
- 备份恢复和镜像回滚演练通过；
- Dashboard 能从 tenant → job → run → session → tool → evidence 追踪。

完整清单见 `docs/ACCEPTANCE-CHECKLIST.md`。
