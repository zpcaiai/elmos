---
id: 43-compatibility-shim-synthesis
title: 兼容层合成规划
version: 1.0.0
phase: planning
priority: P0
requires:
- 31-legacy-web-semantic-ir
- 41-springboot4-target-architecture
produces:
- compatibility-shim-plan
idempotent: true
resumable: true
---

# 兼容层合成规划

## 目标

当 Spring 无直接等价物时生成最小、可测试、可移除的 compatibility shim，而非改变业务行为或留下隐式 TODO。

本技能属于 **迁移策略与目标架构规划**。阶段目标：根据语义、风险和部署约束选择可验证、可回滚的目标设计及转换波次。

## 输入

- `31-legacy-web-semantic-ir`
- `41-springboot4-target-architecture`

同时读取：

- `job-contract` 与不可变 `policy-snapshot`
- 当前 `repository-snapshot`、Environment/Attachment authority
- 上游 artifact 的 hash、schemaVersion、producerVersion
- 已存在的 unknown、risk、decision 与 checkpoint

## 输出

- `compatibility-shim-plan`

每个输出必须携带：

```yaml
artifactId: <uuid>
schemaVersion: <version>
producerSkill: 43-compatibility-shim-synthesis
producerVersion: 1.0.0
inputHashes: []
policySnapshotHash: <sha256>
environmentId: <environment>
evidenceRefs: []
confidence: 0.0
createdAt: <RFC3339>
```

## 硬性不变量

- 默认 preserve-first；UI/领域重构不得与框架迁移混入同一不可分辨 change set。
- 高风险状态/副作用端点必须支持双运行或更强验证。
- 兼容 shim 必须有明确边界、测试和移除条件。
- 规划必须遵守模块 DAG 与可独立回滚边界。

## 执行步骤

1. 读取 IR、风险、部署限制和用户 policy。
2. 枚举 direct mapping、adapter、isolate、defer 等候选策略。
3. 以行为保持、可验证性、可回滚性和成本评分。
4. 生成 transformation unit DAG 与 gate。
5. 输出允许差异和回滚设计。
6. 适用于 legacy message/forward/form lifecycle/value stack/custom tag 等无直接一对一映射语义。
7. shim 必须小于明确复杂度阈值、无业务逻辑、具备 contract tests。
8. 记录 owner、使用点、性能成本、移除 gate 和 target-native replacement。
9. 不得用 shim 隐藏 critical unknown。

## 证据规则

- 静态代码、配置、构建结果、运行 trace、测试观察和人工决策使用不同 evidence type。
- `confirmed` 至少需要可重放的一手证据；仅靠名称相似或模型常识只能标记 `inferred`。
- 证据冲突必须保留候选、环境与解析理由，不能后写覆盖。
- 任何会影响路由、安全、事务、session 或副作用的推断都进入风险预算。

## 失败与降级

| 情况 | 动作 |
|---|---|
| 输入 schema/hash 不匹配 | 停止本 step，失效下游，不消费陈旧 artifact |
| 权限不足或 authority 不明确 | fail closed，不执行副作用 |
| 源系统不可构建 | 使用运行镜像、字节码、trace 与配置取证；标记基线限制 |
| 动态语义无法确定 | 写入 unknown ledger，并提升验证/双运行要求 |
| 可重试工具故障 | 保持 fencing token，按预算重试 |
| 结果不可逆或无法验证 | 不提交 change set，不推进认证 |

## 验收清单

- [ ] 输出通过对应 JSON/YAML Schema 或结构契约校验。
- [ ] 所有结论均有 evidence/provenance；无法证明者标记为 inferred/unknown。
- [ ] 重复执行在相同输入与 policy 下不产生语义漂移。
- [ ] P0/critical 风险不得被 warning 或 normalizer 静默降级。

## Elmos 集成钩子

- 事件：`skill.started`、`artifact.produced`、`evidence.conflict`、`risk.raised`、`skill.completed`、`skill.failed`
- 指标：`wall_clock_ms`、`cache_hit`、`evidence_coverage`、`unknown_count`、`critical_risk_count`
- Trace 属性：`job_id`、`step_id`、`transformation_unit_id`、`repository_snapshot_id`、`policy_hash`
- Artifact 默认写入对象存储；查询索引与状态写入 PostgreSQL；大对象不得直接塞入任务表
