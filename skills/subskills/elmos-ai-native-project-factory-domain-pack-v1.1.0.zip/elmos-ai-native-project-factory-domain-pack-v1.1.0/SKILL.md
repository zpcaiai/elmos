---
name: elmos-ai-native-project-factory-domain-pack
description: Implement, generate, migrate, evaluate, secure, deploy and continuously certify production AI applications, Agent Skills, Plugins, MCP/A2A systems, RAG, multi-agent workflows and managed-agent targets through the existing Elmos project-generation route.
version: 1.1.0
status: production-implementation-contract
route_owner: domain-pack.project-generation
routable: false
---

# Elmos AI-Native Project Factory Domain Pack

## Objective

Drive real repository changes for AI-native projects while preserving K1 intent, K3 semantics, K7 execution authority and K8 independent completion authority.

## Routing

Use the existing `project-generation` Domain Pack entry. Select component Skills from `catalog/skill-registry.yaml`; do not invoke this package as a new top-level Kernel or route.

## Mandatory procedure

1. Freeze Goal, source, policies, target profiles and release-time versions in a RevisionSet.
2. Compile or import AI-SIR, Skill IR, protocol profiles and acceptance scenarios.
3. Negotiate target capabilities and block critical unsupported semantics.
4. Execute deterministic-first generation in fenced workspaces.
5. Run target-native, negative, recovery, upgrade, security, cost and differential tests.
6. Seal evidence and request independent E0–E5/P05 evaluation.

## Stop and escalate

Stop on missing release pins, unavailable native runner, unresolved critical semantic loss, identity/authority ambiguity, skipped holdout, stale evidence, unresolved side effect, failed rollback or legal decision requiring an authorized reviewer.
