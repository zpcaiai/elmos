#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

python3 "$ROOT/scripts/validate_package.py" --strict

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$ROOT" \
  python3 -B -m unittest discover -s "$ROOT/tests" -v

PYTHONDONTWRITEBYTECODE=1 python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1])
files=list((root/"reference_kernel").rglob("*.py"))+list((root/"scripts").glob("*.py"))+list((root/"tests").glob("*.py"))
for p in files:
    compile(p.read_text(encoding="utf-8"),str(p),"exec")
print(f"PASS: Python syntax for {len(files)} files")
PY

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 "$ROOT/scripts/install.py" --repo "$TMP/repo" --host both --profile core >/tmp/elmos-aipf-install.json
python3 "$ROOT/scripts/uninstall.py" --repo "$TMP/repo" >/tmp/elmos-aipf-uninstall.json
python3 "$ROOT/scripts/install.py" --repo "$TMP/repo2" --host both --profile all --dry-run >/tmp/elmos-aipf-dry-run.json

python3 - /tmp/elmos-aipf-install.json /tmp/elmos-aipf-uninstall.json <<'PY'
import json,sys
i=json.load(open(sys.argv[1])); u=json.load(open(sys.argv[2]))
assert i["status"]=="INSTALLED",i
assert u["status"]=="UNINSTALLED",u
assert not u["preservedModified"],u
print(f"PASS: installer round trip ({i['skills']} core-profile Skills, {i['files']} files)")
PY

echo "PASS: package validation, reference tests, syntax and installer round trip"
