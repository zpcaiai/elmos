#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, shutil, sys, time
from pathlib import Path
import yaml

ROOT=Path(__file__).resolve().parents[1]
SHARED_DIRS=["catalog","contracts","target-adapters","workflows","policies","database","implementation","golden-routes","templates","examples","docs","reference_kernel","native-fixtures"]
SHARED_FILES=["package.yaml","README.md","CHANGELOG.md","REFERENCES.md","SKILL.md"]

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()

def load_registry():
    return yaml.safe_load((ROOT/"catalog/skill-registry.yaml").read_text())["spec"]["skills"]

def select(profile: str, rows):
    by_name={r["name"]:r for r in rows}
    if profile=="all":
        seeds=set(by_name)
    elif profile=="p0":
        seeds={n for n,r in by_name.items() if r["priority"]=="P0"}
    else:
        core_groups={"specification","planning","semantic-ir","import","adapter-sdk","governance"}
        seeds={n for n,r in by_name.items() if r["group"] in core_groups}
        seeds.add("elmos-ai-artifact-provenance-packager")
    changed=True
    while changed:
        changed=False
        for n in list(seeds):
            for dep in by_name[n].get("depends_on",[]):
                if dep not in seeds:
                    seeds.add(dep); changed=True
    return [by_name[n] for n in sorted(seeds)]

def copy_tree(src: Path,dst: Path,installed):
    for p in src.rglob("*"):
        rel=p.relative_to(src)
        out=dst/rel
        if p.is_dir():
            out.mkdir(parents=True,exist_ok=True)
        elif p.is_file():
            out.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(p,out)
            installed.append({"path":str(out),"sha256":sha256(out)})

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo",required=True)
    ap.add_argument("--host",choices=["codex","claude","both"],default="both")
    ap.add_argument("--profile",choices=["core","p0","all"],default="p0")
    ap.add_argument("--dry-run",action="store_true")
    ap.add_argument("--force",action="store_true")
    args=ap.parse_args()
    repo=Path(args.repo).resolve()
    rows=load_registry()
    selected=select(args.profile,rows)
    hosts=[]
    if args.host in {"codex","both"}: hosts.append(("codex",repo/".agents/skills"))
    if args.host in {"claude","both"}: hosts.append(("claude",repo/".claude/skills"))
    shared=repo/".elmos/skillpacks/elmos-ai-native-project-factory"
    conflicts=[]
    for _,base in hosts:
        for r in selected:
            if (base/r["name"]).exists(): conflicts.append(str(base/r["name"]))
    if shared.exists(): conflicts.append(str(shared))
    plan={"repo":str(repo),"profile":args.profile,"host":args.host,"skills":[r["name"] for r in selected],
          "sharedDestination":str(shared),"conflicts":conflicts}
    if args.dry_run:
        print(json.dumps(plan,indent=2)); return 0
    if conflicts and not args.force:
        print(json.dumps({"status":"BLOCKED","reason":"destinations exist; use --force for backed-up replacement","conflicts":conflicts},indent=2))
        return 2
    repo.mkdir(parents=True,exist_ok=True)
    stamp=time.strftime("%Y%m%d-%H%M%S")
    backup_root=repo/".elmos/install-backups"/stamp
    backups=[]
    if args.force:
        for item in conflicts:
            src=Path(item)
            rel=src.relative_to(repo)
            dst=backup_root/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.move(str(src),str(dst))
            backups.append({"destination":str(src),"backup":str(dst)})
    installed=[]
    for host,base in hosts:
        base.mkdir(parents=True,exist_ok=True)
        for r in selected:
            src=ROOT/"agent-skills/runtime"/r["name"]
            dst=base/r["name"]
            copy_tree(src,dst,installed)
    shared.mkdir(parents=True,exist_ok=True)
    for name in SHARED_DIRS:
        copy_tree(ROOT/name,shared/name,installed)
    for name in SHARED_FILES:
        dst=shared/name
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(ROOT/name,dst)
        installed.append({"path":str(dst),"sha256":sha256(dst)})
    receipt={
      "package":"elmos-ai-native-project-factory-domain-pack","version":"1.1.0",
      "installedAt":stamp,"repo":str(repo),"profile":args.profile,"host":args.host,
      "skills":[r["name"] for r in selected],"files":installed,"backups":backups
    }
    receipt_path=shared/"install-receipt.json"
    receipt_path.write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps({"status":"INSTALLED","skills":len(selected),"files":len(installed),"receipt":str(receipt_path)},indent=2))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
