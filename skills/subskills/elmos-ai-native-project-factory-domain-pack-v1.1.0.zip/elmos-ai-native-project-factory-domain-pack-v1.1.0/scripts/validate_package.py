#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re, sys
from collections import defaultdict, deque
from pathlib import Path
try:
 import yaml
except Exception as exc:
 print(f"ERROR: PyYAML required: {exc}",file=sys.stderr);raise SystemExit(2)
ROOT=Path(__file__).resolve().parents[1]
REQUIRED_ROOT=["SKILL.md","README.md","package.yaml","CHANGELOG.md","REFERENCES.md","SKILL_INDEX.md","ADAPTER_INDEX.md"]
SKILL_FILES={"SKILL.md","contract.yaml","implementation.yaml","state-machine.yaml","threat-model.yaml","acceptance.yaml","evidence.yaml"}
ADAPTER_FILES={"adapter.yaml","capability-map.yaml","lowering-contract.yaml","conformance.yaml","version-profile.yaml","security-profile.yaml"}
REQUIRED_NEW_SKILLS={"elmos-agent-skill-ir-compiler","elmos-agent-skill-portability-emitter","elmos-agent-skill-trigger-evaluator","elmos-openai-plugin-project-generator","elmos-mcp-2026-profile-compiler","elmos-mcp-tasks-durable-bridge","elmos-mcp-apps-a2ui-generator","elmos-mcp-enterprise-authorization-controller","elmos-a2a-v1-agent-card-trust-compiler","elmos-agent-workload-delegated-identity-controller","elmos-ai-eval-dataset-governor","elmos-ai-judge-calibration-stochastic-assurance","elmos-ai-provider-behavior-fingerprint-recertifier","elmos-agent-skill-mcp-supply-chain-certifier","elmos-rag-memory-poisoning-verifier","elmos-ai-runaway-loop-economic-dos-guard","elmos-ai-incident-kill-switch-controller","elmos-managed-agent-cloud-deployment-generator","elmos-ai-compliance-profile-compiler"}
REQUIRED_NEW_ADAPTERS={"agent-skills-standard","openai-plugins","mcp-2026-07-28","mcp-apps","a2a-v1","a2ui-v1","agentic-resource-discovery","spiffe-spire","aws-bedrock-agentcore","google-gemini-enterprise-agent-platform","microsoft-foundry-agent-service","databricks-agents","mlflow-genai","arize-phoenix","langsmith","openinference-compatible"}
REQUIRED_ROUTES={"portable-skill-route","mcp-2026-modernization","trusted-cross-organization-agent","continuous-agent-certification","framework-to-managed-runtime"}

def parse_frontmatter(path):
 text=path.read_text(encoding='utf-8')
 if not text.startswith('---\n'):raise ValueError('missing YAML frontmatter')
 parts=text.split('---\n',2)
 if len(parts)<3:raise ValueError('unterminated YAML frontmatter')
 return yaml.safe_load(parts[1]),parts[2]

def cycle(graph):
 indeg={n:0 for n in graph};rev=defaultdict(list)
 for n,deps in graph.items():
  for d in deps:indeg[n]+=1;rev[d].append(n)
 q=deque(n for n,v in indeg.items() if v==0);seen=0
 while q:
  n=q.popleft();seen+=1
  for c in rev[n]:
   indeg[c]-=1
   if indeg[c]==0:q.append(c)
 return seen!=len(graph)

def count_tasks(obj):return sum(len(b.get('tasks',[])) for b in obj['spec']['batches'])
def sha256(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--strict',action='store_true');args=ap.parse_args()
 errors=[];warnings=[];metrics={}
 def fail(msg):errors.append(msg)
 for rel in REQUIRED_ROOT:
  if not (ROOT/rel).is_file():fail(f'missing root file {rel}')
 try:
  manifest=yaml.safe_load((ROOT/'package.yaml').read_text());expected=manifest['spec']['counts']
 except Exception as exc:fail(f'package parse: {exc}');manifest={};expected={}
 required_sections=['## Objective','## Use When','## Non-Goals','## Route and Canonical Ownership','## Inputs','## Dependencies','## Primary Outputs','## Workflow','## Skill-Specific Invariants','## Implementation Assets','## Production Controls','## Required Tests','## Native Acceptance Boundary','## Verification','## Stop and Escalate','## Definition of Done','## Completion Report']
 skill_dirs=sorted(p for p in (ROOT/'agent-skills/runtime').iterdir() if p.is_dir());metrics['skills']=len(skill_dirs);metrics['perSkillFiles']=0;graph={};implementation_signatures=set()
 for d in skill_dirs:
  files={p.name for p in d.iterdir() if p.is_file()};metrics['perSkillFiles']+=len(files)
  if files!=SKILL_FILES:fail(f'{d.name}: inventory {sorted(files)} != {sorted(SKILL_FILES)}')
  try:
   fm,body=parse_frontmatter(d/'SKILL.md')
   if fm.get('name')!=d.name:fail(f'{d.name}: frontmatter name mismatch')
   if fm.get('route_owner')!='domain-pack.project-generation' or fm.get('routable') is not False:fail(f'{d.name}: route ownership/routability invalid')
   if fm.get('status')!='production-implementation-contract':fail(f'{d.name}: status must be production-implementation-contract')
   for sec in required_sections:
    if sec not in body:fail(f'{d.name}: missing section {sec}')
   contract=yaml.safe_load((d/'contract.yaml').read_text());spec=contract['spec'];graph[d.name]=spec.get('dependencies',[])
   if spec.get('failureMode')!='fail-closed':fail(f'{d.name}: failure mode not fail-closed')
   impl=yaml.safe_load((d/'implementation.yaml').read_text())['spec']
   for key in ('domainModel','interfaces','persistence','algorithms','stateMachineFile','threatModelFile','nativeConformance','benchmarks'):
    if key not in impl:fail(f'{d.name}: implementation missing {key}')
   if len(impl.get('domainModel',{}).get('entities',[]))<3:fail(f'{d.name}: insufficient domain entities')
   if len(impl.get('algorithms',[]))<2:fail(f'{d.name}: insufficient algorithms')
   if len(impl.get('nativeConformance',{}).get('scenarios',[]))<3:fail(f'{d.name}: insufficient native scenarios')
   sm=yaml.safe_load((d/'state-machine.yaml').read_text())['spec']
   if not sm.get('states') or not sm.get('transitions') or sm.get('terminalGuard') is None:fail(f'{d.name}: incomplete state machine')
   tm=yaml.safe_load((d/'threat-model.yaml').read_text())['spec']
   if len(tm.get('threats',[]))<3 or not tm.get('trustBoundaries'):fail(f'{d.name}: incomplete threat model')
   acc=yaml.safe_load((d/'acceptance.yaml').read_text())['spec'];kinds={c.get('kind') for c in acc.get('scenarios',[])}
   for needed in ('positive','negative','recovery','upgrade'):
    if needed not in kinds:fail(f'{d.name}: acceptance lacks {needed}')
   ev=yaml.safe_load((d/'evidence.yaml').read_text())['spec']
   if not ev.get('requiredArtifacts') or not ev.get('completionBoundary'):fail(f'{d.name}: incomplete evidence contract')
   signature=json.dumps({'entities':impl.get('domainModel',{}).get('entities'),'algorithms':impl.get('algorithms'),'native':impl.get('nativeConformance',{}).get('scenarios')},sort_keys=True)
   implementation_signatures.add(hashlib.sha256(signature.encode()).hexdigest())
  except Exception as exc:fail(f'{d.name}: {exc}')
 names=set(graph)
 for n,deps in graph.items():
  for dep in deps:
   if dep not in names:fail(f'{n}: missing dependency {dep}')
 if cycle(graph):fail('skill dependency cycle')
 if not REQUIRED_NEW_SKILLS.issubset(names):fail(f'missing required hardening Skills {sorted(REQUIRED_NEW_SKILLS-names)}')
 if len(implementation_signatures)<70:fail(f'implementation specificity too low: {len(implementation_signatures)} unique signatures')
 adapter_dirs=sorted(p for p in (ROOT/'target-adapters').iterdir() if p.is_dir());metrics['adapters']=len(adapter_dirs);metrics['perAdapterFiles']=0
 for d in adapter_dirs:
  files={p.name for p in d.iterdir() if p.is_file()};metrics['perAdapterFiles']+=len(files)
  if files!=ADAPTER_FILES:fail(f'adapter {d.name}: inventory mismatch {sorted(files)}')
  try:
   a=yaml.safe_load((d/'adapter.yaml').read_text());s=a['spec']
   if a['metadata']['name']!=d.name:fail(f'adapter {d.name}: name mismatch')
   if s['authority'].get('failureMode')!='fail-closed' or not s['authority'].get('environmentOwned'):fail(f'adapter {d.name}: authority profile invalid')
   if not s.get('versionPolicy') or not s.get('capabilityNegotiation',{}).get('required'):fail(f'adapter {d.name}: missing version/capability policy')
   vp=yaml.safe_load((d/'version-profile.yaml').read_text())['spec'];sp=yaml.safe_load((d/'security-profile.yaml').read_text())['spec']
   if len(vp.get('requiredPins',[]))<4:fail(f'adapter {d.name}: insufficient release pins')
   if len(sp.get('negativeTests',[]))<4:fail(f'adapter {d.name}: insufficient security negatives')
  except Exception as exc:fail(f'adapter {d.name}: {exc}')
 adapter_names={d.name for d in adapter_dirs}
 if not REQUIRED_NEW_ADAPTERS.issubset(adapter_names):fail(f'missing required adapters {sorted(REQUIRED_NEW_ADAPTERS-adapter_names)}')
 schema_paths=sorted((ROOT/'contracts/schemas').glob('*.schema.json'));example_paths=sorted((ROOT/'contracts/examples').glob('*.example.json'));metrics['schemas']=len(schema_paths);metrics['examples']=len(example_paths)
 try:
  from jsonschema import Draft202012Validator,FormatChecker
  schemas={}
  for p in schema_paths:
   sc=json.loads(p.read_text());Draft202012Validator.check_schema(sc);schemas[p.name.replace('.schema.json','')]=sc
  for p in example_paths:
   key=p.name.replace('.example.json','')
   if key not in schemas:fail(f'no schema for {p.name}');continue
   Draft202012Validator(schemas[key],format_checker=FormatChecker()).validate(json.loads(p.read_text()))
 except ImportError:
  warnings.append('jsonschema unavailable')
  if args.strict:fail('strict mode requires jsonschema')
 except Exception as exc:fail(f'JSON Schema/example validation: {exc}')
 for p in ROOT.rglob('*'):
  if not p.is_file():continue
  try:
   if p.suffix in {'.yaml','.yml'}:yaml.safe_load(p.read_text(encoding='utf-8'))
   elif p.suffix=='.json':json.loads(p.read_text(encoding='utf-8'))
  except Exception as exc:fail(f'parse {p.relative_to(ROOT)}: {exc}')
 metrics['workflows']=len(list((ROOT/'workflows').glob('*.yaml')));metrics['policies']=len(list((ROOT/'policies/rego').glob('*.rego')));metrics['migrations']=len(list((ROOT/'database/postgres').glob('*.sql')));metrics['goldenRoutes']=len(list((ROOT/'golden-routes').glob('*/route.yaml')))
 try:metrics['implementationTasks']=count_tasks(yaml.safe_load((ROOT/'implementation/batches.yaml').read_text()))
 except Exception as exc:fail(f'implementation plan: {exc}')
 test_text='\n'.join(p.read_text() for p in (ROOT/'tests').glob('test_*.py'));metrics['referenceTests']=len(re.findall(r'^\s*def test_',test_text,re.M))
 route_names={p.parent.name for p in (ROOT/'golden-routes').glob('*/route.yaml')}
 if not REQUIRED_ROUTES.issubset(route_names):fail(f'missing hardening Golden Routes {sorted(REQUIRED_ROUTES-route_names)}')
 for p in (ROOT/'golden-routes').glob('*/route.yaml'):
  r=yaml.safe_load(p.read_text());s=r['spec']
  if not s.get('releaseGate',{}).get('exactRevisionSet'):fail(f'{p.parent.name}: route lacks exact RevisionSet gate')
 for p in (ROOT/'policies/rego').glob('*.rego'):
  text=p.read_text()
  if 'package ' not in text or 'import rego.v1' not in text:fail(f'{p.name}: missing Rego v1 package/import')
  case=ROOT/'policies/tests'/f'{p.stem}.cases.json'
  if not case.is_file():fail(f'{p.name}: missing policy case file')
 migration_texts=[]
 for p in (ROOT/'database/postgres').glob('*.sql'):
  text=p.read_text();migration_texts.append(text)
  if not text.lstrip().startswith('BEGIN;') or not text.rstrip().endswith('COMMIT;'):fail(f'{p.name}: migration transaction boundary invalid')
 if sum(t.count('ENABLE ROW LEVEL SECURITY') for t in migration_texts) < 20:fail('RLS coverage is incomplete across migrations')
 if sum(t.count('CREATE POLICY tenant_isolation_') for t in migration_texts) < 20:fail('tenant RLS policy coverage is incomplete')
 if not (ROOT/'contracts/api/ai-factory-hardening.openapi.yaml').is_file() or not (ROOT/'contracts/api/ai-factory-hardening.asyncapi.yaml').is_file():fail('hardening API contracts missing')
 for key,val in metrics.items():
  if expected.get(key)!=val:fail(f'manifest count {key}: expected {expected.get(key)} actual {val}')
 spec=manifest.get('spec',{})
 if spec.get('routableEntryDelta')!=0 or spec.get('preservesRoutableEntryCount')!=16:fail('routable architecture invariant failed')
 if spec.get('parentDomainPack')!='project-generation':fail('wrong parent Domain Pack')
 for p in ROOT.rglob('*'):
  if p.is_symlink():fail(f'symlink forbidden: {p.relative_to(ROOT)}')
 secret_patterns=[re.compile(r'AKIA[0-9A-Z]{16}'),re.compile(r'\bsk-[A-Za-z0-9]{20,}\b'),re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')]
 for p in ROOT.rglob('*'):
  if not p.is_file() or p.suffix in {'.png','.jpg','.zip','.gz'}:continue
  try:text=p.read_text(encoding='utf-8')
  except UnicodeDecodeError:continue
  for pattern in secret_patterns:
   if pattern.search(text):fail(f'possible secret in {p.relative_to(ROOT)}')
 controlled=ROOT/'CONTROLLED_FILES.sha256'
 if controlled.is_file():
  for line in controlled.read_text().splitlines():
   if not line.strip():continue
   digest,rel=line.split('  ',1);path=ROOT/rel
   if not path.is_file() or sha256(path)!=digest:fail(f'controlled hash mismatch {rel}')
 placeholders=sum(p.read_text(encoding='utf-8',errors='ignore').count('RELEASE'+'_TIME_') for p in ROOT.rglob('*') if p.is_file())
 if placeholders:warnings.append(f'{placeholders} release-time placeholders remain by design')
 report={'status':'PASS' if not errors else 'FAIL','metrics':metrics,'implementationSignatures':len(implementation_signatures),'warnings':warnings,'errors':errors}
 print(json.dumps(report,ensure_ascii=False,indent=2));return 0 if not errors else 1
if __name__=='__main__':raise SystemExit(main())
