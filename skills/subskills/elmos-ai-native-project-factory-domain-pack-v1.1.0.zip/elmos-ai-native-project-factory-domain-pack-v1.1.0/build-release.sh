#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
"$ROOT/validate.sh"
python3 "$ROOT/scripts/build_release.py" "$@"
