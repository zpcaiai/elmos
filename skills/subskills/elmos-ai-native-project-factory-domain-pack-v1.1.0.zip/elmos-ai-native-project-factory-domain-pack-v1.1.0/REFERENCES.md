# References

Official/primary design baselines consulted for this release. Exact release-time versions and digests remain mandatory.

- Model Context Protocol specification: https://modelcontextprotocol.io/specification/2026-07-28
- MCP 2026-07-28 release overview: https://blog.modelcontextprotocol.io/posts/2026-07-28/
- Agent Skills specification: https://agentskills.io/specification
- Agent Skills evaluations: https://agentskills.io/skill-evals
- OpenAI Plugins: https://developers.openai.com/plugins
- A2A v1.0 announcement/specification: https://a2a-protocol.org/latest/announcing-1.0/
- A2UI: https://a2ui.org/
- SPIFFE/SPIRE concepts: https://spiffe.io/docs/latest/spire-about/spire-concepts/
- NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
- ISO/IEC 42001: https://www.iso.org/standard/81230.html
- OWASP Agentic Applications: https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/
- OpenTelemetry GenAI semantic conventions: https://opentelemetry.io/docs/specs/semconv/gen-ai/
- MLflow GenAI evaluation and monitoring: https://mlflow.org/docs/latest/genai/eval-monitor/
- Arize Phoenix evaluation: https://arize.com/docs/phoenix/evaluation/overview
- AWS Bedrock AgentCore: https://aws.amazon.com/bedrock/agentcore/
- Google agent platform: https://cloud.google.com/products/agent-platform
- Microsoft Foundry Agent Service: https://learn.microsoft.com/azure/ai-foundry/agents/overview
- Databricks Mosaic AI Agent Framework: https://docs.databricks.com/aws/en/generative-ai/agent-framework/

These sources inform interoperability contracts. They do not certify this package or any generated customer system.
