# Native Conformance Matrix

## Required levels

| Level | Evidence | Maximum claim |
|---|---|---|
| C0 | Schema and package structure | STRUCTURALLY_VALID |
| C1 | Reference implementation and unit tests | REFERENCE_TESTED |
| C2 | Target-native import/build/start/protocol exchange | NATIVE_CONFORMANT for exact pins |
| C3 | Negative authority, recovery, upgrade and rollback | OPERATIONALLY_BOUNDED |
| C4 | Differential, security, performance and resilience | VERIFIED envelope |
| C5 | Repeated holdout, customer acceptance, P05 and K8 | E5/P05 CERTIFIED |

## P0 target minimums

- **Dify:** DSL import/export, mode distinctions, plugin manifests, knowledge pipeline, layout stability, secret redaction, upgrade and rollback.
- **LangGraph:** typed state, Checkpointer, interrupt/resume, subgraphs, parallel state conflicts, loop termination, idempotent side effects and worker recovery.
- **Spring AI:** ChatClient, Advisors, tool calling, MCP client/server, VectorStore/RAG, structured output, Spring Security, Actuator/Micrometer, Testcontainers and Flyway/Liquibase.
- **OpenClaw:** Gateway configuration, Skills/Plugins, channel binding, sandbox, pairing, daemon recovery, backup/restore and permission allowlist.
- **MCP 2026:** stateless reconnect, exact extension negotiation, Tasks durability, Skills/Apps resources, authorization audience/scope and deprecation behavior.
- **A2A v1:** signed Agent Card, protocol negotiation, tenant boundary, delegated scope, task recovery and revocation.

Mock-only execution can satisfy C0/C1 but never C2–C5.
