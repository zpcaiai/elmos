# v1.0.0 → v1.1.0 Consolidated Migration Guide

## Package rule

v1.1.0 is a full replacement package, not an overlay. Install only the consolidated package after taking a receipt-backed backup of the prior installation. It preserves the existing `project-generation` route owner and keeps the v3 routable-entry count at 16.

## Structural changes

| Surface | v1.0.0 | v1.1.0 |
|---|---:|---:|
| Component Skills | 75 | 112 |
| Files per Skill | 5 | 7 |
| Adapters | 68 | 84 |
| Files per Adapter | 4 | 6 |
| Schemas/examples | 20/20 | 50/50 |
| Workflows | 12 | 22 |
| Policies | 9 | 18 |
| Migrations | 3 | 6 |
| Golden Routes | 5 | 10 |
| Implementation tasks | 120 | 220 |

## Upgrade procedure

1. Freeze the Elmos repository and existing package receipt.
2. Run `scripts/install.py --dry-run` and review conflicts.
3. Install with `--force` only when receipt-backed replacement and restoration are desired.
4. Apply database migrations 004–006 after 001–003 and after validating tenant RLS in a disposable PostgreSQL 17 database.
5. Register the enlarged Skill and Adapter catalogs.
6. Keep new capabilities disabled until their exact native conformance and policy suites pass.
7. Re-run all affected Golden Routes; v1.0.0 evidence does not automatically certify new v1.1.0 behavior.
8. Preserve rollback artifacts until K8 independently accepts the new certified envelope.

## Compatibility boundary

Existing Skill names and target Adapter directories are retained. Their contracts are deepened, so consumers that assume an exact five-file Skill or four-file Adapter inventory must be upgraded. Status changes from `production-contract` to `production-implementation-contract`; this is a stronger implementation specification, not an automatic production-completion claim.
