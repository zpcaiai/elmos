# Threat Model Catalog

The per-Skill threat models roll up into the following commercial security campaigns.

## Package and protocol supply chain

Publisher impersonation, typosquatting, hidden scripts, dependency confusion, unsigned updates, manifest/behavior mismatch, undeclared network or filesystem behavior, schema poisoning and revoked packages.

## Identity and delegated authority

Agent-card spoofing, workload identity theft, token replay, wrong audience, scope expansion, confused deputy, approval replay, stale consent and cross-tenant delegation.

## RAG, memory and content

Indirect prompt injection, retrieval injection, cross-tenant vector pollution, ACL metadata tampering, citation laundering, stale override, memory poisoning and incomplete deletion propagation.

## Durable runtime and economics

Stale workers, ghost completion, duplicate side effects, cancellation races, recursive delegation, agent ping-pong, retry storms, context expansion, provider fallback cascades and budget reset attacks.

## Evaluation and certification

Holdout contamination, label tampering, LLM-judge self-preference, metric gaming, silent provider drift, stale evidence reuse, status inflation and certificate binding failure.

## Incident response

Kill-switch bypass, partial containment, evidence destruction, credential persistence, unresolved side effects and unsafe automatic restart.
