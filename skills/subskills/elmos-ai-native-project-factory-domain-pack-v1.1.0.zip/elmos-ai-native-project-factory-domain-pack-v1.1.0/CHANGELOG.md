# Changelog

## 1.1.0 — 2026-08-28

- Consolidated the complete v1.0.0 package into one hardening release.
- Increased component Skills from 75 to 112 and Adapters from 68 to 84 without adding a routable entry.
- Added state-machine and threat-model contracts to every Skill.
- Added version and security profiles to every Adapter.
- Added portable Skills, OpenAI Plugins, MCP 2026, A2A v1, Agent UI, identity, evaluation, drift, security, governance and managed-cloud capabilities.
- Added five Golden Routes, 30 schemas, 10 workflows, 9 policies, 3 migrations, reference semantics and strict hardening validation.

## 1.0.0 — 2026-08-28

- Initial AI-Native Project Factory production-contract package.
