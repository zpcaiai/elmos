"""Executable reference semantics for selected v1.1 contracts.

These modules validate contract behavior only; they are not the production control plane.
"""
from .capability import FeatureRequirement, TargetProfile, NegotiationResult, negotiate
from .trace import compare_traces, validate_trace
from .certifier import ProofResult, CertificationInput, CertificationDecision, certify
from .skill_ir import validate_skill_ir, permission_expansions, portability_decision
from .trigger_eval import TriggerObservation, TriggerMetrics, evaluate_trigger, trigger_gate
from .mcp_tasks import McpTaskBridge, TaskState
from .judge_calibration import Calibration, calibrate, judge_use_decision
from .fingerprint import compare_fingerprints, recertification_decision
from .runaway_guard import BudgetLimit, RunawayGuard
from .schema_evolution import backward_compatibility, evolution_decision
from .rag_security import RetrievalCandidate, authorize_candidates, deletion_reconciled
from .multi_agent import validate_topology, dependency_cycle
from .supply_chain import PackageTrustInput, trust_decision
from .incident import IncidentController
from .compliance import Control, profile_decision
