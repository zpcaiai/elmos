---
name: elmos-ai-cross-framework-differential-validator
description: Compare source and target or multiple generated targets by typed observations,
  partial-order trace constraints, state invariants, side effects, grounding and tolerances.
version: 1.1.0
status: production-implementation-contract
priority: P0
risk: critical
route_owner: domain-pack.project-generation
routable: false
---

# Elmos AI Cross Framework Differential Validator

## Objective

Compare source and target or multiple generated targets by typed observations, partial-order trace constraints, state invariants, side effects, grounding and tolerances.

This Skill is a **commercial production implementation contract and executable reference boundary**, not a claim that a customer deployment has already passed E5. It extends the existing Elmos v3 `project-generation` Domain Pack and MUST NOT become an independent owner of intent, semantic, execution or completion truth.

## Use When

Use this capability when a Goal, repository, AI project, protocol, runtime, governance profile, evaluation program or Golden Route requires the behavior described above.

## Non-Goals

- Do not create shadow copies of canonical K1–K8 objects.
- Do not treat generated text, an LLM judgment, a scaffold command or mock-only test as production proof.
- Do not silently drop unsupported semantics, authority requirements, evidence or migration work.
- Do not invent release digests, credentials, legal approval, regulatory applicability or customer acceptance.

## Route and Canonical Ownership

- **Routable owner:** `domain-pack.project-generation`
- **Component routable:** `false`
- **Kernel authorities used:** K6, K8
- K1 owns Goal/Specification; K2/K3 own repository and semantic facts; K7 owns execution authority and durable state; K6/K8 own proof and completion.
- This Skill may emit commands and immutable artifacts; it may not self-certify.

## Inputs

- Exact `GoalContract`, `RevisionSet`, `RequirementGraph` and acceptance scenarios.
- Applicable Repository Evidence, AI-SIR, target/protocol profiles and unsupported-feature ledger.
- Current `EnvironmentAuthority`, tenant context, budget, data classification and approval policy.
- Proof obligations, verifier requirements and dependency artifacts.

## Dependencies

- `elmos-ai-normalized-agent-trace-recorder`

## Primary Outputs

- `differential-results.json`
- `mismatch-clusters.json`
- `equivalence-coverage.json`
- `counterexamples/`

Every output carries tenant/project/goal/revision identifiers, schema version, producer and tool digest, content hash, provenance, timestamps, status and evidence references.

## Workflow

1. Validate exact revision, scope, authority, dependencies, policy, budget and evidence freshness.
2. Compile a deterministic plan and explicit proof obligations; classify unsupported or conditional behavior.
3. Execute in an isolated, fenced and resumable environment using idempotent commands.
4. Produce immutable artifacts and a normalized execution trace.
5. Run Skill-specific native, negative, security, recovery and benchmark suites.
6. Feed counterexamples into bounded repair; otherwise seal evidence for independent K8 evaluation.

## Skill-Specific Invariants

1. AiCrossFrameworkDifferentialValidator artifacts bind the exact RevisionSet and producer digest.
2. AiCrossFrameworkDifferentialValidator never converts UNKNOWN or UNSUPPORTED into PASS.
3. All outputs (differential-results.json, mismatch-clusters.json, equivalence-coverage.json) are content-addressed and provenance-linked.
4. A retry cannot duplicate an externally visible side effect.

## Implementation Assets

The implementation MUST provide and keep synchronized:

- `contract.yaml` — typed ownership, inputs, outputs, commands, events and failure policy;
- `implementation.yaml` — domain model, APIs, persistence, algorithms, delivery phases and benchmarks;
- `state-machine.yaml` — guarded transitions, idempotency, leases, fencing and terminal semantics;
- `threat-model.yaml` — assets, actors, boundaries, threats, controls and incident response;
- `acceptance.yaml` — executable positive, negative and recovery scenarios;
- `evidence.yaml` — evidence classes, bindings, freshness, independence and forbidden claims.

Algorithms and mechanisms:
- verifier portfolio routing
- counterexample minimization
- translation validation
- AiCrossFrameworkDifferentialValidator deterministic plan and bounded repair

## Production Controls

1. **Fail closed:** critical UNKNOWN, UNSUPPORTED, stale evidence, unresolved authority or unsettled side effect blocks the affected claim.
2. **Deterministic first:** schemas, compilers, target-native APIs and reproducible transformations precede bounded generation.
3. **Environment-owned authority:** no thread-global, ambient filesystem, network or secret authority.
4. **Durable execution:** checkpoint, lease, fencing, idempotency, outbox, pause/resume/cancel and reconciliation are mandatory for long tasks.
5. **Exact-version discipline:** release claims bind source, target, model, provider, protocol, toolchain, policy and verifier versions/digests.
6. **Independent evidence:** generator/repair agents cannot authoritatively certify their own work.
7. **Multi-tenant isolation:** database, object, cache, trace, vector and memory namespaces enforce tenant boundaries.
8. **Operational containment:** finite budgets, circuit breakers, revocation and incident kill switches are wired before production.

## Required Tests

Native and domain tests:
- positive proof
- counterexample
- unknown verifier
- AiCrossFrameworkDifferentialValidator representative end-to-end fixture

Security campaigns:
- non-deterministic output false mismatch
- normalizer hiding semantic difference
- oracle coupling
- side-effect order loss

Also execute applicable schema, unit, contract, integration, E2E, differential, property, metamorphic, mutation, fuzz, performance, resilience, backup/restore, upgrade, rollback and evidence-integrity tests.

## Native Acceptance Boundary

A result is not native-conformant until the exact external target/protocol/provider has imported, built, started or executed the generated artifact as applicable. Mock-only execution remains `BOUNDED` or `NOT_RUN`. Version drift invalidates prior conformance until re-evaluated.

## Verification

Each proof result records exact subject revision, typed claim, proof status, verifier and digest, inputs and assumptions, resource bounds, commands/exit codes, artifacts, trace IDs and evidence hashes. `BOUNDED`, `RUNTIME_MONITORED`, `WAIVED`, `UNKNOWN` and `UNSUPPORTED` are never displayed as `PROVED`.

## Stop and Escalate

Stop and emit a blocked result for unresolved authority or fencing, critical unsupported semantics, missing independent verifier, unknown source behavior or ownership, exceeded repair/budget limits, security/privacy/residency/license failure, unsettled side effects, failed native conformance or absent authorized acceptance.

## Definition of Done

- All declared artifacts exist, validate and bind the exact RevisionSet.
- The Skill-specific state machine reached a policy-valid terminal state.
- Native, negative, recovery, security and benchmark obligations have explicit statuses.
- Counterexamples are closed or preserved as blocking evidence.
- Evidence is immutable, fresh and independently consumable by K8.
- Production claims additionally pass applicable E0–E5 and P05 gates.

## Completion Report

Report exact revisions and digests; passed/failed/blocked/unknown/unsupported/waived obligations; machine wall-clock, token, compute, storage and network cost; benchmark metrics (critical_obligation_closure, counterexample_yield, verification_seconds, machine_wall_clock_seconds, cost_per_successful_run); approvals, side effects, rollback state, residual risks; and Evidence Bundle plus Completion Certificate or Blocked Result references.
