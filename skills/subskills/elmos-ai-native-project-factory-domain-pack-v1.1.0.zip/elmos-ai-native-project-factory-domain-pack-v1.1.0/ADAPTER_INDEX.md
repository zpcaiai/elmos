# Adapter Index

**Version:** 1.1.0  
**Adapters:** 84  

Every adapter has six contracts: descriptor, capability map, lowering contract, conformance suite, version profile and security profile.

## agent-framework

### `microsoft-agent-framework-dotnet`

- Ecosystem: Microsoft Agent Framework
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: csharp
- Modes: generate, import, migrate-autogen, migrate-semantic-kernel, conformance
- Release rule: exact release-time pin plus native conformance

### `microsoft-agent-framework-python`

- Ecosystem: Microsoft Agent Framework
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, migrate-autogen, migrate-semantic-kernel, conformance
- Release rule: exact release-time pin plus native conformance

## agent-platform

### `agno`

- Ecosystem: Agno
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## agent-protocol

### `a2a-v1`

- Ecosystem: Agent2Agent Protocol
- Maturity: `P0`
- Protocol/family: `1.0`
- Languages: json, protobuf, typescript, python, java, go
- Modes: agent-card, client, server, task, extensions, conformance
- Release rule: exact release-time pin plus native conformance

## agent-sdk

### `google-adk-go`

- Ecosystem: Google ADK
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: go
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `google-adk-java`

- Ecosystem: Google ADK
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: java, kotlin
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `google-adk-python`

- Ecosystem: Google ADK
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `google-adk-typescript`

- Ecosystem: Google ADK
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: typescript
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `langchain-python`

- Ecosystem: LangChain
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: import, generate, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `langchain-typescript`

- Ecosystem: LangChain
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: typescript
- Modes: import, generate, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `openai-agents-python`

- Ecosystem: OpenAI Agents SDK
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `openai-agents-typescript`

- Ecosystem: OpenAI Agents SDK
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: typescript
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `qwen-agent`

- Ecosystem: Qwen-Agent
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## agent-ui-protocol

### `a2ui-v1`

- Ecosystem: A2UI
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: jsonl, typescript, dart
- Modes: generate, stream, render, action-bind, conformance
- Release rule: exact release-time pin plus native conformance

### `mcp-apps`

- Ecosystem: MCP Apps
- Maturity: `P0`
- Protocol/family: `2026-07-28-extension`
- Languages: json, typescript
- Modes: generate-ui, render, action-bind, conformance
- Release rule: exact release-time pin plus native conformance

## agent-workflow-framework

### `mastra`

- Ecosystem: Mastra
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: typescript
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## ai-ui-sdk

### `vercel-ai-sdk`

- Ecosystem: Vercel AI SDK
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: typescript, javascript
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## assistant-gateway

### `openclaw`

- Ecosystem: OpenClaw
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: json, typescript, markdown
- Modes: generate-assistant, generate-skill, generate-plugin, generate-channel, conformance
- Release rule: exact release-time pin plus native conformance

## automation-platform

### `n8n-ai`

- Ecosystem: n8n AI
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: json, typescript
- Modes: import, export, generate, conformance
- Release rule: exact release-time pin plus native conformance

## coding-agent

### `aider`

- Ecosystem: Aider
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: yaml, markdown
- Modes: generate-convention, generate-command-profile, conformance
- Release rule: exact release-time pin plus native conformance

### `claude-code`

- Ecosystem: Claude Code
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: markdown, json, yaml
- Modes: generate-skill, generate-hook, generate-command, conformance
- Release rule: exact release-time pin plus native conformance

### `cline-roo`

- Ecosystem: Cline / Roo Code
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: markdown, json
- Modes: generate-rules, generate-mode, generate-mcp-config, conformance
- Release rule: exact release-time pin plus native conformance

### `codex`

- Ecosystem: OpenAI Codex
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: markdown, json, yaml
- Modes: generate-skill, generate-plugin, generate-harness-policy, conformance
- Release rule: exact release-time pin plus native conformance

### `continue`

- Ecosystem: Continue
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: yaml, json, markdown
- Modes: generate-assistant, generate-rule, conformance
- Release rule: exact release-time pin plus native conformance

### `gemini-cli`

- Ecosystem: Gemini CLI
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: markdown, json, yaml
- Modes: generate-extension, generate-command, conformance
- Release rule: exact release-time pin plus native conformance

### `opencode`

- Ecosystem: OpenCode
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: typescript, json, markdown
- Modes: generate-agent, generate-plugin, generate-command, conformance
- Release rule: exact release-time pin plus native conformance

## coding-agent-platform

### `openhands`

- Ecosystem: OpenHands
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, typescript, yaml
- Modes: generate-agent, generate-workflow, import, conformance
- Release rule: exact release-time pin plus native conformance

## coding-harness

### `deepseek-harness`

- Ecosystem: DeepSeek Harness
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: typescript, yaml
- Modes: import, generate-plugin, generate-bundle, generate-profile, conformance
- Release rule: exact release-time pin plus native conformance

### `openharness`

- Ecosystem: OpenHarness
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: python, yaml
- Modes: import, generate-extension, generate-policy, conformance
- Release rule: exact release-time pin plus native conformance

### `pi`

- Ecosystem: Pi coding agent
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: typescript, markdown
- Modes: generate-package, generate-extension, generate-skill, embed-rpc, conformance
- Release rule: exact release-time pin plus native conformance

## coding-orchestrator

### `symphony`

- Ecosystem: OpenAI Symphony
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: markdown, yaml, typescript, python
- Modes: generate-workflow, generate-work-item-adapter, conformance
- Release rule: exact release-time pin plus native conformance

## data-agent-framework

### `llamaindex-python`

- Ecosystem: LlamaIndex
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `llamaindex-typescript`

- Ecosystem: LlamaIndex
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: typescript
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## discovery-protocol

### `agentic-resource-discovery`

- Ecosystem: Agentic Resource Discovery
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: json
- Modes: publish, discover, verify, pin
- Release rule: exact release-time pin plus native conformance

## enterprise-ai-framework

### `langchain4j`

- Ecosystem: LangChain4j
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: java
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `spring-ai-java`

- Ecosystem: Spring AI
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: java
- Modes: import, generate, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## evaluation-observability

### `arize-phoenix`

- Ecosystem: Arize Phoenix
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, typescript
- Modes: trace, dataset, experiment, code-eval, llm-judge
- Release rule: exact release-time pin plus native conformance

### `langsmith`

- Ecosystem: LangSmith
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, typescript
- Modes: trace, dataset, experiment, evaluate, monitor
- Release rule: exact release-time pin plus native conformance

### `mlflow-genai`

- Ecosystem: MLflow GenAI
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: trace, dataset, experiment, judge, monitor
- Release rule: exact release-time pin plus native conformance

## graph-rag

### `microsoft-graphrag`

- Ecosystem: Microsoft GraphRAG
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `neo4j-graphrag`

- Ecosystem: Neo4j GraphRAG
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## graph-runtime

### `langgraph-python`

- Ecosystem: LangGraph
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: import, generate, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `langgraph-typescript`

- Ecosystem: LangGraph
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: typescript
- Modes: import, generate, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## interaction-protocol

### `ag-ui`

- Ecosystem: AG-UI
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: json, typescript, python
- Modes: client, server, bridge, conformance
- Release rule: exact release-time pin plus native conformance

## lightweight-agent-sdk

### `smolagents`

- Ecosystem: smolagents
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

### `strands-agents`

- Ecosystem: Strands Agents
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, typescript
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## local-model-serving

### `ollama`

- Ecosystem: Ollama
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: yaml, json
- Modes: deploy, client, conformance
- Release rule: exact release-time pin plus native conformance

## managed-agent-platform

### `aws-bedrock-agentcore`

- Ecosystem: Amazon Bedrock AgentCore
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, typescript, container
- Modes: deploy, memory, gateway, identity, browser, code-interpreter, observe
- Release rule: exact release-time pin plus native conformance

### `databricks-agents`

- Ecosystem: Databricks Agents
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: build, register, deploy, evaluate, monitor, govern
- Release rule: exact release-time pin plus native conformance

### `google-gemini-enterprise-agent-platform`

- Ecosystem: Gemini Enterprise Agent Platform
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, container
- Modes: deploy, a2a, mcp, gateway, govern, observe
- Release rule: exact release-time pin plus native conformance

### `microsoft-foundry-agent-service`

- Ecosystem: Microsoft Foundry Agent Service
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, dotnet, container
- Modes: deploy, host, identity, tools, observe, evaluate
- Release rule: exact release-time pin plus native conformance

## migration-source

### `autogen-compat`

- Ecosystem: Microsoft AutoGen
- Maturity: `compatibility`
- Protocol/family: `release-time-pin`
- Languages: python, csharp
- Modes: import, migrate, differential
- Release rule: exact release-time pin plus native conformance

### `flowise-compat`

- Ecosystem: Flowise
- Maturity: `compatibility`
- Protocol/family: `release-time-pin`
- Languages: json, typescript
- Modes: import, migrate, differential
- Release rule: exact release-time pin plus native conformance

### `semantic-kernel-compat`

- Ecosystem: Microsoft Semantic Kernel
- Maturity: `compatibility`
- Protocol/family: `release-time-pin`
- Languages: csharp, python, java
- Modes: import, migrate, differential
- Release rule: exact release-time pin plus native conformance

### `swarm-compat`

- Ecosystem: OpenAI Swarm
- Maturity: `compatibility`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: import, migrate, differential
- Release rule: exact release-time pin plus native conformance

## model-gateway

### `litellm`

- Ecosystem: LiteLLM
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, yaml
- Modes: generate-config, proxy, routing, conformance
- Release rule: exact release-time pin plus native conformance

### `openrouter`

- Ecosystem: OpenRouter
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: typescript, python, go
- Modes: generate-client, routing, analytics, conformance
- Release rule: exact release-time pin plus native conformance

## model-serving

### `sglang`

- Ecosystem: SGLang
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, yaml
- Modes: deploy, client, benchmark, conformance
- Release rule: exact release-time pin plus native conformance

### `vllm`

- Ecosystem: vLLM
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, yaml
- Modes: deploy, client, benchmark, conformance
- Release rule: exact release-time pin plus native conformance

## multi-agent-framework

### `camel-ai`

- Ecosystem: CAMEL-AI
- Maturity: `P2`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, conformance
- Release rule: exact release-time pin plus native conformance

### `crewai`

- Ecosystem: CrewAI
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## observability

### `opentelemetry`

- Ecosystem: OpenTelemetry
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: multiple
- Modes: instrument, export, validate, conformance
- Release rule: exact release-time pin plus native conformance

## pipeline-framework

### `haystack-python`

- Ecosystem: Haystack
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## plugin-platform

### `openai-plugins`

- Ecosystem: OpenAI Plugins
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: markdown, typescript, python
- Modes: generate-skill, generate-mcp, generate-ui, submit, conformance
- Release rule: exact release-time pin plus native conformance

## programming-optimization-framework

### `dspy`

- Ecosystem: DSPy
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, optimize, conformance
- Release rule: exact release-time pin plus native conformance

## protocol

### `a2a`

- Ecosystem: Agent2Agent Protocol
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: json, python, typescript, java, go
- Modes: client, server, gateway, conformance
- Release rule: exact release-time pin plus native conformance

### `mcp`

- Ecosystem: Model Context Protocol
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: json, typescript, python, java
- Modes: client, server, gateway, conformance
- Release rule: exact release-time pin plus native conformance

### `mcp-2026-07-28`

- Ecosystem: Model Context Protocol
- Maturity: `P0`
- Protocol/family: `2026-07-28`
- Languages: json, typescript, python, java
- Modes: client, server, gateway, tasks, skills, apps, conformance
- Release rule: exact release-time pin plus native conformance

## skill-format

### `agent-skills-standard`

- Ecosystem: Agent Skills open format
- Maturity: `P0`
- Protocol/family: `current-open-spec`
- Languages: markdown, yaml
- Modes: import, emit, validate, evaluate
- Release rule: exact release-time pin plus native conformance

## solution-architecture

### `universal-rag`

- Ecosystem: Elmos Universal RAG
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: python, typescript, java
- Modes: generate, migrate, verify
- Release rule: exact release-time pin plus native conformance

## telemetry-profile

### `openinference-compatible`

- Ecosystem: OpenInference
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, typescript
- Modes: instrument, trace, export, conformance
- Release rule: exact release-time pin plus native conformance

## tool-protocol

### `openapi-tools`

- Ecosystem: OpenAPI tool adapters
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: yaml, json, multiple
- Modes: import, generate-client, generate-tool, conformance
- Release rule: exact release-time pin plus native conformance

## tool-runtime

### `browser-computer-use`

- Ecosystem: Browser / computer-use adapters
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: json, python, typescript
- Modes: generate-tool, sandbox, conformance
- Release rule: exact release-time pin plus native conformance

## typed-agent-sdk

### `pydanticai-python`

- Ecosystem: PydanticAI
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: python
- Modes: generate, import, upgrade, conformance
- Release rule: exact release-time pin plus native conformance

## vector-store

### `milvus`

- Ecosystem: Milvus
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: go, cpp, multiple
- Modes: provision, generate-client, migrate, conformance
- Release rule: exact release-time pin plus native conformance

### `pgvector`

- Ecosystem: pgvector
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: sql, multiple
- Modes: provision, generate-client, migrate, conformance
- Release rule: exact release-time pin plus native conformance

### `qdrant`

- Ecosystem: Qdrant
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: rust, multiple
- Modes: provision, generate-client, migrate, conformance
- Release rule: exact release-time pin plus native conformance

### `weaviate`

- Ecosystem: Weaviate
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: go, multiple
- Modes: provision, generate-client, migrate, conformance
- Release rule: exact release-time pin plus native conformance

## visual-agent-platform

### `coze-studio`

- Ecosystem: Coze Studio
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: json, typescript, go
- Modes: import, export, generate, conformance
- Release rule: exact release-time pin plus native conformance

### `langflow`

- Ecosystem: Langflow
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: json, python
- Modes: import, export, generate, conformance
- Release rule: exact release-time pin plus native conformance

## visual-platform

### `dify`

- Ecosystem: Dify
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: yaml, python
- Modes: import, export, generate-app, generate-plugin, conformance
- Release rule: exact release-time pin plus native conformance

## visual-rag-platform

### `fastgpt`

- Ecosystem: FastGPT
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: json, typescript
- Modes: import, export, generate, conformance
- Release rule: exact release-time pin plus native conformance

### `ragflow`

- Ecosystem: RAGFlow
- Maturity: `P1`
- Protocol/family: `release-time-pin`
- Languages: python, typescript, yaml
- Modes: import, export, generate, conformance
- Release rule: exact release-time pin plus native conformance

## workload-identity

### `spiffe-spire`

- Ecosystem: SPIFFE/SPIRE
- Maturity: `P0`
- Protocol/family: `release-time-pin`
- Languages: x509, jwt, yaml
- Modes: attest, issue-svid, rotate, federate, conformance
- Release rule: exact release-time pin plus native conformance
