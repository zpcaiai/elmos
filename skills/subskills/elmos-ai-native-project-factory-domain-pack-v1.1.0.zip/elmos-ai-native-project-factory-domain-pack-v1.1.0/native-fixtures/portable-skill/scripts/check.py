print("fixture-ok")
