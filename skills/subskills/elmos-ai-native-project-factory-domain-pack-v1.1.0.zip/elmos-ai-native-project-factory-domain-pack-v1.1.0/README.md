# Elmos AI-Native Project Factory Domain Pack v1.1.0

## Result

This single consolidated package upgrades the v1.0.0 AI project factory into a **production implementation contract and executable reference pack**. It preserves all baseline capabilities and adds protocol, identity, portable Skill, evaluation, continuous certification, security, governance and managed-agent deployment depth.

```text
8 canonical K1–K8 authorities
+ existing project-generation Domain Pack route owner
+ 112 non-routable implementation Skills
+ 84 replaceable adapters
+ 0 new routable entry points
```

## What is consolidated

- all 75 v1.0.0 component Skills and 68 adapters;
- 37 hardening Skills and 16 protocol/identity/evaluation/cloud adapters;
- target-specific `implementation.yaml`, state machine, threat model, native acceptance and evidence for every Skill;
- version and security profiles for every Adapter;
- portable Agent Skill and OpenAI Plugin compiler contracts;
- MCP 2026-07-28, A2A v1, A2UI, discovery and delegated identity contracts;
- evaluation dataset, judge calibration, behavior fingerprint, shadow evaluation and recertification;
- Skill/MCP supply chain, RAG/memory poisoning, economic DoS and incident kill switches;
- prompt/schema evolution, multi-agent assurance, AI governance and managed-agent cloud targets;
- ten commercial Golden Routes and a 220-task implementation program.

## Directory

```text
agent-skills/runtime/       112 Skills × 7 contracts
target-adapters/            84 Adapters × 6 contracts
contracts/schemas/          machine-readable domain contracts
contracts/api/              OpenAPI and AsyncAPI
workflows/                  durable workflow contracts
policies/rego/              fail-closed policy modules
database/postgres/          PostgreSQL 17/RLS migrations
golden-routes/              commercial repeatable routes
reference_kernel/           executable bounded reference semantics
native-fixtures/            structural native-test fixtures
implementation/             22 batches / 220 tasks
```

## Installation

```bash
python3 scripts/validate_package.py --strict
python3 scripts/install.py --repo /path/to/elmos --host both --profile p0 --dry-run
python3 scripts/install.py --repo /path/to/elmos --host both --profile p0
```

The installer writes component Skills to `.agents/skills/` and `.claude/skills/`, and shared contracts to `.elmos/skillpacks/elmos-ai-native-project-factory/`.

## Completion boundary

Package validation proves structure, schemas, reference semantics, safe installation and archive integrity. It does **not** prove that external frameworks, protocols, databases, policy engines, cloud services, customer repositories or E5/P05 Golden Routes have executed. Those claims require exact release-time pins, native commands, immutable evidence and an independent K8 decision.
