# Skills Index

**Version:** 1.1.0  
**Component Skills:** 112  
**Route owner:** `domain-pack.project-generation`  
**Routable delta:** `0`

All components are non-routable and delegate canonical authority to K1–K8.

## adapter-sdk

### `elmos-ai-target-adapter-sdk`

Define the only supported extension seam for target detection, capability profiling, lowering, emission, import, conformance, upgrade and evidence capture.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-sir-compiler`
- Native checks: valid adapter, missing capability, drifted adapter, AiTargetAdapterSdk representative end-to-end fixture
- Primary outputs: `adapter-sdk/`, `adapter-contract.schema.json`, `reference-adapter/`, `adapter-conformance-suite/`

## assurance

### `elmos-ai-cross-framework-differential-validator`

Compare source and target or multiple generated targets by typed observations, partial-order trace constraints, state invariants, side effects, grounding and tolerances.

- Priority / risk: `P0` / `critical`
- Kernels: K6, K8
- Dependencies: `elmos-ai-normalized-agent-trace-recorder`
- Native checks: positive proof, counterexample, unknown verifier, AiCrossFrameworkDifferentialValidator representative end-to-end fixture
- Primary outputs: `differential-results.json`, `mismatch-clusters.json`, `equivalence-coverage.json`, `counterexamples/`

### `elmos-ai-generated-project-conformance-validator`

Execute adapter-native import, build, start, schema, tool, state, persistence, API and deployment conformance suites against the exact generated revision.

- Priority / risk: `P0` / `critical`
- Kernels: K6, K8
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: positive proof, counterexample, unknown verifier, AiGeneratedProjectConformanceValidator representative end-to-end fixture
- Primary outputs: `conformance-results.json`, `native-build-evidence/`, `runtime-smoke-evidence/`, `adapter-conformance-certificate.json`

### `elmos-ai-graph-liveness-side-effect-verifier`

Verify graph termination or bounded continuation, deadlock freedom within the declared envelope, serializable checkpoints, retry-safe side effects and compensation coverage.

- Priority / risk: `P0` / `critical`
- Kernels: K6, K8
- Dependencies: `elmos-ai-workflow-state-machine-compiler`
- Native checks: positive proof, counterexample, unknown verifier, AiGraphLivenessSideEffectVerifier representative end-to-end fixture
- Primary outputs: `graph-verification.json`, `liveness-results.json`, `side-effect-safety.json`, `graph-counterexamples/`

### `elmos-ai-normalized-agent-trace-recorder`

Record framework-neutral input, routing, retrieval, model, tool, approval, state, side-effect, evidence and output events with causal and revision binding.

- Priority / risk: `P0` / `critical`
- Kernels: K6, K7
- Dependencies: `elmos-ai-generated-project-conformance-validator`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiNormalizedAgentTraceRecorder representative end-to-end fixture
- Primary outputs: `normalized-traces/`, `trace-schema.json`, `causal-index.json`, `trace-coverage.json`

### `elmos-ai-prompt-tool-security-redteam`

Run prompt-injection, indirect-injection, tool-confusion, authority escalation, data-exfiltration, memory-poisoning, cross-tenant and unsafe-code-execution campaigns.

- Priority / risk: `P0` / `critical`
- Kernels: K6, K7, K8
- Dependencies: `elmos-ai-tool-authority-policy-generator`, `elmos-ai-generated-project-conformance-validator`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiPromptToolSecurityRedteam representative end-to-end fixture
- Primary outputs: `security-redteam-results.json`, `attack-corpus/`, `exploit-traces/`, `security-remediation-plan.json`

### `elmos-ai-rag-retrieval-grounding-certifier`

Certify ingestion correctness, ACL enforcement, retrieval recall/ranking, citation precision, faithfulness, abstention, freshness, deletion and performance.

- Priority / risk: `P0` / `critical`
- Kernels: K6, K8
- Dependencies: `elmos-ai-cross-framework-differential-validator`, `elmos-ai-rag-semantic-compiler`
- Native checks: positive proof, counterexample, unknown verifier, AiRagRetrievalGroundingCertifier representative end-to-end fixture
- Primary outputs: `rag-certification.json`, `retrieval-metrics.json`, `grounding-metrics.json`, `rag-counterexamples/`

### `elmos-ai-supply-chain-performance-resilience-certifier`

Verify SBOM, provenance, dependency policy, image integrity, latency, throughput, resource bounds, load shedding, provider outage, worker loss and disaster recovery.

- Priority / risk: `P0` / `critical`
- Kernels: K6, K8
- Dependencies: `elmos-ai-deployment-pack-generator`, `elmos-ai-generated-project-conformance-validator`
- Native checks: positive proof, counterexample, unknown verifier, AiSupplyChainPerformanceResilienceCertifier representative end-to-end fixture
- Primary outputs: `nonfunctional-certification.json`, `sbom/`, `performance-results/`, `resilience-results/`

## certification

### `elmos-ai-e0-e5-certifier`

Issue an independent bounded completion decision only when the exact RevisionSet, obligations, evidence freshness, side effects and E0–E5 gates satisfy policy.

- Priority / risk: `P0` / `critical`
- Kernels: K8
- Dependencies: `elmos-ai-cross-framework-differential-validator`, `elmos-ai-rag-retrieval-grounding-certifier`, `elmos-ai-graph-liveness-side-effect-verifier`, `elmos-ai-prompt-tool-security-redteam`, `elmos-ai-supply-chain-performance-resilience-certifier`
- Native checks: positive proof, counterexample, unknown verifier, AiE0E5Certifier representative end-to-end fixture
- Primary outputs: `completion-certificate.json`, `certification-report.md`, `gate-decisions.json`, `residual-risk-register.json`

## compatibility

### `elmos-model-response-schema-evolution-controller`

Control backward, forward and full compatibility for model response, tool argument and event schemas with migrations, dual-read and rollback.

- Priority / risk: `P1` / `critical`
- Kernels: K3, K5, K6
- Dependencies: `elmos-structured-output-contract-verifier`, `elmos-ai-compatibility-drift-monitor`
- Native checks: add optional field, remove required field, enum narrowing, rollback during mixed-version traffic
- Primary outputs: `schemas/evolution/`, `schema-compatibility-report.json`, `schema-migration-plan.yaml`

## continuous-certification

### `elmos-ai-online-shadow-eval-controller`

Run privacy-filtered, side-effect-free shadow evaluation, paired comparison, confidence gating, canary promotion and rollback for AI system changes.

- Priority / risk: `P0` / `critical`
- Kernels: K6, K7, K8
- Dependencies: `elmos-ai-eval-dataset-governor`, `elmos-ai-judge-calibration-stochastic-assurance`, `elmos-ai-durable-runtime-integrator`
- Native checks: one-percent shadow, candidate attempts side effect, privacy filter failure, quality pass but cost regression
- Primary outputs: `evals/shadow-runs/`, `shadow-comparison-report.json`, `promotion-decision.json`

### `elmos-ai-provider-behavior-fingerprint-recertifier`

Fingerprint model/provider behavior with probe corpora and invalidate or recertify evidence when aliases, tool calling, schema, safety, latency or cost drift.

- Priority / risk: `P0` / `critical`
- Kernels: K2, K6, K8
- Dependencies: `elmos-ai-eval-dataset-governor`, `elmos-ai-compatibility-drift-monitor`, `elmos-ai-model-contract-compiler`
- Native checks: alias resolves to changed model, tool-call schema drift, latency/cost distribution drift, safety refusal drift
- Primary outputs: `fingerprints/providers/`, `provider-drift-report.json`, `recertification-decision.json`

## control

### `elmos-ai-project-factory-orchestrator`

Compile a business goal or existing AI repository into a governed, resumable, multi-target generation program with explicit proof obligations and release gates.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K4, K7, K8
- Dependencies: `elmos-ai-e0-e5-certifier`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiProjectFactoryOrchestrator representative end-to-end fixture
- Primary outputs: `ai-project-run.yaml`, `target-portfolio.json`, `work-graph.json`, `completion-boundary.json`

### `elmos-ai-revision-set-freezer`

Freeze the exact source, requirements, AI-SIR, target profiles, model/tool policies, adapter digests, templates, data sets and verification configuration used by a generation run.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K7, K8
- Dependencies: `elmos-ai-target-portfolio-planner`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiRevisionSetFreezer representative end-to-end fixture
- Primary outputs: `revision-set.json`, `input-merkle-root.txt`, `toolchain-lock.json`, `freeze-attestation.json`

## deployment

### `elmos-managed-agent-cloud-deployment-generator`

Generate portable deployments for AWS AgentCore, Gemini Enterprise Agent Platform, Microsoft Foundry Agent Service and Databricks Agents with exit plans.

- Priority / risk: `P1` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-deployment-pack-generator`, `elmos-ai-provider-data-residency-controller`, `elmos-ai-compatibility-drift-monitor`
- Native checks: deploy dry-run per cloud profile, identity binding failure, region restriction, export and rollback fixture
- Primary outputs: `deploy/managed-agent-cloud/`, `cloud-capability-delta.json`, `cloud-exit-plan.yaml`

## discovery-governance

### `elmos-agent-registry-resource-discovery-governor`

Discover, verify, policy-filter and pin agents, skills, MCP servers, tools and models across A2A cards, registries and internal catalogs.

- Priority / risk: `P0` / `critical`
- Kernels: K2, K3, K6, K7
- Dependencies: `elmos-a2a-v1-agent-card-trust-compiler`, `elmos-ai-compatibility-drift-monitor`
- Native checks: poisoned registry fixture, stale card invalidation, duplicate identity resolution, offline locked-resource resolution
- Primary outputs: `registries/discovery-index/`, `registry-trust-decisions.json`, `resource-lock.json`

## evaluation

### `elmos-agent-skill-trigger-evaluator`

Evaluate Agent Skill activation precision, recall, conflicts, task-success lift and token/latency overhead using positive, negative and adversarial prompt sets.

- Priority / risk: `P0` / `high`
- Kernels: K4, K6, K7
- Dependencies: `elmos-agent-skill-ir-compiler`, `elmos-ai-normalized-agent-trace-recorder`, `elmos-ai-assurance-contract-compiler`
- Native checks: evaluate should-trigger and should-not-trigger cases, run no-skill control group, detect multi-skill collision
- Primary outputs: `evals/skill-trigger/`, `trigger-confusion-matrix.json`, `skill-ablation-report.json`

### `elmos-ai-eval-dataset-governor`

Govern evaluation datasets across source, consent, PII, lineage, labels, holdout isolation, contamination, difficulty, versioning, expiry and access.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K2, K6, K7
- Dependencies: `elmos-ai-assurance-contract-compiler`, `elmos-ai-artifact-provenance-packager`
- Native checks: duplicate and near-duplicate cases, PII/consent denial, holdout access denial, dataset version rollback
- Primary outputs: `evals/datasets/`, `eval-dataset-manifest.json`, `contamination-report.json`

### `elmos-ai-judge-calibration-stochastic-assurance`

Calibrate LLM judges against human labels and deterministic oracles with uncertainty, agreement, bias, confidence intervals and refusal rules.

- Priority / risk: `P0` / `critical`
- Kernels: K4, K6, K8
- Dependencies: `elmos-ai-eval-dataset-governor`, `elmos-ai-normalized-agent-trace-recorder`
- Native checks: human-aligned benchmark, order and style bias probes, self-preference probe, low-confidence abstention
- Primary outputs: `evals/judges/`, `judge-calibration-report.json`, `judge-use-policy.json`

## evidence

### `elmos-ai-artifact-provenance-packager`

Package source inputs, AI-SIR, target profiles, generated revisions, traces, test results, policies, approvals and limits into a tamper-evident evidence graph.

- Priority / risk: `P0` / `critical`
- Kernels: K6, K7, K8
- Dependencies: `elmos-ai-config-secret-materializer`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiArtifactProvenancePackager representative end-to-end fixture
- Primary outputs: `evidence-bundle/`, `evidence-index.json`, `evidence-graph.json`, `bundle-attestation.json`

## golden-route

### `elmos-ai-golden-route-autogen-sk-to-agent-framework`

Migrate AutoGen or Semantic Kernel agent applications to Microsoft Agent Framework while preserving tools, sessions, workflows, human gates and telemetry contracts.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K2, K3, K4, K5, K6, K7, K8
- Dependencies: `elmos-target-microsoft-agent-framework-generator`, `elmos-ai-source-project-importer`, `elmos-ai-roundtrip-migration-controller`, `elmos-ai-e0-e5-certifier`
- Native checks: three independent repetitions, holdout scenario, rollback and recovery, AiGoldenRouteAutogenSkToAgentFramework representative end-to-end fixture
- Primary outputs: `golden-route/autogen-sk-to-agent-framework/`, `compatibility-map.json`, `migration-evidence.json`, `route-certificate.json`

### `elmos-ai-golden-route-business-requirement-multitarget`

Execute Business Requirement → AI-SIR → Dify prototype + LangGraph production runtime + Spring AI enterprise service + OpenClaw channel gateway.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K2, K3, K4, K5, K6, K7, K8
- Dependencies: `elmos-target-dify-project-generator`, `elmos-target-langgraph-project-generator`, `elmos-target-spring-ai-project-generator`, `elmos-target-openclaw-assistant-generator`, `elmos-ai-e0-e5-certifier`
- Native checks: three independent repetitions, holdout scenario, rollback and recovery, AiGoldenRouteBusinessRequirementMultitarget representative end-to-end fixture
- Primary outputs: `golden-route/business-requirement-multitarget/`, `route-certificate.json`, `customer-acceptance.json`, `benchmark-results.json`

### `elmos-ai-golden-route-dify-to-production-code`

Import a Dify DSL and plugins, recover AI-SIR, generate LangGraph and Spring AI production implementations, and differentially validate supported behavior.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K2, K3, K4, K5, K6, K7, K8
- Dependencies: `elmos-target-dify-project-generator`, `elmos-target-langgraph-project-generator`, `elmos-target-spring-ai-project-generator`, `elmos-ai-roundtrip-migration-controller`, `elmos-ai-e0-e5-certifier`
- Native checks: three independent repetitions, holdout scenario, rollback and recovery, AiGoldenRouteDifyToProductionCode representative end-to-end fixture
- Primary outputs: `golden-route/dify-to-production/`, `roundtrip-report.json`, `cross-target-diff.json`, `route-certificate.json`

### `elmos-ai-golden-route-langchain-to-langgraph`

Modernize an existing LangChain repository to LangGraph with explicit state, persistence, interrupts, durable execution and behavior-differential evidence.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K2, K3, K4, K5, K6, K7, K8
- Dependencies: `elmos-target-langchain-project-generator`, `elmos-target-langgraph-project-generator`, `elmos-ai-roundtrip-migration-controller`, `elmos-ai-e0-e5-certifier`
- Native checks: three independent repetitions, holdout scenario, rollback and recovery, AiGoldenRouteLangchainToLanggraph representative end-to-end fixture
- Primary outputs: `golden-route/langchain-to-langgraph/`, `migration-map.json`, `trace-diff.json`, `route-certificate.json`

### `elmos-ai-golden-route-repository-to-coding-harness`

Analyze a repository and generate repository-specific Pi, Harness, OpenCode/Codex/Claude/Gemini skills, authority policies, workflows and verification gates.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K2, K3, K4, K5, K6, K7, K8
- Dependencies: `elmos-target-pi-package-generator`, `elmos-target-deepseek-harness-generator`, `elmos-target-openharness-generator`, `elmos-target-coding-agent-harness-family-generator`, `elmos-ai-e0-e5-certifier`
- Native checks: three independent repetitions, holdout scenario, rollback and recovery, AiGoldenRouteRepositoryToCodingHarness representative end-to-end fixture
- Primary outputs: `golden-route/repository-to-coding-harness/`, `repository-capability-pack/`, `harness-comparison.json`, `route-certificate.json`

## governance

### `elmos-ai-compliance-profile-compiler`

Compile jurisdiction and organizational AI controls into implementation obligations, evidence requirements, human decisions and unresolved legal questions.

- Priority / risk: `P1` / `critical`
- Kernels: K1, K3, K6, K8
- Dependencies: `elmos-ai-security-governance-compiler`, `elmos-ai-assurance-contract-compiler`
- Native checks: NIST/ISO enterprise profile, EU transparency profile, China labeling profile, conflicting regional requirements
- Primary outputs: `governance/compliance-profiles/`, `control-obligation-map.json`, `legal-decision-ledger.json`

### `elmos-ai-content-provenance-labeling-controller`

Generate visible and machine-readable AI interaction/content labels, provenance metadata, detection tests and regional policy mappings.

- Priority / risk: `P1` / `critical`
- Kernels: K1, K3, K5, K6
- Dependencies: `elmos-ai-compliance-profile-compiler`, `elmos-ai-interaction-channel-compiler`, `elmos-ai-artifact-provenance-packager`
- Native checks: text/image/audio/video fixtures, label stripped by transform, AI interaction disclosure, regional policy variation
- Primary outputs: `governance/content-labeling/`, `content-provenance-manifest.json`, `label-conformance-report.json`

### `elmos-ai-system-model-card-generator`

Generate evidence-backed system and model cards covering intended use, limitations, data, evaluation, safety, operations, ownership and change history.

- Priority / risk: `P1` / `high`
- Kernels: K1, K2, K6, K8
- Dependencies: `elmos-ai-compliance-profile-compiler`, `elmos-ai-artifact-provenance-packager`
- Native checks: engineering and customer card variants, stale metric rejection, missing limitation denial, version update diff
- Primary outputs: `governance/model-cards/`, `system-card.json`, `card-evidence-map.json`

### `elmos-ai-unsupported-feature-ledger`

Record every unsupported, partially represented, emulated, runtime-monitored or waived feature and block silent degradation.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K6, K8
- Dependencies: `elmos-ai-capability-negotiator`
- Native checks: allow, deny, unknown policy, revocation, AiUnsupportedFeatureLedger representative end-to-end fixture
- Primary outputs: `unsupported-feature-ledger.json`, `waiver-requests/`, `fallback-decisions.json`, `certification-impact.json`

### `elmos-human-oversight-consent-contract-compiler`

Compile human oversight, consent, four-eyes approval, expiry, escalation, revocation and approval-to-actual-action binding into executable contracts.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K3, K6, K7
- Dependencies: `elmos-ai-security-governance-compiler`, `elmos-ai-workflow-state-machine-compiler`
- Native checks: parameter changed after approval, approval replay, dual-control same-person denial, timeout and escalation
- Primary outputs: `governance/oversight-contracts/`, `approval-binding-evidence.json`, `oversight-audit.jsonl`

## identity-security

### `elmos-agent-workload-delegated-identity-controller`

Separate human, logical agent, runtime workload and downstream delegated identities using attestation, short-lived credentials and token exchange.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K6, K7
- Dependencies: `elmos-mcp-enterprise-authorization-controller`, `elmos-ai-tool-authority-policy-generator`
- Native checks: attested and unattested workload, credential rotation, delegation scope narrowing, stolen token wrong-workload denial
- Primary outputs: `security/workload-identity/`, `delegation-chain-evidence.json`, `credential-lifecycle-report.json`

### `elmos-mcp-enterprise-authorization-controller`

Generate and enforce MCP enterprise authorization with OAuth 2.1/OIDC, dynamic registration, delegation, resource indicators, token exchange, consent and revocation.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K6, K7
- Dependencies: `elmos-mcp-2026-profile-compiler`, `elmos-ai-tool-authority-policy-generator`, `elmos-ai-security-governance-compiler`
- Native checks: authorization code and client credentials fixtures, wrong-audience denial, revoked consent denial, cross-tenant token isolation
- Primary outputs: `security/mcp-authorization/`, `authorization-decision-log.jsonl`, `consent-ledger.json`

## import

### `elmos-ai-source-project-importer`

Inspect and import existing visual DSLs, agent SDK repositories, RAG systems, harness packages and deployment descriptors into evidence-backed AI-SIR.

- Priority / risk: `P0` / `critical`
- Kernels: K2, K3, K6
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: known framework fixture, mixed framework fixture, opaque dependency, AiSourceProjectImporter representative end-to-end fixture
- Primary outputs: `source-inventory.json`, `recovered-ai-sir.json`, `opaque-boundary-register.json`, `import-confidence.json`

## incident-response

### `elmos-ai-incident-kill-switch-controller`

Provide tenant, agent, tool, provider, skill, prompt and memory kill switches with active-run cancellation, evidence preservation and safe restart gates.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K6, K7, K8
- Dependencies: `elmos-ai-runaway-loop-economic-dos-guard`, `elmos-ai-durable-runtime-integrator`, `elmos-ai-tool-authority-policy-generator`
- Native checks: tenant-only stop, global tool revocation, worker disconnected during kill, memory quarantine and restart
- Primary outputs: `incidents/controls/`, `incident-timeline.jsonl`, `safe-restart-decision.json`

## interaction

### `elmos-mcp-apps-a2ui-generator`

Generate capability-negotiated MCP Apps, AG-UI and A2UI interfaces with progressive rendering, safe actions, accessibility and recoverable UI state.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-mcp-2026-profile-compiler`, `elmos-ai-interaction-channel-compiler`
- Native checks: render same fixture on web/mobile/desktop profiles, CSP/XSS negative suite, resume interrupted multi-step form, accessibility audit
- Primary outputs: `targets/agent-ui/`, `ui-capability-profile.json`, `ui-security-evidence/`

## lifecycle

### `elmos-ai-compatibility-drift-monitor`

Detect target/API/DSL/plugin/runtime/model capability drift, invalidate stale evidence and trigger bounded regeneration or recertification.

- Priority / risk: `P1` / `high`
- Kernels: K2, K3, K6, K8
- Dependencies: `elmos-ai-target-adapter-sdk`, `elmos-ai-unsupported-feature-ledger`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiCompatibilityDriftMonitor representative end-to-end fixture
- Primary outputs: `drift-events.jsonl`, `affected-artifacts.json`, `evidence-invalidation.json`, `upgrade-trigger.json`

### `elmos-ai-generated-project-upgrader`

Upgrade generated projects when target frameworks, adapters, models or platform contracts drift, preserving user-owned changes through source lineage and three-way semantic merge.

- Priority / risk: `P1` / `critical`
- Kernels: K2, K3, K5, K6
- Dependencies: `elmos-ai-compatibility-drift-monitor`, `elmos-ai-project-repository-emitter`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiGeneratedProjectUpgrader representative end-to-end fixture
- Primary outputs: `upgrade-plan.json`, `change-impact.json`, `semantic-merge-result.json`, `recertification-plan.json`

### `elmos-ai-roundtrip-migration-controller`

Control import→AI-SIR→target→re-import round trips and cross-ecosystem migrations while making information loss and manual preservation points explicit.

- Priority / risk: `P1` / `critical`
- Kernels: K3, K5, K6, K8
- Dependencies: `elmos-ai-source-project-importer`, `elmos-ai-cross-framework-differential-validator`
- Native checks: worker crash, duplicate delivery, pause resume cancel, AiRoundtripMigrationController representative end-to-end fixture
- Primary outputs: `roundtrip-plan.json`, `roundtrip-diff.json`, `loss-ledger.json`, `manual-preservation-plan.json`

## multi-agent

### `elmos-multi-agent-budget-scheduler`

Schedule multi-agent fanout, model selection, tools and retries under shared quality, latency, cost, concurrency and fairness budgets.

- Priority / risk: `P1` / `high`
- Kernels: K4, K7
- Dependencies: `elmos-multi-agent-topology-delegation-compiler`, `elmos-ai-runtime-operations-compiler`, `elmos-ai-observability-finops-generator`
- Native checks: high fanout, tenant contention, child retry, cancellation and budget refund
- Primary outputs: `multi-agent/schedules/`, `budget-allocation-ledger.jsonl`, `scheduler-performance.json`

### `elmos-multi-agent-deadlock-consensus-verifier`

Verify multi-agent systems for deadlock, livelock, handoff cycles, consensus safety, conflicting commitments and termination under bounded assumptions.

- Priority / risk: `P1` / `critical`
- Kernels: K3, K6
- Dependencies: `elmos-multi-agent-topology-delegation-compiler`, `elmos-ai-graph-liveness-side-effect-verifier`
- Native checks: mutual wait, handoff loop, split-brain decision, agent crash during consensus
- Primary outputs: `verification/multi-agent/`, `deadlock-counterexamples.json`, `consensus-assurance-report.json`

### `elmos-multi-agent-topology-delegation-compiler`

Compile supervisor, peer, hierarchical and market-style multi-agent topologies with typed delegation, shared state ownership and termination contracts.

- Priority / risk: `P1` / `critical`
- Kernels: K1, K3, K5
- Dependencies: `elmos-ai-agent-contract-compiler`, `elmos-ai-workflow-state-machine-compiler`
- Native checks: supervisor-worker, peer handoff, recursive delegation denial, shared-state ownership conflict
- Primary outputs: `multi-agent/topologies/`, `delegation-contracts.json`, `state-ownership-map.json`

## planning

### `elmos-ai-capability-negotiator`

Resolve required semantics against versioned target capability profiles, producing supported, emulated, conditional, unsupported and blocked decisions with explicit lowering obligations.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K4, K6, K8
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: supported target, bounded target, all-targets-blocked, AiCapabilityNegotiator representative end-to-end fixture
- Primary outputs: `capability-negotiation.json`, `feature-resolution-ledger.json`, `emulation-plan.json`, `blocked-capabilities.json`

### `elmos-ai-solution-archetype-selector`

Select one or more solution archetypes—RAG, agentic RAG, multi-agent workflow, coding harness, personal assistant, data agent, realtime agent or automation—using evidence rather than framework popularity.

- Priority / risk: `P0` / `high`
- Kernels: K1, K4, K8
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: supported target, bounded target, all-targets-blocked, AiSolutionArchetypeSelector representative end-to-end fixture
- Primary outputs: `archetype-candidates.json`, `archetype-decision.json`, `rejected-archetypes.json`, `risk-envelope.json`

### `elmos-ai-target-portfolio-planner`

Choose a target portfolio that separates prototype, production runtime, enterprise service, channels, coding harness and infrastructure targets while minimizing lock-in and unsupported semantics.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K4, K5, K8
- Dependencies: `elmos-ai-solution-archetype-selector`, `elmos-ai-capability-negotiator`
- Native checks: supported target, bounded target, all-targets-blocked, AiTargetPortfolioPlanner representative end-to-end fixture
- Primary outputs: `target-portfolio.json`, `target-role-map.json`, `vendor-lockin-analysis.json`, `migration-exit-plan.json`

## portable-skill

### `elmos-agent-skill-ir-compiler`

Compile repository knowledge, workflows and authority requirements into a host-neutral Agent Skill IR with triggers, instructions, tools, resources, tests, versions and evidence.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K3, K5, K6
- Dependencies: `elmos-ai-sir-compiler`, `elmos-ai-target-adapter-sdk`
- Native checks: parse valid and adversarial SKILL.md fixtures, round-trip Skill IR without resource loss, reject undeclared executable resources
- Primary outputs: `skill-ir/skill.yaml`, `skill-ir/resources.lock.json`, `skill-ir/compatibility-ledger.json`

### `elmos-agent-skill-portability-emitter`

Emit one canonical Agent Skill IR into Agent Skills, Codex, Claude Code, Pi, OpenClaw, Gemini CLI, Continue and OpenCode packages with explicit loss accounting.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-agent-skill-ir-compiler`, `elmos-ai-project-repository-emitter`, `elmos-ai-unsupported-feature-ledger`
- Native checks: load emitted package in every available host harness, compare trigger and output behavior across hosts, verify permission non-expansion
- Primary outputs: `portable-skills/`, `host-delta-ledger.json`, `portability-conformance.json`

## privacy

### `elmos-ai-retention-erasure-verifier`

Verify retention, legal hold, user erasure and deletion propagation across prompts, traces, memory, vector stores, caches, datasets, artifacts and backups.

- Priority / risk: `P1` / `critical`
- Kernels: K2, K6, K7
- Dependencies: `elmos-ai-compliance-profile-compiler`, `elmos-ai-memory-semantic-compiler`, `elmos-rag-acl-freshness-deletion-verifier`
- Native checks: user erasure, legal hold conflict, vector/cache deletion, backup expiry
- Primary outputs: `privacy/retention-erasure/`, `erasure-proof.json`, `retention-exception-ledger.json`

## prompt-engineering

### `elmos-prompt-program-ir-compiler`

Compile prompts into versioned Prompt Program IR containing parameters, roles, tool visibility, examples, output schemas, policies, tests and rollback metadata.

- Priority / risk: `P1` / `critical`
- Kernels: K1, K3, K5, K6
- Dependencies: `elmos-ai-model-contract-compiler`, `elmos-ai-tool-protocol-compiler`, `elmos-ai-assurance-contract-compiler`
- Native checks: parameterized prompt rendering, conflicting instruction detection, tool visibility denial, rollback to prior prompt version
- Primary outputs: `prompt-programs/`, `prompt-ir-index.json`, `prompt-dependency-lock.json`

### `elmos-prompt-registry-experiment-controller`

Manage prompt registry, experiments, variants, traffic allocation, paired evaluation, promotion and rollback with exact model and dataset bindings.

- Priority / risk: `P1` / `high`
- Kernels: K4, K6, K7
- Dependencies: `elmos-prompt-program-ir-compiler`, `elmos-ai-eval-dataset-governor`
- Native checks: A/B prompt experiment, variant authority escalation denial, dataset version drift, automatic rollback
- Primary outputs: `prompt-registry/`, `prompt-experiments/`, `prompt-promotion-decision.json`

## protocol

### `elmos-mcp-2026-profile-compiler`

Compile exact MCP 2026-07-28 core and extension profiles covering stateless transport, Tasks, Skills, Apps, authorization, cache hints and deprecation.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K3, K6, K7
- Dependencies: `elmos-ai-tool-protocol-compiler`, `elmos-ai-target-adapter-sdk`
- Native checks: initialize against exact protocol fixtures, stateless HTTP reconnect, extension negotiation positive and negative cases, deterministic list ordering
- Primary outputs: `protocols/mcp/profile.yaml`, `protocols/mcp/extension-lock.json`, `protocols/mcp/deprecation-ledger.json`

## protocol-identity

### `elmos-a2a-v1-agent-card-trust-compiler`

Compile, sign, verify and govern A2A v1 Agent Cards, interfaces, protocol versions, tenancy, capabilities, extensions, expiry and revocation.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K3, K6, K7
- Dependencies: `elmos-ai-mcp-a2a-gateway-generator`, `elmos-ai-security-governance-compiler`
- Native checks: signed and unsigned card fixtures, tampered card rejection, multi-version interface negotiation, multi-tenant task routing
- Primary outputs: `protocols/a2a/agent-card.json`, `protocols/a2a/trust-bundle.json`, `protocols/a2a/verification-report.json`

## protocol-runtime

### `elmos-mcp-tasks-durable-bridge`

Bridge MCP Tasks to Elmos durable Run/Step execution with polling, mid-flight input, checkpointing, cancellation, leases, fencing and side-effect reconciliation.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K6, K7
- Dependencies: `elmos-mcp-2026-profile-compiler`, `elmos-ai-durable-runtime-integrator`
- Native checks: worker crash and resume, duplicate update delivery, mid-flight input, cancel after external side effect
- Primary outputs: `runtime/mcp-task-bindings/`, `mcp-task-journal.jsonl`, `mcp-task-recovery-report.json`

## rag-data-plane

### `elmos-multimodal-document-intelligence-generator`

Generate document intelligence pipelines for PDF, Office, image, table, chart, layout, OCR and multimodal citation with quality and privacy controls.

- Priority / risk: `P1` / `high`
- Kernels: K2, K3, K5, K6
- Dependencies: `elmos-rag-corpus-connector-cdc-governor`, `elmos-ai-source-project-importer`
- Native checks: scanned PDF, rotated table, chart with caption, mixed-language document
- Primary outputs: `rag/document-intelligence/`, `parse-quality-report.json`, `multimodal-citation-index.json`

### `elmos-rag-corpus-connector-cdc-governor`

Generate and govern corpus connectors, snapshots, CDC, retries, deduplication, versioning, tombstones, reindex and source-to-index reconciliation.

- Priority / risk: `P1` / `critical`
- Kernels: K2, K3, K7
- Dependencies: `elmos-ai-rag-semantic-compiler`, `elmos-ai-durable-runtime-integrator`
- Native checks: duplicate delivery, out-of-order change, connector restart, full reindex with live updates
- Primary outputs: `rag/connectors/`, `rag/cdc-ledger.jsonl`, `rag/reconciliation-report.json`

## rag-runtime

### `elmos-rag-query-planner-optimizer`

Plan query rewrite, decomposition, hybrid retrieval, graph traversal, reranking and context packing under quality, latency, token and cost budgets.

- Priority / risk: `P1` / `high`
- Kernels: K3, K4, K6, K7
- Dependencies: `elmos-ai-rag-semantic-compiler`, `elmos-ai-rag-retrieval-grounding-certifier`, `elmos-ai-observability-finops-generator`
- Native checks: simple fact query, multi-hop decomposition, budget pressure, adversarial query rewrite
- Primary outputs: `rag/query-plans/`, `retrieval-optimization-report.json`, `query-plan-evidence.json`

## rag-verification

### `elmos-rag-acl-freshness-deletion-verifier`

Verify document and chunk ACLs, temporal freshness, deletion propagation, cache invalidation and derived-memory removal across the RAG data plane.

- Priority / risk: `P1` / `critical`
- Kernels: K2, K6
- Dependencies: `elmos-rag-corpus-connector-cdc-governor`, `elmos-ai-security-governance-compiler`
- Native checks: ACL revoked after indexing, document deletion, tenant role change, stale cache query
- Primary outputs: `verification/rag-acl/`, `acl-freshness-report.json`, `deletion-proof.json`

## runtime-platform

### `elmos-ai-context-memory-governor`

Generate context assembly, prefix-stable caching, compaction, memory write/read policy, conflict resolution, deletion propagation and privacy controls.

- Priority / risk: `P0` / `critical`
- Kernels: K4, K5, K6, K7
- Dependencies: `elmos-ai-memory-semantic-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiContextMemoryGovernor representative end-to-end fixture
- Primary outputs: `context-memory/`, `context-plan.schema.json`, `memory-governance-policy.yaml`, `memory-tests/`

### `elmos-ai-deployment-pack-generator`

Generate local, Docker, Kubernetes, Helm and infrastructure profiles with health endpoints, migrations, secret references, network policy, autoscaling, backup and rollback.

- Priority / risk: `P0` / `critical`
- Kernels: K5, K6, K7, K8
- Dependencies: `elmos-ai-multitenant-control-plane-generator`, `elmos-ai-observability-finops-generator`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiDeploymentPackGenerator representative end-to-end fixture
- Primary outputs: `deploy/`, `helm/`, `runbooks/`, `deployment-evidence-plan.json`

### `elmos-ai-durable-runtime-integrator`

Integrate generated projects with durable workflow, checkpoints, replay, pause/resume/cancel, leases, fencing, outbox and side-effect reconciliation.

- Priority / risk: `P0` / `critical`
- Kernels: K5, K6, K7
- Dependencies: `elmos-ai-runtime-operations-compiler`
- Native checks: worker crash, duplicate delivery, pause resume cancel, AiDurableRuntimeIntegrator representative end-to-end fixture
- Primary outputs: `runtime/durable-execution/`, `checkpoint-contract.json`, `recovery-tests/`, `side-effect-ledger.json`

### `elmos-ai-mcp-a2a-gateway-generator`

Generate MCP client/server and A2A agent-card/task gateway projects with discovery, schema validation, identity, authority, transport, audit and protocol conformance.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-tool-protocol-compiler`, `elmos-ai-project-repository-emitter`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiMcpA2aGatewayGenerator representative end-to-end fixture
- Primary outputs: `targets/protocol-gateway/`, `mcp-contracts/`, `a2a-contracts/`, `protocol-conformance/`

### `elmos-ai-model-routing-fallback-generator`

Generate policy-driven model/provider routing, fallback, hedging, retry, rate-limit, structured-output and budget controls with data-handling constraints.

- Priority / risk: `P0` / `critical`
- Kernels: K4, K5, K6, K7
- Dependencies: `elmos-ai-model-contract-compiler`, `elmos-ai-provider-data-residency-controller`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiModelRoutingFallbackGenerator representative end-to-end fixture
- Primary outputs: `model-routing/`, `provider-policy.yaml`, `fallback-state-machine.json`, `routing-evals/`

### `elmos-ai-multitenant-control-plane-generator`

Generate tenant, project, goal, run, quota, concurrency, identity, RLS, audit and operator APIs for safely hosting generated AI solutions.

- Priority / risk: `P0` / `critical`
- Kernels: K5, K6, K7
- Dependencies: `elmos-ai-durable-runtime-integrator`, `elmos-ai-tool-authority-policy-generator`
- Native checks: worker crash, duplicate delivery, pause resume cancel, AiMultitenantControlPlaneGenerator representative end-to-end fixture
- Primary outputs: `control-plane/`, `database/multitenancy/`, `quota-policy.yaml`, `tenant-isolation-tests/`

### `elmos-ai-observability-finops-generator`

Generate OpenTelemetry traces, normalized agent spans, model/tool usage ledgers, cache metrics, budget enforcement, machine wall-clock ETA and SLO dashboards.

- Priority / risk: `P0` / `high`
- Kernels: K5, K6, K7, K8
- Dependencies: `elmos-ai-runtime-operations-compiler`
- Native checks: worker crash, duplicate delivery, pause resume cancel, AiObservabilityFinopsGenerator representative end-to-end fixture
- Primary outputs: `observability/`, `finops/`, `otel-semantic-conventions.yaml`, `eta-model.json`

### `elmos-ai-operator-console-generator`

Generate an operator console for runs, graphs, checkpoints, approvals, traces, costs, feature gaps, proof obligations, evidence and certificate status.

- Priority / risk: `P1` / `high`
- Kernels: K5, K6, K7, K8
- Dependencies: `elmos-ai-multitenant-control-plane-generator`, `elmos-ai-artifact-provenance-packager`
- Native checks: worker crash, duplicate delivery, pause resume cancel, AiOperatorConsoleGenerator representative end-to-end fixture
- Primary outputs: `operator-console/`, `operator-api-contract.json`, `role-permission-map.json`, `console-e2e-tests/`

### `elmos-ai-provider-data-residency-controller`

Enforce provider eligibility, customer VPC/private endpoint, zero-retention requirements, geographic residency, BYOK and sensitive-data routing decisions.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K6, K7, K8
- Dependencies: `elmos-ai-security-governance-compiler`, `elmos-ai-model-contract-compiler`
- Native checks: worker crash, duplicate delivery, pause resume cancel, AiProviderDataResidencyController representative end-to-end fixture
- Primary outputs: `provider-governance/`, `residency-decision.json`, `data-classification-map.json`, `provider-eligibility-tests/`

### `elmos-ai-tool-authority-policy-generator`

Generate environment-owned, attachment-owned and request-scoped tool authority policies with path/parameter constraints, approval gates and deny-by-default behavior.

- Priority / risk: `P0` / `critical`
- Kernels: K6, K7, K8
- Dependencies: `elmos-ai-security-governance-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiToolAuthorityPolicyGenerator representative end-to-end fixture
- Primary outputs: `policies/generated-tool-authority/`, `authority-snapshots/`, `approval-workflows/`, `policy-tests/`

## runtime-security

### `elmos-ai-runaway-loop-economic-dos-guard`

Prevent agent loops, retry storms, recursive delegation, context explosion and provider fallback cascades using multidimensional budgets and circuit breakers.

- Priority / risk: `P0` / `critical`
- Kernels: K6, K7
- Dependencies: `elmos-ai-runtime-operations-compiler`, `elmos-ai-graph-liveness-side-effect-verifier`, `elmos-ai-observability-finops-generator`
- Native checks: agent-to-agent ping-pong, tool retry storm, context growth, fallback cascade
- Primary outputs: `runtime/budget-policies/`, `runaway-detections.jsonl`, `circuit-breaker-report.json`

## security

### `elmos-agent-skill-mcp-supply-chain-certifier`

Certify Skill, Plugin and MCP supply chains using publisher identity, signatures, SBOM/AIBOM, permission diffs, reproducible builds and dynamic behavior.

- Priority / risk: `P0` / `critical`
- Kernels: K2, K6, K8
- Dependencies: `elmos-agent-skill-ir-compiler`, `elmos-mcp-2026-profile-compiler`, `elmos-ai-supply-chain-performance-resilience-certifier`
- Native checks: typosquatted skill, hidden script, manifest/behavior mismatch, revoked publisher
- Primary outputs: `security/skill-mcp-supply-chain/`, `skill-sbom.json`, `trust-decision.json`

### `elmos-rag-memory-poisoning-verifier`

Verify RAG and memory systems against malicious instructions, cross-tenant pollution, ACL bypass, stale override, citation laundering and deletion persistence.

- Priority / risk: `P0` / `critical`
- Kernels: K2, K3, K6
- Dependencies: `elmos-ai-rag-semantic-compiler`, `elmos-ai-memory-semantic-compiler`, `elmos-ai-prompt-tool-security-redteam`
- Native checks: indirect prompt injection document, cross-tenant vector collision, deleted document remains in cache, poison survives summarization
- Primary outputs: `security/rag-memory-poisoning/`, `poisoning-findings.json`, `quarantine-plan.json`

## semantic-ir

### `elmos-ai-agent-contract-compiler`

Represent agent roles, delegation, handoff, supervision, termination, permissions, context and responsibility boundaries independently of a target SDK.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K4, K6
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiAgentContractCompiler representative end-to-end fixture
- Primary outputs: `agent-contracts.json`, `agent-topology.json`, `responsibility-matrix.json`, `termination-obligations.json`

### `elmos-ai-assurance-contract-compiler`

Compile golden data sets, trace invariants, output schemas, security properties, retrieval metrics, differential tolerances, release thresholds and accepted evidence classes.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K3, K6, K8
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiAssuranceContractCompiler representative end-to-end fixture
- Primary outputs: `assurance-contract.json`, `proof-obligation-seed.json`, `oracle-contracts/`, `release-thresholds.json`

### `elmos-ai-interaction-channel-compiler`

Normalize web chat, API, SSE, WebSocket, CLI/TUI, mobile, enterprise messaging, voice/realtime, AG-UI and generative UI interaction contracts.

- Priority / risk: `P0` / `high`
- Kernels: K3, K6
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiInteractionChannelCompiler representative end-to-end fixture
- Primary outputs: `interaction-contract.json`, `channel-capability-map.json`, `streaming-contract.json`, `accessibility-obligations.json`

### `elmos-ai-memory-semantic-compiler`

Separate turn, thread, session, user, organization, episodic, semantic, procedural and repository memory with lifecycle, privacy and conflict semantics.

- Priority / risk: `P0` / `high`
- Kernels: K3, K6, K7
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiMemorySemanticCompiler representative end-to-end fixture
- Primary outputs: `memory-contract.json`, `memory-scope-map.json`, `retention-policy-input.json`, `memory-consistency-obligations.json`

### `elmos-ai-model-contract-compiler`

Model provider-neutral inference, embedding, reranking, structured output, routing, fallback, budget, data handling and determinism requirements.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K6, K7
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiModelContractCompiler representative end-to-end fixture
- Primary outputs: `model-contracts.json`, `model-capability-requirements.json`, `fallback-graph.json`, `model-risk-register.json`

### `elmos-ai-rag-semantic-compiler`

Model the full ingestion, parsing, chunking, ACL, indexing, retrieval, reranking, context packing, grounding, citation, abstention, synchronization and evaluation lifecycle.

- Priority / risk: `P0` / `critical`
- Kernels: K2, K3, K6
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiRagSemanticCompiler representative end-to-end fixture
- Primary outputs: `rag-contract.json`, `ingestion-graph.json`, `retrieval-contract.json`, `grounding-obligations.json`

### `elmos-ai-runtime-operations-compiler`

Represent durable execution, scheduling, queueing, worker ownership, cancellation, backpressure, telemetry, cache, cost, ETA, rollback and operations requirements.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K6, K7
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiRuntimeOperationsCompiler representative end-to-end fixture
- Primary outputs: `runtime-operations-contract.json`, `runtime-topology.json`, `slo-budget.json`, `recovery-obligations.json`

### `elmos-ai-security-governance-compiler`

Compile identity, tenant isolation, tool authority, secret, data boundary, injection defense, PII, approval, audit, retention, sandbox and egress policies.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K3, K6, K7, K8
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiSecurityGovernanceCompiler representative end-to-end fixture
- Primary outputs: `security-governance-contract.json`, `threat-model.json`, `policy-obligations.json`, `approval-matrix.json`

### `elmos-ai-sir-compiler`

Compile solution contracts and recovered repositories into the canonical AI Solution Semantic IR without treating any external framework API as semantic authority.

- Priority / risk: `P0` / `critical`
- Kernels: K2, K3, K6
- Dependencies: `elmos-ai-revision-set-freezer`, `elmos-ai-model-contract-compiler`, `elmos-ai-agent-contract-compiler`, `elmos-ai-workflow-state-machine-compiler`, `elmos-ai-tool-protocol-compiler`, `elmos-ai-rag-semantic-compiler`, `elmos-ai-memory-semantic-compiler`, `elmos-ai-interaction-channel-compiler`, `elmos-ai-security-governance-compiler`, `elmos-ai-runtime-operations-compiler`, `elmos-ai-assurance-contract-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiSirCompiler representative end-to-end fixture
- Primary outputs: `ai-sir.json`, `ai-sir-index/`, `source-map.json`, `semantic-diagnostics.json`

### `elmos-ai-tool-protocol-compiler`

Normalize function tools, MCP, A2A, OpenAPI, CLI, database, browser, filesystem, code execution and computer-use contracts with typed side-effect and authority semantics.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K6, K7
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiToolProtocolCompiler representative end-to-end fixture
- Primary outputs: `tool-catalog.json`, `protocol-contracts/`, `side-effect-classification.json`, `tool-authority-requirements.json`

### `elmos-ai-workflow-state-machine-compiler`

Compile nodes, edges, branches, loops, joins, interrupts, approvals, retries, compensation, checkpointing and liveness constraints into a durable workflow IR.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K6, K7
- Dependencies: `elmos-ai-requirement-contract-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiWorkflowStateMachineCompiler representative end-to-end fixture
- Primary outputs: `workflow-ir.json`, `state-schema.json`, `liveness-obligations.json`, `side-effect-ordering.json`

## specification

### `elmos-ai-requirement-contract-compiler`

Recover and normalize business, interaction, data, security, latency, cost, residency, operability and acceptance requirements into an executable AI solution contract.

- Priority / risk: `P0` / `critical`
- Kernels: K1, K2, K6
- Dependencies: none
- Native checks: schema validation, conflicting requirement fixture, revision-bound acceptance fixture, AiRequirementContractCompiler representative end-to-end fixture
- Primary outputs: `solution-contract.json`, `requirement-graph.json`, `assumption-ledger.json`, `acceptance-scenarios.yaml`

## supply-chain

### `elmos-ai-bom-provenance-generator`

Generate AI BOM and provenance for models, datasets, prompts, skills, MCP servers, tools, adapters, containers, policies and evaluation artifacts.

- Priority / risk: `P1` / `critical`
- Kernels: K2, K6, K8
- Dependencies: `elmos-agent-skill-mcp-supply-chain-certifier`, `elmos-ai-artifact-provenance-packager`
- Native checks: model plus prompt plus tool inventory, missing dataset provenance, skill update diff, container rebuild comparison
- Primary outputs: `supply-chain/aibom/`, `aibom.json`, `aibom-attestation.json`

## target-generator

### `elmos-openai-plugin-project-generator`

Generate complete OpenAI Plugin projects containing skills, MCP server, optional UI, review metadata, starter prompts, tests and submission evidence.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-agent-skill-portability-emitter`, `elmos-mcp-2026-profile-compiler`, `elmos-ai-project-repository-emitter`
- Native checks: developer-mode installation, MCP tool metadata validation, skills-only, MCP-only and combined plugin fixtures, review snapshot reproducibility
- Primary outputs: `targets/openai-plugin/`, `plugin-submission.json`, `plugin-review-evidence/`

### `elmos-target-coding-agent-harness-family-generator`

Generate OpenHands, OpenCode, Codex, Claude Code, Gemini CLI, Cline/Roo, Continue and Aider repository skills, plugins, commands, rules and orchestration policies.

- Priority / risk: `P1` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`, `elmos-ai-tool-authority-policy-generator`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetCodingAgentHarnessFamilyGenerator representative end-to-end fixture
- Primary outputs: `targets/coding-harnesses/`, `repository-skills/`, `harness-policies/`, `harness-conformance/`

### `elmos-target-crewai-generator`

Generate Crew and Flow projects with role contracts, tasks, event-driven control, state persistence, tool policies and evaluation.

- Priority / risk: `P1` / `high`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetCrewaiGenerator representative end-to-end fixture
- Primary outputs: `targets/crewai/`, `crews/`, `flows/`, `crewai-evals/`

### `elmos-target-deepseek-harness-generator`

Generate Cordis-based plugins, services, events, lifecycle effects, bundles, profiles and patch layers with hot-unload and authority conformance tests.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: Cordis plugin lifecycle and unload, bundle and profile patch ordering, typed service/event registration, hot reload state safety, headless and web profile conformance
- Primary outputs: `targets/deepseek-harness/`, `plugins/`, `bundles/`, `profiles/`

### `elmos-target-dify-project-generator`

Generate and import/export Dify Chatflow, Workflow, Agent, knowledge-pipeline and plugin projects with deterministic layout, dependency manifests and unsupported-node accounting.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`, `elmos-ai-roundtrip-migration-controller`
- Native checks: DSL import/export semantic round-trip, Workflow, Chatflow and Agent mode distinction, deterministic node coordinate layout, knowledge-pipeline and plugin manifest load, unsupported node preservation, environment-variable redaction, Dify upgrade and import rollback
- Primary outputs: `targets/dify/`, `dify-dsl/`, `plugins/`, `dify-import-smoke.json`

### `elmos-target-google-adk-generator`

Generate Python, TypeScript, Java/Kotlin and Go ADK projects with agent teams, workflow agents, A2A, evaluation, sessions, artifacts and deployment profiles.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: multi-agent and workflow agent, A2A interface, evaluation fixture, deployment profile, language-specific build for selected SDK
- Primary outputs: `targets/google-adk/`, `adk-agents/`, `adk-evals/`, `adk-deploy/`

### `elmos-target-haystack-generator`

Generate component, pipeline, document-store, agent, toolset and human-loop projects with pipeline serialization and evaluation evidence.

- Priority / risk: `P1` / `high`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`, `elmos-ai-rag-semantic-compiler`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetHaystackGenerator representative end-to-end fixture
- Primary outputs: `targets/haystack/`, `components/`, `pipelines/`, `haystack-evals/`

### `elmos-target-langchain-project-generator`

Generate typed Python and TypeScript LangChain applications for model, tool, retriever, middleware and short-horizon agent composition with migration hooks to LangGraph.

- Priority / risk: `P0` / `high`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetLangchainProjectGenerator representative end-to-end fixture
- Primary outputs: `targets/langchain/`, `langchain-capability-report.json`, `provider-integrations/`, `migration-hooks/`

### `elmos-target-langchain4j-generator`

Generate Java AI services with models, tools, RAG, MCP, agentic modules and Spring Boot integration, including Spring AI comparison and migration evidence.

- Priority / risk: `P1` / `high`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetLangchain4jGenerator representative end-to-end fixture
- Primary outputs: `targets/langchain4j/`, `java-ai-services/`, `comparison-report.json`, `langchain4j-tests/`

### `elmos-target-langgraph-project-generator`

Generate typed graph applications with state schemas, subgraphs, checkpointers, stores, interrupts, durable execution, streaming, human gates and liveness validation.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`, `elmos-ai-graph-liveness-side-effect-verifier`
- Native checks: typed state schema and node/edge compilation, checkpointer serialization and worker crash recovery, interrupt and resume with human approval, subgraph state isolation, parallel branch conflict detection, side-effect idempotency, loop termination and cancellation
- Primary outputs: `targets/langgraph/`, `graph-contract.json`, `checkpoint-profile.json`, `graph-verification.json`

### `elmos-target-lightweight-agent-sdk-family-generator`

Generate Strands Agents, Agno, smolagents, DSPy, Qwen-Agent and CAMEL projects through a shared lightweight-agent contract and explicit capability limitations.

- Priority / risk: `P1` / `high`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetLightweightAgentSdkFamilyGenerator representative end-to-end fixture
- Primary outputs: `targets/lightweight-agents/`, `sdk-profiles/`, `compatibility-ledgers/`, `lightweight-agent-tests/`

### `elmos-target-llamaindex-generator`

Generate Python and TypeScript document-intelligence, agentic RAG, extraction, workflow and knowledge-assistant projects with explicit data lifecycle contracts.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`, `elmos-ai-rag-semantic-compiler`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetLlamaindexGenerator representative end-to-end fixture
- Primary outputs: `targets/llamaindex/`, `document-pipelines/`, `llamaindex-workflows/`, `llamaindex-evals/`

### `elmos-target-mastra-generator`

Generate TypeScript agent, graph workflow, memory, human approval and deployment projects with framework-neutral trace and tool contracts.

- Priority / risk: `P1` / `high`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetMastraGenerator representative end-to-end fixture
- Primary outputs: `targets/mastra/`, `mastra-agents/`, `mastra-workflows/`, `mastra-tests/`

### `elmos-target-microsoft-agent-framework-generator`

Generate .NET and Python projects with typed agents, sessions, graph workflows, human-in-the-loop, telemetry and migration assets from AutoGen or Semantic Kernel.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: session state and graph workflow, human-in-the-loop, telemetry, long-running task recovery, AutoGen/Semantic Kernel migration fixture
- Primary outputs: `targets/microsoft-agent-framework/`, `workflow-contracts/`, `migration-maps/`, `agent-framework-tests/`

### `elmos-target-openai-agents-sdk-generator`

Generate Python and TypeScript agent projects with tools, handoffs, guardrails, sessions, tracing, MCP, structured outputs and realtime integration contracts.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: agent, tool and handoff execution, guardrail and structured output, session and tracing, MCP integration, realtime or voice profile when declared
- Primary outputs: `targets/openai-agents/`, `agents/`, `guardrails/`, `tracing-tests/`

### `elmos-target-openclaw-assistant-generator`

Generate isolated OpenClaw gateway/workspace configurations, agents, skills, plugins, channels, sandbox policies, pairing, service and recovery assets.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`, `elmos-ai-tool-authority-policy-generator`
- Native checks: Gateway configuration validation, Skill and plugin manifest load, channel plugin isolation, sandbox and pairing policy, daemon restart and session recovery, per-tenant or per-authority-domain isolation, plugin allowlist and backup/restore
- Primary outputs: `targets/openclaw/`, `openclaw.json`, `workspace/`, `plugins/`

### `elmos-target-openharness-generator`

Generate provider, tool, skill, plugin, hook, permission, memory, session and multi-agent extensions against the OpenHarness adapter contract.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: provider/tool/skill/plugin loading, hook ordering and permission denial, memory/session backend recovery, autopilot stop conditions, multi-agent coordination
- Primary outputs: `targets/openharness/`, `openharness-extensions/`, `permission-profile.json`, `session-tests/`

### `elmos-target-pi-package-generator`

Generate complete Pi packages containing extensions, custom tools, skills, prompt templates, themes, repository conventions, RPC/SDK embedding and load tests.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: Pi package manifest load, extension, tool, command and skill activation, RPC and SDK embedding, session backend recovery, repository-local settings isolation
- Primary outputs: `targets/pi/`, `pi-package-manifest.json`, `extensions/`, `skills/`

### `elmos-target-pydanticai-generator`

Generate type-safe Python agents, dependency injection, structured output, graph state machines, MCP and durable execution integrations.

- Priority / risk: `P1` / `high`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetPydanticaiGenerator representative end-to-end fixture
- Primary outputs: `targets/pydantic-ai/`, `typed-contracts/`, `pydantic-graphs/`, `type-safety-tests/`

### `elmos-target-ragflow-generator`

Generate document-centric RAGFlow projects, ingestion settings, knowledge bases, agent workflows, APIs and deployment integration while retaining a portable RAG contract.

- Priority / risk: `P1` / `high`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`, `elmos-ai-rag-semantic-compiler`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetRagflowGenerator representative end-to-end fixture
- Primary outputs: `targets/ragflow/`, `ragflow-import/`, `knowledge-config/`, `ragflow-conformance.json`

### `elmos-target-spring-ai-project-generator`

Generate enterprise Spring Boot AI services with ChatClient, Advisors, RAG, VectorStore, tools, MCP, memory, security, observability, Testcontainers and deployment assets.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: Spring Boot native compile and startup, ChatClient and Advisor chain, Tool Calling argument validation, MCP client and server startup, VectorStore/Testcontainers integration, Spring Security tenant isolation, Actuator/Micrometer telemetry, Flyway or Liquibase migration
- Primary outputs: `targets/spring-ai/`, `spring-ai-bom-lock.json`, `spring-ai-tests/`, `spring-ai-deploy/`

### `elmos-target-symphony-workflow-generator`

Generate repository-versioned workflow policy, work-item adapters, isolated workspace contracts, retry/backoff, proof-of-work and handoff artifacts for coding orchestration.

- Priority / risk: `P0` / `high`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`
- Native checks: WORKFLOW policy parse, work-item adapter conformance, isolated workspace lifecycle, reconciler retries and backoff, proof-of-work and acceptance gate
- Primary outputs: `targets/symphony/`, `WORKFLOW.md`, `workspace-policy.yaml`, `work-item-adapter/`

### `elmos-target-universal-rag-project-generator`

Generate production RAG repositories spanning ingestion, parsing, ACL-aware indexing, hybrid retrieval, reranking, grounded answering, administration, evaluation and operations.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`, `elmos-ai-rag-semantic-compiler`
- Native checks: snapshot plus CDC ingestion, hybrid retrieval and reranking, document ACL enforcement, citation and abstention, delete propagation and reindex, multimodal parser fixture, retrieval, grounding, latency and cost evaluation
- Primary outputs: `targets/rag/`, `rag-services/`, `rag-evals/`, `rag-operations/`

### `elmos-target-vercel-ai-sdk-generator`

Generate AI-native web applications with typed streaming, tool calling, generative UI, framework adapters, server routes and backend-agent contracts.

- Priority / risk: `P1` / `high`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`, `elmos-ai-interaction-channel-compiler`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetVercelAiSdkGenerator representative end-to-end fixture
- Primary outputs: `targets/vercel-ai-sdk/`, `web-app/`, `stream-protocol/`, `ui-contract-tests/`

### `elmos-target-visual-agent-platform-family-generator`

Generate or migrate Langflow, Coze Studio, FastGPT and n8n AI projects through platform-specific adapters without making visual DSLs the canonical source of truth.

- Priority / risk: `P1` / `high`
- Kernels: K3, K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`, `elmos-ai-roundtrip-migration-controller`
- Native checks: minimal project, representative project, unsupported feature, upgrade fixture, TargetVisualAgentPlatformFamilyGenerator representative end-to-end fixture
- Primary outputs: `targets/visual-agent-platforms/`, `platform-dsls/`, `roundtrip-ledgers/`, `visual-platform-tests/`

## transformation

### `elmos-ai-config-secret-materializer`

Generate environment schemas, secret references, configuration validation and deployment-time materialization without embedding credentials in generated code or evidence.

- Priority / risk: `P0` / `critical`
- Kernels: K5, K6, K7
- Dependencies: `elmos-ai-project-repository-emitter`, `elmos-ai-security-governance-compiler`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiConfigSecretMaterializer representative end-to-end fixture
- Primary outputs: `config-schema.json`, `secret-reference-map.json`, `environment-examples/`, `secretless-validation.json`

### `elmos-ai-dependency-version-resolver`

Resolve framework, runtime, provider, plugin, model, database and deployment dependencies against compatibility, support, license, vulnerability and reproducibility policy.

- Priority / risk: `P0` / `critical`
- Kernels: K2, K5, K6, K8
- Dependencies: `elmos-ai-multi-target-lowering-planner`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiDependencyVersionResolver representative end-to-end fixture
- Primary outputs: `dependency-lock-plan.json`, `compatibility-decision.json`, `license-risk.json`, `release-pin-requirements.json`

### `elmos-ai-multi-target-lowering-planner`

Plan shared and target-specific lowering stages, preserve common assets, assign semantic-gap obligations and prevent divergent target truth.

- Priority / risk: `P0` / `critical`
- Kernels: K3, K4, K5, K6
- Dependencies: `elmos-ai-target-adapter-sdk`, `elmos-ai-capability-negotiator`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiMultiTargetLoweringPlanner representative end-to-end fixture
- Primary outputs: `lowering-plan.json`, `shared-artifact-plan.json`, `target-work-packages/`, `semantic-gap-obligations.json`

### `elmos-ai-project-repository-emitter`

Emit complete repository structures, source code, schemas, prompts, tools, tests, deployment assets, runbooks and evidence hooks from approved lowering plans.

- Priority / risk: `P0` / `critical`
- Kernels: K5, K6
- Dependencies: `elmos-ai-dependency-version-resolver`
- Native checks: round-trip fixture, unsupported construct, source map integrity, AiProjectRepositoryEmitter representative end-to-end fixture
- Primary outputs: `generated-repository/`, `emission-manifest.json`, `source-lineage.json`, `unresolved-emission-register.json`

## verification

### `elmos-structured-output-contract-verifier`

Verify model structured outputs and tool arguments against schemas, semantic constraints, repair bounds, adversarial values and provider-specific behavior.

- Priority / risk: `P1` / `critical`
- Kernels: K3, K6
- Dependencies: `elmos-prompt-program-ir-compiler`, `elmos-ai-generated-project-conformance-validator`
- Native checks: missing required field, unknown enum, numeric overflow, malicious string in tool argument
- Primary outputs: `verification/structured-output/`, `schema-conformance-report.json`, `repair-ledger.json`
