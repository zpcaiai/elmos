        # Legacy Java/Spring modernization

        ## Purpose

        Spring legacy route including Struts/Servlet migration through canonical Spring Modernization ownership.

        ## Scope

        characterize → build → decompose → migrate framework → compare → prepare rollout

        ## Participating component Skills

        - `reproducible-build-environment`
- `business-invariant-recovery`
- `modernization-strangler-and-rearchitecture`
- `proof-guided-atomic-refactor-execution`
- `characterization-differential-mutation-verification`
- `shadow-dual-run-canary-rollback-preparation`

        ## Required route contract

        - Bind to one existing canonical route owner.
        - Freeze tenant, engagement, repositories, RevisionSet, environment, data and policy identity.
        - Define acceptance, invariant, evidence, side-effect, rollback and approval obligations before execution.
        - Execute through a durable DAG with atomic ChangeSets and independent verification.
        - Preserve `UNKNOWN`, `UNSUPPORTED`, counterexamples and residual risks.
        - Maximum package-local completion is E3; production execution and E4/E5/P05 are external gates.

        ## Fixture matrix

        Each route requires positive, negative, edge, failure-injection, rollback, stale-evidence, tenant-isolation and unsupported-path fixtures. At least one commercial pilot must exceed 500k LOC; the scale benchmark suite must include a repository over 1M LOC before broad production claims.
