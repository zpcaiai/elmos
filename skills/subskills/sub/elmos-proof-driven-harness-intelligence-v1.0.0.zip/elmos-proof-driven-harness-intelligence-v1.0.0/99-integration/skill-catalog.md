# Skill Catalog

## K1 Semantic Intelligence

- `semantic-lsp-federation`
- `compiler-authority-router`
- `repository-semantic-graph`
- `semantic-reference-index`
- `semantic-call-graph`
- `semantic-type-graph`
- `semantic-dataflow-index`
- `framework-semantic-detector`
- `ast-structural-query`
- `repository-prewalk-indexer`
- `cross-language-semantic-diff`
- `semantic-uncertainty-map`

## K2 Transactional Transformation

- `semantic-anchor`
- `content-hash-anchor`
- `symbol-identity-anchor`
- `stale-state-detector`
- `read-set-tracker`
- `write-set-tracker`
- `patch-intent-contract`
- `edit-precondition-validator`
- `semantic-conflict-detector`
- `ast-structural-rewrite`
- `semantic-ir-rewrite`
- `framework-aware-rewrite`
- `edit-postcondition-validator`
- `transactional-patch`
- `snapshot-manager`
- `rollback-manager`
- `atomic-commit-planner`
- `dependency-aware-commit-ordering`
- `semantic-merge-validator`
- `merge-proof-generator`

## K3 Runtime Proof

- `dap-adapter-discovery`
- `dap-runtime-driver`
- `breakpoint-plan-generator`
- `runtime-state-capture`
- `call-stack-capture`
- `variable-snapshot`
- `exception-trace`
- `memory-state-probe`
- `differential-debugger`
- `control-flow-equivalence`
- `state-equivalence`
- `exception-equivalence`
- `api-response-equivalence`
- `database-effect-equivalence`
- `transaction-boundary-equivalence`
- `message-effect-equivalence`
- `file-effect-equivalence`
- `concurrency-observation`
- `deterministic-replay`
- `scenario-replay`
- `fault-injection-runner`
- `counterexample-generator`
- `runtime-root-cause-localizer`
- `auto-debug-repair-loop`

## K4 Agentic Execution

- `agent-definition-ir`
- `agent-capability-registry`
- `agent-discovery`
- `agent-policy-resolution`
- `spawn-policy`
- `recursion-depth-governor`
- `self-recursion-guard`
- `tool-authority-profile`
- `agent-model-policy`
- `effort-ceiling`
- `autoload-skill-policy`
- `read-summary-policy`
- `prewalk-agent`
- `phase-model-handoff`
- `isolated-workspace`
- `workspace-owner`
- `workspace-lease`
- `workspace-fence`
- `workspace-snapshot`
- `typed-agent-yield`
- `proof-carrying-result`
- `agent-task-dag`
- `blocking-vs-async-policy`
- `agent-supervisor`
- `steer-agent`
- `park-revive-agent`
- `kill-release-agent`
- `child-lineage`
- `merge-coordinator`
- `orphan-agent-reaper`

## K5 Assurance

- `independent-advisor-runtime`
- `advisor-context-delta`
- `advisor-private-context`
- `advisor-tool-session`
- `advisor-tool-grant-policy`
- `advisor-severity-router`
- `advisor-nit`
- `advisor-concern`
- `advisor-blocker`
- `advisor-dedup`
- `advisor-rate-limit`
- `advisor-backlog`
- `advisor-backpressure`
- `advisor-quarantine`
- `advisor-failure-isolation`
- `architecture-watchdog`
- `migration-watchdog`
- `security-watchdog`
- `transaction-watchdog`
- `concurrency-watchdog`
- `database-watchdog`
- `api-contract-watchdog`
- `performance-watchdog`
- `proof-watchdog`
- `reviewer-consensus`
- `reviewer-disagreement-resolver`
- `evidence-first-review`
- `release-verdict-reviewer`

## K6 Policy & Invariants

- `rule-source-discovery`
- `rule-normalizer`
- `cross-harness-rule-import`
- `policy-namespace`
- `policy-versioning`
- `policy-authority`
- `policy-precedence`
- `policy-conflict-explainer`
- `always-apply-policy`
- `lazy-rulebook`
- `regex-trigger`
- `ast-trigger`
- `semantic-trigger`
- `runtime-trigger`
- `tool-scope-trigger`
- `path-scope-trigger`
- `symbol-scope-trigger`
- `jit-rule-injection`
- `stream-semantic-guard`
- `policy-interrupt`
- `policy-block`
- `policy-auto-repair`
- `invariant-evidence`
- `policy-audit`

## K7 Skill Evolution

- `project-memory`
- `repository-semantic-memory`
- `failure-memory`
- `counterexample-memory`
- `repair-memory`
- `lesson-extractor`
- `lesson-generalizer`
- `skill-candidate-generator`
- `skill-similarity-dedup`
- `skill-conflict-detector`
- `skill-fixture-generator`
- `skill-negative-fixture-generator`
- `mutation-fixture-generator`
- `regression-corpus-builder`
- `golden-route-evaluator`
- `skill-benchmark`
- `skill-certifier`
- `skill-promoter`
- `skill-canary`
- `skill-versioning`
- `skill-lineage`
- `skill-deprecation`
- `skill-rollback`

## K8 Harness Intelligence

- `tool-authority-router`
- `semantic-tool-priority`
- `tool-capability-negotiator`
- `tool-failure-classifier`
- `no-silent-fallback`
- `tool-approval-router`
- `model-role-router`
- `model-capability-profile`
- `model-fallback-chain`
- `quota-aware-fallback`
- `provider-failure-fallback`
- `effort-aware-routing`
- `phase-model-handoff`
- `cost-aware-routing`
- `latency-aware-routing`
- `quality-aware-routing`
- `path-scoped-model-policy`
- `tenant-model-policy`
- `credential-pool-affinity`
- `prompt-compiler`
- `prompt-linter`
- `rfc-normative-policy`
- `tool-doc-surface-optimizer`
- `example-contract-validator`
- `skill-lazy-loader`
- `rule-lazy-loader`
- `context-budget-manager`
- `append-only-context-optimizer`
- `adaptive-compaction`
- `checkpoint`
- `rewind`
- `context-promotion`
- `provider-stream-reset`
- `context-rebuild`
- `foreign-session-import`
- `harness-ab-test`
- `tool-format-benchmark`
- `edit-format-benchmark`
- `prompt-benchmark`
- `context-strategy-benchmark`
- `routing-benchmark`
- `retry-policy-benchmark`

## K9 Production Control Plane

- `durable-job`
- `durable-phase`
- `durable-agent-state`
- `durable-tool-effect`
- `idempotency-key`
- `checkpoint-resume`
- `crash-recovery`
- `replay-safe-recovery`
- `provider-session-rotation`
- `provider-stream-fresh-reset`
- `session-fork`
- `job-fork`
- `tenant-isolation`
- `project-isolation`
- `workspace-ownership`
- `lease-management`
- `lease-expiry`
- `fencing-token`
- `stale-worker-rejection`
- `distributed-lock-policy`
- `side-effect-outbox`
- `pause-job`
- `resume-job`
- `cancel-job`
- `retry-phase`
- `replay-scenario`
- `steer-agent`
- `kill-agent`
- `revive-agent`
- `rollback-transaction`
- `fork-job`
- `token-meter`
- `model-cost-meter`
- `tool-cost-meter`
- `compute-meter`
- `storage-meter`
- `project-cost-rollup`
- `tenant-cost-rollup`
- `revenue-meter`
- `margin-estimator`
- `progress-model`
- `phase-completion-estimator`
- `wall-clock-eta`
- `critical-path-estimator`
- `retry-risk-adjustment`
- `repository-size-adjustment`
- `trace-correlation`
- `structured-events`
- `audit-log`
- `evidence-provenance`
- `artifact-lineage`
- `metrics-endpoint`
- `health-endpoint`
- `version-endpoint`
- `readiness`
- `liveness`
- `sla-monitor`
- `capacity-planner`
- `quota-governor`


**Total named production capabilities: 262**
