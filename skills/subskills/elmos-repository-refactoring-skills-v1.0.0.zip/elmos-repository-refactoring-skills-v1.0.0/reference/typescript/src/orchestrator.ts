import type {
  Checkpoint,
  RefactorPlan,
  RefactorRequest,
  RunControl,
  RunEvent,
  RunRecord,
  RunStatus,
  StepExecutionResult,
  StepStatus,
} from "./types.js";

export interface DurableStore {
  createRun(request: RefactorRequest, plan: RefactorPlan): Promise<RunRecord>;
  getRun(runId: string): Promise<RunRecord>;
  getControl(runId: string): Promise<RunControl>;
  compareImmutableBindings(runId: string, plan: RefactorPlan): Promise<boolean>;
  transitionRun(runId: string, from: readonly RunStatus[], to: RunStatus, phase: string): Promise<RunRecord>;
  getStepStatus(runId: string, planVersion: number, stepId: string): Promise<StepStatus>;
  transitionStep(
    runId: string,
    planVersion: number,
    stepId: string,
    from: readonly StepStatus[],
    to: StepStatus,
  ): Promise<void>;
  saveCheckpoint(checkpoint: Checkpoint): Promise<void>;
  latestCheckpoint(runId: string, stepId: string, shardId: string): Promise<Checkpoint | undefined>;
  appendEvent(event: RunEvent): Promise<void>;
  nextEventSequence(runId: string): Promise<number>;
}

export interface Lease {
  readonly key: string;
  readonly fencingToken: number;
  release(): Promise<void>;
}

export interface LeaseManager {
  acquire(key: string, owner: string, ttlSeconds: number): Promise<Lease>;
}

export interface StepExecutor {
  execute(input: {
    readonly request: RefactorRequest;
    readonly plan: RefactorPlan;
    readonly stepId: string;
    readonly fencingToken: number;
    readonly checkpoint?: Checkpoint;
  }): Promise<StepExecutionResult>;
}

export interface OrchestratorClock {
  nowIso(): string;
}

export interface OrchestratorIds {
  eventId(): string;
  checkpointId(): string;
}

const TERMINAL: ReadonlySet<RunStatus> = new Set([
  "FAILED_VALIDATION",
  "FAILED_EVIDENCE",
  "FAILED_ROLLBACK",
  "CANCELLED",
  "SUCCEEDED_PATCH_ONLY",
  "PARTIAL_WITH_ROLLBACK",
  "SUCCEEDED",
]);

export class RefactorOrchestrator {
  constructor(
    private readonly store: DurableStore,
    private readonly leases: LeaseManager,
    private readonly executor: StepExecutor,
    private readonly clock: OrchestratorClock,
    private readonly ids: OrchestratorIds,
  ) {}

  async start(request: RefactorRequest, plan: RefactorPlan): Promise<RunRecord> {
    this.assertPlan(request, plan);
    const run = await this.store.createRun(request, plan);
    await this.emit(run.runId, "RUN_CREATED", `run:${run.runId}:created`, {
      planId: plan.planId,
      planVersion: plan.version,
    });
    return this.drive(request, plan);
  }

  async resume(request: RefactorRequest, plan: RefactorPlan): Promise<RunRecord> {
    const bindingsMatch = await this.store.compareImmutableBindings(plan.runId, plan);
    if (!bindingsMatch) {
      throw new Error("Cannot resume: immutable request/plan/recipe/adapter/toolchain/snapshot bindings changed");
    }
    await this.store.transitionRun(plan.runId, ["PAUSED", "BLOCKED_ENVIRONMENT"], "RUNNING", "RESUMING");
    await this.emit(plan.runId, "RUN_RESUMED", `run:${plan.runId}:resume:${plan.version}`, {
      planVersion: plan.version,
    });
    return this.drive(request, plan);
  }

  private async drive(request: RefactorRequest, plan: RefactorPlan): Promise<RunRecord> {
    let run = await this.store.getRun(plan.runId);
    if (run.status === "QUEUED" || run.status === "PAUSED") {
      run = await this.store.transitionRun(run.runId, [run.status], "RUNNING", "EXECUTING");
    }
    if (TERMINAL.has(run.status)) {
      return run;
    }

    for (const step of this.topologicalOrder(plan)) {
      const control = await this.store.getControl(plan.runId);
      if (control.cancelRequested) {
        await this.emit(plan.runId, "RUN_CANCELLED", `run:${plan.runId}:cancelled`, { stepId: step.stepId });
        return this.store.transitionRun(
          plan.runId,
          ["RUNNING", "PAUSING", "PAUSED", "REPAIRING", "BLOCKED_APPROVAL"],
          "CANCELLED",
          "CANCELLED",
        );
      }
      if (control.pauseRequested) {
        await this.emit(plan.runId, "RUN_PAUSED", `run:${plan.runId}:paused:${step.stepId}`, {
          beforeStepId: step.stepId,
        });
        return this.store.transitionRun(plan.runId, ["RUNNING", "PAUSING"], "PAUSED", "PAUSED");
      }

      const current = await this.store.getStepStatus(plan.runId, plan.version, step.stepId);
      if (current === "SUCCEEDED" || current === "SKIPPED") {
        continue;
      }
      await this.assertDependenciesComplete(plan, step.stepId);
      await this.store.transitionStep(
        plan.runId,
        plan.version,
        step.stepId,
        ["PENDING", "READY", "FAILED", "BLOCKED"],
        "RUNNING",
      );

      const lease = await this.leases.acquire(
        `refactor/${plan.runId}/${plan.version}/${step.stepId}/default`,
        `orchestrator:${plan.runId}`,
        120,
      );
      try {
        const checkpoint = await this.store.latestCheckpoint(plan.runId, step.stepId, "default");
        const outcome = await this.executor.execute({
          request,
          plan,
          stepId: step.stepId,
          fencingToken: lease.fencingToken,
          ...(checkpoint === undefined ? {} : { checkpoint }),
        });

        if (outcome.status === "BLOCKED") {
          await this.store.transitionStep(plan.runId, plan.version, step.stepId, ["RUNNING"], "BLOCKED");
          await this.emit(plan.runId, "STEP_BLOCKED", `step:${step.stepId}:blocked`, {
            stepId: step.stepId,
            failure: outcome.failure ?? null,
          });
          return this.store.transitionRun(
            plan.runId,
            ["RUNNING"],
            outcome.failure?.class === "ENVIRONMENT" ? "BLOCKED_ENVIRONMENT" : "BLOCKED_APPROVAL",
            "BLOCKED",
          );
        }

        if (outcome.status === "FAILED") {
          await this.store.transitionStep(plan.runId, plan.version, step.stepId, ["RUNNING"], "FAILED");
          await this.emit(plan.runId, "STEP_FAILED", `step:${step.stepId}:failed`, {
            stepId: step.stepId,
            failure: outcome.failure ?? null,
          });
          return this.store.transitionRun(
            plan.runId,
            ["RUNNING", "REPAIRING"],
            outcome.failure?.class === "EVIDENCE" ? "FAILED_EVIDENCE" : "FAILED_VALIDATION",
            "FAILED",
          );
        }

        this.assertSuccessfulOutput(step.stepId, outcome);
        const sequence = await this.store.nextEventSequence(plan.runId);
        await this.store.saveCheckpoint({
          checkpointId: this.ids.checkpointId(),
          runId: plan.runId,
          stepId: step.stepId,
          shardId: "default",
          sequence,
          workspaceTreeDigest: outcome.workspaceTreeDigest,
          artifactManifestDigest: outcome.artifactManifestDigest,
          sideEffectCursor: `event:${sequence}`,
          createdAt: this.clock.nowIso(),
        });
        await this.store.transitionStep(plan.runId, plan.version, step.stepId, ["RUNNING"], "SUCCEEDED");
        await this.emit(plan.runId, "STEP_SUCCEEDED", `step:${step.stepId}:succeeded:${outcome.outputDigest}`, {
          stepId: step.stepId,
          outputDigest: outcome.outputDigest,
        });
      } finally {
        await lease.release();
      }
    }

    await this.emit(plan.runId, "RUN_SUCCEEDED", `run:${plan.runId}:succeeded:${plan.version}`, {
      planVersion: plan.version,
    });
    return this.store.transitionRun(plan.runId, ["RUNNING"], "SUCCEEDED", "COMPLETED");
  }

  private async assertDependenciesComplete(plan: RefactorPlan, stepId: string): Promise<void> {
    const step = plan.steps.find((candidate) => candidate.stepId === stepId);
    if (step === undefined) {
      throw new Error(`Unknown step ${stepId}`);
    }
    for (const dependency of step.dependsOn) {
      const status = await this.store.getStepStatus(plan.runId, plan.version, dependency);
      if (status !== "SUCCEEDED" && status !== "SKIPPED") {
        throw new Error(`Dependency ${dependency} is ${status}, not complete`);
      }
    }
  }

  private topologicalOrder(plan: RefactorPlan): readonly RefactorPlan["steps"][number][] {
    const byId = new Map(plan.steps.map((step) => [step.stepId, step]));
    const temporary = new Set<string>();
    const permanent = new Set<string>();
    const ordered: RefactorPlan["steps"][number][] = [];

    const visit = (stepId: string): void => {
      if (permanent.has(stepId)) return;
      if (temporary.has(stepId)) throw new Error(`Plan cycle detected at ${stepId}`);
      const step = byId.get(stepId);
      if (step === undefined) throw new Error(`Missing dependency step ${stepId}`);
      temporary.add(stepId);
      for (const dependency of step.dependsOn) visit(dependency);
      temporary.delete(stepId);
      permanent.add(stepId);
      ordered.push(step);
    };

    for (const step of plan.steps) visit(step.stepId);
    return ordered;
  }

  private assertPlan(request: RefactorRequest, plan: RefactorPlan): void {
    if (request.spec.repositories.length === 0) throw new Error("At least one repository is required");
    if (plan.steps.length === 0) throw new Error("At least one plan step is required");
    if (Object.keys(plan.snapshotDigests).length === 0) throw new Error("Snapshot digests are required");
    for (const digest of Object.values(plan.snapshotDigests)) {
      if (!digest.startsWith("sha256:")) throw new Error(`Invalid snapshot digest ${digest}`);
    }
    this.topologicalOrder(plan);
  }

  private assertSuccessfulOutput(stepId: string, outcome: StepExecutionResult): asserts outcome is StepExecutionResult & {
    outputDigest: string;
    workspaceTreeDigest: string;
    artifactManifestDigest: string;
  } {
    if (
      outcome.outputDigest === undefined ||
      outcome.workspaceTreeDigest === undefined ||
      outcome.artifactManifestDigest === undefined
    ) {
      throw new Error(`Step ${stepId} reported success without durable output digests`);
    }
  }

  private async emit(
    runId: string,
    type: string,
    idempotencyKey: string,
    payload: Readonly<Record<string, unknown>>,
  ): Promise<void> {
    const sequence = await this.store.nextEventSequence(runId);
    await this.store.appendEvent({
      eventId: this.ids.eventId(),
      runId,
      sequence,
      type,
      idempotencyKey,
      payload,
      occurredAt: this.clock.nowIso(),
    });
  }
}
