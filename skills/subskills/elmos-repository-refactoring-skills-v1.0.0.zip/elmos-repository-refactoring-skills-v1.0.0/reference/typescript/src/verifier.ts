import type { LanguageAdapter } from "./adapter.js";
import type { FailureDescriptor, ValidationSpec } from "./types.js";

export interface GateDecision {
  readonly gate: string;
  readonly profile: string;
  readonly blocking: boolean;
  readonly decision: "PASS" | "FAIL" | "ERROR" | "NOT_APPLICABLE";
  readonly summary: string;
  readonly evidenceRefs: readonly string[];
  readonly failure?: FailureDescriptor;
}

export interface VerificationResult {
  readonly passed: boolean;
  readonly decisions: readonly GateDecision[];
  readonly blockingFailures: readonly GateDecision[];
}

export interface GatePolicy {
  timeoutFor(gate: string, profile: string): number;
  mayWaive(gate: string): boolean;
}

export class VerificationEngine {
  constructor(
    private readonly adapter: LanguageAdapter,
    private readonly policy: GatePolicy,
  ) {}

  async verify(
    runId: string,
    stepId: string,
    workspaceTreeDigest: string,
    specs: readonly ValidationSpec[],
  ): Promise<VerificationResult> {
    const decisions: GateDecision[] = [];

    for (const spec of specs) {
      const profile = spec.profile ?? "default";
      const result = await this.adapter.validate({
        runId,
        stepId,
        profile: `${spec.gate}:${profile}`,
        workspaceTreeDigest,
        timeoutSeconds: this.policy.timeoutFor(spec.gate, profile),
      });
      decisions.push({
        gate: spec.gate,
        profile,
        blocking: spec.blocking,
        decision: result.decision,
        summary: result.summary,
        evidenceRefs: result.evidenceRefs,
        ...(result.failure === undefined ? {} : { failure: result.failure }),
      });
    }

    const blockingFailures = decisions.filter(
      (decision) =>
        decision.blocking &&
        (decision.decision === "FAIL" || decision.decision === "ERROR"),
    );

    return {
      passed: blockingFailures.length === 0,
      decisions,
      blockingFailures,
    };
  }
}

export class FixedGatePolicy implements GatePolicy {
  constructor(
    private readonly defaultTimeoutSeconds = 3600,
    private readonly waivable = new Set<string>(),
  ) {}

  timeoutFor(_gate: string, _profile: string): number {
    return this.defaultTimeoutSeconds;
  }

  mayWaive(gate: string): boolean {
    return this.waivable.has(gate);
  }
}
