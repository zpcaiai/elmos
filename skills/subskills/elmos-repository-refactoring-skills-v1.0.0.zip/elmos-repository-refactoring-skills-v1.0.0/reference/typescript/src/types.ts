export type RiskClass = "R0" | "R1" | "R2" | "R3" | "R4" | "R5";
export type AdapterLevel = "L0" | "L1" | "L2" | "L3" | "L4";

export type RunStatus =
  | "QUEUED"
  | "RUNNING"
  | "PAUSING"
  | "PAUSED"
  | "BLOCKED_ENVIRONMENT"
  | "BLOCKED_APPROVAL"
  | "REPAIRING"
  | "ROLLING_OUT"
  | "ROLLING_BACK"
  | "FAILED_VALIDATION"
  | "FAILED_EVIDENCE"
  | "FAILED_ROLLBACK"
  | "CANCELLED"
  | "SUCCEEDED_PATCH_ONLY"
  | "PARTIAL_WITH_ROLLBACK"
  | "SUCCEEDED";

export type StepStatus =
  | "PENDING"
  | "READY"
  | "RUNNING"
  | "BLOCKED"
  | "REPAIRING"
  | "ROLLING_BACK"
  | "CANCELLED"
  | "FAILED"
  | "SUCCEEDED"
  | "ROLLED_BACK"
  | "SKIPPED";

export interface RepositoryRef {
  readonly uri: string;
  readonly revision: string;
  readonly subPath?: string;
  readonly role?: "primary" | "provider" | "consumer" | "shared" | "generated-client";
  readonly readOnly?: boolean;
}

export interface RefactorRequest {
  readonly apiVersion: "elmos.dev/v1";
  readonly kind: "RefactorRequest";
  readonly metadata: {
    readonly tenantId: string;
    readonly projectId: string;
    readonly requestId?: string;
  };
  readonly spec: {
    readonly repositories: readonly RepositoryRef[];
    readonly intent: {
      readonly type: string;
      readonly goals: readonly string[];
      readonly acceptanceCriteria?: readonly string[];
    };
    readonly constraints?: Readonly<Record<string, unknown>>;
    readonly execution: {
      readonly mode:
        | "analyze-only"
        | "proposal"
        | "supervised"
        | "autonomous-low-risk"
        | "fleet-wave";
      readonly maxParallelShards?: number;
    };
  };
}

export interface ValidationSpec {
  readonly gate: string;
  readonly blocking: boolean;
  readonly profile?: string;
}

export interface PlanStep {
  readonly stepId: string;
  readonly name: string;
  readonly skill: string;
  readonly dependsOn: readonly string[];
  readonly riskClass: RiskClass;
  readonly recipeRefs?: readonly string[];
  readonly inputs: readonly string[];
  readonly outputs: readonly string[];
  readonly readSet?: readonly string[];
  readonly writeSet?: readonly string[];
  readonly validation: readonly ValidationSpec[];
  readonly rollback?: {
    readonly strategy: "reverse-patch" | "snapshot-restore" | "compensation" | "forward-only";
    readonly handler?: string;
  };
  readonly budgets?: {
    readonly maxAttempts?: number;
    readonly maxCostUsd?: number;
    readonly timeoutSeconds?: number;
  };
}

export interface RefactorPlan {
  readonly apiVersion: "elmos.dev/v1";
  readonly kind: "RefactorPlan";
  readonly planId: string;
  readonly runId: string;
  readonly version: number;
  readonly snapshotDigests: Readonly<Record<string, string>>;
  readonly steps: readonly PlanStep[];
  readonly riskSummary: {
    readonly overallClass: RiskClass;
    readonly reasons: readonly string[];
    readonly unknownRiskWeight?: number;
  };
}

export interface ImmutableRunBindings {
  readonly requestDigest: string;
  readonly policyDigest: string;
  readonly planDigest: string;
  readonly recipeLockDigest: string;
  readonly adapterDigests: readonly string[];
  readonly toolchainDigests: readonly string[];
  readonly snapshotDigests: Readonly<Record<string, string>>;
}

export interface Checkpoint {
  readonly checkpointId: string;
  readonly runId: string;
  readonly stepId: string;
  readonly shardId: string;
  readonly sequence: number;
  readonly workspaceTreeDigest: string;
  readonly artifactManifestDigest: string;
  readonly sideEffectCursor: string;
  readonly createdAt: string;
}

export interface RunControl {
  readonly pauseRequested: boolean;
  readonly cancelRequested: boolean;
}

export interface StepExecutionResult {
  readonly status: "SUCCEEDED" | "BLOCKED" | "FAILED";
  readonly outputDigest?: string;
  readonly workspaceTreeDigest?: string;
  readonly artifactManifestDigest?: string;
  readonly failure?: FailureDescriptor;
}

export interface FailureDescriptor {
  readonly class:
    | "TRANSIENT_INFRA"
    | "ENVIRONMENT"
    | "DETERMINISTIC_TRANSFORM"
    | "VALIDATION"
    | "EVIDENCE"
    | "POLICY"
    | "STATE_DIVERGENCE"
    | "IRREVERSIBLE_SIDE_EFFECT";
  readonly signature: string;
  readonly message: string;
  readonly retryable: boolean;
  readonly details?: Readonly<Record<string, unknown>>;
}

export interface RunRecord {
  readonly runId: string;
  readonly status: RunStatus;
  readonly phase: string;
  readonly planVersion: number;
  readonly immutable: ImmutableRunBindings;
  readonly lastEventSequence: number;
  readonly progress: number;
}

export interface RunEvent {
  readonly eventId: string;
  readonly runId: string;
  readonly sequence: number;
  readonly type: string;
  readonly idempotencyKey: string;
  readonly stepId?: string;
  readonly shardId?: string;
  readonly payload: Readonly<Record<string, unknown>>;
  readonly occurredAt: string;
}
