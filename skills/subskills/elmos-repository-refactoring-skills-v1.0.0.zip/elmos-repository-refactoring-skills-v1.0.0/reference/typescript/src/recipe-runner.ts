import type {
  LanguageAdapter,
  PredicateQuery,
  PredicateResult,
  SemanticSnapshot,
  TransformAction,
  TransformResult,
} from "./adapter.js";
import type { RiskClass } from "./types.js";

export interface RecipePredicate {
  readonly id?: string;
  readonly type: string;
  readonly expression: string;
  readonly expected?: boolean | number | string;
  readonly onUnknown?: "fail" | "approval" | "skip";
  readonly message?: string;
}

export interface RefactorRecipe {
  readonly apiVersion: "elmos.dev/v1";
  readonly kind: "RefactorRecipe";
  readonly metadata: {
    readonly name: string;
    readonly version: string;
    readonly status: "draft" | "verified" | "certified" | "deprecated" | "revoked";
  };
  readonly spec: {
    readonly riskClass: RiskClass;
    readonly applicability: readonly RecipePredicate[];
    readonly preconditions: readonly RecipePredicate[];
    readonly negativeGuards: readonly RecipePredicate[];
    readonly actions: readonly TransformAction[];
    readonly postconditions: readonly RecipePredicate[];
    readonly validation: readonly {
      readonly gate: string;
      readonly profile: string;
      readonly blocking: boolean;
      readonly timeoutSeconds: number;
    }[];
    readonly rollback: {
      readonly strategy: "reverse-patch" | "snapshot-restore" | "compensation" | "forward-only";
    };
    readonly idempotence: {
      readonly secondRunExpectedDiff: "empty";
      readonly key: string;
    };
    readonly evidence: readonly string[];
  };
}

export interface RecipeExecutionInput {
  readonly runId: string;
  readonly stepId: string;
  readonly shardId: string;
  readonly inputTreeDigest: string;
  readonly recipeDigest: string;
  readonly parametersDigest: string;
  readonly parameters: Readonly<Record<string, unknown>>;
  readonly semanticSnapshot: SemanticSnapshot;
}

export interface RecipeExecutionOutput {
  readonly result: TransformResult;
  readonly predicateEvidence: readonly PredicateEvaluation[];
  readonly idempotencyKey: string;
}

export interface PredicateEvaluation {
  readonly phase: "applicability" | "precondition" | "negative-guard" | "postcondition";
  readonly expression: string;
  readonly result: PredicateResult;
}

export class ApprovalRequiredError extends Error {
  constructor(
    message: string,
    readonly predicate: RecipePredicate,
    readonly evidenceRefs: readonly string[],
  ) {
    super(message);
    this.name = "ApprovalRequiredError";
  }
}

export class RecipeRejectedError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "RecipeRejectedError";
  }
}

export class RecipeRunner {
  constructor(private readonly adapter: LanguageAdapter) {}

  async execute(recipe: RefactorRecipe, input: RecipeExecutionInput): Promise<RecipeExecutionOutput> {
    this.validateStaticRecipe(recipe);

    const evidence: PredicateEvaluation[] = [];
    await this.evaluatePredicates("applicability", recipe.spec.applicability, input, evidence);
    await this.evaluatePredicates("precondition", recipe.spec.preconditions, input, evidence);
    await this.evaluatePredicates("negative-guard", recipe.spec.negativeGuards, input, evidence);

    const idempotencyKey = [
      input.inputTreeDigest,
      input.recipeDigest,
      input.parametersDigest,
      input.shardId,
    ].join(":");

    const result = await this.adapter.apply(recipe.spec.actions, {
      runId: input.runId,
      stepId: input.stepId,
      shardId: input.shardId,
      idempotencyKey,
      expectedInputTreeDigest: input.inputTreeDigest,
      dryRun: false,
    });

    this.assertCardinality(recipe.spec.actions, result);
    await this.evaluatePredicates("postcondition", recipe.spec.postconditions, input, evidence);

    const secondRun = await this.adapter.apply(recipe.spec.actions, {
      runId: input.runId,
      stepId: input.stepId,
      shardId: input.shardId,
      idempotencyKey: `${idempotencyKey}:idempotence-check`,
      expectedInputTreeDigest: result.outputTreeDigest,
      dryRun: true,
    });
    if (!secondRun.patchEmpty) {
      throw new RecipeRejectedError(
        `Recipe ${recipe.metadata.name}@${recipe.metadata.version} is not idempotent`,
      );
    }

    return { result, predicateEvidence: evidence, idempotencyKey };
  }

  private async evaluatePredicates(
    phase: PredicateEvaluation["phase"],
    predicates: readonly RecipePredicate[],
    input: RecipeExecutionInput,
    evidence: PredicateEvaluation[],
  ): Promise<void> {
    for (const predicate of predicates) {
      const query: PredicateQuery = {
        expression: predicate.expression,
        parameters: input.parameters,
      };
      const result = await this.adapter.evaluate(input.semanticSnapshot, query);
      evidence.push({ phase, expression: predicate.expression, result });

      if (result.value === "unknown") {
        const action = predicate.onUnknown ?? "fail";
        if (action === "approval") {
          throw new ApprovalRequiredError(
            predicate.message ?? `Unknown predicate requires approval: ${predicate.expression}`,
            predicate,
            result.evidenceRefs,
          );
        }
        if (action === "skip") {
          continue;
        }
        throw new RecipeRejectedError(`Unknown predicate failed closed: ${predicate.expression}`);
      }

      const expected = predicate.expected ?? true;
      if (result.value !== expected) {
        throw new RecipeRejectedError(
          predicate.message ?? `Predicate rejected recipe: ${predicate.expression}`,
        );
      }
    }
  }

  private assertCardinality(
    actions: readonly TransformAction[],
    result: TransformResult,
  ): void {
    for (const action of actions) {
      const actual = result.matchedCountByAction[action.id];
      if (actual === undefined) {
        throw new RecipeRejectedError(`Adapter omitted cardinality for action ${action.id}`);
      }
      if (actual < action.expectedCardinality.min || actual > action.expectedCardinality.max) {
        throw new RecipeRejectedError(
          `Action ${action.id} cardinality ${actual} is outside ` +
            `[${action.expectedCardinality.min}, ${action.expectedCardinality.max}]`,
        );
      }
    }
  }

  private validateStaticRecipe(recipe: RefactorRecipe): void {
    if (recipe.metadata.status === "revoked" || recipe.metadata.status === "deprecated") {
      throw new RecipeRejectedError(`Recipe status ${recipe.metadata.status} cannot execute`);
    }
    const ids = new Set<string>();
    for (const action of recipe.spec.actions) {
      if (ids.has(action.id)) {
        throw new RecipeRejectedError(`Duplicate action id ${action.id}`);
      }
      ids.add(action.id);
      if (action.expectedCardinality.max < action.expectedCardinality.min) {
        throw new RecipeRejectedError(`Invalid cardinality range for action ${action.id}`);
      }
    }
    if (recipe.spec.actions.length === 0 || recipe.spec.postconditions.length === 0) {
      throw new RecipeRejectedError("A write recipe needs actions and postconditions");
    }
  }
}
