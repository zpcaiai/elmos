import type { AdapterLevel, FailureDescriptor, RiskClass } from "./types.js";

export interface AdapterDescriptor {
  readonly name: string;
  readonly version: string;
  readonly digest: string;
  readonly certificationLevel: AdapterLevel;
  readonly languages: readonly string[];
  readonly capabilities: Readonly<Record<string, "full" | "partial" | "none">>;
}

export interface AdapterProbe {
  readonly supported: boolean;
  readonly languageVersions: readonly string[];
  readonly buildSystems: readonly string[];
  readonly diagnostics: readonly string[];
}

export interface SemanticSnapshot {
  readonly snapshotId: string;
  readonly repositoryTreeDigest: string;
  readonly semanticIrDigest: string;
  readonly nativeIrDigest: string;
  readonly symbolResolutionCoverage: number;
  readonly typeAttributionCoverage: number;
}

export interface PredicateQuery {
  readonly expression: string;
  readonly parameters: Readonly<Record<string, unknown>>;
}

export interface PredicateResult {
  readonly value: boolean | "unknown";
  readonly evidenceRefs: readonly string[];
  readonly reason?: string;
}

export interface TransformAction {
  readonly id: string;
  readonly operation: string;
  readonly selector: Readonly<Record<string, unknown>>;
  readonly parameters: Readonly<Record<string, unknown>>;
  readonly expectedCardinality: {
    readonly min: number;
    readonly max: number;
  };
  readonly conflictPolicy: "fail" | "skip" | "merge";
  readonly formatPolicy: "preserve" | "touched-range" | "adapter-default";
}

export interface ApplyOptions {
  readonly runId: string;
  readonly stepId: string;
  readonly shardId: string;
  readonly idempotencyKey: string;
  readonly expectedInputTreeDigest: string;
  readonly dryRun: boolean;
}

export interface TransformResult {
  readonly matchedCountByAction: Readonly<Record<string, number>>;
  readonly changedFiles: readonly string[];
  readonly patchDigest: string;
  readonly patchEmpty: boolean;
  readonly outputTreeDigest: string;
  readonly evidenceRefs: readonly string[];
}

export interface AdapterValidationRequest {
  readonly runId: string;
  readonly stepId: string;
  readonly profile: string;
  readonly workspaceTreeDigest: string;
  readonly timeoutSeconds: number;
}

export interface AdapterValidationResult {
  readonly decision: "PASS" | "FAIL" | "ERROR" | "NOT_APPLICABLE";
  readonly summary: string;
  readonly evidenceRefs: readonly string[];
  readonly failure?: FailureDescriptor;
}

export interface RollbackRequest {
  readonly runId: string;
  readonly stepId: string;
  readonly strategy: "reverse-patch" | "snapshot-restore" | "compensation" | "forward-only";
  readonly inputTreeDigest: string;
  readonly outputTreeDigest: string;
}

export interface RollbackResult {
  readonly status: "SUCCEEDED" | "PARTIAL" | "FAILED";
  readonly restoredTreeDigest?: string;
  readonly evidenceRefs: readonly string[];
}

export interface LanguageAdapter {
  readonly descriptor: AdapterDescriptor;
  probe(repositoryPath: string): Promise<AdapterProbe>;
  index(repositoryPath: string, expectedTreeDigest: string): Promise<SemanticSnapshot>;
  evaluate(snapshot: SemanticSnapshot, query: PredicateQuery): Promise<PredicateResult>;
  apply(actions: readonly TransformAction[], options: ApplyOptions): Promise<TransformResult>;
  validate(request: AdapterValidationRequest): Promise<AdapterValidationResult>;
  rollback(request: RollbackRequest): Promise<RollbackResult>;
}

const LEVEL_ORDER: Readonly<Record<AdapterLevel, number>> = {
  L0: 0,
  L1: 1,
  L2: 2,
  L3: 3,
  L4: 4,
};

export function assertAdapterEligible(
  adapter: LanguageAdapter,
  minimumLevel: AdapterLevel,
  riskClass: RiskClass,
): void {
  if (LEVEL_ORDER[adapter.descriptor.certificationLevel] < LEVEL_ORDER[minimumLevel]) {
    throw new Error(
      `Adapter ${adapter.descriptor.name}@${adapter.descriptor.version} is ${adapter.descriptor.certificationLevel}; ${minimumLevel} required`,
    );
  }
  if (riskClass === "R4" || riskClass === "R5") {
    if (adapter.descriptor.certificationLevel !== "L4") {
      throw new Error(`Risk ${riskClass} requires an L4 adapter plus policy approval`);
    }
  }
}

export class AdapterRegistry {
  readonly #byLanguage = new Map<string, LanguageAdapter>();

  register(adapter: LanguageAdapter): void {
    if (!adapter.descriptor.digest.startsWith("sha256:")) {
      throw new Error("Adapter digest must be content-addressed with sha256:");
    }
    for (const language of adapter.descriptor.languages) {
      const existing = this.#byLanguage.get(language);
      if (existing !== undefined && existing.descriptor.digest !== adapter.descriptor.digest) {
        throw new Error(`Language adapter collision for ${language}`);
      }
      this.#byLanguage.set(language, adapter);
    }
  }

  require(language: string): LanguageAdapter {
    const adapter = this.#byLanguage.get(language);
    if (adapter === undefined) {
      throw new Error(`No registered adapter for language ${language}`);
    }
    return adapter;
  }
}
