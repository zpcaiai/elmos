# TypeScript Reference Skeleton

This directory is a dependency-free, strict TypeScript reference for the contracts that an Elmos production implementation should preserve. It deliberately does not pretend to be a complete runtime.

Included:

- language adapter contract and certification checks;
- deterministic recipe execution with predicates, cardinality and second-run idempotence;
- fail-closed verification engine;
- durable run/step state transitions, immutable binding checks, checkpoints, event idempotency and fenced leases;
- pause, resume, cancel and terminal-state handling.

Production substitutions:

- `DurableStore`: PostgreSQL implementation using the supplied migrations and transactional outbox;
- `LeaseManager`: Temporal activity fencing, database advisory/fencing locks, or an equivalent durable lease system;
- `StepExecutor`: sandbox workers, adapter registry, RecipeRunner and VerificationEngine;
- IDs and digests: UUIDv7/ULID plus cryptographic SHA-256; never use a non-cryptographic checksum for evidence or security;
- event publication: outbox to the selected event bus, deduplicated by event/idempotency key;
- approvals: digest-bound, expiring, signed approval records;
- evidence: content-addressed artifact store, SARIF, validation reports and signed manifest.

Validation:

```bash
cd reference/typescript
npm run typecheck
```

The reference code intentionally fails closed when immutable bindings drift, dependencies are incomplete, successful steps omit durable digests, plan cycles exist, adapter certification is insufficient, Recipe predicates are unknown, cardinality is outside bounds, or the second run is not empty.
