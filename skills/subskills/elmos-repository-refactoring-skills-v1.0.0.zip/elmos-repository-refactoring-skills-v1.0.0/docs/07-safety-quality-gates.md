# 07｜安全与质量门

## 7.1 Gate 层级

| Gate | 内容 | 默认阻断 |
|---|---|---|
| G0 Snapshot | revision、toolchain、lock、基线和 workspace 完整 | 是 |
| G1 Transform | preconditions、cardinality、冲突、幂等、determinism | 是 |
| G2 Syntax | parse、round-trip、format、generated source | 是 |
| G3 Semantic | typecheck、compile、link、symbol resolution | 是 |
| G4 Behavioral | unit/integration/contract/UI/differential | 是，按策略 |
| G5 Data & API | API/event/schema/config compatibility | 是 |
| G6 Quality | security、performance、reliability、license、SBOM | 高风险时是 |
| G7 Operational | canary、observability、rollback drill | 上线任务是 |
| G8 Evidence | provenance、audit、artifact 完整和签名 | 是 |

## 7.2 阻断规则

- 新增 compile/type error。
- 未批准的 public API break、Schema destructive change、消息不兼容。
- 测试失败净增；flaky 只能分类，不能视为 pass。
- 严重安全告警、密钥泄漏、许可证策略违规。
- P95/P99、吞吐、内存或成本越过任务 guardrail。
- patch 超出最大 changed files/LOC/scope，或出现高风险文件但未升级审批。
- 无法生成可靠 rollback。

## 7.3 兼容性

兼容不是单一布尔值。分别评估：source、binary、wire、behavior、data、operational 和 observability compatibility。用户允许某类 break 不等于允许其他 break。

## 7.4 验证覆盖分数

系统输出证据覆盖而不是“模型信心”：

```text
verificationScore = weighted(
  semanticResolution,
  compileCoverage,
  testImpactCoverage,
  contractCoverage,
  runtimeDifferentialCoverage,
  rollbackConfidence
) - unknownRiskPenalty
```

分数只用于决策提示；任何硬门失败都不能被高分抵消。

## 7.5 反作弊

Verifier 检测以下可疑变化：删除/跳过测试、扩大 exclude、降低 lint/error severity、吞异常、返回常量、mock 生产路径、移除安全检查、放宽 auth、增加无限 retry、禁用超时、关闭 migration validation。命中后至少升级为 R4 并阻断自治。
