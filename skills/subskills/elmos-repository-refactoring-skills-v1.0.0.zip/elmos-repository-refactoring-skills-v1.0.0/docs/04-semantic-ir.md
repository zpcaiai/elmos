# 04｜Semantic IR 与 Change IR

## 4.1 设计目标

统一 IR 不能牺牲语言原生语义。Elmos 采用“共享核心 + 语言扩展”：共享核心用于跨语言规划、影响分析与审计；每个 Adapter 可保存 native payload reference，以执行精确变换。

## 4.2 共享实体

- Repository、Module、BuildTarget、SourceFile、GeneratedFile。
- Symbol：namespace/package/module/type/function/method/property/field/variable/macro/template/schema object。
- TypeRef：nominal/structural/generic/union/intersection/nullability/ownership/lifetime/dynamic。
- Relationship：declares、references、calls、overrides、implements、inherits、imports、exports、reads、writes、publishes、subscribes、serializes、persists、tests、owns。
- Contract：HTTP/gRPC/GraphQL/event/SDK/database/config/file-format。
- RuntimeEvidence：trace span、metric、log signature、profile edge、coverage edge。

每个实体至少包含：稳定 ID、repo revision、adapter/version、language、source range、confidence、content hash 和 provenance。

## 4.3 稳定标识

优先使用语义 ID：`repo + module + fully-qualified-symbol + signature + language`。局部符号附加 enclosing symbol 与 lexical ordinal。文件移动后通过内容/符号指纹重关联；不得仅用行号作为身份。

## 4.4 Change IR 动作

基础动作：

- `RenameSymbol`
- `MoveSymbol` / `MoveFile` / `MoveModule`
- `ChangeSignature`
- `AddParameterWithDefault`
- `IntroduceType` / `ExtractInterface`
- `ReplaceCall`
- `WrapWithAdapter`
- `InlineSymbol` / `ExtractSymbol`
- `UpdateDependency`
- `UpdateBuildTarget`
- `UpdateContract`
- `ExpandContractSchema` / `BackfillData` / `ContractSchema`
- `GenerateCompatibilityLayer`
- `DeleteDeadCode`

组合动作必须声明顺序、临时兼容态和最终不变量。

## 4.5 查询

Impact Analyzer 至少支持：

```text
references(symbol)
callers(symbol, depth)
consumers(contract)
buildTargets(files)
tests(symbols | targets)
owners(files | symbols)
dataFlows(source, sink)
changeClosure(actions, compatibilityPolicy)
unknownRegions(scope)
```

## 4.6 IR 质量

- `resolutionCoverage`：可解析引用占比。
- `typeAttributionCoverage`：具有有效类型信息的语义节点占比。
- `buildGraphCoverage`：文件可映射到构建目标的占比。
- `testLinkCoverage`：变更符号可映射到测试/coverage 的占比。
- `unknownRiskWeight`：未知区域按关键度加权，不得简单平均。

自治执行需同时满足 Adapter 认证阈值与任务级 IR 覆盖阈值。
