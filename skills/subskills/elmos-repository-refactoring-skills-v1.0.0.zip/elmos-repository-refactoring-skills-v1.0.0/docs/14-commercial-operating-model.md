# 14｜商业运营模型

## 14.1 产品套餐

- **Assessment**：仓库扫描、架构/债务/风险图、重构候选与 wall-clock/成本区间。
- **Migration Project**：按里程碑执行并以质量门结果交付。
- **Continuous Modernization**：持续依赖、框架、安全和规范治理。
- **Enterprise Fleet**：多仓库波次、私有 Recipe、审批、审计、SLA 与私有部署。

## 14.2 计费单位

- Repo/LOC/Build Target 只用于预估，不作为唯一价值单位。
- 可计费事件：完成语义索引、认证 Plan、成功 Recipe execution、通过验证门、完成 rollout。
- 重试因平台缺陷导致时不重复收费；因用户仓库新增变更导致的 rebase/replan 单独计量。

## 14.3 企业信任

- 在执行前展示最大费用、wall-clock P50/P80/P95、风险和退出点。
- 每个费用项映射到 stage/step/evidence。
- 支持客户自带模型、工具、Runner 与私有制品库；Domain Pack 不绑定单一模型供应商。
