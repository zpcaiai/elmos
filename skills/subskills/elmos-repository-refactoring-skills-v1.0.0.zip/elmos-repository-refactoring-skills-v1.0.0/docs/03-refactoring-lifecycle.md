# 03｜端到端重构生命周期

## Phase 0：请求规范化

- 解析目标、非目标、约束、兼容策略、完成定义和预算。
- 把自然语言断言编译为可检查的 predicates。
- 固定仓库 revision、submodule、LFS、生成代码和工具链版本。
- 计算初始风险；R5 直接阻断执行但继续生成诊断报告。

## Phase 1：仓库发现与可重复环境

- 建立语言、模块、构建目标、依赖、测试、所有权、生成代码和敏感区清单。
- 在洁净 sandbox 中执行“未修改基线”：restore、build、test、lint、scan、benchmark（按策略）。
- 基线失败时分为：环境失败、既有失败、非确定性、外部依赖失败；不得把既有失败误记为重构回归。

## Phase 2：语义索引

- 原生编译器解析、类型归属、符号引用、调用图、继承、数据流、配置引用、API 和 Schema。
- 建立 `symbol -> files -> build targets -> tests -> owners -> runtime signals` 链路。
- 对解析不完整区标记 confidence/unknown，不把 unknown 当作无影响。

## Phase 3：意图编译与方案搜索

- 生成一个或多个候选 Plan，比较变更规模、风险、兼容成本、运行时成本和回滚复杂度。
- 选择最小安全变更，不追求一次性“完美重写”。
- 大型架构改造默认使用 Strangler、branch-by-abstraction、expand-contract 和 feature flag。

## Phase 4：影响分析与波次

- 计算静态变更闭包、动态消费者、数据依赖和组织所有权。
- 把步骤构成 DAG；可独立步骤并行，有共享 symbol/file/build target 的步骤串行或加锁。
- 多仓库变更按 provider-before-consumer、compatibility-window 和 rollback domain 分 wave。

## Phase 5：Recipe 锁定与 Dry Run

- 从 Registry 选择签名 Recipe；无现成 Recipe 时生成候选并先运行 Golden/negative tests。
- 产出 `recipes.lock`，固定 recipe、adapter、parser、compiler、formatter 和 dependency metadata。
- Dry-run 输出 patch、冲突、预计 changed files、风险变化与验证计划。

## Phase 6：确定性执行

- 每个 shard 在独立 worktree 执行；先校验 preconditions，再执行 edit，再校验局部 postconditions。
- Patch fragment 以 source span 和 symbol identity 对齐；合并器检测重叠 edit、rename/move 冲突和 generated-source 冲突。
- 任何 scope expansion 重新进入影响分析，不允许悄悄扩散。

## Phase 7：渐进验证

顺序默认如下：

1. Parse/round-trip/no-op diff。
2. Format/import/compile/typecheck。
3. Recipe unit 与 changed-target tests。
4. Contract/API/Schema/event compatibility。
5. 全量或策略要求的集成、UI、性能、安全和可靠性测试。
6. 差分运行、影子流量或 canary。

越早失败越便宜；后置高成本门不能代替前置确定性门。

## Phase 8：有界自动修复

- 依据失败签名定位 owning step/recipe/shard。
- 允许修复缺失 import、类型适配、测试 fixture、兼容 adapter 等与目标直接相关的问题。
- 禁止删除测试、降低安全规则、吞异常、扩大 catch、添加全局 ignore 或修改无关模块。
- 超过 repair budget、出现同类循环失败或风险升级时进入人工审批。

## Phase 9：交付、灰度与回滚

- 生成 PR/changeset、迁移说明、release note、依赖顺序和回滚手册。
- 数据/消息/API 采用兼容窗口；可用 feature flag 或流量比例灰度。
- 监控错误率、延迟、资源、业务 guardrail；越界自动停止或回滚。

## Phase 10：证据与学习

- 封装 EvidenceBundle，签名 manifest。
- 成功 Recipe 记录适用范围和统计；失败样本进入 quarantine，不能直接晋级通用 Recipe。
- 更新 ETA、风险和成本模型，但保留模型版本，确保历史任务可解释。
