# 11｜数据模型

核心关系：

```text
refactor_programs 1---n refactor_runs 1---n refactor_plan_steps
refactor_runs 1---n refactor_repository_snapshots
refactor_plan_steps 1---n refactor_step_attempts
refactor_step_attempts 1---n refactor_artifacts
refactor_runs 1---n refactor_recipe_executions
refactor_runs 1---n refactor_validations
refactor_runs 1---n refactor_approvals
refactor_runs 1---n refactor_checkpoints
refactor_runs 1---n refactor_evidence_records
```

## 11.1 一致性

- `run` 固定 request、policy、revision、toolchain、adapter 和 recipe lock；修改这些字段必须创建新 run 或正式 replan version。
- `step_attempt` 追加写；最终状态由事件折叠，避免覆盖历史。
- Artifact 以 digest 去重但 tenant 隔离授权。
- Checkpoint 同时记录 DB state version 与 artifact manifest，防止只恢复一半。

## 11.2 大对象

源码、AST、patch、日志和报告保存在对象存储；Postgres 只保存 URI、digest、size、media type、encryption key ref 和 retention class。

## 11.3 成本与收入

每个 stage/step/attempt 记录 model/tool/compute/storage/network 成本和 billable unit。支持预充 credit、订阅、按项目、按成功门或企业合同，不把失败重试全部隐蔽转嫁给用户。

SQL 见 `db/migrations/`。
