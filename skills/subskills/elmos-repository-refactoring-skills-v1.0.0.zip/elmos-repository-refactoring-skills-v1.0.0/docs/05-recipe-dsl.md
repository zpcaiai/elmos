# 05｜Recipe DSL

## 5.1 Recipe 是可验证程序

Recipe 由声明式控制面和可选的受沙箱约束插件组成。声明式部分决定适用性、输入、动作、验证、证据和风险；插件只实现 Adapter 不能直接表达的原生变换。

## 5.2 必需字段

```yaml
apiVersion: elmos.dev/v1
kind: RefactorRecipe
metadata:
  name: rename-symbol
  version: 1.0.0
  digest: sha256:...
spec:
  languages: [java, kotlin]
  riskClass: R2
  applicability: []
  inputs: {}
  preconditions: []
  negativeGuards: []
  select: {}
  actions: []
  postconditions: []
  validation: []
  rollback: {}
  idempotence: {}
  evidence: []
```

## 5.3 匹配规则

匹配应从强到弱：symbol ID/type signature > compiler query > CST pattern > token pattern > exact text。每个 fallback 都要降低 confidence，并可能提高审批等级。

## 5.4 Preconditions 与 Negative Guards

示例：

- 目标符号只有一个定义且解析覆盖率满足阈值。
- 新名称在目标 scope 不冲突。
- 不修改 generated/vendor/third_party 文件。
- 不触及反射字符串、序列化字段或外部契约，除非 Recipe 同时处理。
- 不在宏展开、动态加载或模板生成路径中盲目修改。

## 5.5 Actions

Action 必须指定：selector、operation、parameters、expected match cardinality、conflict policy、format policy、source map policy。`expected cardinality` 与实际不符时默认失败，不能继续“尽量改”。

## 5.6 Postconditions

- 旧符号引用为零，或仅存在于允许的兼容层/文档。
- 新符号定义唯一且所有引用可解析。
- no-op formatter 不产生额外大范围 diff。
- 第二次运行 patch 为空。
- Recipe 声明的 API/Schema/behavior predicates 成立。

## 5.7 多周期 Recipe

跨 Schema/API 的 Recipe 可有 `prepare -> migrate -> verify -> contract` 周期。每一周期都是独立 release-safe 状态，可暂停数天或数周；不能要求一次部署完成所有破坏性步骤。

## 5.8 Recipe 晋级

`draft -> quarantined -> verified -> certified -> deprecated/revoked`。只有 certified Recipe 可在自治模式运行；任何严重逃逸缺陷会撤销签名并阻断旧版本。
