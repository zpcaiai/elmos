# 08｜大型仓库扩展设计

## 8.1 目标

面向 500k–10M+ LOC、数十万文件、复杂 monorepo 与多仓库项目。SLO 必须绑定硬件、工具链和任务类型，不能用单一“每秒 LOC”宣传所有重构。

## 8.2 内容寻址与增量

缓存键至少包含：repo tree hash、submodule/LFS hash、build graph hash、compiler/toolchain lock、adapter digest、parser grammar digest、recipe lock、policy digest。只复用完全相容的索引分片。

## 8.3 分片

- 首选按 build target/module/package 分片，而不是平均按文件数。
- 对共享 symbol、公共 header、宏、基础类型、root tsconfig 等建立高扇出热区，单独串行处理。
- 只读索引可并行；修改 shard 必须声明 read/write set。
- Patch 合并采用语义冲突 + source range 冲突双检测。

## 8.4 调度

调度优先级考虑 critical path、risk、cache locality、worker capability、memory estimate、tool license 和 approval。大型编译器 Worker 与轻量 CST Worker 分池，避免资源互相挤压。

## 8.5 内存与落盘

- 大型 AST/LST 不跨服务直接序列化；持久化压缩语义索引和 source maps。
- 支持 spill-to-disk、分区扫描和 bounded query。
- 对高扇出符号使用倒排索引；对图遍历限制深度、节点数和超时并返回 truncation evidence。

## 8.6 ETA

ETA 模型按阶段估计：restore、index、plan、transform、compile、tests、security、canary。输入包括仓库规模、build targets、语言、cache hit、历史相似任务、worker 数、测试时长和 flaky 率。输出 P50/P80/P95 wall-clock 区间，明确排除人工人天。

## 8.7 大仓库完成策略

- changed-target fast gate 后仍保留 full gate 计划。
- 采用小 patch series；每个 changeset 可独立编译/部署/回滚。
- 超大迁移通过 compatibility layer 和 waves 逐步收敛，不一次生成不可审阅的巨型 diff。
