# 06｜语言适配器契约

## 6.1 接口

每个 Adapter 必须实现：

- `probe`：识别语言、版本、构建系统、工具链和能力等级。
- `restore`：恢复依赖和编译环境，输出 lock 与 provenance。
- `parse`：生成 lossless syntax snapshot，报告 error recovery。
- `index`：导出 symbols/types/references/calls/contracts/build targets。
- `query`：执行语义查询和影响分析。
- `lower`：把 Change IR 转为 native edits。
- `apply`：原子应用 edit，返回 source maps 和 patch fragments。
- `format`：只格式化 touched ranges/files，遵守仓库配置。
- `validate`：parse/type/build/test/lint/compatibility。
- `rollback`：反演或恢复到 checkpoint。

## 6.2 能力声明

Adapter 不能只返回 `supported=true`，必须给出 capability map：

```yaml
capabilities:
  losslessRoundTrip: true
  symbolResolution: full
  typeAttribution: full
  rename: repository
  moveSymbol: repository
  changeSignature: repository
  dataflow: intraprocedural
  callGraph: conservative
  macroAwareness: partial
  generatedCodeAwareness: full
```

## 6.3 编译环境

- 使用固定 compiler/runtime/tool version。
- 读取真实 build graph，不以目录结构猜模块边界。
- 解析 classpath/module path/compile_commands/tsconfig/project references/workspaces。
- baseline 不可构建时输出 degraded mode，禁止需要完整语义的动作。

## 6.4 格式保持

Adapter 必须有 no-op round-trip 测试：不做动作时输出字节完全相同，或仅允许配置声明的标准化差异。若原生 printer 无法保持格式，使用 token/CST 拼接或最小 text edit，而不是重印整个文件。

## 6.5 Generated/Vendor 处理

默认不修改生成物和 vendored code；修改源模板、IDL 或 generator，然后重新生成。生成器必须在受限环境执行，输出与工具链一起记录。

## 6.6 认证

L4 认证包括：Golden corpus、negative corpus、real repository replay、幂等、确定性、并发分片、故障注入、资源限制、安全沙箱、1M+ LOC 基准和逃逸缺陷率门。
