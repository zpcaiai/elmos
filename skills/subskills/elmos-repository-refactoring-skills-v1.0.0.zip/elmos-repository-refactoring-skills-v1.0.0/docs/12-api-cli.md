# 12｜API 与 CLI

## 12.1 API 资源

- `POST /v1/refactor-programs`
- `POST /v1/refactor-runs`
- `GET /v1/refactor-runs/{runId}`
- `POST /v1/refactor-runs/{runId}:pause|resume|cancel|replan|rollback`
- `GET /v1/refactor-runs/{runId}/plan`
- `GET /v1/refactor-runs/{runId}/diff`
- `GET /v1/refactor-runs/{runId}/evidence`
- `POST /v1/refactor-runs/{runId}/approvals`
- `GET /v1/recipes` / `POST /v1/recipes:validate`
- `GET /v1/adapters` / `POST /v1/adapters/{name}:certify`

完整定义见 `contracts/openapi.yaml`。

## 12.2 CLI

```text
elmos refactor analyze request.yaml
elmos refactor plan request.yaml --out plan.json
elmos refactor run request.yaml --mode supervised
elmos refactor status <run-id> --watch
elmos refactor approve <run-id> <gate-id>
elmos refactor pause|resume|cancel|rollback <run-id>
elmos refactor evidence <run-id> --verify-signature
elmos recipe test recipes/java/spring-boot-2-to-3.yaml
elmos adapter certify java --suite production
```

CLI 输出同时支持 human、json、ndjson；长任务进度来自持久化事件，不依赖本地进程存活。
