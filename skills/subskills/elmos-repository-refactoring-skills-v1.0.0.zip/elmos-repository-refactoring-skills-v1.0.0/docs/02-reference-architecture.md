# 02｜参考架构

```mermaid
flowchart LR
    U[User / API / UI] --> G[Refactor Gateway]
    G --> O[Refactor Orchestrator]
    O --> P[Policy & Approval]
    O --> D[Repository Discovery]
    D --> B[Build Graph Resolver]
    D --> I[Semantic Index Service]
    I --> PG[(Semantic Graph Store)]
    O --> IC[Intent Compiler]
    IC --> IA[Impact Analyzer]
    IA --> RS[Recipe Synthesizer & Registry]
    RS --> EX[Transform Executor Pool]
    EX --> SB[Ephemeral Sandboxes / Worktrees]
    EX --> LW[Language Adapter Workers]
    LW --> C[Compiler / LSP / CST / Native Tools]
    O --> V[Verification Harness]
    V --> AR[Bounded Auto-Repair]
    V --> EV[Evidence Builder]
    O --> RO[Canary / PR / Rollout]
    O --> RR[Rollback & Recovery]
    O --> ST[(Postgres State Store)]
    O --> AS[(Artifact Store)]
    O --> OT[OpenTelemetry]
```

## 2.1 控制平面

`Refactor Orchestrator` 负责状态、依赖、预算、策略、checkpoint 和补偿，不负责解析具体语言。建议由 Temporal 类持久化工作流承载；每个 Activity 必须定义：

- 幂等键：`tenant/run/step/shard/attempt-class`。
- 输入快照哈希与输出 artifact hash。
- heartbeat、超时、重试策略和不可重试错误。
- 补偿操作和 side-effect journal。
- 最大模型调用、CPU、内存、网络、磁盘和 wall-clock 预算。

## 2.2 数据平面

语言 Worker 以不可变输入快照工作，输出 `SemanticDelta`、`PatchFragment`、诊断和工具证据。Worker 不直接修改主分支、不拥有审批权、不自行扩大作用域。

优先级顺序：

1. **Compiler-native semantic adapter**：完整 symbol/type/resolve/rename/refactor 能力。
2. **Lossless/CST adapter**：保持注释和格式，处理语法级批量改写。
3. **Structural matcher**：声明式模式匹配和 rewrite，适合跨语言通用规则。
4. **Text adapter**：仅文档、模板或精确配置，必须有严格 guard 和 round-trip 验证。

## 2.3 三层 IR

- **Native IR**：语言原生 AST/PSI/LST、类型和编译器对象；精度最高，不跨 Worker 持久化复杂对象。
- **Elmos Semantic IR**：稳定、版本化、可跨语言查询的符号/依赖/契约模型。
- **Change IR**：语言无关的目标动作，如 RenameSymbol、MoveModule、ChangeSignature、IntroduceAdapter、ExpandContractColumn；由 Adapter lower 为原生 edit。

## 2.4 存储

- Postgres：任务、计划、状态、审批、指标、artifact 元数据和计费。
- 对象存储：源码快照、索引分片、patch、日志、测试、SARIF、证据和回滚包。
- 图/列式索引：可由 Postgres + pgvector/图扩展起步，超大规模可替换为专用图与列式查询层。
- 缓存：内容寻址，以 repo tree hash、toolchain lock、adapter version、build graph hash、recipe lock 为 key。

## 2.5 信任边界

仓库内容、构建脚本、编译器插件、测试、生成器和依赖安装都可能执行不可信代码。索引阶段与执行阶段使用不同权限；默认禁止网络、生产凭据、宿主 Docker Socket 和跨租户缓存读取。
