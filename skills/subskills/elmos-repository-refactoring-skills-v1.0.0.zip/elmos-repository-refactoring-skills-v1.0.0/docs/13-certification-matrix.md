# 13｜适配器与 Recipe 生产认证

## 13.1 认证维度

1. Parse 与 lossless round-trip。
2. 符号、类型、引用、调用、继承与 build graph 精度。
3. Rename/move/change-signature/extract/replace 等核心动作。
4. Generated code、宏、反射、动态加载、模板与混合语言边界。
5. 幂等、确定性、冲突检测和最小 diff。
6. Baseline/build/test/contract/security/performance 验证。
7. 大仓库吞吐、峰值内存、增量缓存和分片合并。
8. 超时、Worker crash、网络中断、磁盘满、编译器崩溃等恢复。
9. 沙箱、权限、依赖和供应链安全。
10. 真实仓库 replay 与逃逸缺陷审计。

## 13.2 等级门

| 等级 | 要求 | 允许模式 |
|---|---|---|
| L1 | Golden 语法改写 + round-trip | proposal/supervised |
| L2 | 项目内 symbol/type + compile | supervised |
| L3 | repo/build/test/contract + 大仓库基础 | supervised/fleet with approval |
| L4 | 全套生产认证 + 真实 replay + 故障注入 | autonomous-low-risk |

## 13.3 Recipe 测试

每条 Recipe 至少包含 positive、negative、already-migrated、ambiguous、conflict、generated-code、formatting、idempotence、rollback 和 version-boundary fixtures。
