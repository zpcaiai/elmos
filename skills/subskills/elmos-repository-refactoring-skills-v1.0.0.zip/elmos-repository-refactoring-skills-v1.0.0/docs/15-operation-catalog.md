# 15｜跨语言仓库级重构操作目录

本目录规定 Elmos 可以表达的“变更意图”，并说明何时允许自动执行。它不把所有语言强行压成同一种 AST：统一的是 Change IR、风险、验证和证据；语言语义仍由 Native Adapter 裁决。

## 15.1 通用 Change IR 操作

| 操作族 | 典型操作 | 默认风险 | 最低能力 |
|---|---|---:|---:|
| Symbol | RenameSymbol、MoveSymbol、ChangeVisibility、ReplaceReference | R2–R3 | L2 |
| Signature | Add/Remove/ReorderParameter、ChangeReturnType、IntroduceOverload/Adapter | R3 | L2/L3 |
| Structure | Extract/Inline Method/Class/Module、Split/Merge Module、Move Package/Namespace | R3 | L3 |
| Dependency | IntroduceInterface、InvertDependency、BreakCycle、ReplaceLibrary、UpgradeDependency | R3–R4 | L3 |
| Architecture | LayerBoundary、DomainExtraction、StranglerFacade、ServiceSplit/Merge | R3–R4 | L3/L4 |
| Runtime | LanguageUpgrade、FrameworkUpgrade、SyncToAsync、ConcurrencyModel、ErrorModel | R3–R4 | L3/L4 |
| Contract | REST/gRPC/GraphQL/Event/SDK/Config versioning and compatibility adapters | R3–R4 | L3/L4 |
| Data | Expand/Migrate/Contract、ORM mapping、query rewrite、CDC/index/cache migration | R4 | L4 |
| UI/Client | Component/state/router/network/design-system refactor、cross-platform client change | R3 | L3 |
| Quality | DeadCode、DuplicateConsolidation、Testability、Observability、Security/Performance | R2–R4 | L2–L4 |
| Build/Delivery | Build graph、workspace、module、CI、container、deployment interface refactor | R3–R4 | L3 |

每个操作在 lower 前必须解析成：目标实体身份、作用域、读写集、适用条件、负向守卫、预期 cardinality、兼容策略、验证闭包和回滚方式。

## 15.2 JVM：Java、Kotlin、Groovy、Scala

重点能力：package/module 移动、类型/方法/字段重命名、overload 与泛型签名、继承/接口抽取、annotation 迁移、Spring/Jakarta/JPA/Gradle/Maven 升级、协程/异步和模块拆分。

强制边界：

- annotation processor、KSP/KAPT、Lombok 和 generated source 先识别源生成链。
- Java reflection、Spring bean name、JPA entity/table/column、Jackson/序列化名称和配置字符串不是普通文本引用。
- Kotlin extension、inline/reified、coroutine、multiplatform `expect/actual` 由 K2/编译器语义处理。
- Scala implicit/given、macro、typeclass 和 binary compatibility 需要专项 adapter/validator。
- 公共库升级执行 API 与 binary compatibility diff；不能只以源码编译成功判断。

## 15.3 .NET：C#、VB.NET、F#

重点能力：solution/project 级 symbol rename、namespace/assembly 拆分、nullable migration、async/await、DI、ASP.NET、EF Core、MSBuild 和 package upgrade。

强制边界：

- Roslyn/MSBuild Workspace 是 C#/VB 的语义权威；F# 通过 FSharp.Compiler.Service，能力单独声明。
- source generator、partial type、conditional compilation、reflection、XAML binding 和 serializer contract 需要全项目分析。
- public assembly 变化执行 API/binary compatibility 检查；strong name、InternalsVisibleTo、COM interop 单独评估。
- EF migration 与数据库 contract 进入 R4，不从实体重命名直接推导破坏性 DDL。

## 15.4 Python

重点能力：package/module 移动、import graph、符号 rename、typing modernization、decorator/API 迁移、sync-to-async、framework/packaging upgrade。

强制边界：

- LibCST 保持格式和注释，`ast`/类型检查器/运行探针补充语义。
- `getattr`/`setattr`、动态 import、monkey patch、metaclass、descriptor、decorator 注册和字符串入口点形成 unknown risk。
- `__all__`、entry points、pickle/import path、ORM/serializer 字段可能是外部契约。
- async 改造必须传播到调用闭包，处理 event loop、context manager、iterator、transaction 和 cancellation。
- 缺少类型信息时，禁止把静态推断“高置信”伪装成完整语义覆盖。

## 15.5 JavaScript、TypeScript、React、Vue、Node.js

重点能力：tsconfig/project references/workspaces、ESM/CJS 迁移、exports/imports、类型/接口、React/Vue 状态与组件、Node framework 和构建工具升级。

强制边界：

- TypeScript Program/Language Service 是符号和类型权威；Babel/SWC/Vue SFC AST 只负责其语法层。
- dynamic import、computed property、decorator、reflect metadata、webpack/Vite alias、package exports 和 runtime require 进入 unknown risk。
- React hooks 迁移验证生命周期、effect dependency、concurrency 和 rendering behavior。
- Vue Options→Composition 验证 reactivity、watch/computed、provide/inject、template refs 和 SFC source maps。
- 前端仓库增加视觉、可访问性、bundle、hydration 和 E2E 门；不能只运行 TypeScript 编译。

## 15.6 Go

重点能力：package 移动、interface extraction、error wrapping、context propagation、module/workspace、goroutine/channel 和 API 迁移。

强制边界：

- 使用 `go/packages`、`go/types`、gopls 与真实 build tags；不同 GOOS/GOARCH/tag 组合分别建图。
- interface satisfaction 是隐式的，变更方法集必须扫描实现者和消费者。
- `init`、linkname、reflection、plugin、cgo 和 generated code 需要专项守卫。
- 并发改造验证 goroutine 泄漏、channel close ownership、context cancellation、race 和 benchmark。

## 15.7 Rust

重点能力：crate/module 移动、trait/error type、API modernization、feature flags、async runtime、ownership/unsafe 收敛和 dependency upgrade。

强制边界：

- rust-analyzer/cargo metadata/rustc diagnostics 联合，按 feature/target/profile 建立配置矩阵。
- macro_rules/procedural macro、build.rs、cfg、unsafe、FFI 和 generated binding 不可按普通 AST 推断。
- public crate 变化验证 semver/API；trait、lifetime、auto trait 和 coherence 变化可能扩大影响闭包。
- async runtime 迁移验证 Send/Sync、pinning、cancellation、blocking boundary 和资源生命周期。

## 15.8 C、C++

重点能力：symbol/signature、header/module、namespace、template、API/ABI、raw pointer ownership、build system 和 standard upgrade。

强制边界：

- 基于真实 `compile_commands.json`/build graph；单文件 AST 不代表仓库语义。
- macro、conditional compilation、template instantiation、ADL、overload、generated header、C linkage 和 platform ABI 单独建模。
- pointer→smart pointer 必须证明 ownership、aliasing、lifetime、custom deleter、FFI 和 exception boundary。
- public library 变化执行 ABI、symbol/export 和布局检查；跨平台 target 分别验证。
- clang format 只作用于 touched ranges，避免全仓噪声。

## 15.9 PHP、Ruby

重点能力：autoload/package/module、namespace/class/method、framework upgrade、typing、dependency injection、ORM 和 test modernization。

强制边界：

- PHP 的 Composer autoload、magic methods、attributes/annotations、reflection、dynamic calls 和 templates；Ruby 的 open classes、metaprogramming、method_missing、autoload、Rails conventions 形成保守边界。
- 使用 PHP-Parser/Prism/Parser 保持源码，PHPStan/Psalm、RBS/Sorbet 提升语义覆盖。
- 动态调用无法消歧时必须进入 approval 或 runtime evidence，不得做全局字符串替换。

## 15.10 Swift、Objective-C

重点能力：module/type/method、SwiftSyntax、async/await、SwiftPM/Xcode、Objective-C selector、bridging 和 Apple 平台 SDK 升级。

强制边界：

- SwiftSyntax 保持 source-accurate tree，SourceKit/编译器提供符号与类型。
- Objective-C selector、runtime message、KVC/KVO、storyboard/xib、Core Data、`NSClassFromString` 和 bridging header 是契约边界。
- Swift/Objective-C 混编修改需要同时验证 generated interface、module map、ABI/API、availability 和 deployment target。

## 15.11 Dart、Flutter

重点能力：package/library、widget/state、router、network/domain layer、null-safety、async、plugin 和 Flutter SDK upgrade。

强制边界：

- Dart analyzer/Analysis Server 提供语义；Flutter tooling 提供 widget/test/build 证据。
- state management 迁移验证 rebuild scope、lifecycle、navigation、deep link、persistence 和 platform channel。
- UI 重构必须增加 golden/visual、semantics/accessibility、integration 和性能门。

## 15.12 SQL、数据、配置与 IaC

这些不是“附属文本”。SQL 需按方言和 catalog；Terraform 需 provider schema/state；Kubernetes 需 CRD/OpenAPI；YAML/JSON/XML 需 schema；Shell 需 shell parser 和 ShellCheck。

破坏性数据、权限、网络、生产部署和 secret 相关变化默认 R4/R5，要求独立审批、真实 validator、灰度和回滚/前滚证据。

## 15.13 自动化决策

- L0：只分析，不生成可合并 patch。
- L1：只做有 exact round-trip 的语法级低风险操作。
- L2：项目内 symbol/type 安全操作，必须 compile/test。
- L3：仓库级结构、构建、契约和测试闭包，默认 supervised。
- L4：通过真实仓库、故障注入、大仓库和确定性认证后，策略可开放低风险自治。

任务风险取“操作风险、语言动态性、覆盖缺口、外部契约、数据/安全影响、回滚难度”的最大值，而不是按修改行数平均。
