# 09｜可观测性、SLO 与成本

## 9.1 Trace

根 Span：`refactor.run`；子 Span：discover、restore、index、plan、recipe、transform、verify、repair、approval、rollout、rollback、evidence。所有 Span 关联 tenant、program、run、step、shard、repo、revision、adapter、recipe 和 attempt。

禁止把源码、密钥或完整 prompt 放入 span attribute；只记录 hash、大小、分类和安全摘要。

## 9.2 关键指标

- `refactor_runs_total{status,risk,mode}`
- `refactor_stage_duration_seconds{stage}`
- `refactor_files_changed_total{language,recipe}`
- `refactor_patch_bytes_total`
- `refactor_recipe_matches_total{outcome}`
- `refactor_validation_failures_total{gate,signature}`
- `refactor_auto_repair_attempts_total{outcome}`
- `refactor_checkpoint_recoveries_total`
- `refactor_cache_hit_ratio{cache}`
- `refactor_semantic_resolution_ratio{language}`
- `refactor_test_impact_coverage_ratio`
- `refactor_cost_usd{model,tool,stage}`
- `refactor_wall_clock_eta_error_ratio{quantile}`

## 9.3 SLO

生产 SLO 不写死虚假速度；由 `hardware profile + repo class + task class` 组成。最低平台 SLO：

- 状态持久化成功率 ≥ 99.99%。
- 已 heartbeat Activity 的 checkpoint 恢复成功率 ≥ 99.9%。
- 重复执行副作用率 = 0。
- 成功任务 EvidenceBundle 完整率 = 100%。
- 自治任务硬门逃逸率目标 = 0；一旦发现自动撤销相关 Recipe/Adapter 认证。
- ETA 持续报告 P50/P80/P95，并监控 calibration，不只报告点估计。

## 9.4 成本

成本拆分为模型 token、编译/测试 CPU、sandbox 内存与磁盘、对象存储、网络、第三方扫描器和人工审批。每个 PlanStep 有预算，超预算先降级非必要分析，再暂停等待策略，而不是无限重试。
