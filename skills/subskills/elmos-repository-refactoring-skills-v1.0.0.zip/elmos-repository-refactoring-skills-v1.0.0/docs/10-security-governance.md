# 10｜安全、权限与治理

## 10.1 威胁模型

- 仓库中的 prompt injection、恶意脚本、编译器插件、测试和生成器。
- 依赖投毒、typosquatting、锁文件篡改和构建下载。
- 路径穿越、符号链接逃逸、Docker socket、宿主凭据与云元数据访问。
- 多租户缓存/日志/对象存储泄漏。
- 模型生成恶意 patch 或把安全回归包装成“兼容修复”。

## 10.2 控制

- sandbox 非 root、只挂载工作区、seccomp/AppArmor、资源和进程限制。
- 默认无网络；restore 使用可审计代理、allowlist、内容校验和内部镜像。
- 工具白名单与参数级权限；禁止任意 shell 拼接。
- 凭据短期、按任务、按 repo、按 action scope；不暴露给模型。
- 生成补丁经过 secrets、SAST、dependency、license、IaC 和 policy scan。
- 审批采用 four-eyes，可对高风险 Recipe、目标文件、数据库阶段和生产 wave 单独授权。

## 10.3 治理对象

Recipe、Adapter、Policy、Toolchain、Prompt、Model、Evaluation Set 都需版本化和签名。执行证据保存实际 digest，而不是只记名称。

## 10.4 数据保留

源代码和 patch 的保留期由租户策略决定；遥测默认只留哈希和聚合指标。删除请求必须覆盖对象存储、缓存、索引、日志和备份索引，并保留不可反推源码的审计 tombstone。
