# Language Adapter Implementation Guide

## 1. 引擎选择

- JVM：Java 以 OpenRewrite LST/类型归属与 JDT 编译能力为主；Kotlin 走 K2 Analysis API/PSI；Scala 通过编译器或 SemanticDB。跨 JVM 共享 Change IR，但 lowering 分语言。
- .NET：以 Roslyn `Solution/Project/Document`、SemanticModel、SymbolFinder、CodeFix/Refactoring API 和 MSBuild Workspace 为主；F# 只在 FCS 能证明的范围执行。
- Python：LibCST 保留注释与格式，CPython AST/类型工具补语义；动态 import、反射、monkey patch 和字符串协议必须提高 unknown risk。
- Go：`go/packages` 恢复模块，`go/types`/gopls 负责符号与重构，`gofmt` 只处理 touched files。
- Rust：rust-analyzer 负责 assists/引用，Cargo metadata 和 rustc/clippy 负责真实构建；宏与 cfg/feature 组合必须多配置验证。
- C/C++/Objective-C：必须取得可靠 `compile_commands.json`；Clang LibTooling/Transformer/ASTMatchers 实施精确变换，宏和模板区域默认保守。
- JS/TS：TypeScript Program/Language Service 提供全项目语义；Vue SFC、JSX/TSX、framework compiler 和 source maps 作为扩展层。
- Swift：SwiftSyntax 保持 source-accurate tree，SourceKit/编译器补符号语义；Objective-C 复用 Clang。
- PHP/Ruby：格式保持解析器 + 可选类型工具；动态特性引起的 unknown 不能被隐藏。
- SQL：解析器必须方言化，并读取真实 catalog、migration history、query consumers；仅靠 SQL 文本不足以决定在线安全。

## 2. 适配器发布

1. 构建 OCI/WASM/JVM/.NET artifact，生成 SBOM 和不可变 digest。
2. 运行 contract tests、Golden corpus、real-repo replay、性能与故障注入。
3. 把签名认证结果写入 Adapter Registry；描述文件中的 `L0` 仅表示本包不伪造已实现认证。
4. Orchestrator 在运行时读取 Registry 的真实等级覆盖描述文件。

## 3. 混合语言仓库

一个文件只由一个 primary adapter 负责写；其他 adapter 可提供只读引用。跨语言动作通过 Contract/Change IR 协调，禁止两个 Worker 对同一 source range 并发修改。
