BEGIN;

CREATE TABLE IF NOT EXISTS refactor_evidence_bundles (
    bundle_id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id            text NOT NULL,
    run_id               uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    bundle_status        text NOT NULL CHECK (bundle_status IN ('BUILDING','COMPLETE','PARTIAL','INVALID','REVOKED')),
    bundle_uri           text,
    bundle_digest        text,
    manifest_uri         text,
    manifest_digest      text,
    signature_algorithm  text,
    signature_key_id     text,
    signature_value      text,
    schema_version       text NOT NULL DEFAULT '1.0.0',
    redaction_summary    jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at           timestamptz NOT NULL DEFAULT now(),
    completed_at         timestamptz,
    UNIQUE(run_id, bundle_digest)
);

CREATE TABLE IF NOT EXISTS refactor_evidence_records (
    evidence_record_id   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id            text NOT NULL,
    run_id               uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    bundle_id            uuid REFERENCES refactor_evidence_bundles(bundle_id) ON DELETE CASCADE,
    evidence_type        text NOT NULL,
    subject_type         text NOT NULL,
    subject_id           text NOT NULL,
    decision             text,
    summary              jsonb NOT NULL DEFAULT '{}'::jsonb,
    artifact_id          uuid REFERENCES refactor_artifacts(artifact_id) ON DELETE SET NULL,
    provenance           jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at           timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_refactor_evidence_subject
ON refactor_evidence_records(run_id, subject_type, subject_id, evidence_type);

CREATE TABLE IF NOT EXISTS refactor_patch_hunks (
    patch_hunk_id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id            text NOT NULL,
    run_id               uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    repository_snapshot_id uuid NOT NULL REFERENCES refactor_repository_snapshots(snapshot_id) ON DELETE CASCADE,
    path_before          text,
    path_after           text,
    old_start_line       integer,
    old_line_count       integer,
    new_start_line       integer,
    new_line_count       integer,
    hunk_digest          text NOT NULL,
    step_id              text NOT NULL,
    recipe_execution_id  uuid REFERENCES refactor_recipe_executions(recipe_execution_id) ON DELETE SET NULL,
    action_id            text,
    symbol_ids           text[] NOT NULL DEFAULT '{}',
    created_at           timestamptz NOT NULL DEFAULT now(),
    UNIQUE(run_id, hunk_digest)
);

CREATE TABLE IF NOT EXISTS refactor_hunk_validation_links (
    patch_hunk_id        uuid NOT NULL REFERENCES refactor_patch_hunks(patch_hunk_id) ON DELETE CASCADE,
    validation_id        uuid NOT NULL REFERENCES refactor_validations(validation_id) ON DELETE CASCADE,
    coverage_kind        text NOT NULL CHECK (coverage_kind IN ('DIRECT','TARGET','CONTRACT','RUNTIME','ROLLBACK','MANUAL')),
    confidence           numeric(6,5) NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    PRIMARY KEY(patch_hunk_id, validation_id, coverage_kind)
);

CREATE TABLE IF NOT EXISTS refactor_recipe_registry (
    recipe_name          text NOT NULL,
    recipe_version       text NOT NULL,
    recipe_digest        text NOT NULL,
    status               text NOT NULL CHECK (status IN ('DRAFT','QUARANTINED','VERIFIED','CERTIFIED','DEPRECATED','REVOKED')),
    risk_class           text NOT NULL CHECK (risk_class IN ('R1','R2','R3','R4','R5')),
    languages            text[] NOT NULL,
    frameworks           text[] NOT NULL DEFAULT '{}',
    recipe_uri           text NOT NULL,
    owner                text NOT NULL,
    signature_key_id     text,
    signature_value      text,
    certified_at         timestamptz,
    revoked_at           timestamptz,
    revocation_reason    text,
    metadata             jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at           timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY(recipe_name, recipe_version),
    UNIQUE(recipe_digest)
);

CREATE TABLE IF NOT EXISTS refactor_recipe_evaluations (
    evaluation_id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    recipe_digest        text NOT NULL REFERENCES refactor_recipe_registry(recipe_digest) ON DELETE CASCADE,
    suite_name           text NOT NULL,
    suite_digest         text NOT NULL,
    adapter_digest       text NOT NULL,
    toolchain_digest     text NOT NULL,
    positive_passed      integer NOT NULL DEFAULT 0,
    positive_total       integer NOT NULL DEFAULT 0,
    negative_passed      integer NOT NULL DEFAULT 0,
    negative_total       integer NOT NULL DEFAULT 0,
    deterministic        boolean NOT NULL,
    idempotent           boolean NOT NULL,
    rollback_passed      boolean NOT NULL,
    escape_defects       integer NOT NULL DEFAULT 0,
    metrics              jsonb NOT NULL DEFAULT '{}'::jsonb,
    report_uri           text NOT NULL,
    report_digest        text NOT NULL,
    evaluated_at         timestamptz NOT NULL DEFAULT now(),
    UNIQUE(recipe_digest, suite_digest, adapter_digest, toolchain_digest)
);

CREATE TABLE IF NOT EXISTS refactor_adapter_registry (
    adapter_name         text NOT NULL,
    adapter_version      text NOT NULL,
    adapter_digest       text NOT NULL,
    certification_level  text NOT NULL CHECK (certification_level IN ('L0','L1','L2','L3','L4')),
    languages            text[] NOT NULL,
    capabilities         jsonb NOT NULL,
    artifact_uri         text NOT NULL,
    sbom_uri             text,
    signature_key_id     text,
    signature_value      text,
    status               text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','DEPRECATED','REVOKED')),
    certified_at         timestamptz,
    revoked_at           timestamptz,
    metadata             jsonb NOT NULL DEFAULT '{}'::jsonb,
    PRIMARY KEY(adapter_name, adapter_version),
    UNIQUE(adapter_digest)
);

CREATE TABLE IF NOT EXISTS refactor_rollout_waves (
    wave_execution_id    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id            text NOT NULL,
    run_id               uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    wave_id               text NOT NULL,
    repository_scope     jsonb NOT NULL DEFAULT '[]'::jsonb,
    target_environment   text,
    traffic_fraction     numeric(7,6) CHECK (traffic_fraction BETWEEN 0 AND 1),
    status               text NOT NULL CHECK (status IN ('PENDING','RUNNING','PAUSED','SUCCEEDED','FAILED','ROLLED_BACK','SKIPPED')),
    guardrail_snapshot   jsonb NOT NULL DEFAULT '{}'::jsonb,
    report_uri           text,
    started_at           timestamptz,
    completed_at         timestamptz,
    UNIQUE(run_id, wave_id)
);

CREATE TABLE IF NOT EXISTS refactor_rollback_executions (
    rollback_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id            text NOT NULL,
    run_id               uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    checkpoint_id        uuid REFERENCES refactor_checkpoints(checkpoint_id) ON DELETE SET NULL,
    scope                jsonb NOT NULL,
    strategy             text NOT NULL CHECK (strategy IN ('REVERSE_PATCH','SNAPSHOT_RESTORE','COMPENSATION','FORWARD_FIX')),
    reason               text NOT NULL,
    status               text NOT NULL CHECK (status IN ('REQUESTED','RUNNING','SUCCEEDED','FAILED','PARTIAL')),
    side_effect_journal  jsonb NOT NULL DEFAULT '[]'::jsonb,
    report_uri           text,
    started_at           timestamptz,
    completed_at         timestamptz,
    created_at           timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS refactor_metric_samples (
    sample_id            bigserial PRIMARY KEY,
    tenant_id            text NOT NULL,
    run_id               uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    step_id              text,
    shard_id             text,
    metric_name          text NOT NULL,
    metric_value         double precision NOT NULL,
    unit                 text,
    attributes           jsonb NOT NULL DEFAULT '{}'::jsonb,
    observed_at          timestamptz NOT NULL DEFAULT now()
) PARTITION BY RANGE(observed_at);

-- Production should create monthly partitions ahead of time. This default partition prevents ingestion loss.
CREATE TABLE IF NOT EXISTS refactor_metric_samples_default
PARTITION OF refactor_metric_samples DEFAULT;

ALTER TABLE refactor_evidence_bundles ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_evidence_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_patch_hunks ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_rollout_waves ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_rollback_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_metric_samples ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'refactor_evidence_bundles','refactor_evidence_records','refactor_patch_hunks',
    'refactor_rollout_waves','refactor_rollback_executions','refactor_metric_samples'
  ] LOOP
    EXECUTE format('DROP POLICY IF EXISTS tenant_isolation ON %I', t);
    EXECUTE format(
      'CREATE POLICY tenant_isolation ON %I USING (tenant_id = current_setting(''app.tenant_id'', true)) WITH CHECK (tenant_id = current_setting(''app.tenant_id'', true))', t
    );
  END LOOP;
END $$;

CREATE OR REPLACE VIEW refactor_run_quality_summary AS
SELECT
    r.tenant_id,
    r.run_id,
    r.status,
    r.risk_class,
    count(v.validation_id) FILTER (WHERE v.blocking) AS blocking_gate_count,
    count(v.validation_id) FILTER (WHERE v.blocking AND v.decision = 'PASS') AS blocking_gate_pass_count,
    count(v.validation_id) FILTER (WHERE v.blocking AND v.decision IN ('FAIL','ERROR')) AS blocking_gate_fail_count,
    count(DISTINCT h.patch_hunk_id) AS patch_hunk_count,
    count(DISTINCT l.patch_hunk_id) AS validated_hunk_count,
    CASE WHEN count(DISTINCT h.patch_hunk_id) = 0 THEN 1.0
         ELSE count(DISTINCT l.patch_hunk_id)::numeric / count(DISTINCT h.patch_hunk_id) END AS hunk_evidence_coverage
FROM refactor_runs r
LEFT JOIN refactor_validations v ON v.run_id = r.run_id
LEFT JOIN refactor_patch_hunks h ON h.run_id = r.run_id
LEFT JOIN refactor_hunk_validation_links l ON l.patch_hunk_id = h.patch_hunk_id
GROUP BY r.tenant_id, r.run_id, r.status, r.risk_class;

COMMIT;
