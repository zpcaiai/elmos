BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS refactor_programs (
    program_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           text NOT NULL,
    account_id          text NOT NULL,
    name                text NOT NULL,
    description         text,
    status              text NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE','PAUSED','COMPLETED','CANCELLED','FAILED')),
    labels              jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_by          text NOT NULL,
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, program_id)
);

CREATE TABLE IF NOT EXISTS refactor_tenant_quotas (
    tenant_id              text NOT NULL,
    account_id             text NOT NULL,
    max_concurrent_runs    integer NOT NULL DEFAULT 3 CHECK (max_concurrent_runs BETWEEN 1 AND 100),
    max_parallel_shards    integer NOT NULL DEFAULT 32 CHECK (max_parallel_shards BETWEEN 1 AND 1024),
    monthly_cost_limit_usd numeric(18,6),
    updated_at             timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant_id, account_id)
);

CREATE TABLE IF NOT EXISTS refactor_runs (
    run_id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    program_id           uuid REFERENCES refactor_programs(program_id) ON DELETE SET NULL,
    tenant_id            text NOT NULL,
    account_id           text NOT NULL,
    request_id           text,
    request_digest       text NOT NULL,
    request_json         jsonb NOT NULL,
    policy_digest        text NOT NULL,
    policy_json          jsonb NOT NULL,
    plan_version         integer NOT NULL DEFAULT 0 CHECK (plan_version >= 0),
    mode                 text NOT NULL CHECK (mode IN ('analyze-only','proposal','supervised','autonomous-low-risk','fleet-wave')),
    risk_class           text NOT NULL DEFAULT 'R0' CHECK (risk_class IN ('R0','R1','R2','R3','R4','R5')),
    status               text NOT NULL DEFAULT 'QUEUED'
                         CHECK (status IN ('QUEUED','RUNNING','PAUSING','PAUSED','BLOCKED_ENVIRONMENT','BLOCKED_APPROVAL','REPAIRING','ROLLING_OUT','ROLLING_BACK','FAILED_VALIDATION','FAILED_EVIDENCE','FAILED_ROLLBACK','CANCELLED','SUCCEEDED_PATCH_ONLY','PARTIAL_WITH_ROLLBACK','SUCCEEDED')),
    phase                text NOT NULL DEFAULT 'RECEIVED',
    concurrency_slot     integer CHECK (concurrency_slot IS NULL OR concurrency_slot > 0),
    progress             numeric(6,5) NOT NULL DEFAULT 0 CHECK (progress BETWEEN 0 AND 1),
    eta_p50_seconds      bigint CHECK (eta_p50_seconds IS NULL OR eta_p50_seconds >= 0),
    eta_p80_seconds      bigint CHECK (eta_p80_seconds IS NULL OR eta_p80_seconds >= 0),
    eta_p95_seconds      bigint CHECK (eta_p95_seconds IS NULL OR eta_p95_seconds >= 0),
    estimated_cost_usd   numeric(18,6) CHECK (estimated_cost_usd IS NULL OR estimated_cost_usd >= 0),
    actual_cost_usd      numeric(18,6) NOT NULL DEFAULT 0 CHECK (actual_cost_usd >= 0),
    cancel_requested_at  timestamptz,
    pause_requested_at   timestamptz,
    started_at           timestamptz,
    completed_at         timestamptz,
    created_by           text NOT NULL,
    created_at           timestamptz NOT NULL DEFAULT now(),
    updated_at           timestamptz NOT NULL DEFAULT now(),
    last_event_sequence  bigint NOT NULL DEFAULT 0,
    UNIQUE (tenant_id, request_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_refactor_active_slot
ON refactor_runs(tenant_id, account_id, concurrency_slot)
WHERE concurrency_slot IS NOT NULL
  AND status IN ('QUEUED','RUNNING','PAUSING','PAUSED','BLOCKED_ENVIRONMENT','BLOCKED_APPROVAL','REPAIRING','ROLLING_OUT','ROLLING_BACK');

CREATE INDEX IF NOT EXISTS ix_refactor_runs_tenant_status
ON refactor_runs(tenant_id, account_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS refactor_repository_snapshots (
    snapshot_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id               uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    tenant_id            text NOT NULL,
    repository_role      text NOT NULL DEFAULT 'primary',
    repository_uri_hash  text NOT NULL,
    revision             text NOT NULL,
    tree_digest          text NOT NULL,
    submodule_digest     text,
    lfs_digest           text,
    inventory_uri        text,
    inventory_digest     text,
    build_graph_uri      text,
    build_graph_digest   text,
    semantic_index_uri   text,
    semantic_index_digest text,
    toolchain_lock_uri   text,
    toolchain_lock_digest text,
    resolution_coverage  numeric(6,5) CHECK (resolution_coverage BETWEEN 0 AND 1),
    type_coverage        numeric(6,5) CHECK (type_coverage BETWEEN 0 AND 1),
    build_coverage       numeric(6,5) CHECK (build_coverage BETWEEN 0 AND 1),
    test_link_coverage   numeric(6,5) CHECK (test_link_coverage BETWEEN 0 AND 1),
    created_at           timestamptz NOT NULL DEFAULT now(),
    UNIQUE(run_id, repository_uri_hash, revision)
);

CREATE TABLE IF NOT EXISTS refactor_plan_versions (
    run_id              uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    tenant_id           text NOT NULL,
    version             integer NOT NULL CHECK (version > 0),
    plan_digest         text NOT NULL,
    plan_json           jsonb NOT NULL,
    recipes_lock_digest text,
    recipes_lock_uri    text,
    risk_class          text NOT NULL CHECK (risk_class IN ('R0','R1','R2','R3','R4','R5')),
    estimated_json      jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_by          text NOT NULL,
    created_at          timestamptz NOT NULL DEFAULT now(),
    superseded_at       timestamptz,
    PRIMARY KEY(run_id, version),
    UNIQUE(run_id, plan_digest)
);

CREATE TABLE IF NOT EXISTS refactor_plan_steps (
    run_id              uuid NOT NULL,
    plan_version        integer NOT NULL,
    tenant_id           text NOT NULL,
    step_id             text NOT NULL,
    name                text NOT NULL,
    skill_name          text NOT NULL,
    risk_class          text NOT NULL CHECK (risk_class IN ('R0','R1','R2','R3','R4','R5')),
    dependencies        text[] NOT NULL DEFAULT '{}',
    read_set            jsonb NOT NULL DEFAULT '[]'::jsonb,
    write_set           jsonb NOT NULL DEFAULT '[]'::jsonb,
    scope_json          jsonb NOT NULL DEFAULT '{}'::jsonb,
    budget_json         jsonb NOT NULL DEFAULT '{}'::jsonb,
    validation_json     jsonb NOT NULL DEFAULT '[]'::jsonb,
    status              text NOT NULL DEFAULT 'PENDING'
                        CHECK (status IN ('PENDING','READY','RUNNING','BLOCKED','REPAIRING','ROLLING_BACK','CANCELLED','FAILED','SUCCEEDED','ROLLED_BACK','SKIPPED')),
    started_at          timestamptz,
    completed_at        timestamptz,
    PRIMARY KEY(run_id, plan_version, step_id),
    FOREIGN KEY(run_id, plan_version) REFERENCES refactor_plan_versions(run_id, version) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS ix_refactor_steps_ready
ON refactor_plan_steps(run_id, plan_version, status);

CREATE TABLE IF NOT EXISTS refactor_step_attempts (
    attempt_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id              uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    tenant_id           text NOT NULL,
    plan_version        integer NOT NULL,
    step_id             text NOT NULL,
    shard_id            text NOT NULL DEFAULT 'default',
    attempt_number      integer NOT NULL CHECK (attempt_number > 0),
    idempotency_key     text NOT NULL,
    worker_id           text,
    adapter_name        text,
    adapter_digest      text,
    recipe_lock_digest  text,
    input_digest        text NOT NULL,
    output_digest       text,
    status              text NOT NULL DEFAULT 'SCHEDULED'
                        CHECK (status IN ('SCHEDULED','RUNNING','HEARTBEATING','SUCCEEDED','FAILED_RETRYABLE','FAILED_TERMINAL','CANCELLED','TIMED_OUT','ROLLED_BACK')),
    failure_class       text,
    failure_signature   text,
    failure_detail      jsonb,
    started_at          timestamptz,
    heartbeat_at        timestamptz,
    completed_at        timestamptz,
    cpu_seconds         numeric(18,6) NOT NULL DEFAULT 0,
    peak_memory_mib     integer,
    disk_bytes          bigint NOT NULL DEFAULT 0,
    model_tokens_in     bigint NOT NULL DEFAULT 0,
    model_tokens_out    bigint NOT NULL DEFAULT 0,
    cost_usd            numeric(18,6) NOT NULL DEFAULT 0,
    UNIQUE(run_id, plan_version, step_id, shard_id, attempt_number),
    UNIQUE(idempotency_key)
);

CREATE INDEX IF NOT EXISTS ix_refactor_attempts_heartbeat
ON refactor_step_attempts(status, heartbeat_at)
WHERE status IN ('RUNNING','HEARTBEATING');

CREATE TABLE IF NOT EXISTS refactor_events (
    event_id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           text NOT NULL,
    run_id              uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    sequence            bigint NOT NULL CHECK (sequence > 0),
    event_type          text NOT NULL,
    step_id             text,
    shard_id            text,
    idempotency_key     text,
    correlation_id      text,
    causation_id        text,
    payload             jsonb NOT NULL DEFAULT '{}'::jsonb,
    occurred_at         timestamptz NOT NULL DEFAULT now(),
    UNIQUE(run_id, sequence),
    UNIQUE(run_id, idempotency_key)
);

CREATE INDEX IF NOT EXISTS ix_refactor_events_timeline
ON refactor_events(run_id, sequence);

CREATE TABLE IF NOT EXISTS refactor_checkpoints (
    checkpoint_id       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           text NOT NULL,
    run_id              uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    plan_version        integer NOT NULL,
    step_id             text NOT NULL,
    shard_id            text NOT NULL DEFAULT 'default',
    checkpoint_sequence bigint NOT NULL CHECK (checkpoint_sequence >= 0),
    state_version       bigint NOT NULL CHECK (state_version >= 0),
    workspace_tree_digest text NOT NULL,
    artifact_manifest_digest text NOT NULL,
    artifact_manifest_uri text NOT NULL,
    side_effect_cursor  bigint NOT NULL CHECK (side_effect_cursor >= 0),
    resume_token_ciphertext bytea,
    created_at          timestamptz NOT NULL DEFAULT now(),
    expires_at          timestamptz,
    UNIQUE(run_id, step_id, shard_id, checkpoint_sequence)
);

CREATE INDEX IF NOT EXISTS ix_refactor_checkpoint_latest
ON refactor_checkpoints(run_id, step_id, shard_id, checkpoint_sequence DESC);

CREATE TABLE IF NOT EXISTS refactor_artifacts (
    artifact_id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           text NOT NULL,
    run_id              uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    attempt_id          uuid REFERENCES refactor_step_attempts(attempt_id) ON DELETE SET NULL,
    artifact_type       text NOT NULL,
    media_type          text NOT NULL,
    uri                 text NOT NULL,
    digest              text NOT NULL,
    size_bytes          bigint NOT NULL CHECK (size_bytes >= 0),
    encryption_key_ref  text,
    retention_class     text NOT NULL DEFAULT 'standard',
    redacted            boolean NOT NULL DEFAULT false,
    metadata            jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at          timestamptz NOT NULL DEFAULT now(),
    deleted_at          timestamptz,
    UNIQUE(tenant_id, digest, artifact_type, uri)
);

CREATE INDEX IF NOT EXISTS ix_refactor_artifacts_run_type
ON refactor_artifacts(run_id, artifact_type, created_at DESC);

CREATE TABLE IF NOT EXISTS refactor_recipe_executions (
    recipe_execution_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           text NOT NULL,
    run_id              uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    attempt_id          uuid NOT NULL REFERENCES refactor_step_attempts(attempt_id) ON DELETE CASCADE,
    recipe_name         text NOT NULL,
    recipe_version      text NOT NULL,
    recipe_digest       text NOT NULL,
    action_id           text,
    match_count         bigint NOT NULL DEFAULT 0 CHECK (match_count >= 0),
    changed_file_count  bigint NOT NULL DEFAULT 0 CHECK (changed_file_count >= 0),
    patch_digest        text,
    deterministic       boolean,
    idempotent          boolean,
    status              text NOT NULL CHECK (status IN ('MATCHED','APPLIED','NOOP','FAILED','ROLLED_BACK')),
    evidence_uri        text,
    created_at          timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS refactor_validations (
    validation_id       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           text NOT NULL,
    run_id              uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    attempt_id          uuid REFERENCES refactor_step_attempts(attempt_id) ON DELETE SET NULL,
    gate_name           text NOT NULL,
    profile             text,
    blocking            boolean NOT NULL,
    decision            text NOT NULL CHECK (decision IN ('PASS','FAIL','WAIVED','NOT_APPLICABLE','ERROR')),
    baseline_status     text,
    candidate_status    text,
    summary             jsonb NOT NULL DEFAULT '{}'::jsonb,
    report_uri          text,
    report_digest       text,
    waiver_approval_id  uuid,
    started_at          timestamptz,
    completed_at        timestamptz,
    created_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_refactor_validations_run_gate
ON refactor_validations(run_id, gate_name, created_at DESC);

CREATE TABLE IF NOT EXISTS refactor_approvals (
    approval_id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           text NOT NULL,
    run_id              uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    gate_id             text NOT NULL,
    decision            text NOT NULL CHECK (decision IN ('PENDING','APPROVE','REJECT','REQUEST_CHANGES','APPROVE_WITH_CONDITIONS','EXPIRED','INVALIDATED')),
    required_roles      text[] NOT NULL DEFAULT '{}',
    actor_subject       text,
    actor_roles         text[] NOT NULL DEFAULT '{}',
    bound_request_digest text NOT NULL,
    bound_plan_digest   text NOT NULL,
    bound_recipe_lock_digest text NOT NULL,
    bound_patch_digest  text NOT NULL,
    conditions          jsonb NOT NULL DEFAULT '[]'::jsonb,
    reason              text,
    signature           text,
    requested_at        timestamptz NOT NULL DEFAULT now(),
    decided_at          timestamptz,
    expires_at          timestamptz,
    invalidated_at      timestamptz
);

CREATE INDEX IF NOT EXISTS ix_refactor_approvals_pending
ON refactor_approvals(run_id, decision, expires_at)
WHERE decision = 'PENDING';

CREATE TABLE IF NOT EXISTS refactor_cost_ledger (
    ledger_id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           text NOT NULL,
    account_id          text NOT NULL,
    run_id              uuid NOT NULL REFERENCES refactor_runs(run_id) ON DELETE CASCADE,
    attempt_id          uuid REFERENCES refactor_step_attempts(attempt_id) ON DELETE SET NULL,
    stage               text NOT NULL,
    cost_type           text NOT NULL CHECK (cost_type IN ('MODEL','COMPUTE','MEMORY','DISK','STORAGE','NETWORK','TOOL_LICENSE','APPROVAL','OTHER')),
    provider            text,
    units               numeric(24,8) NOT NULL DEFAULT 0,
    unit_name           text,
    amount_usd          numeric(18,6) NOT NULL CHECK (amount_usd >= 0),
    billable            boolean NOT NULL DEFAULT true,
    metadata            jsonb NOT NULL DEFAULT '{}'::jsonb,
    occurred_at         timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_refactor_cost_run
ON refactor_cost_ledger(run_id, occurred_at);

CREATE TABLE IF NOT EXISTS refactor_outbox (
    outbox_id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           text NOT NULL,
    aggregate_type      text NOT NULL,
    aggregate_id        text NOT NULL,
    event_type          text NOT NULL,
    payload             jsonb NOT NULL,
    idempotency_key     text NOT NULL UNIQUE,
    created_at          timestamptz NOT NULL DEFAULT now(),
    published_at        timestamptz,
    publish_attempts    integer NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS ix_refactor_outbox_unpublished
ON refactor_outbox(created_at)
WHERE published_at IS NULL;

CREATE OR REPLACE FUNCTION refactor_set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_refactor_programs_updated_at ON refactor_programs;
CREATE TRIGGER trg_refactor_programs_updated_at
BEFORE UPDATE ON refactor_programs
FOR EACH ROW EXECUTE FUNCTION refactor_set_updated_at();

DROP TRIGGER IF EXISTS trg_refactor_runs_updated_at ON refactor_runs;
CREATE TRIGGER trg_refactor_runs_updated_at
BEFORE UPDATE ON refactor_runs
FOR EACH ROW EXECUTE FUNCTION refactor_set_updated_at();

CREATE OR REPLACE FUNCTION refactor_claim_concurrency_slot(
    p_tenant_id text,
    p_account_id text,
    p_run_id uuid
) RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
    v_limit integer;
    v_slot integer;
BEGIN
    PERFORM pg_advisory_xact_lock(hashtextextended(p_tenant_id || ':' || p_account_id, 0));

    SELECT max_concurrent_runs INTO v_limit
      FROM refactor_tenant_quotas
     WHERE tenant_id = p_tenant_id AND account_id = p_account_id;

    IF v_limit IS NULL THEN
        INSERT INTO refactor_tenant_quotas(tenant_id, account_id)
        VALUES (p_tenant_id, p_account_id)
        ON CONFLICT DO NOTHING;
        v_limit := 3;
    END IF;

    FOR v_slot IN 1..v_limit LOOP
        IF NOT EXISTS (
            SELECT 1 FROM refactor_runs
             WHERE tenant_id = p_tenant_id
               AND account_id = p_account_id
               AND concurrency_slot = v_slot
               AND status IN ('QUEUED','RUNNING','PAUSING','PAUSED','BLOCKED_ENVIRONMENT','BLOCKED_APPROVAL','REPAIRING','ROLLING_OUT','ROLLING_BACK')
               AND run_id <> p_run_id
        ) THEN
            UPDATE refactor_runs
               SET concurrency_slot = v_slot
             WHERE run_id = p_run_id
               AND tenant_id = p_tenant_id
               AND account_id = p_account_id;
            IF FOUND THEN RETURN v_slot; END IF;
        END IF;
    END LOOP;

    RAISE EXCEPTION USING
      ERRCODE = 'P0001',
      MESSAGE = 'REFRACTOR_CONCURRENCY_LIMIT_REACHED',
      DETAIL = format('tenant=%s account=%s limit=%s', p_tenant_id, p_account_id, v_limit);
END;
$$;

CREATE OR REPLACE FUNCTION refactor_release_concurrency_slot(p_run_id uuid)
RETURNS void LANGUAGE sql AS $$
    UPDATE refactor_runs SET concurrency_slot = NULL WHERE run_id = p_run_id;
$$;

ALTER TABLE refactor_programs ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_repository_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_plan_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_plan_steps ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_step_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_checkpoints ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_artifacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_recipe_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_validations ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE refactor_cost_ledger ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'refactor_programs','refactor_runs','refactor_repository_snapshots','refactor_plan_versions',
    'refactor_plan_steps','refactor_step_attempts','refactor_events','refactor_checkpoints',
    'refactor_artifacts','refactor_recipe_executions','refactor_validations','refactor_approvals','refactor_cost_ledger'
  ] LOOP
    EXECUTE format('DROP POLICY IF EXISTS tenant_isolation ON %I', t);
    EXECUTE format(
      'CREATE POLICY tenant_isolation ON %I USING (tenant_id = current_setting(''app.tenant_id'', true)) WITH CHECK (tenant_id = current_setting(''app.tenant_id'', true))', t
    );
  END LOOP;
END $$;

COMMIT;
