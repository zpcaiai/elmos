# Persistence Notes

- Migration 使用 Postgres 15+；生产建议 17+。
- API 每次事务开始先执行 `SET LOCAL app.tenant_id = '<tenant>'`，RLS 才会返回租户数据。
- `refactor_claim_concurrency_slot` 在事务内以 advisory lock 分配账号并发槽；默认上限为 3，符合 Elmos 长任务并发要求。
- Event、Attempt、Cost Ledger 和 Evidence 均追加写；不要覆盖历史记录。
- 对象存储中的 artifact 必须先写成功并得到 digest，再提交引用它的 checkpoint。
- `refactor_metric_samples` 应按月创建分区并设置保留策略；默认分区只用于防止采集丢失。
