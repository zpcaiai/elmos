-- Active run overview
SELECT tenant_id, account_id, status, phase, risk_class, progress,
       eta_p50_seconds, eta_p80_seconds, eta_p95_seconds,
       actual_cost_usd, created_at, updated_at
FROM refactor_runs
WHERE status NOT IN ('CANCELLED','SUCCEEDED','SUCCEEDED_PATCH_ONLY','PARTIAL_WITH_ROLLBACK','FAILED_VALIDATION','FAILED_EVIDENCE','FAILED_ROLLBACK')
ORDER BY updated_at DESC;

-- Quality and evidence coverage
SELECT * FROM refactor_run_quality_summary
ORDER BY run_id;

-- Top failure signatures
SELECT failure_signature, failure_class, count(*) AS occurrences,
       count(*) FILTER (WHERE status = 'FAILED_TERMINAL') AS terminal_occurrences,
       sum(cost_usd) AS wasted_cost_usd
FROM refactor_step_attempts
WHERE failure_signature IS NOT NULL
GROUP BY failure_signature, failure_class
ORDER BY occurrences DESC;

-- ETA calibration by task class can be derived from events/metrics; this query is a starter.
SELECT risk_class, mode,
       percentile_cont(0.5) WITHIN GROUP (ORDER BY extract(epoch FROM completed_at - started_at)) AS actual_p50_seconds,
       percentile_cont(0.95) WITHIN GROUP (ORDER BY extract(epoch FROM completed_at - started_at)) AS actual_p95_seconds,
       avg(abs(extract(epoch FROM completed_at - started_at) - eta_p50_seconds) /
           NULLIF(extract(epoch FROM completed_at - started_at),0)) AS mean_p50_absolute_percentage_error
FROM refactor_runs
WHERE completed_at IS NOT NULL AND started_at IS NOT NULL AND eta_p50_seconds IS NOT NULL
GROUP BY risk_class, mode;
