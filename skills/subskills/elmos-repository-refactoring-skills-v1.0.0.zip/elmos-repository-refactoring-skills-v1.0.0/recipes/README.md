# Recipe Catalog

本目录 Recipe 是实现模板，已具备生产契约字段，但打包时统一标记为 `draft`，因为认证必须在 Elmos 实际 Adapter、工具链和 Golden Corpus 上执行。部署流水线应计算 digest、运行测试、签名后再晋级 `verified/certified`。

Recipe Runtime 必须验证 `contracts/recipe.schema.json`，并拒绝未知字段、未锁定插件、越权权限和 cardinality 异常。
