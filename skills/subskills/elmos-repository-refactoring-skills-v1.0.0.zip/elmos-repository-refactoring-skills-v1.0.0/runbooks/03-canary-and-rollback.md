# Runbook 03 — 灰度发布、观测与回滚

适用：重构补丁已经通过静态和测试验证，但行为、性能、依赖或跨服务契约仍需真实环境证明。代码重构不等于部署成功；两者分别记账和裁决。

## 1. 发布前条件

- patch、构建 artifact、SBOM、provenance、policy、Recipe lock、adapter/toolchain 均有 digest。
- 所有阻断门通过；waiver 有审批 ID、范围、有效期和绑定 digest。
- 有 baseline 指标与明确 guardrail：错误率、P95/P99 延迟、吞吐、资源、业务不变量、队列积压、数据库锁/复制延迟。
- rollback artifact 可部署；数据库/消息变更有 forward recovery 路径。
- 新旧版本兼容窗口和路由策略已定义。

## 2. 波次模板

推荐默认：

1. `shadow`：0% 用户流量，复制读/请求；只比较结果，不产生外部副作用。
2. `internal`：内部账号或测试租户。
3. `1%`：最小用户流量，至少覆盖一个完整业务周期。
4. `5%`。
5. `25%`。
6. `50%`。
7. `100%`。
8. `soak`：全量后持续观察。

不是所有任务都需要相同流量比例；批处理、SDK、数据库和消息消费者应使用对象/租户/分区/消费者组波次。每个 wave 在 `refactor_rollout_waves` 中持久化 guardrail snapshot。

## 3. 自动推进条件

一个 wave 只在下列条件全部满足时推进：

- 最小样本量和最小观察时长满足。
- 与 baseline 的差异在置信区间和业务 guardrail 内。
- 没有新增 critical/high 安全发现。
- 兼容性探针通过：旧客户端、新客户端、旧服务、新服务组合。
- 数据一致性对账通过。
- 日志/trace 未出现新的高频 failure signature。
- 人工审批要求已满足且未过期。

## 4. 自动暂停与回滚触发

示例默认阈值，实际由策略覆盖：

- error rate 相对增幅 >20% 或绝对增加 >0.5 percentage point。
- P95 延迟回归 >5%。
- 关键业务成功率下降 >1%。
- 数据不变量、金额、库存、权限或幂等性出现任一违反。
- 消费积压持续超过两个评估窗口。
- DB 锁等待、复制延迟或 CPU 超预算。
- 旧客户端兼容测试失败。
- 无法生成完整 telemetry/evidence。

触发后先停止推进和新流量，再判断 rollback、route-back、disable feature flag、compensation 或 forward fix。

## 5. 回滚策略选择

| 变化 | 首选策略 |
|---|---|
| 纯代码/配置 | 部署上一已签名 artifact |
| API facade | 路由回旧实现，同时保留兼容层 |
| 消息消费者 | 停新消费者、恢复旧 consumer group；处理重复/偏移 |
| DB expand | 保留扩展结构，停用新路径；不破坏性回滚 |
| DB contract | forward fix 或从演练备份恢复，需 R4 审批 |
| 缓存/索引 | 双写/重建；避免直接使用不兼容旧格式 |
| SDK/client | 停止发布并发布兼容修复；无法强制回收已安装版本 |

回滚完成后必须运行 smoke、contract、数据对账和关键指标验证。不能以“流量已回旧版”代替证据。

## 6. 影子差分

对确定性接口比较规范化输出；对非确定性输出使用业务不变量、容差、分布或因果追踪。必须隔离写副作用，外部支付、邮件、通知、库存等使用 mock/sink 或幂等 shadow namespace。

记录：request fingerprint、old/new response digest、normalized diff、latency delta、trace links、sample policy。敏感数据先最小化和脱敏。

## 7. 完成定义

- 所有计划 wave 成功或有批准的停止点。
- soak 窗口结束，guardrail 未越界。
- 新旧兼容窗口达到计划，contract cleanup 获得单独批准。
- EvidenceBundle 包含 rollout timeline、metrics、decisions、approvals 和 rollback readiness。
- 只有部署结果也在任务范围且通过时才标记 `SUCCEEDED`；仅代码可合并则为 `SUCCEEDED_PATCH_ONLY`。
