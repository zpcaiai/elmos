# Runbook 07 — 多仓库重构计划与波次编排

适用：公共库、API、事件、SDK、schema、构建插件或平台升级影响多个独立仓库。

## 1. 建立仓库关系图

节点：provider、consumer、shared、generated client、deployment/config。边：build、runtime call、schema consumption、event production/consumption、version constraint、deployment ordering。每条边记录来源、版本、owner、信心和验证方式。

未知消费者是风险，不是“没有消费者”。通过代码搜索、artifact registry、API gateway、service catalog、SBOM、telemetry 和 owner attestation 交叉确认。

## 2. 兼容策略

优先：provider 先扩展 → adapters/generated clients → early consumers → long-tail consumers → contract cleanup。破坏性 big-bang 只在明确维护窗口和 R4/R5 审批下允许。

对无法同步升级的消费者提供限时兼容 facade、versioned endpoint/event、双格式 parser 或 adapter library；每个兼容层有 owner、sunset date 和移除 gate。

## 3. Wave 设计

- Wave 0：只读分析与 consumer inventory。
- Wave 1：provider 兼容扩展，旧消费者不受影响。
- Wave 2：generated clients/SDK 和示范消费者。
- Wave 3：低风险内部消费者。
- Wave 4：关键消费者，分业务窗口。
- Wave 5：长尾和外部消费者。
- Wave 6：contract cleanup，单独审批。

每个 wave 有 entry/exit criteria、repository scope、owner、并发、ETA、成本、质量门、rollback 和 deadline。下游 wave 只能依赖已发布且验证的上游 artifact digest。

## 4. PR 与合并协调

- 每仓库独立 branch/PR，但共享 program/run traceability。
- PR 描述包含 program ID、wave、contract version、upstream artifact digest、验证结果和回滚。
- 合并不等于发布；记录 merge、build、deploy、consumer validation 四个状态。
- 任何 upstream 重新构建导致 digest 改变，下游验证作废并重跑。

## 5. 波次暂停

发生兼容失败、未知消费者、指标越界、owner 未确认、审批过期或上游 artifact 撤销时，暂停当前及所有依赖 wave。已迁移消费者保持兼容，不立即回滚整个 fleet，除非存在系统性安全/数据风险。

## 6. 完成定义

- 关系图中的所有已知消费者有迁移或批准例外。
- 兼容层有明确移除日期；contract cleanup 已完成或作为独立债务追踪。
- 每个仓库 patch hunk 与 program/wave/recipe/evidence 可追溯。
- fleet 级成功率、总成本、wall-clock、失败模式和节省量有统一报告。
