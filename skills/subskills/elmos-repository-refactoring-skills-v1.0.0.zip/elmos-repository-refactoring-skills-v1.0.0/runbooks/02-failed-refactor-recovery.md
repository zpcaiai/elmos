# Runbook 02 — 失败重构恢复与状态对账

目标：在 Worker、编排器、状态库、工件库、构建系统或验证环节失败后恢复到最近一致状态，保证不重复副作用、不丢证据、不把失败伪装成成功。

## 1. 首先冻结

1. 把 run 转为 `PAUSING`；停止调度新 step/shard。
2. 撤销或等待所有活跃 write lease 到期，记录 fencing token。
3. 冻结 request、policy、plan version、recipe lock、adapter/toolchain digests。
4. 保存现场：事件尾部、最近 checkpoint、活跃 attempt、workspace digest、artifact upload 状态、日志和资源指标。
5. 不要立即“重跑全部”；先判断一致性边界。

## 2. 失败分类

| 类别 | 示例 | 默认处置 |
|---|---|---|
| TRANSIENT_INFRA | 超时、临时网络、Worker 被驱逐 | 同一输入 digest 下有限重试 |
| ENVIRONMENT | restore/build baseline 失败、工具链缺失 | `BLOCKED_ENVIRONMENT`，修环境后新 attempt |
| DETERMINISTIC_TRANSFORM | Recipe 冲突、cardinality 错误、postcondition 失败 | 停止；修 Recipe 或新 plan version |
| VALIDATION | 编译、测试、API、安全、性能失败 | `FAILED_VALIDATION` 或受预算的 `REPAIRING` |
| EVIDENCE | 工件缺失、digest 不符、traceability 不全 | `FAILED_EVIDENCE`，禁止发布成功 |
| POLICY | 未授权路径、风险升级、审批过期 | `BLOCKED_APPROVAL` 或终止 |
| STATE_DIVERGENCE | DB、事件、workspace、artifact 不一致 | 强制对账；不得普通重试 |
| IRREVERSIBLE_SIDE_EFFECT | 数据 contract、外部系统变更 | 优先 forward fix/compensation，人工接管 |

## 3. 对账顺序

按以下真值优先级对账：

1. 内容寻址的仓库快照和工件 digest。
2. 已提交的数据库事务与 checkpoint manifest。
3. 单调递增的 `refactor_events.sequence`。
4. step attempt 状态与 heartbeat。
5. Worker 本地日志，仅作为补充，不是最终真值。

检查：

```sql
SELECT run_id, status, phase, plan_version, last_event_sequence,
       cancel_requested_at, pause_requested_at
FROM refactor_runs WHERE run_id = :run_id FOR UPDATE;

SELECT sequence, event_type, step_id, shard_id, idempotency_key, occurred_at
FROM refactor_events
WHERE run_id = :run_id
ORDER BY sequence DESC LIMIT 100;

SELECT step_id, shard_id, attempt_number, status, idempotency_key,
       input_digest, output_digest, heartbeat_at, failure_class, failure_signature
FROM refactor_step_attempts
WHERE run_id = :run_id
ORDER BY started_at DESC;

SELECT step_id, shard_id, checkpoint_sequence, workspace_tree_digest,
       artifact_manifest_digest, created_at
FROM refactor_checkpoints
WHERE run_id = :run_id
ORDER BY checkpoint_sequence DESC;
```

## 4. 恢复决策

### A. 可安全重试

只有同时满足：输入 digest 不变、操作幂等、未提交不可逆副作用、预算允许、failure class 为 retryable。创建新的 attempt number，但复用同一个逻辑 idempotency key 派生链；不得覆盖旧 attempt。

### B. 从 checkpoint 恢复

1. 校验 checkpoint 的 workspace tree 和 artifact manifest digest。
2. 校验 side-effect cursor，确认外部动作是否已完成。
3. 创建新的 fenced lease。
4. 从 checkpoint 后的第一个未确认原子单元继续。
5. 对可能重复的 outbox/event 以 idempotency key 去重。

### C. 自动修复

仅限 `repairBudget` 内，并满足：失败可归因、修复范围不超原 step write set、风险不升级、不得删除/弱化测试或安全规则。修复生成新 Recipe execution 和独立 patch hunk，必须重新运行原阻断门与相邻门。

### D. 回滚

- 代码/配置：reverse patch 或 snapshot restore。
- 已发布包/服务：部署前一已签名 artifact。
- 数据库 expand：通常保留新列/索引，停止双写；不要急于破坏性回滚。
- 数据库 contract 已执行：优先 forward fix，除非有经过演练的可逆脚本和备份。
- 消息/API：恢复兼容 facade、旧 schema 或路由。

每次回滚写 `refactor_rollback_executions`，保存 side-effect journal 和报告。

## 5. 状态转换规则

- 可恢复基础设施失败：`RUNNING -> PAUSING -> PAUSED -> RUNNING`。
- 环境缺陷：`RUNNING -> BLOCKED_ENVIRONMENT`。
- 需审批：`RUNNING -> BLOCKED_APPROVAL`。
- 验证失败且修复预算存在：`RUNNING -> REPAIRING -> RUNNING|FAILED_VALIDATION`。
- 回滚：`* -> ROLLING_BACK -> PARTIAL_WITH_ROLLBACK|FAILED_ROLLBACK`。
- 用户取消：`* -> CANCELLED`，但必须完成安全收尾和证据封装。

禁止直接从任意失败状态改为 `SUCCEEDED`。恢复后必须重放所有依赖于失效输出的 gate。

## 6. 完成恢复

恢复成功需要：

- 事件序列连续，重复事件已去重。
- 没有两个有效 Worker 写同一 shard。
- DB step/attempt 状态与 workspace/artifact 相符。
- 所有 side effects 有确认、补偿或明确 forward-only 状态。
- 新证据记录恢复过程、旧失败和最终验证。
- 更新 ETA 和成本，不隐藏重试开销。

## 7. 事后动作

- 给 failure signature 建立可检索指纹。
- 将新故障加入 `tests/resilience/fault-injection.yaml`。
- 若是 Recipe/adapter 缺陷，降级或隔离 registry 状态，阻止新的自治运行。
- 只有在隐藏评测通过后，修复版本才可重新认证。
