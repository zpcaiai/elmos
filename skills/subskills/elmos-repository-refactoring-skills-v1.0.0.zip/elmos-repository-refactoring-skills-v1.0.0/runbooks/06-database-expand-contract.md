# Runbook 06 — 数据库 Schema 的 Expand–Migrate–Contract

数据库重构默认 R4。任何 rename/drop/type narrowing/约束加强都不得与应用切换在同一不可分离步骤中执行。

## 1. 阶段

### Expand

添加向后兼容结构：新列、新表、新索引、新 schema version。大表使用低锁策略，例如并发索引、`NOT VALID` 约束再验证。记录锁预算、statement timeout、复制延迟阈值。

### Dual compatibility

部署可同时读写新旧结构的应用版本。写入必须幂等；定义 source of truth、冲突解决和失败补偿。

### Backfill/Migrate

按主键/时间游标分批，checkpoint 每批；限速并观测锁、WAL、复制、CPU、IO。每批记录 count、checksum/null-rate 和 cursor。任务可暂停/恢复。

### Read switch

先 shadow 比较，再逐步把读取切到新结构。保留旧读取 fallback 和数据不变量报警。

### Contract

只有所有 writer/reader、报表、CDC、ETL、缓存、索引、备份/恢复脚本和外部消费者迁移完，且兼容窗口结束、R4 审批生效，才能删除旧结构。

## 2. 计划必须识别的消费者

应用服务、批任务、BI、数据湖/CDC、触发器、视图、存储过程、ORM migration、手写 SQL、权限、审计、备份、灾备、搜索索引和第三方集成。无法证明覆盖时 contract 阶段禁止执行。

## 3. 验证

- migration lint 和目标数据库版本 dry-run。
- schema diff、lock/transaction 评估。
- old app + expanded DB、new app + expanded DB、rollback app + expanded DB 组合测试。
- backfill 行数、hash、null、唯一性、业务聚合对账。
- CDC/replication lag 和事件顺序。
- 性能基线与慢查询对比。
- 备份恢复演练。

## 4. 失败处置

- Expand 失败：事务回滚或保留安全的未使用结构。
- Backfill 失败：从 cursor 恢复；不得重复非幂等转换。
- Dual-write 不一致：停止推进，确定 authoritative side，补偿并重放。
- Contract 失败：通常 forward fix；只有经过演练且数据仍可恢复时回滚。
- 用户取消：停止后续批次，不自动执行 drop。

## 5. 证据

每一阶段输出独立 migration artifact、计划/实际锁时间、批次 cursor、对账结果、部署版本矩阵、审批、回滚/前滚说明。EvidenceBundle 必须把数据库 hunk 与应用 dual-read/dual-write 验证关联。
