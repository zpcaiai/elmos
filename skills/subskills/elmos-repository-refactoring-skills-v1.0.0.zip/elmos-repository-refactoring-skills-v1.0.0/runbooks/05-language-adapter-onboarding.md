# Runbook 05 — 新编程语言/框架适配器接入与认证

目标：让“支持某语言”变成可度量、可降级、可认证的能力声明，而不是营销标签。

## 1. 适配器边界

适配器实现统一操作：`probe`、`restore`、`parse`、`index`、`query`、`lower`、`apply`、`format`、`validate`、`rollback`。原生语义模型保留为 Native IR；跨语言查询只投影到 Semantic IR，不能为了统一而丢失宏、泛型、条件编译、动态特性等关键语义。

## 2. 引擎选择顺序

1. 编译器/语言服务官方 API：语法、符号、类型、诊断、workspace/build graph。
2. Lossless/CST：保留 trivia、注释、格式和局部打印。
3. 结构化 matcher：覆盖受控长尾模式。
4. 纯文本：仅配置/文档等明确白名单，要求锚点、cardinality、postcondition 和完整复验。

记录工具许可、版本、平台、线程安全、增量能力、内存模型、codegen 和宏支持。

## 3. 能力等级交付

### L0

文件识别、工具链探测、只读清单。所有写操作拒绝。

### L1

解析/CST、格式保持、局部语法改写、幂等和 exact golden。不能声称符号安全。

### L2

符号身份、引用解析、类型归属、scope conflict、项目内 rename/move/signature change。要求正负 corpus。

### L3

构建图、调用/依赖图、跨模块契约、影响测试选择、generated code awareness、回滚与完整 evidence。

### L4

大仓库、多仓库、故障注入、性能、对抗语料、确定性重放和真实 Golden Route 认证。只有 L4 才可能在策略允许时自治。

## 4. 必需实现

- `LanguageAdapter` descriptor，初始 certificationLevel 必须为 L0。
- 版本锁和 artifact digest；SBOM 和签名。
- Native IR ↔ Semantic IR 投影规则和信息损失声明。
- 操作 capability matrix：full/partial/none，不能用 boolean 隐藏差异。
- error taxonomy、failure signature 和 retryability。
- resource profile、sandbox executable/network/write paths。
- formatter touched-range 策略；禁止默认全仓格式化。
- build/test discovery 和可复现命令。
- rollback implementation。

## 5. Corpus 设计

覆盖：多模块、同名符号、重载、泛型、继承、反射、动态导入、宏/条件编译、生成代码、注释中的名称、字符串协议、不同换行/编码、语法错误文件、混合语言、旧工具链、monorepo 和大型 vendor tree。

每个操作至少有：正例、拒绝例、冲突例、未知风险例、第二次零 diff、rollback 后 byte/semantic 等价。

## 6. 性能基线

按 10k/100k/500k/1M+ LOC 测试：冷/热索引时间、增量更新时间、峰值内存、磁盘、match throughput、apply throughput、build/test selection recall。性能结果绑定 adapter/toolchain digest。

## 7. 上线步骤

1. 注册 L0 descriptor，feature flag 仅开放 analyze-only。
2. 通过 schema/contract/security 测试。
3. 达到 L1 后开放 proposal 的语法级 recipes。
4. 达到 L2/L3 后按 recipe family 分别开放 supervised，不按语言一次性放开。
5. 完成 L4 后，由组织策略决定是否允许 `autonomous-low-risk`。
6. 新版本先 shadow，与旧版本比较 matches、patch hash、diagnostics 和资源。

## 8. 降级与撤销

发现 escape defect、非确定性、错误符号解析、供应链风险或严重性能回归时：立即降级 certification level 或置 `REVOKED`。已生成但未合并的 PR 重新验证；正在运行的任务暂停并检查 digest。
