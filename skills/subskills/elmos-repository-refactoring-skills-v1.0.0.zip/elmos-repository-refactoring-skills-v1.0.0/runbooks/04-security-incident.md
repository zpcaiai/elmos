# Runbook 04 — 重构执行安全事件

安全事件包括：仓库脚本尝试越权、凭据疑似泄露、依赖投毒、恶意生成代码、路径逃逸、沙箱突破、未授权网络、敏感文件被修改、证据被篡改或适配器供应链被撤销。

## 1. 立即控制

1. 暂停受影响 run 和同一 adapter/toolchain digest 的新运行。
2. 撤销 Worker lease、网络和临时凭据；保留只读取证访问。
3. 隔离 workspace、容器镜像、日志、trace、进程树、网络记录和 artifact manifest。
4. 不执行仓库提供的额外清理脚本；避免破坏证据。
5. 将 Recipe/adapter registry 状态改为 `QUARANTINED`/`REVOKED`（按影响），禁止自治模式。

## 2. 严重度

- SEV-0：生产凭据/数据实际外泄、沙箱逃逸、签名链被破坏。
- SEV-1：高可信越权执行、供应链恶意 artifact、跨租户访问。
- SEV-2：被阻止的网络/进程尝试、敏感路径写入被拦截、可疑依赖。
- SEV-3：策略配置缺陷或低风险扫描发现，无实际越权。

## 3. 取证最低集

- request/policy/plan/recipe/adapter/toolchain/snapshot digests。
- sandbox image、kernel/runtime、seccomp/AppArmor/SELinux 配置。
- 进程执行、参数、工作目录、uid/gid、环境变量名清单（值脱敏）。
- DNS/网络目的、拒绝日志、连接时间线。
- 文件系统 writes、路径规范化结果、symlink traversal。
- artifact upload/download digest 与签名验证。
- 用户、服务身份、审批和 token issuance/revocation 时间线。
- 相关 SARIF、OTel traces 和 event sequence。

## 4. 常见处置

### 恶意构建脚本

继续 deny network；将 restore 与 build 分离；使用 allowlisted executable；在无 secret 的一次性 sandbox 重现。不得为了“构建成功”放开公网。

### 凭据暴露

立即撤销并轮换；检索日志、patch、artifact 和 cache；重签受影响证据。新凭据不得注入旧 workspace。

### 路径逃逸/符号链接

拒绝提交；检查所有 path canonicalization 与 mount；扫描同一执行器历史 runs；增加 adversarial golden case。

### 供应链问题

冻结 adapter/toolchain/recipe digest；验证 SBOM、签名、provenance；在干净环境重建并比较 digest。无法证明来源时禁止恢复。

### 跨租户风险

冻结相关租户和共享缓存 namespace；验证 PostgreSQL RLS、object-store prefix、KMS key 和 telemetry attributes；以最小必要范围通知。

## 5. 恢复条件

- 根因确定，受影响 digest 和时间范围明确。
- 凭据、访问、artifact 和缓存已完成处置。
- 修复通过安全回归、故障注入和隐藏 corpus。
- adapter/recipe 重新签名并完成相应等级认证。
- 所有受影响 runs 被标记、重验或撤销；不能只修最新版本。

## 6. 永久改进

把事件映射为：新的 policy rule、sandbox control、detector、SARIF rule、golden negative case、fault scenario 和 release gate。安全例外必须有到期时间，不得成为永久 allowlist。
