# Runbook 01 — 大型仓库重构运行

适用范围：单仓库超过 500k LOC、超过 50k 文件、构建目标超过 1,000，或预计任务持续超过 30 分钟。超过 1M LOC 的仓库默认启用本 Runbook，不允许直接以单 Worker、全仓扫描、全量补丁方式执行。

## 1. 进入条件与责任

- Incident/Run owner：本次重构运行的唯一运营负责人。
- Technical approver：仓库所有者或架构负责人。
- Refactor operator：有权暂停、恢复、取消，不得绕过阻断门。
- Security approver：只有策略命中安全敏感区时加入。

运行前必须有不可变的 `request_digest`、`policy_digest`、仓库 revision、工具链镜像 digest 和 adapter digest。任何一个变化都创建新 plan version；不得在运行中静默漂移。

## 2. 预检

1. 确认 revision 是完整 commit，不是 branch/tag 浮动引用。
2. 记录 submodule、LFS、生成代码、符号链接、文件大小写和换行策略。
3. 在隔离环境执行 restore/build baseline；失败时状态置为 `BLOCKED_ENVIRONMENT`，不得把既有失败归因于重构。
4. 建立语言、构建目标、模块、服务、数据库、消息、API、测试和 ownership 清单。
5. 计算语义覆盖率：symbol resolution、type attribution、build target、test link。低于策略阈值时降级自治等级或阻断。
6. 估计 wall-clock P50/P80/P95、成本 P50/P95、峰值内存、磁盘、Worker 数和缓存空间。
7. 为大二进制、vendor、generated、fixtures、snapshots、minified 资产定义明确排除或专门适配规则。

## 3. 分片策略

优先级从高到低：

1. 构建目标/模块边界。
2. 语义依赖的强连通分量。
3. 服务或包边界。
4. ownership 边界。
5. 文件路径，仅作为无更好语义边界时的兜底。

分片必须满足：

- 每个 shard 有确定的 read set、write set、input digest 和 idempotency key。
- 同一 write set 只能由一个有效 lease 持有。
- 跨 shard 符号修改先生成全局 rename/move plan，再并行应用局部 edits。
- 强连通分量不得被强行拆开；过大的 SCC 进入串行“核心 shard”。
- 共享构建文件、lockfile、公共 schema 和 codegen 配置进入独占 shard。
- 合并顺序稳定：按 dependency wave、step ordinal、shard id 排序。

建议初始范围：每 shard 2k–10k 文件或 20k–100k LOC；以峰值内存和解析耗时实测调整，而不是只按 LOC。

## 4. 缓存与增量索引

缓存键必须至少包含：repository tree digest、submodule/LFS digest、toolchain digest、adapter digest、parser options digest、build configuration digest、recipe digest 和参数 digest。

允许复用：

- 内容寻址的 parse/CST/LST 结果。
- 符号和类型索引分区。
- build/test graph。
- 未变化目标的 baseline build/test artifacts。
- 纯函数式 Recipe 的 match 与 lower 结果。

禁止复用：

- digest 不完整的缓存。
- 来自不同租户且未经过内容隔离策略批准的敏感工件。
- 工具链、编译 flag、环境变量或 codegen 输入改变后的结果。
- 失败结果，除非其 failure signature、TTL 和环境 digest 均绑定。

## 5. 执行顺序

1. `DISCOVERY`：固定快照和环境。
2. `INDEXING`：并行构建局部索引，再合并全局图。
3. `PLANNING`：输出变更闭包、风险、Recipe lock 与 wave DAG。
4. `DRY_RUN`：只生成 matches、预期 edits、冲突和验证选择，不写工作区。
5. `TRANSFORMING`：在独立 worktree/shard workspace 原子写入。
6. `MERGING`：以稳定顺序合并；冲突不得用“最后写入胜出”。
7. `VERIFYING`：changed-file parse → type/build → impact tests → contract/security/performance → full suite（按策略）。
8. `EVIDENCE`：每个 hunk 绑定 step、recipe execution、action 和 validation。
9. `PUBLISHING`：生成 PR/changeset；满足策略时进入 canary。

每个阶段结束写 checkpoint。长阶段按固定工作单位和最大时间间隔双触发 checkpoint，例如每 500 文件或 120 秒，以先到者为准。

## 6. 资源与并发控制

- 每账号默认最多 3 个并发 run；从 `refactor_tenant_quotas` 读取，不在 Worker 中硬编码。
- `max_parallel_shards` 是上限，不是目标。调度器根据 CPU、内存、磁盘、缓存命中率和 build queue 自适应。
- 保留至少 20% 磁盘用于补丁、checkpoint、日志和 rollback bundle。
- 内存压力达到 80% 时停止新 shard；达到 90% 时优雅 checkpoint 并回收最低优先级 Worker。
- 验证 Worker 与 transform Worker 隔离，避免编译峰值拖垮状态持久化。
- 外部 registry 只允许 restore-only 网络；依赖下载完成后切换到 deny。

## 7. 进度与 ETA

进度不能只用“完成步骤数”。使用加权工作量：已索引实体、已处理 match、已完成 build targets、已完成 tests、已上传 evidence。每完成一个 shard 更新吞吐量分布，以历史相似仓库作为先验并在线校准 P50/P80/P95。

必须向用户显示 Elmos 自动运行 wall-clock ETA，不把人工人天混入同一数字。若关键路径、缓存命中率或失败重试改变，应更新 ETA，并记录估计版本和误差。

## 8. 暂停、恢复、取消

- 暂停：停止调度新工作；当前原子单位完成或安全回滚后进入 `PAUSED`。
- 恢复：重新验证 immutable digests、lease、checkpoint manifest 和 workspace tree digest。
- 取消：设置 `cancel_requested_at`；停止新工作并生成当前状态 EvidenceBundle。数据库 expand 阶段已执行时，不自动执行 contract 阶段。
- Worker 丢失：heartbeat 超时后 lease 失效；新 Worker 从最后 checkpoint 接管，旧 Worker 的提交必须被 fencing token 拒绝。

## 9. 阻断条件

任一条件出现即暂停或失败关闭：

- snapshot/tree digest 漂移。
- 语义覆盖率低于计划假设。
- changed files/lines/cost/time 超预算。
- 非预期公共 API、Schema、消息、权限或依赖变化。
- 第二次执行仍产生 diff。
- blocking gate fail/error。
- rollback bundle 不完整或证据 manifest 无法校验。
- 大量格式噪声、生成代码被直接修改、未知脚本试图访问网络/凭据。

## 10. 运行完成检查

```sql
SELECT run_id, status, phase, progress,
       eta_p50_seconds, eta_p80_seconds, eta_p95_seconds,
       estimated_cost_usd, actual_cost_usd
FROM refactor_runs
WHERE run_id = :run_id;

SELECT *
FROM refactor_run_quality_summary
WHERE run_id = :run_id;
```

只有所有阻断门通过、hunk evidence coverage 为 1.0、EvidenceBundle digest/signature 完整、rollback 路径验证通过，才可发布 `SUCCEEDED`。只生成安全补丁但未完成部署/灰度时使用 `SUCCEEDED_PATCH_ONLY`。
