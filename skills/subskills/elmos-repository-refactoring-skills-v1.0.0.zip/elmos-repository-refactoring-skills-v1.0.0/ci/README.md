# CI Integration

`quality-gates.yaml` is the Elmos-native release policy. `github-actions-example.yaml` shows how a consuming repository can call the offline validator and the full certification harness.

Before production use:

1. Pin every third-party action to a reviewed commit SHA.
2. Generate hash-locked Python and npm lockfiles from the organization's approved package mirror; included versions are exact but distribution hashes are intentionally not invented.
3. Run golden and fault-injection suites on isolated, reproducible workers with pinned adapter/toolchain images.
4. Sign the package manifest and certification evidence through workload identity/KMS, not a repository secret.
5. Publish SARIF and retain evidence according to organization policy.
