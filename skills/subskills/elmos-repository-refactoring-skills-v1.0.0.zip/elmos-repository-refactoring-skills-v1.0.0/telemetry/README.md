# Telemetry

Metric/attribute 名称使用 Elmos 命名空间，并对齐 OpenTelemetry 的 trace/metric/log/event 语义。生产导出器可映射到 Prometheus、OTLP、Datadog、Grafana 等，但字段含义和单位必须保持稳定。

所有 repository、tenant、recipe 和 adapter 标识默认使用不透明 ID 或 digest；禁止以 file/symbol 作为高基数 metric label。详细路径只进入权限受控的 Evidence Artifact。
