# Sources

`capability-basis.md` records the primary technical references used to define this package. It is an architectural provenance list, not a dependency lockfile. Actual adapter implementations must pin licenses, versions, container digests, SBOMs and signatures in the adapter registry.
