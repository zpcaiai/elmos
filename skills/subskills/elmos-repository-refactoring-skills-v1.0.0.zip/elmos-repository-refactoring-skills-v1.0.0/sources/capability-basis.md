# Capability Basis and Primary References

Checked: 2026-08-26. These sources inform the architecture; Elmos does not copy their implementations and does not claim certification merely because an engine is named.

## Transformation model

- OpenRewrite documentation — Lossless Semantic Trees, type attribution, visitors and composable Recipes. Basis for format-preserving, minimally invasive, type-aware transformations and a Recipe lifecycle.
  - https://docs.openrewrite.org/
  - https://docs.openrewrite.org/concepts-and-explanations/lossless-semantic-trees
  - https://docs.openrewrite.org/reference/type-attribution
- Tree-sitter documentation — incremental concrete syntax trees. Basis for incremental parsing, error-tolerant inventory and long-tail CST adapters.
  - https://tree-sitter.github.io/tree-sitter/
- ast-grep and GritQL documentation — structural search/rewrite and declarative codemods. Basis for the controlled structural-matcher tier below compiler-native adapters.
  - https://ast-grep.github.io/
  - https://docs.grit.io/

## Language-native semantic adapters

- Roslyn/.NET Compiler Platform SDK — analyzers, code fixes and refactorings for C# and Visual Basic.
  - https://learn.microsoft.com/dotnet/csharp/roslyn-sdk/
- Clang LibTooling, AST Matchers and Transformer — typed C/C++ program transformations.
  - https://clang.llvm.org/docs/LibTooling.html
  - https://clang.llvm.org/docs/LibASTMatchers.html
  - https://clang.llvm.org/docs/ClangTransformerTutorial.html
- Go packages and gopls — syntax, types, workspace analysis and code actions.
  - https://pkg.go.dev/golang.org/x/tools/go/packages
  - https://go.dev/gopls/features/transformation
- rust-analyzer assists — semantic assists and code actions for Rust.
  - https://rust-analyzer.github.io/book/assists.html
- LibCST codemods — metadata-aware, multi-pass, formatting-preserving Python codemods.
  - https://libcst.readthedocs.io/en/latest/codemods.html
- TypeScript Compiler API — Program, CompilerHost and SourceFile model for application-wide analysis.
  - https://github.com/microsoft/TypeScript/wiki/Using-the-Compiler-API
- SwiftSyntax — source-accurate Swift syntax tree for parsing, inspecting, generating and transforming code.
  - https://github.com/swiftlang/swift-syntax
- PHP-Parser — AST and format-preserving PHP transformations.
  - https://github.com/nikic/PHP-Parser
- Kotlin Analysis API/K2 — semantic analysis integration for Kotlin tooling.
  - https://kotlin.github.io/analysis-api/
- Dart analyzer — static analysis and source tooling for Dart/Flutter.
  - https://github.com/dart-lang/sdk/tree/main/pkg/analyzer

## Evidence, interoperability and operations

- SARIF 2.1.0 and GitHub code scanning integration — machine-readable diagnostics and security findings.
  - https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
  - https://docs.github.com/code-security/how-tos/find-and-fix-code-vulnerabilities/integrate-with-existing-tools/upload-sarif-file
- OpenTelemetry semantic conventions — common attribute naming for traces, metrics, logs, profiles and resources.
  - https://opentelemetry.io/docs/concepts/semantic-conventions/
- OpenAPI 3.1 and JSON Schema 2020-12 — request, plan, Recipe and evidence contracts.
  - https://spec.openapis.org/oas/v3.1.0
  - https://json-schema.org/draft/2020-12
- Protocol Buffers — durable event envelope schema.
  - https://protobuf.dev/programming-guides/proto3/
- Temporal durable execution concepts — long-running, retryable, resumable workflows. Elmos keeps the workflow contract Temporal-compatible but preserves a replaceable runtime boundary.
  - https://docs.temporal.io/workflows

## Design conclusions adopted by Elmos

1. Use compiler/language-service semantics as the authority for identity, type and scope.
2. Preserve Native IR and project only shared facts into Semantic IR; never flatten away language-specific semantics.
3. Keep Lossless/CST representations for comments, trivia, exact ranges and minimal printing.
4. Use declarative Recipes with applicability, negative guards, bounded cardinality, postconditions, validation, idempotence and rollback.
5. Treat a model-generated edit as a proposal until a deterministic adapter applies it and independent gates verify it.
6. Bind every plan, patch, approval, validation and evidence artifact to immutable digests.
7. Certification is empirical: Golden Corpus, negative cases, real repositories, fault injection, large-repository performance and deterministic replay.
