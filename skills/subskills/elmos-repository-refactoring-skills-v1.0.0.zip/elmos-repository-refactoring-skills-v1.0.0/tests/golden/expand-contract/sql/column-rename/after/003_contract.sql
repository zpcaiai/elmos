-- Requires proof that all deployed writers use display_name and a separately
-- bound R4 approval. Prefer NOT VALID + validate phases for large tables.
ALTER TABLE customer ALTER COLUMN display_name SET NOT NULL;
ALTER TABLE customer DROP COLUMN full_name;
