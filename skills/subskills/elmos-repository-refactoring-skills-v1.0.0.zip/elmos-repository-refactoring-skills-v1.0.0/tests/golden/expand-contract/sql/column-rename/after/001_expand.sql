ALTER TABLE customer ADD COLUMN display_name text;

COMMENT ON COLUMN customer.display_name IS
    'Replacement for full_name; dual-write until contract approval.';
