CREATE TABLE customer (
    id bigint PRIMARY KEY,
    full_name text NOT NULL,
    updated_at timestamptz NOT NULL DEFAULT now()
);
