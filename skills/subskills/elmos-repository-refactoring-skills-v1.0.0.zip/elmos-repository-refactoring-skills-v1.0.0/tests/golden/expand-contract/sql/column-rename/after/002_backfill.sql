-- Run in bounded, resumable batches. The production executor substitutes :last_id
-- and :batch_size, records the cursor, and verifies rows before advancing.
UPDATE customer
SET display_name = full_name
WHERE id > :last_id
  AND id <= :last_id + :batch_size
  AND display_name IS NULL;
