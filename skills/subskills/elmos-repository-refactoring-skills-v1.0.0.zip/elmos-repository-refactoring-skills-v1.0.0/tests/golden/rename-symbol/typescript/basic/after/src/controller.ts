import { UserService } from "./user-service.js";

const service = new UserService();
const metadata = { fetchUser: "fetchUser" };
export const result = `${metadata.fetchUser}:${service.loadUser("42")}:${service.loadUser("43")}`;
