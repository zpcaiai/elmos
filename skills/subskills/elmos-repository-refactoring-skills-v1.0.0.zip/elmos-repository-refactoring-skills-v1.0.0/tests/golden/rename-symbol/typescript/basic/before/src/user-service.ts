export class UserService {
  fetchUser(id: string): string {
    return `user:${id}`;
  }
}
