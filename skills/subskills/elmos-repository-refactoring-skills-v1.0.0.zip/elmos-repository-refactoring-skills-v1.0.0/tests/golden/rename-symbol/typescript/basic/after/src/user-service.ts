export class UserService {
  loadUser(id: string): string {
    return `user:${id}`;
  }
}
