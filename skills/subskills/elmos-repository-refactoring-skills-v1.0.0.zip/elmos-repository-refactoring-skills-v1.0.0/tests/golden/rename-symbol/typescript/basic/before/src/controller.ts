import { UserService } from "./user-service.js";

const service = new UserService();
const metadata = { fetchUser: "fetchUser" };
export const result = `${metadata.fetchUser}:${service.fetchUser("42")}:${service.fetchUser("43")}`;
