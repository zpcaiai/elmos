import { UserService } from "./service.js";

declare const configuredMethod: keyof UserService;
const service = new UserService();
export const result = service[configuredMethod]("42");
