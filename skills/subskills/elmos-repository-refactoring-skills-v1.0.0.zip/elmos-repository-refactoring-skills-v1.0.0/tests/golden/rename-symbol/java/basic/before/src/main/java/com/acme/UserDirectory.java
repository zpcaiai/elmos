package com.acme;

public final class UserDirectory {
    public String findUser(String id) {
        return "user:" + id;
    }
}
