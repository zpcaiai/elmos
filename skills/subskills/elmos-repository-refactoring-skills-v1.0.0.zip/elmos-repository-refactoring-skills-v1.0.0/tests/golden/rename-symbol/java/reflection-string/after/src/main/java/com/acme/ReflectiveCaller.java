package com.acme;

public final class ReflectiveCaller {
    public Object call(UserDirectory target, String id) throws Exception {
        return UserDirectory.class.getMethod("findUser", String.class).invoke(target, id);
    }
}
