package com.acme;

public final class UserController {
    private final UserDirectory directory = new UserDirectory();

    public String show(String id) {
        String auditLabel = "findUser";
        return auditLabel + ":" + directory.findUser(id) + ":" + directory.findUser(id);
    }
}
