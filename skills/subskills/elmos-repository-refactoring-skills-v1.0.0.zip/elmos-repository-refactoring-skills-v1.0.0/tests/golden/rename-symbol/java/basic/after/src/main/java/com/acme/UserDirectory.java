package com.acme;

public final class UserDirectory {
    public String loadUser(String id) {
        return "user:" + id;
    }
}
