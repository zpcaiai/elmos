from acme_core import load_user

print(load_user("42"))
