def load_user(user_id: str) -> str:
    return f"user:{user_id}"
