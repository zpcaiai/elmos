from acme_service import load_user

print(load_user("42"))
