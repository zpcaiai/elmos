"""Acme service package."""

from .users import load_user

__all__ = ["load_user"]
