# Golden Corpus Layout

Golden tests are exact, content-addressed before/after cases. They are not snapshots of model prose. The harness checks applicability, match cardinality, transformed files, semantic postconditions, validation commands, second-run idempotence, evidence traceability, and deterministic patch hash.

```text
tests/golden/<operation>/<language-or-domain>/<case>/
  case.yaml
  before/
  after/
  optional-baseline/
  expected/
```

Rules:

1. `before/` is immutable test input; `after/` is the canonical minimal result.
2. Untouched files must remain byte-identical.
3. A case must pin adapter, recipe, toolchain and formatting profiles by digest in the real certification environment.
4. Negative cases use `expected.outcome: rejected` and state the guard that must reject the run.
5. The second execution against `after/` must produce an empty patch.
6. Generated files, line endings, encodings, comments, symlinks, submodules and case-sensitive paths need dedicated corpus coverage.
7. A production adapter needs hidden evaluation cases in addition to the examples in this package.

The included cases are executable seed fixtures, not sufficient by themselves for L4 certification.
