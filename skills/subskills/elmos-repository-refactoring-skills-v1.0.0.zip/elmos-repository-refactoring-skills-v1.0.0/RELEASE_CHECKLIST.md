# Release Checklist

## Package release

- [ ] `scripts/validate_package.py` returns PASS with zero errors and zero warnings.
- [ ] Seed Golden smoke tests pass on the approved builder image.
- [ ] TypeScript reference skeleton typechecks with the locked toolchain.
- [ ] JSON Schema, OpenAPI and Protobuf changes are backward-compatible or versioned.
- [ ] Database migrations were tested on an empty database and an upgrade snapshot.
- [ ] Recipe catalog, adapter matrix and package manifest contain no dangling paths.
- [ ] `MANIFEST.sha256` is regenerated after the final edit.
- [ ] SBOM, provenance and vulnerability scans are attached.
- [ ] Release artifact and validation evidence are signed through workload identity/KMS.

## Adapter/Recipe enablement

- [ ] Adapter binary/image digest exactly matches the certification input.
- [ ] Recipe digest and toolchain digest exactly match the certification input.
- [ ] Required L1–L4 suites pass for the requested operating mode.
- [ ] Hidden corpus and real-repository replay pass.
- [ ] Determinism, idempotence, rollback and evidence coverage are 100% for blocking cases.
- [ ] Security and supply-chain findings contain no unresolved high/critical issue.
- [ ] Registry status is signed and active; previous vulnerable versions are revoked.

## Production rollout

- [ ] Tenant quotas, default maximum three concurrent runs per account and shard limits are configured.
- [ ] PostgreSQL RLS, object-store tenant prefixes and KMS boundaries are verified.
- [ ] `/livez`, `/readyz`, `/metrics` and `/version` are available for every service.
- [ ] Dashboards and alerts in `telemetry/` are deployed.
- [ ] Pause/resume/cancel, Worker crash, orchestrator restart and artifact-store outage have been rehearsed.
- [ ] Approval roles, expiry, digest binding and escalation paths are configured.
- [ ] Large repository, failed recovery, canary/rollback and security Runbooks have named owners.
- [ ] Cost and wall-clock ETA calibration are enabled and user-visible.
