---
name: performance-preservation
description: 在重构前后进行工作负载、Profile 和资源成本对比，阻止性能回归。
risk: high
depends_on: build-environment, test-verification
version: 1.0.0
---

# performance-preservation

## 目的

在重构前后进行工作负载、Profile 和资源成本对比，阻止性能回归。

## 输入

- `BenchmarkPlan`
- `baseline artifacts`
- `SLO guardrails`
- `runtime profiles`

## 执行流程

1. 固定硬件/容器/数据集/warmup/concurrency 和采样方法。
2. 选择 micro、component、end-to-end 与 production-shadow workload。
3. 对 latency distribution、throughput、CPU、memory、alloc、IO、network、DB plan 和 cost 比较。
4. 出现回归时用 changed symbols、profile diff 和 bisect 定位。
5. 对噪声做重复、置信区间和环境异常判定。

## 输出

- `PerformanceDiff`
- `ProfileDiff`
- `GuardrailDecision`
- `OptimizationEvidence`

## 强制不变量

- 不以单次平均值裁决。
- 基线与候选环境必须等价。
- 性能修复不能牺牲正确性或安全。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 所有声明的性能目标有可重放 benchmark。
- 超过 guardrail 阻断。
- 报告区分统计噪声与实际回归。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
