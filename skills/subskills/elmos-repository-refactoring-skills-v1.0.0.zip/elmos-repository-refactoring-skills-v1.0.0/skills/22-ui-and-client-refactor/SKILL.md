---
name: ui-and-client-refactor
description: 重构 Web、桌面、移动端和小程序的组件、状态、路由、网络和设计系统。
risk: high
depends_on: semantic-index, api-compatibility, test-verification
version: 1.0.0
---

# ui-and-client-refactor

## 目的

重构 Web、桌面、移动端和小程序的组件、状态、路由、网络和设计系统。

## 输入

- `UI component graph`
- `routes/state/network contracts`
- `design tokens`
- `target platform matrix`

## 执行流程

1. 建立 component/import/route/state/event/network/native capability 图。
2. 执行组件拆分/合并、class→hooks、state store 迁移、路由和 API client 重构。
3. 对 Vue/React/Flutter 到微信/支付宝/抖音/小红书小程序保留平台能力差异和适配层。
4. 运行 type/build/unit/component/e2e、visual regression、a11y、bundle/performance。
5. 对埋点、实验、深链、权限、支付和原生桥单独验证。

## 输出

- `ClientPatchSet`
- `VisualDiff`
- `AccessibilityReport`
- `PlatformCompatibilityMatrix`

## 强制不变量

- 截图相似不能替代交互/可访问性测试。
- 跨端转换不伪造目标平台不支持的能力。
- 设计系统 token 和业务逻辑分离。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 关键用户旅程通过。
- 视觉差异在批准阈值内。
- 各目标平台构建和权限检查通过。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
