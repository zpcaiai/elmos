---
name: semantic-index
description: 建立跨语言符号、类型、调用、数据流、契约、构建和测试关联图。
risk: read-only
depends_on: repository-discovery, build-graph-and-environment
version: 1.0.0
---

# semantic-index

## 目的

建立跨语言符号、类型、调用、数据流、契约、构建和测试关联图。

## 输入

- `RepositoryInventory`
- `BuildGraph`
- `AdapterCapabilitySnapshot`

## 执行流程

1. 按语言调用 compiler/LSP/native parser 生成 lossless syntax 与类型归属。
2. 索引 definitions/references/imports/exports/calls/inheritance/overrides/reads/writes。
3. 识别反射、序列化、宏、模板、动态 import、配置键和字符串协议的潜在引用。
4. 关联 API/IDL/Schema/event/config、构建目标、测试、coverage、owner 和 runtime evidence。
5. 内容寻址保存分片，支持 revision 增量更新和 unknown risk。

## 输出

- `SemanticIndexSnapshot`
- `CoverageMetrics`
- `UnknownRegionReport`

## 强制不变量

- source range 必须可回溯到固定 revision。
- 低置信引用不能静默丢弃。
- native IR 与共享 IR 的版本/adapter provenance 必须保存。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 符号查询、caller/consumer/build target/test 查询可重复。
- 索引增量与全量结果在规定误差内一致。
- 高风险任务达到策略规定 resolution/type/build/test coverage。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
