---
name: api-compatibility
description: 检测并治理 source、binary、wire、behavior 和 SDK 兼容性。
risk: high
depends_on: semantic-index
version: 1.0.0
---

# api-compatibility

## 目的

检测并治理 source、binary、wire、behavior 和 SDK 兼容性。

## 输入

- `Baseline API snapshot`
- `candidate API snapshot`
- `compatibility policy`

## 执行流程

1. 抽取 exported/public symbols、signatures、annotations、ABI/wire/schema 和 generated SDK。
2. 分类 additive、source break、binary break、wire break、behavior risk。
3. 生成 overload/default/adapter/deprecation/versioned endpoint 等兼容策略。
4. 运行 consumer compile、contract tests、binary/API diff 和 serialization fixtures。
5. 生成 deprecation 生命周期和最终移除门。

## 输出

- `APIDiff`
- `CompatibilityDecision`
- `AdapterPatch`
- `DeprecationPlan`

## 强制不变量

- 新增 optional 字段也要验证默认和序列化语义。
- 名称不变不代表行为兼容。
- 外部消费者不可见时提高风险。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 所有 public changes 被分类。
- 策略禁止的 break 为零。
- 兼容层有使用监控和移除条件。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
