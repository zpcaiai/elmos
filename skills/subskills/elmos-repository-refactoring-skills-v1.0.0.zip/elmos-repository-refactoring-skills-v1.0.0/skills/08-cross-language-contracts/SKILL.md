---
name: cross-language-contract-refactor
description: 跨语言演进 REST/gRPC/GraphQL/SDK/事件/配置/文件格式契约与消费者。
risk: high
depends_on: impact-analysis, transform-executor, api-compatibility
version: 1.0.0
---

# cross-language-contract-refactor

## 目的

跨语言演进 REST/gRPC/GraphQL/SDK/事件/配置/文件格式契约与消费者。

## 输入

- `ContractGraph`
- `producer/consumer repositories`
- `compatibility policy`

## 执行流程

1. 识别 source-of-truth：OpenAPI/Proto/GraphQL schema/IDL/code-first annotations。
2. 计算 producer、generated clients、manual clients、tests、gateway、docs 和 observability consumers。
3. 采用 additive-first：新增字段/方法/版本、生成兼容 adapter、双版本验证。
4. 按 provider-before-consumer 或 consumer-before-provider 策略组织 waves。
5. 最终移除旧契约前验证 telemetry 中旧消费者归零并通过审批。

## 输出

- `ContractMigrationPlan`
- `CompatibilityAdapters`
- `ConsumerMatrix`
- `ContractDiff`

## 强制不变量

- 字段复用、enum ordinal、wire number、nullable/default 语义不可盲改。
- 生成代码从 IDL 重建，不直接长期维护生成物补丁。
- 不可见外部消费者视为风险而非不存在。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 契约 diff 可机器读取。
- 所有已知消费者通过 contract tests。
- 每一阶段可独立部署/回滚。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
