---
name: repository-discovery
description: 建立真实仓库、语言、模块、生成代码、敏感区和所有权清单。
risk: read-only
depends_on: none
version: 1.0.0
---

# repository-discovery

## 目的

建立真实仓库、语言、模块、生成代码、敏感区和所有权清单。

## 输入

- `RepositorySnapshot`
- `ignore/include policy`
- `sandbox capability`

## 执行流程

1. 验证 Git revision、submodule、LFS、symlink、case sensitivity、encoding 和 dirty state。
2. 识别语言、框架、package manager、monorepo tool、build files、IDL、migration、test 和 generated/vendor 目录。
3. 提取 CODEOWNERS、模块 owner、数据/支付/鉴权/加密等敏感区域。
4. 计算文件内容哈希、规模分布、超大文件、二进制、压缩包和未知类型。
5. 输出可信度和未扫描区域，禁止把 unreadable/unknown 当作 empty。

## 输出

- `RepositoryInventory`
- `LanguageInventory`
- `SensitiveAreaMap`
- `DiscoveryEvidence`

## 强制不变量

- 不执行仓库脚本。
- 不跟随越出工作区的符号链接。
- 任何过滤规则都进入证据。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 相同快照清单哈希稳定。
- 覆盖所有 tracked files 或明确列出例外。
- 能够识别 generated source 的源模板/生成器关系。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
