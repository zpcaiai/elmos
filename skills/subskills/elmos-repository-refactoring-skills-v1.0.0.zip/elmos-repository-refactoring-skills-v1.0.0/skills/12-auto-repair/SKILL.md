---
name: bounded-auto-repair
description: 依据构建/测试失败证据执行有预算、可解释、可回滚的自动修复。
risk: high
depends_on: test-and-verification
version: 1.0.0
---

# bounded-auto-repair

## 目的

依据构建/测试失败证据执行有预算、可解释、可回滚的自动修复。

## 输入

- `ValidationFailures`
- `PatchSet`
- `PlanStep ownership`
- `repair budget`

## 执行流程

1. 对失败归一化为 signature，映射到 owning recipe/action/shard。
2. 生成最小候选：imports、类型适配、调用点、fixture、兼容层、构建配置。
3. 在新 checkpoint 分支应用单一候选并只运行最小复现，再运行受影响门。
4. 记录 root cause、candidate rationale、diff、结果与成本。
5. 同签名循环、预算耗尽、scope/risk 扩大时停止并请求审批。

## 输出

- `RepairAttemptRecords`
- `UpdatedPatchSet`
- `UnresolvedFailureReport`

## 强制不变量

- 禁止删除/跳过测试、吞异常、全局 ignore、降级安全规则。
- 每次 repair 只解决已观察失败，不做无关清理。
- 失败候选完整回滚。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 修复前后失败签名可比较。
- 修复后重新通过所有相关硬门。
- 无无限重试或重复副作用。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
