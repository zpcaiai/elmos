---
name: multi-repository-refactor-program
description: 对多个仓库和团队按依赖、兼容窗口和发布节奏执行组织级重构。
risk: critical
depends_on: orchestrator, cross-language-contracts, canary-rollout
version: 1.0.0
---

# multi-repository-refactor-program

## 目的

对多个仓库和团队按依赖、兼容窗口和发布节奏执行组织级重构。

## 输入

- `RepositoryPortfolio`
- `dependency/ownership graph`
- `release calendars`
- `program intent`

## 执行流程

1. 建立跨仓库 artifact/API/event/SDK/deployment dependency graph。
2. 识别 source repo、generated clients、fork、镜像、内外部消费者。
3. 设计 wave 0 compatibility、provider waves、consumer waves、contract cleanup wave。
4. 为每仓库生成独立 Run，同时由 Program 维护全局 gate 和 rollback domain。
5. 跟踪 PR merge、release、adoption telemetry、exceptions 和 stuck consumers。

## 输出

- `ProgramPlan`
- `RepositoryRuns`
- `WaveDashboard`
- `AdoptionReport`

## 强制不变量

- 单仓成功不等于 program 成功。
- cleanup wave 不能早于消费者归零。
- 每个团队审批和 release window 独立尊重。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 波次 DAG 无破坏性顺序。
- 可暂停单仓而不丢失全局状态。
- program evidence 可下钻到每个 patch。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
