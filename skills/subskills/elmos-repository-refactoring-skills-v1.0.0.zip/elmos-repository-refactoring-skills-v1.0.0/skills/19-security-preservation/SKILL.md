---
name: security-preservation
description: 确保重构不削弱鉴权、输入验证、加密、秘密、依赖和供应链控制。
risk: critical
depends_on: test-verification, policy engine
version: 1.0.0
---

# security-preservation

## 目的

确保重构不削弱鉴权、输入验证、加密、秘密、依赖和供应链控制。

## 输入

- `SecurityBaseline`
- `PatchSet`
- `threat model`
- `policy`

## 执行流程

1. 比较 authn/authz、tenant boundary、validation、crypto、secret、logging 和 data exposure。
2. 运行 SAST/taint/dependency/license/secret/IaC/container scans。
3. 检测规则降级、异常吞噬、绕过检查、宽泛权限和危险默认值。
4. 高风险路径生成 abuse cases、negative tests 和 privilege-boundary tests。
5. 输出 SARIF、SBOM delta、threat-model delta 和审批项。

## 输出

- `SecurityDiff`
- `SARIF`
- `SBOMDelta`
- `ThreatModelDelta`

## 强制不变量

- 安全告警不能通过 ignore 作为默认修复。
- 模型无权读取真实 secrets。
- 新依赖必须有 provenance 与许可策略结果。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 无新增阻断级漏洞。
- 权限边界负向测试通过。
- 所有 suppressions 有显式批准和到期时间。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
