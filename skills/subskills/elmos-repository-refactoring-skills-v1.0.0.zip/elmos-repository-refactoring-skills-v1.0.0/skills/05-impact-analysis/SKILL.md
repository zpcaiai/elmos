---
name: change-impact-analysis
description: 计算代码、构建、测试、契约、数据、运行时和组织层面的完整变更闭包。
risk: read-only
depends_on: semantic-index, intent-compiler
version: 1.0.0
---

# change-impact-analysis

## 目的

计算代码、构建、测试、契约、数据、运行时和组织层面的完整变更闭包。

## 输入

- `CompiledIntent`
- `SemanticIndexSnapshot`
- `runtime/coverage evidence`

## 执行流程

1. 从 Change IR seed 沿 reference/call/import/export/build/contract/data edges 扩展闭包。
2. 计算 high fan-out symbol、shared header、base type、public package 和 dynamic boundary。
3. 识别测试闭包、消费者、部署单元、owner 和 release order。
4. 比较候选方案的 changed files、risk、compatibility layer、rollback domain 和 expected validation cost。
5. 输出 DAG、shards、waves、approval points 和 unknown-risk penalty。

## 输出

- `ImpactReport`
- `ChangeClosure`
- `TestSelectionPlan`
- `WavePlan`
- `RiskAssessment`

## 强制不变量

- unknown 不是 no-impact。
- 动态证据只能补充静态分析，不能抹除潜在消费者。
- 任何 scope expansion 必须重新运行影响分析。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 每个 changed target 有原因链。
- 公共契约消费者被列出或标记不可见。
- Plan DAG 无未解释的环；环需通过兼容层/阶段拆解。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
