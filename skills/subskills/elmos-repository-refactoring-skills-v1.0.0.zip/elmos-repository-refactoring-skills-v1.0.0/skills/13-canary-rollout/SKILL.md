---
name: canary-rollout
description: 把已验证变更以 PR、changeset、feature flag、shadow 或流量波次安全交付。
risk: critical
depends_on: test-and-verification, human-approval
version: 1.0.0
---

# canary-rollout

## 目的

把已验证变更以 PR、changeset、feature flag、shadow 或流量波次安全交付。

## 输入

- `ValidatedPatchSet`
- `DeploymentGraph`
- `SLO guardrails`
- `rollback bundle`

## 执行流程

1. 生成小型、可审阅、依赖有序的 PR/changeset 和 release notes。
2. 对 API/数据/服务重构配置 feature flag、dual path、shadow 和 canary。
3. 按 1%→5%→25%→50%→100% 或策略波次推进。
4. 比较 error、latency、resource、business KPI、data consistency 和 old-path usage。
5. 越界自动停止、回滚或保持双轨；所有决策写证据。

## 输出

- `PullRequests/Changesets`
- `RolloutPlan`
- `CanaryReport`
- `ReleaseEvidence`

## 强制不变量

- 未验证 rollback 不开始 canary。
- 业务指标未知时不得以技术指标单独批准高风险全量。
- 不自动删除兼容层，除非使用归零且审批通过。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 每个 wave 有开始/成功/失败条件。
- 回滚在目标 RTO 内完成。
- 最终状态和实际部署 revision 可核对。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
