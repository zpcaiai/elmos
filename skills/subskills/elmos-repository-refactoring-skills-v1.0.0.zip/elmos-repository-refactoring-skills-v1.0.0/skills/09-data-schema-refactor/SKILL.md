---
name: data-schema-refactor
description: 安全执行数据库、缓存、搜索索引和持久化模型的 expand-contract 重构。
risk: critical
depends_on: impact-analysis, human-approval, rollback-recovery
version: 1.0.0
---

# data-schema-refactor

## 目的

安全执行数据库、缓存、搜索索引和持久化模型的 expand-contract 重构。

## 输入

- `SchemaSnapshot`
- `data access graph`
- `migration policy`
- `volume/SLA`

## 执行流程

1. 识别真实 schema、ORM、migration history、queries、ETL/CDC/BI 和外部消费者。
2. 默认生成 expand：新增兼容结构、索引和双读/双写开关。
3. 设计可暂停、可重入、限速、分片的 backfill；记录 watermark 和校验和。
4. 验证读写一致性、锁/日志/复制延迟、容量、查询计划和回滚。
5. 在旧路径使用归零并审批后 contract；破坏性 DDL 单独 gate。

## 输出

- `SchemaMigrationPlan`
- `MigrationFiles`
- `BackfillWorkflow`
- `DataValidationReport`
- `RollbackPlan`

## 强制不变量

- 禁止一次性 rename/drop 关键列作为默认策略。
- migration 和应用部署顺序必须显式。
- 回滚不能依赖已丢失数据。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 每阶段 online-safe 或明确维护窗口。
- backfill 幂等且可断点恢复。
- 数据校验覆盖 row count、checksum、业务不变量和抽样。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
