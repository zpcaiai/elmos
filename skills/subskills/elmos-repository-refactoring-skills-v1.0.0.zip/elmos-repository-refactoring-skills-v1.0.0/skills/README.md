# 子 Skill 索引

| 序号 | Skill | 作用 |
|---|---|---|
| 00 | orchestrator | 持久化 DAG、预算、恢复与补偿 |
| 01–03 | discovery/build/index | 建立真实仓库、构建和语义基线 |
| 04–07 | intent/impact/recipe/transform | 从目标到确定性补丁 |
| 08–10 | contract/data/distributed | 高风险跨系统重构 |
| 11–15 | verify/repair/rollout/rollback/evidence | 证明、交付与恢复 |
| 16–17 | registry/approval | 企业治理与人机协作 |
| 18–22 | performance/security/API/multi-repo/UI | 专项质量与产品覆盖 |

总入口始终是根目录 `SKILL.md`，除非上层 Orchestrator 已明确满足依赖和策略。
