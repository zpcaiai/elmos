---
name: deterministic-transform-executor
description: 在隔离 worktree 中分片执行 Recipe，生成最小、可合并、可反演的补丁。
risk: high
depends_on: recipe-synthesis
version: 1.0.0
---

# deterministic-transform-executor

## 目的

在隔离 worktree 中分片执行 Recipe，生成最小、可合并、可反演的补丁。

## 输入

- `RecipeLock`
- `PlanStep`
- `RepositorySnapshot`
- `ShardPlan`

## 执行流程

1. 创建只针对固定 revision 的 isolated worktree/sandbox。
2. 校验 step 和 recipe preconditions、toolchain digest、read/write set。
3. 调用 Adapter lower/apply；记录每个 edit 的 symbol/source map/recipe action。
4. 局部格式化 touched ranges，运行 parse/round-trip/postconditions。
5. 合并 patch fragments；检测 source overlap、semantic conflict、rename/move 和 generated code 冲突。

## 输出

- `PatchSet`
- `ChangedSymbolSet`
- `SourceMap`
- `TransformEvidence`

## 强制不变量

- 不直接写主分支。
- 非计划文件修改触发 scope expansion。
- 不允许全仓格式化掩盖 diff。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- patch 可 clean apply 到固定 revision。
- 反向 patch 或 snapshot restore 可回滚。
- 并行/串行执行产生相同最终 tree hash。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
