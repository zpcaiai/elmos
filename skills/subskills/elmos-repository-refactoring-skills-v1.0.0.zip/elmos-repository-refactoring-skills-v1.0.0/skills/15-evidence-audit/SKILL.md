---
name: evidence-and-audit
description: 生成完整、可签名、可验证、可用于合规和计费的重构证据包。
risk: read-only
depends_on: all execution skills
version: 1.0.0
---

# evidence-and-audit

## 目的

生成完整、可签名、可验证、可用于合规和计费的重构证据包。

## 输入

- `Run event stream`
- `artifacts`
- `approvals`
- `tool provenance`

## 执行流程

1. 汇总 request、plan、policy、snapshot、toolchain、recipes.lock 和 adapter digests。
2. 关联每个 patch hunk 到 plan step、recipe action、symbol 和验证。
3. 封装 build/test/SARIF/API/Schema/performance/security/rollout/rollback 结果。
4. 生成 manifest、artifact hashes、provenance、retention 和 redaction records。
5. 签名 EvidenceBundle 并执行独立 schema/hash verification。

## 输出

- `EvidenceBundle`
- `SignedManifest`
- `AuditTimeline`
- `BillingBreakdown`

## 强制不变量

- 不把未验证模型叙述当证据。
- 敏感信息按策略脱敏，但保留不可抵赖哈希。
- 任何缺失必需 artifact 都阻断 success。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 100% changed hunks 可追溯。
- manifest hash 与实际 artifact 一致。
- 独立 verifier 可离线验证证据。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
