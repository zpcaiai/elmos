---
name: recipe-synthesis
description: 从 Registry 选择、组合或生成可测试、可签名、幂等的重构 Recipe。
risk: medium
depends_on: intent-compiler, impact-analysis
version: 1.0.0
---

# recipe-synthesis

## 目的

从 Registry 选择、组合或生成可测试、可签名、幂等的重构 Recipe。

## 输入

- `CompiledIntent`
- `ChangeClosure`
- `RecipeRegistry`
- `AdapterCapabilities`

## 执行流程

1. 优先复用 certified Recipe；按版本、语言、框架和 preconditions 过滤。
2. 组合多条 Recipe 为阶段化 DAG，检测 edit overlap 和 postcondition 冲突。
3. 无现成 Recipe 时由模型生成声明式候选或受限插件，并自动生成 positive/negative/idempotence fixtures。
4. 在 Golden sandbox 执行 dry-run、cardinality、round-trip、compile 和 rollback tests。
5. 生成 recipes.lock，固定 digest、adapter、toolchain、formatter 和 validation profile。

## 输出

- `RecipeSet`
- `RecipeLock`
- `DryRunPatch`
- `RecipeTestReport`

## 强制不变量

- draft/quarantined Recipe 不能自治执行。
- Recipe 不允许隐式扩大文件 glob。
- expected cardinality 不符默认失败。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 第二次执行零 diff。
- 同一输入和 lock 得到相同 patch hash。
- 所有 actions 有 pre/postconditions 与 rollback。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
