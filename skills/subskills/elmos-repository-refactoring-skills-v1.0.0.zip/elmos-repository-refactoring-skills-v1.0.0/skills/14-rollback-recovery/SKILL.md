---
name: rollback-and-recovery
description: 提供 step、shard、run、release 和数据迁移层的局部恢复与补偿。
risk: critical
depends_on: orchestrator
version: 1.0.0
---

# rollback-and-recovery

## 目的

提供 step、shard、run、release 和数据迁移层的局部恢复与补偿。

## 输入

- `Checkpoint`
- `SideEffectJournal`
- `PatchSet`
- `migration/rollout state`

## 执行流程

1. 确定失败边界和最后一致 checkpoint。
2. 对纯源码使用 reverse patch/tree restore；对外部副作用使用补偿。
3. 对数据迁移优先停止写入切换、回旧读路径、保留新增兼容结构。
4. 核对 DB state、artifact manifest、workspace tree 和 external systems。
5. 恢复后重新运行最小一致性验证并生成 incident evidence。

## 输出

- `RollbackExecution`
- `RecoveredCheckpoint`
- `IncidentReport`

## 强制不变量

- 不执行未知可逆性的自动数据回滚。
- 补偿操作也必须幂等。
- 恢复不能删除调查证据。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 注入任意已定义故障后状态一致。
- 源码 tree hash 回到预期值或明确前滚状态。
- 外部副作用有可核验结果。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
