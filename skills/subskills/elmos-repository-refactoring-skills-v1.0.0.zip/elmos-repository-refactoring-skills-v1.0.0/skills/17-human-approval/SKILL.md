---
name: human-approval-gate
description: 为高风险、不可逆、证据不足或策略冲突步骤提供细粒度审批。
risk: critical
depends_on: policy engine
version: 1.0.0
---

# human-approval-gate

## 目的

为高风险、不可逆、证据不足或策略冲突步骤提供细粒度审批。

## 输入

- `ApprovalRequest`
- `risk/evidence summary`
- `diff/plan`
- `required roles`

## 执行流程

1. 生成最小充分审批上下文：目标、diff、风险、替代方案、验证、回滚和费用。
2. 按角色、租户、仓库、环境、步骤和有效期校验权限。
3. 支持 approve/reject/request-changes/approve-with-conditions。
4. 批准绑定 request digest、plan version、recipe lock 和 patch hash；任一变化使批准失效。
5. 记录四眼审批、电子签名、理由和条件执行结果。

## 输出

- `ApprovalDecision`
- `Conditions`
- `AuditRecord`

## 强制不变量

- 批准不可泛化到不同 patch/hash。
- 执行者不能在策略要求时自批。
- 超时默认为不批准。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 审批条件可机器检查。
- 所有高风险步骤在执行前有有效批准。
- replan 后旧批准自动失效。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
