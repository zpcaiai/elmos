---
name: refactor-intent-compiler
description: 把自然语言重构目标编译成机器可检查的目标、非目标、约束和验收谓词。
risk: read-only
depends_on: semantic-index
version: 1.0.0
---

# refactor-intent-compiler

## 目的

把自然语言重构目标编译成机器可检查的目标、非目标、约束和验收谓词。

## 输入

- `RefactorRequest`
- `SemanticIndexSnapshot`
- `organization policies`

## 执行流程

1. 抽取目标、非目标、兼容窗口、性能/安全/成本 guardrail。
2. 把“不要改变行为”等模糊约束拆成 source/binary/wire/data/behavior/operational predicates。
3. 识别缺失业务语义并生成 assumptions 与阻断条件。
4. 形成 Change IR 候选和允许/禁止的 scope。
5. 对冲突约束给出最小冲突集，不擅自选择不可逆解释。

## 输出

- `CompiledIntent`
- `AcceptancePredicates`
- `AssumptionRegister`
- `ScopePolicy`

## 强制不变量

- 每个计划步骤必须映射到至少一个目标或必要前置。
- 非目标不因“顺手优化”被修改。
- 推断必须显式记录来源和置信度。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 所有用户验收要求有机器门或人工审批项。
- 冲突约束可被定位。
- 可从 CompiledIntent 生成 deterministic plan inputs。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
