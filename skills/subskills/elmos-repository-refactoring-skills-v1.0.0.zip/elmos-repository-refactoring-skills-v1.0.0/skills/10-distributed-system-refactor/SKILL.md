---
name: distributed-system-refactor
description: 重构服务边界、消息语义、事务、重试、幂等、缓存和容错策略。
risk: critical
depends_on: cross-language-contracts, data-schema-refactor, performance-preservation
version: 1.0.0
---

# distributed-system-refactor

## 目的

重构服务边界、消息语义、事务、重试、幂等、缓存和容错策略。

## 输入

- `ServiceGraph`
- `event/API contracts`
- `runtime traces`
- `SLO/error budget`

## 执行流程

1. 建立同步调用、异步事件、数据所有权、事务和故障域图。
2. 对单体拆分使用 branch-by-abstraction/strangler；避免直接共享数据库长期耦合。
3. 为事件定义 version、ordering、idempotency、dedupe、retry/DLQ 和 replay。
4. 跨服务写入使用 outbox/saga/补偿等显式模式，按业务语义选择。
5. 用故障注入、延迟、重复、乱序、分区和依赖降级验证。

## 输出

- `ServiceBoundaryPlan`
- `EventMigrationPlan`
- `ResilienceTests`
- `OperationalRunbook`

## 强制不变量

- 不把网络调用当本地调用。
- 重试必须有上限、退避、超时和幂等。
- 分布式事务语义变化必须审批。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 故障注入下满足一致性和 SLO guardrail。
- 消息可 replay 且不会重复副作用。
- 每个阶段具备回退/兼容路径。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
