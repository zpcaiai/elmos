---
name: build-graph-and-environment
description: 恢复可重复构建环境并生成跨语言 Build/Test Graph。
risk: medium
depends_on: repository-discovery
version: 1.0.0
---

# build-graph-and-environment

## 目的

恢复可重复构建环境并生成跨语言 Build/Test Graph。

## 输入

- `RepositoryInventory`
- `toolchain policy`
- `dependency/network policy`

## 执行流程

1. 识别 Maven/Gradle/Bazel/CMake/MSBuild/Cargo/go/npm/pnpm/yarn/Poetry/uv/Composer/Bundler/SwiftPM/Xcode/Flutter 等。
2. 固定运行时、编译器、SDK、包管理器和 lockfile；校验内部镜像与 checksum。
3. 解析 project references、workspace、target、source set、profile、feature 和 codegen。
4. 在未修改快照运行 restore/build/test baseline，并区分既有失败与环境失败。
5. 生成 file->target->test->artifact->deployable 图和可重复环境清单。

## 输出

- `BuildGraph`
- `ToolchainLock`
- `BaselineReport`
- `SandboxImageSpec`

## 强制不变量

- 默认无公网，restore 必须走策略允许的制品源。
- baseline 失败时不得声称具备完整语义。
- 不把本机偶然缓存作为可重复依赖。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 洁净 sandbox 可重现 baseline。
- 任一 source file 可追踪到一个或多个 build target，未知项明确标记。
- 工具链 digest 可用于缓存隔离。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
