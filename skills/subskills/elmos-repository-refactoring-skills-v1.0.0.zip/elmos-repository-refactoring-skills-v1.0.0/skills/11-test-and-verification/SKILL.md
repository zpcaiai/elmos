---
name: test-and-verification
description: 执行从语法到运行时的分层验证，并形成可机器裁决的质量门。
risk: high
depends_on: transform-executor
version: 1.0.0
---

# test-and-verification

## 目的

执行从语法到运行时的分层验证，并形成可机器裁决的质量门。

## 输入

- `PatchSet`
- `BaselineReport`
- `TestSelectionPlan`
- `PolicySnapshot`

## 执行流程

1. 先运行 parse/round-trip/format/import/type/compile/link。
2. 执行 Recipe tests、changed-target tests、contract/schema/API checks。
3. 按策略执行全量 unit/integration/e2e/UI/performance/security/reliability。
4. 与 baseline 比较，区分既有失败、flaky、环境失败和回归。
5. 生成 SARIF/JUnit/API diff/perf diff，并计算 evidence coverage。

## 输出

- `ValidationReport`
- `GateDecisions`
- `SARIF`
- `TestArtifacts`
- `RegressionDiff`

## 强制不变量

- 任何硬门失败不能被平均分抵消。
- flaky 只能隔离调查，不能自动记 pass。
- 测试删除/skip/规则降级触发反作弊门。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 每个 changed symbol/target 有测试或明确风险证据。
- 报告可重放并关联 tool/version/input hash。
- 成功状态满足全部适用硬门。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
