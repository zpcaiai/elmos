---
name: recipe-learning-registry
description: 管理 Recipe 生命周期，并从成功迁移与失败模式中安全学习。
risk: high
depends_on: evidence-audit
version: 1.0.0
---

# recipe-learning-registry

## 目的

管理 Recipe 生命周期，并从成功迁移与失败模式中安全学习。

## 输入

- `Verified runs`
- `manual PRs`
- `migration guides`
- `failure corpus`

## 执行流程

1. 抽取可泛化的 before/after、semantic predicates 和 context variables。
2. 由模型生成候选 Recipe 与 positive/negative/adversarial fixtures。
3. 在隔离 benchmark corpus 评测 precision、recall、idempotence、escape defects 和 cost。
4. 经 owner review/signature 晋级 draft→quarantined→verified→certified。
5. 监控线上异常；严重缺陷自动 revoke digest 并定位受影响 runs。

## 输出

- `VersionedRecipe`
- `EvaluationReport`
- `RegistryMetadata`
- `RevocationList`

## 强制不变量

- 客户代码不得未经授权进入共享 corpus。
- 一次成功不能直接晋级 certified。
- Recipe digest 不可变，更新必须新版本。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- 每个 certified Recipe 有完整 corpus 和 owner。
- 可查询适用版本/语言/框架/风险/历史成功率。
- revoked Recipe 无法新执行。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
