---
name: repository-refactor-orchestrator
description: 把仓库级重构编排为可恢复 DAG，负责状态、预算、策略、审批与补偿。
risk: high
depends_on: all child skills
version: 1.0.0
---

# repository-refactor-orchestrator

## 目的

把仓库级重构编排为可恢复 DAG，负责状态、预算、策略、审批与补偿。

## 输入

- `RefactorRequest`
- `固定仓库快照`
- `PolicySnapshot`
- `AdapterCapabilitySnapshot`

## 执行流程

1. 创建 RefactorProgram/Run，冻结 request、policy、revision 和 toolchain digest。
2. 根据阶段 DAG 调用 discovery、index、plan、transform、verify、rollout；每一步写 checkpoint。
3. 维护 step/shard 读写集、资源预算、并发限制、租户配额和 critical path。
4. 对失败分类为 retryable、repairable、approval-required、rollback-required、terminal。
5. 持续发布进度、P50/P80/P95 wall-clock ETA、成本和风险变化。

## 输出

- `持久化 Run 状态`
- `StepAttempt/Checkpoint/Event`
- `最终 EvidenceBundle/rollback bundle`

## 强制不变量

- 状态迁移只能由事件驱动且可重放。
- 相同 idempotency key 不得产生第二次副作用。
- 取消后停止新调度，等待安全点并执行必要补偿。

## 失败与升级

- 工具能力低于计划要求、输入快照变化、作用域扩大、风险升级、预算耗尽或硬门失败时，立即停止当前副作用并写入 checkpoint。
- 可恢复失败交给 Orchestrator 重试；语义不确定或不可逆风险进入审批；已产生外部副作用且无法安全继续时调用 rollback/recovery。
- 不允许通过降低验证、删除测试、修改无关文件或扩大 ignore 来规避失败。

## 验收标准

- Worker 在任意阶段崩溃后可从最近一致 checkpoint 恢复。
- 重放事件得到相同最终状态。
- 并发任务遵守每账号/租户限制。

## 遥测

至少记录 `run_id`、`step_id`、`shard_id`、输入/输出 digest、adapter/recipe/tool version、duration、resource、cost、status、failure_signature 和 evidence URI。源码内容不得直接进入普通日志。
