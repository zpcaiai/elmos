# Implementation Backlog

本清单用于把本 Skills Package 落地为 Elmos 产品代码。优先级不是能力缩水，而是上线顺序；所有 P0/P1/P2 接口已在本包中稳定定义。

## P0：可付费 Golden Route

| Epic | 必须交付 | 验收 |
|---|---|---|
| Core Orchestrator | 状态机、checkpoint、暂停/恢复/取消、幂等、租户隔离 | 故障注入后从最近 checkpoint 恢复且无重复副作用 |
| Repository Discovery | 语言、构建、生成代码、所有权、敏感区识别 | 1M LOC 仓库清单可分页、可重放、内容哈希稳定 |
| Semantic Index | 文件/符号/类型/调用/依赖/构建/测试图 | 增量更新；可追溯到 source span；索引版本化 |
| Recipe Runtime | declarative + imperative plugin、dry-run、幂等、冲突检测 | Golden before/after、第二次零 diff、并行合并确定性 |
| P0 Adapters | Java、TypeScript/JavaScript、Python、C#、Go | 每个达到 L3；至少 Java/Spring 达到 L4 Golden Route |
| Verification | parse/type/build/test/API/SARIF/evidence | 阻断级失败绝不进入 success；报告可机器读取 |
| Recovery | step/shard/task 回滚、补丁反演、artifact restore | 任意注入故障后工作区和状态库一致 |
| API & DB | OpenAPI、events、SQL migrations、tenant/cost | 端到端任务可查询、可审计、可计费 |

## P1：完整跨语言与跨系统

- Kotlin/Groovy/Scala、Rust、C/C++、PHP、Ruby、Swift/Objective-C、Dart/Flutter、SQL/IaC 适配器达到 L3；关键语言达到 L4。
- 公共 API、事件、数据库、缓存、搜索索引与配置的跨系统契约重构。
- 多仓库 wave、依赖顺序、兼容适配器、消费者验证和自动 PR 编排。
- UI 视觉回归、可访问性、端到端测试和跨端转换矩阵。
- 性能基线、Profile-guided 影响分析和自动 benchmark bisect。
- 组织级 Recipe Registry、签名、审批、版本与回滚治理。

## P2：SOTA 自进化能力

- 从成功人工 PR、迁移指南、编译错误和测试失败中合成可泛化 Recipe，经隔离评测后晋级。
- 动态/符号执行、差分运行、生产影子流量、形式化契约和等价性证明的可插拔验证器。
- 10M+ LOC / 数千仓库的 fleet modernization，按风险和业务窗口自动编排。
- 以结果为单位的计费：分析、变更、验证、迁移成功、节省工时和持续治理订阅。

## 禁止延期的横向能力

安全沙箱、最小权限、密钥隔离、证据、可观测性、成本核算、数据保留、审计、可恢复性和幂等性必须从 P0 第一版存在，不得作为后补项。
