---
name: elmos-repository-refactoring
version: 1.0.0
description: 跨语言、仓库级、可验证、可恢复、可审计的生产级项目重构总编排 Skill。
license: Elmos commercial-compatible
metadata:
  category: software-factory
  risk: high
  autonomy: policy-controlled
  owner: elmos-refactoring-platform
---

# Elmos Repository Refactoring

## 触发条件

当用户要求对一个或多个真实项目执行仓库级重构、架构调整、模块拆分/合并、跨语言 API 迁移、框架升级、数据库契约演进、性能/安全重构或大规模 codemod 时触发。

以下请求不得降级为普通代码生成：

- 涉及多个文件、模块、服务、仓库或语言。
- 修改公共 API、数据库、消息、配置、构建系统、依赖或部署接口。
- 需要编译、测试、性能、安全、兼容性或灰度验证。
- 需要暂停、恢复、取消、审批、回滚、审计或按结果收费。

## 必需输入

1. 精确仓库快照：URI、revision、submodules、LFS 状态和工作区脏状态。
2. 重构意图：目标、非目标、约束、验收标准、风险预算。
3. 兼容策略：行为、API、数据、消息、配置、部署与性能。
4. 执行模式：analyze-only、proposal、supervised、autonomous-low-risk、fleet-wave。
5. 允许的工具、网络、包安装、凭据和资源上限。

缺少非关键字段时使用企业默认策略；不得因可推断字段缺失而阻塞整个任务。涉及不可逆数据操作、生产凭据或未定义业务语义时，生成阻断证据并进入审批门。

## 输出

- `RepositoryInventory`
- `SemanticIndexSnapshot`
- `RefactorPlan`
- `RecipeLock`
- `PatchSet` / PR / changeset
- 自动生成或更新的测试
- `EvidenceBundle`
- `RollbackBundle`
- 成本、ETA、进度、风险和质量指标

## 不可违反的 Invariants

- 所有修改必须发生在隔离的 worktree/sandbox 中。
- 任何最终 patch 必须来自已登记 Recipe 或明确标记的人工补丁步骤。
- 高风险步骤不得仅凭 LLM 自评通过。
- 验证失败不得通过删除测试、降低规则严重性或扩大 ignore 范围来“修复”。
- 默认不访问公网；安装依赖和执行仓库脚本遵守 allowlist 与审批策略。
- 失败后保留最后一致 checkpoint；重试必须使用幂等键。
- 任何数据库破坏性变更必须采用 expand-contract 或获得显式例外批准。

## 总流程

1. 调用 `01-repository-discovery` 建立仓库清单和信任边界。
2. 调用 `02-build-graph-and-environment` 恢复可重复构建环境。
3. 调用 `03-semantic-index` 建立多层代码与契约图。
4. 调用 `04-refactor-intent-compiler` 把自然语言目标编译为机器约束。
5. 调用 `05-impact-analysis` 计算变更闭包、风险、测试闭包与波次。
6. 调用 `06-recipe-synthesis` 选择、组合或生成 Recipe；锁定版本和工具链。
7. 调用 `07-transform-executor` 在分片工作区执行确定性修改。
8. 视任务调用契约、数据库、分布式系统、UI、性能和安全专项 Skill。
9. 调用 `11-test-and-verification`；失败时调用 `12-auto-repair`，但受预算和范围约束。
10. 高风险步骤调用 `17-human-approval`。
11. 调用 `13-canary-rollout` 或生成 PR；任何失败可调用 `14-rollback-recovery`。
12. 调用 `15-evidence-audit` 封装并签名证据。
13. 将成功 Recipe 与失败模式写入 `16-recipe-learning-registry`。

## 风险等级

- R0：只读分析。
- R1：格式、局部命名、无外部可见行为的确定性修改。
- R2：项目内符号/模块变化，编译与测试可完整证明。
- R3：公共 API、依赖、框架、并发、性能或跨服务变化。
- R4：数据库、消息语义、鉴权、支付、加密、数据保留或生产部署变化。
- R5：不可逆、证据不足、业务语义冲突或无法建立可靠环境；禁止自治执行。

## 完成条件

遵循 `docs/07-safety-quality-gates.md`。任何阻断级门失败时，状态必须为 `FAILED_VALIDATION`、`BLOCKED_APPROVAL` 或 `PARTIAL_WITH_ROLLBACK`，不得标记成功。
