# Contracts

- JSON Schema 使用 draft 2020-12。
- 所有持久化对象都带版本与 digest；生产实现应对 Schema 做兼容性测试。
- OpenAPI 中的相对 `$ref` 在打包/发布时应由构建流程 bundle 成单文件版本。
- Protobuf Event Envelope 用于事件总线；`sequence` 在 run 内单调递增，消费者按 `event_id` 幂等。
