# Elmos Repository Refactoring Skills Package

**版本：v1.0.0｜级别：Enterprise Production Specification｜目标：跨语言、仓库级、可验证、可恢复、可审计的自动重构**

本包把“项目重构”定义为一个受约束的软件变更程序，而不是让大模型直接批量改文件。Elmos 负责从重构意图出发，建立完整仓库语义模型，生成确定性 Recipe，分阶段修改代码、配置、依赖、数据库与接口，执行构建和测试，自动修复有限范围内的问题，最后交付可审阅补丁、验证证据、回滚包与运行指标。

## 1. 产品边界

支持以下仓库级任务：

- 跨文件、跨模块、跨服务、跨仓库的符号重命名、包/命名空间移动、API 签名修改、模块抽取、模块合并与依赖倒置。
- 单体拆分、分层重构、领域边界调整、共享库治理、循环依赖消除、重复代码收敛、废弃代码删除。
- 框架与运行时升级、依赖升级、语言版本升级、同步转异步、并发模型调整、错误处理模型迁移。
- REST/gRPC/GraphQL/Event/SDK 契约演进，数据库 Schema 的 expand-contract 迁移，消息事件版本化。
- 前端组件、状态管理、路由、网络层、设计系统和跨端工程重构；覆盖 React、Vue、Flutter 及小程序目标矩阵。
- 性能、安全、可观测性、可测试性、可维护性与云原生改造。

不允许把以下行为默认为“完成”：只生成建议、不执行构建；只做文本替换；仅通过局部测试；把失败测试标记为忽略；无回滚证据；无法解释每个改动来自哪条 Recipe。

## 2. 七项强制设计原则

1. **编译器语义优先**：优先调用语言编译器、语言服务或原生分析 API；CST/Tree-sitter 用于格式保持和长尾覆盖；正则/纯文本仅限明确批准的低风险文件类型。
2. **Lossless 修改**：尽量保留注释、空白、换行、编码、文件头、局部风格和未相关代码，禁止“格式化整个仓库掩盖真实变更”。
3. **LLM 只负责推理和合成，不直接成为最终执行器**：模型生成意图、候选 Recipe、失败归因与修复建议；最终补丁由确定性变换器执行并由验证器裁决。
4. **先证明适用，再修改**：每条 Recipe 必须定义 applicability、preconditions、negative guards、postconditions、idempotence 与 rollback。
5. **风险分级自动化**：低风险可全自动；公共 API、数据库、鉴权、支付、加密、并发、数据删除等必须进入审批门和更强验证门。
6. **可恢复长任务**：所有节点幂等、可检查点、可暂停/恢复/取消；网络中断、Worker 故障或服务重启后从最近一致状态继续。
7. **证据即产物**：补丁、构建日志、测试结果、API diff、Schema diff、性能对比、安全扫描、审批记录和回滚说明一起交付。

## 3. 支持范围

| 领域 | 生产目标语言/技术 | 首选语义引擎 |
|---|---|---|
| JVM | Java、Kotlin、Groovy、Scala | OpenRewrite/JDT/K2 Analysis API/编译器模型 |
| .NET | C#、VB.NET、F#（结构层） | Roslyn/MSBuild Workspace/FCS |
| Python | Python | LibCST、`ast`、类型检查器与 import graph |
| Web/Node | JavaScript、TypeScript、React、Vue、Node.js | TypeScript Compiler API/tsserver、框架编译器、CST |
| Systems | C、C++、Rust、Go | Clang LibTooling/Transformer、rust-analyzer、go/types/gopls |
| Mobile | Swift、Objective-C、Dart、Flutter | SwiftSyntax/SourceKit/Clang、Dart analyzer |
| Dynamic | PHP、Ruby | PHP-Parser、Prism/Parser、静态类型工具可选 |
| Data/IaC | SQL、Shell、Terraform、YAML、JSON、XML、Dockerfile、K8s | 方言解析器、Tree-sitter、Schema/Provider validator |

每个适配器必须公布 **L0–L4 能力等级**，不能用“支持”掩盖语义能力差异：

- L0：只识别文件；禁止自动修改。
- L1：语法/CST 安全改写。
- L2：符号和类型感知的项目内改写。
- L3：仓库级调用图、依赖图、构建图与契约感知。
- L4：经过 Golden Corpus、故障注入、性能与大仓库认证，可在策略允许时自治执行。

## 4. 包结构

- `SKILL.md`：总编排 Skill。
- `skills/`：23 个可独立调用的生产技能。
- `contracts/`：请求、计划、Recipe、Semantic IR、证据、审批、策略、事件与 API 契约。
- `adapters/`：各语言及构建生态的适配器规范。
- `recipes/`：通用与语言专项 Recipe 示例。
- `policies/`：企业默认、公共 API、数据库、安全敏感与自治模式策略。
- `workflows/`：长任务状态机、分片和多仓库波次。
- `db/`：运行状态、补丁、证据、审批和指标的数据库 Migration。
- `telemetry/`：OpenTelemetry 属性、指标和看板定义。
- `tests/`：契约、Golden、故障注入和生产认证测试。
- `runbooks/`：大型仓库、失败恢复、灰度回滚、安全事件和适配器接入手册。
- `reference/`：TypeScript 参考接口与编排骨架。
- `ci/`：CI 质量门示例。

## 5. 推荐接入 Elmos 主仓库

```text
packages/repository-refactoring/
  package.yaml
  SKILL.md
  skills/
  contracts/
  adapters/
  recipes/
  policies/
services/refactor-orchestrator/
services/refactor-indexer/
services/refactor-worker-*/
services/refactor-verifier/
```

接入顺序：

1. 注册 `package.yaml` 与 Skill Catalog。
2. 执行 `db/migrations/*.sql`。
3. 实现 `contracts/openapi.yaml` 和 `contracts/events.proto`。
4. 先上线 Java/TypeScript/Python/C#/Go 五个 P0 适配器，再按认证矩阵开放其他适配器。
5. 把构建、测试、安全扫描与证据生成接入现有 Elmos Harness、缓存、任务恢复、计费和部署门。
6. 只有通过 `tests/acceptance/production-certification.yaml` 的适配器才允许启用自治模式。

## 6. 最小调用示例

```yaml
kind: RefactorRequest
apiVersion: elmos.dev/v1
metadata:
  tenantId: acme
  projectId: billing-platform
spec:
  repositories:
    - uri: git@example/acme/billing.git
      revision: 8a8f...c31
  intent:
    type: architecture-refactor
    goals:
      - split payment orchestration from legacy order service
      - remove cyclic dependencies between order, billing and notification
  constraints:
    behaviorCompatibility: strict
    publicApiCompatibility: backward-compatible
    databaseStrategy: expand-contract
    maximumChangedFiles: 800
  execution:
    mode: supervised
    createPullRequest: true
```

## 7. 商业生产 Definition of Done

一次重构任务只有同时满足以下条件才可标记为 `SUCCEEDED`：

- 计划中的所有必要步骤完成，未批准步骤未越权执行。
- 修改可重复：同一快照、同一 Recipe lock、同一工具链得到相同 patch hash。
- Recipe 幂等：第二次执行不再产生非预期差异。
- 解析、类型检查、编译和受影响测试通过；策略要求时全量测试通过。
- 公共 API、消息、Schema、配置与依赖变化有机器可读 diff，并符合兼容性策略。
- 性能、安全、许可证、SBOM、密钥与供应链门未出现阻断级回归。
- 每个 changed hunk 能映射到 plan step、recipe execution 和 evidence record。
- 生成可执行回滚包；数据库/消息类变更具有前滚与回滚路径。
- 所有日志、指标、审批和成本数据持久化，任务可审计、可重放。

详细实现见 `docs/` 与各子 Skill。


## 8. 本包验证状态

本包已经通过离线结构、契约和参考实现验收：17 条 Recipe、13 个适配器描述、9 份 JSON Schema、OpenAPI、Protobuf、PostgreSQL Migration、严格 TypeScript 骨架以及 Java/TypeScript/Python/SQL Golden 种子样例均已校验。详情见 `VALIDATION_REPORT.md`。

必须区分“生产级规范”与“已认证运行时”：本包给出可直接实现的稳定契约和工程骨架，但 Recipe 示例保持 `draft`，适配器源描述保持 `L0`。只有真实实现通过 `tests/acceptance/production-certification.yaml` 并写入签名 registry 后，才可宣称 L3/L4 或开放自治模式。

## 9. 补充入口

- `docs/15-operation-catalog.md`：Java、Kotlin、C#、Python、JavaScript/TypeScript、Go、Rust、C/C++、PHP、Ruby、Swift/Objective-C、Dart/Flutter、SQL/IaC 的操作与语义边界。
- `sources/capability-basis.md`：官方编译器、语义树、SARIF 与 OpenTelemetry 能力依据。
- `VALIDATION_REPORT.md`：已执行验证与未认证边界。
- `RELEASE_CHECKLIST.md`：包发布、适配器认证和生产上线清单。
- `scripts/validate_package.py`：离线 fail-closed 验收。
