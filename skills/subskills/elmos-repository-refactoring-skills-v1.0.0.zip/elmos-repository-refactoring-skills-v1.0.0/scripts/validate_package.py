#!/usr/bin/env python3
"""Validate the Elmos repository-refactoring skill package.

The validator is intentionally offline and fail-closed. It checks syntax, JSON Schema
contracts, catalog/path integrity, recipe invariants, adapter declarations, OpenAPI
local references, package manifest paths, database transaction wrappers, and the
TypeScript reference skeleton.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import yaml
from jsonschema import Draft202012Validator


@dataclass
class Finding:
    severity: str
    code: str
    path: str
    message: str


@dataclass
class Report:
    root: Path
    findings: list[Finding] = field(default_factory=list)
    counters: dict[str, int] = field(default_factory=dict)

    def count(self, key: str, amount: int = 1) -> None:
        self.counters[key] = self.counters.get(key, 0) + amount

    def add(self, severity: str, code: str, path: Path | str, message: str) -> None:
        value = str(path)
        try:
            value = str(Path(path).relative_to(self.root))
        except (ValueError, TypeError):
            pass
        self.findings.append(Finding(severity, code, value, message))

    @property
    def errors(self) -> list[Finding]:
        return [finding for finding in self.findings if finding.severity == "error"]

    @property
    def warnings(self) -> list[Finding]:
        return [finding for finding in self.findings if finding.severity == "warning"]


def load_data(path: Path) -> Any:
    text = path.read_text(encoding="utf-8")
    if path.suffix == ".json":
        return json.loads(text)
    if path.suffix in {".yaml", ".yml"}:
        return yaml.safe_load(text)
    raise ValueError(f"Unsupported data file: {path}")


def iter_files(root: Path, suffixes: set[str]) -> Iterable[Path]:
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.suffix.lower() in suffixes:
            yield path


def validate_parse(report: Report) -> None:
    for path in iter_files(report.root, {".json", ".yaml", ".yml"}):
        try:
            load_data(path)
            report.count(f"parsed_{path.suffix.lstrip('.')}")
        except Exception as exc:  # noqa: BLE001 - validator reports any parser error
            report.add("error", "DATA_PARSE", path, str(exc))


def schema_validator(root: Path, relative: str) -> Draft202012Validator:
    schema = json.loads((root / relative).read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema)


def validate_against(report: Report, data_path: Path, validator: Draft202012Validator) -> None:
    try:
        data = load_data(data_path)
    except Exception:
        return
    errors = sorted(validator.iter_errors(data), key=lambda error: list(error.absolute_path))
    if errors:
        for error in errors:
            pointer = "/" + "/".join(str(item) for item in error.absolute_path)
            report.add("error", "SCHEMA", data_path, f"{pointer}: {error.message}")
    else:
        report.count("schema_validated")


def validate_contracts(report: Report) -> None:
    mappings: list[tuple[str, list[Path]]] = [
        (
            "contracts/recipe.schema.json",
            [
                path
                for path in report.root.glob("recipes/**/*.yaml")
                if path.name != "catalog.yaml"
            ],
        ),
        (
            "contracts/language-adapter.schema.json",
            [
                path
                for path in report.root.glob("adapters/*.yaml")
                if path.name != "adapter-matrix.yaml"
            ],
        ),
        ("contracts/policy.schema.json", list(report.root.glob("policies/*.yaml"))),
        (
            "contracts/refactor-request.schema.json",
            [report.root / "tests/fixtures/sample-request.yaml"],
        ),
        (
            "contracts/refactor-plan.schema.json",
            [report.root / "tests/fixtures/sample-plan.json"],
        ),
        (
            "contracts/evidence-bundle.schema.json",
            [report.root / "tests/fixtures/sample-evidence-bundle.json"],
        ),
    ]
    for schema_path, paths in mappings:
        try:
            validator = schema_validator(report.root, schema_path)
            report.count("schemas_checked")
        except Exception as exc:  # noqa: BLE001
            report.add("error", "SCHEMA_INVALID", report.root / schema_path, str(exc))
            continue
        for path in paths:
            if not path.exists():
                report.add("error", "FIXTURE_MISSING", path, "Expected contract fixture is missing")
                continue
            validate_against(report, path, validator)


def validate_package_manifest(report: Report) -> None:
    path = report.root / "package.yaml"
    data = load_data(path)
    declared_paths: list[str] = []
    spec = data.get("spec", {})
    entrypoint = spec.get("entrypoint")
    if isinstance(entrypoint, str):
        declared_paths.append(entrypoint)
    for value in spec.get("persistence", {}).get("migrations", []):
        if isinstance(value, str):
            declared_paths.append(value)
    for value in spec.get("contracts", {}).values():
        if isinstance(value, str):
            declared_paths.append(value)
    suite = spec.get("certification", {}).get("suite")
    if isinstance(suite, str):
        declared_paths.append(suite)
    for relative in declared_paths:
        if not (report.root / relative).exists():
            report.add("error", "MANIFEST_PATH", path, f"Declared path does not exist: {relative}")
    report.count("manifest_paths", len(declared_paths))


def validate_recipe_catalog(report: Report) -> None:
    path = report.root / "recipes/catalog.yaml"
    catalog = load_data(path)
    seen_names: set[str] = set()
    seen_paths: set[str] = set()
    for entry in catalog.get("entries", []):
        name = entry.get("name")
        relative = entry.get("path")
        if not isinstance(name, str) or not isinstance(relative, str):
            report.add("error", "CATALOG_ENTRY", path, f"Invalid catalog entry: {entry!r}")
            continue
        if name in seen_names:
            report.add("error", "CATALOG_DUPLICATE_NAME", path, name)
        if relative in seen_paths:
            report.add("error", "CATALOG_DUPLICATE_PATH", path, relative)
        seen_names.add(name)
        seen_paths.add(relative)
        recipe_path = report.root / "recipes" / relative
        if not recipe_path.exists():
            report.add("error", "CATALOG_MISSING", path, f"Missing {relative}")
            continue
        recipe = load_data(recipe_path)
        metadata = recipe.get("metadata", {})
        spec = recipe.get("spec", {})
        if metadata.get("name") != name:
            report.add("error", "CATALOG_NAME_MISMATCH", recipe_path, f"Expected {name}")
        if spec.get("riskClass") != entry.get("riskClass"):
            report.add("error", "CATALOG_RISK_MISMATCH", recipe_path, f"Catalog risk differs for {name}")
    recipe_files = {
        str(path.relative_to(report.root / "recipes"))
        for path in report.root.glob("recipes/**/*.yaml")
        if path.name != "catalog.yaml"
    }
    missing_from_catalog = recipe_files - seen_paths
    for relative in sorted(missing_from_catalog):
        report.add("error", "CATALOG_UNLISTED", report.root / "recipes" / relative, "Recipe not listed")
    report.count("recipes_cataloged", len(seen_paths))


def validate_recipes(report: Report) -> None:
    for path in sorted(report.root.glob("recipes/**/*.yaml")):
        if path.name == "catalog.yaml":
            continue
        recipe = load_data(path)
        spec = recipe.get("spec", {})
        metadata = recipe.get("metadata", {})
        actions = spec.get("actions", [])
        action_ids = [action.get("id") for action in actions if isinstance(action, dict)]
        if len(action_ids) != len(set(action_ids)):
            report.add("error", "RECIPE_ACTION_IDS", path, "Action IDs must be unique")
        if not spec.get("postconditions"):
            report.add("error", "RECIPE_POSTCONDITIONS", path, "Write recipe must have postconditions")
        if not spec.get("idempotence"):
            report.add("error", "RECIPE_IDEMPOTENCE", path, "Idempotence contract is required")
        if not spec.get("rollback"):
            report.add("error", "RECIPE_ROLLBACK", path, "Rollback contract is required")
        for index, gate in enumerate(spec.get("validation", [])):
            if not isinstance(gate.get("timeoutSeconds"), int) or gate["timeoutSeconds"] <= 0:
                report.add("error", "RECIPE_GATE_TIMEOUT", path, f"Validation gate {index} needs a positive timeout")
        languages = spec.get("languages", [])
        if "*" in languages:
            expressions = [item.get("expression", "") for item in spec.get("applicability", [])]
            if not any("adapter.capability" in expression for expression in expressions):
                report.add("error", "RECIPE_WILDCARD_CAPABILITY", path, "Wildcard language recipe needs adapter capability predicate")
        if metadata.get("status") == "certified":
            report.add("warning", "EXAMPLE_CERTIFIED", path, "Packaged examples should not claim certification")
        report.count("recipes_linted")


def validate_adapters(report: Report) -> None:
    matrix = load_data(report.root / "adapters/adapter-matrix.yaml")
    matrix_ids = {entry.get("id") for entry in matrix.get("adapters", [])}
    descriptor_ids = {path.stem for path in report.root.glob("adapters/*.yaml") if path.name != "adapter-matrix.yaml"}
    for adapter_id in sorted(matrix_ids - descriptor_ids):
        report.add("error", "ADAPTER_DESCRIPTOR_MISSING", report.root / "adapters/adapter-matrix.yaml", str(adapter_id))
    for adapter_id in sorted(descriptor_ids - matrix_ids):
        report.add("error", "ADAPTER_MATRIX_MISSING", report.root / f"adapters/{adapter_id}.yaml", str(adapter_id))
    for path in sorted(report.root.glob("adapters/*.yaml")):
        if path.name == "adapter-matrix.yaml":
            continue
        adapter = load_data(path)
        metadata = adapter.get("metadata", {})
        spec = adapter.get("spec", {})
        if metadata.get("certificationLevel") != "L0":
            report.add(
                "warning",
                "UNSIGNED_CERTIFICATION",
                path,
                "Source descriptors should remain L0 until signed registry certification exists",
            )
        digest = metadata.get("digest")
        if not isinstance(digest, str) or not digest.startswith("sha256:"):
            report.add("error", "ADAPTER_DIGEST", path, "Adapter digest must start with sha256:")
        required_ops = {"probe", "restore", "parse", "index", "query", "lower", "apply", "format", "validate", "rollback"}
        missing = required_ops - set(spec.get("operations", []))
        if missing:
            report.add("error", "ADAPTER_OPERATIONS", path, f"Missing operations: {sorted(missing)}")
        security = spec.get("security", {})
        if security.get("network") not in {"deny", "restore-only", "allowlisted"}:
            report.add("error", "ADAPTER_NETWORK", path, "Invalid or missing network policy")
        report.count("adapters_linted")


def validate_openapi(report: Report) -> None:
    path = report.root / "contracts/openapi.yaml"
    data = load_data(path)
    if data.get("openapi") != "3.1.0":
        report.add("error", "OPENAPI_VERSION", path, "Expected OpenAPI 3.1.0")
    text = path.read_text(encoding="utf-8")
    for reference in re.findall(r"\$ref:\s*['\"]([^'\"]+)['\"]", text):
        if reference.startswith("#"):
            continue
        local = (path.parent / reference).resolve()
        if not local.exists():
            report.add("error", "OPENAPI_REF", path, f"Missing local reference {reference}")
    operation_ids: list[str] = []
    for route in data.get("paths", {}).values():
        if not isinstance(route, dict):
            continue
        for method in route.values():
            if isinstance(method, dict) and isinstance(method.get("operationId"), str):
                operation_ids.append(method["operationId"])
    duplicates = sorted({item for item in operation_ids if operation_ids.count(item) > 1})
    if duplicates:
        report.add("error", "OPENAPI_OPERATION_ID", path, f"Duplicate operationIds: {duplicates}")
    report.count("openapi_operations", len(operation_ids))


def validate_proto(report: Report) -> None:
    path = report.root / "contracts/events.proto"
    text = path.read_text(encoding="utf-8")
    for required in ["syntax = \"proto3\"", "message RefactorEvent", "run_id", "sequence", "idempotency_key"]:
        if required not in text:
            report.add("error", "PROTO_REQUIRED", path, f"Missing token: {required}")
    if text.count("{") != text.count("}"):
        report.add("error", "PROTO_BRACES", path, "Unbalanced braces")
    report.count("proto_files")


def validate_sql(report: Report) -> None:
    for path in sorted(report.root.glob("db/migrations/*.sql")):
        text = path.read_text(encoding="utf-8").strip()
        if not text.startswith("BEGIN;") or not text.endswith("COMMIT;"):
            report.add("error", "SQL_TRANSACTION", path, "Migration must be wrapped in BEGIN/COMMIT")
        report.count("sql_migrations")


def validate_golden_cases(report: Report) -> None:
    for path in sorted(report.root.glob("tests/golden/**/case.yaml")):
        case = load_data(path)
        spec = case.get("spec", {})
        for key in ("inputRoot", "expectedRoot"):
            value = spec.get(key)
            if not isinstance(value, str) or not (path.parent / value).exists():
                report.add("error", "GOLDEN_ROOT", path, f"Missing {key}: {value}")
        recipe = spec.get("recipe")
        adapter = spec.get("adapter")
        for key, value in (("recipe", recipe), ("adapter", adapter)):
            if not isinstance(value, str) or not (report.root / value).exists():
                report.add("error", "GOLDEN_REFERENCE", path, f"Missing {key}: {value}")
        if spec.get("expected", {}).get("secondRunDiff") != "empty" and case.get("metadata", {}).get("riskClass") != "R0":
            report.add("error", "GOLDEN_IDEMPOTENCE", path, "Golden write case must require empty second run")
        report.count("golden_cases")


def validate_typescript(report: Report, run_external: bool) -> None:
    if not run_external:
        return
    directory = report.root / "reference/typescript"
    try:
        completed = subprocess.run(
            ["npm", "run", "typecheck"],
            cwd=directory,
            check=False,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=120,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        report.add("error", "TYPESCRIPT_TOOL", directory, str(exc))
        return
    if completed.returncode != 0:
        report.add("error", "TYPESCRIPT", directory, completed.stdout[-4000:])
    else:
        report.count("typescript_typecheck")


def render(report: Report, output: Path | None) -> int:
    status = "PASS" if not report.errors else "FAIL"
    payload = {
        "status": status,
        "root": str(report.root),
        "counters": dict(sorted(report.counters.items())),
        "errors": [finding.__dict__ for finding in report.errors],
        "warnings": [finding.__dict__ for finding in report.warnings],
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return 0 if status == "PASS" else 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    parser.add_argument("--skip-external", action="store_true")
    args = parser.parse_args()

    report = Report(args.root.resolve())
    validate_parse(report)
    validate_contracts(report)
    validate_package_manifest(report)
    validate_recipe_catalog(report)
    validate_recipes(report)
    validate_adapters(report)
    validate_openapi(report)
    validate_proto(report)
    validate_sql(report)
    validate_golden_cases(report)
    validate_typescript(report, not args.skip_external)
    return render(report, args.output)


if __name__ == "__main__":
    sys.exit(main())
