#!/usr/bin/env python3
"""Smoke-check the included Golden Corpus seed fixtures.

This confirms that canonical `after/` code parses/builds in the local toolchain and
that the fixtures preserve the intended literal/non-symbol cases. It does not grant
adapter or Recipe certification; the production harness must actually execute the
pinned adapter and compare the resulting patch to these trees.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def run(command: list[str], cwd: Path) -> dict[str, object]:
    completed = subprocess.run(
        command,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
        timeout=120,
    )
    return {
        "command": command,
        "cwd": str(cwd.relative_to(ROOT)) if cwd.is_relative_to(ROOT) else str(cwd),
        "returnCode": completed.returncode,
        "output": completed.stdout[-4000:],
    }


def main() -> int:
    results: list[dict[str, object]] = []
    with tempfile.TemporaryDirectory(prefix="elmos-golden-") as temp_value:
        temp = Path(temp_value)

        java_src = ROOT / "tests/golden/rename-symbol/java/basic/after/src/main/java/com/acme"
        java_work = temp / "java"
        shutil.copytree(java_src, java_work)
        results.append(run(["javac", "--release", "17", *sorted(path.name for path in java_work.glob("*.java"))], java_work))
        controller = (java_work / "UserController.java").read_text(encoding="utf-8")
        results.append({
            "assertion": "java-string-literal-preserved",
            "passed": 'String auditLabel = "findUser";' in controller and ".loadUser(" in controller,
        })

        ts_src = ROOT / "tests/golden/rename-symbol/typescript/basic/after"
        ts_work = temp / "typescript"
        shutil.copytree(ts_src, ts_work)
        results.append(
            run(
                [
                    "tsc",
                    "--noEmit",
                    "--strict",
                    "--target",
                    "ES2022",
                    "--module",
                    "NodeNext",
                    *sorted(str(path.relative_to(ts_work)) for path in ts_work.glob("src/*.ts")),
                ],
                ts_work,
            )
        )
        ts_controller = (ts_work / "src/controller.ts").read_text(encoding="utf-8")
        results.append({
            "assertion": "typescript-object-key-and-literal-preserved",
            "passed": '{ fetchUser: "fetchUser" }' in ts_controller and "service.loadUser" in ts_controller,
        })

        python_src = ROOT / "tests/golden/package-rename/python/basic/after"
        python_work = temp / "python"
        shutil.copytree(python_src, python_work)
        results.append(run([sys.executable, "-m", "compileall", "-q", "."], python_work))
        results.append(run([sys.executable, "main.py"], python_work))

        sql_root = ROOT / "tests/golden/expand-contract/sql/column-rename/after"
        sql_files = sorted(path.name for path in sql_root.glob("*.sql"))
        sql_text = "\n".join(path.read_text(encoding="utf-8") for path in sorted(sql_root.glob("*.sql")))
        results.append({
            "assertion": "sql-phases-separated-and-ordered",
            "passed": sql_files == ["001_expand.sql", "002_backfill.sql", "003_contract.sql"]
            and "ADD COLUMN display_name" in sql_text
            and "DROP COLUMN full_name" in sql_text,
        })

    failed = [
        item
        for item in results
        if ("returnCode" in item and item["returnCode"] != 0)
        or ("passed" in item and item["passed"] is not True)
    ]
    report = {"status": "PASS" if not failed else "FAIL", "results": results, "failed": failed}
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
