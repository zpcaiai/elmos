# Changelog

## 1.0.0

- 首个企业生产级规范版本。
- 定义跨语言 Semantic IR、Recipe DSL、语言适配器契约和 23 个子 Skill。
- 增加大仓库分片、长任务恢复、多仓库波次、验证/自动修复、审批、证据和回滚体系。
- 提供 OpenAPI、Protobuf、JSON Schema、SQL Migration、CI、遥测、Runbook 与参考实现骨架。
- 增加 15 类跨语言 Change IR 操作目录和各语言动态/ABI/宏/反射边界。
- 增加 6 个 Golden 种子用例、契约负例、故障注入和生产认证套件。
- 增加 7 份生产 Runbook、严格 TypeScript 编排骨架、离线校验器和 CI 质量门。
- 增加能力依据、验证报告、发布清单和机器可读验证产物。

