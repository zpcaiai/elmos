# Artifact 版本与人工内容保护 — Module Specification

## 1. Epic

- **Epic ID**：`EPIC-32`
- **Skill**：`elmos-artifact-versioning-human-lock`
- **批次**：`BATCH-05-diagram-platform`
- **目标**：确保自动更新不会破坏人工维护内容，同时保持与代码 revision 的一致性。

## 2. 用户价值

管理图表、文档、PPT、报告和解释的版本、草稿、审批、人工 override、锁定和三方合并。

## 3. 功能需求

| ID | 需求 |
|---|---|
| `REQ-32-01` | 锁定支持内容、语义、布局和整页/整章范围。 |
| `REQ-32-02` | 人工 override 与自动事实分离。 |
| `REQ-32-03` | Artifact 必须绑定 project revision、analysis run、template/model/generator version。 |
| `REQ-32-04` | 可生成 stale reason 和 regen preview。 |
| `REQ-32-05` | 审批签名不可由生成 worker 伪造。 |

## 4. API 触点

- `/api/v1/artifacts`
- `/api/v1/artifacts/{id}/versions`
- `/locks`
- `/reviews`

所有 API 必须：

- 使用 `/api/v1` 版本前缀或清晰的内部契约版本；
- 携带 `tenant_id`、`project_id`、`revision_id/analysis_run_id` 的服务端上下文；
- 支持幂等键、分页、错误码和权限校验；
- 不在错误消息中泄露代码、凭据或跨租户对象；
- 对长任务返回 `job_id`、状态、检查点和可恢复错误。

## 5. 主要领域实体

- `CacheEntry`
- `Checkpoint`
- `ArtifactLock`
- `GitDelivery`
- `SchedulerLease`

实体必须包含必要的：

- stable ID；
- tenant/project scope；
- revision 或 version；
- created/updated/actor；
- provenance/evidence；
- optimistic lock 或 immutable version。

## 6. 事件与异步工作

建议事件命名：`elmos.project-intelligence.<domain>.<event>.v1`。

- 开始、完成、失败、取消和检查点事件必须可区分；
- 事件携带引用 ID，不携带大段源代码；
- 消费者必须幂等；
- 外部副作用保存 idempotency key；
- poison message 进入隔离队列并生成可操作诊断。

## 7. UI/交互要求

- 页面必须显示 revision、分析覆盖、可信度和数据新鲜度。
- 长任务显示阶段、已完成单位、P50/P90 机器 ETA、重试和恢复入口。
- 用户可从结论跳转证据；无证据时显示 Unknown/Inferred。
- 人工编辑、锁定、审批和自动生成状态视觉区分。
- 权限不足不得通过搜索、缩略图、缓存或深链泄漏信息。

## 8. 非功能要求

- API、图查询、渲染和长任务分别定义 p50/p95/p99。
- 支持水平扩展、背压、配额和 graceful degradation。
- 所有持久化 Schema 与事件有版本和迁移路径。
- 安全默认拒绝、Secrets Broker、审计、传输/静态加密。
- 可通过内容哈希、版本和输入 manifest 重现。

## 9. 关键指标

- 缓存命中率
- 恢复成功率
- 重复副作用数
- 队列等待 p95

## 10. 交付物

- `artifact-schema.json`
- `merge-policy.md`
- `artifact-lifecycle-tests.md`

## 11. 任务清单

| Task | 标题 | 类型 | 优先级 |
|---|---|---|---|
| `ELMOS-PI-32-T01` | 定义 Artifact、Block、Element、Version、Lock、Override 和 Review 模型 | implementation | P1 |
| `ELMOS-PI-32-T02` | 为段落、图节点、PPT 页面和表格分配稳定 ID | implementation | P1 |
| `ELMOS-PI-32-T03` | 保存 base-generated、human-patch 和 next-generated 三方数据 | implementation | P1 |
| `ELMOS-PI-32-T04` | 执行语义合并并分类自动可合并/冲突/失效 | implementation | P1 |
| `ELMOS-PI-32-T05` | 支持 Draft、Reviewed、Approved、Certified 生命周期 | implementation | P1 |
| `ELMOS-PI-32-T06` | 提供回滚、比较、审计和保留策略 | implementation | P1 |
| `ELMOS-PI-32-T07` | 实现权限、安全和不可信输入防护 | security | P1 |
| `ELMOS-PI-32-T08` | 接入日志、指标、Trace、错误分类和审计 | observability | P1 |
| `ELMOS-PI-32-T09` | 建立单元、契约、集成、E2E 与回归测试 | testing | P1 |
| `ELMOS-PI-32-T10` | 更新 API、Schema、文档、追踪矩阵并完成验收 | documentation | P1 |

## 12. 验收标准

| ID | 验收标准 |
|---|---|
| `AC-32-01` | 三方合并核心场景通过。 |
| `AC-32-02` | 锁定内容跨再生成保持。 |
| `AC-32-03` | 每个版本可完整重建或验证。 |
| `AC-32-04` | 审批和状态转换权限正确。 |
| `AC-32-05` | stale artifact 不可误标 Certified。 |

## 13. 依赖

- `elmos-evidence-provenance`

## 14. 失败与恢复

- 将错误分类为 user-fixable、transient、capacity、permission、unsupported、internal。
- 可重试错误使用指数退避和最大次数；不可重试错误保留输入、日志和检查点。
- 恢复前验证 revision、配置、规则、模型、模板和权限是否仍兼容。
- 取消操作释放租约和临时资源，但保留审计与已确认 artifact。
