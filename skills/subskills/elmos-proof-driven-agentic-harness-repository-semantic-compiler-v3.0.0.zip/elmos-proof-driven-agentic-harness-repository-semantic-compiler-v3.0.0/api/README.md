# API Contracts

- `openapi.yaml`: synchronous control plane.
- `asyncapi.yaml`: durable run/proof/reconciliation events.
- `elmos_v3.proto`: internal typed kernel gateway.

Every mutation requires tenant context, exact revisions, idempotency and current authority/fencing. Authentication alone is not authorization.
