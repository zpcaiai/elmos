# K3 — Repository Semantic Compiler Kernel

将多语言、多框架、多数据技术的具体程序编译为可执行、可比较、可证明的 Repository Semantic IR，并显式建模语义间隙。

## Components

- `FrontendRegistry`
- `LosslessSyntaxLayer`
- `CompilerSemanticBridge`
- `RepositoryLinker`
- `TypeAndEffectIR`
- `ControlDataSSA`
- `ProtocolStateMachineIR`
- `DataTransactionIR`
- `FrameworkSemanticModel`
- `SourceMapAndLineage`
- `SemanticGapAnalyzer`
- `ExecutableSemanticsRuntime`

## Hard gates

- `frontend_conformance`
- `critical_type_attribution`
- `semantic_ir_schema_valid`
- `source_map_complete`
- `semantic_gap_obligations_emitted`

Internal components are not routable skills and cannot own competing truth.
