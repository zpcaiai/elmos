# K1 — Goal / Specification Kernel

把自然语言目标、存量规范、约束、预算和验收标准编译为版本化、可执行、可证明的 Goal Contract、Observable Contract、Requirement Graph 与 Revision Set。

## Components

- `GoalAggregate`
- `GoalCommandService`
- `RevisionSetRegistry`
- `RequirementGraphCompiler`
- `ObservableContractCompiler`
- `SpecDeltaCompiler`
- `AssumptionLedger`
- `AcceptanceScenarioCompiler`
- `BudgetAndEtaContract`
- `GoalRiskClassifier`
- `GoalCheckpointProjection`
- `GoalChangeImpactAnalyzer`

## Hard gates

- `goal_schema_valid`
- `revision_set_complete`
- `critical_requirement_conflicts_zero`
- `observable_contract_approved_or_policy_accepted`
- `proof_obligations_initialized`

Internal components are not routable skills and cannot own competing truth.
