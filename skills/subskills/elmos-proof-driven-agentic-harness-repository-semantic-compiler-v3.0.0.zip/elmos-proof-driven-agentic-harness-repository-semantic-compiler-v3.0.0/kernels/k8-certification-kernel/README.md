# K8 — Certification Kernel

由独立于生成与修复 Agent 的 Certifier 对精确 Revision Set、Proof Obligation closure、E0–E5、部署证据和商业 Golden Route 证据签发不可伪造的 Completion Certificate。

## Components

- `IndependentStopGate`
- `ProofStatusPolicy`
- `E0E5GateEvaluator`
- `P05DeploymentGate`
- `EvidenceBundleSealer`
- `CompletionCertificateSigner`
- `CertifiedEnvelopeRegistry`
- `WaiverGovernance`
- `DriftAndRevocationMonitor`
- `CommercialGoldenRouteCertifier`
- `AssuranceReportGenerator`
- `AuditExport`

## Hard gates

- `certifier_independent`
- `revision_binding_exact`
- `critical_obligations_closed`
- `E0_E5_pass`
- `P05_pass_for_prod`
- `evidence_bundle_sealed`
- `side_effects_settled`

Internal components are not routable skills and cannot own competing truth.
