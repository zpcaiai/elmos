# K6 — Proof & Verification Kernel

为每个 Proof Obligation 选择独立、组合式 verifier portfolio，运行静态、动态、差分、属性、形式化和非功能验证，并把反例反馈给修复闭环。

## Components

- `ProofObligationGraph`
- `VerifierPortfolioRouter`
- `StaticVerificationPipeline`
- `DifferentialExecutionEngine`
- `PropertyMetamorphicFuzzEngine`
- `SymbolicAndSMTEngine`
- `ModelCheckingEngine`
- `ProofAssistantBridge`
- `NonFunctionalVerification`
- `CounterexampleMinimizer`
- `CounterexampleToTest`
- `ProofCacheAndDriftInvalidator`

## Hard gates

- `all_required_verifiers_executed_or_explicit_status`
- `authoritative_oracles_independent`
- `critical_refutations_zero`
- `unknown_policy_applied`
- `proof_evidence_immutable`

Internal components are not routable skills and cannot own competing truth.
