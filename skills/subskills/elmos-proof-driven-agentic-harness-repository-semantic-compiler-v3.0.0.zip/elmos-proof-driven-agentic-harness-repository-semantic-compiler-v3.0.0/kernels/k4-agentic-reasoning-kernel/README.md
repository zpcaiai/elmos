# K4 — Agentic Reasoning Kernel

把大模型用于最有价值的认知工作：规范恢复、假设生成、规划、引理/不变量合成、反例解释和最小修复，同时禁止模型成为最终正确性 Oracle。

## Components

- `RoleSeparatedAgentRuntime`
- `PhaseAwareModelRouter`
- `ModelCapabilityRegistry`
- `ContextPlanner`
- `ArtifactMailbox`
- `ProofPlanner`
- `InvariantAndLemmaSynthesizer`
- `CounterexampleReasoner`
- `RepairSynthesizer`
- `AdversarialReviewer`
- `AgentArena`
- `ReasoningProvenanceRecorder`

## Hard gates

- `role_separation`
- `no_llm_authoritative_oracle`
- `model_budget_reserved`
- `context_lineage_valid`
- `review_independence_for_critical_changes`

Internal components are not routable skills and cannot own competing truth.
