# K5 — Transformation Kernel

以 deterministic-first、semantic-rule-driven、bounded-generative 的方式执行仓库级生成、转换、现代化和重构，形成可回滚、可重放、可验证的 ChangeGraph。

## Components

- `TransformationPlanner`
- `RuleRegistry`
- `RulePreservationContract`
- `DeterministicRecipeEngine`
- `BoundedGenerativeTransformer`
- `ChangeGraph`
- `WorktreeCoordinator`
- `SemanticMergeEngine`
- `FixpointController`
- `DataMigrationPlanner`
- `CutoverRollbackPlanner`
- `TransformationCache`

## Hard gates

- `rule_preconditions_met`
- `change_lineage_complete`
- `unresolved_semantic_conflicts_zero`
- `deterministic_fixpoint_or_bounded_exception`
- `candidate_revision_frozen`

Internal components are not routable skills and cannot own competing truth.
