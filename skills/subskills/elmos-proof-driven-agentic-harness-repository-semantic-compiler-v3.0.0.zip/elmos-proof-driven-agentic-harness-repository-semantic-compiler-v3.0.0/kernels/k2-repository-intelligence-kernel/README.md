# K2 — Repository Intelligence Kernel

以只读、增量、证据优先方式重建仓库的结构、依赖、运行行为、数据、协议、安全与业务能力图谱，为推理和变换提供可查询事实层。

## Components

- `RepositorySnapshotter`
- `BuildSystemDetector`
- `SymbolGraphBuilder`
- `TypeGraphBuilder`
- `CallAndDataFlowGraphBuilder`
- `ConfigurationGraphBuilder`
- `DataAndMessageGraphBuilder`
- `RuntimeTraceIngestor`
- `CapabilityLedger`
- `DynamicBoundaryDetector`
- `RepositoryRiskMap`
- `IncrementalInvalidationEngine`

## Hard gates

- `snapshot_integrity`
- `baseline_build_classified`
- `critical_graph_completeness`
- `dynamic_boundaries_declared`
- `evidence_provenance_complete`

Internal components are not routable skills and cannot own competing truth.
