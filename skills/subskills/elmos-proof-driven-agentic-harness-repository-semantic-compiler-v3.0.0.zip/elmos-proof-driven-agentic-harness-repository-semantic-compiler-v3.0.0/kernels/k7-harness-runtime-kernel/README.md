# K7 — Harness Runtime Kernel

提供长任务、多 Agent、多工作区、多模型、多工具的 durable execution substrate，把权限、运行状态、来源、策略和生命周期绑定到具体 Environment/Attachment。

## Components

- `DurableWorkflowRuntime`
- `EnvironmentAuthority`
- `WorkspaceManager`
- `SessionTimeline`
- `ExecutionProvenance`
- `ToolGateway`
- `PolicyDecisionPoint`
- `LeaseAndFencing`
- `CheckpointReplayFork`
- `SideEffectReconciler`
- `HarnessAdapterSPI`
- `SchedulerBackpressureFinOps`

## Hard gates

- `authority_resolved`
- `fencing_current`
- `tenant_isolation`
- `side_effect_state_known_or_blocked`
- `checkpoint_recoverable`
- `budget_not_overdrawn`

Internal components are not routable skills and cannot own competing truth.
