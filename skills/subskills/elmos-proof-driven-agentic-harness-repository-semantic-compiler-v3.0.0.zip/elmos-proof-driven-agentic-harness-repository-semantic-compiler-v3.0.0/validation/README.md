# V3 Evaluation and Trust Data Plane

The v3 package inherits the ETGB v1.1 corpus and runner as an independent validation plane:

- total cases: **46,664**
- Spring modernization: **3,117**
- Cross-language: **29,535**
- Project generation: **1,451**
- SQL conversion: **11,761**
- Cross-cutting/runtime: **800**

ETGB results are evidence inputs to K6/K8. They cannot independently certify a Goal and cannot be used to inflate bounded coverage into proof. The old ETGB skills are non-routable in v3 and are represented by the migration alias map.
