# Policy Kernel Modules

The Rego modules are fail-closed reference policies for:
- Environment-owned authority;
- proof status and model-oracle restrictions;
- tenant isolation;
- external side-effect reconciliation;
- independent completion certification.

Production activation requires `opa test`, signed policy bundles and exact policy revision binding.
