package elmos.v3.environment_authority
import rego.v1

default allow := false

allow if {
  input.tenant_id == input.authority.tenant_id
  input.run_id == input.authority.run_id
  input.execution_epoch == input.authority.execution_epoch
  input.fencing_generation == input.authority.fencing_generation
  time.now_ns() >= time.parse_rfc3339_ns(input.authority.valid_from)
  time.now_ns() < time.parse_rfc3339_ns(input.authority.expires_at)
  capability_allowed
  path_allowed
}

capability_allowed if {
  some cap in input.authority.capabilities
  cap.name == input.requested_capability
}

path_allowed if {
  not input.path
}

path_allowed if {
  some prefix in input.authority.sandbox.read_paths
  startswith(input.path, prefix)
  input.operation == "read"
}

path_allowed if {
  some prefix in input.authority.sandbox.write_paths
  startswith(input.path, prefix)
  input.operation == "write"
}

deny contains "tenant mismatch" if input.tenant_id != input.authority.tenant_id
deny contains "execution epoch mismatch" if input.execution_epoch != input.authority.execution_epoch
deny contains "stale fencing generation" if input.fencing_generation != input.authority.fencing_generation
deny contains "capability not granted" if not capability_allowed
deny contains "path not granted" if not path_allowed
