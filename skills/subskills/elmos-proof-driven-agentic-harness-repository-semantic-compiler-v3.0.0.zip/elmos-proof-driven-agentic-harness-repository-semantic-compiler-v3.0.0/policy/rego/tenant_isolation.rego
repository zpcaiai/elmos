package elmos.v3.tenant_isolation
import rego.v1

default allow := false

allow if {
  input.subject_tenant_id == input.resource_tenant_id
  input.cache_partition == input.subject_tenant_id
  input.artifact_tenant_id == input.subject_tenant_id
}

deny contains "cross-tenant resource access" if input.subject_tenant_id != input.resource_tenant_id
deny contains "cross-tenant cache partition" if input.cache_partition != input.subject_tenant_id
deny contains "cross-tenant artifact" if input.artifact_tenant_id != input.subject_tenant_id
