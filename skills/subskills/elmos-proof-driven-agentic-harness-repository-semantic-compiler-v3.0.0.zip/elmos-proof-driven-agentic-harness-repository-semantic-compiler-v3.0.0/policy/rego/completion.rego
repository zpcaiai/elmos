package elmos.v3.completion
import rego.v1

required_gates := {"E0", "E1", "E2", "E3", "E4"}

default complete := false

complete if {
  input.certifier.independent == true
  input.exact_revision_binding == true
  input.critical_total == input.critical_closed
  input.unresolved_critical == 0
  input.evidence_sealed == true
  input.evidence_fresh == true
  input.evidence_revoked == false
  input.side_effects_unsettled == 0
  every g in required_gates {
    input.gates[g] == "PASS"
  }
  production_gate_ok
}

production_gate_ok if input.environment != "production"
production_gate_ok if {
  input.environment == "production"
  input.gates["P05"] == "PASS"
}

deny contains "agent self-certification" if input.certifier.execution_source in {"ROOT_AGENT", "SUBAGENT", "TRANSFORMER", "REPAIRER"}
deny contains "critical obligations remain" if input.critical_total != input.critical_closed
deny contains "evidence not trustworthy" if {
  not input.evidence_sealed
}
deny contains "unsettled external side effects" if input.side_effects_unsettled > 0
