package elmos.v3.side_effect
import rego.v1

default execute := false

execute if {
  input.policy_decision == "ALLOW"
  input.authority_valid
  input.idempotency_key != ""
  input.reconciliation_strategy != ""
  input.previous_state in {"NOT_STARTED", "FAILED_RETRYABLE"}
}

deny contains "unknown previous result requires reconciliation" if input.previous_state == "UNKNOWN_RESULT"
deny contains "missing idempotency key" if input.idempotency_key == ""
deny contains "missing reconciliation strategy" if input.reconciliation_strategy == ""
deny contains "approval required" if input.policy_decision == "REVIEW"
