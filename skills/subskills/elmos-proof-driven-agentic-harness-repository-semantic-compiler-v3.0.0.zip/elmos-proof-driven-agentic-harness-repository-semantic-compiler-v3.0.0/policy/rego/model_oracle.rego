package elmos.v3.model_oracle
import rego.v1

default authoritative := false

authoritative if {
  input.source_type != "llm"
  input.independent == true
  input.reproducible == true
  input.evidence_hash != ""
}

deny contains "model judgment cannot be authoritative" if input.source_type == "llm"
deny contains "self-review cannot be authoritative" if input.producer_execution_id == input.subject_execution_id
deny contains "missing evidence hash" if input.evidence_hash == ""
