package elmos.v3.proof_status
import rego.v1

proof_statuses := {
  "PROVED_CERTIFIED",
  "PROVED_INDUCTIVE",
  "PROVED_SOLVER_TRUSTED",
  "PROVED_FOR_SUPPORTED_FRAGMENT",
}

nonproof_statuses := {
  "BOUNDED_NO_COUNTEREXAMPLE",
  "REFUTED_WITH_COUNTEREXAMPLE",
  "UNKNOWN_TIMEOUT",
  "UNKNOWN_RESOURCE_LIMIT",
  "UNSUPPORTED",
  "ASSUMPTION_REQUIRED",
  "RUNTIME_MONITORED",
  "WAIVED_BY_APPROVER",
}

default accepted := false

accepted if {
  input.status in proof_statuses
  input.evidence_count > 0
  input.tool_digest != ""
  input.subject_revision != ""
}

accepted if {
  input.severity != "critical"
  input.policy_allows_bounded
  input.status == "BOUNDED_NO_COUNTEREXAMPLE"
  input.evidence_count > 0
}

deny contains "llm-only oracle" if input.authoritative_oracle == "llm"
deny contains "critical obligation is not proved" if {
  input.severity == "critical"
  not input.status in proof_statuses
}
deny contains "refuted obligation" if input.status == "REFUTED_WITH_COUNTEREXAMPLE"
