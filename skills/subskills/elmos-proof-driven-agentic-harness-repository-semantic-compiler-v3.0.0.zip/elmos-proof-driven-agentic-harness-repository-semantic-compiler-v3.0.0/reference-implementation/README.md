# Executable Reference Kernel

This dependency-light Python package demonstrates:
- canonical proof status semantics;
- Proof Obligation Graph validation and readiness;
- non-inflating proof-result application;
- Environment-owned authority and fencing;
- durable workflow transitions;
- semantic-gap generation;
- append-only evidence and deterministic evidence root;
- independent certification.

It is a reference kernel, not a substitute for production databases, compiler frontends, sandboxes or external verification tools.
