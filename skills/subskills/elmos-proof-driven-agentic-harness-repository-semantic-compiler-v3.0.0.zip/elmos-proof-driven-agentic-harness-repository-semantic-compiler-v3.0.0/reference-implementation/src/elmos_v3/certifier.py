from __future__ import annotations

import uuid
from datetime import datetime
from typing import Iterable

from .evidence import EvidenceStore
from .models import CompletionCertificate, GateDecision, GateResult, RevisionSet
from .proof_graph import ProofObligationGraph


class CertificationError(ValueError):
    pass


class IndependentCertifier:
    def __init__(self, identity: str, *, execution_source: str = "CERTIFIER", independent: bool = True) -> None:
        self.identity = identity
        self.execution_source = execution_source
        self.independent = independent

    def certify(
        self,
        *,
        tenant_id: str,
        goal_id: str,
        revision_set: RevisionSet,
        graph: ProofObligationGraph,
        gates: Iterable[GateResult],
        evidence_store: EvidenceStore,
        evidence_ids: Iterable[str],
        now: datetime,
        production: bool,
        certified_envelope: dict,
        unsettled_side_effects: int = 0,
    ) -> CompletionCertificate:
        if not self.independent or self.execution_source != "CERTIFIER":
            raise CertificationError("certifier must be independent")
        if not revision_set.is_complete():
            raise CertificationError("revision set is incomplete")
        if graph.refutations():
            raise CertificationError("refuted proof obligations exist")
        if not graph.all_critical_closed():
            raise CertificationError("critical proof obligations remain unclosed")
        if unsettled_side_effects:
            raise CertificationError("external side effects remain unsettled")

        gate_map = {item.gate: item for item in gates}
        required = {"E0", "E1", "E2", "E3", "E4"}
        if production:
            required.add("P05")
        missing_or_failed = sorted(
            gate for gate in required
            if gate not in gate_map or gate_map[gate].decision is not GateDecision.PASS
        )
        if missing_or_failed:
            raise CertificationError(f"required gates not passed: {missing_or_failed}")

        records = evidence_store.fresh_records(evidence_ids, now)
        root = evidence_store.merkle_like_root(records)
        return CompletionCertificate(
            certificate_id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            goal_id=goal_id,
            revision_set_id=revision_set.revision_set_id,
            certified_envelope=certified_envelope,
            gate_results=tuple(gate_map.values()),
            status_counts=graph.status_counts(),
            evidence_root=root,
            signer_identity=self.identity,
            signer_independent=True,
            issued_at=now,
            status="CERTIFIED" if "E5" in gate_map and gate_map["E5"].decision is GateDecision.PASS else "VERIFIED_COMPLETE",
        )
