from __future__ import annotations

import hashlib
import json
from dataclasses import asdict
from datetime import datetime
from typing import Iterable

from .models import EvidenceRecord


class EvidenceError(ValueError):
    pass


class EvidenceStore:
    """Append-only evidence reference store used by the reference kernel."""

    def __init__(self) -> None:
        self._records: dict[str, EvidenceRecord] = {}

    def append(self, record: EvidenceRecord) -> None:
        if record.evidence_id in self._records:
            raise EvidenceError("evidence id already exists")
        self._records[record.evidence_id] = record

    def get(self, evidence_id: str) -> EvidenceRecord:
        try:
            return self._records[evidence_id]
        except KeyError as exc:
            raise EvidenceError(f"unknown evidence: {evidence_id}") from exc

    def fresh_records(self, evidence_ids: Iterable[str], now: datetime) -> tuple[EvidenceRecord, ...]:
        records = tuple(self.get(item) for item in evidence_ids)
        if not all(record.is_fresh(now) for record in records):
            raise EvidenceError("evidence is expired or revoked")
        return records

    @staticmethod
    def merkle_like_root(records: Iterable[EvidenceRecord]) -> str:
        leaves = []
        for record in sorted(records, key=lambda item: item.evidence_id):
            payload = json.dumps(asdict(record), sort_keys=True, default=str, separators=(",", ":")).encode()
            leaves.append(hashlib.sha256(payload).digest())
        if not leaves:
            raise EvidenceError("cannot seal empty evidence bundle")
        while len(leaves) > 1:
            if len(leaves) % 2:
                leaves.append(leaves[-1])
            leaves = [
                hashlib.sha256(leaves[i] + leaves[i + 1]).digest()
                for i in range(0, len(leaves), 2)
            ]
        return "sha256:" + leaves[0].hex()
