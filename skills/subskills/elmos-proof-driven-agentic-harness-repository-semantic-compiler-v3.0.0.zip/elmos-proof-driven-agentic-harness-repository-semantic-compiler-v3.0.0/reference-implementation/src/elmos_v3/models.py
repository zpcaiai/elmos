from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any


class ProofStatus(StrEnum):
    PENDING = "PENDING"
    READY = "READY"
    RUNNING = "RUNNING"
    BLOCKED = "BLOCKED"
    PROVED_CERTIFIED = "PROVED_CERTIFIED"
    PROVED_INDUCTIVE = "PROVED_INDUCTIVE"
    PROVED_SOLVER_TRUSTED = "PROVED_SOLVER_TRUSTED"
    PROVED_FOR_SUPPORTED_FRAGMENT = "PROVED_FOR_SUPPORTED_FRAGMENT"
    BOUNDED_NO_COUNTEREXAMPLE = "BOUNDED_NO_COUNTEREXAMPLE"
    REFUTED_WITH_COUNTEREXAMPLE = "REFUTED_WITH_COUNTEREXAMPLE"
    UNKNOWN_TIMEOUT = "UNKNOWN_TIMEOUT"
    UNKNOWN_RESOURCE_LIMIT = "UNKNOWN_RESOURCE_LIMIT"
    UNSUPPORTED = "UNSUPPORTED"
    ASSUMPTION_REQUIRED = "ASSUMPTION_REQUIRED"
    RUNTIME_MONITORED = "RUNTIME_MONITORED"
    WAIVED_BY_APPROVER = "WAIVED_BY_APPROVER"


class Severity(StrEnum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class GateDecision(StrEnum):
    PASS = "PASS"
    FAIL = "FAIL"
    BLOCKED = "BLOCKED"
    NOT_APPLICABLE = "NOT_APPLICABLE"


ACCEPTED_PROOF_STATUSES = frozenset({
    ProofStatus.PROVED_CERTIFIED,
    ProofStatus.PROVED_INDUCTIVE,
    ProofStatus.PROVED_SOLVER_TRUSTED,
    ProofStatus.PROVED_FOR_SUPPORTED_FRAGMENT,
})


@dataclass(frozen=True, slots=True)
class ArtifactRef:
    artifact_id: str
    sha256: str
    media_type: str
    uri: str | None = None


@dataclass(slots=True)
class ProofObligation:
    obligation_id: str
    family: str
    severity: Severity
    relation: str
    scope: str
    required_minimum_status: ProofStatus
    accepted_evidence_classes: frozenset[str]
    assumptions: tuple[str, ...] = ()
    open_world: bool = False
    status: ProofStatus = ProofStatus.PENDING
    affected_symbols: tuple[str, ...] = ()

    def is_accepted(self, result: "ProofResult", *, allow_bounded_noncritical: bool = False) -> bool:
        if result.obligation_id != self.obligation_id:
            return False
        if not result.evidence:
            return False
        if result.status in ACCEPTED_PROOF_STATUSES:
            return bool(self.accepted_evidence_classes.intersection(result.evidence_classes))
        if (
            allow_bounded_noncritical
            and self.severity is not Severity.CRITICAL
            and result.status is ProofStatus.BOUNDED_NO_COUNTEREXAMPLE
        ):
            return bool(self.accepted_evidence_classes.intersection(result.evidence_classes))
        return False


@dataclass(frozen=True, slots=True)
class ProofResult:
    result_id: str
    obligation_id: str
    status: ProofStatus
    subject_revision: str
    tool_name: str
    tool_digest: str
    encoder_digest: str
    environment_revision: str
    evidence: tuple[ArtifactRef, ...]
    evidence_classes: frozenset[str]
    assumptions: tuple[str, ...] = ()
    scope: str = ""
    resource_bounds: dict[str, int | float | str] = field(default_factory=dict)
    counterexample: ArtifactRef | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))


@dataclass(frozen=True, slots=True)
class RevisionSet:
    revision_set_id: str
    source_repository: str
    baseline_repository: str
    requirements: str
    policy: str
    workflow: str
    model_route: str
    toolchain: str
    environment: str
    domain_pack: str

    def values(self) -> tuple[str, ...]:
        return (
            self.source_repository, self.baseline_repository, self.requirements,
            self.policy, self.workflow, self.model_route, self.toolchain,
            self.environment, self.domain_pack,
        )

    def is_complete(self) -> bool:
        return all(value.startswith("sha256:") and len(value) == 71 for value in self.values())


@dataclass(frozen=True, slots=True)
class GateResult:
    gate: str
    decision: GateDecision
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class EvidenceRecord:
    evidence_id: str
    tenant_id: str
    subject_revision: str
    kind: str
    content_sha256: str
    producer_execution_id: str
    producer_source: str
    tool_digest: str
    created_at: datetime
    expires_at: datetime | None = None
    revoked: bool = False
    lineage: tuple[str, ...] = ()

    def is_fresh(self, now: datetime) -> bool:
        return not self.revoked and (self.expires_at is None or now < self.expires_at)


@dataclass(frozen=True, slots=True)
class CompletionCertificate:
    certificate_id: str
    tenant_id: str
    goal_id: str
    revision_set_id: str
    certified_envelope: dict[str, Any]
    gate_results: tuple[GateResult, ...]
    status_counts: dict[str, int]
    evidence_root: str
    signer_identity: str
    signer_independent: bool
    issued_at: datetime
    status: str
