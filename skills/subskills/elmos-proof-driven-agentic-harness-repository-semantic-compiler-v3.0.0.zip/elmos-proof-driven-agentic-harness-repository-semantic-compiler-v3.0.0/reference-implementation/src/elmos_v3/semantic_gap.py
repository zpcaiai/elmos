from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SemanticGap:
    family: str
    source_value: str
    target_value: str
    severity: str
    resolution_required: bool = True


_CANONICAL = {
    "nullability": "null/undefined/option semantics",
    "numeric": "integer/float/decimal semantics",
    "exceptions": "exception/error/panic/result semantics",
    "concurrency": "concurrency/async/cancellation/memory model",
    "resources": "resource lifetime/GC/RAII/finalization",
    "dynamic": "reflection/dynamic/FFI/open-world boundary",
}


def compare_profiles(source: dict[str, str], target: dict[str, str]) -> tuple[SemanticGap, ...]:
    gaps = []
    for key, family in _CANONICAL.items():
        source_value = source.get(key, "UNDECLARED")
        target_value = target.get(key, "UNDECLARED")
        if source_value != target_value:
            severity = "critical" if key in {"nullability", "numeric", "exceptions", "concurrency"} else "high"
            gaps.append(SemanticGap(family, source_value, target_value, severity))
    return tuple(gaps)
