from __future__ import annotations

import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


class Handler(BaseHTTPRequestHandler):
    server_version = "ElmosV3Reference/3.0.0"

    def _write(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/livez":
            self._write(200, b'{"status":"live"}\n', "application/json")
            return
        if self.path == "/readyz":
            self._write(200, b'{"status":"ready","mode":"reference-kernel"}\n', "application/json")
            return
        if self.path == "/metrics":
            body = (
                "# HELP elmos_v3_reference_info Reference service build information.\n"
                "# TYPE elmos_v3_reference_info gauge\n"
                'elmos_v3_reference_info{version="3.0.0"} 1\n'
            ).encode()
            self._write(200, body, "text/plain; version=0.0.4")
            return
        if self.path == "/version":
            payload = {
                "name": "elmos-proof-driven-agentic-harness-repository-semantic-compiler",
                "version": "3.0.0",
                "mode": "reference-kernel",
                "release_manifest": os.getenv("ELMOS_RELEASE_MANIFEST_SHA256", "UNPINNED_REFERENCE"),
            }
            self._write(200, (json.dumps(payload) + "\n").encode(), "application/json")
            return
        self._write(404, b'{"error":"not_found"}\n', "application/json")

    def log_message(self, fmt: str, *args: object) -> None:
        print(json.dumps({"component": "reference-service", "message": fmt % args}))


def main() -> int:
    host = os.getenv("ELMOS_HOST", "0.0.0.0")
    port = int(os.getenv("ELMOS_PORT", "8080"))
    server = ThreadingHTTPServer((host, port), Handler)
    print(json.dumps({"event": "started", "host": host, "port": port}))
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
