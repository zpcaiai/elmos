from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import replace
from typing import Iterable

from .models import ProofObligation, ProofResult, ProofStatus, Severity


class ProofGraphError(ValueError):
    pass


class ProofObligationGraph:
    """In-memory reference graph. Production state belongs in PostgreSQL."""

    def __init__(self, obligations: Iterable[ProofObligation], dependencies: Iterable[tuple[str, str]] = ()) -> None:
        self._obligations = {item.obligation_id: item for item in obligations}
        if len(self._obligations) == 0:
            raise ProofGraphError("at least one proof obligation is required")
        self._dependencies: dict[str, set[str]] = defaultdict(set)
        self._dependents: dict[str, set[str]] = defaultdict(set)
        for obligation_id, dependency_id in dependencies:
            if obligation_id not in self._obligations or dependency_id not in self._obligations:
                raise ProofGraphError(f"unknown dependency edge: {obligation_id} -> {dependency_id}")
            if obligation_id == dependency_id:
                raise ProofGraphError("self dependency is not allowed")
            self._dependencies[obligation_id].add(dependency_id)
            self._dependents[dependency_id].add(obligation_id)
        self._assert_acyclic()

    @property
    def obligations(self) -> tuple[ProofObligation, ...]:
        return tuple(self._obligations.values())

    def _assert_acyclic(self) -> None:
        indegree = {key: len(self._dependencies[key]) for key in self._obligations}
        queue = deque(key for key, degree in indegree.items() if degree == 0)
        visited = 0
        while queue:
            node = queue.popleft()
            visited += 1
            for dependent in self._dependents[node]:
                indegree[dependent] -= 1
                if indegree[dependent] == 0:
                    queue.append(dependent)
        if visited != len(self._obligations):
            raise ProofGraphError("proof obligation graph contains a dependency cycle")

    def ready(self) -> tuple[ProofObligation, ...]:
        accepted = {
            key for key, item in self._obligations.items()
            if item.status in {
                ProofStatus.PROVED_CERTIFIED,
                ProofStatus.PROVED_INDUCTIVE,
                ProofStatus.PROVED_SOLVER_TRUSTED,
                ProofStatus.PROVED_FOR_SUPPORTED_FRAGMENT,
            }
        }
        result = []
        for key, item in self._obligations.items():
            if item.status in {ProofStatus.PENDING, ProofStatus.BLOCKED} and self._dependencies[key].issubset(accepted):
                result.append(item)
        return tuple(result)

    def apply_result(self, result: ProofResult, *, allow_bounded_noncritical: bool = False) -> ProofObligation:
        current = self._obligations.get(result.obligation_id)
        if current is None:
            raise ProofGraphError(f"unknown obligation: {result.obligation_id}")
        if not current.is_accepted(result, allow_bounded_noncritical=allow_bounded_noncritical):
            # Preserve the verifier's exact non-accepted status. Never inflate it.
            new_status = result.status
        else:
            new_status = result.status
        updated = replace(current, status=new_status)
        self._obligations[current.obligation_id] = updated
        return updated

    def critical_unclosed(self) -> tuple[ProofObligation, ...]:
        accepted = {
            ProofStatus.PROVED_CERTIFIED,
            ProofStatus.PROVED_INDUCTIVE,
            ProofStatus.PROVED_SOLVER_TRUSTED,
            ProofStatus.PROVED_FOR_SUPPORTED_FRAGMENT,
        }
        return tuple(
            item for item in self._obligations.values()
            if item.severity is Severity.CRITICAL and item.status not in accepted
        )

    def refutations(self) -> tuple[ProofObligation, ...]:
        return tuple(item for item in self._obligations.values() if item.status is ProofStatus.REFUTED_WITH_COUNTEREXAMPLE)

    def status_counts(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for item in self._obligations.values():
            counts[item.status.value] = counts.get(item.status.value, 0) + 1
        return counts

    def all_critical_closed(self) -> bool:
        return not self.critical_unclosed()
