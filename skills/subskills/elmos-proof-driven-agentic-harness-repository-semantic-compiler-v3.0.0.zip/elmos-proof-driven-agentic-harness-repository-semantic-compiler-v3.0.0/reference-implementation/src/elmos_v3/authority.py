from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import PurePosixPath


class AuthorityError(PermissionError):
    pass


@dataclass(frozen=True, slots=True)
class Capability:
    name: str
    path_prefixes: tuple[str, ...] = ()
    parameters: dict[str, tuple[str, ...]] | None = None


@dataclass(frozen=True, slots=True)
class ToolRequest:
    tenant_id: str
    run_id: str
    execution_epoch: int
    fencing_generation: int
    capability: str
    operation: str
    path: str | None = None


@dataclass(frozen=True, slots=True)
class EnvironmentAuthority:
    authority_id: str
    tenant_id: str
    run_id: str
    execution_epoch: int
    revision: str
    environment_id: str
    execution_source: str
    capabilities: tuple[Capability, ...]
    read_paths: tuple[str, ...]
    write_paths: tuple[str, ...]
    network_mode: str
    valid_from: datetime
    expires_at: datetime
    fencing_generation: int
    revoked: bool = False

    def authorize(self, request: ToolRequest, *, now: datetime) -> None:
        if self.revoked:
            raise AuthorityError("authority is revoked")
        if request.tenant_id != self.tenant_id:
            raise AuthorityError("tenant mismatch")
        if request.run_id != self.run_id:
            raise AuthorityError("run mismatch")
        if request.execution_epoch != self.execution_epoch:
            raise AuthorityError("execution epoch mismatch")
        if request.fencing_generation != self.fencing_generation:
            raise AuthorityError("stale fencing generation")
        if not (self.valid_from <= now < self.expires_at):
            raise AuthorityError("authority not currently valid")
        capability = next((item for item in self.capabilities if item.name == request.capability), None)
        if capability is None:
            raise AuthorityError("capability not granted")
        if request.path is not None:
            normalized = self._normalize(request.path)
            allowed = self.read_paths if request.operation == "read" else self.write_paths
            if not any(self._is_within(normalized, prefix) for prefix in allowed):
                raise AuthorityError("path not granted")
            if capability.path_prefixes and not any(self._is_within(normalized, prefix) for prefix in capability.path_prefixes):
                raise AuthorityError("capability path constraint failed")

    @staticmethod
    def _normalize(path: str) -> str:
        pure = PurePosixPath(path)
        if ".." in pure.parts:
            raise AuthorityError("path traversal")
        normalized = str(pure)
        if not normalized.startswith("/"):
            raise AuthorityError("absolute path required")
        return normalized.rstrip("/") or "/"

    @staticmethod
    def _is_within(path: str, prefix: str) -> bool:
        normalized_prefix = str(PurePosixPath(prefix)).rstrip("/") or "/"
        return path == normalized_prefix or path.startswith(normalized_prefix + "/")
