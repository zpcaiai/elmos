from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class WorkflowError(ValueError):
    pass


class RunState(StrEnum):
    CREATED = "CREATED"
    ADMITTED = "ADMITTED"
    PLANNING = "PLANNING"
    EXECUTING = "EXECUTING"
    CHECKPOINTED = "CHECKPOINTED"
    PAUSED = "PAUSED"
    RESUMING = "RESUMING"
    VERIFYING = "VERIFYING"
    CERTIFYING = "CERTIFYING"
    COMPLETED = "COMPLETED"
    BLOCKED = "BLOCKED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    PARTIAL = "PARTIAL"


_ALLOWED: dict[RunState, frozenset[RunState]] = {
    RunState.CREATED: frozenset({RunState.ADMITTED, RunState.CANCELLED}),
    RunState.ADMITTED: frozenset({RunState.PLANNING, RunState.BLOCKED, RunState.CANCELLED}),
    RunState.PLANNING: frozenset({RunState.EXECUTING, RunState.BLOCKED, RunState.CANCELLED}),
    RunState.EXECUTING: frozenset({RunState.CHECKPOINTED, RunState.PAUSED, RunState.VERIFYING, RunState.BLOCKED, RunState.FAILED, RunState.CANCELLED}),
    RunState.CHECKPOINTED: frozenset({RunState.EXECUTING, RunState.PAUSED, RunState.RESUMING, RunState.CANCELLED}),
    RunState.PAUSED: frozenset({RunState.RESUMING, RunState.CANCELLED}),
    RunState.RESUMING: frozenset({RunState.EXECUTING, RunState.VERIFYING, RunState.BLOCKED}),
    RunState.VERIFYING: frozenset({RunState.EXECUTING, RunState.CERTIFYING, RunState.BLOCKED, RunState.FAILED, RunState.PARTIAL}),
    RunState.CERTIFYING: frozenset({RunState.COMPLETED, RunState.BLOCKED, RunState.FAILED, RunState.PARTIAL}),
    RunState.COMPLETED: frozenset(),
    RunState.BLOCKED: frozenset({RunState.RESUMING, RunState.CANCELLED}),
    RunState.FAILED: frozenset(),
    RunState.CANCELLED: frozenset(),
    RunState.PARTIAL: frozenset(),
}


@dataclass(slots=True)
class RunAggregate:
    run_id: str
    revision_set_id: str
    execution_epoch: int
    fencing_generation: int
    state: RunState = RunState.CREATED
    last_event_sequence: int = 0

    def transition(self, target: RunState, *, expected_sequence: int, fencing_generation: int) -> int:
        if expected_sequence != self.last_event_sequence:
            raise WorkflowError("optimistic sequence conflict")
        if fencing_generation != self.fencing_generation:
            raise WorkflowError("stale fencing generation")
        if target not in _ALLOWED[self.state]:
            raise WorkflowError(f"invalid transition: {self.state} -> {target}")
        self.state = target
        self.last_event_sequence += 1
        return self.last_event_sequence

    def recover(self, *, new_execution_epoch: int, new_fencing_generation: int) -> None:
        if new_execution_epoch <= self.execution_epoch:
            raise WorkflowError("execution epoch must increase")
        if new_fencing_generation <= self.fencing_generation:
            raise WorkflowError("fencing generation must increase")
        self.execution_epoch = new_execution_epoch
        self.fencing_generation = new_fencing_generation
        if self.state in {RunState.PAUSED, RunState.CHECKPOINTED, RunState.BLOCKED}:
            self.state = RunState.RESUMING
        elif self.state in {RunState.COMPLETED, RunState.FAILED, RunState.CANCELLED, RunState.PARTIAL}:
            raise WorkflowError("terminal run cannot be recovered in-place")
