from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from datetime import UTC, datetime, timedelta

from .certifier import IndependentCertifier
from .evidence import EvidenceStore
from .models import (
    ArtifactRef, EvidenceRecord, GateDecision, GateResult, ProofObligation,
    ProofResult, ProofStatus, RevisionSet, Severity,
)
from .proof_graph import ProofObligationGraph


def demo() -> dict:
    obligation = ProofObligation(
        obligation_id="PO-DEMO-001",
        family="observable behavior",
        severity=Severity.CRITICAL,
        relation="refinement",
        scope="demo",
        required_minimum_status=ProofStatus.PROVED_SOLVER_TRUSTED,
        accepted_evidence_classes=frozenset({"solver"}),
    )
    graph = ProofObligationGraph([obligation])
    artifact = ArtifactRef("artifact-proof", "sha256:" + "1" * 64, "application/json")
    graph.apply_result(ProofResult(
        result_id="result-demo",
        obligation_id=obligation.obligation_id,
        status=ProofStatus.PROVED_SOLVER_TRUSTED,
        subject_revision="sha256:" + "2" * 64,
        tool_name="demo-solver",
        tool_digest="sha256:" + "3" * 64,
        encoder_digest="sha256:" + "4" * 64,
        environment_revision="sha256:" + "5" * 64,
        evidence=(artifact,),
        evidence_classes=frozenset({"solver"}),
    ))
    now = datetime.now(UTC)
    store = EvidenceStore()
    store.append(EvidenceRecord(
        evidence_id="evidence-demo", tenant_id="tenant-demo",
        subject_revision="sha256:" + "2" * 64, kind="solver",
        content_sha256=artifact.sha256, producer_execution_id="exec-verifier",
        producer_source="VERIFIER", tool_digest="sha256:" + "3" * 64,
        created_at=now, expires_at=now + timedelta(days=30),
    ))
    revision = RevisionSet(
        "revision-set-demo", *(["sha256:" + "a" * 64] * 9)
    )
    gates = [GateResult(gate, GateDecision.PASS, ("evidence-demo",)) for gate in ["P05","E0","E1","E2","E3","E4"]]
    certificate = IndependentCertifier("elmos-independent-certifier").certify(
        tenant_id="tenant-demo", goal_id="goal-demo", revision_set=revision,
        graph=graph, gates=gates, evidence_store=store, evidence_ids=["evidence-demo"],
        now=now, production=True, certified_envelope={"name":"demo","version":"1","scope":["demo"],"assumptions":[]},
    )
    return asdict(certificate)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["demo"])
    args = parser.parse_args()
    if args.command == "demo":
        print(json.dumps(demo(), default=str, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
