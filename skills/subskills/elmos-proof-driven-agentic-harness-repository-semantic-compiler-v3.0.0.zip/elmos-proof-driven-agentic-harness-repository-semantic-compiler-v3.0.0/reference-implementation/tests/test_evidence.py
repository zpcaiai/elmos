import unittest
from datetime import UTC, datetime
from elmos_v3.evidence import EvidenceError, EvidenceStore
from elmos_v3.models import EvidenceRecord


class EvidenceTests(unittest.TestCase):
    def test_append_only_identity(self):
        store=EvidenceStore()
        record=EvidenceRecord("e","t","sha256:"+"0"*64,"test","sha256:"+"1"*64,"x","VERIFIER","sha256:"+"2"*64,datetime.now(UTC))
        store.append(record)
        with self.assertRaises(EvidenceError):
            store.append(record)

    def test_deterministic_root(self):
        now=datetime.now(UTC)
        a=EvidenceRecord("a","t","sha256:"+"0"*64,"test","sha256:"+"1"*64,"x","VERIFIER","sha256:"+"2"*64,now)
        b=EvidenceRecord("b","t","sha256:"+"0"*64,"test","sha256:"+"3"*64,"x","VERIFIER","sha256:"+"2"*64,now)
        self.assertEqual(EvidenceStore.merkle_like_root([a,b]),EvidenceStore.merkle_like_root([b,a]))


if __name__ == "__main__":
    unittest.main()
