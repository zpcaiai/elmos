import unittest
from datetime import UTC, datetime, timedelta

from elmos_v3.certifier import CertificationError, IndependentCertifier
from elmos_v3.evidence import EvidenceStore
from elmos_v3.models import (
    ArtifactRef, EvidenceRecord, GateDecision, GateResult, ProofObligation,
    ProofResult, ProofStatus, RevisionSet, Severity,
)
from elmos_v3.proof_graph import ProofObligationGraph


def revision():
    return RevisionSet("revset",*(["sha256:"+"a"*64]*9))


def accepted_graph():
    po=ProofObligation("PO-1","demo",Severity.CRITICAL,"refinement","demo",
                       ProofStatus.PROVED_SOLVER_TRUSTED,frozenset({"solver"}))
    graph=ProofObligationGraph([po])
    graph.apply_result(ProofResult(
        "result","PO-1",ProofStatus.PROVED_SOLVER_TRUSTED,"sha256:"+"b"*64,
        "solver","sha256:"+"c"*64,"sha256:"+"d"*64,"sha256:"+"e"*64,
        (ArtifactRef("artifact","sha256:"+"f"*64,"application/json"),),
        frozenset({"solver"}),
    ))
    return graph


def store(expired=False):
    now=datetime.now(UTC)
    s=EvidenceStore()
    s.append(EvidenceRecord(
        "e","tenant","sha256:"+"b"*64,"solver","sha256:"+"f"*64,
        "exec","VERIFIER","sha256:"+"c"*64,now-timedelta(minutes=1),
        expires_at=now-timedelta(seconds=1) if expired else now+timedelta(days=1),
    ))
    return s


class CertifierTests(unittest.TestCase):
    def test_certifies_only_with_independent_gates_and_evidence(self):
        now=datetime.now(UTC)
        cert=IndependentCertifier("certifier").certify(
            tenant_id="tenant",goal_id="goal",revision_set=revision(),graph=accepted_graph(),
            gates=[GateResult(x,GateDecision.PASS,("e",)) for x in ["P05","E0","E1","E2","E3","E4"]],
            evidence_store=store(),evidence_ids=["e"],now=now,production=True,
            certified_envelope={"name":"demo","version":"1","scope":["demo"],"assumptions":[]},
        )
        self.assertEqual(cert.status,"VERIFIED_COMPLETE")
        self.assertTrue(cert.signer_independent)

    def test_self_certifier_rejected(self):
        with self.assertRaises(CertificationError):
            IndependentCertifier("agent",execution_source="ROOT_AGENT",independent=False).certify(
                tenant_id="tenant",goal_id="goal",revision_set=revision(),graph=accepted_graph(),
                gates=[],evidence_store=store(),evidence_ids=["e"],now=datetime.now(UTC),
                production=False,certified_envelope={}
            )

    def test_missing_p05_rejected_in_production(self):
        with self.assertRaises(CertificationError):
            IndependentCertifier("certifier").certify(
                tenant_id="tenant",goal_id="goal",revision_set=revision(),graph=accepted_graph(),
                gates=[GateResult(x,GateDecision.PASS) for x in ["E0","E1","E2","E3","E4"]],
                evidence_store=store(),evidence_ids=["e"],now=datetime.now(UTC),production=True,
                certified_envelope={}
            )

    def test_expired_evidence_rejected(self):
        with self.assertRaises(Exception):
            IndependentCertifier("certifier").certify(
                tenant_id="tenant",goal_id="goal",revision_set=revision(),graph=accepted_graph(),
                gates=[GateResult(x,GateDecision.PASS) for x in ["E0","E1","E2","E3","E4"]],
                evidence_store=store(expired=True),evidence_ids=["e"],now=datetime.now(UTC),production=False,
                certified_envelope={}
            )

    def test_unsettled_side_effect_rejected(self):
        with self.assertRaises(CertificationError):
            IndependentCertifier("certifier").certify(
                tenant_id="tenant",goal_id="goal",revision_set=revision(),graph=accepted_graph(),
                gates=[GateResult(x,GateDecision.PASS) for x in ["E0","E1","E2","E3","E4"]],
                evidence_store=store(),evidence_ids=["e"],now=datetime.now(UTC),production=False,
                certified_envelope={},unsettled_side_effects=1
            )


if __name__ == "__main__":
    unittest.main()
