import unittest
from datetime import UTC, datetime, timedelta
from elmos_v3.authority import AuthorityError, Capability, EnvironmentAuthority, ToolRequest


def authority():
    now=datetime.now(UTC)
    return EnvironmentAuthority(
        authority_id="auth", tenant_id="tenant-a", run_id="run-a", execution_epoch=2,
        revision="sha256:"+"0"*64, environment_id="env-a", execution_source="VERIFIER",
        capabilities=(Capability("repository:read",("/workspace",)), Capability("evidence:write",("/workspace/evidence",))),
        read_paths=("/workspace",), write_paths=("/workspace/evidence",), network_mode="DENY",
        valid_from=now-timedelta(minutes=1), expires_at=now+timedelta(minutes=10), fencing_generation=5,
    )


class AuthorityTests(unittest.TestCase):
    def test_valid_read(self):
        now=datetime.now(UTC)
        authority().authorize(ToolRequest("tenant-a","run-a",2,5,"repository:read","read","/workspace/src/A.java"), now=now)

    def test_cross_tenant_denied(self):
        with self.assertRaises(AuthorityError):
            authority().authorize(ToolRequest("tenant-b","run-a",2,5,"repository:read","read","/workspace/A"), now=datetime.now(UTC))

    def test_stale_fencing_denied(self):
        with self.assertRaises(AuthorityError):
            authority().authorize(ToolRequest("tenant-a","run-a",2,4,"repository:read","read","/workspace/A"), now=datetime.now(UTC))

    def test_path_escape_denied(self):
        with self.assertRaises(AuthorityError):
            authority().authorize(ToolRequest("tenant-a","run-a",2,5,"repository:read","read","/workspace/../secret"), now=datetime.now(UTC))

    def test_write_scope_denied(self):
        with self.assertRaises(AuthorityError):
            authority().authorize(ToolRequest("tenant-a","run-a",2,5,"evidence:write","write","/workspace/src/A"), now=datetime.now(UTC))


if __name__ == "__main__":
    unittest.main()
