import unittest
from elmos_v3.semantic_gap import compare_profiles


class SemanticGapTests(unittest.TestCase):
    def test_gaps_are_explicit(self):
        gaps=compare_profiles(
            {"nullability":"Java nullable refs","numeric":"fixed-width wrap","exceptions":"throw"},
            {"nullability":"Option","numeric":"checked","exceptions":"Result"},
        )
        families={g.family for g in gaps}
        self.assertIn("null/undefined/option semantics",families)
        self.assertIn("integer/float/decimal semantics",families)
        self.assertIn("exception/error/panic/result semantics",families)
        self.assertTrue(all(g.resolution_required for g in gaps))


if __name__ == "__main__":
    unittest.main()
