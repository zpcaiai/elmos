import unittest
from elmos_v3.models import ArtifactRef, ProofObligation, ProofResult, ProofStatus, Severity
from elmos_v3.proof_graph import ProofGraphError, ProofObligationGraph


def obligation(key, severity=Severity.CRITICAL):
    return ProofObligation(
        obligation_id=key, family="demo", severity=severity, relation="refinement",
        scope=key, required_minimum_status=ProofStatus.PROVED_SOLVER_TRUSTED,
        accepted_evidence_classes=frozenset({"solver"}),
    )


class ProofGraphTests(unittest.TestCase):
    def test_cycle_is_rejected(self):
        with self.assertRaises(ProofGraphError):
            ProofObligationGraph([obligation("A"), obligation("B")], [("A","B"),("B","A")])

    def test_missing_dependency_is_rejected(self):
        with self.assertRaises(ProofGraphError):
            ProofObligationGraph([obligation("A")], [("A","MISSING")])

    def test_bounded_result_does_not_close_critical(self):
        graph = ProofObligationGraph([obligation("A")])
        artifact = ArtifactRef("a","sha256:"+"1"*64,"application/json")
        graph.apply_result(ProofResult(
            result_id="r", obligation_id="A", status=ProofStatus.BOUNDED_NO_COUNTEREXAMPLE,
            subject_revision="sha256:"+"2"*64, tool_name="bounded", tool_digest="sha256:"+"3"*64,
            encoder_digest="sha256:"+"4"*64, environment_revision="sha256:"+"5"*64,
            evidence=(artifact,), evidence_classes=frozenset({"solver"}),
        ))
        self.assertFalse(graph.all_critical_closed())
        self.assertEqual(graph.critical_unclosed()[0].status, ProofStatus.BOUNDED_NO_COUNTEREXAMPLE)

    def test_proved_result_closes_dependency(self):
        graph = ProofObligationGraph([obligation("A"), obligation("B")], [("B","A")])
        self.assertEqual([x.obligation_id for x in graph.ready()], ["A"])
        artifact = ArtifactRef("a","sha256:"+"1"*64,"application/json")
        graph.apply_result(ProofResult(
            result_id="r", obligation_id="A", status=ProofStatus.PROVED_SOLVER_TRUSTED,
            subject_revision="sha256:"+"2"*64, tool_name="solver", tool_digest="sha256:"+"3"*64,
            encoder_digest="sha256:"+"4"*64, environment_revision="sha256:"+"5"*64,
            evidence=(artifact,), evidence_classes=frozenset({"solver"}),
        ))
        self.assertEqual([x.obligation_id for x in graph.ready()], ["B"])


if __name__ == "__main__":
    unittest.main()
