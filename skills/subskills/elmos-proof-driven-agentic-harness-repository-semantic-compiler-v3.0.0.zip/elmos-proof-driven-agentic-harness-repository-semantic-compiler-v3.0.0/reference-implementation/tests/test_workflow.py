import unittest
from elmos_v3.workflow import RunAggregate, RunState, WorkflowError


class WorkflowTests(unittest.TestCase):
    def test_valid_transition_and_recovery(self):
        run=RunAggregate("r","rev",1,1)
        run.transition(RunState.ADMITTED, expected_sequence=0, fencing_generation=1)
        run.transition(RunState.PLANNING, expected_sequence=1, fencing_generation=1)
        run.transition(RunState.EXECUTING, expected_sequence=2, fencing_generation=1)
        run.transition(RunState.CHECKPOINTED, expected_sequence=3, fencing_generation=1)
        run.recover(new_execution_epoch=2, new_fencing_generation=2)
        self.assertEqual(run.state, RunState.RESUMING)

    def test_sequence_conflict(self):
        run=RunAggregate("r","rev",1,1)
        with self.assertRaises(WorkflowError):
            run.transition(RunState.ADMITTED, expected_sequence=7, fencing_generation=1)

    def test_stale_fencing(self):
        run=RunAggregate("r","rev",1,2)
        with self.assertRaises(WorkflowError):
            run.transition(RunState.ADMITTED, expected_sequence=0, fencing_generation=1)

    def test_invalid_terminal_recovery(self):
        run=RunAggregate("r","rev",1,1,state=RunState.COMPLETED)
        with self.assertRaises(WorkflowError):
            run.recover(new_execution_epoch=2,new_fencing_generation=2)


if __name__ == "__main__":
    unittest.main()
