# License Policy

This package is an Elmos implementation specification and reference code bundle. Before commercial redistribution, replace this policy with the organization's approved license and complete automated dependency/license review.

Third-party tools, language compilers, solvers, model providers and inherited ETGB fixtures retain their own licenses. Adapter presence does not grant redistribution rights. Production release requires SBOM, license allow/deny policy and legal review.
