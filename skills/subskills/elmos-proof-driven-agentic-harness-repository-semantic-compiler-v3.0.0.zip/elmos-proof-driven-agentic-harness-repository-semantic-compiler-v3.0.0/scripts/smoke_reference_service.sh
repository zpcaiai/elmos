#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PORT="${ELMOS_SMOKE_PORT:-18080}"
PYTHONPATH="$ROOT/reference-implementation/src" ELMOS_PORT="$PORT" python3 -m elmos_v3.service >"$ROOT/.smoke-service.log" 2>&1 &
PID=$!
trap 'kill "$PID" 2>/dev/null || true; rm -f "$ROOT/.smoke-service.log"' EXIT
READY=0
for _ in $(seq 1 30); do
  if python3 - "$PORT" 2>/dev/null <<'PY'
import sys, urllib.request
urllib.request.urlopen(f"http://127.0.0.1:{sys.argv[1]}/readyz",timeout=1).read()
PY
  then
    READY=1
    break
  fi
  sleep 0.2
done
if [[ "$READY" != "1" ]]; then
  echo "reference service did not become ready" >&2
  cat "$ROOT/.smoke-service.log" >&2
  exit 1
fi
for path in livez readyz metrics version; do
  python3 - "$PORT" "$path" <<'PY'
import sys, urllib.request
url=f"http://127.0.0.1:{sys.argv[1]}/{sys.argv[2]}"
with urllib.request.urlopen(url,timeout=2) as response:
    assert response.status==200, (url,response.status)
PY
done
echo "reference service smoke PASS"
