#!/usr/bin/env bash
set -euo pipefail
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET_ROOT="${1:?usage: install.sh /path/to/elmos [--force]}"
FORCE="${2:-}"
DEST="$TARGET_ROOT/packages/elmos-v3"
REGISTRY_DIR="$TARGET_ROOT/.elmos/skill-registries"

if [[ -e "$DEST" && "$FORCE" != "--force" ]]; then
  echo "Refusing to overwrite $DEST. Use --force only after reviewing local changes." >&2
  exit 2
fi

mkdir -p "$TARGET_ROOT/packages" "$REGISTRY_DIR"
if [[ -e "$DEST" ]]; then
  BACKUP="$TARGET_ROOT/packages/elmos-v3.backup.$(date +%Y%m%d%H%M%S)"
  mv "$DEST" "$BACKUP"
  echo "Existing installation moved to $BACKUP"
fi
cp -a "$SOURCE_DIR" "$DEST"
cp "$DEST/skills/registry.yaml" "$REGISTRY_DIR/elmos-v3.yaml"
cp "$DEST/migration/legacy-alias-registry.yaml" "$REGISTRY_DIR/elmos-v3-legacy-aliases.yaml"
(
  cd "$DEST"
  python3 scripts/validate_package.py
  PYTHONPATH=reference-implementation/src python3 -m unittest discover -s reference-implementation/tests -v
  python3 scripts/generate_registry.py --check
  python3 scripts/verify_migration_coverage.py
  python3 scripts/generate_checksums.py --check
)
echo "Installed Elmos v3 into $DEST"
