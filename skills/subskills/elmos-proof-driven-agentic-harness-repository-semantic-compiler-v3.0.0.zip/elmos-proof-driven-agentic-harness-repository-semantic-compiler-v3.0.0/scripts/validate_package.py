#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import py_compile
import sys
from collections import Counter, defaultdict, deque
from pathlib import Path

try:
    import yaml
    import jsonschema
except ImportError as exc:
    raise SystemExit("Install validation dependencies: pip install pyyaml jsonschema") from exc

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
warnings: list[str] = []


def fail(message: str) -> None:
    errors.append(message)


def load_yaml(path: Path):
    try:
        documents = list(yaml.safe_load_all(path.read_text(encoding="utf-8")))
        return documents[0] if len(documents) == 1 else documents
    except Exception as exc:
        fail(f"YAML parse failed: {path.relative_to(ROOT)}: {exc}")
        return None


def load_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"JSON parse failed: {path.relative_to(ROOT)}: {exc}")
        return None


# 1. Parse all YAML/JSON files except inherited large JSONL corpus.
for path in ROOT.rglob("*.yaml"):
    load_yaml(path)
for path in ROOT.rglob("*.yml"):
    load_yaml(path)
for path in ROOT.rglob("*.json"):
    load_json(path)

# 2. Validate routable skill shape and registry.
skill_docs = sorted(ROOT.glob("skills/P*/elmos-*/SKILL.md"))
if len(skill_docs) != 16:
    fail(f"expected 16 routable skills, found {len(skill_docs)}")
required_skill_files = {"SKILL.md","manifest.yaml","acceptance.yaml","implementation.yaml","runbook.md"}
skill_names: set[str] = set()
deps: dict[str, set[str]] = {}
for doc in skill_docs:
    folder = doc.parent
    missing = required_skill_files - {p.name for p in folder.iterdir() if p.is_file()}
    if missing:
        fail(f"{folder.relative_to(ROOT)} missing {sorted(missing)}")
    manifest = load_yaml(folder / "manifest.yaml") or {}
    name = manifest.get("metadata", {}).get("name")
    if not name:
        fail(f"{folder.relative_to(ROOT)} manifest has no name")
        continue
    if name in skill_names:
        fail(f"duplicate skill name: {name}")
    skill_names.add(name)
    deps[name] = {item["name"] for item in manifest.get("spec", {}).get("dependencies", [])}

registry = load_yaml(ROOT / "skills/registry.yaml") or {}
registry_names = {item.get("name") for item in registry.get("spec", {}).get("entrypoints", [])}
if registry_names != skill_names:
    fail(f"skill registry mismatch: missing={sorted(skill_names-registry_names)} extra={sorted(registry_names-skill_names)}")
for name, required in deps.items():
    unknown = required - skill_names
    if unknown:
        fail(f"{name} has unknown dependencies: {sorted(unknown)}")

# Detect dependency cycle.
indegree = {name: len(reqs) for name, reqs in deps.items()}
dependents: dict[str, set[str]] = defaultdict(set)
for name, reqs in deps.items():
    for req in reqs:
        dependents[req].add(name)
queue = deque(name for name, degree in indegree.items() if degree == 0)
visited = 0
while queue:
    current = queue.popleft()
    visited += 1
    for dependent in dependents[current]:
        indegree[dependent] -= 1
        if indegree[dependent] == 0:
            queue.append(dependent)
if visited != len(deps):
    fail("routable skill dependency graph contains a cycle")

# 3. JSON Schema meta-validation and examples.
schemas = {}
for path in sorted((ROOT / "contracts/schemas").glob("*.schema.json")):
    obj = load_json(path)
    if obj is not None:
        try:
            jsonschema.Draft202012Validator.check_schema(obj)
            schemas[path.name] = obj
        except Exception as exc:
            fail(f"schema meta-validation failed: {path.name}: {exc}")
example_map = {
    "revision-set.example.json":"revision-set.schema.json",
    "environment-authority.example.json":"environment-authority.schema.json",
    "proof-result.example.json":"proof-result.schema.json",
}
for example, schema in example_map.items():
    obj = load_json(ROOT / "contracts/examples" / example)
    if obj is not None and schema in schemas:
        try:
            jsonschema.validate(obj, schemas[schema])
        except Exception as exc:
            fail(f"example validation failed: {example}: {exc}")

# 4. Fixed architecture counts.
checks = {
    "kernels": len(list((ROOT / "kernels").glob("k*"))),
    "domain_packs": len(list((ROOT / "domain-packs").glob("*/domain-pack.yaml"))),
    "language_profiles": len(list((ROOT / "semantic-compiler/profiles/languages").glob("*.yaml"))),
    "framework_profiles": len(list((ROOT / "semantic-compiler/profiles/frameworks").glob("*.yaml"))),
    "verifier_adapters": len(list((ROOT / "verification/adapters").glob("*.yaml"))),
    "harness_adapters": len(list((ROOT / "harness/adapters").glob("*.yaml"))),
    "golden_routes": len(list((ROOT / "golden-routes").glob("*.yaml"))),
    "rego_modules": len(list((ROOT / "policy/rego").glob("*.rego"))),
    "postgres_migrations": len(list((ROOT / "database/migrations").glob("*.sql"))),
}
expected = {
    "kernels":8, "domain_packs":5, "language_profiles":15, "framework_profiles":9,
    "verifier_adapters":20, "harness_adapters":7, "golden_routes":5,
    "rego_modules":6, "postgres_migrations":4,
}
for key, value in expected.items():
    if checks[key] != value:
        fail(f"{key}: expected {value}, found {checks[key]}")

# 5. Legacy mapping exact coverage.
mapping_path = ROOT / "migration/legacy-skill-map.csv"
with mapping_path.open(encoding="utf-8", newline="") as handle:
    rows = list(csv.DictReader(handle))
if len(rows) != 115:
    fail(f"legacy mapping expected 115 rows, found {len(rows)}")
keys = {(row["source_package"], row["legacy_skill"]) for row in rows}
if len(keys) != 115:
    fail("legacy mapping has duplicate source skill")
if any(row["v3_owner_skill"] not in skill_names for row in rows):
    fail("legacy mapping targets unknown v3 skill")
if any(row["routable_in_v3"].lower() != "false" for row in rows):
    fail("a legacy skill remains independently routable")
snapshot_count = len(list((ROOT / "migration/source-snapshots").rglob("SKILL.md")))
if snapshot_count != 115:
    fail(f"legacy source snapshots expected 115, found {snapshot_count}")

# 6. ETGB inherited corpus.
summary = load_json(ROOT / "validation/etgb-v1.1/suites/summary.json") or {}
if summary.get("total_cases") != 46664:
    fail(f"ETGB total cases expected 46664, found {summary.get('total_cases')}")
case_index = ROOT / "validation/etgb-v1.1/suites/CASE_INDEX.csv"
if not case_index.exists():
    fail("ETGB CASE_INDEX.csv missing")

# 7. Compile reference Python and scripts.
for path in list((ROOT / "reference-implementation").rglob("*.py")) + list((ROOT / "scripts").glob("*.py")):
    try:
        py_compile.compile(str(path), doraise=True)
    except Exception as exc:
        fail(f"Python compile failed: {path.relative_to(ROOT)}: {exc}")

# 8. Anti-status-inflation/static invariants.
certificate_schema = schemas.get("completion-certificate.schema.json", {})
serialized = json.dumps(certificate_schema)
for required_text in ["independent", "evidence_root", "revision_set_id"]:
    if required_text not in serialized:
        fail(f"completion certificate schema lacks {required_text}")
proof_policy = (ROOT / "verification/proof-status-policy.yaml").read_text(encoding="utf-8")
for status in ["BOUNDED_NO_COUNTEREXAMPLE","UNKNOWN_TIMEOUT","UNSUPPORTED","WAIVED_BY_APPROVER"]:
    if status not in proof_policy:
        fail(f"proof status policy lacks {status}")
for placeholder in ["REPLACE_WITH_RELEASE_TIME_PINNED_DIGEST","REPLACE_WITH_SIGNED_DIGEST","REPLACE_WITH_SIGNED_MIGRATION_IMAGE_DIGEST"]:
    if any(placeholder in p.read_text(encoding="utf-8", errors="ignore") for p in ROOT.rglob("*") if p.is_file() and p.stat().st_size < 5_000_000):
        warnings.append(f"release-time placeholder remains: {placeholder}")

report = {
    "status":"PASS" if not errors else "FAIL",
    "errors":errors,
    "warnings":sorted(set(warnings)),
    "counts":checks | {
        "routable_skills":len(skill_docs),
        "legacy_mappings":len(rows),
        "legacy_snapshots":snapshot_count,
        "json_schemas":len(schemas),
        "etgb_cases":summary.get("total_cases"),
    },
}
print(json.dumps(report, indent=2))
if errors:
    raise SystemExit(1)
