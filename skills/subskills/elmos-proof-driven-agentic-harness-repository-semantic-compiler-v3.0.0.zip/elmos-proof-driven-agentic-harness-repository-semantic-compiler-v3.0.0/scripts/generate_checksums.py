#!/usr/bin/env python3
from __future__ import annotations
import argparse
import hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"FILES.sha256"
EXCLUDED={"FILES.sha256"}


def rows():
    result=[]
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel=str(path.relative_to(ROOT))
        if path.name in EXCLUDED or "__pycache__" in path.parts or rel.startswith(".git/"):
            continue
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        result.append(f"{digest}  {rel}")
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--check",action="store_true")
    args=parser.parse_args()
    content="\n".join(rows())+"\n"
    if args.check:
        if not OUT.exists() or OUT.read_text(encoding="utf-8") != content:
            print("FILES.sha256 is stale")
            return 1
        print(f"checksums valid: {len(content.splitlines())} files")
        return 0
    OUT.write_text(content,encoding="utf-8")
    print(f"wrote {len(content.splitlines())} checksums")
    return 0


if __name__=="__main__":
    raise SystemExit(main())
