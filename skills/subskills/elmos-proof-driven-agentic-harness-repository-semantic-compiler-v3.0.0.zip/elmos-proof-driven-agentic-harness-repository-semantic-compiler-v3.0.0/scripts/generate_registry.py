#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]


def build() -> dict:
    entries=[]
    for manifest_path in sorted(ROOT.glob("skills/P*/elmos-*/manifest.yaml")):
        data=yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
        meta=data["metadata"]
        spec=data["spec"]
        skill_dir=manifest_path.parent
        entries.append({
            "id":meta["id"],"name":meta["name"],"priority":meta["priority"],
            "kind":meta["labels"]["kind"],"path":str((skill_dir/"SKILL.md").relative_to(ROOT)),
            "owner":spec["owner"],
            "dependencies":[item["name"] for item in spec.get("dependencies",[])],
        })
    return {
        "apiVersion":"elmos.ai/v3","kind":"SkillRegistry",
        "metadata":{"name":"elmos-v3","version":"3.0.0"},
        "spec":{"routableCount":len(entries),"entrypoints":entries,
                "legacyRouting":"migration/legacy-alias-registry.yaml",
                "rule":"legacy aliases may resolve to v3 entrypoints but may not execute as independent owners"}
    }


def main() -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument("--check",action="store_true")
    args=parser.parse_args()
    generated=build()
    yaml_path=ROOT/"skills/registry.yaml"
    json_path=ROOT/"skills/registry.json"
    if args.check:
        current=yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
        if current != generated:
            print("registry.yaml is stale")
            return 1
        current_json=json.loads(json_path.read_text(encoding="utf-8"))
        if current_json != generated:
            print("registry.json is stale")
            return 1
        print(f"registry consistent: {len(generated['spec']['entrypoints'])} skills")
        return 0
    yaml_path.write_text(yaml.safe_dump(generated,sort_keys=False,allow_unicode=True),encoding="utf-8")
    json_path.write_text(json.dumps(generated,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    return 0


if __name__=="__main__":
    raise SystemExit(main())
