#!/usr/bin/env python3
from __future__ import annotations
import csv
from collections import Counter
from pathlib import Path
import yaml

ROOT=Path(__file__).resolve().parents[1]
with (ROOT/"migration/legacy-skill-map.csv").open(encoding="utf-8",newline="") as f:
    rows=list(csv.DictReader(f))
registry=yaml.safe_load((ROOT/"skills/registry.yaml").read_text(encoding="utf-8"))
targets={x["name"] for x in registry["spec"]["entrypoints"]}
assert len(rows)==115, len(rows)
assert len({(x["source_package"],x["legacy_skill"]) for x in rows})==115
assert all(x["v3_owner_skill"] in targets for x in rows)
assert all(x["routable_in_v3"].lower()=="false" for x in rows)
snapshots=list((ROOT/"migration/source-snapshots").rglob("SKILL.md"))
assert len(snapshots)==115, len(snapshots)
print("legacy migration coverage PASS")
print(Counter(x["source_package"] for x in rows))
print(Counter(x["v3_owner_skill"] for x in rows))
