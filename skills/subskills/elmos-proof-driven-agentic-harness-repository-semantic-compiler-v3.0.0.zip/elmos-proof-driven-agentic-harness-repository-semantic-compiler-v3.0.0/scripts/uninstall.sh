#!/usr/bin/env bash
set -euo pipefail
TARGET_ROOT="${1:?usage: uninstall.sh /path/to/elmos}"
DEST="$TARGET_ROOT/packages/elmos-v3"
if [[ ! -d "$DEST" ]]; then
  echo "Elmos v3 is not installed at $DEST"
  exit 0
fi
python3 - "$DEST" <<'PY'
from pathlib import Path
import hashlib, sys
root=Path(sys.argv[1])
manifest=root/"FILES.sha256"
modified=[]
for line in manifest.read_text(encoding="utf-8").splitlines():
    expected, rel=line.split("  ",1)
    path=root/rel
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        modified.append(rel)
if modified:
    print("Refusing uninstall because installed files were modified:", file=sys.stderr)
    for item in modified[:50]:
        print("  "+item, file=sys.stderr)
    raise SystemExit(3)
PY
rm -rf "$DEST"
rm -f "$TARGET_ROOT/.elmos/skill-registries/elmos-v3.yaml"
rm -f "$TARGET_ROOT/.elmos/skill-registries/elmos-v3-legacy-aliases.yaml"
echo "Uninstalled Elmos v3"
