# Elmos Proof-Driven Agentic Harness / Repository Semantic Compiler v3

**Package:** `elmos-proof-driven-agentic-harness-repository-semantic-compiler-v3.0.0`  
**Version:** `3.0.0`  
**Release date:** `2026-08-28`  
**Status:** **commercial production architecture + executable reference kernel + migration/validation package**  
**Product category:** Proof-guided / proof-carrying repository-scale software engineering platform

## 1. Product definition

Elmos v3 is not another coding-agent wrapper and not a loose collection of skills. It is one coherent execution system:

```text
Goal / Acceptance Contract
          ↓
Repository Evidence Graph
          ↓
Repository Semantic IR
          ↓
Proof Obligation Graph
          ↓
Agentic reasoning + deterministic transformation
          ↓
Verifier portfolio + counterexample/repair loop
          ↓
E0–E5 + P05 independent stop gate
          ↓
Signed Completion Certificate
```

The commercial promise is deliberately precise:

> **Within a declared Certified Envelope, every critical Proof Obligation must reach an accepted closure state. Unknown, unsupported, bounded, assumed, monitored and waived results remain visible and can never be inflated into proof.**

The model may propose specifications, invariants, lemmas, transformation rules, tests and repairs. The model is never the authoritative oracle and never certifies its own work.

## 2. Why v3 replaces capability stacking

The three source packages contained **115 independently named skill entry points**:

- Repository Autonomy Kernel v2: 31
- Formal Assurance Kernel v1: 60
- ETGB v1.1: 24

v3 maps all 115 into **8 unique kernels + 5 domain packs + 3 cross-cutting product skills**. Legacy IDs remain compatibility aliases and migration evidence only. Runtime planning must route through the 16 v3 entry points; it may invoke hundreds of internal components, but it cannot create competing ownership of goal state, authority, semantic truth, proof status or certification.

## 3. Eight-kernel architecture

| Kernel | Name | Mission |
|---|---|---|
| K1 | **Goal / Specification Kernel** | 把自然语言目标、存量规范、约束、预算和验收标准编译为版本化、可执行、可证明的 Goal Contract、Observable Contract、Requirement Graph 与 Revision Set。 |
| K2 | **Repository Intelligence Kernel** | 以只读、增量、证据优先方式重建仓库的结构、依赖、运行行为、数据、协议、安全与业务能力图谱，为推理和变换提供可查询事实层。 |
| K3 | **Repository Semantic Compiler Kernel** | 将多语言、多框架、多数据技术的具体程序编译为可执行、可比较、可证明的 Repository Semantic IR，并显式建模语义间隙。 |
| K4 | **Agentic Reasoning Kernel** | 把大模型用于最有价值的认知工作：规范恢复、假设生成、规划、引理/不变量合成、反例解释和最小修复，同时禁止模型成为最终正确性 Oracle。 |
| K5 | **Transformation Kernel** | 以 deterministic-first、semantic-rule-driven、bounded-generative 的方式执行仓库级生成、转换、现代化和重构，形成可回滚、可重放、可验证的 ChangeGraph。 |
| K6 | **Proof & Verification Kernel** | 为每个 Proof Obligation 选择独立、组合式 verifier portfolio，运行静态、动态、差分、属性、形式化和非功能验证，并把反例反馈给修复闭环。 |
| K7 | **Harness Runtime Kernel** | 提供长任务、多 Agent、多工作区、多模型、多工具的 durable execution substrate，把权限、运行状态、来源、策略和生命周期绑定到具体 Environment/Attachment。 |
| K8 | **Certification Kernel** | 由独立于生成与修复 Agent 的 Certifier 对精确 Revision Set、Proof Obligation closure、E0–E5、部署证据和商业 Golden Route 证据签发不可伪造的 Completion Certificate。 |

Cross-cutting invariants:

1. **Database and immutable artifacts are the state of record.** Chat history is not recovery state.
2. **Environment-owned authority.** Thread identity never silently grants sandbox, network, secret or tool authority.
3. **Semantic truth is compiler/runtime grounded.** LLM text and generic ASTs are not authoritative semantics.
4. **Deterministic-first transformation.** Generative edits are bounded, localized and independently validated.
5. **Proof obligations drive work.** Every edit, test, proof and repair must close or refine an obligation.
6. **Independent completion.** `Agent says done != VERIFIED_COMPLETE`.
7. **Fail closed.** Ambiguous side effects, stale fencing, missing evidence, unknown proof status or cross-tenant access block completion.
8. **Machine time and cost.** ETA is automatic wall-clock duration; usage, compute, storage and revenue are reconciled.

## 4. Domain packs

| Domain pack | Scope | Core obligation families |
|---|---|---|
| `spring-legacy-modernization` | Struts 1、Struts 2、原生 Servlet 及混合遗留 Java Web 仓库到 Spring Boot 4 的语义保持现代化。 | route precedence and method equivalence, request binding/validation, session state refinement, filter/interceptor/AOP ordering… |
| `cross-language-conversion` | Java、Kotlin、Python、C#、Go、Rust、C/C++、PHP、TypeScript/JavaScript、Objective-C、Swift、Dart/Flutter 等仓库级跨语言/框架转换。 | types/nullability, integer overflow and numeric precision, Unicode/string/regex, floating point and decimal… |
| `multi-language-project-generation` | 从需求、多模态材料、现有系统契约或产品原型生成完整、可部署、可运维、多语言项目。 | requirement satisfaction, architecture constraint conformance, API/schema invariants, workflow safety/liveness/fairness… |
| `sql-dialect-routine-conversion` | SQL dialect、DDL/DML、query、procedure/function/package/trigger 与事务语义的数据库间转换。 | bag/set/order semantics, NULL and three-valued logic, type/precision/collation/time, query equivalence… |
| `repository-refactoring` | 跨文件、跨模块、跨服务的架构重构、依赖升级、模块拆分/合并、API 演进、并发/性能/安全改造。 | observable behavior preservation, public contract compatibility, data and event invariants, architecture constraints… |

A Domain Pack is not a separate agent stack. It supplies:

```text
Semantic profiles
+ Framework/data models
+ Transformation rules
+ Proof-obligation templates
+ Oracle contracts
+ Golden Route
+ Certification thresholds
```

All packs run on the same eight kernels.

## 5. Canonical proof result semantics

| Status | Meaning |
|---|---|
| `PROVED_CERTIFIED` | 由可独立检查的证书或 proof object 证明；最强。 |
| `PROVED_INDUCTIVE` | 归纳不变量/模型检查证明 safety/liveness，在声明模型与公平性假设内成立。 |
| `PROVED_SOLVER_TRUSTED` | SMT/符号工具返回 unsat/valid；信任边界包含 solver 与编码器。 |
| `PROVED_FOR_SUPPORTED_FRAGMENT` | 仅对声明的语法/语义片段完成证明。 |
| `BOUNDED_NO_COUNTEREXAMPLE` | 在有限边界内未发现反例；绝不展示成无界证明。 |
| `REFUTED_WITH_COUNTEREXAMPLE` | 存在可重放反例，必须失败或修复。 |
| `UNKNOWN_TIMEOUT` | 验证超时，不能通过 critical gate。 |
| `UNKNOWN_RESOURCE_LIMIT` | 资源耗尽，不能通过 critical gate。 |
| `UNSUPPORTED` | 工具或语义片段不支持；必须换策略、监控或明确排除。 |
| `ASSUMPTION_REQUIRED` | 只有增加显式假设才能继续；假设必须审批并进入证书。 |
| `RUNTIME_MONITORED` | 开放世界边界只能运行期监测；必须有告警和回滚。 |
| `WAIVED_BY_APPROVER` | 授权人接受残余风险；不能提升为 PROVED。 |

Critical obligations may close only with the evidence classes allowed by their policy. `BOUNDED_NO_COUNTEREXAMPLE`, `RUNTIME_MONITORED`, `WAIVED_BY_APPROVER`, `ASSUMPTION_REQUIRED`, `UNKNOWN_*` and `UNSUPPORTED` never silently become proof.

## 6. E0–E5 and P05

| Gate | Required outcome |
|---|---|
| `P05_DEPLOYMENT_COMPLETE` | Exact release manifest, migrations, health/readiness/metrics/version, security controls, backup/restore, worker recovery and deployment evidence pass. |
| `E0_FROZEN_CONTRACT` | Goal, observable contract, assumptions, certified envelope and exact revision set are frozen. |
| `E1_STATIC_SEMANTIC` | Build/type/symbol/dataflow/contracts/dependencies and critical semantic gaps are resolved or explicitly bounded. |
| `E2_FORMAL_MODEL` | Required SMT/model-checking/symbolic/proof obligations reach accepted statuses under declared TCB and assumptions. |
| `E3_DIFFERENTIAL_BEHAVIOR` | Source/target or spec/implementation scenarios, properties, metamorphic relations and data reconciliation pass. |
| `E4_RESILIENCE_SECURITY_PERFORMANCE` | Security, tenant isolation, supply chain, failure recovery, concurrency, load, latency and resource guardrails pass. |
| `E5_CUSTOMER_GOLDEN_ROUTE` | Representative real repository, independent holdout, customer acceptance, rollback/cutover and signed evidence bundle pass. |

`PROD` or `CERTIFIED` is impossible unless the exact candidate revision passes the applicable gates with fresh, unrevoked evidence.

## 7. Package layout

```text
skills/                         16 routable skills, five files each
kernels/                        internal component registries and workflows
domain-packs/                   semantic profiles, rules, obligations and gates
contracts/schemas/              machine-valid contracts
semantic-compiler/              frontend/profile/IR and semantic-gap definitions
verification/                   verifier adapters and proof policies
harness/                        environment authority, adapters and lifecycle
golden-routes/                  five commercial workflows
validation/etgb-v1.1/           46,664-case inherited evaluation data plane
reference-implementation/       executable Python proof/runtime kernel
database/migrations/            PostgreSQL 17 authority/proof/evidence schema
policy/rego/                    fail-closed policy modules
api/                            OpenAPI, AsyncAPI and protobuf contracts
observability/                  metrics, alerts and dashboard specification
console/                        operator/product UI information architecture
deploy/                         local/Kubernetes/CI deployment skeleton
migration/                      115→16 mapping and compatibility alias registry
docs/                           architecture, semantics, assurance and runbooks
scripts/                        validation, registry, checksums, install/uninstall
```

## 8. Quick validation

```bash
python3 scripts/validate_package.py
python3 -m unittest discover -s reference-implementation/tests -v
python3 scripts/generate_registry.py --check
python3 scripts/verify_migration_coverage.py
```

Optional tools, when installed in the target environment:

```bash
opa test policy/rego
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f database/migrations/V300__v3_core.sql
docker compose -f deploy/docker-compose.yaml config
kubectl apply --dry-run=server -f deploy/k8s/
```

## 9. Installation into Elmos

```bash
./scripts/install.sh /path/to/elmos
```

The installer performs a hash-aware copy under `packages/elmos-v3/`, registers v3 skills and compatibility aliases, and refuses to overwrite locally modified files without an explicit flag.

## 10. Commercial production boundary

This package contains a production-grade architecture, contracts, policies, migration plan, executable reference kernel, tests, ETGB corpus, domain workflows and deployment skeleton. It does **not** claim that:

- all external compiler frontends and verifier binaries are installed in the current environment;
- live PostgreSQL/OPA/Kubernetes/model-provider conformance has already run;
- a customer repository has passed E5;
- arbitrary programs can always be proved equivalent;
- a bounded or runtime-monitored result is a mathematical proof.

Those claims require exact target-environment evidence. See `docs/HONEST_ASSURANCE_BOUNDARY.md`.
