# SQL Dialect / Routine Conversion Domain Pack

## Scope

SQL dialect、DDL/DML、query、procedure/function/package/trigger 与事务语义的数据库间转换。

## Architectural rule

This pack contributes semantic profiles, transformation rules, obligations, oracles and thresholds. It does not create a separate agent stack and cannot bypass the eight kernels.

## Source profiles

- PostgreSQL
- Oracle
- SQL Server
- MySQL/MariaDB
- DB2
- Snowflake
- BigQuery
- Redshift
- Teradata
- SQLite
- Hive/Spark SQL

## Target profiles

- registered SQL/runtime profiles

## Proof-obligation families

- bag/set/order semantics
- NULL and three-valued logic
- type/precision/collation/time
- query equivalence
- lossless schema mapping
- constraint preservation
- DML state equivalence
- routine CFG/SSA contracts
- trigger trace and termination
- dynamic SQL boundary
- transaction/isolation/exception
- query plan/performance

## Minimum certification

- `schema losslessness closed`
- `critical query/routine equivalence`
- `transaction semantics accepted`
- `data reconciliation zero unexplained drift`
- `performance regression within contract`

## Golden Route

`golden-routes/sql-dialect-routine-conversion.yaml`
