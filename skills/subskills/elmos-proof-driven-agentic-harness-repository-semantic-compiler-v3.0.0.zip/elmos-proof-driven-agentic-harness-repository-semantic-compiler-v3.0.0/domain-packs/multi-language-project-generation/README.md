# Multi-Language Project Generation Domain Pack

## Scope

从需求、多模态材料、现有系统契约或产品原型生成完整、可部署、可运维、多语言项目。

## Architectural rule

This pack contributes semantic profiles, transformation rules, obligations, oracles and thresholds. It does not create a separate agent stack and cannot bypass the eight kernels.

## Source profiles

- Requirement Graph
- Data/API/Workflow/Security/Resource Formal Specs
- Architecture constraints

## Target profiles

- backend/frontend/mobile/miniapp/data/AI/industrial system archetypes

## Proof-obligation families

- requirement satisfaction
- architecture constraint conformance
- API/schema invariants
- workflow safety/liveness/fairness
- tenant noninterference
- security and privacy
- resource/token/credit bounds
- build/deploy/ops completeness
- UI/accessibility/compatibility
- observability/rollback/disaster recovery

## Minimum certification

- `requirements traceability 100% for critical requirements`
- `architecture decisions recorded`
- `generated core verified or rigorously tested`
- `deployability P05`
- `customer acceptance scenarios pass`

## Golden Route

`golden-routes/multi-language-project-generation.yaml`
