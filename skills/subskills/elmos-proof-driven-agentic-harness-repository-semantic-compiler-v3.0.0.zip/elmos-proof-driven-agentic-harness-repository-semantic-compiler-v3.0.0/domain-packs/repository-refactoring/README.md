# Repository-Scale Refactoring Domain Pack

## Scope

跨文件、跨模块、跨服务的架构重构、依赖升级、模块拆分/合并、API 演进、并发/性能/安全改造。

## Architectural rule

This pack contributes semantic profiles, transformation rules, obligations, oracles and thresholds. It does not create a separate agent stack and cannot bypass the eight kernels.

## Source profiles

- existing repository semantic profile

## Target profiles

- approved architecture and quality target

## Proof-obligation families

- observable behavior preservation
- public contract compatibility
- data and event invariants
- architecture constraints
- dependency and supply-chain safety
- performance/resource guardrails
- concurrency correctness
- operational continuity
- rollback and staged rollout

## Minimum certification

- `public contract unchanged or versioned`
- `critical behavior preserved`
- `architecture constraints pass`
- `mutation effectiveness`
- `canary/rollback readiness`

## Golden Route

`golden-routes/repository-refactoring.yaml`
