# Full-Repository Cross-Language Conversion Domain Pack

## Scope

Java、Kotlin、Python、C#、Go、Rust、C/C++、PHP、TypeScript/JavaScript、Objective-C、Swift、Dart/Flutter 等仓库级跨语言/框架转换。

## Architectural rule

This pack contributes semantic profiles, transformation rules, obligations, oracles and thresholds. It does not create a separate agent stack and cannot bypass the eight kernels.

## Source profiles

- all registered language profiles

## Target profiles

- all certified target profiles

## Proof-obligation families

- types/nullability
- integer overflow and numeric precision
- Unicode/string/regex
- floating point and decimal
- time/date/timezone
- exceptions/effects/resources
- concurrency/async/memory model
- reflection/dynamic/FFI/ABI
- serialization/API/protocol
- data/transaction/cache/event state
- build/deploy/observability
- repository assume-guarantee composition

## Minimum certification

- `semantic profiles pinned`
- `product-program or translation validation for critical units`
- `behavioral differential coverage`
- `open-world boundaries monitored`
- `performance and resource budget accepted`

## Golden Route

`golden-routes/cross-language-conversion.yaml`
