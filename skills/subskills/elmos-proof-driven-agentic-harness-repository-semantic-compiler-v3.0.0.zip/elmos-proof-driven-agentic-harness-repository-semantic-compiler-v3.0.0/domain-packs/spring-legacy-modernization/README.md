# Spring Legacy Modernization Domain Pack

## Scope

Struts 1、Struts 2、原生 Servlet 及混合遗留 Java Web 仓库到 Spring Boot 4 的语义保持现代化。

## Architectural rule

This pack contributes semantic profiles, transformation rules, obligations, oracles and thresholds. It does not create a separate agent stack and cannot bypass the eight kernels.

## Source profiles

- Struts 1
- Struts 2
- Servlet/JSP
- Spring Framework legacy
- EJB/JPA/Hibernate legacy
- XML-heavy configuration

## Target profiles

- Spring Boot 4
- Spring Framework 7
- Jakarta EE namespace
- Spring Security 7
- supported Java LTS profile

## Proof-obligation families

- route precedence and method equivalence
- request binding/validation
- session state refinement
- filter/interceptor/AOP ordering
- authentication/authorization dominance
- exception/status/view refinement
- transaction boundary and rollback
- ORM/schema/data migration
- JSP/view observable output
- async/scheduling/messaging
- external side effects
- performance/security/supply chain

## Minimum certification

- `baseline reproducible`
- `critical route coverage 100%`
- `security dominance preserved`
- `no unresolved P0 semantic gap`
- `dual-runtime differential within contract`
- `rollback rehearsed`

## Golden Route

`golden-routes/spring-legacy-modernization.yaml`
