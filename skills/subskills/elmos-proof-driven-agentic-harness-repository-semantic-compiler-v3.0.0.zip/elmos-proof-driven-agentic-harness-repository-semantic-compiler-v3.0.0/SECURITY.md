# Security

Report vulnerabilities through the organization's private security channel, not a public issue.

Critical categories:
- cross-tenant access;
- authority/sandbox/secret/network bypass;
- stale fencing commit;
- evidence/certificate forgery or substitution;
- model self-certification/status inflation;
- external-side-effect duplication;
- supply-chain/toolchain compromise.

Never include customer repositories, secrets, proof evidence or exploit details in public reports.
