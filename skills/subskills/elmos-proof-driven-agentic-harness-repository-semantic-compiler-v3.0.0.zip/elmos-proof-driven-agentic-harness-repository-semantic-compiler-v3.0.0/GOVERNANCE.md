# Governance

Changes to canonical objects, proof statuses, authority semantics, certification gates, semantic profiles or trusted computing base require architecture and security review.

A new feature should normally become:
- an internal component of one kernel;
- a Domain Pack rule/profile/obligation;
- a verifier/harness adapter;
- an evaluation case.

Creating a new routable skill requires proof that no existing canonical owner can safely contain it, plus a migration and anti-duplication plan.
