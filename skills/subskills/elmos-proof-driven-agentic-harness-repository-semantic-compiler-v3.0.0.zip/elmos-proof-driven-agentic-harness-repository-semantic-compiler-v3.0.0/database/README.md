# PostgreSQL 17 Data Model

Migrations implement the v3 canonical runtime:
- durable Goal/Run/Execution Epoch/Task state;
- Environment Authority, lease and fencing;
- Repository Evidence Graph and Semantic IR metadata;
- Proof Obligation Graph, results, evidence, gates and certificates;
- external-side-effect reconciliation;
- credit, usage, cost and machine ETA;
- verified-case learning and controlled promotion;
- RLS, append-only evidence and operational views.

Production validation must run against a real PostgreSQL 17 server, including RLS negative tests, stale-worker races, checkpoint recovery, backup/PITR and capacity tests.
