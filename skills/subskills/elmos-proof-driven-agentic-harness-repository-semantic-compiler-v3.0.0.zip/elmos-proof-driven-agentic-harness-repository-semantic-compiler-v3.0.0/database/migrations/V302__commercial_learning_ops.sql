BEGIN;

CREATE TABLE integration.external_side_effect (
  side_effect_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  run_id uuid NOT NULL REFERENCES exec.run(run_id),
  task_attempt_id uuid NOT NULL REFERENCES exec.task_attempt(attempt_id),
  provider text NOT NULL,
  operation text NOT NULL,
  idempotency_key text NOT NULL,
  request_sha256 text NOT NULL CHECK (request_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  state text NOT NULL CHECK (state IN ('NOT_STARTED','STARTED','SUCCEEDED','FAILED_RETRYABLE','FAILED_TERMINAL','UNKNOWN_RESULT','RECONCILED')),
  external_reference text,
  reconciliation_strategy text NOT NULL,
  last_reconciled_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, provider, operation, idempotency_key)
);

CREATE TABLE metering.credit_account (
  credit_account_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  account_key text NOT NULL,
  currency text NOT NULL,
  available_amount numeric(20,8) NOT NULL DEFAULT 0,
  reserved_amount numeric(20,8) NOT NULL DEFAULT 0,
  version bigint NOT NULL DEFAULT 0,
  UNIQUE (tenant_id, account_key),
  CHECK (available_amount >= 0 AND reserved_amount >= 0)
);

CREATE TABLE metering.credit_reservation (
  reservation_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  credit_account_id uuid NOT NULL REFERENCES metering.credit_account(credit_account_id),
  goal_id uuid NOT NULL REFERENCES core.goal(goal_id),
  run_id uuid REFERENCES exec.run(run_id),
  reserved_amount numeric(20,8) NOT NULL CHECK (reserved_amount >= 0),
  consumed_amount numeric(20,8) NOT NULL DEFAULT 0 CHECK (consumed_amount >= 0),
  refunded_amount numeric(20,8) NOT NULL DEFAULT 0 CHECK (refunded_amount >= 0),
  state text NOT NULL CHECK (state IN ('ACTIVE','CONSUMED','RELEASED','EXPIRED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  CHECK (consumed_amount + refunded_amount <= reserved_amount)
);

CREATE TABLE metering.usage_event (
  usage_event_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  goal_id uuid NOT NULL REFERENCES core.goal(goal_id),
  run_id uuid NOT NULL REFERENCES exec.run(run_id),
  execution_epoch_id uuid REFERENCES exec.execution_epoch(execution_epoch_id),
  task_attempt_id uuid REFERENCES exec.task_attempt(attempt_id),
  provider text NOT NULL,
  resource_kind text NOT NULL,
  quantity numeric(24,8) NOT NULL CHECK (quantity >= 0),
  unit text NOT NULL,
  unit_cost numeric(20,10) NOT NULL CHECK (unit_cost >= 0),
  total_cost numeric(20,8) GENERATED ALWAYS AS (quantity * unit_cost) STORED,
  currency text NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE metering.eta_projection (
  eta_projection_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  run_id uuid NOT NULL REFERENCES exec.run(run_id),
  workflow_node_id text,
  projected_remaining_seconds bigint NOT NULL CHECK (projected_remaining_seconds >= 0),
  confidence_low_seconds bigint,
  confidence_high_seconds bigint,
  model_revision text NOT NULL,
  features jsonb NOT NULL,
  projected_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE learning.verified_case (
  verified_case_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES core.tenant(tenant_id),
  domain_pack text NOT NULL,
  source_profile text NOT NULL,
  target_profile text,
  repository_fingerprint text NOT NULL,
  goal_contract_artifact_id uuid NOT NULL REFERENCES artifact.artifact(artifact_id),
  evidence_root_sha256 text NOT NULL CHECK (evidence_root_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  certificate_id uuid REFERENCES verify.completion_certificate(certificate_id),
  consent_scope text NOT NULL,
  holdout_eligible boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE learning.improvement_candidate (
  improvement_candidate_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES core.tenant(tenant_id),
  candidate_kind text NOT NULL CHECK (candidate_kind IN ('RULE','SKILL','POLICY','MODEL_ROUTE','HARNESS_ADAPTER','VERIFIER_ENCODING')),
  source_case_ids jsonb NOT NULL,
  candidate_artifact_id uuid NOT NULL REFERENCES artifact.artifact(artifact_id),
  state text NOT NULL CHECK (state IN ('INBOX','REPLAYING','HOLDOUT','REVIEW','CANARY','PROMOTED','REJECTED','ROLLED_BACK')),
  holdout_result jsonb,
  approved_by text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE ops.skill_alias (
  alias_name text PRIMARY KEY,
  v3_skill_name text NOT NULL,
  owning_kernel text,
  domain_pack text,
  source_package text NOT NULL,
  source_version text NOT NULL,
  source_path text NOT NULL,
  migration_status text NOT NULL CHECK (migration_status IN ('MAPPED','DEPRECATED','BLOCKED')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE ops.release_manifest (
  release_manifest_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  version text NOT NULL,
  git_revision text,
  manifest_sha256 text NOT NULL CHECK (manifest_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  components jsonb NOT NULL,
  database_schema_revision integer NOT NULL,
  policy_bundle_sha256 text NOT NULL CHECK (policy_bundle_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (version, manifest_sha256)
);

CREATE TABLE ops.deployment_gate (
  deployment_gate_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES core.tenant(tenant_id),
  environment text NOT NULL,
  release_manifest_id uuid NOT NULL REFERENCES ops.release_manifest(release_manifest_id),
  decision text NOT NULL CHECK (decision IN ('PASS','FAIL','BLOCKED')),
  evidence_root_sha256 text,
  evaluated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (environment, release_manifest_id)
);

CREATE INDEX idx_side_effect_unknown ON integration.external_side_effect(tenant_id, state) WHERE state = 'UNKNOWN_RESULT';
CREATE INDEX idx_usage_run ON metering.usage_event(tenant_id, run_id, occurred_at);
CREATE INDEX idx_improvement_state ON learning.improvement_candidate(state, created_at);

COMMIT;
