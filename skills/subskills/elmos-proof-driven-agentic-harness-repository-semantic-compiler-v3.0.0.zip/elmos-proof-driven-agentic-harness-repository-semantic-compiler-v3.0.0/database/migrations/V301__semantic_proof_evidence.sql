BEGIN;

CREATE TABLE artifact.artifact (
  artifact_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  sha256 text NOT NULL CHECK (sha256 ~ '^sha256:[0-9a-f]{64}$'),
  media_type text NOT NULL,
  size_bytes bigint NOT NULL CHECK (size_bytes >= 0),
  storage_uri text NOT NULL,
  schema_version text,
  created_by_execution_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, sha256)
);

CREATE TABLE analysis.repository_snapshot (
  repository_snapshot_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  project_id uuid NOT NULL REFERENCES core.project(project_id),
  repository_revision_sha256 text NOT NULL CHECK (repository_revision_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  manifest_artifact_id uuid NOT NULL REFERENCES artifact.artifact(artifact_id),
  source_kind text NOT NULL,
  immutable boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, repository_revision_sha256)
);

CREATE TABLE analysis.evidence_graph (
  evidence_graph_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  repository_snapshot_id uuid NOT NULL REFERENCES analysis.repository_snapshot(repository_snapshot_id),
  profile_revision_sha256 text NOT NULL CHECK (profile_revision_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  graph_manifest_artifact_id uuid NOT NULL REFERENCES artifact.artifact(artifact_id),
  coverage jsonb NOT NULL,
  dynamic_boundary_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, repository_snapshot_id, profile_revision_sha256)
);

CREATE TABLE semantic.semantic_profile (
  semantic_profile_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES core.tenant(tenant_id),
  profile_key text NOT NULL,
  version text NOT NULL,
  profile_sha256 text NOT NULL CHECK (profile_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  profile_artifact_id uuid NOT NULL REFERENCES artifact.artifact(artifact_id),
  authoritative_scope jsonb NOT NULL,
  unsupported_policy text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, profile_key, version)
);

CREATE TABLE semantic.repository_ir (
  repository_ir_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  repository_snapshot_id uuid NOT NULL REFERENCES analysis.repository_snapshot(repository_snapshot_id),
  ir_revision_sha256 text NOT NULL CHECK (ir_revision_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  manifest_artifact_id uuid NOT NULL REFERENCES artifact.artifact(artifact_id),
  source_map_complete boolean NOT NULL,
  open_world_boundary_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, repository_snapshot_id, ir_revision_sha256)
);

CREATE TABLE semantic.ir_shard (
  ir_shard_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  repository_ir_id uuid NOT NULL REFERENCES semantic.repository_ir(repository_ir_id),
  shard_key text NOT NULL,
  shard_kind text NOT NULL,
  shard_sha256 text NOT NULL CHECK (shard_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  artifact_id uuid NOT NULL REFERENCES artifact.artifact(artifact_id),
  dependency_fingerprint text NOT NULL,
  coverage numeric(8,7) CHECK (coverage BETWEEN 0 AND 1),
  UNIQUE (tenant_id, repository_ir_id, shard_key)
);

CREATE TABLE verify.proof_obligation_graph (
  proof_graph_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  goal_id uuid NOT NULL REFERENCES core.goal(goal_id),
  revision_set_id uuid NOT NULL REFERENCES core.revision_set(revision_set_id),
  graph_revision_sha256 text NOT NULL CHECK (graph_revision_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, goal_id, graph_revision_sha256)
);

CREATE TABLE verify.proof_obligation (
  proof_obligation_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  proof_graph_id uuid NOT NULL REFERENCES verify.proof_obligation_graph(proof_graph_id),
  obligation_key text NOT NULL,
  family text NOT NULL,
  severity text NOT NULL CHECK (severity IN ('critical','high','medium','low')),
  subject jsonb NOT NULL,
  claim jsonb NOT NULL,
  assumptions jsonb NOT NULL DEFAULT '[]'::jsonb,
  required_assurance jsonb NOT NULL,
  status text NOT NULL CHECK (status IN ('PENDING','READY','RUNNING','BLOCKED','PROVED_CERTIFIED','PROVED_INDUCTIVE','PROVED_SOLVER_TRUSTED','PROVED_FOR_SUPPORTED_FRAGMENT','BOUNDED_NO_COUNTEREXAMPLE','REFUTED_WITH_COUNTEREXAMPLE','UNKNOWN_TIMEOUT','UNKNOWN_RESOURCE_LIMIT','UNSUPPORTED','ASSUMPTION_REQUIRED','RUNTIME_MONITORED','WAIVED_BY_APPROVER')),
  open_world boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, proof_graph_id, obligation_key)
);

CREATE TABLE verify.proof_obligation_edge (
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  proof_graph_id uuid NOT NULL REFERENCES verify.proof_obligation_graph(proof_graph_id),
  from_obligation_id uuid NOT NULL REFERENCES verify.proof_obligation(proof_obligation_id),
  to_obligation_id uuid NOT NULL REFERENCES verify.proof_obligation(proof_obligation_id),
  edge_kind text NOT NULL CHECK (edge_kind IN ('depends_on','refines','discharges_assumption','shares_evidence','invalidates')),
  PRIMARY KEY (tenant_id, proof_graph_id, from_obligation_id, to_obligation_id, edge_kind),
  CHECK (from_obligation_id <> to_obligation_id)
);

CREATE TABLE verify.proof_result (
  proof_result_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  proof_obligation_id uuid NOT NULL REFERENCES verify.proof_obligation(proof_obligation_id),
  subject_revision_sha256 text NOT NULL CHECK (subject_revision_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  status text NOT NULL CHECK (status IN ('PROVED_CERTIFIED','PROVED_INDUCTIVE','PROVED_SOLVER_TRUSTED','PROVED_FOR_SUPPORTED_FRAGMENT','BOUNDED_NO_COUNTEREXAMPLE','REFUTED_WITH_COUNTEREXAMPLE','UNKNOWN_TIMEOUT','UNKNOWN_RESOURCE_LIMIT','UNSUPPORTED','ASSUMPTION_REQUIRED','RUNTIME_MONITORED','WAIVED_BY_APPROVER')),
  scope text,
  assumptions jsonb NOT NULL DEFAULT '[]'::jsonb,
  tool_name text NOT NULL,
  tool_version text NOT NULL,
  tool_digest text NOT NULL,
  adapter_version text NOT NULL,
  encoder_digest text,
  environment_revision_sha256 text NOT NULL CHECK (environment_revision_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  resource_bounds jsonb NOT NULL,
  counterexample_artifact_id uuid REFERENCES artifact.artifact(artifact_id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE verify.evidence (
  evidence_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  subject_revision_sha256 text NOT NULL CHECK (subject_revision_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  evidence_kind text NOT NULL,
  artifact_id uuid NOT NULL REFERENCES artifact.artifact(artifact_id),
  producer_execution_id uuid NOT NULL,
  producer_source text NOT NULL,
  tool_digest text NOT NULL,
  lineage jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  revoked_at timestamptz,
  revocation_reason text,
  signature text
);

CREATE TABLE verify.proof_result_evidence (
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  proof_result_id uuid NOT NULL REFERENCES verify.proof_result(proof_result_id),
  evidence_id uuid NOT NULL REFERENCES verify.evidence(evidence_id),
  PRIMARY KEY (tenant_id, proof_result_id, evidence_id)
);

CREATE TABLE verify.gate_evaluation (
  gate_evaluation_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  goal_id uuid NOT NULL REFERENCES core.goal(goal_id),
  run_id uuid NOT NULL REFERENCES exec.run(run_id),
  revision_set_id uuid NOT NULL REFERENCES core.revision_set(revision_set_id),
  gate_name text NOT NULL CHECK (gate_name IN ('P05','E0','E1','E2','E3','E4','E5')),
  decision text NOT NULL CHECK (decision IN ('PASS','FAIL','BLOCKED','NOT_APPLICABLE')),
  policy_sha256 text NOT NULL CHECK (policy_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  evidence_root_sha256 text,
  evaluated_by_execution_id uuid NOT NULL,
  evaluated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, run_id, gate_name, policy_sha256)
);

CREATE TABLE verify.completion_certificate (
  certificate_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  goal_id uuid NOT NULL REFERENCES core.goal(goal_id),
  run_id uuid NOT NULL REFERENCES exec.run(run_id),
  revision_set_id uuid NOT NULL REFERENCES core.revision_set(revision_set_id),
  certified_envelope jsonb NOT NULL,
  gate_results jsonb NOT NULL,
  proof_summary jsonb NOT NULL,
  evidence_root_sha256 text NOT NULL CHECK (evidence_root_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  signer_identity text NOT NULL,
  signer_key_id text NOT NULL,
  signer_independent boolean NOT NULL CHECK (signer_independent),
  status text NOT NULL CHECK (status IN ('CERTIFIED','VERIFIED_COMPLETE','BLOCKED','FAILED_ASSURANCE','EXPIRED','REVOKED')),
  issued_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  revoked_at timestamptz,
  signature text NOT NULL,
  UNIQUE (tenant_id, goal_id, revision_set_id, evidence_root_sha256)
);

CREATE INDEX idx_po_ready ON verify.proof_obligation(tenant_id, status, severity);
CREATE INDEX idx_proof_result_obligation ON verify.proof_result(tenant_id, proof_obligation_id, created_at DESC);
CREATE INDEX idx_evidence_subject ON verify.evidence(tenant_id, subject_revision_sha256, created_at DESC);
CREATE INDEX idx_ir_shard_dependency ON semantic.ir_shard(tenant_id, dependency_fingerprint);

COMMIT;
