BEGIN;

CREATE OR REPLACE FUNCTION core.current_tenant_id()
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  SELECT nullif(current_setting('app.tenant_id', true), '')::uuid
$$;

DO $$
DECLARE
  t regclass;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'core.project'::regclass,
    'core.goal'::regclass,
    'core.revision_set'::regclass,
    'exec.run'::regclass,
    'exec.execution_epoch'::regclass,
    'exec.environment_authority'::regclass,
    'exec.task'::regclass,
    'exec.task_lease'::regclass,
    'exec.task_attempt'::regclass,
    'exec.event_journal'::regclass,
    'exec.checkpoint'::regclass,
    'artifact.artifact'::regclass,
    'analysis.repository_snapshot'::regclass,
    'analysis.evidence_graph'::regclass,
    'semantic.repository_ir'::regclass,
    'semantic.ir_shard'::regclass,
    'verify.proof_obligation_graph'::regclass,
    'verify.proof_obligation'::regclass,
    'verify.proof_obligation_edge'::regclass,
    'verify.proof_result'::regclass,
    'verify.evidence'::regclass,
    'verify.proof_result_evidence'::regclass,
    'verify.gate_evaluation'::regclass,
    'verify.completion_certificate'::regclass,
    'integration.external_side_effect'::regclass,
    'integration.outbox'::regclass,
    'metering.credit_account'::regclass,
    'metering.credit_reservation'::regclass,
    'metering.usage_event'::regclass,
    'metering.eta_projection'::regclass
  ]
  LOOP
    EXECUTE format('ALTER TABLE %s ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %s FORCE ROW LEVEL SECURITY', t);
    EXECUTE format(
      'CREATE POLICY tenant_isolation ON %s USING (tenant_id = core.current_tenant_id()) WITH CHECK (tenant_id = core.current_tenant_id())',
      t
    );
  END LOOP;
END $$;

CREATE OR REPLACE FUNCTION audit.reject_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'append-only table % cannot be updated or deleted', TG_TABLE_NAME;
END;
$$;

CREATE TRIGGER evidence_append_only
BEFORE UPDATE OR DELETE ON verify.evidence
FOR EACH ROW EXECUTE FUNCTION audit.reject_mutation();

CREATE TRIGGER proof_result_append_only
BEFORE UPDATE OR DELETE ON verify.proof_result
FOR EACH ROW EXECUTE FUNCTION audit.reject_mutation();

CREATE TRIGGER usage_event_append_only
BEFORE UPDATE OR DELETE ON metering.usage_event
FOR EACH ROW EXECUTE FUNCTION audit.reject_mutation();

CREATE TRIGGER event_journal_append_only
BEFORE UPDATE OR DELETE ON exec.event_journal
FOR EACH ROW EXECUTE FUNCTION audit.reject_mutation();

CREATE OR REPLACE FUNCTION exec.assert_current_fencing(
  p_task_id uuid,
  p_lease_generation bigint,
  p_fencing_token uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = exec, pg_temp
AS $$
DECLARE
  current_lease exec.task_lease%ROWTYPE;
BEGIN
  SELECT * INTO current_lease
  FROM exec.task_lease
  WHERE task_id = p_task_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'task lease missing';
  END IF;

  IF current_lease.lease_generation <> p_lease_generation
     OR current_lease.fencing_token <> p_fencing_token
     OR current_lease.expires_at <= now() THEN
    RAISE EXCEPTION 'stale or expired fencing';
  END IF;
END;
$$;

CREATE VIEW verify.v_goal_assurance AS
SELECT
  g.tenant_id,
  g.goal_id,
  g.state,
  count(po.proof_obligation_id) AS obligation_total,
  count(*) FILTER (WHERE po.severity = 'critical') AS critical_total,
  count(*) FILTER (
    WHERE po.severity = 'critical'
      AND po.status IN ('PROVED_CERTIFIED','PROVED_INDUCTIVE','PROVED_SOLVER_TRUSTED','PROVED_FOR_SUPPORTED_FRAGMENT')
  ) AS critical_closed,
  count(*) FILTER (
    WHERE po.status IN ('REFUTED_WITH_COUNTEREXAMPLE','UNKNOWN_TIMEOUT','UNKNOWN_RESOURCE_LIMIT','UNSUPPORTED','ASSUMPTION_REQUIRED')
  ) AS blocking_total
FROM core.goal g
LEFT JOIN verify.proof_obligation_graph pog ON pog.goal_id = g.goal_id AND pog.tenant_id = g.tenant_id
LEFT JOIN verify.proof_obligation po ON po.proof_graph_id = pog.proof_graph_id AND po.tenant_id = g.tenant_id
GROUP BY g.tenant_id, g.goal_id, g.state;

CREATE VIEW metering.v_run_cost AS
SELECT
  tenant_id,
  run_id,
  sum(total_cost) AS posted_cost,
  max(currency) AS currency,
  sum(quantity) FILTER (WHERE unit = 'machine_second') AS machine_seconds
FROM metering.usage_event
GROUP BY tenant_id, run_id;

COMMIT;
