BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE SCHEMA IF NOT EXISTS core;
CREATE SCHEMA IF NOT EXISTS exec;
CREATE SCHEMA IF NOT EXISTS analysis;
CREATE SCHEMA IF NOT EXISTS semantic;
CREATE SCHEMA IF NOT EXISTS transform;
CREATE SCHEMA IF NOT EXISTS verify;
CREATE SCHEMA IF NOT EXISTS artifact;
CREATE SCHEMA IF NOT EXISTS integration;
CREATE SCHEMA IF NOT EXISTS metering;
CREATE SCHEMA IF NOT EXISTS learning;
CREATE SCHEMA IF NOT EXISTS ops;
CREATE SCHEMA IF NOT EXISTS audit;

CREATE TABLE core.tenant (
  tenant_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_key text NOT NULL UNIQUE,
  display_name text NOT NULL,
  status text NOT NULL CHECK (status IN ('ACTIVE','SUSPENDED','DELETING')),
  data_region text NOT NULL DEFAULT 'default',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE core.project (
  project_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  project_key text NOT NULL,
  name text NOT NULL,
  risk_class text NOT NULL CHECK (risk_class IN ('critical','high','medium','low')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, project_key)
);

CREATE TABLE core.goal (
  goal_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  project_id uuid NOT NULL REFERENCES core.project(project_id),
  goal_key text NOT NULL,
  objective text NOT NULL,
  state text NOT NULL CHECK (state IN ('DRAFT','FROZEN','ACTIVE','PAUSED','BLOCKED','FAILED','CANCELLED','VERIFIED_COMPLETE')),
  risk_class text NOT NULL CHECK (risk_class IN ('critical','high','medium','low')),
  current_revision_set_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, goal_key)
);

CREATE TABLE core.revision_set (
  revision_set_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  goal_id uuid NOT NULL REFERENCES core.goal(goal_id),
  source_repository_sha256 text NOT NULL CHECK (source_repository_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  baseline_repository_sha256 text NOT NULL CHECK (baseline_repository_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  requirements_sha256 text NOT NULL CHECK (requirements_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  policy_sha256 text NOT NULL CHECK (policy_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  workflow_sha256 text NOT NULL CHECK (workflow_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  model_route_sha256 text NOT NULL CHECK (model_route_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  toolchain_sha256 text NOT NULL CHECK (toolchain_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  environment_sha256 text NOT NULL CHECK (environment_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  domain_pack_sha256 text NOT NULL CHECK (domain_pack_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  input_bundle_sha256 text,
  supersedes_revision_set_id uuid REFERENCES core.revision_set(revision_set_id),
  frozen_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, goal_id, revision_set_id)
);

ALTER TABLE core.goal
  ADD CONSTRAINT fk_goal_current_revision_set
  FOREIGN KEY (current_revision_set_id) REFERENCES core.revision_set(revision_set_id);

CREATE TABLE exec.run (
  run_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  goal_id uuid NOT NULL REFERENCES core.goal(goal_id),
  revision_set_id uuid NOT NULL REFERENCES core.revision_set(revision_set_id),
  run_number integer NOT NULL,
  state text NOT NULL CHECK (state IN ('CREATED','ADMITTED','PLANNING','EXECUTING','CHECKPOINTED','PAUSED','RESUMING','VERIFYING','CERTIFYING','COMPLETED','BLOCKED','FAILED','CANCELLED','PARTIAL')),
  machine_eta_seconds bigint,
  admitted_at timestamptz,
  terminal_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, goal_id, run_number)
);

CREATE TABLE exec.execution_epoch (
  execution_epoch_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  run_id uuid NOT NULL REFERENCES exec.run(run_id),
  epoch_number integer NOT NULL CHECK (epoch_number > 0),
  root_execution_id uuid NOT NULL,
  state text NOT NULL CHECK (state IN ('ACTIVE','PAUSED','SUPERSEDED','TERMINAL')),
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  UNIQUE (tenant_id, run_id, epoch_number)
);

CREATE TABLE exec.environment_authority (
  authority_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  run_id uuid NOT NULL REFERENCES exec.run(run_id),
  execution_epoch_id uuid NOT NULL REFERENCES exec.execution_epoch(execution_epoch_id),
  environment_id uuid NOT NULL,
  attachment_id uuid,
  execution_source text NOT NULL CHECK (execution_source IN ('USER','ROOT_AGENT','SUBAGENT','PLANNER','TRANSFORMER','REVIEWER','ADVERSARY','VERIFIER','CERTIFIER','SYSTEM_INTERNAL','REPLAY','RECOVERY','OPERATOR')),
  authority_revision_sha256 text NOT NULL CHECK (authority_revision_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  capability_set jsonb NOT NULL,
  sandbox_profile jsonb NOT NULL,
  network_profile jsonb NOT NULL,
  secret_lease_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
  policy_bundle_sha256 text NOT NULL CHECK (policy_bundle_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  fencing_generation bigint NOT NULL CHECK (fencing_generation > 0),
  valid_from timestamptz NOT NULL,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  CHECK (expires_at > valid_from)
);

CREATE TABLE exec.task (
  task_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  run_id uuid NOT NULL REFERENCES exec.run(run_id),
  execution_epoch_id uuid NOT NULL REFERENCES exec.execution_epoch(execution_epoch_id),
  workflow_node_id text NOT NULL,
  owner_skill text NOT NULL,
  state text NOT NULL CHECK (state IN ('PENDING','READY','CLAIMED','RUNNING','WAITING','SUCCEEDED','BLOCKED','FAILED','CANCELLED')),
  input_revision_sha256 text NOT NULL CHECK (input_revision_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  max_attempts integer NOT NULL DEFAULT 3 CHECK (max_attempts > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, run_id, workflow_node_id, input_revision_sha256)
);

CREATE TABLE exec.task_lease (
  task_id uuid PRIMARY KEY REFERENCES exec.task(task_id),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  owner_worker_id text NOT NULL,
  lease_generation bigint NOT NULL CHECK (lease_generation > 0),
  fencing_token uuid NOT NULL DEFAULT gen_random_uuid(),
  claimed_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  heartbeat_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE exec.task_attempt (
  attempt_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  task_id uuid NOT NULL REFERENCES exec.task(task_id),
  lease_generation bigint NOT NULL,
  fencing_token uuid NOT NULL,
  authority_id uuid NOT NULL REFERENCES exec.environment_authority(authority_id),
  state text NOT NULL CHECK (state IN ('STARTED','SUCCEEDED','BLOCKED','FAILED','CANCELLED','UNKNOWN_RESULT')),
  idempotency_key text NOT NULL,
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  result_artifact_id uuid,
  UNIQUE (tenant_id, task_id, idempotency_key)
);

CREATE TABLE exec.event_journal (
  event_seq bigserial PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  run_id uuid NOT NULL REFERENCES exec.run(run_id),
  execution_epoch_id uuid REFERENCES exec.execution_epoch(execution_epoch_id),
  event_id uuid NOT NULL DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  aggregate_type text NOT NULL,
  aggregate_id uuid NOT NULL,
  causation_id uuid,
  correlation_id uuid,
  payload jsonb NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, event_id)
);

CREATE TABLE integration.outbox (
  outbox_id bigserial PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  run_id uuid REFERENCES exec.run(run_id),
  topic text NOT NULL,
  message_key text NOT NULL,
  payload jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz,
  publish_attempts integer NOT NULL DEFAULT 0
);

CREATE TABLE exec.checkpoint (
  checkpoint_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES core.tenant(tenant_id),
  run_id uuid NOT NULL REFERENCES exec.run(run_id),
  execution_epoch_id uuid NOT NULL REFERENCES exec.execution_epoch(execution_epoch_id),
  event_seq bigint NOT NULL REFERENCES exec.event_journal(event_seq),
  manifest_sha256 text NOT NULL CHECK (manifest_sha256 ~ '^sha256:[0-9a-f]{64}$'),
  sealed boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_run_tenant_state ON exec.run(tenant_id, state);
CREATE INDEX idx_task_ready ON exec.task(tenant_id, state, created_at);
CREATE INDEX idx_event_run_seq ON exec.event_journal(tenant_id, run_id, event_seq);
CREATE INDEX idx_outbox_unpublished ON integration.outbox(created_at) WHERE published_at IS NULL;

COMMIT;
