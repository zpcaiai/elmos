# Observability

Dashboards are outcome-first:
- proof closure and blockers;
- semantic coverage/gaps;
- runtime authority/recovery/side effects;
- cost, machine ETA and cache;
- certificate and Golden Route status.

Raw token/tool activity is diagnostic, not a success metric.
