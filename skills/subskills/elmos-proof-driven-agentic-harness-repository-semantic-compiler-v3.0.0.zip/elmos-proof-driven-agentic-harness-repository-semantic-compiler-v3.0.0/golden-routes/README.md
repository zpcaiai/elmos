# Commercial Golden Routes

Each route is a durable, proof-obligation-driven workflow. A route is certified only on exact revisions and target-environment evidence. Fixture success is not customer certification.

Routes:
- Spring legacy modernization
- Cross-language conversion
- Multi-language project generation
- SQL dialect/routine conversion
- Repository-scale refactoring
