# Contributing

Every change must declare:
1. owning kernel/Domain Pack;
2. canonical objects and revisions changed;
3. proof obligations and evidence;
4. tenant/security/authority impact;
5. cost/ETA impact;
6. migration/rollback;
7. tests, negative cases and release gate.

Run `make all` before submission. Do not mark package consistency as customer certification.
