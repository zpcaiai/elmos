# Validation Report

**Package:** `elmos-proof-driven-agentic-harness-repository-semantic-compiler-v3.0.0`  
**Status:** **PASS WITH RELEASE-TIME PINS REQUIRED**

## Executed checks

| Check | Result |
|---|---|
| Package/YAML/JSON/skill/dependency/count validation | PASS |
| JSON Schema Draft 2020-12 meta-validation | PASS — 15 schemas, 3 examples |
| V3 registry consistency | PASS — 16 routable skills, no dependency cycle |
| Legacy consolidation | PASS — 115/115 mapped, 0 old skills independently routable |
| Reference kernel tests | PASS — 21/21 |
| Reference service smoke | PASS — `/livez`, `/readyz`, `/metrics`, `/version` |
| Inherited ETGB tests | PASS — 26/26 across all 14 modules |
| Python compile and shell syntax | PASS |

The inherited ETGB monolithic pytest command exceeded the command execution window; it is not counted as evidence. Every collected test was then executed by its module, including the corrected nested ETGB skill metadata test, and all 26 passed.

## Package metrics

| Item | Count |
|---|---:|
| Routable v3 skills | 16 |
| Per-skill contract files | 80 |
| Internal kernel components | 96 |
| Legacy mappings / snapshots | 115 / 115 |
| JSON Schemas | 15 |
| Language / framework profiles | 15 / 9 |
| Verifier / Harness adapters | 20 / 7 |
| Golden Routes | 5 |
| ETGB cases | 46,664 |
| Current package files | 986 |
| Current unpacked bytes | 94,560,623 |

## Expected release-time warnings

The package intentionally refuses to invent production digests. Exact signed image, migration-image, compiler, verifier and adapter digests must replace release placeholders after SBOM, vulnerability, signature, provenance and conformance checks.

## Not executed in this environment

- live PostgreSQL 17 migrations/RLS/recovery;
- OPA;
- image build/signing and Kubernetes;
- external compiler/verifier/model/Harness conformance;
- large-repository and customer E5 certification.

Package consistency is not equivalent to `PROD`, `VERIFIED_COMPLETE` or `CERTIFIED`.
