# Deployment

The included image serves the executable reference kernel and health endpoints. Production Elmos uses separate control-plane and execution-plane services; this skeleton validates packaging, probes, non-root/read-only execution and release-manifest binding.

Before release:
- pin every base/tool/support image by signed digest;
- build SBOM, scan, sign and attest;
- apply PostgreSQL migrations and RLS negative tests;
- run OPA tests;
- validate Kubernetes server-side and NetworkPolicy behavior;
- run kill/resume, fencing, side-effect reconciliation and backup/restore;
- pass P05.
