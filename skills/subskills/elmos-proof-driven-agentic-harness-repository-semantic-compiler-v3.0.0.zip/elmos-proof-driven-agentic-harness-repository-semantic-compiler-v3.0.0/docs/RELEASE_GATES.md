# Release Gates

## P05 — Deployment Complete

Required:
- exact release manifest and signed image/tool digests;
- SBOM, vulnerability/license policy, signatures and provenance;
- PostgreSQL migrations on clean install and upgrade path;
- RLS/tenant isolation and append-only evidence tests;
- policy bundle compile/tests and fail-closed behavior;
- `/livez`, `/readyz`, `/metrics`, `/version`;
- backup, restore and point-in-time recovery;
- lease/fencing, kill/resume, checkpoint and side-effect reconciliation;
- network/secret/sandbox enforcement;
- capacity, SLO, alert and incident runbooks.

## E0 — Frozen Contract

Goal, acceptance, observable behavior, assumptions, exclusions, risk, certified envelope and exact Revision Set are immutable for this run.

## E1 — Static/Semantic

Build and compiler frontends run; required symbol/type/dataflow/framework coverage is met; critical semantic gaps are closed or explicitly blocked.

## E2 — Formal Model

Required proof/model/symbolic obligations have accepted statuses under pinned tools, encoders, bounds, assumptions and TCB. `UNKNOWN_*` cannot pass critical gates.

## E3 — Differential Behavior

Contracts, properties, metamorphic relations, fixtures, source/target traces, data/state/event reconciliation and hidden holdout satisfy route thresholds.

## E4 — Resilience/Security/Performance

Tenant isolation, auth, supply chain, failure injection, recovery, concurrency, load, latency, resources, observability and rollback pass.

## E5 — Customer Golden Route

Representative real repository, independent holdout, customer acceptance, cutover/rollback rehearsal, unresolved-risk acceptance and signed evidence bundle pass.

## Gate invalidation

Any change to a bound revision, assumption, tool/encoder digest, policy, environment, oracle, subject code, evidence freshness or external dependency contract invalidates dependent gate decisions.
