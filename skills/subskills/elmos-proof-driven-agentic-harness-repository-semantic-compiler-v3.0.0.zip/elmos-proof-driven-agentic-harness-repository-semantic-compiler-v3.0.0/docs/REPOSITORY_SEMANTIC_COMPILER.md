# Repository Semantic Compiler

## Purpose

The semantic compiler converts heterogeneous repositories into an executable, source-linked semantic representation suitable for transformation, relational comparison, proof generation and impact analysis.

## Multi-layer representation

```text
bytes / files / build graph
  → lossless concrete syntax
  → compiler-native AST/HIR/MIR/SIL/semantic model
  → symbol + type + generic/trait/protocol graph
  → CFG + SSA + dataflow + alias/points-to
  → effects + exceptions + resources + ownership
  → concurrency + async + memory model
  → API/protocol/state-machine model
  → data/schema/query/transaction model
  → framework/runtime/deployment model
  → Repository Semantic IR
```

Each node preserves `source_span`, `origin`, `symbol_identity`, `profile_version`, `confidence`, `evidence_refs` and `invalidation_dependencies`.

## Frontend policy

- Use the language's official or compiler-grade semantic frontend where available.
- Use a lossless syntax layer for comments, formatting, recipes and error recovery.
- Generic parsers may index unsupported code, but cannot issue a `semantic_authoritative=true` result.
- Dynamic languages combine static approximation with runtime evidence and explicit open-world boundaries.
- Generated code, macros, annotation processors and plugins must record expansion provenance.

## Language profiles

The included profile registry covers Java, Kotlin, C#, TypeScript, JavaScript, Python, Rust, Go, C, C++, Objective-C, Swift, Dart, PHP and SQL. Each profile declares:

- syntax/semantic frontend;
- type/nullability and numeric rules;
- exceptions/effects/resources;
- concurrency and memory model;
- dynamic/reflection/FFI boundaries;
- serialization, time, Unicode and platform semantics;
- supported proof encodings;
- degradation/unsupported policy.

## Core IR domains

| Domain | Representative nodes |
|---|---|
| Declaration/type | module, namespace, class, trait, generic, variance, nullability |
| Value/computation | literals, operations, conversion, allocation, ownership |
| Control/data | blocks, CFG edges, phi nodes, def-use, alias/effect summaries |
| Failure/resource | exceptions, result types, cleanup, transaction/lock/resource scope |
| Concurrency | task/thread/actor, synchronization, happens-before, cancellation |
| Protocol | endpoint, message, state machine, temporal constraint |
| Data | schema, relation, query algebra, routine CFG/SSA, trigger, transaction |
| Framework | routing, binding, DI, middleware, security, ORM, lifecycle |
| Deployment | process, service, environment, secret, network, health, scaling |

## Semantic gap generation

Profile comparison generates obligations for semantic mismatches. No default conversion is allowed for a gap with material behavioral impact. Examples:

- Java signed overflow vs target checked arithmetic;
- JavaScript `undefined`/coercion vs static target types;
- Python arbitrary integers vs fixed-width integers;
- C/C++ undefined behavior vs defined target semantics;
- async cancellation and exception aggregation;
- GC finalization vs deterministic resource ownership;
- Unicode normalization/collation/regex differences;
- decimal, floating, timestamp and timezone behavior;
- SQL bag/order/NULL/three-valued logic;
- reflection, dynamic loading, native ABI and external protocol behavior.

## Executable semantics

The reference contract supports:

- interpreter/reference evaluator for supported IR fragments;
- relation generation for source/target product programs;
- SMT/Boogie/Dafny/Lean/TLA+ encodings through versioned adapters;
- runtime trace instrumentation and canonical observation normalization;
- source-to-IR-to-source mapping for counterexamples and repairs.

## Scaling

IR is content-addressed and sharded by build target/module/symbol cone. Incremental invalidation uses dependency fingerprints rather than full re-analysis. Large-repository certification records completeness metrics per shard and blocks critical obligations when required semantic coverage is absent.
