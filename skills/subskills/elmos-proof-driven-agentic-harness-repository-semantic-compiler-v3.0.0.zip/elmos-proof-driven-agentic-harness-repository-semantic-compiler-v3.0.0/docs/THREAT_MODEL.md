# Threat Model and Safety Invariants

## Assets

Repository source, customer secrets, credentials, models, tool authority, semantic/proof artifacts, evidence, billing credit, certificates and deployment systems.

## Principal threats

- prompt/repository injection causing unauthorized tools or data exfiltration;
- cross-tenant reads/writes/cache reuse;
- stale worker or replay committing after ownership loss;
- model self-certification or fabricated evidence;
- malicious/compromised compiler, solver, adapter or dependency;
- ambiguous external side effect repeated on recovery;
- poisoned fixtures/holdout leakage/reward hacking;
- path traversal, symlink escape, network pivot, secret persistence;
- status inflation from bounded/unknown/waived results;
- evidence substitution across revisions.

## Required controls

- deny-by-default capability and parameter policy;
- Environment-owned authority with short-lived credentials;
- secretless execution and network egress policy;
- RLS, encryption and tenant-keyed cache;
- lease generation and fencing;
- immutable content hashes and signed evidence root;
- independent Certifier and model-oracle prohibition;
- TCB registry, SBOM, signatures and provenance;
- hidden holdout isolation and corpus governance;
- external-side-effect idempotency/reconciliation;
- certificate expiry, revocation and drift invalidation.

See `policy/rego/` and `database/migrations/`.
