# Commercial Production Capability Model

## Product outcomes

Elmos v3 is designed to sell outcomes rather than token throughput:

1. certified Spring legacy modernization;
2. repository-scale cross-language conversion;
3. complete multi-language project generation;
4. SQL dialect/routine conversion;
5. repository-scale refactoring and dependency/architecture modernization.

Each outcome includes code, tests, architecture and operational artifacts, evidence bundle, unresolved-risk ledger, rollback/cutover plan and certificate status.

## Enterprise controls

- multi-tenant PostgreSQL RLS and tenant-scoped encryption;
- enterprise SSO/OIDC/SAML integration boundary;
- customer-VPC/private runner and air-gapped profile;
- data residency, retention, legal hold and deletion policy;
- approval workflows and four-eyes control;
- audit export, SBOM, provenance and signed artifacts;
- model/provider allow-list and no-training/no-retention policy metadata;
- per-project budget, credit reservation, cost attribution and revenue ledger;
- SLO, incident, support bundle, backup/restore and disaster recovery.

## Productivity mechanisms

| Mechanism | Benefit |
|---|---|
| Incremental Repository Evidence Graph | avoids repeatedly reading the whole repository |
| Content-addressed semantic/proof cache | reuses valid analysis without stale evidence |
| Deterministic-first recipes | lower cost and higher repeatability |
| Proof-obligation scheduling | spends compute on closure, not aimless iteration |
| Counterexample-guided repair | converts failures into localized, testable work |
| Model portfolio routing | uses strong models where reasoning value is highest |
| Parallel worktrees + semantic merge | safe fanout without uncontrolled conflicts |
| Hidden ETGB and Repository Gym | prevents overfitting and status inflation |
| Independent certification | trusted handoff to customer and operators |
| Machine ETA/FinOps | predictable project economics |

## Commercial service tiers

| Tier | Assurance |
|---|---|
| Explore | read-only intelligence, plan, risk and cost/ETA; no completion claim |
| Transform | candidate revision + tests; bounded verification |
| Verified | required E0–E4 obligations closed within declared envelope |
| Certified Golden Route | E0–E5 + P05, independent holdout, rollback/cutover and signed evidence |
| Enterprise Private | customer VPC/air gap, private models/tools, custom TCB and compliance pack |

## Metrics that matter

- critical Proof Obligation closure rate;
- verified completion rate, not agent-reported completion;
- first-pass compile and test rate;
- semantic-gap escape rate;
- post-certification defect/rollback rate;
- time/cost to verified closure;
- ETA MAPE;
- deterministic transformation ratio;
- customer acceptance pass rate;
- evidence reproducibility and stale-evidence rejection;
- model route regret and verifier disagreement;
- gross margin per Golden Route.

## Anti-metrics

The product must not optimize for generated LOC, number of agents, number of tests, token consumption, raw tool calls or LLM self-score without demonstrated relationship to verified outcomes.
