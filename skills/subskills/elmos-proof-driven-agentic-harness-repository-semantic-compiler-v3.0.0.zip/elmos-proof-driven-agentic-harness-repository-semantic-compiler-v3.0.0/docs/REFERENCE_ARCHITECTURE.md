# V3 Reference Architecture

## Architectural objective

The v3 architecture maximizes repository-scale task success by separating four kinds of authority:

1. **Intent authority** — Goal/Spec objects determine what must be achieved.
2. **Semantic authority** — compiler frontends, profiles, runtime evidence and formal encodings determine what programs mean.
3. **Execution authority** — Environment-owned capability and durable workflow state determine what may run.
4. **Completion authority** — independent verification and certification determine whether the goal is achieved.

No model, worker, thread or UI component owns all four.

## End-to-end control flow

```mermaid
flowchart TD
  U[User / API / Product UI] --> K1[K1 Goal & Specification]
  K1 --> POG[Proof Obligation Graph]
  R[Immutable Repository Snapshot] --> K2[K2 Repository Intelligence]
  K2 --> K3[K3 Repository Semantic Compiler]
  K3 --> K4[K4 Agentic Reasoning]
  POG --> K4
  K4 --> K5[K5 Transformation]
  K5 --> CR[Candidate Revision]
  CR --> K6[K6 Proof & Verification]
  K6 -->|counterexample| K4
  K6 -->|evidence| K8[K8 Certification]
  K7[K7 Harness Runtime] -.durable execution, authority, cost.-> K1
  K7 -.-> K2
  K7 -.-> K3
  K7 -.-> K4
  K7 -.-> K5
  K7 -.-> K6
  K7 -.-> K8
  K8 --> C[Completion Certificate / Blocked Result]
```

## Control-plane / execution-plane / data-plane

| Plane | Services |
|---|---|
| Control plane | Goal API, Workflow Compiler, Scheduler, Policy, Approval, Model Router, Skill Registry, Certifier |
| Execution plane | Workspace/Sandbox Manager, compiler workers, transformation workers, verifier workers, UI/runtime differential workers |
| Data plane | PostgreSQL 17 + RLS, CAS/object store, event bus, cache, evidence WORM store, OTel backend, secret broker |
| Enterprise edge | customer VPC runner, Git provider adapter, artifact mirror, identity/SSO, private model/verifier endpoints |

The control plane never grants ambient filesystem/network/secret access. Each execution attempt receives a short-lived authority snapshot and fencing generation.

## Canonical object graph

```text
Tenant
 └─ Project
     └─ Goal
         ├─ RevisionSet
         ├─ RequirementGraph
         ├─ ObservableContract
         ├─ AssumptionLedger
         ├─ WorkflowIR
         ├─ RepositorySnapshot
         │   └─ RepositoryEvidenceGraph
         │       └─ RepositorySemanticIR
         ├─ ProofObligationGraph
         └─ Run
             ├─ ExecutionEpoch
             ├─ EnvironmentAuthority
             ├─ Workspace/Session/Turn/ToolRequest
             ├─ ChangeGraph/CandidateRevision
             ├─ ProofResult/Evidence
             └─ GateEvaluation/CompletionCertificate
```

## Kernel specifications

## K1 — Goal / Specification Kernel

**Mission.** 把自然语言目标、存量规范、约束、预算和验收标准编译为版本化、可执行、可证明的 Goal Contract、Observable Contract、Requirement Graph 与 Revision Set。

**Responsibilities**

- Goal 与聊天线程解耦并持久化；支持暂停、恢复、取消、分叉、重规划与机器 wall-clock ETA。
- 建立 immutable Revision Set，固定 source/baseline/requirements/policy/workflow/model/toolchain/environment/domain-pack 版本。
- 从文档、代码、测试、流量、工单和数据库行为恢复显式及隐式需求。
- 把需求分解为可观察行为、数据不变量、安全属性、活性属性、资源预算和非功能目标。
- 生成 Spec Delta、Assumption Ledger、Acceptance Scenarios 与初始 Proof Obligation Graph。
- 对需求冲突、不完整、不可判定或超出认证包络的目标 fail-closed。

**Internal components**

`GoalAggregate`, `GoalCommandService`, `RevisionSetRegistry`, `RequirementGraphCompiler`, `ObservableContractCompiler`, `SpecDeltaCompiler`, `AssumptionLedger`, `AcceptanceScenarioCompiler`, `BudgetAndEtaContract`, `GoalRiskClassifier`, `GoalCheckpointProjection`, `GoalChangeImpactAnalyzer`

**Inputs:** 用户目标和验收偏好; 不可变仓库快照; 现有需求/架构/API/数据文档; 预算、SLA、风险和合规策略.  
**Outputs:** Goal Contract; Revision Set; Requirement Graph; Observable Behavior Contract; Spec Delta; Assumption Ledger; Acceptance Scenario Set; initial Proof Obligation Graph.

**Hard gates:** `goal_schema_valid`, `revision_set_complete`, `critical_requirement_conflicts_zero`, `observable_contract_approved_or_policy_accepted`, `proof_obligations_initialized`.  
**KPIs:** `goal_to_spec_lead_time`, `requirement_coverage`, `assumption_escape_rate`, `acceptance_ambiguity_rate`, `eta_mape`.

**Ownership rule.** This kernel is the single writer/authority for its canonical objects. Other kernels can reference immutable artifacts or issue commands but cannot maintain a shadow copy of truth.

## K2 — Repository Intelligence Kernel

**Mission.** 以只读、增量、证据优先方式重建仓库的结构、依赖、运行行为、数据、协议、安全与业务能力图谱，为推理和变换提供可查询事实层。

**Responsibilities**

- 构建 file/module/build/symbol/type/call/data/control/effect/config/runtime/deployment 图。
- 关联代码、测试、API、SQL、消息、配置、日志、trace、UI 和外部服务形成 Repository Evidence Graph。
- 识别 dead code、dynamic boundary、reflection/FFI、生成代码、宏、插件、条件编译和运行时发现机制。
- 执行源代码与构建环境指纹、许可证、供应链、密钥、漏洞和所有权分析。
- 支持增量 invalidation、shard、内容寻址缓存与百万文件规模。
- 所有推断保存 provenance、confidence、counterevidence 和 freshness。

**Internal components**

`RepositorySnapshotter`, `BuildSystemDetector`, `SymbolGraphBuilder`, `TypeGraphBuilder`, `CallAndDataFlowGraphBuilder`, `ConfigurationGraphBuilder`, `DataAndMessageGraphBuilder`, `RuntimeTraceIngestor`, `CapabilityLedger`, `DynamicBoundaryDetector`, `RepositoryRiskMap`, `IncrementalInvalidationEngine`

**Inputs:** immutable repository snapshot; Environment IR; build metadata; optional runtime traces/traffic/logs.  
**Outputs:** Repository Evidence Graph; Capability Ledger; Impact Graph; Dynamic Boundary Register; Risk Map; Baseline Reproducibility Record.

**Hard gates:** `snapshot_integrity`, `baseline_build_classified`, `critical_graph_completeness`, `dynamic_boundaries_declared`, `evidence_provenance_complete`.  
**KPIs:** `graph_coverage`, `symbol_resolution_rate`, `type_attribution_rate`, `dynamic_boundary_recall`, `incremental_reanalysis_ratio`.

**Ownership rule.** This kernel is the single writer/authority for its canonical objects. Other kernels can reference immutable artifacts or issue commands but cannot maintain a shadow copy of truth.

## K3 — Repository Semantic Compiler Kernel

**Mission.** 将多语言、多框架、多数据技术的具体程序编译为可执行、可比较、可证明的 Repository Semantic IR，并显式建模语义间隙。

**Responsibilities**

- 组合 compiler-native frontend、lossless syntax tree、framework model 与 runtime evidence；禁止仅靠文本或通用 AST 充当语义权威。
- 统一表示声明、类型、值、控制流、SSA、数据流、别名、effect、异常、资源、并发、协议、状态机、事务和外部交互。
- 保持 source map、comments、formatting、generated origin、symbol identity 与 provenance。
- 建立 Language Semantic Profile、Framework Semantic Profile、SQL Semantic Profile 和 Target Runtime Profile。
- 比较 source/target profiles，生成 null/overflow/Unicode/floating/time/concurrency/exception/ownership/FFI 等 Semantic Gap Obligations。
- 支持分片、增量编译、跨模块链接、open-world 假设和精确降级状态。

**Internal components**

`FrontendRegistry`, `LosslessSyntaxLayer`, `CompilerSemanticBridge`, `RepositoryLinker`, `TypeAndEffectIR`, `ControlDataSSA`, `ProtocolStateMachineIR`, `DataTransactionIR`, `FrameworkSemanticModel`, `SourceMapAndLineage`, `SemanticGapAnalyzer`, `ExecutableSemanticsRuntime`

**Inputs:** Repository Evidence Graph; language/framework/toolchain profiles; runtime evidence.  
**Outputs:** Repository Semantic IR; Semantic Profiles; Semantic Gap Register; source maps; open-world boundary contracts.

**Hard gates:** `frontend_conformance`, `critical_type_attribution`, `semantic_ir_schema_valid`, `source_map_complete`, `semantic_gap_obligations_emitted`.  
**KPIs:** `supported_construct_coverage`, `ir_round_trip_fidelity`, `semantic_profile_precision`, `gap_detection_recall`, `compiler_frontend_cache_hit_rate`.

**Ownership rule.** This kernel is the single writer/authority for its canonical objects. Other kernels can reference immutable artifacts or issue commands but cannot maintain a shadow copy of truth.

## K4 — Agentic Reasoning Kernel

**Mission.** 把大模型用于最有价值的认知工作：规范恢复、假设生成、规划、引理/不变量合成、反例解释和最小修复，同时禁止模型成为最终正确性 Oracle。

**Responsibilities**

- 按 phase、风险、语言、上下文和历史 verified task-fit 路由模型，而不是固定单模型。
- 将 planner、spec miner、semantic reasoner、proof planner、counterexample reasoner、repair synthesizer、reviewer、adversary、verifier 分离。
- 维护 prefix-stable context、provider-native state continuity、artifact-first communication 与 structured reasoning envelope。
- 允许受控 fanout、Agent Arena、多候选竞争、独立审查和停止条件。
- 把模型结论转成 hypothesis/spec/rule/test/proof request，必须由编译器、solver、runtime 或人工权威验证。
- 对 hallucinated evidence、self-certification、authority confusion、context drift 和 reward hacking fail-closed。

**Internal components**

`RoleSeparatedAgentRuntime`, `PhaseAwareModelRouter`, `ModelCapabilityRegistry`, `ContextPlanner`, `ArtifactMailbox`, `ProofPlanner`, `InvariantAndLemmaSynthesizer`, `CounterexampleReasoner`, `RepairSynthesizer`, `AdversarialReviewer`, `AgentArena`, `ReasoningProvenanceRecorder`

**Inputs:** Goal/Spec artifacts; Repository Semantic IR; Proof Obligation Graph; counterexamples and diagnostics.  
**Outputs:** transformation hypotheses; proof strategy; candidate invariants/lemmas/tests; repair plans; review findings; reasoning provenance.

**Hard gates:** `role_separation`, `no_llm_authoritative_oracle`, `model_budget_reserved`, `context_lineage_valid`, `review_independence_for_critical_changes`.  
**KPIs:** `verified_reasoning_yield`, `counterexample_to_fix_rate`, `false_completion_attempt_rate`, `model_route_regret`, `repair_cycles_to_closure`.

**Ownership rule.** This kernel is the single writer/authority for its canonical objects. Other kernels can reference immutable artifacts or issue commands but cannot maintain a shadow copy of truth.

## K5 — Transformation Kernel

**Mission.** 以 deterministic-first、semantic-rule-driven、bounded-generative 的方式执行仓库级生成、转换、现代化和重构，形成可回滚、可重放、可验证的 ChangeGraph。

**Responsibilities**

- 把 transformation plan 编译为依赖感知、可分片、可重试、可补偿的 ChangeGraph。
- 优先使用 compiler rewrite、codemod、recipe、schema migration 和模板生成；LLM 只处理规则选择、缺口和例外。
- 每个规则声明 precondition/postcondition/semantic preservation/evidence requirements/rollback。
- 使用隔离 worktree/workspace、patch lineage、semantic conflict detection 和 deterministic fixpoint。
- 支持 parallel units、merge queue、冲突重规划、partial commit、strangler/dual-run/canary/cutover。
- 任何变换都关联所影响的 Proof Obligations 和待执行 Validation DAG。

**Internal components**

`TransformationPlanner`, `RuleRegistry`, `RulePreservationContract`, `DeterministicRecipeEngine`, `BoundedGenerativeTransformer`, `ChangeGraph`, `WorktreeCoordinator`, `SemanticMergeEngine`, `FixpointController`, `DataMigrationPlanner`, `CutoverRollbackPlanner`, `TransformationCache`

**Inputs:** approved transformation plan; Repository Semantic IR; domain pack; proof obligations.  
**Outputs:** ChangeGraph; candidate repository revisions; patch lineage; rule evidence; rollback/cutover plan.

**Hard gates:** `rule_preconditions_met`, `change_lineage_complete`, `unresolved_semantic_conflicts_zero`, `deterministic_fixpoint_or_bounded_exception`, `candidate_revision_frozen`.  
**KPIs:** `deterministic_change_ratio`, `first_pass_compile_rate`, `semantic_conflict_rate`, `repair_edit_locality`, `rollback_readiness`.

**Ownership rule.** This kernel is the single writer/authority for its canonical objects. Other kernels can reference immutable artifacts or issue commands but cannot maintain a shadow copy of truth.

## K6 — Proof & Verification Kernel

**Mission.** 为每个 Proof Obligation 选择独立、组合式 verifier portfolio，运行静态、动态、差分、属性、形式化和非功能验证，并把反例反馈给修复闭环。

**Responsibilities**

- Proof Obligation Graph 是运行时一级对象；明确 subject、claim、assumptions、scope、dependencies、required assurance 和 accepted evidence classes。
- 执行 compiler/static analysis、contract/property/metamorphic/mutation/fuzz、differential runtime、symbolic execution、SMT、model checking、proof assistant、security/performance/resilience。
- 采用 translation validation：对每次具体转换验证，而非盲目信任生成器。
- 对 repository-level proof 使用 assume–guarantee、compositional refinement 与 open-world boundary monitoring。
- 所有 verifier 使用固定 tool digest、input hash、timeout/resource limit、trusted computing base 与可复现环境。
- 将 counterexample 最小化、归因并转为回归测试；UNKNOWN/UNSUPPORTED 不得被包装为通过。

**Internal components**

`ProofObligationGraph`, `VerifierPortfolioRouter`, `StaticVerificationPipeline`, `DifferentialExecutionEngine`, `PropertyMetamorphicFuzzEngine`, `SymbolicAndSMTEngine`, `ModelCheckingEngine`, `ProofAssistantBridge`, `NonFunctionalVerification`, `CounterexampleMinimizer`, `CounterexampleToTest`, `ProofCacheAndDriftInvalidator`

**Inputs:** candidate revision; proof obligations; source/target semantic IR; environment and oracle contracts.  
**Outputs:** Proof Results; counterexamples; regression tests; coverage map; assurance report.

**Hard gates:** `all_required_verifiers_executed_or_explicit_status`, `authoritative_oracles_independent`, `critical_refutations_zero`, `unknown_policy_applied`, `proof_evidence_immutable`.  
**KPIs:** `critical_obligation_closure_rate`, `counterexample_discovery_rate`, `mutation_score`, `differential_scenario_coverage`, `proof_reuse_validity`.

**Ownership rule.** This kernel is the single writer/authority for its canonical objects. Other kernels can reference immutable artifacts or issue commands but cannot maintain a shadow copy of truth.

## K7 — Harness Runtime Kernel

**Mission.** 提供长任务、多 Agent、多工作区、多模型、多工具的 durable execution substrate，把权限、运行状态、来源、策略和生命周期绑定到具体 Environment/Attachment。

**Responsibilities**

- 核心对象采用 Capability + RuntimeState + Provenance + Policy + Lifecycle，并保存 root/parent execution lineage。
- Thread/Turn 不是权限所有者；Environment、workspace、attachment 和 tool request 拥有明确 authority snapshot。
- 实现 durable workflow、event sourcing、checkpoint/replay/fork/time travel、pause/resume/cancel/recovery。
- 通过 lease generation、fencing token、idempotency key、transactional outbox 和 external side-effect reconciliation 防止双写和幽灵完成。
- Setup 与 Execution 两阶段隔离；执行默认 secretless、deny-network、least privilege、path/parameter-level policy。
- 提供 Harness SPI、MCP/A2A/tool gateway、provider adapter、workspace manager、scheduler、backpressure、cost/ETA ledger 和 OTel。

**Internal components**

`DurableWorkflowRuntime`, `EnvironmentAuthority`, `WorkspaceManager`, `SessionTimeline`, `ExecutionProvenance`, `ToolGateway`, `PolicyDecisionPoint`, `LeaseAndFencing`, `CheckpointReplayFork`, `SideEffectReconciler`, `HarnessAdapterSPI`, `SchedulerBackpressureFinOps`

**Inputs:** Workflow IR; environment authority; model/tool requests; artifacts/events.  
**Outputs:** durable execution journal; checkpoints; policy decisions; tool results; cost/ETA events; recovery decisions.

**Hard gates:** `authority_resolved`, `fencing_current`, `tenant_isolation`, `side_effect_state_known_or_blocked`, `checkpoint_recoverable`, `budget_not_overdrawn`.  
**KPIs:** `recovery_success_rate`, `stale_worker_rejection_rate`, `unreconciled_side_effect_rate`, `tool_policy_violation_rate`, `machine_eta_mape`, `cost_accounting_gap`.

**Ownership rule.** This kernel is the single writer/authority for its canonical objects. Other kernels can reference immutable artifacts or issue commands but cannot maintain a shadow copy of truth.

## K8 — Certification Kernel

**Mission.** 由独立于生成与修复 Agent 的 Certifier 对精确 Revision Set、Proof Obligation closure、E0–E5、部署证据和商业 Golden Route 证据签发不可伪造的 Completion Certificate。

**Responsibilities**

- 定义 canonical proof statuses，禁止把 bounded、unknown、runtime monitored 或 waiver 显示成 unbounded proof。
- 把 E0–E5、P05、domain gates、evidence freshness、revocation、coverage 和 side-effect settlement 组成 independent stop gate。
- 对 certificate 固定 exact revision set、policy bundle、toolchain digest、TCB、assumptions、waivers、evidence Merkle root 和 signer。
- 支持 certified envelope、assurance level、expiry、drift invalidation、re-certification、customer acceptance 和 audit export。
- 防止 Agent says done、测试数量膨胀、LLM judge、空证据、旧证据复用和 status inflation。
- 输出面向工程、管理、客户、合规和保险/审计场景的分层报告。

**Internal components**

`IndependentStopGate`, `ProofStatusPolicy`, `E0E5GateEvaluator`, `P05DeploymentGate`, `EvidenceBundleSealer`, `CompletionCertificateSigner`, `CertifiedEnvelopeRegistry`, `WaiverGovernance`, `DriftAndRevocationMonitor`, `CommercialGoldenRouteCertifier`, `AssuranceReportGenerator`, `AuditExport`

**Inputs:** sealed evidence bundle; proof results; revision set; gate decisions; customer acceptance.  
**Outputs:** Completion Certificate; Certification Report; unresolved risk ledger; re-certification trigger.

**Hard gates:** `certifier_independent`, `revision_binding_exact`, `critical_obligations_closed`, `E0_E5_pass`, `P05_pass_for_prod`, `evidence_bundle_sealed`, `side_effects_settled`.  
**KPIs:** `false_certification_rate`, `certificate_reproducibility`, `stale_evidence_rejection_rate`, `golden_route_pass_rate`, `post_certification_escape_rate`.

**Ownership rule.** This kernel is the single writer/authority for its canonical objects. Other kernels can reference immutable artifacts or issue commands but cannot maintain a shadow copy of truth.

## Non-negotiable system invariants

- Every terminal state references an exact `RevisionSet`.
- Every worker write is checked against tenant, execution epoch, lease generation and fencing token.
- Every side-effecting tool call has an idempotency key and a reconciliation state.
- Every proof result records tool digest, encoding version, resource bounds, assumptions and evidence hash.
- Every certificate is independently produced and cryptographically bound to the evidence root.
- Every legacy skill ID maps to exactly one v3 route owner.
- No cross-kernel cyclic ownership is permitted; workflow cycles occur only as explicit repair/fixpoint loops.
