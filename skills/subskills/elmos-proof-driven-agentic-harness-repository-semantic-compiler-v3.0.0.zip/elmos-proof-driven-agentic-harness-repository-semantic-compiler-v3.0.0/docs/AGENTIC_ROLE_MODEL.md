# Agentic Role Separation and Reasoning Policy

## Principle

Elmos uses models for hypothesis generation and high-value reasoning, not as an authority for semantics, permissions, evidence or completion. Each role receives the minimum artifacts and tools needed for its phase.

| Role | Primary output | May modify candidate? | May authoritatively verify? | May certify? |
|---|---|---:|---:|---:|
| Spec Miner | recovered requirements/assumptions | no | no | no |
| Semantic Reasoner | semantic explanations/gap hypotheses | no | no | no |
| Transformation Planner | ChangeGraph strategy | no | no | no |
| Proof Planner | obligation decomposition/verifier portfolio | no | no | no |
| Transformer | deterministic rule application / bounded patch | yes | no | no |
| Counterexample Reasoner | root cause and affected cone | no | no | no |
| Repair Synthesizer | minimal repair proposal | yes, isolated | no | no |
| Reviewer | findings and approval recommendation | no | no | no |
| Adversarial Agent | attacks/counterexamples/negative scenarios | no | no | no |
| Verifier Adapter | tool result/evidence | no | yes, within adapter scope | no |
| Independent Certifier | gate/certificate decision | no | consumes evidence | yes |

## Model portfolio routing

Routing uses phase, language/framework, risk, context size, tool-use capability, prior verified task-fit, latency, cost, data policy and provider health. It never routes solely by a marketing model rank.

High-risk decisions use:
- independent candidate/reviewer executions;
- artifact-level blinded comparison where possible;
- verifier-driven selection;
- no shared mutable context between generator and critic;
- explicit model/provider provenance.

## Context architecture

Stable prefix:
- Goal and exact revisions;
- architecture invariants;
- tool/policy contracts;
- domain semantic profile;
- canonical status semantics.

Dynamic context:
- affected evidence graph cone;
- current obligation/counterexample;
- relevant source/IR/change artifacts;
- bounded history summaries with source references.

Models communicate through typed artifacts, not unbounded chat transcripts.

## Reasoning outputs

Acceptable model outputs:
- candidate requirement/spec/invariant/lemma;
- transformation or proof plan;
- semantic-gap hypothesis;
- test/property/metamorphic relation;
- counterexample explanation;
- repair patch and rationale;
- reviewer risk finding.

Each output has `hypothesis` status until an accepted authority validates it.
