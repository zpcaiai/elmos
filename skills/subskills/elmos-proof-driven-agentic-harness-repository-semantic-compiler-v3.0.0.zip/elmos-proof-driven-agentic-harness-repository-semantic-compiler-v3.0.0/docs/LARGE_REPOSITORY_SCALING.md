# Large-Repository Scaling Architecture

## Target class

The architecture supports repositories from small services to multi-language monorepos above 1M LOC. Commercial large-repository certification requires evidence on at least three repositories above 500k LOC, including one above 1M LOC, for the selected Golden Route.

## Scaling axes

- files, LOC, symbols and generated code;
- build targets/modules/services;
- languages/frameworks/toolchains;
- proof obligations and scenarios;
- runtime traffic/data volume;
- parallel workspaces and verifier jobs;
- artifact/cache/evidence retention.

## Sharding

| Object | Shard key |
|---|---|
| Repository Evidence Graph | build target/module + symbol namespace |
| Semantic IR | language profile + module + dependency cone |
| ChangeGraph | transformation unit / worktree |
| Proof Obligation Graph | family + subject cone + risk |
| Tests/differential scenarios | capability/contract + fixture partition |
| Evidence | tenant + subject revision + producer |
| OTel/logs | tenant + run + epoch + component |

Shards are content addressed and carry dependency fingerprints. A change invalidates only affected cones unless a profile/toolchain/assumption change requires wider invalidation.

## Parallelism safety

Parallel work is allowed only when:
- Proof Graph dependencies are ready;
- file/symbol/write sets do not conflict or have a semantic merge plan;
- workspaces have unique ownership and fencing;
- budget and verifier throughput are reserved;
- merge order and validation are deterministic.

A large fanout is not automatically productive. The scheduler models expected information gain, conflict probability, downstream validation cost and cache reuse.

## Cache hierarchy

1. immutable source/artifact CAS;
2. parse/lossless syntax cache;
3. compiler semantic shard cache;
4. repository graph/query cache;
5. transformation recipe/result cache;
6. test/build dependency cache;
7. proof result cache;
8. model prefix/provider state cache.

Every cache key includes the revisions that affect validity. Cross-tenant cache reuse is denied by default unless artifacts are public, consented, normalized and cryptographically isolated.

## Storage and retention

- PostgreSQL stores authoritative metadata and state.
- Object storage stores repositories, IR, patches, traces and evidence.
- Event bus transports work; it is not the source of truth.
- OTel backend stores operational telemetry.
- WORM or equivalent controls protect released evidence bundles.
- Partitioning/archival policies are tenant and compliance aware.

## Capacity gates

Before large-repository production:
- million-file/1M+ LOC analysis benchmark;
- worker kill/resume and queue backpressure;
- graph/IR incremental invalidation;
- workspace cleanup and orphan detection;
- proof/evidence partition and query latency;
- object-store throughput and lifecycle;
- database connection/lock/partition tests;
- cost and machine ETA accuracy by size bucket.
