# Proof-Driven Execution and Assurance Model

## 1. Proof Obligation Graph as the scheduling backbone

A Proof Obligation is not a test name. It is a versioned claim:

```yaml
id: PO-SPRING-ROUTE-0001
subject:
  source_revision: sha256:...
  target_revision: sha256:...
claim:
  relation: observable_trace_refinement
  scope: GET /orders/:id
assumptions:
  - external-payment-sandbox-is-contract-conformant
required_assurance:
  minimum_status: PROVED_SOLVER_TRUSTED
  accepted_evidence_classes:
    - static-route-model
    - property-test
    - differential-runtime
dependencies:
  - PO-SECURITY-0002
risk:
  severity: critical
  open_world: false
```

Edges express logical dependency, evidence dependency, refinement hierarchy, shared assumptions or invalidation. The scheduler prioritizes obligations by criticality, centrality, uncertainty, affected surface, expected information gain and verifier cost.

## 2. Status lattice

| Status | Semantics |
|---|---|
| `PROVED_CERTIFIED` | 由可独立检查的证书或 proof object 证明；最强。 |
| `PROVED_INDUCTIVE` | 归纳不变量/模型检查证明 safety/liveness，在声明模型与公平性假设内成立。 |
| `PROVED_SOLVER_TRUSTED` | SMT/符号工具返回 unsat/valid；信任边界包含 solver 与编码器。 |
| `PROVED_FOR_SUPPORTED_FRAGMENT` | 仅对声明的语法/语义片段完成证明。 |
| `BOUNDED_NO_COUNTEREXAMPLE` | 在有限边界内未发现反例；绝不展示成无界证明。 |
| `REFUTED_WITH_COUNTEREXAMPLE` | 存在可重放反例，必须失败或修复。 |
| `UNKNOWN_TIMEOUT` | 验证超时，不能通过 critical gate。 |
| `UNKNOWN_RESOURCE_LIMIT` | 资源耗尽，不能通过 critical gate。 |
| `UNSUPPORTED` | 工具或语义片段不支持；必须换策略、监控或明确排除。 |
| `ASSUMPTION_REQUIRED` | 只有增加显式假设才能继续；假设必须审批并进入证书。 |
| `RUNTIME_MONITORED` | 开放世界边界只能运行期监测；必须有告警和回滚。 |
| `WAIVED_BY_APPROVER` | 授权人接受残余风险；不能提升为 PROVED。 |

The lattice is deliberately non-boolean. A UI may summarize, but it must preserve the original status and scope.

## 3. Evidence hierarchy

| Class | Examples | Typical use |
|---|---|---|
| Certified proof object | Lean kernel check, independently checkable certificate | critical pure logic / protocol invariants |
| Solver/model result | SMT unsat, model checker proof, symbolic execution | bounded or modeled semantics |
| Compiler/static evidence | type checking, dataflow, API/schema checks | language/framework constraints |
| Differential runtime | source/target traces, data reconciliation | observable behavior |
| Property/metamorphic/fuzz | generated inputs, shrinking, mutation score | broad behavioral space |
| Operational evidence | chaos/recovery/load/security/deploy | non-functional and open-world |
| Runtime monitor | production invariant/trace monitor | unavoidable open-world boundary |
| Human approval/waiver | scoped risk acceptance | never transforms risk into proof |

No evidence is valid without provenance, tool/environment identity, input hash, freshness and reproducibility policy.

## 4. Translation validation

Transformation engines are not trusted merely because their recipes were previously validated. For each candidate:

```text
source + target + relation + assumptions
          ↓
specific verification condition
          ↓
verifier portfolio
          ↓
result / counterexample / unknown
```

This permits deterministic codemods and generative repairs while keeping the trusted computing base smaller than the transformation system.

## 5. Counterexample-guided repair

```text
REFUTED_WITH_COUNTEREXAMPLE
  → normalize/minimize
  → root-cause classification
  → attach affected symbols/rules/obligations
  → counterexample-to-test
  → bounded repair proposal
  → recompile/reverify dependent subgraph
  → regress against hidden and historical corpus
```

Repeated no-progress, expanding edit radius, inconsistent counterexamples or verifier disagreement triggers strategy change or human escalation.

## 6. Compositional repository proof

Large repositories cannot be monolithically proved. v3 applies:

- module/service assume–guarantee contracts;
- interface and protocol refinement;
- data invariant decomposition;
- effect and side-effect summaries;
- dependency cones and change-impact invalidation;
- verified core / rigorously tested shell;
- runtime monitoring for open-world integrations.

Composition is accepted only when assumptions are discharged by providers or explicitly exposed in the certificate.

## 7. Trusted Computing Base

The TCB registry includes:

- compiler frontend/parser/type checker versions;
- IR encoder and semantics version;
- solver/proof checker binaries and digests;
- runtime harness, sandbox and policy bundle;
- oracle definitions and fixture generators;
- evidence hashing/signing components.

A TCB change invalidates affected cached proof results and may trigger re-certification.

## 8. Completion rule

```text
VERIFIED_COMPLETE ⇔
  exact RevisionSet is frozen
  ∧ no unresolved critical Proof Obligation
  ∧ all required gates pass
  ∧ evidence is fresh, sealed and unrevoked
  ∧ external side effects are settled
  ∧ budget and usage ledgers reconcile
  ∧ independent Certifier signs the certificate
```

A workflow may finish operationally while the Goal remains `BLOCKED`, `PARTIAL`, `FAILED_ASSURANCE` or `AWAITING_APPROVAL`.
