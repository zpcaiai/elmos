# Platform Operations Runbook

## Start-of-day checks

- control DB, object store, event bus, policy, identity, secret broker and OTel health;
- stuck/expired leases and orphan workspaces;
- `UNKNOWN_RESULT` side effects;
- blocked critical obligations and verifier capacity;
- evidence expiry/revocation queue;
- credit reservation and usage reconciliation;
- model/tool provider health and route fallback;
- backup/PITR and release manifest status.

## Incident priorities

**P0:** cross-tenant exposure, unauthorized tool/secret/network, false certificate, evidence corruption, double external side effect.  
**P1:** durable recovery failure, large-scale stuck runs, proof-status inflation, cost ledger divergence.  
**P2:** verifier/provider degradation, ETA/SLO breach, cache invalidation inefficiency.

## Emergency actions

- revoke Environment Authorities and secret leases;
- pause affected Goals/tenants;
- fence all current worker generations;
- disable adapter/model/tool revision in registry;
- revoke affected evidence/certificates;
- preserve immutable journal and forensic artifacts;
- reconcile side effects and billing;
- run regression/holdout before reactivation.

## Never do

- edit database state manually to mark a run completed;
- delete evidence to hide a failure;
- reuse a certificate across revisions;
- blind retry an `UNKNOWN_RESULT`;
- widen thread-global permissions to fix an adapter;
- accept LLM judgment as proof.
