# Commercial Certification

## Certification products

- **Verified Transformation:** E0–E4 on exact candidate revision.
- **Production Verified:** E0–E4 + P05.
- **Certified Golden Route:** E0–E5 + P05, customer/holdout and cutover evidence.
- **Runtime-Monitored Envelope:** proven/tested core plus explicitly monitored open-world boundaries.

## Certificate contents

- tenant/project/Goal and exact Revision Set;
- domain pack and certified envelope;
- observable contract and acceptance scenarios;
- Proof Obligation summary and full status distribution;
- assumptions, waivers, unsupported and monitored boundaries;
- gate decisions and policy revisions;
- toolchain/compiler/verifier/encoder/environment digests;
- evidence Merkle root, freshness and revocation policy;
- customer acceptance and rollout/rollback references;
- independent signer, issue/expiry/revocation.

## Independent certification controls

The Certifier:
- is a distinct execution source and permission profile;
- cannot modify the candidate;
- cannot accept model self-report as evidence;
- checks exact revisions and evidence lineage;
- rejects empty/stale/revoked evidence;
- rejects unsettled external side effects;
- preserves bounded/unknown/waived statuses;
- signs only after the stop gate passes.

## Re-certification

Triggered by:
- source/target revision change;
- policy/domain profile/toolchain/TCB change;
- evidence expiry or revocation;
- runtime drift or monitored invariant breach;
- new critical vulnerability;
- customer acceptance contract change.
