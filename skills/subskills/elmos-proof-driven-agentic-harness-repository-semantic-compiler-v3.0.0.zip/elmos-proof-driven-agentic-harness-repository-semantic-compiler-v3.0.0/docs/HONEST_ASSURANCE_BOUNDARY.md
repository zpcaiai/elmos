# Honest Assurance Boundary

Elmos v3 pursues the engineering limit of correctness without making mathematically or operationally false promises.

## What can be certified

Certification is relative to:

- a precise source and target revision;
- a declared observable contract;
- supported semantic fragments;
- explicit environmental and external-service assumptions;
- a versioned trusted computing base;
- required evidence classes and resource bounds;
- a defined validity period and drift policy.

## What cannot be universally promised

General semantic equivalence for arbitrary programs and open-world systems is not universally decidable or observable. Reflection, dynamic code, native components, undefined behavior, races, external services, hardware, time, randomness and distributed failures may require assumptions, bounded checking or runtime monitoring.

## Required product language

Allowed:

> All critical obligations are closed within Certified Envelope X; the remaining open-world boundaries are listed and monitored.

Forbidden:

> Elmos proves every arbitrary program 100% correct.

## Fail-closed behavior

Missing/expired/revoked evidence, unsupported semantics, unknown solver result, ambiguous external side effect, unapproved assumption, stale worker, model-only oracle or unbound revision prevents a certified status.

## Package boundary

The included reference implementation demonstrates contracts, state transitions, authority checks, status policy and certification logic. External proof tools, compiler integrations, live infrastructure and customer Golden Routes require deployment-specific adapters and evidence.
