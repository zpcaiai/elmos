# Build vs. Integration Status

## Present in this package

- unified 8-kernel architecture and 16 routable skills;
- 115/115 legacy migration map and read-only source snapshots;
- machine-valid schemas, policies, APIs and workflows;
- language/framework semantic profile registry;
- verifier and harness adapter contracts/conformance suites;
- five Domain Packs and Golden Routes;
- PostgreSQL 17 migration model;
- executable reference proof/authority/workflow/certification kernel;
- inherited 46,664-case ETGB data plane;
- deployment/observability/console specifications;
- validation, checksum and install/uninstall tooling.

## Requires Elmos main-repository integration

- service implementations for all ports and workers;
- compiler-native frontend binaries/bridges;
- real model/harness/provider adapters;
- external verifier installation and encoding implementations;
- production sandbox/network/secret enforcement;
- live PostgreSQL/object store/event bus/OTel/identity;
- UI implementation;
- real repository and customer Golden Route certification.

## Evidence terminology

A package validator PASS means internal package consistency. It is not E5 customer certification. The final build report lists exactly what was and was not executed.
