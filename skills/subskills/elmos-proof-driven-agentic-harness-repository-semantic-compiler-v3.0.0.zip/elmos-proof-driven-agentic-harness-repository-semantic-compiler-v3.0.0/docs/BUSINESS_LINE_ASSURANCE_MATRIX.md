# Business-Line Assurance Matrix

| Concern | Spring modernization | Cross-language | Project generation | SQL conversion | Refactoring |
|---|---|---|---|---|---|
| Correctness relation | observable trace refinement | relational semantic equivalence / translation validation | requirements/spec conformance | relational/data/transaction equivalence | behavior preservation + target constraints |
| Semantic authority | Java/Jakarta/Spring/legacy framework models | language profiles + product program | formal requirement/architecture/workflow specs | dialect catalog + relational/routine/transaction IR | source semantic IR + architecture constraints |
| Critical runtime oracle | legacy/target dual run | source/target dual run | acceptance/reference contract | source/target DB differential | before/after differential |
| Formal focus | routes/security/session/order/transactions | type/effect/concurrency/gaps | workflow safety/liveness/tenant/resource | query/schema/routine/trigger/transaction | public contracts/concurrency/architecture |
| Rollout | strangler/shadow/canary | dual run/adapters/cutover | staged environment promotion | shadow queries/data reconciliation/cutover | canary/feature flags/module rollout |
| Certificate boundary | supported legacy stack and external services | supported language fragments/open-world contracts | frozen requirement/spec envelope | supported dialect features/data/workload | defined public behavior and target constraints |

Each cell is instantiated as Proof Obligations and evidence requirements, not a checklist-only statement.
