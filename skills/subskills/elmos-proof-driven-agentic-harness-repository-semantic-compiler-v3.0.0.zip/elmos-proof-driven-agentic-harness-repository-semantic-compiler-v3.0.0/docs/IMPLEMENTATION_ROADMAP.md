# V3 Implementation and Adoption Roadmap

This is a dependency-ordered implementation plan. It reports system delivery gates rather than optimistic calendar promises.

## Wave 0 — Architecture freeze

Exit:
- 8-kernel ownership accepted;
- 16 routable skills registered;
- 115 legacy IDs mapped exactly once;
- canonical schemas and proof statuses frozen;
- no new standalone skill bypasses a kernel owner.

## Wave 1 — Durable authority and evidence

Implement K1, K7 and K8 control objects, PostgreSQL migrations, RLS, lease/fencing, outbox, environment authority, immutable evidence and independent certificate skeleton.

Exit:
- kill/resume, stale worker and cross-tenant negative tests pass;
- `Agent says done` cannot complete a Goal;
- exact RevisionSet binding enforced.

## Wave 2 — Repository intelligence and semantic compiler

Implement K2/K3 frontend registry, repository graph, Java/Spring and SQL profiles first, content-addressed shards and semantic-gap generation.

Exit:
- compiler-grade type attribution for Golden Route;
- critical graph coverage metrics;
- supported/unsupported fragment reporting;
- incremental invalidation tests.

## Wave 3 — Transformation and verifier closure

Implement K4–K6 loops, deterministic recipes, bounded repair, Proof Obligation scheduler, differential runtime and initial SMT/model-checking adapters.

Exit:
- counterexample→test→repair→reverify closed loop;
- no LLM-only authoritative oracle;
- proof cache invalidates on TCB/input/assumption drift.

## Wave 4 — Golden Routes

Order:
1. Spring legacy modernization;
2. SQL dialect/routine conversion;
3. repository refactoring;
4. cross-language conversion;
5. project generation.

Each route progresses fixture → public repository → internal large repository → hidden holdout → customer repository.

## Wave 5 — Commercial certification

Exit:
- live P05 deployment gate;
- E0–E5 evidence;
- at least three repositories above 500k LOC and one above 1M LOC for the selected large-repository route;
- customer acceptance, rollback rehearsal, support and audit export;
- reproducible cost/ETA and margin model.

## Backlog policy

Every feature request must declare:
- owning kernel/domain pack;
- canonical object changed;
- proof obligations affected;
- security/tenant/cost impact;
- migration and compatibility;
- release gate and evidence.

Requests without an owner or evidence plan do not become new top-level skills.
