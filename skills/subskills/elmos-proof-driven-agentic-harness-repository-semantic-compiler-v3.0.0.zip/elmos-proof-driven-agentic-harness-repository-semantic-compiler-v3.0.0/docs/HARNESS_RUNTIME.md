# Proof-Driven Agentic Harness Runtime

## Core runtime tuple

Every executable attachment is modeled as:

```text
Capability + RuntimeState + Provenance + Policy + Lifecycle
```

This tuple is immutable for a specific authority revision. Changes create a new revision and execution epoch.

## Ownership hierarchy

```text
Goal
 └─ Run
    └─ ExecutionEpoch
       └─ Environment
          ├─ Workspace
          ├─ ModelSession
          ├─ ToolAttachment
          ├─ SandboxProfile
          ├─ NetworkProfile
          ├─ SecretLease
          └─ EvidenceScope
```

Permissions are evaluated against the concrete Environment/Attachment owning a request. They are never inherited from a broad chat thread by accident.

## Execution provenance

`ExecutionSource` includes:

```text
USER
ROOT_AGENT
SUBAGENT
PLANNER
TRANSFORMER
REVIEWER
ADVERSARY
VERIFIER
CERTIFIER
SYSTEM_INTERNAL
REPLAY
RECOVERY
OPERATOR
```

Every event records root/parent/current execution IDs, tenant, goal, run, epoch, workspace, authority revision and causation/correlation IDs.

## Durable lifecycle

Canonical states:

```text
CREATED → ADMITTED → PLANNING → EXECUTING ↔ CHECKPOINTED
                         ↓             ↓
                    AWAITING_REVIEW  PAUSED
                         ↓             ↓
                      VERIFYING ← RESUMING
                         ↓
              CERTIFYING → COMPLETED
                         ↘ BLOCKED / FAILED / CANCELLED
```

State and outbox events commit in one transaction. Workers are disposable; recovery reconstructs from the database journal and sealed artifacts.

## Lease and fencing

Every claim carries:

- lease owner and expiry;
- monotonic lease generation;
- opaque fencing token;
- execution epoch;
- expected input revision;
- idempotency key.

A stale worker can compute, but cannot commit. CAS writes are staged and only referenced after an authoritative transaction accepts the attempt.

## Tool safety

Tool requests pass:

1. schema validation;
2. capability check;
3. tenant/path/parameter constraints;
4. policy decision `ALLOW / DENY / REVIEW`;
5. side-effect classification;
6. idempotency and reconciliation setup;
7. sandbox/network/secret materialization;
8. timeout/resource enforcement;
9. output sanitization and evidence recording.

Unknown tool, unknown authority or policy engine failure is `DENY`.

## Two-phase environment

- **Setup phase:** optional approved network, dependency resolution, immutable lock and image capture.
- **Execution phase:** secretless by default, deny network, read/write paths limited to workspace, pinned toolchain, reproducible clocks/randomness where possible.

## Provider/harness adapters

Adapters must preserve:

- provider-native session/tool state when supported;
- explicit loss annotations when not supported;
- cancellation and pause semantics;
- tool-call identity;
- reasoning provenance class without exposing private hidden reasoning;
- event order and replay behavior;
- authority ownership and policy decisions.

Cross-harness conversion fails closed when security or lifecycle semantics cannot be represented.

## Parallelism and backpressure

Top-level account concurrency defaults to three. Internal fanout is governed separately by:

- proof graph readiness;
- merge/conflict probability;
- verifier throughput;
- model/tool quota;
- budget reservation;
- workspace capacity;
- customer priority and SLO.

## Realtime steering

A user or operator may add constraints, pause, cancel or approve a scoped action. Steering creates a new command/event; it does not mutate historical prompts or silently widen authority.
