# Legacy Capability Consolidation: 115 → 16

## Coverage result

- Repository Autonomy Kernel v2: **31/31 mapped**
- Formal Assurance Kernel v1: **60/60 mapped**
- ETGB v1.1: **24/24 mapped**
- Total: **115/115 mapped exactly once**
- Unmapped: **0**
- Legacy capabilities independently routable in v3: **0**

## Distribution

| V3 canonical owner | Legacy capabilities absorbed |
|---|---:|
| `elmos-agentic-reasoning-kernel` | 6 |
| `elmos-certification-kernel` | 13 |
| `elmos-commercial-operations-finops` | 2 |
| `elmos-domain-cross-language-conversion` | 8 |
| `elmos-domain-multi-language-project-generation` | 5 |
| `elmos-domain-repository-refactoring` | 0 |
| `elmos-domain-spring-legacy-modernization` | 10 |
| `elmos-domain-sql-dialect-routine-conversion` | 11 |
| `elmos-evaluation-trust-gate` | 12 |
| `elmos-goal-specification-kernel` | 6 |
| `elmos-harness-runtime-kernel` | 16 |
| `elmos-proof-verification-kernel` | 12 |
| `elmos-repository-intelligence-kernel` | 1 |
| `elmos-repository-semantic-compiler-kernel` | 3 |
| `elmos-self-improvement-governance` | 9 |
| `elmos-transformation-kernel` | 1 |

## Migration semantics

A legacy invocation is resolved as:

```text
legacy skill ID
  → alias registry
  → v3 canonical owner
  → legacy ID retained in provenance
  → v3 schemas/authority/workflow/proof policies apply
```

The compatibility layer never executes the old skill as a separate state owner. Legacy content is retained as:

- internal kernel component;
- domain-specific semantic/rule/obligation template;
- verifier or evaluation technique;
- compatibility trigger and provenance label;
- migration test case.

## Activation gate

Migration is complete only when:

1. alias coverage is 100%;
2. no alias targets another alias;
3. every target exists in the v3 registry;
4. old workflow state has a deterministic migration;
5. regression/holdout tests compare old and v3 behavior;
6. audit and rollback preserve the old source package/version/path.
