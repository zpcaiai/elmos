# Approval Reviewer Agent

> Skill ID: `elmos-approval-reviewer-agent`  
> Priority: **P0**  
> Package: `elmos-repository-autonomy-kernel`  
> Contract version: `2.0.0`  
> Status: `CANDIDATE` — 必须通过本文件定义的发布门后才能进入生产。

## 1. 目标

由独立、只读、权限受限的 Reviewer 审核可审批越权请求；Reviewer 只能批准策略允许审批的精确动作，不能扩大权限。

该 Skill 是 Elmos 仓库级生成/转换执行内核的一部分。它必须以结构化契约、持久状态、可验证证据和可恢复执行为核心，禁止把关键正确性仅寄托在模型提示词或单次对话上下文中。

## 2. 触发条件

- Policy 返回 REVIEW
- 高风险副作用需要第二意见
- 用户启用自动审批代理

路由器只有在输入契约、租户能力、依赖版本和策略许可同时满足时才能激活本 Skill；歧义触发必须输出 `NOT_APPLICABLE` 或 `NEEDS_EVIDENCE`，不得静默猜测。

## 3. 输入契约

- `approval request`
- `bounded transcript/evidence pack`
- `exact normalized action`
- `policy reason and safer alternatives`

所有输入必须携带：

```yaml
tenant_id: uuid
project_id: uuid
goal_id: uuid
workflow_run_id: uuid
repository_snapshot_id: uuid
correlation_id: uuid
idempotency_key: string
schema_version: string
created_at: RFC3339
```

输入对象使用 JSON Schema 校验；外部文件和大对象仅传递 content-addressed Artifact 引用，不在事件中内嵌原文。

## 4. 输出契约

- `APPROVE/DENY/ESCALATE decision`
- `exact-action approval lease`
- `review evidence`
- `safer-action recommendation`

每个终态输出必须关联：

- `trace_id`、`attempt_id`、`producer_version`；
- 精确输入与策略 bundle 的 content hash；
- 机器执行 wall-clock、模型/工具成本与资源用量；
- `evidence_refs[]` 和可机读的通过、失败或豁免原因；
- 上游 Artifact lineage 与下游缓存失效范围。

## 5. 执行流水线

1. 确认请求属于 policy-defined reviewable 类别
2. 加载最小只读证据
3. 评估必要性、范围、可逆性和替代方案
4. 验证 normalized action hash
5. 签发限参数/限时/限 tenant 的 lease 或拒绝
6. 记录 Reviewer 模型、上下文、证据和 policy hash

每一步均需作为持久化 Workflow Node 或 Node Attempt 执行。Node 完成和 Outbox 事件写入必须在同一数据库事务中完成；Worker 失联后由租约过期机制安全重放。

## 6. 生产不变量

- Reviewer 无权执行被审动作
- Reviewer 无权改 Policy Bundle
- 参数任何变化都使 lease 失效
- 不确定时升级而非自动批准
- Main Agent 与 Reviewer 上下文隔离

共同不变量：

- 所有读写必须携带 `tenant_id`，数据库 RLS 和应用层双重隔离；
- 模型输出从不构成授权、完成证据或外部副作用许可；
- Side effect 必须声明 `NONE/READ/WORKSPACE_WRITE/EXTERNAL_WRITE/DESTRUCTIVE`；
- 重试必须使用幂等键；非幂等步骤需要 compensation 或人工恢复 Runbook；
- `SUCCESS` 只表示节点执行成功，Goal 完成必须由独立 hard gates 证明；
- `ETA` 指 Elmos 自动执行的机器 wall-clock 预测，不使用人工人天替代。

## 7. 组件分解

- `ApprovalRequestNormalizer`
- `EvidencePackBuilder`
- `IndependentReviewer`
- `SaferPathFinder`
- `LeaseIssuer`
- `ApprovalAudit`

每个组件必须有明确的输入/输出 schema、超时、重试、幂等、权限、审计和故障注入测试。组件之间通过 typed command/event 或 Artifact 引用通信，不共享隐式可变内存。

## 8. 权限与策略

所需最小 capability：

- `approval:review`
- `approval:read_evidence`

调用流程：

```text
Intent
  → authenticated principal
  → tenant/project capability
  → tool/path/parameter policy
  → side-effect risk classification
  → ALLOW | DENY | REVIEW
  → scoped lease
  → execution
  → audit + evidence
```

任何 `REVIEW` 决策必须绑定 exact action hash、参数、路径、环境、过期时间和单次使用 nonce；审批不能泛化为无限期权限。

## 9. 依赖

- `policy-kernel`
- `artifact-protocol`
- `model-router`
- `audit-log`

依赖在 Registry 中以语义版本与 capability 约束解析。缺失依赖时返回结构化 `DEPENDENCY_UNAVAILABLE`，不得退化成低保证模式后继续写代码。

## 10. 故障、恢复与补偿

| 故障 | 必须行为 |
|---|---|
| Worker/容器崩溃 | 租约超时；从最后 durability boundary 重新领取；不重复已提交副作用 |
| 数据库短暂不可用 | 停止推进状态；指数退避；禁止仅在内存中标记完成 |
| 模型超时/限流 | 保留 provider-native turn envelope；按路由策略切换或 checkpoint |
| 网络中断 | 执行阶段默认无网；必要网络动作由审批租约和 egress proxy 管理 |
| 预算即将耗尽 | 在安全边界 checkpoint，输出剩余 DAG、风险和机器 ETA |
| 证据不完整 | 状态置为 `BLOCKED_EVIDENCE`，不得发布 Completion Certificate |
| Schema 不兼容 | fail closed；进入 dead-letter/quarantine；人工或自动 migration |
| 补偿失败 | `COMPENSATION_FAILED`，冻结相关资源并触发高优先级事件 |

## 11. 可观测性

| 指标 | 要求 |
|---|---|
| `approval_latency` | Prometheus/OTel；按 tenant/project/skill_version 聚合，避免高基数原始标签 |
| `approval_rate` | Prometheus/OTel；按 tenant/project/skill_version 聚合，避免高基数原始标签 |
| `safer_alternative_rate` | Prometheus/OTel；按 tenant/project/skill_version 聚合，避免高基数原始标签 |
| `lease_mismatch_count` | Prometheus/OTel；按 tenant/project/skill_version 聚合，避免高基数原始标签 |
| `post_approval_incident_rate` | Prometheus/OTel；按 tenant/project/skill_version 聚合，避免高基数原始标签 |

必须发出标准 span：

```text
skill.activate
skill.input.validate
policy.evaluate
node.attempt
tool.execute
artifact.persist
evidence.evaluate
skill.complete
```

日志只记录结构化 ID、摘要和 hash；源代码、Secret、完整 prompt/thinking 不进入普通日志。

## 12. 验收测试

| ID | 场景 | 判定 |
|---|---|---|
| AT-01 | DENY 类动作不能被 Reviewer 批准 | 自动化；失败即阻止当前发布级别 |
| AT-02 | 修改一个参数后 lease 失效 | 自动化；失败即阻止当前发布级别 |
| AT-03 | Reviewer 工具集只读 | 自动化；失败即阻止当前发布级别 |
| AT-04 | 证据不足时 DENY 或 ESCALATE | 自动化；失败即阻止当前发布级别 |
| AT-X01 | 跨租户对象引用 | 必须拒绝并产生不可篡改审计事件 |
| AT-X02 | Node 状态已持久化、事件尚未发布时进程崩溃 | Outbox Relay 恢复后只发布一次语义事件 |
| AT-X03 | 重复提交相同 `idempotency_key` | 返回同一逻辑结果，不重复副作用 |
| AT-X04 | 终态 Attempt | 必须拥有 trace、metrics、cost 和 evidence refs |
| AT-X05 | 权限或依赖缺失 | fail closed，不进入隐式降级路径 |

## 13. 发布门

| 级别 | 必须满足 |
|---|---|
| `CONTRACT` | Schema、状态机、权限、错误目录和示例通过静态检查 |
| `LOCAL` | 单元、属性、并发、崩溃恢复和故障注入测试通过 |
| `SHADOW` | 在真实仓库只读/影子运行；与人工或旧系统对比，不产生生产写入 |
| `CANARY` | 限定租户、仓库和预算；可一键回滚；SLO 与安全告警有效 |
| `PROD` | 30 天错误预算合格；无 P0/P1 安全缺陷；Runbook 演练完成 |
| `TRUSTED` | 跨至少 3 个 >500k LOC 仓库，其中至少 1 个 >1M LOC；Golden Route 可重复付费交付 |

## 14. Definition of Done

- 代码、schema、migration、API、策略、dashboard、告警和 Runbook 同版本发布；
- happy path、失败路径、重试、取消、恢复和补偿均有自动化测试；
- 真实仓库基准报告同时给出质量、wall-clock、Token/工具成本和资源用量；
- 证据可由独立 Verifier 重放；
- 安全审批、数据保留、审计导出和租户删除流程完成演练；
- 兼容性或能力不足时明确失败，不伪造成功。
