# Runbook — elmos-shared-agent-daemon

## Ownership

- Primary: Repository Autonomy team
- Secondary: Platform Runtime, Security, Developer Productivity
- Severity policy: tenant data risk or incorrect production write = SEV-1; blocked workflows at scale = SEV-2.

## Fast triage

1. Resolve `tenant_id`, `goal_id`, `workflow_run_id`, `node_attempt_id`, `trace_id`.
2. Read append-only audit and exact policy bundle hash.
3. Confirm repository snapshot, environment fingerprint and Skill version.
4. Freeze write leases before manual intervention.
5. Prefer checkpoint/fork over editing database rows.
6. Preserve failed artifacts and evidence until incident retention expires.

## Primary alerts

- `connected_clients` exceeds its release-specific threshold
- `event_replay_lag_seconds` exceeds its release-specific threshold
- `duplicate_command_suppression_total` exceeds its release-specific threshold
- `slow_consumer_disconnects_total` exceeds its release-specific threshold

## Recovery decisions

| Condition | Action |
|---|---|
| transient provider/tool failure | retry inside declared attempt budget |
| repeated deterministic failure | quarantine node; route to alternate implementation or operator |
| evidence mismatch | invalidate downstream cache and re-run affected validation |
| suspected cross-tenant access | revoke leases, isolate tenant, preserve audit, invoke security incident plan |
| cost runaway | stop new fanout; checkpoint active work; retain completed ChangeSets |
| corrupted snapshot/artifact | block promotion; restore from verified prior checkpoint |
| adapter/schema drift | fail closed; pin prior compatible version; run conformance suite |

## Manual operations

All manual commands require break-glass capability, ticket/reference, reason, expiry, and second-party approval for production. Direct deletion or state mutation in PostgreSQL is prohibited; use control-plane commands that emit audit events.

## Post-incident

- Add a deterministic regression to `acceptance.yaml` or Repository Gym.
- Link incident, root cause, impacted versions and fixed version.
- Recalculate Skill confidence and routing rating.
- Verify rollback and data-retention obligations.
