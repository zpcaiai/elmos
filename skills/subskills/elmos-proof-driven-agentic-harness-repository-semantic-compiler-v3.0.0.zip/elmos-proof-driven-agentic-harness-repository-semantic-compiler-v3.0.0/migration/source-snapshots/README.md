# Read-only legacy source snapshots

These files preserve the exact skill source material used for the 115→16 mapping. They are non-routable and excluded from v3 registry discovery. They exist for audit, migration review and regression authoring.
