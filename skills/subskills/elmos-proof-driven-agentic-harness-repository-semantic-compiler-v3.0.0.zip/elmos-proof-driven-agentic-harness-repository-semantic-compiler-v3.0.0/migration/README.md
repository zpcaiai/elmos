# Migration

`legacy-skill-map.csv/json` provides a complete auditable mapping from 115 old entry points to 16 v3 owners. `legacy-alias-registry.yaml` is the only supported compatibility router.

No automatic migration is allowed to claim semantic equivalence without replay/regression evidence.
