---
name: elmos-harness-runtime-kernel
description: 提供长任务、多 Agent、多工作区、多模型、多工具的 durable execution substrate，把权限、运行状态、来源、策略和生命周期绑定到具体 Environment/Attachment。
version: 3.0.0
priority: P0
kind: kernel
---

# Harness Runtime Kernel

**Skill ID:** `ELMOS-V3-007`  
**Route owner:** `K7`  
**Release:** `elmos-v3.0.0`

## Purpose

提供长任务、多 Agent、多工作区、多模型、多工具的 durable execution substrate，把权限、运行状态、来源、策略和生命周期绑定到具体 Environment/Attachment。

This is a v3 routable capability. It owns or coordinates a defined canonical boundary; it must not be replaced by an ad-hoc agent prompt or a legacy skill executing as an independent control plane.

## Responsibilities

- 核心对象采用 Capability + RuntimeState + Provenance + Policy + Lifecycle，并保存 root/parent execution lineage。
- Thread/Turn 不是权限所有者；Environment、workspace、attachment 和 tool request 拥有明确 authority snapshot。
- 实现 durable workflow、event sourcing、checkpoint/replay/fork/time travel、pause/resume/cancel/recovery。
- 通过 lease generation、fencing token、idempotency key、transactional outbox 和 external side-effect reconciliation 防止双写和幽灵完成。
- Setup 与 Execution 两阶段隔离；执行默认 secretless、deny-network、least privilege、path/parameter-level policy。
- 提供 Harness SPI、MCP/A2A/tool gateway、provider adapter、workspace manager、scheduler、backpressure、cost/ETA ledger 和 OTel。

## Inputs

- Workflow IR
- environment authority
- model/tool requests
- artifacts/events

All mutable inputs must resolve to immutable revisions before execution. Tenant, Goal, Run, Execution Epoch and Environment Authority are mandatory runtime context.

## Outputs

- durable execution journal
- checkpoints
- policy decisions
- tool results
- cost/ETA events
- recovery decisions

Outputs are artifacts with content hashes, lineage, schema version, producer identity, environment/tool digest and evidence classification.

## Internal components

- `DurableWorkflowRuntime`
- `EnvironmentAuthority`
- `WorkspaceManager`
- `SessionTimeline`
- `ExecutionProvenance`
- `ToolGateway`
- `PolicyDecisionPoint`
- `LeaseAndFencing`
- `CheckpointReplayFork`
- `SideEffectReconciler`
- `HarnessAdapterSPI`
- `SchedulerBackpressureFinOps`

Components are implementation modules, not separately routable skills unless a future version assigns an explicit canonical owner and migration.

## Workflow

1. Validate invocation, tenant, exact Revision Set, authority and budget.
2. Load prerequisites and content-addressed artifacts.
3. Compile a versioned workflow fragment and idempotency plan.
4. Execute only ready nodes; record events and artifacts transactionally.
5. Emit/refine affected Proof Obligations.
6. Run validation or request the required downstream kernel.
7. Stop on refutation, stale authority, ambiguous side effect, budget breach or no-progress.
8. Return a structured result; never use free-text completion as terminal truth.

## Verification

- `authority_resolved`
- `fencing_current`
- `tenant_isolation`
- `side_effect_state_known_or_blocked`
- `checkpoint_recoverable`
- `budget_not_overdrawn`

Critical gates require immutable evidence. Model judgment alone is not accepted as authoritative evidence.

## Dependencies

- none

Dependency versions are pinned through the Goal Revision Set; runtime discovery cannot silently change them.

## Security and authority

- deny by default;
- Environment/Attachment-owned authority;
- tenant-scoped paths, cache and evidence;
- no secret value in prompts, logs or artifacts;
- path/parameter/side-effect policy evaluation;
- lease generation and fencing on every authoritative commit;
- external side effects use idempotency and reconciliation.

## Observability and FinOps

- `recovery_success_rate`
- `stale_worker_rejection_rate`
- `unreconciled_side_effect_rate`
- `tool_policy_violation_rate`
- `machine_eta_mape`
- `cost_accounting_gap`

Every span includes tenant, goal, run, epoch, kernel/skill, workflow node, workspace, model/tool, proof obligation and cost attribution where applicable.

## Stop and escalate

Stop with a typed status when:

- required semantics or verifier is unsupported;
- a critical result is `REFUTED_WITH_COUNTEREXAMPLE`;
- required proof is unknown or resource-limited;
- authority, policy, evidence or revision binding cannot be resolved;
- repeated repairs make no measurable obligation progress;
- external side-effect result is unknown;
- human approval is required by policy.

Escalation must include the smallest reproducible artifact bundle, affected obligations, candidate options, residual risks and machine ETA/cost impact.

## Definition of done

This skill is done only when its own hard gates pass, its outputs are durably committed and all downstream obligations it owns are closed or explicitly handed off. Only the independent Certification Kernel may mark the Goal `VERIFIED_COMPLETE`.
