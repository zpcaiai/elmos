---
name: elmos-goal-specification-kernel
description: 把自然语言目标、存量规范、约束、预算和验收标准编译为版本化、可执行、可证明的 Goal Contract、Observable Contract、Requirement Graph 与 Revision Set。
version: 3.0.0
priority: P0
kind: kernel
---

# Goal / Specification Kernel

**Skill ID:** `ELMOS-V3-001`  
**Route owner:** `K1`  
**Release:** `elmos-v3.0.0`

## Purpose

把自然语言目标、存量规范、约束、预算和验收标准编译为版本化、可执行、可证明的 Goal Contract、Observable Contract、Requirement Graph 与 Revision Set。

This is a v3 routable capability. It owns or coordinates a defined canonical boundary; it must not be replaced by an ad-hoc agent prompt or a legacy skill executing as an independent control plane.

## Responsibilities

- Goal 与聊天线程解耦并持久化；支持暂停、恢复、取消、分叉、重规划与机器 wall-clock ETA。
- 建立 immutable Revision Set，固定 source/baseline/requirements/policy/workflow/model/toolchain/environment/domain-pack 版本。
- 从文档、代码、测试、流量、工单和数据库行为恢复显式及隐式需求。
- 把需求分解为可观察行为、数据不变量、安全属性、活性属性、资源预算和非功能目标。
- 生成 Spec Delta、Assumption Ledger、Acceptance Scenarios 与初始 Proof Obligation Graph。
- 对需求冲突、不完整、不可判定或超出认证包络的目标 fail-closed。

## Inputs

- 用户目标和验收偏好
- 不可变仓库快照
- 现有需求/架构/API/数据文档
- 预算、SLA、风险和合规策略

All mutable inputs must resolve to immutable revisions before execution. Tenant, Goal, Run, Execution Epoch and Environment Authority are mandatory runtime context.

## Outputs

- Goal Contract
- Revision Set
- Requirement Graph
- Observable Behavior Contract
- Spec Delta
- Assumption Ledger
- Acceptance Scenario Set
- initial Proof Obligation Graph

Outputs are artifacts with content hashes, lineage, schema version, producer identity, environment/tool digest and evidence classification.

## Internal components

- `GoalAggregate`
- `GoalCommandService`
- `RevisionSetRegistry`
- `RequirementGraphCompiler`
- `ObservableContractCompiler`
- `SpecDeltaCompiler`
- `AssumptionLedger`
- `AcceptanceScenarioCompiler`
- `BudgetAndEtaContract`
- `GoalRiskClassifier`
- `GoalCheckpointProjection`
- `GoalChangeImpactAnalyzer`

Components are implementation modules, not separately routable skills unless a future version assigns an explicit canonical owner and migration.

## Workflow

1. Validate invocation, tenant, exact Revision Set, authority and budget.
2. Load prerequisites and content-addressed artifacts.
3. Compile a versioned workflow fragment and idempotency plan.
4. Execute only ready nodes; record events and artifacts transactionally.
5. Emit/refine affected Proof Obligations.
6. Run validation or request the required downstream kernel.
7. Stop on refutation, stale authority, ambiguous side effect, budget breach or no-progress.
8. Return a structured result; never use free-text completion as terminal truth.

## Verification

- `goal_schema_valid`
- `revision_set_complete`
- `critical_requirement_conflicts_zero`
- `observable_contract_approved_or_policy_accepted`
- `proof_obligations_initialized`

Critical gates require immutable evidence. Model judgment alone is not accepted as authoritative evidence.

## Dependencies

- none

Dependency versions are pinned through the Goal Revision Set; runtime discovery cannot silently change them.

## Security and authority

- deny by default;
- Environment/Attachment-owned authority;
- tenant-scoped paths, cache and evidence;
- no secret value in prompts, logs or artifacts;
- path/parameter/side-effect policy evaluation;
- lease generation and fencing on every authoritative commit;
- external side effects use idempotency and reconciliation.

## Observability and FinOps

- `goal_to_spec_lead_time`
- `requirement_coverage`
- `assumption_escape_rate`
- `acceptance_ambiguity_rate`
- `eta_mape`

Every span includes tenant, goal, run, epoch, kernel/skill, workflow node, workspace, model/tool, proof obligation and cost attribution where applicable.

## Stop and escalate

Stop with a typed status when:

- required semantics or verifier is unsupported;
- a critical result is `REFUTED_WITH_COUNTEREXAMPLE`;
- required proof is unknown or resource-limited;
- authority, policy, evidence or revision binding cannot be resolved;
- repeated repairs make no measurable obligation progress;
- external side-effect result is unknown;
- human approval is required by policy.

Escalation must include the smallest reproducible artifact bundle, affected obligations, candidate options, residual risks and machine ETA/cost impact.

## Definition of done

This skill is done only when its own hard gates pass, its outputs are durably committed and all downstream obligations it owns are closed or explicitly handed off. Only the independent Certification Kernel may mark the Goal `VERIFIED_COMPLETE`.
