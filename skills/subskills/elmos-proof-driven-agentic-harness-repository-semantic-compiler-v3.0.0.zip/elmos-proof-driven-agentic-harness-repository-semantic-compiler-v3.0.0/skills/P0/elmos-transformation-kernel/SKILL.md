---
name: elmos-transformation-kernel
description: 以 deterministic-first、semantic-rule-driven、bounded-generative 的方式执行仓库级生成、转换、现代化和重构，形成可回滚、可重放、可验证的 ChangeGraph。
version: 3.0.0
priority: P0
kind: kernel
---

# Transformation Kernel

**Skill ID:** `ELMOS-V3-005`  
**Route owner:** `K5`  
**Release:** `elmos-v3.0.0`

## Purpose

以 deterministic-first、semantic-rule-driven、bounded-generative 的方式执行仓库级生成、转换、现代化和重构，形成可回滚、可重放、可验证的 ChangeGraph。

This is a v3 routable capability. It owns or coordinates a defined canonical boundary; it must not be replaced by an ad-hoc agent prompt or a legacy skill executing as an independent control plane.

## Responsibilities

- 把 transformation plan 编译为依赖感知、可分片、可重试、可补偿的 ChangeGraph。
- 优先使用 compiler rewrite、codemod、recipe、schema migration 和模板生成；LLM 只处理规则选择、缺口和例外。
- 每个规则声明 precondition/postcondition/semantic preservation/evidence requirements/rollback。
- 使用隔离 worktree/workspace、patch lineage、semantic conflict detection 和 deterministic fixpoint。
- 支持 parallel units、merge queue、冲突重规划、partial commit、strangler/dual-run/canary/cutover。
- 任何变换都关联所影响的 Proof Obligations 和待执行 Validation DAG。

## Inputs

- approved transformation plan
- Repository Semantic IR
- domain pack
- proof obligations

All mutable inputs must resolve to immutable revisions before execution. Tenant, Goal, Run, Execution Epoch and Environment Authority are mandatory runtime context.

## Outputs

- ChangeGraph
- candidate repository revisions
- patch lineage
- rule evidence
- rollback/cutover plan

Outputs are artifacts with content hashes, lineage, schema version, producer identity, environment/tool digest and evidence classification.

## Internal components

- `TransformationPlanner`
- `RuleRegistry`
- `RulePreservationContract`
- `DeterministicRecipeEngine`
- `BoundedGenerativeTransformer`
- `ChangeGraph`
- `WorktreeCoordinator`
- `SemanticMergeEngine`
- `FixpointController`
- `DataMigrationPlanner`
- `CutoverRollbackPlanner`
- `TransformationCache`

Components are implementation modules, not separately routable skills unless a future version assigns an explicit canonical owner and migration.

## Workflow

1. Validate invocation, tenant, exact Revision Set, authority and budget.
2. Load prerequisites and content-addressed artifacts.
3. Compile a versioned workflow fragment and idempotency plan.
4. Execute only ready nodes; record events and artifacts transactionally.
5. Emit/refine affected Proof Obligations.
6. Run validation or request the required downstream kernel.
7. Stop on refutation, stale authority, ambiguous side effect, budget breach or no-progress.
8. Return a structured result; never use free-text completion as terminal truth.

## Verification

- `rule_preconditions_met`
- `change_lineage_complete`
- `unresolved_semantic_conflicts_zero`
- `deterministic_fixpoint_or_bounded_exception`
- `candidate_revision_frozen`

Critical gates require immutable evidence. Model judgment alone is not accepted as authoritative evidence.

## Dependencies

- `elmos-repository-semantic-compiler-kernel`
- `elmos-agentic-reasoning-kernel`
- `elmos-harness-runtime-kernel`

Dependency versions are pinned through the Goal Revision Set; runtime discovery cannot silently change them.

## Security and authority

- deny by default;
- Environment/Attachment-owned authority;
- tenant-scoped paths, cache and evidence;
- no secret value in prompts, logs or artifacts;
- path/parameter/side-effect policy evaluation;
- lease generation and fencing on every authoritative commit;
- external side effects use idempotency and reconciliation.

## Observability and FinOps

- `deterministic_change_ratio`
- `first_pass_compile_rate`
- `semantic_conflict_rate`
- `repair_edit_locality`
- `rollback_readiness`

Every span includes tenant, goal, run, epoch, kernel/skill, workflow node, workspace, model/tool, proof obligation and cost attribution where applicable.

## Stop and escalate

Stop with a typed status when:

- required semantics or verifier is unsupported;
- a critical result is `REFUTED_WITH_COUNTEREXAMPLE`;
- required proof is unknown or resource-limited;
- authority, policy, evidence or revision binding cannot be resolved;
- repeated repairs make no measurable obligation progress;
- external side-effect result is unknown;
- human approval is required by policy.

Escalation must include the smallest reproducible artifact bundle, affected obligations, candidate options, residual risks and machine ETA/cost impact.

## Definition of done

This skill is done only when its own hard gates pass, its outputs are durably committed and all downstream obligations it owns are closed or explicitly handed off. Only the independent Certification Kernel may mark the Goal `VERIFIED_COMPLETE`.
