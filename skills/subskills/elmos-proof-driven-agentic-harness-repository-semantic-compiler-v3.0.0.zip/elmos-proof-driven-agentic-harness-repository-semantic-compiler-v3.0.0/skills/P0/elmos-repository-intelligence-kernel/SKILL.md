---
name: elmos-repository-intelligence-kernel
description: 以只读、增量、证据优先方式重建仓库的结构、依赖、运行行为、数据、协议、安全与业务能力图谱，为推理和变换提供可查询事实层。
version: 3.0.0
priority: P0
kind: kernel
---

# Repository Intelligence Kernel

**Skill ID:** `ELMOS-V3-002`  
**Route owner:** `K2`  
**Release:** `elmos-v3.0.0`

## Purpose

以只读、增量、证据优先方式重建仓库的结构、依赖、运行行为、数据、协议、安全与业务能力图谱，为推理和变换提供可查询事实层。

This is a v3 routable capability. It owns or coordinates a defined canonical boundary; it must not be replaced by an ad-hoc agent prompt or a legacy skill executing as an independent control plane.

## Responsibilities

- 构建 file/module/build/symbol/type/call/data/control/effect/config/runtime/deployment 图。
- 关联代码、测试、API、SQL、消息、配置、日志、trace、UI 和外部服务形成 Repository Evidence Graph。
- 识别 dead code、dynamic boundary、reflection/FFI、生成代码、宏、插件、条件编译和运行时发现机制。
- 执行源代码与构建环境指纹、许可证、供应链、密钥、漏洞和所有权分析。
- 支持增量 invalidation、shard、内容寻址缓存与百万文件规模。
- 所有推断保存 provenance、confidence、counterevidence 和 freshness。

## Inputs

- immutable repository snapshot
- Environment IR
- build metadata
- optional runtime traces/traffic/logs

All mutable inputs must resolve to immutable revisions before execution. Tenant, Goal, Run, Execution Epoch and Environment Authority are mandatory runtime context.

## Outputs

- Repository Evidence Graph
- Capability Ledger
- Impact Graph
- Dynamic Boundary Register
- Risk Map
- Baseline Reproducibility Record

Outputs are artifacts with content hashes, lineage, schema version, producer identity, environment/tool digest and evidence classification.

## Internal components

- `RepositorySnapshotter`
- `BuildSystemDetector`
- `SymbolGraphBuilder`
- `TypeGraphBuilder`
- `CallAndDataFlowGraphBuilder`
- `ConfigurationGraphBuilder`
- `DataAndMessageGraphBuilder`
- `RuntimeTraceIngestor`
- `CapabilityLedger`
- `DynamicBoundaryDetector`
- `RepositoryRiskMap`
- `IncrementalInvalidationEngine`

Components are implementation modules, not separately routable skills unless a future version assigns an explicit canonical owner and migration.

## Workflow

1. Validate invocation, tenant, exact Revision Set, authority and budget.
2. Load prerequisites and content-addressed artifacts.
3. Compile a versioned workflow fragment and idempotency plan.
4. Execute only ready nodes; record events and artifacts transactionally.
5. Emit/refine affected Proof Obligations.
6. Run validation or request the required downstream kernel.
7. Stop on refutation, stale authority, ambiguous side effect, budget breach or no-progress.
8. Return a structured result; never use free-text completion as terminal truth.

## Verification

- `snapshot_integrity`
- `baseline_build_classified`
- `critical_graph_completeness`
- `dynamic_boundaries_declared`
- `evidence_provenance_complete`

Critical gates require immutable evidence. Model judgment alone is not accepted as authoritative evidence.

## Dependencies

- `elmos-goal-specification-kernel`

Dependency versions are pinned through the Goal Revision Set; runtime discovery cannot silently change them.

## Security and authority

- deny by default;
- Environment/Attachment-owned authority;
- tenant-scoped paths, cache and evidence;
- no secret value in prompts, logs or artifacts;
- path/parameter/side-effect policy evaluation;
- lease generation and fencing on every authoritative commit;
- external side effects use idempotency and reconciliation.

## Observability and FinOps

- `graph_coverage`
- `symbol_resolution_rate`
- `type_attribution_rate`
- `dynamic_boundary_recall`
- `incremental_reanalysis_ratio`

Every span includes tenant, goal, run, epoch, kernel/skill, workflow node, workspace, model/tool, proof obligation and cost attribution where applicable.

## Stop and escalate

Stop with a typed status when:

- required semantics or verifier is unsupported;
- a critical result is `REFUTED_WITH_COUNTEREXAMPLE`;
- required proof is unknown or resource-limited;
- authority, policy, evidence or revision binding cannot be resolved;
- repeated repairs make no measurable obligation progress;
- external side-effect result is unknown;
- human approval is required by policy.

Escalation must include the smallest reproducible artifact bundle, affected obligations, candidate options, residual risks and machine ETA/cost impact.

## Definition of done

This skill is done only when its own hard gates pass, its outputs are durably committed and all downstream obligations it owns are closed or explicitly handed off. Only the independent Certification Kernel may mark the Goal `VERIFIED_COMPLETE`.
