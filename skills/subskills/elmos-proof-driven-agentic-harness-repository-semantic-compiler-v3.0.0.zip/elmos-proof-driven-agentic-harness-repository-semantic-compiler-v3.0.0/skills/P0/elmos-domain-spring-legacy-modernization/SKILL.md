---
name: elmos-domain-spring-legacy-modernization
description: Struts 1、Struts 2、原生 Servlet 及混合遗留 Java Web 仓库到 Spring Boot 4 的语义保持现代化。
version: 3.0.0
priority: P0
kind: domain-pack
---

# Spring Legacy Modernization Domain Pack

**Skill ID:** `ELMOS-V3-009`  
**Route owner:** `spring-modernization`  
**Release:** `elmos-v3.0.0`

## Purpose

Struts 1、Struts 2、原生 Servlet 及混合遗留 Java Web 仓库到 Spring Boot 4 的语义保持现代化。

This is a v3 routable capability. It owns or coordinates a defined canonical boundary; it must not be replaced by an ad-hoc agent prompt or a legacy skill executing as an independent control plane.

## Responsibilities

- 加载并固定业务线 Semantic/Framework/Data profiles。
- 实例化该业务线的 Proof Obligation templates 和 oracle contracts。
- 提供 deterministic transformation rules、bounded repair policy 与 rollback/cutover strategy。
- 定义 E0–E5 的业务线附加门槛和 commercial Golden Route。
- 禁止业务线绕过共享 K1–K8 或自行签发完成状态。

## Inputs

- Goal Contract
- Repository Semantic IR
- Proof Obligation Graph
- Domain Pack revision

All mutable inputs must resolve to immutable revisions before execution. Tenant, Goal, Run, Execution Epoch and Environment Authority are mandatory runtime context.

## Outputs

- Domain-specific transformation plan
- domain proof obligations
- Golden Route evidence
- certification decision inputs

Outputs are artifacts with content hashes, lineage, schema version, producer identity, environment/tool digest and evidence classification.

## Internal components

- `DomainSemanticProfile`
- `ObligationTemplateSet`
- `TransformationRuleSet`
- `OracleContractSet`
- `GoldenRoute`
- `CertificationThresholds`

Components are implementation modules, not separately routable skills unless a future version assigns an explicit canonical owner and migration.

## Workflow

1. Validate invocation, tenant, exact Revision Set, authority and budget.
2. Load prerequisites and content-addressed artifacts.
3. Compile a versioned workflow fragment and idempotency plan.
4. Execute only ready nodes; record events and artifacts transactionally.
5. Emit/refine affected Proof Obligations.
6. Run validation or request the required downstream kernel.
7. Stop on refutation, stale authority, ambiguous side effect, budget breach or no-progress.
8. Return a structured result; never use free-text completion as terminal truth.

## Verification

- `baseline reproducible`
- `critical route coverage 100%`
- `security dominance preserved`
- `no unresolved P0 semantic gap`
- `dual-runtime differential within contract`
- `rollback rehearsed`

Critical gates require immutable evidence. Model judgment alone is not accepted as authoritative evidence.

## Dependencies

- `elmos-goal-specification-kernel`
- `elmos-repository-intelligence-kernel`
- `elmos-repository-semantic-compiler-kernel`
- `elmos-agentic-reasoning-kernel`
- `elmos-transformation-kernel`
- `elmos-proof-verification-kernel`
- `elmos-harness-runtime-kernel`
- `elmos-certification-kernel`

Dependency versions are pinned through the Goal Revision Set; runtime discovery cannot silently change them.

## Security and authority

- deny by default;
- Environment/Attachment-owned authority;
- tenant-scoped paths, cache and evidence;
- no secret value in prompts, logs or artifacts;
- path/parameter/side-effect policy evaluation;
- lease generation and fencing on every authoritative commit;
- external side effects use idempotency and reconciliation.

## Observability and FinOps

- `domain_critical_obligation_closure_rate`
- `domain_golden_route_pass_rate`
- `semantic_gap_escape_rate`
- `customer_acceptance_rate`

Every span includes tenant, goal, run, epoch, kernel/skill, workflow node, workspace, model/tool, proof obligation and cost attribution where applicable.

## Stop and escalate

Stop with a typed status when:

- required semantics or verifier is unsupported;
- a critical result is `REFUTED_WITH_COUNTEREXAMPLE`;
- required proof is unknown or resource-limited;
- authority, policy, evidence or revision binding cannot be resolved;
- repeated repairs make no measurable obligation progress;
- external side-effect result is unknown;
- human approval is required by policy.

Escalation must include the smallest reproducible artifact bundle, affected obligations, candidate options, residual risks and machine ETA/cost impact.

## Definition of done

This skill is done only when its own hard gates pass, its outputs are durably committed and all downstream obligations it owns are closed or explicitly handed off. Only the independent Certification Kernel may mark the Goal `VERIFIED_COMPLETE`.
