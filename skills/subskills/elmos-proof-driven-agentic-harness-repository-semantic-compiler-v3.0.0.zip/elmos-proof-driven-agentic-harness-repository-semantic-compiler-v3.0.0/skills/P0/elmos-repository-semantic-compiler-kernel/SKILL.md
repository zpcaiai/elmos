---
name: elmos-repository-semantic-compiler-kernel
description: 将多语言、多框架、多数据技术的具体程序编译为可执行、可比较、可证明的 Repository Semantic IR，并显式建模语义间隙。
version: 3.0.0
priority: P0
kind: kernel
---

# Repository Semantic Compiler Kernel

**Skill ID:** `ELMOS-V3-003`  
**Route owner:** `K3`  
**Release:** `elmos-v3.0.0`

## Purpose

将多语言、多框架、多数据技术的具体程序编译为可执行、可比较、可证明的 Repository Semantic IR，并显式建模语义间隙。

This is a v3 routable capability. It owns or coordinates a defined canonical boundary; it must not be replaced by an ad-hoc agent prompt or a legacy skill executing as an independent control plane.

## Responsibilities

- 组合 compiler-native frontend、lossless syntax tree、framework model 与 runtime evidence；禁止仅靠文本或通用 AST 充当语义权威。
- 统一表示声明、类型、值、控制流、SSA、数据流、别名、effect、异常、资源、并发、协议、状态机、事务和外部交互。
- 保持 source map、comments、formatting、generated origin、symbol identity 与 provenance。
- 建立 Language Semantic Profile、Framework Semantic Profile、SQL Semantic Profile 和 Target Runtime Profile。
- 比较 source/target profiles，生成 null/overflow/Unicode/floating/time/concurrency/exception/ownership/FFI 等 Semantic Gap Obligations。
- 支持分片、增量编译、跨模块链接、open-world 假设和精确降级状态。

## Inputs

- Repository Evidence Graph
- language/framework/toolchain profiles
- runtime evidence

All mutable inputs must resolve to immutable revisions before execution. Tenant, Goal, Run, Execution Epoch and Environment Authority are mandatory runtime context.

## Outputs

- Repository Semantic IR
- Semantic Profiles
- Semantic Gap Register
- source maps
- open-world boundary contracts

Outputs are artifacts with content hashes, lineage, schema version, producer identity, environment/tool digest and evidence classification.

## Internal components

- `FrontendRegistry`
- `LosslessSyntaxLayer`
- `CompilerSemanticBridge`
- `RepositoryLinker`
- `TypeAndEffectIR`
- `ControlDataSSA`
- `ProtocolStateMachineIR`
- `DataTransactionIR`
- `FrameworkSemanticModel`
- `SourceMapAndLineage`
- `SemanticGapAnalyzer`
- `ExecutableSemanticsRuntime`

Components are implementation modules, not separately routable skills unless a future version assigns an explicit canonical owner and migration.

## Workflow

1. Validate invocation, tenant, exact Revision Set, authority and budget.
2. Load prerequisites and content-addressed artifacts.
3. Compile a versioned workflow fragment and idempotency plan.
4. Execute only ready nodes; record events and artifacts transactionally.
5. Emit/refine affected Proof Obligations.
6. Run validation or request the required downstream kernel.
7. Stop on refutation, stale authority, ambiguous side effect, budget breach or no-progress.
8. Return a structured result; never use free-text completion as terminal truth.

## Verification

- `frontend_conformance`
- `critical_type_attribution`
- `semantic_ir_schema_valid`
- `source_map_complete`
- `semantic_gap_obligations_emitted`

Critical gates require immutable evidence. Model judgment alone is not accepted as authoritative evidence.

## Dependencies

- `elmos-repository-intelligence-kernel`

Dependency versions are pinned through the Goal Revision Set; runtime discovery cannot silently change them.

## Security and authority

- deny by default;
- Environment/Attachment-owned authority;
- tenant-scoped paths, cache and evidence;
- no secret value in prompts, logs or artifacts;
- path/parameter/side-effect policy evaluation;
- lease generation and fencing on every authoritative commit;
- external side effects use idempotency and reconciliation.

## Observability and FinOps

- `supported_construct_coverage`
- `ir_round_trip_fidelity`
- `semantic_profile_precision`
- `gap_detection_recall`
- `compiler_frontend_cache_hit_rate`

Every span includes tenant, goal, run, epoch, kernel/skill, workflow node, workspace, model/tool, proof obligation and cost attribution where applicable.

## Stop and escalate

Stop with a typed status when:

- required semantics or verifier is unsupported;
- a critical result is `REFUTED_WITH_COUNTEREXAMPLE`;
- required proof is unknown or resource-limited;
- authority, policy, evidence or revision binding cannot be resolved;
- repeated repairs make no measurable obligation progress;
- external side-effect result is unknown;
- human approval is required by policy.

Escalation must include the smallest reproducible artifact bundle, affected obligations, candidate options, residual risks and machine ETA/cost impact.

## Definition of done

This skill is done only when its own hard gates pass, its outputs are durably committed and all downstream obligations it owns are closed or explicitly handed off. Only the independent Certification Kernel may mark the Goal `VERIFIED_COMPLETE`.
