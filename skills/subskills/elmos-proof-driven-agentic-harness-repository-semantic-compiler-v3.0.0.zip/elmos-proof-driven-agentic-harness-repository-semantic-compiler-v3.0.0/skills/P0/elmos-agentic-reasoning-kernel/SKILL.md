---
name: elmos-agentic-reasoning-kernel
description: 把大模型用于最有价值的认知工作：规范恢复、假设生成、规划、引理/不变量合成、反例解释和最小修复，同时禁止模型成为最终正确性 Oracle。
version: 3.0.0
priority: P0
kind: kernel
---

# Agentic Reasoning Kernel

**Skill ID:** `ELMOS-V3-004`  
**Route owner:** `K4`  
**Release:** `elmos-v3.0.0`

## Purpose

把大模型用于最有价值的认知工作：规范恢复、假设生成、规划、引理/不变量合成、反例解释和最小修复，同时禁止模型成为最终正确性 Oracle。

This is a v3 routable capability. It owns or coordinates a defined canonical boundary; it must not be replaced by an ad-hoc agent prompt or a legacy skill executing as an independent control plane.

## Responsibilities

- 按 phase、风险、语言、上下文和历史 verified task-fit 路由模型，而不是固定单模型。
- 将 planner、spec miner、semantic reasoner、proof planner、counterexample reasoner、repair synthesizer、reviewer、adversary、verifier 分离。
- 维护 prefix-stable context、provider-native state continuity、artifact-first communication 与 structured reasoning envelope。
- 允许受控 fanout、Agent Arena、多候选竞争、独立审查和停止条件。
- 把模型结论转成 hypothesis/spec/rule/test/proof request，必须由编译器、solver、runtime 或人工权威验证。
- 对 hallucinated evidence、self-certification、authority confusion、context drift 和 reward hacking fail-closed。

## Inputs

- Goal/Spec artifacts
- Repository Semantic IR
- Proof Obligation Graph
- counterexamples and diagnostics

All mutable inputs must resolve to immutable revisions before execution. Tenant, Goal, Run, Execution Epoch and Environment Authority are mandatory runtime context.

## Outputs

- transformation hypotheses
- proof strategy
- candidate invariants/lemmas/tests
- repair plans
- review findings
- reasoning provenance

Outputs are artifacts with content hashes, lineage, schema version, producer identity, environment/tool digest and evidence classification.

## Internal components

- `RoleSeparatedAgentRuntime`
- `PhaseAwareModelRouter`
- `ModelCapabilityRegistry`
- `ContextPlanner`
- `ArtifactMailbox`
- `ProofPlanner`
- `InvariantAndLemmaSynthesizer`
- `CounterexampleReasoner`
- `RepairSynthesizer`
- `AdversarialReviewer`
- `AgentArena`
- `ReasoningProvenanceRecorder`

Components are implementation modules, not separately routable skills unless a future version assigns an explicit canonical owner and migration.

## Workflow

1. Validate invocation, tenant, exact Revision Set, authority and budget.
2. Load prerequisites and content-addressed artifacts.
3. Compile a versioned workflow fragment and idempotency plan.
4. Execute only ready nodes; record events and artifacts transactionally.
5. Emit/refine affected Proof Obligations.
6. Run validation or request the required downstream kernel.
7. Stop on refutation, stale authority, ambiguous side effect, budget breach or no-progress.
8. Return a structured result; never use free-text completion as terminal truth.

## Verification

- `role_separation`
- `no_llm_authoritative_oracle`
- `model_budget_reserved`
- `context_lineage_valid`
- `review_independence_for_critical_changes`

Critical gates require immutable evidence. Model judgment alone is not accepted as authoritative evidence.

## Dependencies

- `elmos-goal-specification-kernel`
- `elmos-repository-semantic-compiler-kernel`

Dependency versions are pinned through the Goal Revision Set; runtime discovery cannot silently change them.

## Security and authority

- deny by default;
- Environment/Attachment-owned authority;
- tenant-scoped paths, cache and evidence;
- no secret value in prompts, logs or artifacts;
- path/parameter/side-effect policy evaluation;
- lease generation and fencing on every authoritative commit;
- external side effects use idempotency and reconciliation.

## Observability and FinOps

- `verified_reasoning_yield`
- `counterexample_to_fix_rate`
- `false_completion_attempt_rate`
- `model_route_regret`
- `repair_cycles_to_closure`

Every span includes tenant, goal, run, epoch, kernel/skill, workflow node, workspace, model/tool, proof obligation and cost attribution where applicable.

## Stop and escalate

Stop with a typed status when:

- required semantics or verifier is unsupported;
- a critical result is `REFUTED_WITH_COUNTEREXAMPLE`;
- required proof is unknown or resource-limited;
- authority, policy, evidence or revision binding cannot be resolved;
- repeated repairs make no measurable obligation progress;
- external side-effect result is unknown;
- human approval is required by policy.

Escalation must include the smallest reproducible artifact bundle, affected obligations, candidate options, residual risks and machine ETA/cost impact.

## Definition of done

This skill is done only when its own hard gates pass, its outputs are durably committed and all downstream obligations it owns are closed or explicitly handed off. Only the independent Certification Kernel may mark the Goal `VERIFIED_COMPLETE`.
