---
name: elmos-commercial-operations-finops
description: 提供多租户、三并发槽、预付 credit/按项目计费、成本归因、机器 ETA、容量规划、SLO、支持与客户审计，确保技术闭环可以商业运营。
version: 3.0.0
priority: P0
kind: cross-cutting
---

# Commercial Operations / FinOps

**Skill ID:** `ELMOS-V3-016`  
**Route owner:** `platform`  
**Release:** `elmos-v3.0.0`

## Purpose

提供多租户、三并发槽、预付 credit/按项目计费、成本归因、机器 ETA、容量规划、SLO、支持与客户审计，确保技术闭环可以商业运营。

This is a v3 routable capability. It owns or coordinates a defined canonical boundary; it must not be replaced by an ad-hoc agent prompt or a legacy skill executing as an independent control plane.

## Responsibilities

- 提供多租户、三并发槽、预付 credit/按项目计费、成本归因、机器 ETA、容量规划、SLO、支持与客户审计，确保技术闭环可以商业运营。
- 作为共享服务运行，不覆盖 K1–K8 的 canonical ownership。
- 所有结果进入 immutable evidence 和 audit lineage。

## Inputs

- Goal/Run/Revision context
- Evidence and metrics
- policy and budget

All mutable inputs must resolve to immutable revisions before execution. Tenant, Goal, Run, Execution Epoch and Environment Authority are mandatory runtime context.

## Outputs

- governance decisions
- evaluation evidence
- commercial operations records

Outputs are artifacts with content hashes, lineage, schema version, producer identity, environment/tool digest and evidence classification.

## Internal components

- `TenantQuota`
- `CreditReservation`
- `UsageLedger`
- `PricingPolicy`
- `MachineEta`
- `CapacityPlanner`
- `SLOManager`
- `CustomerAuditPortal`

Components are implementation modules, not separately routable skills unless a future version assigns an explicit canonical owner and migration.

## Workflow

1. Validate invocation, tenant, exact Revision Set, authority and budget.
2. Load prerequisites and content-addressed artifacts.
3. Compile a versioned workflow fragment and idempotency plan.
4. Execute only ready nodes; record events and artifacts transactionally.
5. Emit/refine affected Proof Obligations.
6. Run validation or request the required downstream kernel.
7. Stop on refutation, stale authority, ambiguous side effect, budget breach or no-progress.
8. Return a structured result; never use free-text completion as terminal truth.

## Verification

- `tenant_scope_valid`
- `evidence_provenance_complete`
- `policy_decision_recorded`

Critical gates require immutable evidence. Model judgment alone is not accepted as authoritative evidence.

## Dependencies

- `elmos-goal-specification-kernel`
- `elmos-repository-intelligence-kernel`
- `elmos-repository-semantic-compiler-kernel`
- `elmos-agentic-reasoning-kernel`
- `elmos-transformation-kernel`
- `elmos-proof-verification-kernel`
- `elmos-harness-runtime-kernel`
- `elmos-certification-kernel`

Dependency versions are pinned through the Goal Revision Set; runtime discovery cannot silently change them.

## Security and authority

- deny by default;
- Environment/Attachment-owned authority;
- tenant-scoped paths, cache and evidence;
- no secret value in prompts, logs or artifacts;
- path/parameter/side-effect policy evaluation;
- lease generation and fencing on every authoritative commit;
- external side effects use idempotency and reconciliation.

## Observability and FinOps

- `verified_outcome_rate`
- `governance_escape_rate`
- `cost_reconciliation_rate`
- `operational_slo`

Every span includes tenant, goal, run, epoch, kernel/skill, workflow node, workspace, model/tool, proof obligation and cost attribution where applicable.

## Stop and escalate

Stop with a typed status when:

- required semantics or verifier is unsupported;
- a critical result is `REFUTED_WITH_COUNTEREXAMPLE`;
- required proof is unknown or resource-limited;
- authority, policy, evidence or revision binding cannot be resolved;
- repeated repairs make no measurable obligation progress;
- external side-effect result is unknown;
- human approval is required by policy.

Escalation must include the smallest reproducible artifact bundle, affected obligations, candidate options, residual risks and machine ETA/cost impact.

## Definition of done

This skill is done only when its own hard gates pass, its outputs are durably committed and all downstream obligations it owns are closed or explicitly handed off. Only the independent Certification Kernel may mark the Goal `VERIFIED_COMPLETE`.
