---
name: elmos-proof-verification-kernel
description: 为每个 Proof Obligation 选择独立、组合式 verifier portfolio，运行静态、动态、差分、属性、形式化和非功能验证，并把反例反馈给修复闭环。
version: 3.0.0
priority: P0
kind: kernel
---

# Proof & Verification Kernel

**Skill ID:** `ELMOS-V3-006`  
**Route owner:** `K6`  
**Release:** `elmos-v3.0.0`

## Purpose

为每个 Proof Obligation 选择独立、组合式 verifier portfolio，运行静态、动态、差分、属性、形式化和非功能验证，并把反例反馈给修复闭环。

This is a v3 routable capability. It owns or coordinates a defined canonical boundary; it must not be replaced by an ad-hoc agent prompt or a legacy skill executing as an independent control plane.

## Responsibilities

- Proof Obligation Graph 是运行时一级对象；明确 subject、claim、assumptions、scope、dependencies、required assurance 和 accepted evidence classes。
- 执行 compiler/static analysis、contract/property/metamorphic/mutation/fuzz、differential runtime、symbolic execution、SMT、model checking、proof assistant、security/performance/resilience。
- 采用 translation validation：对每次具体转换验证，而非盲目信任生成器。
- 对 repository-level proof 使用 assume–guarantee、compositional refinement 与 open-world boundary monitoring。
- 所有 verifier 使用固定 tool digest、input hash、timeout/resource limit、trusted computing base 与可复现环境。
- 将 counterexample 最小化、归因并转为回归测试；UNKNOWN/UNSUPPORTED 不得被包装为通过。

## Inputs

- candidate revision
- proof obligations
- source/target semantic IR
- environment and oracle contracts

All mutable inputs must resolve to immutable revisions before execution. Tenant, Goal, Run, Execution Epoch and Environment Authority are mandatory runtime context.

## Outputs

- Proof Results
- counterexamples
- regression tests
- coverage map
- assurance report

Outputs are artifacts with content hashes, lineage, schema version, producer identity, environment/tool digest and evidence classification.

## Internal components

- `ProofObligationGraph`
- `VerifierPortfolioRouter`
- `StaticVerificationPipeline`
- `DifferentialExecutionEngine`
- `PropertyMetamorphicFuzzEngine`
- `SymbolicAndSMTEngine`
- `ModelCheckingEngine`
- `ProofAssistantBridge`
- `NonFunctionalVerification`
- `CounterexampleMinimizer`
- `CounterexampleToTest`
- `ProofCacheAndDriftInvalidator`

Components are implementation modules, not separately routable skills unless a future version assigns an explicit canonical owner and migration.

## Workflow

1. Validate invocation, tenant, exact Revision Set, authority and budget.
2. Load prerequisites and content-addressed artifacts.
3. Compile a versioned workflow fragment and idempotency plan.
4. Execute only ready nodes; record events and artifacts transactionally.
5. Emit/refine affected Proof Obligations.
6. Run validation or request the required downstream kernel.
7. Stop on refutation, stale authority, ambiguous side effect, budget breach or no-progress.
8. Return a structured result; never use free-text completion as terminal truth.

## Verification

- `all_required_verifiers_executed_or_explicit_status`
- `authoritative_oracles_independent`
- `critical_refutations_zero`
- `unknown_policy_applied`
- `proof_evidence_immutable`

Critical gates require immutable evidence. Model judgment alone is not accepted as authoritative evidence.

## Dependencies

- `elmos-repository-semantic-compiler-kernel`
- `elmos-harness-runtime-kernel`

Dependency versions are pinned through the Goal Revision Set; runtime discovery cannot silently change them.

## Security and authority

- deny by default;
- Environment/Attachment-owned authority;
- tenant-scoped paths, cache and evidence;
- no secret value in prompts, logs or artifacts;
- path/parameter/side-effect policy evaluation;
- lease generation and fencing on every authoritative commit;
- external side effects use idempotency and reconciliation.

## Observability and FinOps

- `critical_obligation_closure_rate`
- `counterexample_discovery_rate`
- `mutation_score`
- `differential_scenario_coverage`
- `proof_reuse_validity`

Every span includes tenant, goal, run, epoch, kernel/skill, workflow node, workspace, model/tool, proof obligation and cost attribution where applicable.

## Stop and escalate

Stop with a typed status when:

- required semantics or verifier is unsupported;
- a critical result is `REFUTED_WITH_COUNTEREXAMPLE`;
- required proof is unknown or resource-limited;
- authority, policy, evidence or revision binding cannot be resolved;
- repeated repairs make no measurable obligation progress;
- external side-effect result is unknown;
- human approval is required by policy.

Escalation must include the smallest reproducible artifact bundle, affected obligations, candidate options, residual risks and machine ETA/cost impact.

## Definition of done

This skill is done only when its own hard gates pass, its outputs are durably committed and all downstream obligations it owns are closed or explicitly handed off. Only the independent Certification Kernel may mark the Goal `VERIFIED_COMPLETE`.
