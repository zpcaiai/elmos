---
name: elmos-certification-kernel
description: 由独立于生成与修复 Agent 的 Certifier 对精确 Revision Set、Proof Obligation closure、E0–E5、部署证据和商业 Golden Route 证据签发不可伪造的 Completion Certificate。
version: 3.0.0
priority: P0
kind: kernel
---

# Certification Kernel

**Skill ID:** `ELMOS-V3-008`  
**Route owner:** `K8`  
**Release:** `elmos-v3.0.0`

## Purpose

由独立于生成与修复 Agent 的 Certifier 对精确 Revision Set、Proof Obligation closure、E0–E5、部署证据和商业 Golden Route 证据签发不可伪造的 Completion Certificate。

This is a v3 routable capability. It owns or coordinates a defined canonical boundary; it must not be replaced by an ad-hoc agent prompt or a legacy skill executing as an independent control plane.

## Responsibilities

- 定义 canonical proof statuses，禁止把 bounded、unknown、runtime monitored 或 waiver 显示成 unbounded proof。
- 把 E0–E5、P05、domain gates、evidence freshness、revocation、coverage 和 side-effect settlement 组成 independent stop gate。
- 对 certificate 固定 exact revision set、policy bundle、toolchain digest、TCB、assumptions、waivers、evidence Merkle root 和 signer。
- 支持 certified envelope、assurance level、expiry、drift invalidation、re-certification、customer acceptance 和 audit export。
- 防止 Agent says done、测试数量膨胀、LLM judge、空证据、旧证据复用和 status inflation。
- 输出面向工程、管理、客户、合规和保险/审计场景的分层报告。

## Inputs

- sealed evidence bundle
- proof results
- revision set
- gate decisions
- customer acceptance

All mutable inputs must resolve to immutable revisions before execution. Tenant, Goal, Run, Execution Epoch and Environment Authority are mandatory runtime context.

## Outputs

- Completion Certificate
- Certification Report
- unresolved risk ledger
- re-certification trigger

Outputs are artifacts with content hashes, lineage, schema version, producer identity, environment/tool digest and evidence classification.

## Internal components

- `IndependentStopGate`
- `ProofStatusPolicy`
- `E0E5GateEvaluator`
- `P05DeploymentGate`
- `EvidenceBundleSealer`
- `CompletionCertificateSigner`
- `CertifiedEnvelopeRegistry`
- `WaiverGovernance`
- `DriftAndRevocationMonitor`
- `CommercialGoldenRouteCertifier`
- `AssuranceReportGenerator`
- `AuditExport`

Components are implementation modules, not separately routable skills unless a future version assigns an explicit canonical owner and migration.

## Workflow

1. Validate invocation, tenant, exact Revision Set, authority and budget.
2. Load prerequisites and content-addressed artifacts.
3. Compile a versioned workflow fragment and idempotency plan.
4. Execute only ready nodes; record events and artifacts transactionally.
5. Emit/refine affected Proof Obligations.
6. Run validation or request the required downstream kernel.
7. Stop on refutation, stale authority, ambiguous side effect, budget breach or no-progress.
8. Return a structured result; never use free-text completion as terminal truth.

## Verification

- `certifier_independent`
- `revision_binding_exact`
- `critical_obligations_closed`
- `E0_E5_pass`
- `P05_pass_for_prod`
- `evidence_bundle_sealed`
- `side_effects_settled`

Critical gates require immutable evidence. Model judgment alone is not accepted as authoritative evidence.

## Dependencies

- `elmos-goal-specification-kernel`
- `elmos-proof-verification-kernel`
- `elmos-harness-runtime-kernel`

Dependency versions are pinned through the Goal Revision Set; runtime discovery cannot silently change them.

## Security and authority

- deny by default;
- Environment/Attachment-owned authority;
- tenant-scoped paths, cache and evidence;
- no secret value in prompts, logs or artifacts;
- path/parameter/side-effect policy evaluation;
- lease generation and fencing on every authoritative commit;
- external side effects use idempotency and reconciliation.

## Observability and FinOps

- `false_certification_rate`
- `certificate_reproducibility`
- `stale_evidence_rejection_rate`
- `golden_route_pass_rate`
- `post_certification_escape_rate`

Every span includes tenant, goal, run, epoch, kernel/skill, workflow node, workspace, model/tool, proof obligation and cost attribution where applicable.

## Stop and escalate

Stop with a typed status when:

- required semantics or verifier is unsupported;
- a critical result is `REFUTED_WITH_COUNTEREXAMPLE`;
- required proof is unknown or resource-limited;
- authority, policy, evidence or revision binding cannot be resolved;
- repeated repairs make no measurable obligation progress;
- external side-effect result is unknown;
- human approval is required by policy.

Escalation must include the smallest reproducible artifact bundle, affected obligations, candidate options, residual risks and machine ETA/cost impact.

## Definition of done

This skill is done only when its own hard gates pass, its outputs are durably committed and all downstream obligations it owns are closed or explicitly handed off. Only the independent Certification Kernel may mark the Goal `VERIFIED_COMPLETE`.
