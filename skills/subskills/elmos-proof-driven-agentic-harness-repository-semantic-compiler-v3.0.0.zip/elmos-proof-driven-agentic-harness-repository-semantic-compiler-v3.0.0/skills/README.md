# V3 Routable Skills Index

Only these 16 capabilities are routable in v3. Internal components and legacy aliases cannot independently own workflow state or certification.

| ID | Priority | Kind | Skill | Purpose |
|---|---|---|---|---|
| ELMOS-V3-001 | P0 | kernel | [`elmos-goal-specification-kernel`](P0/elmos-goal-specification-kernel/SKILL.md) | 把自然语言目标、存量规范、约束、预算和验收标准编译为版本化、可执行、可证明的 Goal Contract、Observable Contract、Requirement Graph 与 Revision Set。 |
| ELMOS-V3-002 | P0 | kernel | [`elmos-repository-intelligence-kernel`](P0/elmos-repository-intelligence-kernel/SKILL.md) | 以只读、增量、证据优先方式重建仓库的结构、依赖、运行行为、数据、协议、安全与业务能力图谱，为推理和变换提供可查询事实层。 |
| ELMOS-V3-003 | P0 | kernel | [`elmos-repository-semantic-compiler-kernel`](P0/elmos-repository-semantic-compiler-kernel/SKILL.md) | 将多语言、多框架、多数据技术的具体程序编译为可执行、可比较、可证明的 Repository Semantic IR，并显式建模语义间隙。 |
| ELMOS-V3-004 | P0 | kernel | [`elmos-agentic-reasoning-kernel`](P0/elmos-agentic-reasoning-kernel/SKILL.md) | 把大模型用于最有价值的认知工作：规范恢复、假设生成、规划、引理/不变量合成、反例解释和最小修复，同时禁止模型成为最终正确性 Oracle。 |
| ELMOS-V3-005 | P0 | kernel | [`elmos-transformation-kernel`](P0/elmos-transformation-kernel/SKILL.md) | 以 deterministic-first、semantic-rule-driven、bounded-generative 的方式执行仓库级生成、转换、现代化和重构，形成可回滚、可重放、可验证的 ChangeGraph。 |
| ELMOS-V3-006 | P0 | kernel | [`elmos-proof-verification-kernel`](P0/elmos-proof-verification-kernel/SKILL.md) | 为每个 Proof Obligation 选择独立、组合式 verifier portfolio，运行静态、动态、差分、属性、形式化和非功能验证，并把反例反馈给修复闭环。 |
| ELMOS-V3-007 | P0 | kernel | [`elmos-harness-runtime-kernel`](P0/elmos-harness-runtime-kernel/SKILL.md) | 提供长任务、多 Agent、多工作区、多模型、多工具的 durable execution substrate，把权限、运行状态、来源、策略和生命周期绑定到具体 Environment/Attachment。 |
| ELMOS-V3-008 | P0 | kernel | [`elmos-certification-kernel`](P0/elmos-certification-kernel/SKILL.md) | 由独立于生成与修复 Agent 的 Certifier 对精确 Revision Set、Proof Obligation closure、E0–E5、部署证据和商业 Golden Route 证据签发不可伪造的 Completion Certificate。 |
| ELMOS-V3-009 | P0 | domain-pack | [`elmos-domain-spring-legacy-modernization`](P0/elmos-domain-spring-legacy-modernization/SKILL.md) | Struts 1、Struts 2、原生 Servlet 及混合遗留 Java Web 仓库到 Spring Boot 4 的语义保持现代化。 |
| ELMOS-V3-010 | P0 | domain-pack | [`elmos-domain-cross-language-conversion`](P0/elmos-domain-cross-language-conversion/SKILL.md) | Java、Kotlin、Python、C#、Go、Rust、C/C++、PHP、TypeScript/JavaScript、Objective-C、Swift、Dart/Flutter 等仓库级跨语言/框架转换。 |
| ELMOS-V3-011 | P0 | domain-pack | [`elmos-domain-multi-language-project-generation`](P0/elmos-domain-multi-language-project-generation/SKILL.md) | 从需求、多模态材料、现有系统契约或产品原型生成完整、可部署、可运维、多语言项目。 |
| ELMOS-V3-012 | P0 | domain-pack | [`elmos-domain-sql-dialect-routine-conversion`](P0/elmos-domain-sql-dialect-routine-conversion/SKILL.md) | SQL dialect、DDL/DML、query、procedure/function/package/trigger 与事务语义的数据库间转换。 |
| ELMOS-V3-013 | P0 | domain-pack | [`elmos-domain-repository-refactoring`](P0/elmos-domain-repository-refactoring/SKILL.md) | 跨文件、跨模块、跨服务的架构重构、依赖升级、模块拆分/合并、API 演进、并发/性能/安全改造。 |
| ELMOS-V3-014 | P0 | cross-cutting | [`elmos-evaluation-trust-gate`](P0/elmos-evaluation-trust-gate/SKILL.md) | 把 46,664 条既有 ETGB 测试基线、隐藏集治理、统计有效性、mutation/fuzz、性能、恢复、安全和发布完整性统一为 v3 的独立质量数据平面。 |
| ELMOS-V3-015 | P1 | cross-cutting | [`elmos-self-improvement-governance`](P1/elmos-self-improvement-governance/SKILL.md) | 把失败→反例→修复→回归→规则候选→独立 holdout→审批→灰度→回滚形成受控自进化闭环，禁止模型直接修改生产 Skill/Policy/Harness。 |
| ELMOS-V3-016 | P0 | cross-cutting | [`elmos-commercial-operations-finops`](P0/elmos-commercial-operations-finops/SKILL.md) | 提供多租户、三并发槽、预付 credit/按项目计费、成本归因、机器 ETA、容量规划、SLO、支持与客户审计，确保技术闭环可以商业运营。 |

## Routing rule

```text
User goal
  → K1 Goal/Specification
  → applicable Domain Pack
  → K2–K7 execution
  → K8 certification
```

Cross-cutting skills may be invoked by the workflow but cannot replace a kernel owner.
