# Runbook — Verified Self-Improvement Governance

## Preflight

1. Resolve tenant, Goal, Run, Execution Epoch and exact Revision Set.
2. Verify current lease/fencing and Environment Authority.
3. Confirm required adapters/tools and their signed digests.
4. Reserve model/tool/compute budget and calculate machine ETA.
5. Confirm artifact/evidence stores and transactional outbox are healthy.

## Normal operation

- Start through Workflow IR, never by invoking an internal component directly.
- Use immutable artifacts for handoff.
- Update Proof Obligation states only with typed evidence.
- Emit OTel traces and usage ledger events.
- Checkpoint before expensive, side-effecting or authority-changing nodes.

## Common failure classes

| Failure | Required response |
|---|---|
| stale lease/fencing | reject write, reacquire through scheduler |
| verifier timeout/resource limit | preserve `UNKNOWN_*`, route alternate strategy or escalate |
| counterexample | minimize, create regression test, repair affected cone |
| ambiguous external side effect | block, reconcile externally, never blind retry |
| semantic frontend unsupported | mark scope `UNSUPPORTED`, use approved fallback or narrow envelope |
| model/provider loss | restore provider state if trustworthy; otherwise fork with explicit information-loss record |
| evidence drift/revocation | invalidate dependent proof/cache and re-run required gates |
| budget pressure | checkpoint, replan, request approval or terminate with partial evidence |

## Recovery

Recovery reads the authoritative database journal, verifies artifact hashes and starts a new execution attempt with a new lease generation. Process memory and chat summaries are never considered recovery truth.

## Rollback

Deactivate the immutable skill version in the registry, restore the previous routing revision and invalidate certificates that depend on incompatible semantics/policy/toolchain. Never delete historical evidence.

## Escalation bundle

Include Goal/Revision Set, affected workflow nodes, authority revision, proof obligations, minimized counterexamples, logs/traces, cost/ETA delta, options and residual risk.

## Completion check

The runbook cannot declare the Goal complete. It confirms only this skill's outputs and hard gates; K8 evaluates final certification.
