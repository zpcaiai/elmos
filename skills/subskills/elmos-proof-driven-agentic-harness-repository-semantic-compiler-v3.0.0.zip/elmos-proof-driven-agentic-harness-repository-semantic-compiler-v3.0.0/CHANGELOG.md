# Changelog

## 3.0.0 — 2026-08-28

- Replaced independent capability stacking with one 8-kernel architecture.
- Added Proof Obligation Graph as the scheduling and completion backbone.
- Unified Agentic reasoning, Repository Semantic Compiler, formal/differential verification, Harness runtime and independent certification.
- Consolidated 115 legacy skills into 16 routable v3 capabilities with complete compatibility mapping.
- Added five Domain Packs and commercial Golden Routes.
- Added Environment-owned authority, execution provenance, timeline, lease/fencing and side-effect reconciliation.
- Added 15 language, 9 framework, 20 verifier and 7 harness adapter contracts.
- Added PostgreSQL 17, RLS, append-only evidence, FinOps and controlled learning model.
- Embedded the 46,664-case ETGB v1.1 evaluation data plane.
- Added executable reference kernel, tests, APIs, policies, deployment and observability.
