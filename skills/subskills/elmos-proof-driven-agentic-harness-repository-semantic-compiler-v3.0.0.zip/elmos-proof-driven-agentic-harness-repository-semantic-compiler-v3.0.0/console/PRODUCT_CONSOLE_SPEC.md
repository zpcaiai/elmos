# Elmos V3 Product Console Specification

## Primary navigation

1. **Portfolio** — projects, business lines, certified outcomes, cost/revenue and SLO.
2. **Goals** — objective, observable contract, assumptions, revisions, budget and machine ETA.
3. **Repository Intelligence** — architecture, dependency, capability, data, protocol and risk graphs.
4. **Semantic IR** — language/framework coverage, unsupported constructs and semantic gaps.
5. **Proof Center** — Proof Obligation Graph, verifier portfolio, counterexamples, assumptions and status lattice.
6. **Transformation Studio** — ChangeGraph, worktrees, rules, patches, conflicts, repair history and rollback.
7. **Runtime** — environments, authority, sessions, tools, leases/fencing, checkpoints and side effects.
8. **Certification** — E0–E5/P05, evidence bundle, certificate, expiry/revocation and customer acceptance.
9. **Evaluation / Gym** — ETGB, hidden holdout, benchmark integrity, failure→repair and candidate promotion.
10. **FinOps / Admin** — credits, pricing, usage, capacity, tenants, policies, adapters, releases and audit.

## Goal page

Top strip:
- Goal state;
- certification target;
- critical closure numerator/denominator;
- machine ETA range;
- posted/reserved/projected cost;
- current exact revision;
- latest checkpoint;
- stop/cancel/pause controls.

Tabs:
- Contract;
- Architecture;
- Semantic Coverage;
- Proof Graph;
- Changes;
- Tests/Runtime Diff;
- Security/Performance;
- Cost/ETA;
- Evidence/Certificate;
- Timeline/Audit.

## Proof Center behavior

The UI must not collapse status into green/red. It shows:
- exact proof status;
- scope and supported fragment;
- assumptions;
- verifier/tool/encoder/environment digests;
- bounds/timeout;
- evidence and reproducer;
- dependencies and invalidation;
- accepted/blocked reason.

`BOUNDED_NO_COUNTEREXAMPLE` uses distinct language from `PROVED_*`. Waivers remain visible.

## Human control

Approvals are scoped by action hash, path/resource, amount, expiry and nonce. Approval never grants broad ambient authority. Realtime steering produces a revisioned command and impact preview.

## Large-repository experience

Graphs and diffs are sharded and progressively loaded. The UI defaults to affected cones, critical obligations and unresolved semantic gaps rather than rendering the entire repository at once.

## Accessibility and auditability

Keyboard navigation, WCAG-oriented labels, deterministic URLs for artifacts/obligations, exportable evidence, and no critical state conveyed solely by color.
