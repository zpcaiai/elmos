import httpx

BASE = "http://localhost:8080"
payload = {
    "project_id": "00000000-0000-0000-0000-000000000001",
    "objective": "Create a deterministic demo task"
}
r = httpx.post(f"{BASE}/v1/tasks", json=payload, timeout=30)
r.raise_for_status()
task = r.json()
print("created:", task)

r = httpx.get(f"{BASE}/v1/tasks/{task['task_id']}", timeout=30)
r.raise_for_status()
print("read:", r.json())
