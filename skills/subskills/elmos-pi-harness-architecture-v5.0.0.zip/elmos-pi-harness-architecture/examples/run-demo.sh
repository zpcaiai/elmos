#!/usr/bin/env sh
set -eu
python examples/e2e_demo.py
