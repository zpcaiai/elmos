package ai.elmos.demo;

import javax.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
public class DemoController {
    @PostMapping("/hello")
    public String hello(@Valid @RequestBody String name) {
        return "hello " + name;
    }
}
