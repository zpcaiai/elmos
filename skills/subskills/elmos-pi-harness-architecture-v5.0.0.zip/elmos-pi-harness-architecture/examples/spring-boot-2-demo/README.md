# Spring Boot 2 demo

Purpose:
- prove deterministic Jakarta namespace migration,
- exercise the Golden Route workflow,
- produce baseline and post-migration evidence.

This demo is intentionally small. It is not a substitute for >500k / >1M LOC certification.
