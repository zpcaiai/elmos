---
name: elmos-pi-harness-architecture
description: >
  Execution Kernel Convergence Edition. Integrates durable ownership, typed context,
  timeline/artifacts, runtime connection state, policy/effects, interrupt lifecycle,
  and evidence execution into a single production-grade Harness Runtime Kernel.
version: 5.0.0
license: Proprietary
---

# Elmos Pi Harness Architecture — Execution Kernel Convergence Edition

## Objective

v5.0 converges the previously separate evidence runtime and upstream Harness-native SPIs
into one production execution kernel.

## Canonical model

`Execution = Identity + Ownership + TypedContext + Timeline + Artifacts + RuntimeState + Policy + Lifecycle + Effects + Evidence`

## New capability groups

1. ExecutionKernel aggregate
2. Durable ownership transaction protocol
3. Timeline-first state recovery
4. Artifact-backed projections
5. RuntimeConnectionState control plane
6. Typed effect/approval journal
7. Interrupt + suspend/handoff coordination
8. Parent-authoritative subagent recovery
9. Policy composition and fail-closed adapter mapping
10. E4/E5 evidence emitted from the same durable execution timeline

## Core invariant

There is only one authoritative execution state:
the durable timeline + ownership record + typed artifacts.

Agent memory, UI state, worker state and adapter state are projections/caches.
