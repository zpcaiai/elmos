# Spring Security AST Rewrite

Target: `WebSecurityConfigurerAdapter` → `SecurityFilterChain`.

Steps:
1. resolve exact class and overridden configure(HttpSecurity)
2. remove adapter inheritance
3. preserve HttpSecurity statement sequence
4. create @Bean SecurityFilterChain method
5. return http.build()
6. update imports
7. compile
8. run graph-selected security tests
9. run full integration gate before certification

Ambiguous inheritance/reflection requires semantic-agent escalation.
