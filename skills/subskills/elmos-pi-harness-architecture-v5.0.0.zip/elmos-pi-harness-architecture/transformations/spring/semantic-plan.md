# Spring Semantic Rewrite Execution Plan

1. locate exact symbols with Java resolver
2. validate recipe preconditions
3. use deterministic AST rewrite where mapping is exact
4. use LLM only for ambiguous semantic gaps
5. compile immediately
6. run impacted tests
7. update graph from diff
8. re-run API compatibility check
9. checkpoint validated state
