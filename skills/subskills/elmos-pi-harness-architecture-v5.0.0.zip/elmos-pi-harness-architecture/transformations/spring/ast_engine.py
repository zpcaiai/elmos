from __future__ import annotations
from pathlib import Path
from dataclasses import dataclass

@dataclass
class RewriteResult:
    changed_files: list[str]
    diagnostics: list[dict]
    confidence: float

class SpringAstRewriteEngine:
    def jakarta_namespace(self, root: Path) -> RewriteResult:
        from elmos_runtime_core.recipe_runner import rewrite_import_prefix
        changed=[]
        for old,new in [
            ("javax.persistence","jakarta.persistence"),
            ("javax.validation","jakarta.validation"),
            ("javax.servlet","jakarta.servlet"),
        ]:
            changed += rewrite_import_prefix(root,old,new)
        return RewriteResult(sorted(set(changed)),[],1.0)

    def security_filter_chain(self, root: Path, resolver_evidence: dict) -> RewriteResult:
        # Production implementation target: AST-aware class/method rewrite.
        return RewriteResult([],[
            {"type":"not_implemented","adapter":"security_filter_chain","needs_ast_adapter":True}
        ],0.0)

    def hibernate6(self, root: Path, resolver_evidence: dict) -> RewriteResult:
        return RewriteResult([],[
            {"type":"not_implemented","adapter":"hibernate6","needs_ast_adapter":True}
        ],0.0)
