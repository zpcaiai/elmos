from __future__ import annotations
from pathlib import Path

class SpringSemanticRewriteAdapter:
    def rewrite_security_filter_chain(self, project_root: Path, match: dict):
        raise NotImplementedError("Implement AST-aware SecurityFilterChain rewrite")

    def rewrite_hibernate6_semantics(self, project_root: Path, match: dict):
        raise NotImplementedError("Implement Hibernate 6 semantic rewrite")

    def rewrite_webmvc_semantics(self, project_root: Path, match: dict):
        raise NotImplementedError("Implement Spring MVC semantic rewrite")
