# Hibernate 6 Semantic Rewrite

Handle:
- Jakarta namespaces
- custom UserType contracts
- Criteria/query API changes
- dialect changes
- native query result handling

Deterministic mappings run first. Ambiguous changes require resolver evidence + model-assisted patch + compile/test loop.
