# Production Index Worker

Input: shard ID, project/revision, paths, parser/resolver versions, environment fingerprint.

Output: immutable artifact URI/hash, node/edge counts, unresolved references, diagnostics,
duration and worker version.

Worker never publishes a graph. Coordinator verifies, merges and atomically publishes it.
