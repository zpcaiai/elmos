# Index Lease / Merge Protocol

Shard lifecycle:
QUEUED → LEASED → RUNNING → ARTIFACT_WRITTEN → VERIFIED → MERGED

Rules:
- lease has owner + expiry
- heartbeat extends lease
- expired lease is reclaimable
- shard artifact is immutable
- coordinator verifies revision + artifact hash
- graph merge occurs only when required shards are VERIFIED
- latest graph pointer swaps atomically after merge
