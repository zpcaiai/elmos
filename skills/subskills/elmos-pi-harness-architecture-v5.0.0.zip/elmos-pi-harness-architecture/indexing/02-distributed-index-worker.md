# Distributed Repository Index Workers

Coordinator:
- computes Git delta
- partitions affected paths
- assigns immutable shard IDs
- tracks leases/checkpoints
- merges graph outputs

Worker:
- parses assigned paths
- resolves local symbols
- produces node/edge artifact
- checkpoints embedding/resolver stage
- is retry-safe

Cross-shard reconciliation:
- imports
- calls
- type references
- API/data-flow edges

No worker writes graph state directly without versioned merge semantics.
