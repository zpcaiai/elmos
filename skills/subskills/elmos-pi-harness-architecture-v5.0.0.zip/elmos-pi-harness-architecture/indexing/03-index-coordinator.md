# Distributed Index Coordinator

Responsibilities:
- accept repo revision/Git delta
- partition changed paths
- issue immutable shard IDs
- lease shards
- collect immutable node/edge artifacts
- reconcile cross-shard edges
- merge a new graph version atomically
- trigger embeddings/resolvers
- record incremental reparse ratio

Partial runs must never be exposed as complete graph versions.
