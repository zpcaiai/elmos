# Distributed Incremental Repository Indexing

Partition by module/package/path while preserving cross-partition edge reconciliation.

Pipeline:
Git diff
→ affected partitions
→ parallel parse
→ local symbol extraction
→ semantic resolver
→ edge reconciliation
→ graph merge
→ embedding batch
→ index checkpoint

Large repos should not be fully reparsed after every patch.
