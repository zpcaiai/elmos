# Chaos Certification Execution

A real 50x batch requires actual failure injectors against staging infrastructure.

Examples:
- `docker kill <worker>`
- Kubernetes pod deletion
- Redis network isolation
- provider fault proxy
- Temporal/Postgres controlled restart

Do not simulate success by calling a no-op injector.

Every repetition must point to:
- task/workflow ID
- injection evidence
- recovery evidence
- final verification
- side-effect reconciliation
