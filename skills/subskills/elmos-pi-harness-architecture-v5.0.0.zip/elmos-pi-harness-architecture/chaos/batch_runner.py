import json
from pathlib import Path
from chaos.runner import run_repetitions

def run_batch(manifest, injectors, verifiers, output_dir):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    all_results = {}
    reps = int(manifest.get("default_repetitions", 50))

    for scenario in manifest["scenarios"]:
        if scenario not in injectors or scenario not in verifiers:
            all_results[scenario] = {"status": "missing_adapter"}
            continue
        rows = run_repetitions(scenario, reps, injectors[scenario], verifiers[scenario])
        all_results[scenario] = rows

    (out / "chaos-results.json").write_text(
        json.dumps(all_results, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return all_results
