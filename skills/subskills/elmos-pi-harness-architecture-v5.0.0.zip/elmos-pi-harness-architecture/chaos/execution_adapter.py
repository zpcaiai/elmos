from dataclasses import dataclass
import subprocess,time

@dataclass
class ChaosInjection:
    scenario:str
    command:list[str]
    settle_seconds:float=1.0

def inject(spec:ChaosInjection):
    started=time.perf_counter()
    p=subprocess.run(spec.command,text=True,capture_output=True)
    time.sleep(spec.settle_seconds)
    return {
      "scenario":spec.scenario,
      "returncode":p.returncode,
      "stdout":p.stdout,
      "stderr":p.stderr,
      "injection_ms":int((time.perf_counter()-started)*1000)
    }
