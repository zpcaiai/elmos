from dataclasses import dataclass, asdict
import time

@dataclass
class ChaosResult:
    scenario: str
    iteration: int
    success: bool
    recovery_ms: int
    duplicate_side_effects: int = 0
    data_loss_events: int = 0
    billing_mismatch: bool = False

def run_repetitions(scenario, repetitions, injector, verifier):
    results = []
    for i in range(repetitions):
        started = time.perf_counter()
        injector()
        status = verifier()
        results.append(ChaosResult(
            scenario=scenario,
            iteration=i,
            success=bool(status.get("success")),
            recovery_ms=int((time.perf_counter() - started) * 1000),
            duplicate_side_effects=int(status.get("duplicate_side_effects", 0)),
            data_loss_events=int(status.get("data_loss_events", 0)),
            billing_mismatch=bool(status.get("billing_mismatch", False))
        ))
    return [asdict(r) for r in results]
