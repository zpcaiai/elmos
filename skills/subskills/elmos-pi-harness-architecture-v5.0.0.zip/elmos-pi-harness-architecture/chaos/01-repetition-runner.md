# Chaos Repetition Runner

Certification target: 50–100 repetitions per supported scenario in staging.

Scenarios:
- task worker kill
- API kill
- Redis outage
- PostgreSQL restart
- Temporal outage
- model-provider outage
- index-worker kill
- sandbox kill
- object-store outage
- duplicate delivery
- client disconnect

Collect:
resume success, recovery time, duplicate side effects, data loss, billing mismatch,
and final verification integrity.
