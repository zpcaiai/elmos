# Machine Wall-Clock ETA

Predict Elmos autonomous runtime, not human engineering effort.

Decompose:
queue + index + plan + model + tools + compile + tests + repair + deploy/checks.

Return:
- p50 ETA
- p90 ETA
- confidence
- stage estimates
- uncertainty drivers

Update ETA after every completed stage and repair loop.
