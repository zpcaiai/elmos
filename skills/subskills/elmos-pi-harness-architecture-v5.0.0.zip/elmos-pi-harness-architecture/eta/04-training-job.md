# ETA Training Job

Pipeline:
verified task/stage outcomes
→ feature extraction
→ lineage-safe train/validation split
→ quantile model training
→ calibration
→ benchmark
→ artifact registration
→ shadow
→ canary
→ activation

Target is Elmos machine wall-clock runtime, not human effort.
