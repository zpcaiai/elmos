# Learned ETA Pipeline

Target:
predict Elmos machine wall-clock, not human effort.

Features:
- task class
- repo LOC/modules
- graph density
- planned DAG
- expected model/tool calls
- provider latency
- cache-hit estimates
- selected verification waves
- historical repair loops
- worker/queue pressure

Labels:
- stage actual duration
- total actual wall-clock

Models:
baseline linear/GBDT → calibrated quantile model → online recalibration.

Required outputs:
P50, P90, confidence and top uncertainty drivers.
