# Quantile ETA Model

Predict P50/P90 machine wall-clock.

Features:
task class, LOC/modules, graph density, DAG shape, model/tool calls, provider latency,
cache estimate, verification waves, repair history, queue/worker pressure.

Evaluate pinball loss, interval coverage, calibration error and absolute error.
Refresh ETA after indexing, planning, fallback, repair and verification escalation.
