def derive_evidence_level(status, lineage_persisted, manifest_sealed, repetitions=1, statistics_ready=False):
    if not status.get("run_id"):
        return "E2"
    if status.get("verification") is None:
        return "E3"
    if not manifest_sealed or not lineage_persisted:
        return "E3"
    if repetitions >= 5 and statistics_ready:
        return "E5"
    return "E4"
