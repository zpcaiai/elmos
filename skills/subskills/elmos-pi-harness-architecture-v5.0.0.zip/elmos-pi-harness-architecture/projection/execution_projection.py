def build_status(kernel_state, timeline_state):
    return {
        "execution_id": kernel_state["execution_id"],
        "state": timeline_state["lifecycle_state"],
        "runtime_owner_id": timeline_state["runtime_owner_id"],
        "ownership_epoch": timeline_state["ownership_epoch"],
        "runtime_states": timeline_state["runtime_states"],
        "artifact_count": len(timeline_state["artifacts"]),
        "verification": timeline_state["verification"]
    }
