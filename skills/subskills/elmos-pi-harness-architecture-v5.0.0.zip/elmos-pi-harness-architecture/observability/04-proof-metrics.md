# Proof Metrics

- validated_success_rate
- regression_free_success_rate
- cost_per_validated_success
- p50/p95_machine_wall_clock
- cache_hit_ratio
- crash_resume_success_rate
- duplicate_side_effect_count
- data_loss_event_count
- eta_p90_coverage
- router_fallback_rate

Dashboards must expose system/policy/model versions.
