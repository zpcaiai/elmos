# Metrics

Counters:
- elmos_tasks_total{status}
- elmos_model_invocations_total{provider,model,status}
- elmos_tool_calls_total{tool,status}
- elmos_verification_runs_total{type,status}
- elmos_recovery_total{result}

Histograms:
- elmos_task_wall_clock_seconds
- elmos_model_latency_seconds
- elmos_tool_latency_seconds
- elmos_context_tokens
- elmos_cost_per_task_usd

Gauges:
- elmos_active_tasks
- elmos_active_agents
- elmos_checkpoint_age_seconds
- elmos_prompt_cache_hit_ratio
- elmos_queue_depth
