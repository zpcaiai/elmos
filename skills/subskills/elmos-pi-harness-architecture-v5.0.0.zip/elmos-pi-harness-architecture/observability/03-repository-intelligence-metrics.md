# Repository Intelligence Metrics

## Indexing
- repo_index_files_total
- repo_index_nodes_total
- repo_index_edges_total
- repo_index_duration_seconds
- repo_incremental_reparse_ratio

## Resolution
- exact_symbol_resolution_ratio
- unresolved_reference_ratio
- typed_call_edge_ratio

## Retrieval
- context_candidate_total
- context_selected_total
- context_token_count
- context_redundancy_ratio
- context_cache_hit_ratio

## Impact / Verification
- impacted_symbol_recall
- impacted_test_count
- selected_test_count
- verification_wave_duration_seconds

## Business
- tokens_saved_vs_baseline
- verification_minutes_saved
- cost_per_successful_repo_task
