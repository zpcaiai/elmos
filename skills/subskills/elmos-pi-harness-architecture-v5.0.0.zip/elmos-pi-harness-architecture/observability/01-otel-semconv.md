# OpenTelemetry Semantic Conventions

Trace hierarchy:

task.run
  ├─ planning
  ├─ context.build
  ├─ model.invoke
  ├─ tool.execute
  ├─ transform.apply
  ├─ verification.run
  ├─ repair.loop
  └─ checkpoint.write

Required attributes:
- tenant.id
- project.id
- task.id
- dag.node.id
- model.provider
- model.name
- tokens.input
- tokens.output
- tokens.cached
- cost.usd
- artifact.ids
- repo.revision
- attempt
- verification.type
- verification.status

Never attach secrets or raw sensitive file contents to telemetry.
