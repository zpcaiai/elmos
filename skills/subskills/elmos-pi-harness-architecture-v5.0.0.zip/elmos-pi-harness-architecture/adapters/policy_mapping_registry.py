class PolicyMappingRegistry:
    def __init__(self):
        self._mappings = {}

    def register(self, adapter, protocol_version, mapping):
        self._mappings[(adapter, protocol_version)] = mapping

    def resolve(self, adapter, protocol_version):
        mapping = self._mappings.get((adapter, protocol_version))
        if mapping is None:
            return {"valid": False, "fail_closed": True, "reason": "mapping_not_found"}
        return {"valid": True, "mapping": mapping, "fail_closed": False}
