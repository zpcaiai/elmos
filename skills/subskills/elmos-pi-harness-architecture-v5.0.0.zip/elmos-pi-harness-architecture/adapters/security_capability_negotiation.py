def validate_policy_mapping(adapter,internal_policy):
    required=["getSupportedCapabilities","getSupportedApprovalModes","getProtocolVersion","validatePolicyMapping"]
    missing=[x for x in required if not hasattr(adapter,x)]
    if missing: return {"valid":False,"missing":missing,"fail_closed":True}
    ok=bool(adapter.validatePolicyMapping(internal_policy))
    return {"valid":ok,"fail_closed":not ok}
