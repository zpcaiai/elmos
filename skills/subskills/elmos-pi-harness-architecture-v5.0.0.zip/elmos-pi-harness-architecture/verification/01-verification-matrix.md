# Verification Matrix

| Change Type | Required Gates |
|---|---|
| docs only | lint/docs-link |
| local code edit | compile + targeted tests |
| multi-module change | compile + unit + integration |
| API change | contract + integration + backward compatibility |
| DB schema change | migration up/down + data compatibility |
| UI change | unit + E2E + visual/interaction checks |
| performance-sensitive | benchmark + regression threshold |
| security-sensitive | SAST + dependency + policy tests |
| deployment change | build + image scan + /livez + /readyz + /metrics + /version |
| large migration | all applicable + differential validation |

Success is evidence-driven. A task cannot bypass required gates through model confidence.
