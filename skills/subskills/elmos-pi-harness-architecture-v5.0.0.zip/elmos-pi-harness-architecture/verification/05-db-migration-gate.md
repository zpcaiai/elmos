# Database Migration Gate

Require:
- migration plan
- expand/contract compatibility
- rollback or forward-fix plan
- data backup policy
- destructive-operation approval
- staging dry-run
- row-count/checksum evidence where applicable
- application compatibility window
