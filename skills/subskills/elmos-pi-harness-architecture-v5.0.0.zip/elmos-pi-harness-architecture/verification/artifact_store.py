from __future__ import annotations
from pathlib import Path
import json, hashlib

class VerificationArtifactStore:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def put(self, run_id: str, payload: dict):
        data = json.dumps(payload, ensure_ascii=False, indent=2).encode()
        digest = hashlib.sha256(data).hexdigest()
        path = self.root / f"{run_id}-{digest}.json"
        path.write_bytes(data)
        return {
            "uri": f"file://{path}",
            "sha256": digest,
            "bytes": len(data)
        }
