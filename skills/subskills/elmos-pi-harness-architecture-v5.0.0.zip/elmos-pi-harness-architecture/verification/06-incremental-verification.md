# Incremental Verification

Use semantic graph + content hashes + historical test evidence.

Algorithm:
changed nodes
→ impact closure
→ directly impacted tests
→ environment/dependency invalidation
→ cached-safe test results
→ run Wave 0/1/2
→ escalate on failure/uncertainty/risk
→ full suite at release/certification gate

Measure false-negative regression escapes explicitly.
Optimization is invalid if it reduces runtime by missing regressions.
