# Verifier Pack

A verifier pack defines deterministic quality gates for a task family.

Possible gates:
- compile
- unit tests
- integration tests
- API compatibility
- schema compatibility
- performance threshold
- static security checks
- anti-test-suppression scan

The verifier pack is versioned independently from the harness.
