# Graph-Aware Verification Scheduler

Input:
- changed nodes
- impact graph
- historical failing tests
- test duration statistics
- risk classification

Schedule verification in waves:

Wave 0: syntax/type/compile
Wave 1: directly-related unit tests
Wave 2: graph-neighbor integration tests
Wave 3: broader module tests
Wave 4: full regression when risk/uncertainty threshold requires it

Goals:
- fail fast
- reduce verification wall-clock
- preserve regression confidence
- avoid blindly running the entire suite after every tiny edit

A full suite remains mandatory at configured release/certification gates.
