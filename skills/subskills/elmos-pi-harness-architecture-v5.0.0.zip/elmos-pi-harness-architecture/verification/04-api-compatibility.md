# API Compatibility Gate

Sources:
- OpenAPI
- protobuf/gRPC descriptors
- GraphQL schema
- public Java/Kotlin/C#/TS API surface

Classify:
- breaking
- potentially breaking
- additive
- behavioral unknown

Golden Route release gate fails on unapproved breaking changes.
