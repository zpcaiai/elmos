from pathlib import Path
import subprocess, time, yaml

def run_pack(repo_path: str, pack_path: str):
    pack = yaml.safe_load(Path(pack_path).read_text(encoding="utf-8"))
    results = []
    for gate in pack["gates"]:
        started = time.perf_counter()
        try:
            p = subprocess.run(
                gate["command"], cwd=repo_path, text=True, capture_output=True,
                timeout=gate.get("timeout_seconds", 900)
            )
            result = {
                "name": gate["name"],
                "mandatory": gate.get("mandatory", True),
                "passed": p.returncode == 0,
                "returncode": p.returncode,
                "wall_clock_ms": int((time.perf_counter()-started)*1000),
                "stdout": p.stdout[-12000:],
                "stderr": p.stderr[-12000:]
            }
        except subprocess.TimeoutExpired as e:
            result = {
                "name": gate["name"], "mandatory": gate.get("mandatory", True),
                "passed": False, "returncode": None,
                "wall_clock_ms": int((time.perf_counter()-started)*1000),
                "stdout": str(e.stdout or "")[-12000:], "stderr": str(e.stderr or "")[-12000:]
            }
        results.append(result)
        if result["mandatory"] and not result["passed"]:
            break
    return {
        "pack": pack["name"], "version": pack["version"],
        "passed": all((not r["mandatory"]) or r["passed"] for r in results),
        "results": results
    }
