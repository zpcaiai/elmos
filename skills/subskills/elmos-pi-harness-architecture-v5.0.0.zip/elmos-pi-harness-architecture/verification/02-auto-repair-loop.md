# Auto-Repair Loop

1. Execute verification.
2. Normalize failures into structured diagnostics.
3. Cluster failures by root-cause hypothesis.
4. Select smallest responsible code region.
5. Rebuild targeted context.
6. Route model based on failure complexity.
7. Apply minimal patch.
8. Re-run targeted checks.
9. Periodically run broader regression.
10. Stop on:
   - all gates pass
   - budget exhausted
   - repeated identical failure
   - unsafe repair
   - approval required

Guardrails:
- max repair attempts per root cause
- rollback to last validated checkpoint
- never disable tests to create a pass
- never weaken assertions without explicit justification/evidence
