from verification.verifier_pack_runner import run_pack

def dispatch(repo_path,verifier_pack_path):
    result=run_pack(repo_path,verifier_pack_path)
    return {
      "passed":bool(result.get("passed")),
      "pack":result.get("pack"),
      "version":result.get("version"),
      "results":result.get("results",[])
    }
