# Production Deployment Gates

Required endpoints:
- `/livez`
- `/readyz`
- `/metrics`
- `/version`

CI/CD gates:
1. build
2. unit tests
3. integration tests
4. migration dry run
5. container scan
6. SBOM
7. signed image
8. deploy canary
9. readiness
10. smoke tests
11. rollback validation
12. production promotion

Database migrations:
- expand/contract pattern
- backward compatible first
- long-running backfills isolated
- explicit rollback strategy
