alter table evidence_campaign
  add column if not exists created_by text,
  add column if not exists updated_at timestamptz default now();

create table if not exists benchmark_execution_job(
  id uuid primary key,
  campaign_id uuid not null references evidence_campaign(id),
  system_name text not null,
  repo_revision text not null,
  task_case_id text not null,
  repetition int not null,
  status text not null,
  lease_owner text,
  lease_expires_at timestamptz,
  run_id uuid,
  evidence_uri text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create unique index if not exists uq_benchmark_execution_job
on benchmark_execution_job(campaign_id,system_name,repo_revision,task_case_id,repetition);

create table if not exists campaign_evidence_manifest(
  campaign_id uuid primary key references evidence_campaign(id),
  manifest_uri text not null,
  sha256 text not null,
  evidence_level text not null,
  created_at timestamptz default now()
);
