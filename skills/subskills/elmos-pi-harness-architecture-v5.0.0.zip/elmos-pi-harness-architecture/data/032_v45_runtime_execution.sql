create table if not exists runtime_execution_binding(
 id uuid primary key,
 runtime_binding_id uuid references runtime_binding_snapshot(id),
 engine_name text not null,
 engine_version text,
 transport text not null,
 benchmark_mode boolean not null default true,
 created_at timestamptz default now()
);
