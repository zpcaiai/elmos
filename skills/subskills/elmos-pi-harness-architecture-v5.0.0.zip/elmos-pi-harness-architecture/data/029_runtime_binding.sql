create table if not exists runtime_binding_snapshot(
  id uuid primary key,
  campaign_id uuid references evidence_campaign(id),
  transport text not null,
  runtime_version text not null,
  model text not null,
  provider text not null,
  binary_path text,
  endpoint text,
  environment_lock_sha256 text,
  created_at timestamptz default now()
);

create index if not exists idx_runtime_binding_campaign
on runtime_binding_snapshot(campaign_id, runtime_version, model, provider);
