create table if not exists e5_batch_run(
  logical_run_id text primary key,
  campaign_id uuid not null references evidence_campaign(id),
  repetition int not null,
  binding_hash text not null,
  frozen_config jsonb not null,
  physical_run_id uuid,
  status text not null,
  created_at timestamptz default now(),
  completed_at timestamptz
);

create index if not exists idx_e5_batch_campaign
on e5_batch_run(campaign_id,repetition);
