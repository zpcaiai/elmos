create table if not exists cli_validation_snapshot(
  id uuid primary key,
  system_name text not null,
  binary_name text not null,
  installed boolean not null,
  version text,
  validated_flags jsonb not null,
  missing_flags jsonb not null,
  created_at timestamptz default now()
);

create table if not exists benchmark_campaign(
  id uuid primary key,
  name text not null,
  mode text not null,
  status text not null,
  repetitions int not null,
  systems jsonb not null,
  environment_fingerprint text,
  created_at timestamptz default now(),
  completed_at timestamptz
);

create table if not exists benchmark_smoke_result(
  id uuid primary key,
  campaign_id uuid references benchmark_campaign(id),
  system_name text not null,
  system_version text,
  status text not null,
  exit_code int,
  wall_clock_ms bigint,
  evidence_uri text,
  created_at timestamptz default now()
);
