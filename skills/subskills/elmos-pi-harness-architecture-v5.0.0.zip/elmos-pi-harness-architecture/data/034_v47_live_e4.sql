create table if not exists runtime_execution_audit(
  run_id uuid primary key,
  binding_hash text not null,
  manifest_sha256 text not null,
  runtime_identity jsonb not null,
  validated_success boolean not null,
  evidence_level text not null,
  audit jsonb not null,
  created_at timestamptz default now()
);
