# Event Contract

Core events: task.created/started/paused/resumed/cancelled/completed/failed/replanned; agent.started/completed; model.requested/completed/failed; tool.requested/completed/failed; patch.created/applied/reverted; verification.started/completed; checkpoint.created; approval.requested/granted/denied; artifact.created; budget.warning/exhausted.

Every event includes event_id, task_id, tenant_id, timestamp, actor, correlation_id, causation_id, payload_version, payload.
