create table if not exists tenant_execution_permit (
  tenant_id uuid not null,
  task_id uuid not null references task(id),
  acquired_at timestamptz not null default now(),
  heartbeat_at timestamptz not null default now(),
  primary key(tenant_id,task_id)
);
create index if not exists idx_tenant_execution_permit_tenant on tenant_execution_permit(tenant_id);
