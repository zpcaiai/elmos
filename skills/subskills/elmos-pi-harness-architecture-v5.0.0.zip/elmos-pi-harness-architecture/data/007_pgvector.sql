create extension if not exists vector;

create table if not exists repository_vector (
  project_id uuid not null references project(id),
  revision text not null,
  node_id uuid not null references repo_graph_node(id),
  embedding_model text not null,
  dimension int not null,
  embedding vector,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  primary key(project_id,revision,node_id,embedding_model)
);

create index if not exists idx_repository_vector_project_revision
on repository_vector(project_id, revision);
