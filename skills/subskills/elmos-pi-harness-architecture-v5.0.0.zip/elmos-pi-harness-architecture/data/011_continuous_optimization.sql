create table if not exists dag_runtime_prediction(
 id bigserial primary key, task_id uuid references task(id), dag_node_id uuid,
 expected_duration_ms bigint, expected_cost_usd numeric(18,6),
 critical_path boolean default false, priority_score numeric(18,6),
 created_at timestamptz default now()
);

create table if not exists semantic_cache_entry(
 cache_key text primary key, equivalence_level text not null,
 payload_artifact_id uuid references artifact(id), metadata jsonb not null,
 created_at timestamptz default now(), last_used_at timestamptz
);

create table if not exists benchmark_policy_evaluation(
 id uuid primary key, benchmark_run_id uuid, policy_name text not null,
 policy_version text not null, baseline_version text,
 metrics jsonb not null, decision text, created_at timestamptz default now()
);

create table if not exists router_training_record(
 id bigserial primary key, task_id uuid references task(id), features jsonb not null,
 decision jsonb not null, outcome jsonb not null, created_at timestamptz default now()
);
