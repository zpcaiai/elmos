create table if not exists campaign_transition_event(
  id bigserial primary key,
  campaign_id uuid not null references evidence_campaign(id),
  from_state text,
  to_state text not null,
  evidence_ids jsonb not null default '[]'::jsonb,
  note text,
  created_at timestamptz default now()
);

create table if not exists verifier_pack_run(
  id uuid primary key,
  campaign_id uuid references evidence_campaign(id),
  pack_name text not null,
  pack_version text not null,
  repo_revision text not null,
  passed boolean not null,
  results jsonb not null,
  evidence_artifact_id uuid references artifact(id),
  created_at timestamptz default now()
);

create table if not exists evidence_promotion_event(
  id bigserial primary key,
  campaign_id uuid references evidence_campaign(id),
  from_level text not null,
  to_level text not null,
  evidence_ids jsonb not null,
  created_at timestamptz default now()
);
