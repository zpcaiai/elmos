create table if not exists execution_kernel(
  execution_id uuid primary key,
  root_execution_id uuid not null,
  parent_execution_id uuid,
  source text not null,
  runtime_owner_id uuid,
  ownership_epoch bigint not null default 0,
  lifecycle_state text not null,
  durable_barrier_complete boolean not null default false,
  metadata jsonb not null default '{}'::jsonb,
  updated_at timestamptz default now()
);

create table if not exists execution_effect(
  effect_id uuid primary key,
  execution_id uuid not null references execution_kernel(execution_id),
  action_kind text not null,
  parent_call_id text,
  status text not null,
  resolver text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz default now(),
  resolved_at timestamptz
);

create table if not exists adapter_policy_mapping(
  adapter_id text not null,
  protocol_version text not null,
  mapping jsonb not null,
  created_at timestamptz default now(),
  primary key(adapter_id, protocol_version)
);

create index if not exists idx_execution_kernel_owner
on execution_kernel(runtime_owner_id, lifecycle_state);

create index if not exists idx_execution_effect_execution
on execution_effect(execution_id, action_kind, status);
