alter table task add column if not exists updated_at timestamptz not null default now();

alter table task_event add column if not exists tenant_id uuid;
create index if not exists idx_task_event_tenant_task_seq on task_event(tenant_id,task_id,seq);

create table if not exists workflow_binding (
  task_id uuid primary key references task(id),
  workflow_id text not null unique,
  run_id text,
  task_queue text not null,
  created_at timestamptz not null default now()
);

create table if not exists workspace (
  id uuid primary key,
  task_id uuid not null references task(id),
  repo_uri text not null,
  base_revision text,
  local_path text,
  branch_name text,
  status text not null,
  created_at timestamptz not null default now(),
  released_at timestamptz
);

create table if not exists model_capability (
  provider text not null,
  model text not null,
  capability text not null,
  score numeric(8,4),
  observed_success_rate numeric(8,4),
  observed_cost_per_success numeric(18,6),
  updated_at timestamptz not null default now(),
  primary key(provider,model,capability)
);

create table if not exists task_usage (
  id bigserial primary key,
  tenant_id uuid not null,
  project_id uuid,
  task_id uuid not null references task(id),
  provider text,
  model text,
  input_tokens bigint not null default 0,
  output_tokens bigint not null default 0,
  cached_input_tokens bigint not null default 0,
  latency_ms bigint,
  cost_usd numeric(18,6) not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_task_usage_task on task_usage(task_id);
