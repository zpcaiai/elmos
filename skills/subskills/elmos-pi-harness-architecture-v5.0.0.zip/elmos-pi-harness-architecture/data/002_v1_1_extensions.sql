alter table task
  add column if not exists cancel_requested_at timestamptz,
  add column if not exists pause_requested_at timestamptz,
  add column if not exists last_checkpoint_at timestamptz,
  add column if not exists estimated_remaining_ms bigint,
  add column if not exists verification_status text,
  add column if not exists model_policy text default 'auto';

create table if not exists dag_node (
  id uuid primary key,
  task_id uuid not null references task(id),
  node_type text not null,
  name text not null,
  status text not null,
  objective text,
  attempt int not null default 0,
  max_attempts int not null default 3,
  lease_owner text,
  lease_expires_at timestamptz,
  model_tier text,
  tool_scope jsonb not null default '{}'::jsonb,
  budget jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  started_at timestamptz,
  completed_at timestamptz
);

create index if not exists idx_dag_node_task_status
on dag_node(task_id, status);

create table if not exists dag_edge (
  task_id uuid not null references task(id),
  from_node_id uuid not null references dag_node(id),
  to_node_id uuid not null references dag_node(id),
  dependency_type text not null default 'hard',
  primary key(task_id, from_node_id, to_node_id)
);

create table if not exists side_effect_journal (
  id uuid primary key,
  task_id uuid not null references task(id),
  dag_node_id uuid references dag_node(id),
  effect_type text not null,
  idempotency_key text not null,
  target text,
  status text not null,
  request_artifact_id uuid references artifact(id),
  response_artifact_id uuid references artifact(id),
  created_at timestamptz not null default now(),
  reconciled_at timestamptz,
  unique(idempotency_key)
);

create table if not exists repo_graph_node (
  id uuid primary key,
  project_id uuid not null references project(id),
  revision text not null,
  node_type text not null,
  qualified_name text not null,
  file_path text,
  start_line int,
  end_line int,
  metadata jsonb not null default '{}'::jsonb
);

create index if not exists idx_repo_graph_node_project_revision
on repo_graph_node(project_id, revision);

create table if not exists repo_graph_edge (
  project_id uuid not null references project(id),
  revision text not null,
  from_node_id uuid not null references repo_graph_node(id),
  to_node_id uuid not null references repo_graph_node(id),
  edge_type text not null,
  weight numeric(10,5),
  metadata jsonb not null default '{}'::jsonb,
  primary key(project_id, revision, from_node_id, to_node_id, edge_type)
);

create table if not exists context_snapshot (
  id uuid primary key,
  task_id uuid not null references task(id),
  dag_node_id uuid references dag_node(id),
  context_hash text not null,
  token_count bigint not null,
  cacheable_prefix_tokens bigint default 0,
  segments jsonb not null,
  provenance jsonb not null,
  created_at timestamptz not null default now()
);

create table if not exists routing_decision (
  id uuid primary key,
  task_id uuid not null references task(id),
  dag_node_id uuid references dag_node(id),
  task_features jsonb not null,
  selected_provider text not null,
  selected_model text not null,
  fallback_chain jsonb not null default '[]'::jsonb,
  expected_quality numeric(8,4),
  expected_cost_usd numeric(18,6),
  expected_latency_ms bigint,
  reason jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists approval_request (
  id uuid primary key,
  task_id uuid not null references task(id),
  dag_node_id uuid references dag_node(id),
  approval_type text not null,
  risk_level text not null,
  requested_action jsonb not null,
  status text not null,
  requested_at timestamptz not null default now(),
  decided_at timestamptz,
  decided_by text
);
