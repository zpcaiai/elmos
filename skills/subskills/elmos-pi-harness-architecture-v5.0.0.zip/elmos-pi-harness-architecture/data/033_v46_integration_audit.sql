create table if not exists runtime_integration_audit(
  id uuid primary key,
  repository_revision text,
  integration_version text not null,
  manifest_sha256 text not null,
  host_binding_ready boolean not null,
  diagnostics jsonb not null,
  created_at timestamptz default now()
);
