create table if not exists performance_policy(
  id uuid primary key,
  name text not null,
  version text not null,
  state text not null,
  configuration jsonb not null,
  created_at timestamptz default now(),
  activated_at timestamptz,
  retired_at timestamptz,
  unique(name,version)
);

create table if not exists policy_rollout_event(
  id bigserial primary key,
  policy_id uuid not null references performance_policy(id),
  event_type text not null,
  evidence jsonb not null default '{}'::jsonb,
  created_at timestamptz default now()
);

create table if not exists index_shard_run(
  id text primary key,
  project_id uuid,
  revision text not null,
  status text not null,
  lease_owner text,
  lease_expires_at timestamptz,
  artifact_uri text,
  duration_ms bigint,
  updated_at timestamptz default now()
);

create table if not exists eta_model_evaluation(
  id bigserial primary key,
  model_version text not null,
  task_class text,
  sample_count bigint not null,
  p50_coverage numeric(8,4),
  p90_coverage numeric(8,4),
  mae_seconds numeric(18,3),
  calibration_error numeric(18,6),
  created_at timestamptz default now()
);
