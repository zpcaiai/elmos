create extension if not exists pgcrypto;

create table if not exists project (
  id uuid primary key,
  tenant_id uuid,
  name text not null default 'default',
  created_at timestamptz not null default now()
);

insert into project(id, name)
values ('00000000-0000-0000-0000-000000000001','demo')
on conflict do nothing;

create table if not exists task (
  id uuid primary key default gen_random_uuid(),
  project_id uuid references project(id),
  objective text not null,
  status text not null,
  estimated_wall_clock_ms bigint,
  actual_wall_clock_ms bigint,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists task_event (
  seq bigserial primary key,
  task_id uuid not null references task(id),
  event_type text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
