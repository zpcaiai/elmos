create table if not exists golden_route_certification(
 id uuid primary key, route_name text not null, route_version text not null,
 project_id uuid not null references project(id), revision text not null, loc bigint,
 status text not null, evidence_artifact_id uuid references artifact(id),
 total_cost_usd numeric(18,6), wall_clock_ms bigint, created_at timestamptz default now()
);
create table if not exists benchmark_run(
 id uuid primary key, suite text not null, status text not null, configuration jsonb not null,
 started_at timestamptz, completed_at timestamptz, summary_artifact_id uuid references artifact(id),
 created_at timestamptz default now()
);
create table if not exists sla_measurement(
 id bigserial primary key, tenant_id uuid, task_id uuid references task(id), metric text not null,
 value numeric(24,8) not null, target numeric(24,8), compliant boolean,
 measured_at timestamptz default now()
);
