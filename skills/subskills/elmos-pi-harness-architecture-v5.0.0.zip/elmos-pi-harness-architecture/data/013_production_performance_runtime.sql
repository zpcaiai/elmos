create table if not exists router_artifact(
  id uuid primary key,
  version text not null,
  feature_schema_version text not null,
  uri text not null,
  metrics jsonb not null,
  state text not null,
  created_at timestamptz default now()
);

create table if not exists semantic_cache_audit(
  cache_key text primary key,
  equivalence_level text not null,
  artifact_uri text not null,
  validation_evidence jsonb not null,
  hit_count bigint not null default 0,
  invalidated boolean not null default false,
  invalidation_reason text,
  created_at timestamptz default now(),
  last_used_at timestamptz
);

create table if not exists graph_version(
  id uuid primary key,
  project_id uuid not null references project(id),
  revision text not null,
  status text not null,
  manifest_artifact_id uuid references artifact(id),
  created_at timestamptz default now(),
  completed_at timestamptz,
  unique(project_id, revision)
);

create table if not exists performance_guardrail_event(
  id bigserial primary key,
  policy_version text not null,
  guardrail text not null,
  observed_value numeric(24,8),
  threshold_value numeric(24,8),
  action text not null,
  evidence jsonb not null default '{}'::jsonb,
  created_at timestamptz default now()
);
