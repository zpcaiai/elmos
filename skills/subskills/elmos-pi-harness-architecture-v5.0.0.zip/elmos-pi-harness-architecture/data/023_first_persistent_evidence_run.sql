alter table benchmark_execution_job
  add column if not exists failure_class text,
  add column if not exists abandoned_at timestamptz;

create table if not exists run_evidence_chain(
  run_id uuid primary key,
  campaign_id uuid not null references evidence_campaign(id),
  job_id uuid not null references benchmark_execution_job(id),
  evidence_level text not null,
  manifest_uri text not null,
  manifest_sha256 text not null,
  created_at timestamptz default now()
);

create index if not exists idx_job_retryable
on benchmark_execution_job(status,attempt)
where status in ('RETRYABLE','FAILED');
