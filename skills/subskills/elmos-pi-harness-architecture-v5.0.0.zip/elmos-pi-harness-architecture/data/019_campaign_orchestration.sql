create table if not exists evidence_campaign(
  id uuid primary key,
  name text not null,
  mode text not null,
  state text not null,
  suite_name text not null,
  suite_version text not null,
  verifier_pack_version text not null,
  systems jsonb not null,
  repositories jsonb not null,
  repetitions int not null,
  target_evidence_level text not null,
  created_at timestamptz default now(),
  completed_at timestamptz
);

create table if not exists claim_invalidation_event(
  id bigserial primary key,
  claim_id uuid not null references evidence_claim(id),
  changed_keys jsonb not null,
  old_scope jsonb not null,
  new_scope jsonb not null,
  created_at timestamptz default now()
);

create table if not exists commercial_readiness_snapshot(
  id uuid primary key,
  system_version text not null,
  score numeric(8,3) not null,
  hard_fail boolean not null,
  dimensions jsonb not null,
  evidence_ids jsonb not null,
  created_at timestamptz default now()
);
