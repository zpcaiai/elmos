create table if not exists e5_campaign_summary(
  id uuid primary key,
  campaign_id uuid not null references evidence_campaign(id),
  system_name text not null,
  system_version text,
  repo_revision text not null,
  task_case_id text not null,
  model text,
  provider text,
  repetitions int not null,
  validated_successes int not null,
  summary jsonb not null,
  evidence_level text not null default 'E5',
  created_at timestamptz default now()
);

create unique index if not exists uq_e5_summary_scope
on e5_campaign_summary(campaign_id,system_name,repo_revision,task_case_id);
