create table if not exists e4_admission_result(
 id uuid primary key,
 run_id uuid,
 campaign_id uuid references evidence_campaign(id),
 admitted boolean not null,
 blockers jsonb not null default '[]'::jsonb,
 plan_sha256 text,
 manifest_sha256 text,
 runtime_binding_id uuid references runtime_binding_snapshot(id),
 created_at timestamptz default now()
);

create table if not exists bound_task_plan(
 id uuid primary key,
 campaign_id uuid references evidence_campaign(id),
 repo_revision text not null,
 task_case_id text not null,
 suite_version text not null,
 verifier_pack_version text not null,
 plan_sha256 text not null unique,
 plan jsonb not null,
 created_at timestamptz default now()
);
