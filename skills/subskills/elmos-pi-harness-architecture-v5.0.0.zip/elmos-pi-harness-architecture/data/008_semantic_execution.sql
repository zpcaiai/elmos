create table if not exists semantic_resolution_run (
  id uuid primary key,
  project_id uuid not null references project(id),
  revision text not null,
  language text not null,
  resolver text not null,
  status text not null,
  symbol_count bigint default 0,
  reference_count bigint default 0,
  unresolved_count bigint default 0,
  duration_ms bigint,
  diagnostics_artifact_id uuid references artifact(id),
  created_at timestamptz not null default now()
);

create table if not exists api_compatibility_run (
  id uuid primary key,
  task_id uuid not null references task(id),
  api_kind text not null,
  breaking_count bigint not null default 0,
  report_artifact_id uuid references artifact(id),
  created_at timestamptz not null default now()
);

create table if not exists benchmark_shard (
  id text primary key,
  benchmark_name text not null,
  repo_id text not null,
  revision text not null,
  status text not null,
  attempt int not null default 0,
  checkpoint_uri text,
  result_uri text,
  wall_clock_ms bigint,
  updated_at timestamptz not null default now()
);
