create table if not exists runtime_identity_snapshot(
  id uuid primary key,
  campaign_id uuid references evidence_campaign(id),
  system_name text not null,
  transport text not null,
  version text,
  model text,
  provider text,
  endpoint text,
  binary_path text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz default now()
);

create table if not exists e4_execution_status(
  run_id uuid primary key,
  campaign_id uuid references evidence_campaign(id),
  job_id uuid references benchmark_execution_job(id),
  status text not null,
  blocked_reason text,
  runtime_identity_id uuid references runtime_identity_snapshot(id),
  created_at timestamptz default now()
);
