create table if not exists evidence_provenance(
  run_id uuid primary key,
  plan_sha256 text not null,
  manifest_sha256 text not null,
  provenance_sha256 text not null,
  runtime_identity jsonb not null,
  repo_revision text not null,
  verifier jsonb not null,
  created_at timestamptz default now()
);
