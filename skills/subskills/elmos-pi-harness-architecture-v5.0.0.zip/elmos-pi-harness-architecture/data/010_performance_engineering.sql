create table if not exists routing_outcome(
 id bigserial primary key, task_id uuid references task(id), policy_version text not null,
 features jsonb not null, provider text not null, model text not null,
 validated_success boolean, cost_usd numeric(18,6), wall_clock_ms bigint,
 repair_loops int, created_at timestamptz default now()
);
create table if not exists cache_event(
 id bigserial primary key, task_id uuid references task(id), cache_layer text not null,
 cache_key text not null, hit boolean not null, tokens_saved bigint default 0,
 ms_saved bigint default 0, reuse_reason jsonb not null default '{}'::jsonb,
 created_at timestamptz default now()
);
create table if not exists eta_prediction(
 id bigserial primary key, task_id uuid references task(id), stage text,
 p50_seconds numeric(18,3), p90_seconds numeric(18,3), confidence numeric(8,4),
 actual_seconds numeric(18,3), created_at timestamptz default now()
);
create table if not exists tuning_experiment(
 id uuid primary key, name text not null, baseline_policy text not null,
 candidate_policy text not null, status text not null, metrics jsonb,
 created_at timestamptz default now()
);
