create table if not exists benchmark_case_result(
 id uuid primary key, benchmark_run_id uuid not null, system_name text not null,
 system_version text, model_provider text, model_name text, repo_id text not null,
 revision text not null, task_case_id text not null, repetition int not null,
 validated_success boolean not null, regression_free boolean,
 input_tokens bigint default 0, output_tokens bigint default 0, cached_tokens bigint default 0,
 cost_usd numeric(18,6) default 0, wall_clock_ms bigint, tool_calls int default 0,
 repair_loops int default 0, evidence_artifact_id uuid references artifact(id),
 configuration jsonb not null, created_at timestamptz default now()
);
create index if not exists idx_benchmark_case_compare
on benchmark_case_result(benchmark_run_id,task_case_id,system_name);

create table if not exists chaos_certification_run(
 id uuid primary key, system_version text not null, scenario text not null,
 repetitions int not null, successes int not null, duplicate_side_effects int not null default 0,
 data_loss_events int not null default 0, p95_recovery_ms bigint,
 evidence_artifact_id uuid references artifact(id), created_at timestamptz default now()
);
