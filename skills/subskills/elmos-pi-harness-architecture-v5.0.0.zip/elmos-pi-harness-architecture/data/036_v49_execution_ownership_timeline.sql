create table if not exists execution_timeline(
 execution_id uuid not null, sequence bigint not null, event_type text not null, payload jsonb not null,
 created_at timestamptz default now(), primary key(execution_id,sequence));
create table if not exists execution_artifact(
 thread_id uuid not null, artifact_type text not null, identity_key text not null, payload jsonb not null,
 sequence bigint not null, created_at timestamptz default now(), primary key(thread_id,artifact_type,identity_key));
create table if not exists execution_ownership(
 execution_id uuid primary key, runtime_owner_id uuid, ownership_epoch bigint not null default 0,
 state text not null, durable_barrier_complete boolean not null default false, updated_at timestamptz default now());
create table if not exists tool_runtime_state(
 execution_id uuid not null, adapter_id text not null, capability text not null, runtime_state text,
 config_fingerprint text, observed_at timestamptz default now(), primary key(execution_id,adapter_id,capability));
create table if not exists typed_context_item(
 id uuid primary key, execution_id uuid not null, role text not null, kind text not null, producer text not null,
 source text not null, trust text not null, scope text not null, parent_execution_id uuid,
 retention_policy text not null, replay_policy text not null, payload jsonb not null, created_at timestamptz default now());
