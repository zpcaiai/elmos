alter table benchmark_execution_job
  add column if not exists idempotency_key text,
  add column if not exists attempt int not null default 0,
  add column if not exists last_error text;

create unique index if not exists uq_benchmark_job_idempotency
on benchmark_execution_job(idempotency_key);

create index if not exists idx_benchmark_job_lease
on benchmark_execution_job(status,lease_expires_at);

create table if not exists benchmark_job_attempt(
 id bigserial primary key,
 job_id uuid not null references benchmark_execution_job(id),
 attempt int not null, worker_id text, status text not null, error text,
 evidence_uri text, started_at timestamptz default now(), completed_at timestamptz
);
