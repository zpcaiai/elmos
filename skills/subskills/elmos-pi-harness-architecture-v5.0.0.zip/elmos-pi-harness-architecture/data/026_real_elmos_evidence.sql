create table if not exists harness_preflight_snapshot(
 id uuid primary key,
 system_name text not null,
 system_version text,
 installed boolean not null,
 eligible_e4 boolean not null,
 details jsonb not null,
 created_at timestamptz default now()
);

create table if not exists evidence_integrity_check(
 id bigserial primary key,
 run_id uuid,
 manifest_uri text not null,
 valid boolean not null,
 failures jsonb not null default '[]'::jsonb,
 checked_at timestamptz default now()
);
