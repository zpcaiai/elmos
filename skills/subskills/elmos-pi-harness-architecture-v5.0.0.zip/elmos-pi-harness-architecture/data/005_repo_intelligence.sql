alter table repo_graph_node add column if not exists language text;
alter table repo_graph_node add column if not exists content_hash text;
alter table repo_graph_node add column if not exists embedding_ref text;
alter table repo_graph_node add column if not exists authority_score numeric(8,4);
alter table repo_graph_edge add column if not exists confidence numeric(8,4) default 1.0;

create index if not exists idx_repo_graph_node_qn
on repo_graph_node(project_id,revision,qualified_name);
create index if not exists idx_repo_graph_node_file
on repo_graph_node(project_id,revision,file_path);
create index if not exists idx_repo_graph_edge_from
on repo_graph_edge(project_id,revision,from_node_id);
create index if not exists idx_repo_graph_edge_to
on repo_graph_edge(project_id,revision,to_node_id);

create table if not exists repo_index_run(
  id uuid primary key,
  project_id uuid not null references project(id),
  revision text not null,
  parser_version text not null,
  status text not null,
  file_count bigint default 0,
  node_count bigint default 0,
  edge_count bigint default 0,
  duration_ms bigint,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

create table if not exists context_selection(
  id uuid primary key,
  task_id uuid not null references task(id),
  candidate_id text not null,
  source_type text not null,
  source_ref text not null,
  lexical_score numeric(8,4),
  semantic_score numeric(8,4),
  structural_score numeric(8,4),
  fused_score numeric(8,4),
  token_count bigint,
  cache_stability text,
  selected boolean not null,
  reason jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
