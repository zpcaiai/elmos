create table if not exists evidence_claim(
 id uuid primary key, claim_text text not null, evidence_level text not null,
 scope jsonb not null, evidence_ids jsonb not null, status text not null default 'ACTIVE',
 created_at timestamptz default now(), invalidated_at timestamptz
);
create table if not exists customer_pilot_acceptance(
 id uuid primary key, project_id uuid references project(id), route_name text,
 acceptance_criteria jsonb not null, outcome jsonb, evidence_artifact_id uuid references artifact(id),
 status text not null, created_at timestamptz default now()
);
create table if not exists task_unit_economics(
 task_id uuid primary key references task(id), revenue_usd numeric(18,6),
 model_cost_usd numeric(18,6), compute_cost_usd numeric(18,6), storage_cost_usd numeric(18,6),
 external_cost_usd numeric(18,6), support_cost_usd numeric(18,6),
 contribution_margin_usd numeric(18,6), created_at timestamptz default now()
);
