alter table benchmark_execution_job
  add column if not exists max_attempts int not null default 3,
  add column if not exists max_cost_usd numeric(18,6),
  add column if not exists max_elapsed_seconds bigint,
  add column if not exists next_retry_at timestamptz;

alter table benchmark_job_attempt
  add column if not exists failure_class text,
  add column if not exists cost_usd numeric(18,6),
  add column if not exists wall_clock_ms bigint;
