create table if not exists harness_capability_snapshot(
  id uuid primary key,
  system_name text not null,
  system_version text,
  capabilities jsonb not null,
  environment_fingerprint text,
  captured_at timestamptz default now()
);

create table if not exists competitive_benchmark_run(
  id uuid primary key,
  suite_name text not null,
  mode text not null,
  status text not null,
  environment jsonb not null,
  configuration jsonb not null,
  created_at timestamptz default now(),
  completed_at timestamptz
);

create table if not exists normalized_harness_result(
  id uuid primary key,
  benchmark_run_id uuid references competitive_benchmark_run(id),
  system_name text not null,
  system_version text,
  repo_revision text not null,
  task_case_id text not null,
  repetition int not null,
  validated_success boolean,
  timed_out boolean,
  wall_clock_ms bigint,
  input_tokens bigint,
  output_tokens bigint,
  cached_tokens bigint,
  cost_usd numeric(18,6),
  tool_calls int,
  manual_interventions int not null default 0,
  evidence_uri text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz default now()
);
