create table if not exists run_evidence_lineage(
  run_id uuid primary key,
  campaign_id uuid not null references evidence_campaign(id),
  job_id uuid not null references benchmark_execution_job(id),
  evidence_level text not null,
  verifier_pack_run_id uuid references verifier_pack_run(id),
  manifest_uri text not null,
  manifest_sha256 text not null,
  created_at timestamptz default now()
);
create index if not exists idx_lineage_campaign on run_evidence_lineage(campaign_id,evidence_level);
