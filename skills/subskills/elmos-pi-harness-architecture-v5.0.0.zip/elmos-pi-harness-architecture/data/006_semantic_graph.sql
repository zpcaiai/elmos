create table if not exists symbol_reference (
  project_id uuid not null references project(id),
  revision text not null,
  source_node_id uuid not null references repo_graph_node(id),
  target_node_id uuid,
  reference_kind text not null,
  confidence text not null,
  file_path text,
  line_no int,
  metadata jsonb not null default '{}'::jsonb
);

create index if not exists idx_symbol_reference_source
on symbol_reference(project_id,revision,source_node_id);

create index if not exists idx_symbol_reference_target
on symbol_reference(project_id,revision,target_node_id);

create table if not exists repository_embedding (
  project_id uuid not null references project(id),
  revision text not null,
  node_id uuid not null references repo_graph_node(id),
  embedding_model text not null,
  embedding_ref text not null,
  created_at timestamptz not null default now(),
  primary key(project_id,revision,node_id,embedding_model)
);

create table if not exists test_impact_evidence (
  task_id uuid not null references task(id),
  changed_node_id uuid not null,
  test_node_id uuid not null,
  graph_distance int,
  confidence numeric(8,4),
  selected boolean not null default false,
  created_at timestamptz not null default now()
);
