create table if not exists evidence_run(
  id uuid primary key,
  run_type text not null,
  system_name text not null,
  system_version text,
  repo_revision text,
  task_case_id text,
  repetition int,
  validated_success boolean,
  wall_clock_ms bigint,
  cost_usd numeric(18,6),
  evidence_manifest_uri text,
  configuration jsonb not null,
  created_at timestamptz default now()
);

create table if not exists model_training_artifact(
  id uuid primary key,
  artifact_type text not null,
  version text not null,
  uri text not null,
  training_dataset_version text not null,
  metrics jsonb not null,
  state text not null,
  created_at timestamptz default now()
);

create table if not exists pilot_repository(
  id uuid primary key,
  repo_id text not null,
  revision text not null,
  loc bigint not null,
  qualification jsonb not null,
  status text not null,
  created_at timestamptz default now()
);
