# Router Training Data

Each completed task/node produces one training record.

Features:
- normalized task/repository/operational features
- eligible models
- selected model
- cache/context configuration

Outcomes:
- verified success
- quality score
- cost
- wall-clock
- repair loops
- fallback count

Do not train reward from self-reported model confidence.
Use post-verification outcome.
