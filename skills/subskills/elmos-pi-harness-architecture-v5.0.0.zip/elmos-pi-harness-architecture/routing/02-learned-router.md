# Learned Model Router

## Features
Task:
- task class
- ambiguity
- blast radius
- expected tool count
- required reasoning depth

Repository:
- language/framework
- LOC
- modules
- graph density
- changed files
- context tokens

Operational:
- provider latency/error rate
- cache availability
- queue pressure
- budget/SLA

Historical:
- model success by task class
- repair loops
- cost/success
- p95 latency

## Policy evolution
Phase 1 rules
→ Phase 2 supervised ranker
→ Phase 3 contextual bandit with safety constraints

Reward should emphasize validated success, then cost/latency.
Never reward unverified fast completion.
