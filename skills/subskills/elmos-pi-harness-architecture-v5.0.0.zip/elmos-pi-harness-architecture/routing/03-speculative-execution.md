# Speculative Parallel Execution

Use only when expected value exceeds extra cost.

Candidate cases:
- ambiguous architecture choice
- hard bug with multiple hypotheses
- migration repair with uncertain mapping
- high-value final patch review

Patterns:
- same model / different strategies
- heterogeneous models
- generator + critic
- N candidates + deterministic verifier

Stop losers early when verifier evidence establishes a winner.

Hard limits:
- max speculative branches
- max incremental cost
- max wall-clock
- tenant/provider concurrency
