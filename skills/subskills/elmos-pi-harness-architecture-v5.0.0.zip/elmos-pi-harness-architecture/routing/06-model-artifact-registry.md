# Router Model Artifact Registry

Each artifact records:
- artifact ID/version
- training dataset version
- feature schema version
- benchmark run IDs
- calibration metrics
- rollout state

Inference loads only approved/canary artifacts.
Rollback changes the active artifact pointer; immutable historical artifacts are preserved.
