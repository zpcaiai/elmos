# Trained Router Inference

Pipeline:
eligibility filters → feature extraction → learned score → policy constraints → fallback chain.

Return chosen model/provider, fallback chain, policy/model version, feature hash,
expected success/cost/latency and explanation.

Training reward uses post-verification outcomes, never model self-confidence.
