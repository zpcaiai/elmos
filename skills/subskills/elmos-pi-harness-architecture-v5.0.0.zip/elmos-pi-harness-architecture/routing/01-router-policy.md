# Router Policy

## Features

Repository:
- language
- framework
- LOC
- dependency depth
- changed-file count

Task:
- type
- ambiguity
- blast radius
- reasoning depth
- required tool use
- expected output size

Operational:
- SLA
- budget
- provider health
- cache availability
- tenant restrictions

Historical:
- model success rate for task class
- average repair loops
- cost per success
- latency
- structured-output reliability

## Initial rule-based score

For each candidate model:

quality_score
+ reliability_score
+ cache_bonus
- normalized_cost_penalty
- latency_penalty
- provider_risk_penalty

Hard filters run before scoring.

## Escalation

Escalate when:
- confidence below threshold
- repeated failed verification
- architecture-impact task
- uncertainty disagreement between agents
- security-critical change

Downgrade after:
- plan stable
- change decomposed
- deterministic recipe available
