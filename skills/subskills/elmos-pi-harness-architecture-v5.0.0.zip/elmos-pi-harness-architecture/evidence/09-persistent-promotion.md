# Persistent Promotion Service

Promotion facts are written to the database; evidence level is never only an in-memory property.

E3:
real run + immutable evidence manifest.

E4:
E3 + deterministic verifier record.

E5:
all required groups meet repetition floor and statistical gate.

Promotion events are append-only.
