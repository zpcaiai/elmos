# PostgreSQL Integration Contract

CI/staging must verify:
- migrations through latest version apply cleanly
- Campaign row persists
- Job row persists
- E4 transaction inserts run + lineage + promotion
- closing/reopening connection preserves lineage
- foreign keys remain valid
- duplicate run ID does not create conflicting lineage
- incomplete transaction rolls back

SQLite reference proof is not a substitute for this production integration test.
