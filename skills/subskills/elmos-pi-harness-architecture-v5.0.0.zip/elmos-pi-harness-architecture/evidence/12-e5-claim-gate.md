# E5 Claim Gate

A scoped E5 claim requires:
- >=5 E4-equivalent repetitions
- identical system version
- identical repo revision
- identical task/suite/verifier version
- identical model/provider for matched configuration
- deterministic verifier evidence
- persistent run lineage
- raw evidence manifests
- statistical summary

E5 supports scoped performance/quality statements only, never universal superiority.
