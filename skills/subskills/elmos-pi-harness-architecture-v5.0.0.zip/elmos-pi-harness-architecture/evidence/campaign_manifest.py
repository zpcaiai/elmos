from pathlib import Path
import json, hashlib

def build_campaign_manifest(campaign_id, run_ids, evidence_ids, output_path):
    payload = {
        "campaign_id": campaign_id,
        "run_ids": sorted(run_ids),
        "evidence_ids": sorted(evidence_ids),
    }
    raw = json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()
    payload["sha256"] = hashlib.sha256(raw).hexdigest()
    Path(output_path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload
