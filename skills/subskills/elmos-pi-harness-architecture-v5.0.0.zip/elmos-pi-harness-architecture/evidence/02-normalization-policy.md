# Evidence Normalization Policy

Values:
- numeric value when observed
- null when unavailable/unobservable
- never infer proprietary usage metrics from output length

Required always:
- system/version
- repo revision
- task case
- start/end or wall-clock
- exit/timed-out state
- manual-intervention count
- validation result
- evidence artifact references

Optional when observable:
- input/output/cached tokens
- cost
- tool-call count
