def build_e6(e5_pack, large_repo_certifications, chaos_certifications):
    ready = bool(
        e5_pack.get("ready")
        and large_repo_certifications
        and chaos_certifications
        and all(x.get("status") == "PASS" for x in large_repo_certifications)
        and all(x.get("status") == "PASS" for x in chaos_certifications)
    )
    return {
        "target_level":"E6","ready":ready,"e5":e5_pack,
        "large_repo_certifications":large_repo_certifications,
        "chaos_certifications":chaos_certifications
    }
