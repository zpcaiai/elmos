def build(campaign_id, job_id, run_record, manifest_sha256, provenance_sha256, binding_hash):
    return {
        "campaign_id": campaign_id,
        "job_id": job_id,
        "run_id": run_record["run_id"],
        "system": run_record.get("system", "elmos"),
        "system_version": run_record.get("system_version"),
        "model": run_record.get("model"),
        "provider": run_record.get("provider"),
        "repo_revision": run_record["repo_revision"],
        "task_case": run_record["task_case"],
        "validated_success": bool(run_record["validated_success"]),
        "evidence_level": run_record.get("evidence_level", "E4"),
        "manifest_sha256": manifest_sha256,
        "provenance_sha256": provenance_sha256,
        "binding_hash": binding_hash
    }
