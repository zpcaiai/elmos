def build(run_id, events, artifacts, lineage):
    verification = next(
        (e["payload"] for e in reversed(events) if e["event_type"] == "verification.completed"),
        None
    )
    return {
        "run_id": run_id,
        "verification": verification,
        "artifacts": artifacts,
        "lineage": lineage,
        "validated_success": bool(verification and verification.get("passed"))
    }
