import json,hashlib
from pathlib import Path

def validate(path):
    payload=json.loads(Path(path).read_text())
    expected=payload.get("sha256")
    body=dict(payload); body.pop("sha256",None)
    actual=hashlib.sha256(json.dumps(body,sort_keys=True).encode()).hexdigest()
    required=["campaign_id","job_id","run_id","evidence_level","artifacts"]
    missing=[k for k in required if k not in payload]
    return {"valid":expected==actual and not missing,"hash_matches":expected==actual,
            "missing":missing,"evidence_level":payload.get("evidence_level")}
