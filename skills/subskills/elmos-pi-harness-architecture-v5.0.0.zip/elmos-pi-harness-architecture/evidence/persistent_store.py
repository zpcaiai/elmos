import sqlite3

SCHEMA = '''
create table if not exists campaign(id text primary key,state text not null,target_level text not null);
create table if not exists job(id text primary key,campaign_id text not null references campaign(id),status text not null,attempt integer not null default 0);
create table if not exists run(id text primary key,job_id text not null references job(id),campaign_id text not null references campaign(id),
 system_name text not null,validated_success integer not null,evidence_level text not null,manifest_uri text not null);
create table if not exists promotion(id integer primary key autoincrement,campaign_id text not null references campaign(id),
 run_id text not null references run(id),from_level text not null,to_level text not null,created_at text not null default current_timestamp);
'''

class PersistentEvidenceStore:
    def __init__(self,path):
        self.conn=sqlite3.connect(str(path))
        self.conn.execute("pragma foreign_keys=on")
        self.conn.executescript(SCHEMA); self.conn.commit()

    def persist_e4(self,campaign_id,job_id,run_id,system_name,manifest_uri,validated_success=True):
        with self.conn:
            self.conn.execute("insert or ignore into campaign values(?,?,?)",(campaign_id,"VERIFYING","E5"))
            self.conn.execute("insert or ignore into job values(?,?,?,?)",(job_id,campaign_id,"RUNNING",1))
            self.conn.execute("insert into run values(?,?,?,?,?,?,?)",
                (run_id,job_id,campaign_id,system_name,int(validated_success),"E4",manifest_uri))
            self.conn.execute("update job set status='COMPLETED' where id=?",(job_id,))
            self.conn.execute("insert into promotion(campaign_id,run_id,from_level,to_level) values(?,?,?,?)",
                (campaign_id,run_id,"E3","E4"))
            self.conn.execute("update campaign set state='NORMALIZING' where id=?",(campaign_id,))

    def lineage(self,run_id):
        r=self.conn.execute('''select r.id,r.evidence_level,r.manifest_uri,j.id,j.status,c.id,c.state
          from run r join job j on j.id=r.job_id join campaign c on c.id=r.campaign_id where r.id=?''',(run_id,)).fetchone()
        if not r: return None
        return {"run_id":r[0],"evidence_level":r[1],"manifest_uri":r[2],"job_id":r[3],
                "job_status":r[4],"campaign_id":r[5],"campaign_state":r[6]}

    def close(self): self.conn.close()
