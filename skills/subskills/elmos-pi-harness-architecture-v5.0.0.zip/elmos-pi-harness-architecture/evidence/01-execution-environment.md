# Evidence Execution Environment

Required infrastructure:
- PostgreSQL
- Redis
- S3-compatible object storage
- pgvector
- Temporal
- isolated benchmark workers
- sandbox workers
- artifact/evidence store
- metrics/trace backend

Each benchmark run records:
- infrastructure versions
- worker image digest
- CPU/memory limits
- network policy
- harness version
- model/provider version
- repository revision
- benchmark suite revision

Evidence must be reproducible from pinned configuration.
