import json

REQUIRED = {"run_id","system","repo_revision","task_case","wall_clock_ms","evidence_level"}

def validate(record):
    missing = sorted(REQUIRED - set(record))
    if missing:
        return False, {"missing": missing}
    if record["evidence_level"] not in {"E3","E4","E5","E6","E7"}:
        return False, {"reason":"invalid_evidence_level"}
    return True, {}

def normalize(record):
    ok, err = validate(record)
    if not ok:
        raise ValueError(err)
    numeric_nullable = ["input_tokens","output_tokens","cached_tokens","cost_usd","tool_calls"]
    out = dict(record)
    for k in numeric_nullable:
        out.setdefault(k, None)
    out.setdefault("manual_interventions", 0)
    return out
