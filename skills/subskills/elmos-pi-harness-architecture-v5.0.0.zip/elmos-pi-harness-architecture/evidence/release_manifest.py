from pathlib import Path
import json,hashlib

def build(output,version,preflight,campaigns,claims):
    payload={
      "version":version,
      "preflight":preflight,
      "campaigns":campaigns,
      "claims":claims
    }
    raw=json.dumps(payload,sort_keys=True,ensure_ascii=False).encode()
    payload["sha256"]=hashlib.sha256(raw).hexdigest()
    Path(output).write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
    return payload
