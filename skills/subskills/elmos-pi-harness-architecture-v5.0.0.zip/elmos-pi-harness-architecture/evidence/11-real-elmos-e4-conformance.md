# Real Elmos E4 Conformance

PASS requires:
- actual `elmos` executable discovered
- exact version recorded
- CLI contract validated
- immutable repository revision
- isolated worktree
- real execution
- raw stdout/stderr/diff
- deterministic verifier
- hashed evidence manifest
- durable Campaign/Job/Run lineage

BLOCKED is a valid result when runtime prerequisites are absent.
Fabricated execution is not.
