from pathlib import Path
import hashlib,json

def file_sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def seal(root,run_id,metadata):
    root=Path(root)
    files=[]
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.name!="sealed-manifest.json":
            files.append({
              "path":str(p.relative_to(root)),
              "sha256":file_sha256(p),
              "bytes":p.stat().st_size
            })
    manifest={"run_id":run_id,"metadata":metadata,"files":files}
    raw=json.dumps(manifest,sort_keys=True,ensure_ascii=False).encode()
    manifest["sha256"]=hashlib.sha256(raw).hexdigest()
    path=root/"sealed-manifest.json"
    path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    return {"manifest_uri":str(path),"manifest_sha256":manifest["sha256"]}
