import json

class PostgresEvidenceStore:
    def __init__(self,connection_factory):
        self.connection_factory=connection_factory

    def persist_e4(self,campaign_id,job_id,record,manifest_uri,manifest_sha256):
        required=["run_id","system","repo_revision","task_case","validated_success","verification"]
        missing=[k for k in required if k not in record]
        if missing:
            raise ValueError(f"missing fields: {missing}")
        if record["verification"].get("passed") is None:
            raise ValueError("deterministic verification required")

        with self.connection_factory() as conn:
            conn.execute(
              '''insert into normalized_harness_result(
                 id,system_name,system_version,repo_revision,task_case_id,repetition,
                 validated_success,timed_out,wall_clock_ms,input_tokens,output_tokens,
                 cached_tokens,cost_usd,tool_calls,manual_interventions,evidence_uri,metadata)
                 values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb)
                 on conflict(id) do nothing''',
              (record["run_id"],record["system"],record.get("system_version"),
               record["repo_revision"],record["task_case"],record.get("repetition",0),
               record["validated_success"],record.get("timed_out",False),record["wall_clock_ms"],
               record.get("input_tokens"),record.get("output_tokens"),record.get("cached_tokens"),
               record.get("cost_usd"),record.get("tool_calls"),record.get("manual_interventions",0),
               manifest_uri,json.dumps({"verification":record["verification"],"evidence_level":"E4"})))
            conn.execute(
              '''insert into run_evidence_lineage(
                 run_id,campaign_id,job_id,evidence_level,manifest_uri,manifest_sha256)
                 values(%s,%s,%s,'E4',%s,%s)
                 on conflict(run_id) do nothing''',
              (record["run_id"],campaign_id,job_id,manifest_uri,manifest_sha256))
            conn.execute(
              "update benchmark_execution_job set status='COMPLETED',run_id=%s,evidence_uri=%s,updated_at=now() where id=%s",
              (record["run_id"],manifest_uri,job_id))
            conn.execute(
              "insert into evidence_promotion_event(campaign_id,from_level,to_level,evidence_ids) values(%s,'E3','E4',%s::jsonb)",
              (campaign_id,json.dumps([record["run_id"]])))
            conn.commit()
        return {"run_id":record["run_id"],"evidence_level":"E4"}
