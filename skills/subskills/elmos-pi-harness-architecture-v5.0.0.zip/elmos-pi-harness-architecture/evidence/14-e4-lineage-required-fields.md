# E4 Lineage Required Fields

Every real Elmos E4 record must persist:

- campaign_id
- job_id
- run_id
- runtime transport/version
- model/provider
- repository revision
- task case
- suite version
- verifier pack version
- environment lock hash
- stdout/stderr/diff manifest
- deterministic verification
- validated_success
- wall-clock
- manual intervention count
