from evidence.e5_packager import build_e5
from evidence.e6_packager import build_e6
from evidence.e7_packager import build_e7

def finalize_e5(records, min_repetitions=5):
    pack = build_e5(records, min_repetitions=min_repetitions)
    return {"level":"E5","status":"PASS" if pack["ready"] else "BLOCKED","pack":pack}

def finalize_e6(records, large_repo_certifications, chaos_certifications, min_repetitions=5):
    e5 = build_e5(records, min_repetitions=min_repetitions)
    e6 = build_e6(e5, large_repo_certifications, chaos_certifications)
    return {"level":"E6","status":"PASS" if e6["ready"] else "BLOCKED","pack":e6}

def finalize_e7(records, large_repo_certifications, chaos_certifications, pilot_acceptance, min_repetitions=5):
    e5 = build_e5(records, min_repetitions=min_repetitions)
    e6 = build_e6(e5, large_repo_certifications, chaos_certifications)
    e7 = build_e7(e6, pilot_acceptance)
    return {"level":"E7","status":"PASS" if e7["ready"] else "BLOCKED","pack":e7}
