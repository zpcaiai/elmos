def evaluate(record,sealed_evidence,persistent_lineage=False):
    blockers=[]
    if record.get("status")!="EXECUTED": blockers.append("not_executed")
    if not record.get("system_version"): blockers.append("missing_system_version")
    if not record.get("model"): blockers.append("missing_model")
    if not record.get("provider"): blockers.append("missing_provider")
    verification=record.get("verification")
    if not verification or verification.get("passed") is None:
        blockers.append("missing_deterministic_verification")
    if not sealed_evidence.get("manifest_sha256"):
        blockers.append("missing_sealed_manifest")
    if not persistent_lineage:
        blockers.append("missing_persistent_lineage")
    return {"e4_admitted":not blockers,"blockers":blockers}
