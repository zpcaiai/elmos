from pathlib import Path
import json,hashlib

def write_chain(path,campaign_id,job_id,run_id,evidence_level,artifacts):
    payload={
      "campaign_id":campaign_id,"job_id":job_id,"run_id":run_id,
      "evidence_level":evidence_level,"artifacts":artifacts
    }
    raw=json.dumps(payload,sort_keys=True).encode()
    payload["sha256"]=hashlib.sha256(raw).hexdigest()
    Path(path).write_text(json.dumps(payload,indent=2),encoding="utf-8")
    return payload
