from datetime import datetime, timezone

def build(run_record, runtime_identity, binding_hash, manifest_sha256):
    return {
        "run_id": run_record["run_id"],
        "runtime_identity": runtime_identity,
        "binding_hash": binding_hash,
        "manifest_sha256": manifest_sha256,
        "validated_success": run_record["validated_success"],
        "evidence_level": run_record["evidence_level"],
        "audited_at": datetime.now(timezone.utc).isoformat()
    }
