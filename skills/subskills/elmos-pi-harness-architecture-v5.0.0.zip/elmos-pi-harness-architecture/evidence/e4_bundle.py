from pathlib import Path
import json, hashlib, shutil

REQUIRED_ARTIFACTS = [
    "stdout.txt",
    "stderr.txt",
    "diff.patch",
    "verification.json",
    "run.json",
    "manifest.json"
]

def file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def build(run_dir, bundle_dir, provenance=None):
    run_dir = Path(run_dir)
    bundle_dir = Path(bundle_dir)
    bundle_dir.mkdir(parents=True, exist_ok=True)

    missing = [name for name in REQUIRED_ARTIFACTS if not (run_dir / name).exists()]
    if missing:
        return {"ready": False, "missing": missing}

    entries = []
    for name in REQUIRED_ARTIFACTS:
        src = run_dir / name
        dst = bundle_dir / name
        shutil.copy2(src, dst)
        entries.append({
            "path": name,
            "sha256": file_hash(dst),
            "bytes": dst.stat().st_size
        })

    if provenance is not None:
        p = bundle_dir / "provenance.json"
        p.write_text(json.dumps(provenance, ensure_ascii=False, indent=2), encoding="utf-8")
        entries.append({"path": "provenance.json", "sha256": file_hash(p), "bytes": p.stat().st_size})

    bundle = {"artifacts": entries}
    raw = json.dumps(bundle, sort_keys=True, ensure_ascii=False).encode()
    bundle["bundle_sha256"] = hashlib.sha256(raw).hexdigest()
    (bundle_dir / "bundle.json").write_text(
        json.dumps(bundle, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return {"ready": True, "bundle_sha256": bundle["bundle_sha256"], "bundle_dir": str(bundle_dir)}
