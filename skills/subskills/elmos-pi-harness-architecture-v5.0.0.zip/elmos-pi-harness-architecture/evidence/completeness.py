REQUIRED = {
    "run_id","system","system_version","repo_revision",
    "task_case","validated_success","wall_clock_ms","manual_interventions"
}

def validate_record(record):
    missing = sorted(k for k in REQUIRED if k not in record)
    return {"valid": not missing, "missing": missing}

def validate_campaign(records, expected_count=None):
    invalid = []
    for i, r in enumerate(records):
        v = validate_record(r)
        if not v["valid"]:
            invalid.append({"index": i, **v})
    result = {
        "records": len(records),
        "complete_records": len(records) - len(invalid),
        "invalid_records": invalid
    }
    if expected_count is not None:
        result["expected_records"] = expected_count
        result["count_complete"] = len(records) == expected_count
    return result
