import hashlib,json
from pathlib import Path

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def verify_manifest(manifest_path,root):
    manifest=json.loads(Path(manifest_path).read_text())
    failures=[]
    for item in manifest.get("files",[]):
        p=Path(root)/item["path"]
        if not p.exists():
            failures.append({"path":item["path"],"reason":"missing"})
        elif sha256_file(p)!=item["sha256"]:
            failures.append({"path":item["path"],"reason":"hash_mismatch"})
    return {"valid":not failures,"failures":failures}
