def persist_if_eligible(store, campaign_id, job_id, record, manifest_uri, manifest_sha256):
    if record.get("status") != "EXECUTED":
        return {"persisted": False, "reason": "not_executed"}

    verification = record.get("verification")
    if not verification or verification.get("passed") is None:
        return {"persisted": False, "reason": "missing_verification"}

    result = store.persist_e4(
        campaign_id=campaign_id,
        job_id=job_id,
        record=record,
        manifest_uri=manifest_uri,
        manifest_sha256=manifest_sha256
    )
    return {"persisted": True, "result": result}
