from collections import defaultdict
from benchmark.statistical_gate import summarize_success, evidence_ready

def build_e5(records, min_repetitions=5):
    groups = defaultdict(list)
    for r in records:
        groups[(r["system"], r["task_case"])].append(r)

    summary = {}
    ready = True
    reasons = []
    for key, rows in groups.items():
        ok, reason = evidence_ready(rows, min_repetitions=min_repetitions)
        summary[str(key)] = summarize_success(rows)
        if not ok:
            ready = False
            reasons.append({"group": str(key), "reason": reason})

    return {"target_level":"E5","ready":ready,"reasons":reasons,"summary":summary}
