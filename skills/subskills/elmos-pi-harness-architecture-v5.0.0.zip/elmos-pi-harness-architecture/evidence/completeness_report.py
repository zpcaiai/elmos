REQUIRED = [
    "campaign_id","job_id","run_id","system","model","provider",
    "repo_revision","task_case","validated_success","evidence_level",
    "manifest_sha256","provenance_sha256","binding_hash"
]

def evaluate(payload):
    missing = [k for k in REQUIRED if payload.get(k) in (None, "")]
    return {
        "complete": not missing,
        "missing": missing,
        "field_count": len(REQUIRED),
        "present_count": len(REQUIRED) - len(missing)
    }
