# First Bound E4 Admission Report

Record:
- runtime identity
- connector conformance
- repository/revision
- bound task plan hash
- execution envelope
- Run ID
- stdout/stderr/diff
- deterministic verifier
- sealed manifest
- PostgreSQL lineage
- E4 admission result

BLOCKED runs are reported separately and never counted in benchmark success statistics.
