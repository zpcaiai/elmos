# Transactional Evidence Ingestion

A completed run is ingested atomically:

1. validate normalized record
2. verify evidence manifest hash
3. insert normalized harness result
4. insert verifier artifact linkage
5. update benchmark job run_id/evidence_uri
6. append evidence promotion event
7. commit

If any required step fails, rollback the transaction.
