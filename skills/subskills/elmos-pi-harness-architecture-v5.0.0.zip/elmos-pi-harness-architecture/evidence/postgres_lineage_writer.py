import json

class PostgresLineageWriter:
    def __init__(self, connection_factory):
        self.connection_factory = connection_factory

    def persist(self, campaign_id, job_id, run_record, manifest_uri, manifest_sha256, provenance):
        with self.connection_factory() as conn:
            conn.execute(
                '''insert into run_evidence_lineage(
                   run_id,campaign_id,job_id,evidence_level,manifest_uri,manifest_sha256)
                   values(%s,%s,%s,%s,%s,%s)
                   on conflict(run_id) do nothing''',
                (
                    run_record["run_id"],
                    campaign_id,
                    job_id,
                    run_record["evidence_level"],
                    manifest_uri,
                    manifest_sha256
                )
            )

            conn.execute(
                '''insert into evidence_provenance(
                   run_id,plan_sha256,manifest_sha256,provenance_sha256,
                   runtime_identity,repo_revision,verifier)
                   values(%s,%s,%s,%s,%s::jsonb,%s,%s::jsonb)
                   on conflict(run_id) do nothing''',
                (
                    run_record["run_id"],
                    provenance["plan_sha256"],
                    manifest_sha256,
                    provenance["provenance_sha256"],
                    json.dumps(provenance["runtime_identity"]),
                    run_record["repo_revision"],
                    json.dumps(provenance["verifier"])
                )
            )

            conn.execute(
                '''update benchmark_execution_job
                   set status='COMPLETED',run_id=%s,evidence_uri=%s,updated_at=now()
                   where id=%s''',
                (run_record["run_id"], manifest_uri, job_id)
            )

            conn.commit()

        return {
            "persisted": True,
            "run_id": run_record["run_id"],
            "evidence_level": run_record["evidence_level"]
        }
