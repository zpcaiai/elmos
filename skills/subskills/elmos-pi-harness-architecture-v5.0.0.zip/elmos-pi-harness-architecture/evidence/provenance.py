import hashlib,json
from datetime import datetime,timezone

def build(run_id,plan_sha256,manifest_sha256,runtime_identity,repo_revision,verifier):
    payload={
      "run_id":run_id,
      "plan_sha256":plan_sha256,
      "manifest_sha256":manifest_sha256,
      "runtime_identity":runtime_identity,
      "repo_revision":repo_revision,
      "verifier":verifier,
      "sealed_at":datetime.now(timezone.utc).isoformat()
    }
    payload["provenance_sha256"]=hashlib.sha256(
      json.dumps(payload,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    return payload
