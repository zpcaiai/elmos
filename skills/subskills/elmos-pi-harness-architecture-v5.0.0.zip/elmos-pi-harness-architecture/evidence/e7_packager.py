def build_e7(e6_pack, pilot_acceptance):
    ready = bool(
        e6_pack.get("ready")
        and pilot_acceptance
        and pilot_acceptance.get("status") == "ACCEPTED"
        and pilot_acceptance.get("evidence_ids")
    )
    return {"target_level":"E7","ready":ready,"e6":e6_pack,"pilot_acceptance":pilot_acceptance}
