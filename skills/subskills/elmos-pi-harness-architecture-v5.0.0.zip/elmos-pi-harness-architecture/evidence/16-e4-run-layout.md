# E4 Run Directory Layout

`.elmos-evidence/<run_id>/`

Required:
- `stdout.txt`
- `stderr.txt`
- `verification.json`
- `run.json`

Recommended:
- `diff.patch`
- `manifest.json`
- `provenance.json`
- `runtime-identity.json`
- `environment-lock.json`

The verifier output is evidence even when the task fails.
