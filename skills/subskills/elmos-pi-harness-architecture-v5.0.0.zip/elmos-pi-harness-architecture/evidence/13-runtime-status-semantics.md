# Runtime Status Semantics

`BLOCKED`
- prerequisites absent
- no run ID
- no E3/E4 claim

`EXECUTED`
- actual runtime invocation occurred
- run ID exists
- evidence artifacts exist

`VERIFIED`
- deterministic verifier completed

`E4`
- EXECUTED + deterministic verification + immutable manifest + durable lineage

Never convert BLOCKED into a synthetic failure/success benchmark row.
