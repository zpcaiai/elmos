# Evidence Warehouse Ingestion

Ingest only normalized E3+ run records.

Pipeline:
raw run artifact
→ schema validation
→ verifier linkage
→ evidence manifest hash check
→ normalize nullable metrics
→ insert benchmark warehouse row
→ associate campaign/run IDs

Reject:
- missing run ID
- missing repository revision
- missing task case
- missing wall-clock
- invalid evidence manifest
- fabricated metrics
