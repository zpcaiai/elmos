# Kernel Contracts

## AgentRuntime
Turn lifecycle, model calls, tool calls, steering, events, checkpoints. No domain semantics.

## ContextRuntime
Inputs: task, repo graph, failures, artifacts, skills, policies, token budget. Outputs: ordered context, token estimate, cache keys, provenance.

## ModelRuntime
Provider-independent requests, streaming, tools, structured output, reasoning level, capability metadata, cost accounting, fallback.

## ToolRuntime
Registration, schema validation, permission check, sandbox, timeout/cancel, idempotency, stdout/stderr/artifact capture.

## TaskRuntime
DAG nodes, retries, pause/resume/cancel, checkpoints, leases/heartbeats, recovery, concurrency.

## VerificationRuntime
Compile/lint/test/security/perf/UI checks, baseline comparison, evidence aggregation.

## TransformationRuntime
AST-aware patches, Semantic IR, rewrite recipes, reversible migrations, differential validation.
