# Target Architecture

## Kernel
- AgentRuntime
- ContextRuntime
- ToolRuntime
- TaskRuntime
- ArtifactRuntime
- ModelRuntime
- PolicyRuntime
- EventRuntime
- VerificationRuntime
- TransformationRuntime
- CacheRuntime

No domain-specific logic is allowed in the kernel.

## Control plane
Tenant/project/task lifecycle, policy/approvals, budgets/quotas, scheduling, model routing, package registry, observability, billing.

## Execution data plane
Repo checkout/worktree, sandbox, source index, context materialization, tool invocation, patching, verification, artifact production.

## Persistent graph model
Pi-style session tree becomes `conversation_tree + task_dag + artifact_graph + decision_graph`, enabling branch, fork, retry, rollback, compare, merge, replay.

## Extensibility
Packages may contribute skills, agents, tools, prompts, policies, adapters, transformations, validators, evals, UI descriptors. Packages are versioned, signed and permission-scoped.
