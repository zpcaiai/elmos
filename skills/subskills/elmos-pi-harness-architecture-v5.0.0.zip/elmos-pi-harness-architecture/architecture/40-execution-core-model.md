# Execution Core Model v4.9

Identity: execution/root/parent IDs + ExecutionSource.
Ownership: RuntimeOwner, ownership epoch, handoff state, durable barrier.
TypedContext: content + semantic kind + producer + provenance + trust + scope + replay/retention policy.
Timeline: canonical append-only events.
Artifacts: typed durable plan/patch/report/checkpoint/review evidence.
Policy: intersection of tenant, harness, environment and tool authorities.
Lifecycle: Started → Running → InterruptRequested → InterruptHooks → Completed | Aborted | Suspended/HandoffReady.
Effects: command, stdin, network, mutation, browser, credential and computer-use actions.
