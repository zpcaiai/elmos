# Repository Intelligence Architecture

## Layers
L0 repository snapshot
L1 parsed syntax
L2 symbols and types
L3 dependency/call/data/API graph
L4 tests and runtime evidence
L5 historical decisions, validated patches, failures

## Retrieval
objective
→ exact symbol lookup
→ lexical retrieval
→ semantic retrieval
→ graph expansion
→ failure/change boosts
→ authority/recency adjustment
→ reranking
→ token budget optimization
→ stable/dynamic prompt partition

## Nodes
repo, module, package, file, class, interface, enum, function, method, field,
API endpoint, DB table, queue/topic, config key, build target, test, runtime service, artifact.

## Edges
contains, imports, calls, extends, implements, reads, writes, exposes, consumes,
produces, tests, configures, depends_on, deploys.
