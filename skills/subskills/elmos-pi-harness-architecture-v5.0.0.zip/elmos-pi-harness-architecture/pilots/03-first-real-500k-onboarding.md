# First Real >500k LOC Pilot Onboarding

1. Authorization and data-handling scope
2. Pin immutable revision
3. Verify real source LOC >500k
4. Reproduce build/tests
5. Capture baseline wall-clock
6. Index and resolve repository
7. Execute selected benchmark tasks / Golden Route
8. Inject supported failure
9. Resume and verify
10. Full regression
11. Rollback proof
12. Generate immutable evidence bundle
13. Repeat to estimate variance
