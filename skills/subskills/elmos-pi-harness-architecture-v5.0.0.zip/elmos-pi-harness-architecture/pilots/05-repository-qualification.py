from dataclasses import dataclass

@dataclass
class QualificationResult:
    qualified: bool
    reasons: list[str]
    score: int

def qualify(repo):
    score = 0
    reasons = []

    if repo.get("immutable_revision"):
        score += 20
    else:
        reasons.append("missing_immutable_revision")

    if repo.get("reproducible_build"):
        score += 20
    else:
        reasons.append("build_not_reproducible")

    if repo.get("reproducible_tests"):
        score += 20
    else:
        reasons.append("tests_not_reproducible")

    if repo.get("authorized"):
        score += 20
    else:
        reasons.append("missing_authorization")

    if int(repo.get("loc", 0)) >= 500000:
        score += 20
    else:
        reasons.append("below_500k_loc")

    return QualificationResult(score == 100, reasons, score)
