# First >500k LOC Pilot Execution Plan

1. Intake and authorization
2. Pin commit/revision
3. Count real source LOC
4. Capture toolchain and dependency versions
5. Baseline build/test
6. Index/resolve repository
7. Run selected Golden Route or repository task
8. Capture machine wall-clock, cost, token, cache and repair metrics
9. Inject supported failures
10. Resume and verify
11. Full regression
12. Rollback proof
13. Generate immutable evidence bundle
14. Repeat enough times to estimate variance
15. Certification review

Pilot does not become a commercial reference until evidence is complete.
