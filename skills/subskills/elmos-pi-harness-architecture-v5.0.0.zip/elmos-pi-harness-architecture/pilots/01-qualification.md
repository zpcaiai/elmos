# Large Repository Pilot Qualification

Required:
- immutable revision
- real application code
- reproducible build
- reproducible tests
- measurable LOC
- known toolchain/dependencies
- authorization to benchmark

Certification target:
- at least 3 repos >500k LOC
- at least 1 repo >1M LOC

Generated filler code does not qualify.
