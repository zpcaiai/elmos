# Large Repository Certification Readiness

Readiness dimensions:
- authorization
- immutable revision
- reproducible build
- reproducible tests
- LOC threshold
- stable toolchain
- full verification feasibility
- rollback feasibility
- evidence retention permission

A repo can be technically runnable but still not certification-ready.
