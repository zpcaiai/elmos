# Real Repository Evidence Contract

For >500k LOC pilot certification retain:
- repository identity under allowed disclosure level
- immutable commit
- LOC method/tool
- baseline build/test commands
- dependency lock/build environment
- benchmark task definitions
- all run IDs
- full verification evidence
- failure/recovery evidence
- cost and machine wall-clock
- rollback proof

If repository confidentiality prevents naming it publicly, internal certification evidence must still retain immutable identity.
