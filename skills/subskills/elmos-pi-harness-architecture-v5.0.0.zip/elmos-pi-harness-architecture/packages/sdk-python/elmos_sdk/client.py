import httpx

class ElmosClient:
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")

    def create_task(self, project_id: str, objective: str, **kwargs):
        payload = {"project_id": project_id, "objective": objective, **kwargs}
        r = httpx.post(f"{self.base_url}/v1/tasks", json=payload, timeout=30)
        r.raise_for_status()
        return r.json()

    def get_task(self, task_id: str):
        r = httpx.get(f"{self.base_url}/v1/tasks/{task_id}", timeout=30)
        r.raise_for_status()
        return r.json()
