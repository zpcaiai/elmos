from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Any, Literal

TaskStatus = Literal[
    "CREATED","QUEUED","PLANNING","RUNNING","VERIFYING",
    "WAITING_APPROVAL","PAUSED","CANCEL_REQUESTED",
    "CANCELLED","FAILED","SUCCEEDED"
]

class Budget(BaseModel):
    max_cost_usd: float | None = Field(default=None, ge=0)
    max_wall_clock_seconds: int | None = Field(default=None, ge=1)
    max_tokens: int | None = Field(default=None, ge=1)

class TaskCreate(BaseModel):
    project_id: str
    tenant_id: str
    objective: str = Field(min_length=1)
    constraints: dict[str, Any] = {}
    budgets: Budget = Budget()
    model_policy: str = "auto"

class ProviderUsage(BaseModel):
    input_tokens: int = 0
    output_tokens: int = 0
    cached_input_tokens: int = 0
    cost_usd: float = 0.0

class ProviderResult(BaseModel):
    provider: str
    model: str
    text: str
    usage: ProviderUsage
    latency_ms: int
    finish_reason: str | None = None

class VerificationResult(BaseModel):
    gate: str
    status: Literal["passed","failed","skipped"]
    evidence: dict[str, Any] = {}
