import asyncio, json
from dataclasses import dataclass

@dataclass
class LspResponse:
    result: object | None
    error: object | None

class JsonRpcProcessClient:
    def __init__(self, command):
        self.command=command
        self.proc=None
        self._id=0

    async def start(self):
        self.proc=await asyncio.create_subprocess_exec(
            *self.command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

    async def stop(self):
        if self.proc:
            self.proc.terminate()
            await self.proc.wait()

    async def request(self, method, params):
        if not self.proc:
            await self.start()
        self._id += 1
        msg={"jsonrpc":"2.0","id":self._id,"method":method,"params":params}
        body=json.dumps(msg).encode()
        header=f"Content-Length: {len(body)}\r\n\r\n".encode()
        self.proc.stdin.write(header+body)
        await self.proc.stdin.drain()
        return LspResponse(None, {"status":"reader_requires_full_lsp_framing"})

class GoplsClient(JsonRpcProcessClient):
    def __init__(self): super().__init__(["gopls","serve"])

class RustAnalyzerClient(JsonRpcProcessClient):
    def __init__(self): super().__init__(["rust-analyzer"])

class RoslynClient(JsonRpcProcessClient):
    def __init__(self, executable="Elmos.RoslynResolver"):
        super().__init__([executable,"--stdio"])
