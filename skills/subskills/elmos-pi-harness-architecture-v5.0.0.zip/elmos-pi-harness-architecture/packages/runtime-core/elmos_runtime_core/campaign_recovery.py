TERMINAL = {"RELEASED","CLAIM_REJECTED"}

def recovery_action(campaign, artifacts):
    state = campaign["state"]
    if state in TERMINAL:
        return {"action":"none","reason":"terminal"}
    if state == "RUNNING" and not artifacts.get("run_ids"):
        return {"action":"resume_execution"}
    if state == "VERIFYING" and not artifacts.get("verification_results"):
        return {"action":"resume_verification"}
    if state == "NORMALIZING" and not artifacts.get("normalized_records"):
        return {"action":"resume_normalization"}
    if state == "ANALYZING" and not artifacts.get("statistics"):
        return {"action":"resume_analysis"}
    return {"action":"inspect_transition_requirements"}
