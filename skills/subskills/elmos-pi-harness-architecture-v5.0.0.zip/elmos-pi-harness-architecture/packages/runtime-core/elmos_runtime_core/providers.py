from __future__ import annotations
import os, time, httpx
from .models import ProviderResult, ProviderUsage

class ProviderError(RuntimeError):
    pass

class BaseProvider:
    name = "base"
    async def complete(self, model: str, messages: list[dict], **kwargs) -> ProviderResult:
        raise NotImplementedError

class OpenAIProvider(BaseProvider):
    name = "openai"
    def __init__(self):
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.base_url = os.getenv("OPENAI_BASE_URL","https://api.openai.com/v1")
    async def complete(self, model: str, messages: list[dict], **kwargs):
        if not self.api_key:
            raise ProviderError("OPENAI_API_KEY missing")
        started = time.perf_counter()
        headers={"Authorization":f"Bearer {self.api_key}","Content-Type":"application/json"}
        payload={"model":model,"messages":messages}
        payload.update(kwargs)
        async with httpx.AsyncClient(timeout=120) as c:
            r=await c.post(f"{self.base_url}/chat/completions",headers=headers,json=payload)
            r.raise_for_status()
            data=r.json()
        usage=data.get("usage",{})
        return ProviderResult(
            provider=self.name, model=model,
            text=data["choices"][0]["message"].get("content",""),
            usage=ProviderUsage(
                input_tokens=usage.get("prompt_tokens",0),
                output_tokens=usage.get("completion_tokens",0),
                cached_input_tokens=usage.get("prompt_tokens_details",{}).get("cached_tokens",0),
                cost_usd=0.0
            ),
            latency_ms=int((time.perf_counter()-started)*1000),
            finish_reason=data["choices"][0].get("finish_reason")
        )

class AnthropicProvider(BaseProvider):
    name = "anthropic"
    def __init__(self):
        self.api_key = os.getenv("ANTHROPIC_API_KEY")
        self.base_url = os.getenv("ANTHROPIC_BASE_URL","https://api.anthropic.com/v1")
    async def complete(self, model: str, messages: list[dict], **kwargs):
        if not self.api_key:
            raise ProviderError("ANTHROPIC_API_KEY missing")
        started=time.perf_counter()
        headers={
            "x-api-key":self.api_key,
            "anthropic-version":"2023-06-01",
            "content-type":"application/json"
        }
        system=None
        user_messages=[]
        for m in messages:
            if m.get("role")=="system":
                system=m.get("content")
            else:
                user_messages.append(m)
        payload={"model":model,"messages":user_messages,"max_tokens":kwargs.pop("max_tokens",4096)}
        if system: payload["system"]=system
        payload.update(kwargs)
        async with httpx.AsyncClient(timeout=120) as c:
            r=await c.post(f"{self.base_url}/messages",headers=headers,json=payload)
            r.raise_for_status()
            data=r.json()
        usage=data.get("usage",{})
        text="".join(block.get("text","") for block in data.get("content",[]) if block.get("type")=="text")
        return ProviderResult(
            provider=self.name, model=model, text=text,
            usage=ProviderUsage(
                input_tokens=usage.get("input_tokens",0),
                output_tokens=usage.get("output_tokens",0),
                cached_input_tokens=usage.get("cache_read_input_tokens",0),
                cost_usd=0.0
            ),
            latency_ms=int((time.perf_counter()-started)*1000),
            finish_reason=data.get("stop_reason")
        )

class OpenRouterProvider(OpenAIProvider):
    name = "openrouter"
    def __init__(self):
        self.api_key = os.getenv("OPENROUTER_API_KEY")
        self.base_url = os.getenv("OPENROUTER_BASE_URL","https://openrouter.ai/api/v1")
