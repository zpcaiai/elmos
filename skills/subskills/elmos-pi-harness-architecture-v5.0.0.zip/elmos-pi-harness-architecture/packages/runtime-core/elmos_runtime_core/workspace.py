from __future__ import annotations
from pathlib import Path
import subprocess, shutil, os
from uuid import uuid4

WORKSPACE_ROOT = Path(os.getenv("ELMOS_WORKSPACE_ROOT","/tmp/elmos-workspaces"))

def run(*args, cwd=None):
    p=subprocess.run(args,cwd=cwd,text=True,capture_output=True)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.strip() or p.stdout.strip())
    return p.stdout.strip()

class WorkspaceManager:
    def __init__(self, root: Path = WORKSPACE_ROOT):
        self.root=root
        self.root.mkdir(parents=True,exist_ok=True)

    def clone(self, repo_uri: str, revision: str | None = None) -> Path:
        target=self.root / f"repo-{uuid4().hex[:12]}"
        run("git","clone","--no-tags",repo_uri,str(target))
        if revision:
            run("git","checkout",revision,cwd=target)
        return target

    def create_worktree(self, repo: Path, task_id: str, base_ref: str="HEAD") -> Path:
        target=self.root / f"task-{task_id}"
        branch=f"elmos/{task_id}"
        run("git","worktree","add","-b",branch,str(target),base_ref,cwd=repo)
        return target

    def remove(self, path: Path):
        if path.exists():
            shutil.rmtree(path,ignore_errors=True)
