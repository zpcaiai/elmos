from dataclasses import dataclass

FORBIDDEN_KEYS = {
    "security_policy",
    "tenant_authorization",
    "mandatory_release_gates",
    "destructive_action_approval"
}

@dataclass
class CandidatePolicy:
    version: str
    config: dict
    evidence_ids: list[str]

def validate_candidate(candidate):
    forbidden = FORBIDDEN_KEYS.intersection(candidate.config)
    if forbidden:
        raise ValueError(f"candidate modifies forbidden keys: {sorted(forbidden)}")
    if not candidate.evidence_ids:
        raise ValueError("candidate requires evidence")
    return True
