from contextlib import contextmanager
from psycopg_pool import ConnectionPool
import os, json
from uuid import uuid4

DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql://elmos:elmos@localhost:5432/elmos")
pool = ConnectionPool(DATABASE_URL, min_size=1, max_size=int(os.getenv("DB_POOL_MAX","10")))

@contextmanager
def connection():
    with pool.connection() as conn:
        yield conn

def append_event(task_id: str, tenant_id: str, event_type: str, payload: dict):
    with connection() as conn:
        conn.execute(
            "insert into task_event(task_id, tenant_id, event_type, payload) values (%s,%s,%s,%s::jsonb)",
            (task_id, tenant_id, event_type, json.dumps(payload))
        )
        conn.commit()

def create_task(row: dict) -> str:
    task_id = row.get("id") or str(uuid4())
    with connection() as conn:
        conn.execute(
            '''
            insert into task(id, tenant_id, project_id, objective, status, model_policy, token_budget, cost_budget_usd)
            values (%s,%s,%s,%s,'CREATED',%s,%s,%s)
            ''',
            (
                task_id, row["tenant_id"], row["project_id"], row["objective"],
                row.get("model_policy","auto"), row.get("max_tokens"), row.get("max_cost_usd")
            )
        )
        conn.commit()
    append_event(task_id, row["tenant_id"], "task.created", {"objective": row["objective"]})
    return task_id

def update_task_status(task_id: str, tenant_id: str, status: str):
    with connection() as conn:
        conn.execute("update task set status=%s, updated_at=now() where id=%s and tenant_id=%s",
                     (status, task_id, tenant_id))
        conn.commit()
    append_event(task_id, tenant_id, "task.status_changed", {"status": status})

def get_task(task_id: str, tenant_id: str):
    with connection() as conn:
        row = conn.execute(
            "select id, tenant_id, project_id, objective, status, model_policy, created_at, updated_at "
            "from task where id=%s and tenant_id=%s",
            (task_id, tenant_id)
        ).fetchone()
        if not row:
            return None
        keys = ["id","tenant_id","project_id","objective","status","model_policy","created_at","updated_at"]
        return dict(zip(keys,row))
