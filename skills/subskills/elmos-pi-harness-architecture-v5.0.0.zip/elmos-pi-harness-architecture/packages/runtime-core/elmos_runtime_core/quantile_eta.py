from dataclasses import dataclass

@dataclass
class QuantilePrediction:
    p50: float
    p90: float
    confidence: float
    model_version: str

class QuantileEtaModel:
    def __init__(self, predictor=None, version="baseline-quantile-v1"):
        self.predictor = predictor
        self.version = version

    def predict(self, features: dict):
        if self.predictor is None:
            base = float(features.get("baseline_seconds", 60.0))
            repairs = float(features.get("expected_repairs", 0.0))
            p50 = base * (1 + 0.25 * repairs)
            p90 = p50 * (1.35 + 0.10 * repairs)
            return QuantilePrediction(p50, p90, 0.55, self.version)
        p50, p90 = self.predictor(features)
        return QuantilePrediction(float(p50), float(p90), 0.8, self.version)
