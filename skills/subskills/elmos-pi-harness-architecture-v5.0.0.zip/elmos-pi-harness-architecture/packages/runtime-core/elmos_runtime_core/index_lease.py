from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

@dataclass
class Lease:
    shard_id: str
    owner: str
    expires_at: datetime

def new_lease(shard_id, owner, seconds=120):
    return Lease(shard_id, owner, datetime.now(timezone.utc) + timedelta(seconds=seconds))

def expired(lease):
    return datetime.now(timezone.utc) >= lease.expires_at

def heartbeat(lease, seconds=120):
    lease.expires_at = datetime.now(timezone.utc) + timedelta(seconds=seconds)
    return lease
