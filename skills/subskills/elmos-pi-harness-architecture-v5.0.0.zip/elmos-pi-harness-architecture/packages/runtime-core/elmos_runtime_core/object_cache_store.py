from pathlib import Path
import hashlib, os

class LocalObjectCacheStore:
    def __init__(self, root=None):
        self.root = Path(root or os.getenv("ELMOS_CACHE_OBJECT_ROOT", "/tmp/elmos-cache-objects"))
        self.root.mkdir(parents=True, exist_ok=True)

    def put(self, data: bytes):
        digest = hashlib.sha256(data).hexdigest()
        path = self.root / digest
        if not path.exists():
            path.write_bytes(data)
        return {"uri": f"file://{path}", "sha256": digest, "bytes": len(data)}

    def get(self, sha256):
        path = self.root / sha256
        return path.read_bytes() if path.exists() else None
