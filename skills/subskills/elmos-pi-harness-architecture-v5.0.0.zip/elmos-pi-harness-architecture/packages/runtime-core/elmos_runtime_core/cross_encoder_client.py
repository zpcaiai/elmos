from __future__ import annotations
import httpx

class CrossEncoderClient:
    def __init__(self, endpoint: str):
        self.endpoint=endpoint.rstrip("/")

    async def rerank(self, query: str, candidates: list[dict], top_k: int=20):
        payload={"query":query,"candidates":candidates,"top_k":top_k}
        async with httpx.AsyncClient(timeout=60) as c:
            r=await c.post(f"{self.endpoint}/rerank",json=payload)
            r.raise_for_status()
            return r.json()["results"]
