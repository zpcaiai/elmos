from collections import defaultdict, deque

def topological_order(nodes, edges):
    indeg={n:0 for n in nodes}
    out=defaultdict(list)
    for a,b in edges:
        out[a].append(b)
        indeg[b]=indeg.get(b,0)+1
    q=deque([n for n,d in indeg.items() if d==0])
    order=[]
    while q:
        n=q.popleft()
        order.append(n)
        for m in out[n]:
            indeg[m]-=1
            if indeg[m]==0:
                q.append(m)
    if len(order)!=len(nodes):
        raise ValueError("DAG contains cycle")
    return order,out

def critical_path(nodes, edges, duration_ms):
    order,out=topological_order(nodes,edges)
    longest={n:float(duration_ms.get(n,0)) for n in nodes}
    parent={n:None for n in nodes}
    for n in order:
        for m in out[n]:
            cand=longest[n]+float(duration_ms.get(m,0))
            if cand>longest[m]:
                longest[m]=cand
                parent[m]=n
    end=max(nodes,key=lambda n:longest[n]) if nodes else None
    path=[]
    while end is not None:
        path.append(end)
        end=parent[end]
    path.reverse()
    return {"path":path,"duration_ms":max(longest.values(),default=0),"longest":longest}

def ready_priority(node, cp_nodes, remaining_ms, unblock_count=0, sla_urgency=0.0):
    return (
        (1000 if node in cp_nodes else 0)
        + float(remaining_ms)
        + 25*unblock_count
        + 100*sla_urgency
    )
