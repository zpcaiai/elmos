from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import subprocess

@dataclass
class GitDelta:
    added: list[str]
    modified: list[str]
    deleted: list[str]
    renamed: list[tuple[str,str]]

def git_delta(repo: Path, old_rev: str, new_rev: str) -> GitDelta:
    p = subprocess.run(
        ["git","diff","--name-status","-M",old_rev,new_rev],
        cwd=repo,text=True,capture_output=True,check=True
    )
    added,modified,deleted,renamed=[],[],[],[]
    for line in p.stdout.splitlines():
        parts=line.split("\t")
        status=parts[0]
        if status=="A":
            added.append(parts[1])
        elif status=="M":
            modified.append(parts[1])
        elif status=="D":
            deleted.append(parts[1])
        elif status.startswith("R") and len(parts)>=3:
            renamed.append((parts[1],parts[2]))
    return GitDelta(added,modified,deleted,renamed)

def affected_paths(delta: GitDelta):
    out=set(delta.added+delta.modified+delta.deleted)
    for a,b in delta.renamed:
        out.add(a); out.add(b)
    return sorted(out)
