def schedule_verification(changed_nodes, impacted_tests, risk="medium"):
    waves=[]
    waves.append({"wave":0,"gates":["compile","lint"]})

    direct=[t for t in impacted_tests if getattr(t,"metadata",{}).get("distance",1) <= 1]
    near=[t for t in impacted_tests if getattr(t,"metadata",{}).get("distance",2) <= 3]

    if direct:
        waves.append({"wave":1,"tests":[getattr(t,"qualified_name",str(t)) for t in direct]})
    if near:
        waves.append({"wave":2,"tests":[getattr(t,"qualified_name",str(t)) for t in near]})

    if risk in {"high","critical"}:
        waves.append({"wave":3,"gates":["module_integration"]})
    if risk=="critical":
        waves.append({"wave":4,"gates":["full_regression"]})
    return waves
