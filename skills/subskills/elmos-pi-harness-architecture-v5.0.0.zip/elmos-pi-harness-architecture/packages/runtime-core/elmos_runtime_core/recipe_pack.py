from pathlib import Path
import yaml
from .recipe_runner import load_recipe, execute_actions

def run_recipe_pack(root: Path, pack_path: Path):
    pack=yaml.safe_load(pack_path.read_text(encoding="utf-8"))
    results=[]
    for rel in pack["ordered_recipes"]:
        recipe_path=pack_path.parent / rel
        if not recipe_path.exists():
            results.append({"recipe":rel,"status":"missing"})
            continue
        recipe=load_recipe(recipe_path)
        try:
            changed=execute_actions(root,recipe)
            results.append({"recipe":recipe["id"],"status":"applied","changed_files":changed})
        except Exception as e:
            results.append({"recipe":recipe.get("id",rel),"status":"needs_semantic_adapter","error":str(e)})
    return {"pack":pack["name"],"results":results}
