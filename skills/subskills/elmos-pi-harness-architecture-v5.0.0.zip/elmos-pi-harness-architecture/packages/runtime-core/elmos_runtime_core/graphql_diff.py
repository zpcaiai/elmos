def compare_schema(old, new):
    breaking=[]
    old_types=old.get("types",{})
    new_types=new.get("types",{})
    for tname,tdef in old_types.items():
        if tname not in new_types:
            breaking.append({"type":"removed_type","name":tname})
            continue
        old_fields=set(tdef.get("fields",{}))
        new_fields=set(new_types[tname].get("fields",{}))
        for field in sorted(old_fields-new_fields):
            breaking.append({"type":"removed_field","type_name":tname,"field":field})
    return {"breaking":breaking}
