def evaluate_canary(baseline,candidate,min_samples=30):
    if candidate.get("samples",0)<min_samples:
        return {"action":"hold","reason":"insufficient_samples"}
    if candidate["validated_success_rate"] < baseline["validated_success_rate"]:
        return {"action":"rollback","reason":"success_regression"}
    if candidate.get("critical_incidents",0)>0:
        return {"action":"rollback","reason":"critical_incident"}
    if candidate["cost_per_success"] > baseline["cost_per_success"]*1.05:
        return {"action":"hold","reason":"cost_regression"}
    if candidate["p95_wall_clock_ms"] > baseline["p95_wall_clock_ms"]*1.10:
        return {"action":"hold","reason":"latency_regression"}
    return {"action":"advance","reason":"guardrails_pass"}
