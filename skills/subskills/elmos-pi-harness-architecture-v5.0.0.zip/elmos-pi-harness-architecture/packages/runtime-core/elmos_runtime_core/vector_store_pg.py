from __future__ import annotations
import json

class PgVectorRuntimeStore:
    def __init__(self, connection_factory):
        self.connection_factory=connection_factory

    def upsert(self, project_id, revision, node_id, model, vector, metadata=None):
        metadata = metadata or {}
        with self.connection_factory() as conn:
            conn.execute(
                '''
                insert into repository_vector(
                  project_id,revision,node_id,embedding_model,dimension,embedding,metadata
                ) values (%s,%s,%s,%s,%s,%s,%s::jsonb)
                on conflict(project_id,revision,node_id,embedding_model)
                do update set embedding=excluded.embedding, dimension=excluded.dimension,
                              metadata=excluded.metadata, created_at=now()
                ''',
                (project_id,revision,node_id,model,len(vector),vector,json.dumps(metadata))
            )
            conn.commit()

    def search(self, project_id, revision, model, query_vector, limit=20):
        with self.connection_factory() as conn:
            rows=conn.execute(
                '''
                select node_id, 1 - (embedding <=> %s) as score
                from repository_vector
                where project_id=%s and revision=%s and embedding_model=%s
                order by embedding <=> %s
                limit %s
                ''',
                (query_vector,project_id,revision,model,query_vector,limit)
            ).fetchall()
            return [{"node_id":str(r[0]),"score":float(r[1])} for r in rows]
