WEIGHTS = {
    "quality": 0.20,
    "large_repo": 0.15,
    "reliability": 0.15,
    "economics": 0.15,
    "security": 0.10,
    "eta_sla": 0.10,
    "paid_pilot": 0.10,
    "competitive_evidence": 0.05,
}

HARD_FAIL_KEYS = {"critical_security_issue", "data_loss", "unsafe_duplicate_side_effect"}

def score(metrics):
    if any(metrics.get(k) for k in HARD_FAIL_KEYS):
        return {"score": 0.0, "hard_fail": True}
    total = 0.0
    for key, weight in WEIGHTS.items():
        total += max(0.0, min(100.0, float(metrics.get(key, 0)))) * weight
    return {"score": round(total, 2), "hard_fail": False}
