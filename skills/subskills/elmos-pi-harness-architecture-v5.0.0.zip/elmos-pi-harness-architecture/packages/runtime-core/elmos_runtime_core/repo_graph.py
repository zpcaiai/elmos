from dataclasses import dataclass, field
from collections import defaultdict, deque
from typing import Any, Iterable

@dataclass
class RepoNode:
    id: str
    node_type: str
    qualified_name: str
    file_path: str | None = None
    start_line: int | None = None
    end_line: int | None = None
    language: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class RepoEdge:
    from_id: str
    to_id: str
    edge_type: str
    weight: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)

class RepoGraph:
    def __init__(self):
        self.nodes = {}
        self.out_edges = defaultdict(list)
        self.in_edges = defaultdict(list)

    def add_node(self, n):
        self.nodes[n.id] = n

    def add_edge(self, e):
        self.out_edges[e.from_id].append(e)
        self.in_edges[e.to_id].append(e)

    def expand(self, seeds: Iterable[str], hops=2, edge_types=None):
        q = deque((s,0) for s in seeds)
        seen = set(seeds)
        result = []
        while q:
            nid, d = q.popleft()
            if nid in self.nodes:
                result.append(self.nodes[nid])
            if d >= hops:
                continue
            edges = self.out_edges[nid] + self.in_edges[nid]
            for e in edges:
                if edge_types and e.edge_type not in edge_types:
                    continue
                nxt = e.to_id if e.from_id == nid else e.from_id
                if nxt not in seen:
                    seen.add(nxt)
                    q.append((nxt,d+1))
        return result
