def validate_shard_artifacts(shards, expected_revision):
    errors = []
    for s in shards:
        if s.get("revision") != expected_revision:
            errors.append({"shard": s.get("id"), "reason": "revision_mismatch"})
        if s.get("status") != "VERIFIED":
            errors.append({"shard": s.get("id"), "reason": "not_verified"})
        if not s.get("artifact_sha256"):
            errors.append({"shard": s.get("id"), "reason": "missing_hash"})
    return errors

def can_merge(shards, expected_revision):
    return not validate_shard_artifacts(shards, expected_revision)
