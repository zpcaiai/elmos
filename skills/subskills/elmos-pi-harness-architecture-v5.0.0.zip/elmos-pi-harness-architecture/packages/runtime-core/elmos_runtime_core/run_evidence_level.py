def run_level(record):
    if not record.get("run_id") or not record.get("evidence_manifest"):
        return "E2"
    if "verification" not in record or record["verification"].get("passed") is None:
        return "E3"
    return "E4"
