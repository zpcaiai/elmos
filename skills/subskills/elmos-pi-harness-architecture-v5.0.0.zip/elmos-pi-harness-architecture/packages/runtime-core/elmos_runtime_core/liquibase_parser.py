from __future__ import annotations
from pathlib import Path
import xml.etree.ElementTree as ET

TAG_TO_TYPE = {
    "dropTable":"drop_table",
    "dropColumn":"drop_column",
    "addColumn":"add_column",
    "createTable":"create_table",
    "modifyDataType":"change_type"
}

def parse_liquibase_xml(path: Path):
    root=ET.parse(path).getroot()
    ops=[]
    for elem in root.iter():
        tag=elem.tag.split("}")[-1]
        if tag in TAG_TO_TYPE:
            ops.append({"type":TAG_TO_TYPE[tag],"file":str(path),"attrs":dict(elem.attrib)})
    return ops
