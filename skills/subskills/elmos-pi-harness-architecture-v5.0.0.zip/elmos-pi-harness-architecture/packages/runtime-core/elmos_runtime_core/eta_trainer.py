class QuantileEtaTrainer:
    def train(self, records):
        if not records:
            raise ValueError("no training records")
        return {
            "artifact_type": "quantile_eta_model",
            "training_rows": len(records),
            "status": "training_adapter_required"
        }
