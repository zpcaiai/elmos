import json, time
from dataclasses import asdict
from .semantic_cache_backend import SemanticCacheRecord

class RedisSemanticCache:
    def __init__(self, redis_client, namespace="elmos:semantic-cache", ttl_seconds=86400):
        self.redis = redis_client
        self.namespace = namespace
        self.ttl_seconds = ttl_seconds

    def _key(self, cache_key):
        return f"{self.namespace}:{cache_key}"

    def get_exact(self, cache_key):
        raw = self.redis.get(self._key(cache_key))
        if not raw:
            return None
        return SemanticCacheRecord(**json.loads(raw))

    def put(self, record):
        self.redis.setex(
            self._key(record.cache_key),
            self.ttl_seconds,
            json.dumps(asdict(record), ensure_ascii=False)
        )

    def invalidate(self, cache_key, reason):
        self.redis.delete(self._key(cache_key))
        self.redis.hset(
            f"{self.namespace}:invalidations",
            cache_key,
            json.dumps({"reason": reason, "ts": time.time()})
        )
