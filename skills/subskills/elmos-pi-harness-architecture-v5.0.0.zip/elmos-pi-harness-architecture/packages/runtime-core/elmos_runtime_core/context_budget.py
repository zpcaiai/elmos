from dataclasses import dataclass

@dataclass
class ContextItem:
    id: str
    tokens: int
    value: float
    stable: bool
    group: str

def select_under_budget(items, budget_tokens):
    ranked = sorted(items, key=lambda x: x.value / max(x.tokens,1), reverse=True)
    selected, used = [], 0
    for item in ranked:
        if used + item.tokens <= budget_tokens:
            selected.append(item)
            used += item.tokens
    return selected, used
