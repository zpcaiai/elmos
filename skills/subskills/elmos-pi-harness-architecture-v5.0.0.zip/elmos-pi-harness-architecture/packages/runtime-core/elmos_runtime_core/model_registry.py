from dataclasses import dataclass
from typing import FrozenSet

@dataclass(frozen=True)
class ModelSpec:
    provider: str
    model: str
    tier: str
    capabilities: FrozenSet[str]
    max_context: int
    relative_cost: float

REGISTRY = [
    ModelSpec("openai", "gpt-5.6-sol", "T3", frozenset({"coding","reasoning","tools","large_context"}), 200000, 1.0),
    ModelSpec("anthropic", "claude-opus-4-1", "T3", frozenset({"coding","reasoning","tools","large_context"}), 200000, 1.0),
    ModelSpec("openrouter", "openai/gpt-5.6-sol", "T3", frozenset({"coding","reasoning","tools"}), 200000, 1.05),
]

def candidates(required: set[str]):
    return [m for m in REGISTRY if required.issubset(m.capabilities)]
