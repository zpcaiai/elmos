DEFAULT_IMPACT_EDGES={"calls","imports","implements","extends","reads","writes","tests","depends_on","contains"}

def impacted_nodes(graph, changed_ids, hops=3):
    return graph.expand(changed_ids, hops=hops, edge_types=DEFAULT_IMPACT_EDGES)
