from __future__ import annotations

def select_tests(graph, changed_ids: list[str], max_hops: int = 4):
    impacted = graph.expand(
        changed_ids,
        hops=max_hops,
        edge_types={"tests","calls","imports","depends_on","contains","reads","writes"}
    )
    tests=[]
    for node in impacted:
        if node.node_type in {"test","test_class","test_function"}:
            tests.append(node)
        elif node.file_path and (
            "/test/" in node.file_path.lower()
            or node.file_path.lower().startswith("test")
            or node.file_path.lower().endswith(("test.py","test.java","spec.ts","spec.js"))
        ):
            tests.append(node)
    seen=set()
    out=[]
    for t in tests:
        if t.id not in seen:
            seen.add(t.id); out.append(t)
    return out
