from collections import defaultdict

def evaluate(records,min_repetitions=5):
    groups=defaultdict(list)
    for r in records:
        groups[(r["system"],r["task_case"])].append(r)
    blockers=[]
    for key,rows in groups.items():
        if len(rows)<min_repetitions:
            blockers.append({"group":str(key),"reason":"insufficient_repetitions"})
        if any(r.get("evidence_level") not in {"E4","E5","E6","E7"} for r in rows):
            blockers.append({"group":str(key),"reason":"contains_unverified_record"})
    return {"ready":not blockers,"blockers":blockers,"groups":len(groups)}
