from dataclasses import dataclass

@dataclass
class SpeculationDecision:
    enabled: bool
    branches: int
    max_extra_cost_usd: float
    reason: str

def decide(uncertainty: float, task_value: float, budget_remaining: float, max_branches=3):
    if uncertainty < 0.55:
        return SpeculationDecision(False,1,0.0,"low_uncertainty")
    if budget_remaining <= 0:
        return SpeculationDecision(False,1,0.0,"no_budget")
    branches=min(max_branches, 2 if uncertainty < 0.8 else 3)
    extra=min(budget_remaining, max(0.0, task_value*0.05))
    return SpeculationDecision(True,branches,extra,"high_expected_value")
