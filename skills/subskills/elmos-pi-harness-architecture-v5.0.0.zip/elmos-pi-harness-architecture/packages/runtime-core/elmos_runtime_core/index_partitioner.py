from collections import defaultdict
from pathlib import PurePosixPath

def partition_paths(paths, max_files=500):
    groups=defaultdict(list)
    for p in paths:
        parts=PurePosixPath(p).parts
        key=parts[0] if len(parts)>1 else "_root"
        groups[key].append(p)

    shards=[]
    for key,items in sorted(groups.items()):
        for i in range(0,len(items),max_files):
            shards.append({"partition":key,"paths":items[i:i+max_files]})
    return shards
