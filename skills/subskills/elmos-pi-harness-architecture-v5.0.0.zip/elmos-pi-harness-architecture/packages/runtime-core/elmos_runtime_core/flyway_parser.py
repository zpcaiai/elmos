from __future__ import annotations
from pathlib import Path
import re

PATTERNS = [
    ("drop_table", re.compile(r"\bdrop\s+table\b", re.I)),
    ("drop_column", re.compile(r"\bdrop\s+column\b", re.I)),
    ("add_column", re.compile(r"\badd\s+column\b", re.I)),
    ("alter_column", re.compile(r"\balter\s+column\b", re.I)),
    ("create_table", re.compile(r"\bcreate\s+table\b", re.I)),
]

def parse_flyway_file(path: Path):
    sql=path.read_text(encoding="utf-8",errors="ignore")
    ops=[]
    for typ,pat in PATTERNS:
        if pat.search(sql):
            ops.append({"type":typ,"file":str(path)})
    return ops
