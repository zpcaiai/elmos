from __future__ import annotations
from pathlib import Path
import re, yaml

class RecipeError(RuntimeError): pass

def load_recipe(path: Path):
    return yaml.safe_load(path.read_text(encoding="utf-8"))

def rewrite_import_prefix(root: Path, old: str, new: str):
    changed=[]
    pattern=re.compile(rf"\bimport\s+{re.escape(old)}([\w\.\*]*);")
    for path in root.rglob("*.java"):
        text=path.read_text(encoding="utf-8",errors="ignore")
        out=pattern.sub(lambda m: f"import {new}{m.group(1)};", text)
        if out != text:
            path.write_text(out,encoding="utf-8")
            changed.append(str(path))
    return changed

def execute_actions(root: Path, recipe: dict):
    changed=[]
    for action in recipe.get("actions",[]):
        typ=action.get("type")
        if typ=="rewrite_import_prefix":
            changed += rewrite_import_prefix(root,action["from"],action["to"])
        elif typ=="semantic_rewrite":
            raise RecipeError("semantic_rewrite requires AST/LLM transformation adapter")
        else:
            raise RecipeError(f"unsupported recipe action: {typ}")
    return sorted(set(changed))
