from dataclasses import dataclass, field
from typing import Any
import math, re

@dataclass
class Candidate:
    id: str
    text: str
    metadata: dict[str, Any] = field(default_factory=dict)
    lexical_score: float = 0.0
    semantic_score: float = 0.0
    structural_score: float = 0.0
    recency_score: float = 0.0
    failure_score: float = 0.0

    @property
    def fused_score(self):
        return (0.25*self.lexical_score + 0.30*self.semantic_score +
                0.25*self.structural_score + 0.10*self.recency_score +
                0.10*self.failure_score)

def _tokens(s):
    return set(re.findall(r"[A-Za-z_][A-Za-z0-9_]+|[\u4e00-\u9fff]+", s.lower()))

def lexical_similarity(query, text):
    a,b = _tokens(query), _tokens(text)
    if not a or not b:
        return 0.0
    return len(a & b) / math.sqrt(len(a)*len(b))

def fuse(query, candidates):
    for c in candidates:
        c.lexical_score = lexical_similarity(query, c.text)
    return sorted(candidates, key=lambda c: c.fused_score, reverse=True)
