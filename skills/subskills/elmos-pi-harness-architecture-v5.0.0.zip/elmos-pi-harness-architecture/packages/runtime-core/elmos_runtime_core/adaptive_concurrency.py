def recommended_parallelism(queue_depth, provider_error_rate, p95_latency_ms, hard_limit):
    n=max(1,min(hard_limit,1+queue_depth//2))
    if provider_error_rate > 0.10:
        n=max(1,n//2)
    if p95_latency_ms > 60000:
        n=max(1,n-1)
    return n
