def should_promote(candidate, baseline, thresholds=None):
    thresholds=thresholds or {
      "max_success_regression":0.0,
      "max_cost_regression":0.05,
      "max_p95_latency_regression":0.10,
    }
    if candidate["validated_success_rate"] < baseline["validated_success_rate"] - thresholds["max_success_regression"]:
        return False,"success_regression"
    if candidate["cost_per_success"] > baseline["cost_per_success"]*(1+thresholds["max_cost_regression"]):
        return False,"cost_regression"
    if candidate["p95_wall_clock_ms"] > baseline["p95_wall_clock_ms"]*(1+thresholds["max_p95_latency_regression"]):
        return False,"latency_regression"
    return True,"passes"
