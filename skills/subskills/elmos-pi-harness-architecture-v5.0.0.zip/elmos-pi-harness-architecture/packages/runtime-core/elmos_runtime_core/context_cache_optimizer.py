from dataclasses import dataclass

@dataclass
class CacheStats:
    total_tokens: int
    stable_prefix_tokens: int
    cached_tokens: int

    @property
    def stable_ratio(self):
        return self.stable_prefix_tokens / max(self.total_tokens,1)

    @property
    def cache_hit_ratio(self):
        return self.cached_tokens / max(self.total_tokens,1)

def optimize_segment_order(segments: list[dict]):
    priority={
        "system_policy":0,
        "package_manifest":1,
        "project_instruction":2,
        "stable_skill_header":3,
        "repo_file":4,
        "symbol_definition":5,
        "task_objective":90,
        "failure_trace":95,
        "recent_diff":96,
        "tool_output":99,
    }
    return sorted(segments,key=lambda s:priority.get(s.get("kind",""),50))
