def build_eta_record(task, stages, operational):
    return {
        "features": {
            "task_class": task.get("task_class"),
            "repo_loc": task.get("repo_loc", 0),
            "module_count": task.get("module_count", 0),
            "dag_nodes": task.get("dag_nodes", 0),
            "expected_repairs": task.get("expected_repairs", 0),
            "cache_hit_estimate": operational.get("cache_hit_estimate", 0),
            "queue_depth": operational.get("queue_depth", 0)
        },
        "labels": {
            "actual_wall_clock_seconds": task.get("actual_wall_clock_seconds", 0),
            "stage_seconds": {s["name"]: s.get("actual_seconds", 0) for s in stages}
        }
    }
