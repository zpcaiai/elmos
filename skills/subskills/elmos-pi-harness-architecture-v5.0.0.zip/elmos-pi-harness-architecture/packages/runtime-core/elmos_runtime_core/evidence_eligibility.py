def e4_eligible(record):
    blockers=[]
    if not record.get("run_id"): blockers.append("missing_run_id")
    if not record.get("system_version"): blockers.append("missing_system_version")
    if not record.get("repo_revision"): blockers.append("missing_repo_revision")
    if not record.get("evidence_manifest"): blockers.append("missing_manifest")
    verification=record.get("verification")
    if not verification or verification.get("passed") is None:
        blockers.append("missing_deterministic_verification")
    return {"eligible":not blockers,"blockers":blockers}

def e5_eligible(records,min_repetitions=5):
    if len(records)<min_repetitions:
        return {"eligible":False,"blockers":["insufficient_repetitions"]}
    bad=[i for i,r in enumerate(records) if not e4_eligible(r)["eligible"]]
    return {"eligible":not bad,"blockers":[] if not bad else [f"non_e4_records:{bad}"]}
