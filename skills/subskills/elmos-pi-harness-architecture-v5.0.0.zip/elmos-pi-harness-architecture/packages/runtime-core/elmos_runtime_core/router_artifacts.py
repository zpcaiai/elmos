from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class RouterArtifact:
    id: str
    version: str
    feature_schema_version: str
    uri: str
    metrics: dict[str, Any]
    state: str

class RouterArtifactRegistry:
    def __init__(self):
        self.artifacts = {}
        self.active_id = None

    def register(self, artifact):
        self.artifacts[artifact.id] = artifact

    def activate(self, artifact_id):
        artifact = self.artifacts[artifact_id]
        if artifact.state not in {"approved", "canary"}:
            raise ValueError("artifact not approved for activation")
        self.active_id = artifact_id

    def active(self):
        return self.artifacts.get(self.active_id)
