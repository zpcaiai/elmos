import os
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter

def init_telemetry(service_name: str):
    resource=Resource.create({"service.name":service_name,"service.version":"1.3.0"})
    provider=TracerProvider(resource=resource)
    if os.getenv("ELMOS_OTEL_CONSOLE","false").lower()=="true":
        provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
    trace.set_tracer_provider(provider)
    return trace.get_tracer(service_name)
