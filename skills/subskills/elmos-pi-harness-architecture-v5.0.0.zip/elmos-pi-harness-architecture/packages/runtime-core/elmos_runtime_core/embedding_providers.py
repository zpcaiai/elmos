from __future__ import annotations
import os, httpx

class OpenAICompatibleEmbeddingProvider:
    def __init__(self, api_key=None, base_url=None, model=None):
        self.api_key=api_key or os.getenv("EMBEDDING_API_KEY") or os.getenv("OPENAI_API_KEY")
        self.base_url=(base_url or os.getenv("EMBEDDING_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
        self.model=model or os.getenv("EMBEDDING_MODEL","text-embedding-3-small")

    async def embed(self, texts: list[str]) -> list[list[float]]:
        if not self.api_key:
            raise RuntimeError("embedding API key missing")
        headers={"Authorization":f"Bearer {self.api_key}","Content-Type":"application/json"}
        payload={"model":self.model,"input":texts}
        async with httpx.AsyncClient(timeout=120) as c:
            r=await c.post(f"{self.base_url}/embeddings",headers=headers,json=payload)
            r.raise_for_status()
            data=r.json()
        ordered=sorted(data["data"],key=lambda x:x["index"])
        return [x["embedding"] for x in ordered]
