from dataclasses import dataclass

@dataclass
class EquivalenceEvidence:
    level: str
    equivalent: bool
    reasons: list[str]
    confidence: float

def validate_equivalence(a: dict, b: dict) -> EquivalenceEvidence:
    if a.get("content_hash") and a.get("content_hash")==b.get("content_hash"):
        return EquivalenceEvidence("E0",True,["content_hash_equal"],1.0)

    structural_keys=["language","framework","symbol","signature","dependency_fingerprint"]
    if all(a.get(k)==b.get(k) for k in structural_keys if a.get(k) is not None or b.get(k) is not None):
        return EquivalenceEvidence("E1",True,["structural_keys_equal"],0.98)

    pre_a=a.get("preconditions")
    pre_b=b.get("preconditions")
    if pre_a is not None and pre_a==pre_b:
        return EquivalenceEvidence("E2",True,["preconditions_equal"],0.95)

    return EquivalenceEvidence("NONE",False,["insufficient_equivalence_evidence"],0.0)
