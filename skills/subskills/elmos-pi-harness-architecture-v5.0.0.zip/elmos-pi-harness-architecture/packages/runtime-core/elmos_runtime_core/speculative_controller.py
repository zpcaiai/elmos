from dataclasses import dataclass

@dataclass
class BranchState:
    id: str
    validated_score: float
    cost_usd: float
    expected_remaining_cost_usd: float
    terminal_failure: bool=False

def losers_to_cancel(branches, confidence_gap=0.25):
    if not branches:
        return []
    best=max(branches,key=lambda b:b.validated_score)
    losers=[]
    for b in branches:
        if b.id==best.id:
            continue
        if b.terminal_failure:
            losers.append(b.id)
            continue
        gap=best.validated_score-b.validated_score
        if gap>=confidence_gap and b.expected_remaining_cost_usd>0:
            losers.append(b.id)
    return losers
