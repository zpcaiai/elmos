from __future__ import annotations
from pathlib import Path
import hashlib, os, shutil
from dataclasses import dataclass
from uuid import uuid4

@dataclass
class ArtifactRef:
    id: str
    uri: str
    sha256: str
    size_bytes: int

class LocalArtifactStore:
    def __init__(self, root: str | None=None):
        self.root=Path(root or os.getenv("ELMOS_ARTIFACT_ROOT","/tmp/elmos-artifacts"))
        self.root.mkdir(parents=True,exist_ok=True)

    def put_bytes(self, data: bytes, suffix: str="bin") -> ArtifactRef:
        aid=str(uuid4())
        digest=hashlib.sha256(data).hexdigest()
        path=self.root / f"{aid}.{suffix}"
        path.write_bytes(data)
        return ArtifactRef(aid, f"file://{path}", digest, len(data))

    def put_file(self, src: Path) -> ArtifactRef:
        data=src.read_bytes()
        return self.put_bytes(data, src.suffix.lstrip(".") or "bin")
