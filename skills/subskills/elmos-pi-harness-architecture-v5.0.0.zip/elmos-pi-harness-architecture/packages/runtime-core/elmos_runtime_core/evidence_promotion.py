def promote(current, artifacts):
    if current == "E2" and artifacts.get("real_run"):
        return "E3"
    if current == "E3" and artifacts.get("deterministic_verification"):
        return "E4"
    if current == "E4" and artifacts.get("repeated_statistics"):
        return "E5"
    if current == "E5" and artifacts.get("certification"):
        return "E6"
    if current == "E6" and artifacts.get("customer_acceptance"):
        return "E7"
    return current
