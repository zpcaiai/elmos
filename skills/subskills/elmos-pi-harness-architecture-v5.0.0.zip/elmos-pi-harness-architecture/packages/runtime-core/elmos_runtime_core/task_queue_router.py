def select_task_queue(resource_class, priority, tenant_tier="standard"):
    urgent = priority >= 1000
    if resource_class == "frontier-model":
        return "elmos-frontier-high" if urgent else "elmos-frontier-normal"
    if resource_class == "economical-model":
        return "elmos-economical"
    if resource_class == "memory-heavy-index":
        return "elmos-index"
    if resource_class == "cpu-build":
        return "elmos-build"
    if resource_class == "verification":
        return "elmos-verification"
    return "elmos-default"
