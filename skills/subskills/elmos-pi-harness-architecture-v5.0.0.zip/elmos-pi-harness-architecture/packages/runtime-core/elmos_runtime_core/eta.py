from dataclasses import dataclass

@dataclass
class EtaEstimate:
    p50_seconds: float
    p90_seconds: float
    confidence: float
    drivers: list[str]

def estimate(stage_history, expected_repairs=0.0, queue_seconds=0.0):
    base=sum(float(x.get("expected_seconds",0)) for x in stage_history)
    repair=sum(float(x.get("repair_seconds",0)) for x in stage_history)*expected_repairs
    p50=queue_seconds+base+repair
    uncertainty=max(0.15, min(1.0, 0.25+0.12*expected_repairs))
    p90=p50*(1.0+uncertainty)
    return EtaEstimate(p50,p90,max(0.1,1.0-uncertainty),["repair_variance"] if expected_repairs else [])
