from __future__ import annotations
import hashlib
from dataclasses import dataclass

@dataclass
class EmbeddingCacheEntry:
    model: str
    content_hash: str
    vector: list[float]

def content_hash(text: str):
    return hashlib.sha256(text.encode()).hexdigest()

class EmbeddingBatcher:
    def __init__(self, provider, cache, batch_size=64):
        self.provider=provider
        self.cache=cache
        self.batch_size=batch_size

    async def embed(self, model: str, texts: list[str]):
        out=[None]*len(texts)
        missing=[]
        missing_idx=[]
        for i,text in enumerate(texts):
            key=(model,content_hash(text))
            cached=self.cache.get(key)
            if cached is not None:
                out[i]=cached
            else:
                missing.append(text)
                missing_idx.append(i)

        for start in range(0,len(missing),self.batch_size):
            batch=missing[start:start+self.batch_size]
            vectors=await self.provider.embed(batch)
            for off,vec in enumerate(vectors):
                i=missing_idx[start+off]
                out[i]=vec
                self.cache[(model,content_hash(texts[i]))]=vec
        return out
