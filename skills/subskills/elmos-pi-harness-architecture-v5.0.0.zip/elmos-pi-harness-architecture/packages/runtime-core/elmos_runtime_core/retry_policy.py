from dataclasses import dataclass

@dataclass
class RetryDecision:
    retry: bool
    delay_seconds: float
    reason: str

RETRYABLE={"worker_crash","provider_timeout","provider_rate_limit","sandbox_lost","transient_network","lease_expired"}

def decide(error_code,attempt,max_attempts=3,base_delay=2.0,max_delay=60.0,
           budget_remaining_usd=None,elapsed_seconds=None,max_elapsed_seconds=None):
    if error_code not in RETRYABLE:
        return RetryDecision(False,0.0,"non_retryable")
    if attempt>=max_attempts:
        return RetryDecision(False,0.0,"max_attempts")
    if budget_remaining_usd is not None and budget_remaining_usd<=0:
        return RetryDecision(False,0.0,"budget_exhausted")
    if max_elapsed_seconds is not None and elapsed_seconds is not None and elapsed_seconds>=max_elapsed_seconds:
        return RetryDecision(False,0.0,"time_budget_exhausted")
    return RetryDecision(True,min(base_delay*(2**max(attempt-1,0)),max_delay),"retryable")
