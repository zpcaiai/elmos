def classify_cache_stability(kind, metadata):
    if kind in {"system_policy","package_manifest","project_instruction","stable_skill_header"}:
        return "stable"
    if kind in {"repo_file","symbol_definition"} and metadata.get("unchanged_since_revision"):
        return "stable_revision"
    return "dynamic"

def partition(segments):
    stable, dynamic = [], []
    for s in segments:
        target = stable if classify_cache_stability(s.get("kind",""), s.get("metadata",{})).startswith("stable") else dynamic
        target.append(s)
    return {"stable_prefix":stable, "dynamic_suffix":dynamic}
