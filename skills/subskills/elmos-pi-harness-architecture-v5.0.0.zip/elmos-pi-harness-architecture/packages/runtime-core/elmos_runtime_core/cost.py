from .db import connection
import json

def record_cost(tenant_id: str, project_id: str, task_id: str, category: str, amount_usd: float, metadata: dict):
    with connection() as conn:
        conn.execute(
            "insert into cost_ledger(tenant_id,project_id,task_id,category,amount_usd,metadata) "
            "values (%s,%s,%s,%s,%s,%s::jsonb)",
            (tenant_id,project_id,task_id,category,amount_usd,json.dumps(metadata))
        )
        conn.commit()

def total_task_cost(task_id: str) -> float:
    with connection() as conn:
        row=conn.execute("select coalesce(sum(amount_usd),0) from cost_ledger where task_id=%s",(task_id,)).fetchone()
        return float(row[0])
