REQUIREMENTS = {
    ("DRAFT","PREFLIGHT"): {"campaign_config"},
    ("PREFLIGHT","ENV_LOCKED"): {"environment_fingerprint","infra_versions"},
    ("ENV_LOCKED","ADAPTER_VALIDATED"): {"adapter_smoke"},
    ("ADAPTER_VALIDATED","REPO_VALIDATED"): {"repo_revision","build_baseline","test_baseline"},
    ("REPO_VALIDATED","TASKS_VALIDATED"): {"task_suite","verifier_pack"},
    ("TASKS_VALIDATED","RUNNING"): {"execution_workspace"},
    ("RUNNING","VERIFYING"): {"run_ids"},
    ("VERIFYING","NORMALIZING"): {"verification_results"},
    ("NORMALIZING","ANALYZING"): {"normalized_records"},
    ("ANALYZING","REPORT_READY"): {"statistics","sample_floor"},
    ("REPORT_READY","RELEASED"): {"approved_claims"},
}

def can_transition(current, target, evidence_kinds):
    required = REQUIREMENTS.get((current,target))
    if required is None:
        return False, {"reason":"unsupported_transition"}
    missing = sorted(required - set(evidence_kinds))
    return (not missing), {"missing": missing}
