from __future__ import annotations
from abc import ABC, abstractmethod

class Reranker(ABC):
    @abstractmethod
    async def rerank(self, query: str, candidates: list[dict], top_k: int) -> list[dict]: ...

class WeightedFeatureReranker(Reranker):
    async def rerank(self, query, candidates, top_k):
        def score(c):
            return (
                0.30*c.get("semantic_score",0.0)
                +0.25*c.get("lexical_score",0.0)
                +0.25*c.get("structural_score",0.0)
                +0.10*c.get("failure_score",0.0)
                +0.10*c.get("authority_score",0.0)
            )
        return sorted(candidates,key=score,reverse=True)[:top_k]
