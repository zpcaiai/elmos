from __future__ import annotations

def compare_openapi(old: dict, new: dict):
    breaking=[]
    additive=[]
    old_paths=old.get("paths",{})
    new_paths=new.get("paths",{})

    for path, methods in old_paths.items():
        if path not in new_paths:
            breaking.append({"type":"removed_path","path":path})
            continue
        for method in methods:
            if method.lower() not in new_paths[path]:
                breaking.append({"type":"removed_method","path":path,"method":method})

    for path, methods in new_paths.items():
        if path not in old_paths:
            additive.append({"type":"added_path","path":path})
        else:
            for method in methods:
                if method.lower() not in old_paths[path]:
                    additive.append({"type":"added_method","path":path,"method":method})
    return {"breaking":breaking,"additive":additive}
