import json

class PostgresCacheAudit:
    def __init__(self, connection_factory):
        self.connection_factory=connection_factory

    def record_hit(self, cache_key):
        with self.connection_factory() as conn:
            conn.execute("update semantic_cache_audit set hit_count=hit_count+1,last_used_at=now() where cache_key=%s",(cache_key,))
            conn.commit()

    def record_entry(self, cache_key, level, artifact_uri, evidence):
        with self.connection_factory() as conn:
            conn.execute(
              '''insert into semantic_cache_audit(cache_key,equivalence_level,artifact_uri,validation_evidence)
                 values(%s,%s,%s,%s::jsonb)
                 on conflict(cache_key) do update set equivalence_level=excluded.equivalence_level,
                 artifact_uri=excluded.artifact_uri,validation_evidence=excluded.validation_evidence,
                 invalidated=false,invalidation_reason=null''',
              (cache_key,level,artifact_uri,json.dumps(evidence)))
            conn.commit()
