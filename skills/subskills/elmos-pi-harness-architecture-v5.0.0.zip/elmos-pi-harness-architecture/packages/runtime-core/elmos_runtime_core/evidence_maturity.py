LEVELS=["E0","E1","E2","E3","E4","E5","E6","E7"]

def at_least(actual,required):
    return LEVELS.index(actual)>=LEVELS.index(required)

def claim_allowed(claim_level,required_level,evidence_ids):
    if not evidence_ids:
        return False,"missing_evidence"
    if not at_least(claim_level,required_level):
        return False,"insufficient_maturity"
    return True,"allowed"
