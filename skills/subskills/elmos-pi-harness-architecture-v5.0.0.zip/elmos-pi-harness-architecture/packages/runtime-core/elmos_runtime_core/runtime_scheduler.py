from dataclasses import dataclass
from .critical_path import critical_path, ready_priority

@dataclass
class ReadyNode:
    id: str
    remaining_ms: int
    unblock_count: int = 0
    sla_urgency: float = 0.0
    resource_class: str = "default"

def rank_ready_nodes(nodes, edges, duration_ms, ready_nodes):
    cp = critical_path(nodes, edges, duration_ms)
    cp_set = set(cp["path"])
    ranked = []
    for n in ready_nodes:
        score = ready_priority(
            n.id, cp_set, n.remaining_ms,
            unblock_count=n.unblock_count,
            sla_urgency=n.sla_urgency
        )
        ranked.append((score, n))
    ranked.sort(key=lambda x: x[0], reverse=True)
    return {
        "critical_path": cp["path"],
        "critical_path_duration_ms": cp["duration_ms"],
        "ready": [
            {"node_id": n.id, "priority": score, "resource_class": n.resource_class}
            for score, n in ranked
        ]
    }
