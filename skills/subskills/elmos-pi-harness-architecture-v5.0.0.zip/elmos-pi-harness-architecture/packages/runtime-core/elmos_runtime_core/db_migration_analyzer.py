from __future__ import annotations

DESTRUCTIVE={"drop_table","drop_column","truncate","change_type_narrowing"}

def analyze(operations: list[dict]):
    findings=[]
    for op in operations:
        typ=op.get("type")
        risk="high" if typ in DESTRUCTIVE else "medium" if typ in {"rename_column","change_type"} else "low"
        findings.append({
            "operation":op,
            "risk":risk,
            "requires_approval":risk=="high",
            "requires_backup":risk=="high",
            "requires_dual_read_write":typ in {"rename_column","change_type"}
        })
    return findings
