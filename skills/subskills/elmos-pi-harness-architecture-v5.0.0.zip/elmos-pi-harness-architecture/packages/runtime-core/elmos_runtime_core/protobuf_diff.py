def compare_descriptors(old, new):
    breaking=[]
    old_msgs=old.get("messages",{})
    new_msgs=new.get("messages",{})
    for name,msg in old_msgs.items():
        if name not in new_msgs:
            breaking.append({"type":"removed_message","message":name})
            continue
        old_fields={f["number"]:f for f in msg.get("fields",[])}
        new_fields={f["number"]:f for f in new_msgs[name].get("fields",[])}
        for num,field in old_fields.items():
            if num not in new_fields:
                breaking.append({"type":"removed_field","message":name,"number":num})
            elif new_fields[num].get("type") != field.get("type"):
                breaking.append({"type":"changed_field_type","message":name,"number":num})
    return {"breaking":breaking}
