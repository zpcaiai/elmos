import hashlib, json

def canonical_hash(obj):
    raw=json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
    return hashlib.sha256(raw).hexdigest()

def repo_fragment_key(repo_id, revision, path, content_hash, parser_version):
    return canonical_hash({
      "kind":"repo_fragment","repo":repo_id,"revision":revision,"path":path,
      "content":content_hash,"parser":parser_version
    })

def tool_cache_key(tool, args, workspace_revision, environment_fingerprint):
    return canonical_hash({
      "kind":"tool","tool":tool,"args":args,"revision":workspace_revision,
      "environment":environment_fingerprint
    })

def verification_cache_key(test_id, impacted_content_hashes, environment_fingerprint):
    return canonical_hash({
      "kind":"verification","test":test_id,
      "inputs":sorted(impacted_content_hashes),"environment":environment_fingerprint
    })
