class S3CompatibleObjectStore:
    def __init__(self, client, bucket):
        self.client=client
        self.bucket=bucket

    def put(self, key, data:bytes, metadata=None):
        self.client.put_object(Bucket=self.bucket,Key=key,Body=data,Metadata=metadata or {})
        return f"s3://{self.bucket}/{key}"

    def get(self, key):
        return self.client.get_object(Bucket=self.bucket,Key=key)["Body"].read()

    def exists(self, key):
        try:
            self.client.head_object(Bucket=self.bucket,Key=key)
            return True
        except Exception:
            return False
