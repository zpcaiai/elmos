from dataclasses import dataclass
from typing import Any

@dataclass
class SemanticCacheRecord:
    cache_key: str
    equivalence_level: str
    artifact_ref: str
    metadata: dict[str, Any]
    validation_evidence: dict[str, Any]

class SemanticCacheBackend:
    def get_exact(self, cache_key: str):
        raise NotImplementedError
    def find_candidates(self, query_vector, limit=10):
        raise NotImplementedError
    def put(self, record: SemanticCacheRecord):
        raise NotImplementedError
    def invalidate(self, cache_key: str, reason: str):
        raise NotImplementedError
