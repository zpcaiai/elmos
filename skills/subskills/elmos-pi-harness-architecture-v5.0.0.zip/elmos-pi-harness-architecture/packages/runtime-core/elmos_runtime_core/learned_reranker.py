from __future__ import annotations
from abc import ABC, abstractmethod

class LearnedReranker(ABC):
    @abstractmethod
    async def rerank(self, query: str, candidates: list[dict], top_k: int) -> list[dict]:
        ...

class CrossEncoderReranker(LearnedReranker):
    def __init__(self, endpoint: str):
        self.endpoint=endpoint

    async def rerank(self, query, candidates, top_k):
        raise NotImplementedError("Bind to cross-encoder serving endpoint")

class LLMJudgeReranker(LearnedReranker):
    def __init__(self, provider_runtime):
        self.provider_runtime=provider_runtime

    async def rerank(self, query, candidates, top_k):
        raise NotImplementedError("Use structured pairwise/listwise relevance scoring")
