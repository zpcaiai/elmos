from __future__ import annotations
from abc import ABC, abstractmethod
import hashlib, math

class EmbeddingProvider(ABC):
    @abstractmethod
    async def embed(self, texts: list[str]) -> list[list[float]]: ...

class DeterministicHashEmbedding(EmbeddingProvider):
    """Offline deterministic fallback for testing, never a production semantic-quality claim."""
    async def embed(self, texts):
        vectors=[]
        for text in texts:
            digest=hashlib.sha256(text.encode()).digest()
            v=[(b-127.5)/127.5 for b in digest]
            norm=math.sqrt(sum(x*x for x in v)) or 1.0
            vectors.append([x/norm for x in v])
        return vectors
