from campaigns.e5_orchestrator import evaluate_e5
from benchmark.run_group_validator import validate_group

def evaluate(records,min_repetitions=5):
    group=validate_group(records)
    if not group.get("valid"):
        return {"allowed":False,"reason":"configuration_mismatch","details":group}
    e5=evaluate_e5(records,min_repetitions=min_repetitions)
    if not e5.get("ready"):
        return {"allowed":False,"reason":"e5_not_ready","details":e5}
    if any(not r.get("validated_success") for r in records):
        return {
          "allowed":True,
          "scope":"measured_success_rate_only",
          "details":e5
        }
    return {"allowed":True,"scope":"measured_suite_configuration_only","details":e5}
