from __future__ import annotations
from abc import ABC, abstractmethod

class VectorStore(ABC):
    @abstractmethod
    def upsert(self, project_id, revision, node_id, model, vector, metadata=None): ...
    @abstractmethod
    def search(self, project_id, revision, model, query_vector, limit=20): ...

class PgVectorStore(VectorStore):
    def __init__(self, connection_factory):
        self.connection_factory=connection_factory

    def upsert(self, project_id, revision, node_id, model, vector, metadata=None):
        # Concrete SQL binding depends on psycopg/pgvector adapter in production.
        raise NotImplementedError

    def search(self, project_id, revision, model, query_vector, limit=20):
        raise NotImplementedError
