from __future__ import annotations
import subprocess, os, json
from dataclasses import dataclass
from pathlib import Path

@dataclass
class SandboxResult:
    returncode: int
    stdout: str
    stderr: str

class DockerSandbox:
    def __init__(self, image: str | None = None):
        self.image=image or os.getenv("ELMOS_SANDBOX_IMAGE","python:3.12-slim")

    def execute(self, workspace: Path, command: list[str], timeout: int=300, network: bool=False):
        args=[
            "docker","run","--rm",
            "--read-only",
            "--pids-limit","256",
            "--memory","2g",
            "--cpus","2",
            "--security-opt","no-new-privileges",
            "--cap-drop","ALL",
            "-v",f"{workspace}:/workspace:rw",
            "-w","/workspace",
        ]
        if not network:
            args += ["--network","none"]
        args += [self.image, *command]
        p=subprocess.run(args,text=True,capture_output=True,timeout=timeout)
        return SandboxResult(p.returncode,p.stdout,p.stderr)
