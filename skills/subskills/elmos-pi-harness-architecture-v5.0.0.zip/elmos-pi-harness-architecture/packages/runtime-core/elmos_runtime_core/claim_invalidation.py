INVALIDATION_KEYS = {
    "system_version",
    "competitor_version",
    "model",
    "provider",
    "task_suite_version",
    "verifier_pack_version",
    "repo_revision",
    "environment_class",
    "benchmark_mode",
}

def should_invalidate(claim_scope, current_scope):
    changed = []
    for key in INVALIDATION_KEYS:
        if key in claim_scope and key in current_scope and claim_scope[key] != current_scope[key]:
            changed.append(key)
    return {
        "invalidate": bool(changed),
        "changed_keys": sorted(changed)
    }
