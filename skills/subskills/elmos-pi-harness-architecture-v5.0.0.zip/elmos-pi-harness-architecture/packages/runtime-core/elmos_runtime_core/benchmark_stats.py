import math, statistics

def mean_ci95(values):
    values = [float(x) for x in values]
    n = len(values)
    if n == 0:
        return {"n": 0, "mean": None, "ci95": None}
    mean = statistics.mean(values)
    if n < 2:
        return {"n": n, "mean": mean, "ci95": None}
    sd = statistics.stdev(values)
    margin = 1.96 * sd / math.sqrt(n)
    return {"n": n, "mean": mean, "ci95": [mean-margin, mean+margin]}

def summarize(values):
    values = sorted(float(x) for x in values)
    if not values:
        return {"n": 0}
    return {
        "n": len(values),
        "mean": statistics.mean(values),
        "median": statistics.median(values),
        "min": values[0],
        "max": values[-1],
        "ci95": mean_ci95(values)["ci95"]
    }
