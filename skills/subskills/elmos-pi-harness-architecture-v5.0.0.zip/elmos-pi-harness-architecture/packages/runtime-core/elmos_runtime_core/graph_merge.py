from __future__ import annotations

def merge_incremental_graph(existing_nodes, existing_edges, deleted_paths, new_nodes, new_edges):
    deleted_paths=set(deleted_paths)

    nodes={
        nid:n for nid,n in existing_nodes.items()
        if getattr(n,"file_path",None) not in deleted_paths
    }

    removed_ids=set(existing_nodes)-set(nodes)

    edges=[
        e for e in existing_edges
        if e.from_id not in removed_ids and e.to_id not in removed_ids
    ]

    for n in new_nodes:
        nodes[n.id]=n

    # Replace edges touching re-indexed nodes with new authoritative edges.
    new_ids={n.id for n in new_nodes}
    edges=[e for e in edges if e.from_id not in new_ids and e.to_id not in new_ids]
    edges.extend(new_edges)

    return nodes, edges
