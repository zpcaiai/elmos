# Type Resolution Contract

Type resolution enriches syntax-only graphs.

## Inputs
- parsed symbols
- imports
- package/module metadata
- build files
- dependency graph
- language server/compiler metadata where available

## Outputs
- fully-qualified symbol IDs
- declaration → reference edges
- overload resolution confidence
- generic/type-parameter bindings
- external dependency symbols
- unresolved-reference records

## Confidence levels
- exact
- compiler/language-server confirmed
- graph inferred
- lexical inferred
- unresolved

## Rule
Only `exact` or `compiler/language-server confirmed` edges may be used for destructive automated rewrites without additional verification.
