# Data Flow Graph

Represent:
- variable/field reads and writes
- DTO/entity propagation
- API request/response flow
- DB table/column access
- message queue produce/consume
- configuration propagation

Core node types:
api_endpoint
dto
entity
db_table
db_column
queue
topic
config_key
external_service

Core edge types:
accepts
returns
maps_to
reads
writes
produces
consumes
configures
calls_external
