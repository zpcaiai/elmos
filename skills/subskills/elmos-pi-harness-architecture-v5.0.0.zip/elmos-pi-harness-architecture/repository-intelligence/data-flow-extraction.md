# Data Flow Extraction

## Static layers

1. intra-function def-use
2. field read/write
3. parameter/return propagation
4. DTO/entity mapping
5. API ↔ service ↔ repository flow
6. repository ↔ database table/column
7. producer ↔ queue/topic ↔ consumer

## Framework adapters

Spring:
- @RestController
- @RequestMapping / mapping annotations
- @Service
- @Repository
- Spring Data repositories
- JPA entities
- Kafka/Rabbit listeners and producers

TypeScript:
- route/controller frameworks
- ORM adapters
- RPC clients

## Output

Data-flow edges remain versioned with repository revision and confidence.
