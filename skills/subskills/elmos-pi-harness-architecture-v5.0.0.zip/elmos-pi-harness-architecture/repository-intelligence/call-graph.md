# Call Graph Contract

Edge:
`caller_symbol -> callee_symbol`

Metadata:
- static/dynamic
- resolution confidence
- call site location
- dispatch kind
- framework-generated flag

For dynamic frameworks, store multiple possible callees with probabilities/confidence rather than forcing a false exact edge.
