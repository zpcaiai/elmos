# Typed Call Graph

## Edge classes

- exact_static_call
- virtual_dispatch_candidate
- interface_dispatch_candidate
- reflection_candidate
- framework_injected_call
- unresolved_call

## Required metadata

- caller
- callee or candidate set
- type resolver source
- confidence
- call site file/line
- dispatch kind
- framework annotation/context

## Safety rule

Automated transformations that depend on call-target correctness require either:
- exact compiler-confirmed edge, or
- multiple independent evidence sources + verification gate.
