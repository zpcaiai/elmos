# Golden Route Demo Runbook

1. checkout demo/target repository
2. capture revision and baseline build/test results
3. index repository
4. invoke Java resolver
5. execute deterministic recipes
6. run compile and targeted verification
7. execute semantic adapters where supported
8. run full verification
9. perform API/DB compatibility checks
10. run deployment smoke
11. generate evidence bundle
12. restore from checkpoint and prove rollback
13. mark certification outcome

Never represent the small demo as large-repository certification.
