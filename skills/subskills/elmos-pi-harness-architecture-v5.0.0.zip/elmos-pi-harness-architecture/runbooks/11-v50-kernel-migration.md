# v5.0 Kernel Migration Runbook

1. introduce `execution_kernel`
2. dual-write existing task/session state and new timeline
3. migrate typed context producers
4. migrate tool registry checks to CapabilityInventory + RuntimeConnectionState
5. move approvals to effect-level journal
6. add InterruptLifecycle hooks
7. enable non-terminal suspend/handoff
8. move child recovery behind RuntimeOwner
9. persist typed artifacts
10. rebuild UI/history/report from projections
11. derive E4/E5 evidence from timeline/artifacts
12. remove legacy session-as-source-of-truth paths after equivalence tests pass
