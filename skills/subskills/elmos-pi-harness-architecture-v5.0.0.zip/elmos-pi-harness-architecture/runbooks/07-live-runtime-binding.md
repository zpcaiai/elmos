# Live Runtime Binding Runbook

1. set `ELMOS_API_URL` or `ELMOS_CLI`
2. set/resolve exact `ELMOS_MODEL` and `ELMOS_PROVIDER`
3. run runtime identity discovery
4. build runtime binding
5. health-check runtime
6. pin repository revision
7. pin task/suite/verifier versions
8. build environment lock
9. activate E4 campaign
10. execute
11. deterministically verify
12. persist evidence lineage
13. repeat exactly 5x for E5
