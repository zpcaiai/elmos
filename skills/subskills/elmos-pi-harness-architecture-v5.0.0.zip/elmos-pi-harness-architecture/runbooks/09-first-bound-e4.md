# First Bound E4 Runbook

1. expose actual Elmos CLI/API
2. build RuntimeConnector
3. run connector conformance
4. negotiate E4 capabilities
5. pin repository revision
6. freeze execution envelope
7. build bound-task plan/hash
8. execute actual Elmos task
9. dispatch deterministic verifier
10. seal evidence
11. transactionally persist PostgreSQL lineage
12. run E4 admission
13. if admitted, schedule 5 drift-free E5 repetitions
