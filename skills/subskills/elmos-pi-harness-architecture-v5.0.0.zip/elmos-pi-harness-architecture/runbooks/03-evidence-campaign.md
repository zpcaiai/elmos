# Evidence Campaign Runbook

1. create campaign
2. lock environment
3. validate adapters
4. qualify repository
5. validate task suite + verifier pack
6. execute isolated runs
7. run verifier pack
8. normalize evidence
9. package E5
10. add large-repo/chaos certifications for E6
11. add customer acceptance for E7
12. register scoped claims
13. generate customer/investor proof packs
