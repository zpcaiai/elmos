# Persistent E3 → E5 Runbook

1. create campaign in PostgreSQL
2. plan jobs idempotently
3. lease jobs with SKIP LOCKED
4. create isolated worktree
5. execute harness
6. persist raw evidence
7. deterministic verification produces E4
8. normalize/ingest records
9. reclaim stale jobs
10. reach repetition floor
11. evaluate E5 readiness
12. finalize E5 and register scoped claims
