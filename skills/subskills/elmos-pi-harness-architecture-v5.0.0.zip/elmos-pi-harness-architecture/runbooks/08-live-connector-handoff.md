# Live Connector Handoff

1. deploy or expose actual Elmos runtime
2. choose CLI or HTTP connector
3. capture exact version/model/provider
4. run connector conformance
5. bind real repository revision
6. activate E4 campaign
7. execute real task
8. deterministic verification
9. persist evidence lineage
10. repeat identical configuration 5x for E5
