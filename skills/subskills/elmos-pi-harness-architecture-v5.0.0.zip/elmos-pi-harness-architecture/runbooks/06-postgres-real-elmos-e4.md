# PostgreSQL + Real Elmos E4 Runbook

1. deploy PostgreSQL schema through migration 025
2. run `benchmark/elmos_preflight.py`
3. if BLOCKED, retain preflight evidence and stop
4. qualify/pin repository revision
5. create persistent Campaign + Job
6. lease job and heartbeat
7. execute real Elmos in isolated worktree
8. deterministic verifier decides success
9. verify evidence-manifest hashes
10. transactionally persist E4 to PostgreSQL
11. close/reopen connection and query lineage
12. repeat 5x only after E4 is stable
