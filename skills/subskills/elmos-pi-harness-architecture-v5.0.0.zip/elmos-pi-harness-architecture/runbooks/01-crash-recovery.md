# Crash Recovery Runbook

## Worker crash
Temporal re-delivers incomplete activity according to retry policy.
Side-effecting activities must use `side_effect_journal.idempotency_key`.

## API crash
No task correctness impact. Task API is stateless apart from durable DB/Temporal state.

## PostgreSQL restart
Workers back off and retry. Do not accept mutation completion until event/ledger persistence succeeds.

## Temporal outage
API may accept to an outbox or return service-unavailable based on deployment policy.
Never start an untracked local background task as a substitute.

## Model provider outage
Router switches to allowed fallback chain. Preserve task/model provenance.

## Sandbox crash
Workspace remains isolated and can be re-mounted/rebuilt from repository revision + artifacts.

## Client network disconnect
Server-side workflow continues. Client reconnect reads state from PostgreSQL/Temporal.

## Recovery acceptance
Inject each failure at least 50 times in staging and measure:
- resume success
- duplicate effects
- recovery latency
- artifact integrity
