# First Persistent Local E3/E4 Fixture Run

1. initialize PostgreSQL schema
2. create a Git repo from `fixtures/local-python-bug`
3. commit broken baseline
4. create campaign
5. plan one local-fixture job
6. lease job
7. start heartbeat
8. execute deterministic fixture repair
9. retain Git diff/stdout/stderr
10. run local-python-fixture verifier pack
11. build evidence manifest
12. transactionally ingest E4 record
13. confirm Campaign/Job/Run IDs survive process restart

Success criterion:
database contains a durable Campaign ID, Job ID and Run ID linked to E4 evidence.
