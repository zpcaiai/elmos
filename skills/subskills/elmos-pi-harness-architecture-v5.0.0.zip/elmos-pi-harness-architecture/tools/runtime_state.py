from enum import Enum
class RuntimeConnectionState(str,Enum):
    UNKNOWN="unknown"; NOT_STARTED="not-started"; STARTING="starting"; CONNECTED="connected"
    AUTHENTICATION_REQUIRED="authentication-required"; FAILED="failed"; CANCELLED="cancelled"; DISABLED="disabled"
def observe_runtime_status(published_state,config_matches=True):
    if not config_matches: return RuntimeConnectionState.UNKNOWN
    return published_state if published_state is not None else RuntimeConnectionState.UNKNOWN
