from dataclasses import dataclass
@dataclass(frozen=True)
class HookSpec:
    source:str; phase:str; blocking:bool; control_effect:bool; cancellation_scope:str; environment_id:str|None=None
def validate(spec):
    return {"valid":not (not spec.blocking and spec.control_effect)}
