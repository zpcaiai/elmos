def record(call_id,capability,adapter,started_at,terminal_status,result=None,error=None,side_effects=None,evidence=None):
    return {"callId":call_id,"capability":capability,"adapter":adapter,"startedAt":started_at,
      "terminalStatus":terminal_status,"result":result,"error":error,"sideEffects":side_effects or [],"evidence":evidence or []}
def replayable(entry):
    return entry.get("terminalStatus") in {"completed","failed","cancelled","timed_out","authentication_required"}
