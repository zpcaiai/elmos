def dispatch_decision(capability_exists, runtime_state):
    if not capability_exists:
        return {"action": "unavailable"}

    mapping = {
        "connected": "execute",
        "not-started": "lazy_start",
        "starting": "wait",
        "authentication-required": "request_authentication",
        "failed": "retry_or_fallback",
        "cancelled": "retry_or_fallback",
        "disabled": "fallback",
        "unknown": "observe_or_revalidate"
    }
    return {"action": mapping.get(runtime_state, "observe_or_revalidate")}
