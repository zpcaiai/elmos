# References

Primary public sources reviewed in August 2026:
- Pi official website/docs: minimal harness, multi-provider support, session trees, context engineering, skills, extensions, packages, interactive/JSON/RPC/SDK modes.
- Pi GitHub: split packages for model API, agent core, coding agent and telemetry.
- pi-agent-harness package: team patterns, progressive-disclosure skills, model tiering, validation.
- Terminal-Bench 2 public leaderboard: whole-system performance depends on harness + model; empirical benchmark baselines matter more than architectural claims.

This package does not assume Pi is universally the strongest coding agent; it uses Pi as an architectural reference and adds enterprise/large-repo capabilities.
