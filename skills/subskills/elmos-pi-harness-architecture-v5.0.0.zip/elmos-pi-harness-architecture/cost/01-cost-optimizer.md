# Cost Optimizer

Optimize expected cost per validated success.

Levers:
- model tier
- context size
- cache reuse
- speculative branches
- test selection
- concurrency
- fallback/escalation

Constraints:
- required quality
- SLA
- tenant policy
- model availability
- verification gates

Do not optimize raw token price in isolation.
