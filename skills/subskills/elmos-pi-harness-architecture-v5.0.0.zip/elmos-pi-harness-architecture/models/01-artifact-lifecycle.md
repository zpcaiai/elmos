# Router / ETA Artifact Lifecycle

TRAINING → EVALUATED → SHADOW → CANARY → APPROVED → ACTIVE → RETIRED

Failure transitions lead to REJECTED or ROLLED_BACK.

Every transition stores benchmark IDs, metrics and evidence. Artifacts are immutable.
