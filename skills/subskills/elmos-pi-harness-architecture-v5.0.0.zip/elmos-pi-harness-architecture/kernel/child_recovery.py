def recover_child(child_snapshot, parent_runtime, current_environment, current_permissions):
    if not parent_runtime or not parent_runtime.get("loaded"):
        return {"allowed": False, "reason": "parent_runtime_unavailable"}

    if child_snapshot.get("runtime_owner_id") != parent_runtime.get("execution_id"):
        return {"allowed": False, "reason": "owner_mismatch"}

    if child_snapshot.get("workspace_root") != current_environment.get("workspace_root"):
        return {"allowed": False, "reason": "workspace_drift"}

    requested = set(child_snapshot.get("permissions", []))
    allowed = requested & set(current_permissions)

    return {
        "allowed": True,
        "effective_permissions": sorted(allowed),
        "inherit_from_parent": ["execution_policy", "mcp_extensions"],
        "restore_child_local": ["model", "provider", "reasoning", "role"]
    }
