ALLOWED = {
    "CREATED": {"RUNNING"},
    "RUNNING": {"INTERRUPT_REQUESTED", "SUSPENDING", "COMPLETED", "FAILED"},
    "INTERRUPT_REQUESTED": {"INTERRUPT_HOOKS"},
    "INTERRUPT_HOOKS": {"ABORTED", "SUSPENDING", "RUNNING"},
    "SUSPENDING": {"SUSPENDED"},
    "SUSPENDED": {"HANDOFF_READY", "RUNNING"},
    "HANDOFF_READY": {"RUNNING"},
    "COMPLETED": set(),
    "ABORTED": set(),
    "FAILED": set()
}

def can_transition(current, target):
    return target in ALLOWED.get(current, set())
