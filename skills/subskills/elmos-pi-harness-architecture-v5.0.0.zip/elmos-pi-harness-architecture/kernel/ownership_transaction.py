def prepare_handoff(execution, live_descendants, writer_closed, checkpoint_flushed):
    blockers = []
    if execution["lifecycle_state"] not in {"SUSPENDING", "SUSPENDED"}:
        blockers.append("invalid_lifecycle_state")
    if live_descendants:
        blockers.append("live_descendants")
    if not checkpoint_flushed:
        blockers.append("checkpoint_not_flushed")
    if not writer_closed:
        blockers.append("history_writer_open")

    return {
        "ready": not blockers,
        "blockers": blockers,
        "next_state": "HANDOFF_READY" if not blockers else execution["lifecycle_state"]
    }

def transfer_owner(execution, expected_epoch, new_owner_id):
    if execution["ownership_epoch"] != expected_epoch:
        return {"transferred": False, "reason": "ownership_epoch_conflict"}
    if execution["lifecycle_state"] != "HANDOFF_READY":
        return {"transferred": False, "reason": "not_handoff_ready"}

    updated = dict(execution)
    updated["runtime_owner_id"] = new_owner_id
    updated["ownership_epoch"] = expected_epoch + 1
    updated["lifecycle_state"] = "RUNNING"
    updated["durable_barrier_complete"] = False
    return {"transferred": True, "execution": updated}
