def interrupt_then_suspend(transcript_flushed, interrupt_hooks_complete, repeated=False):
    blockers = []
    if not transcript_flushed:
        blockers.append("transcript_not_flushed")
    if not interrupt_hooks_complete:
        blockers.append("interrupt_hooks_incomplete")

    return {
        "allowed": not blockers,
        "idempotent": repeated,
        "blockers": blockers,
        "next_state": "SUSPENDING" if not blockers else "INTERRUPT_HOOKS"
    }
