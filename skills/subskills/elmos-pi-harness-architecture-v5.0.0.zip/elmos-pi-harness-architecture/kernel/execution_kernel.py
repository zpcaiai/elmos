from dataclasses import dataclass, field
from typing import Any

@dataclass
class ExecutionKernel:
    execution_id: str
    root_execution_id: str
    parent_execution_id: str | None
    source: str
    runtime_owner_id: str | None
    ownership_epoch: int
    lifecycle_state: str
    durable_barrier_complete: bool
    runtime_states: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def terminal(self):
        return self.lifecycle_state in {"COMPLETED", "ABORTED", "FAILED"}

    def handoff_ready(self):
        return (
            self.lifecycle_state == "HANDOFF_READY"
            and self.durable_barrier_complete
            and not self.terminal()
        )
