# Runtime Sidecar Deployment Contract

A production Elmos runtime connector may run as:

- local CLI on benchmark worker
- localhost sidecar
- internal HTTP service

Recommended HTTP surface:
- `GET /version`
- `GET /readyz`
- `POST /v1/tasks`

The HTTP runtime should return exact model/provider/runtime version and must not decide benchmark success.
The external deterministic verifier remains authoritative.
