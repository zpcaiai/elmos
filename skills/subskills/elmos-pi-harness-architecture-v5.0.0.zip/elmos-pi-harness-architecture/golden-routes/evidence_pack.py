from pathlib import Path
import json, hashlib

def build_evidence_pack(output: Path, records: dict):
    output.mkdir(parents=True,exist_ok=True)
    manifest={}
    for name,payload in records.items():
        p=output/f"{name}.json"
        data=json.dumps(payload,ensure_ascii=False,indent=2).encode()
        p.write_bytes(data)
        manifest[name]={"file":p.name,"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data)}
    (output/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    return manifest
