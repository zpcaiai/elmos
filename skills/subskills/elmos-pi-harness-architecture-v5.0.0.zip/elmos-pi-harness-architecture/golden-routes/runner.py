from __future__ import annotations
from pathlib import Path
import yaml, time, json

class GoldenRouteRunner:
    def __init__(self, handlers: dict[str, callable]):
        self.handlers=handlers

    def run(self, workflow_path: Path, context: dict):
        spec=yaml.safe_load(workflow_path.read_text(encoding="utf-8"))
        results=[]
        started=time.perf_counter()

        for stage in spec["stages"]:
            action=stage["action"]
            handler=self.handlers.get(action)
            if not handler:
                results.append({"stage":stage["id"],"status":"missing_handler","action":action})
                break
            out=handler(stage,context)
            results.append({"stage":stage["id"],"status":"ok","output":out})
            if isinstance(out,dict) and out.get("status")=="failed":
                break

        return {
            "workflow":spec["name"],
            "version":spec["version"],
            "wall_clock_ms":int((time.perf_counter()-started)*1000),
            "results":results
        }
