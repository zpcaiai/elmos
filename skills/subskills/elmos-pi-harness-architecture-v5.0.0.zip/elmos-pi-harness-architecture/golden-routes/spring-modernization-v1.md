# Golden Route: Spring Modernization v1

## Qualification

Target repos:
- Spring Boot 2.x
- Java 8/11/17
- Maven/Gradle
- monolith or multi-module
- optional Spring Security/JPA/Kafka

## Stages

1. inventory
2. build baseline
3. dependency graph
4. compatibility analysis
5. automated deterministic rewrites
6. compile repair
7. framework semantic fixes
8. test modernization
9. integration verification
10. performance/smoke
11. deployment artifacts
12. evidence bundle

## Large-repo acceptance

Commercial certification requires:
- 3 repositories >500k LOC
- at least 1 repository >1M LOC
- repeatable success
- documented rollback
- measured machine wall-clock runtime
- measured token and compute cost
- no unresolved critical regressions
