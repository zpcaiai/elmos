from __future__ import annotations
from dataclasses import dataclass, asdict
import json, time

@dataclass
class EvidenceBundle:
    task_id: str
    repo_revision_before: str
    repo_revision_after: str
    changed_files: list[str]
    verification: list[dict]
    api_diff: dict
    db_findings: list[dict]
    model_usage: list[dict]
    cost_usd: float
    wall_clock_ms: int

    def to_json(self):
        return json.dumps(asdict(self),ensure_ascii=False,indent=2)
