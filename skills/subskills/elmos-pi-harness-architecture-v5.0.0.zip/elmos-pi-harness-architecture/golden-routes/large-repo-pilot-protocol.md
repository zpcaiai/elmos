# Large Repository Pilot Protocol
Minimum: 3 real repos >500k LOC and at least 1 >1M LOC.

For each:
1. pin revision
2. baseline build/tests
3. index/resolve
4. run route repeatedly
5. inject supported failures
6. verify resume
7. collect tokens/cost/machine wall-clock
8. full certification
9. rollback proof
10. immutable evidence manifest

Generated filler LOC does not qualify.
