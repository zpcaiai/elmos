from collections import defaultdict
import statistics
from benchmark.statistical_gate import summarize_success

def summarize(records):
    groups=defaultdict(list)
    for r in records:
        groups[r["system"]].append(r)
    out={}
    for system,rows in groups.items():
        wall=[r["wall_clock_ms"] for r in rows]
        out[system]={
          "success":summarize_success(rows),
          "median_wall_clock_ms":statistics.median(wall) if wall else None,
          "manual_interventions":sum(r.get("manual_interventions",0) for r in rows),
          "evidence_levels":sorted(set(r.get("evidence_level") for r in rows))
        }
    return out
