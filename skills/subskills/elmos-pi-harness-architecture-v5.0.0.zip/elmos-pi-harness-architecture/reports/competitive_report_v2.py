from collections import defaultdict
import statistics, json
from reports.statistics import ci95_mean, success_summary

def summarize(records):
    groups=defaultdict(list)
    for r in records:
        groups[r["system"]].append(r)

    out={}
    for system, rows in groups.items():
        wall=[r["wall_clock_ms"] for r in rows if r.get("wall_clock_ms") is not None]
        cost=[r["cost_usd"] for r in rows if r.get("cost_usd") is not None]
        out[system]={
            "success": success_summary(rows),
            "wall_clock": {
                "median_ms": statistics.median(wall) if wall else None,
                "mean_ci95": ci95_mean(wall)
            },
            "cost_usd": {
                "median": statistics.median(cost) if cost else None,
                "mean_ci95": ci95_mean(cost)
            },
            "manual_interventions": sum(int(r.get("manual_interventions",0)) for r in rows),
            "unavailable_metrics": sorted({
                key for r in rows for key in ("input_tokens","output_tokens","cached_tokens","cost_usd","tool_calls")
                if r.get(key) is None
            })
        }
    return out

def write_report(records, path):
    payload={"summary":summarize(records),"records":records}
    with open(path,"w",encoding="utf-8") as f:
        json.dump(payload,f,ensure_ascii=False,indent=2)
