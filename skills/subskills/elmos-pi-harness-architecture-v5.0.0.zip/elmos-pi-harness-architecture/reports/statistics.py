import math, statistics

def ci95_mean(values):
    vals=[float(x) for x in values]
    if not vals:
        return None
    mean=statistics.mean(vals)
    if len(vals)<2:
        return {"mean":mean,"ci95":None,"n":len(vals)}
    sd=statistics.stdev(vals)
    margin=1.96*sd/math.sqrt(len(vals))
    return {"mean":mean,"ci95":[mean-margin,mean+margin],"n":len(vals)}

def success_summary(rows):
    n=len(rows)
    successes=sum(1 for r in rows if r.get("validated_success"))
    return {"n":n,"successes":successes,"rate":successes/n if n else None}
