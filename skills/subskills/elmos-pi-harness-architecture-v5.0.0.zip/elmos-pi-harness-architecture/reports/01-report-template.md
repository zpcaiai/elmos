# Elmos Harness Competitive Evidence Report

## Benchmark mode
Matched-model / Native-product

## Compared systems
Exact versions:
Models/providers:

## Dataset
Repositories/revisions:
Tasks:
Repetitions:

## Environment
CPU/memory:
Network:
Tool permissions:
Budgets:

## Results
Validated success:
Regression-free success:
Cost/success:
P50/P95 machine wall-clock:
Cache:
Repair loops:
Recovery:
Manual interventions:

## Statistical notes
Sample counts:
Confidence intervals:
Unavailable metrics:

## Evidence
Benchmark run IDs:
Artifact manifest:

## Conclusion
Only state claims supported by the measurements above.
