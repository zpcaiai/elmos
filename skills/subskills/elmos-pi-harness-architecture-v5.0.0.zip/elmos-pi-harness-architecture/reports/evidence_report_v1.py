from collections import defaultdict
from pathlib import Path
import statistics, math

def ci95(values):
    vals = [float(x) for x in values]
    if len(vals) < 2:
        return None
    mean = statistics.mean(vals)
    margin = 1.96 * statistics.stdev(vals) / math.sqrt(len(vals))
    return [mean - margin, mean + margin]

def summarize(records):
    groups = defaultdict(list)
    for r in records:
        groups[r["system"]].append(r)

    out = {}
    for system, rows in groups.items():
        wc = [r["wall_clock_ms"] for r in rows]
        costs = [r["cost_usd"] for r in rows if r.get("cost_usd") is not None]
        out[system] = {
            "runs": len(rows),
            "validated_success_rate": sum(1 for r in rows if r["validated_success"]) / len(rows),
            "median_wall_clock_ms": statistics.median(wc),
            "mean_wall_clock_ci95": ci95(wc),
            "median_cost_usd": statistics.median(costs) if costs else None,
            "total_manual_interventions": sum(int(r.get("manual_interventions", 0)) for r in rows),
        }
    return out

def render_markdown(records, metadata):
    summary = summarize(records)
    lines = [
        "# Elmos Harness Evidence Report v1",
        "",
        f"Benchmark mode: **{metadata.get('mode','unknown')}**",
        f"Suite: **{metadata.get('suite','unknown')}**",
        "",
        "| System | Runs | Validated success | Median wall-clock (ms) | Median cost (USD) | Manual interventions |",
        "|---|---:|---:|---:|---:|---:|"
    ]
    for system, row in summary.items():
        cost = "" if row["median_cost_usd"] is None else "{:.4f}".format(row["median_cost_usd"])
        lines.append("| {} | {} | {:.3f} | {:.0f} | {} | {} |".format(
            system, row["runs"], row["validated_success_rate"],
            row["median_wall_clock_ms"], cost, row["total_manual_interventions"]
        ))
    lines += [
        "",
        "This report supports only claims directly grounded in these runs."
    ]
    return "\n".join(lines)

def write_report(records, metadata, output):
    Path(output).write_text(render_markdown(records, metadata), encoding="utf-8")
