from pathlib import Path
import json

def build_pack(output,summary,claims,certifications):
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    payload={
      "summary":summary,"claims":claims,"certifications":certifications,
      "disclaimer":"Claims are limited to their recorded scope and evidence maturity."
    }
    (out/"commercial-proof.json").write_text(
      json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
    return payload
