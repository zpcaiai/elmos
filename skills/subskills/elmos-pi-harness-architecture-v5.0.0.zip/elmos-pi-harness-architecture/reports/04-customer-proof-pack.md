# Customer Proof Pack

Focus:
- repository/task scope
- supported/unsupported patterns
- runtime ETA
- cost range
- verification coverage
- rollback
- security/isolation
- residual risks
- comparable pilot evidence

Customer pack should be operational and contractual, not investor-style hype.
