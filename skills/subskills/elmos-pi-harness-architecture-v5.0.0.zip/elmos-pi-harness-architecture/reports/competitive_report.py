from collections import defaultdict
import statistics, json

def summarize(records):
    by_system = defaultdict(list)
    for r in records:
        by_system[r["system"]].append(r)

    out = {}
    for system, rows in by_system.items():
        success = [1 if r["validated_success"] else 0 for r in rows]
        wc = [r["wall_clock_ms"] for r in rows]
        costs = [r.get("cost_usd", 0.0) for r in rows]
        out[system] = {
            "runs": len(rows),
            "validated_success_rate": sum(success) / len(rows),
            "median_wall_clock_ms": statistics.median(wc),
            "mean_cost_usd": sum(costs) / len(costs)
        }
    return out

def write_report(records, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"summary": summarize(records), "records": records}, f, ensure_ascii=False, indent=2)
