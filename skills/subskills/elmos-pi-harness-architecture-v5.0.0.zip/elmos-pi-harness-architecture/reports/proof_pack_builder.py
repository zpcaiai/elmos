from pathlib import Path
import json

def build(output_dir, audience, scorecard, claims, certifications, pilots):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    payload = {
        "audience": audience,
        "scorecard": scorecard,
        "claims": claims,
        "certifications": certifications,
        "pilots": pilots,
        "scope_note": "All claims are limited to their recorded evidence scope."
    }
    path = out / f"{audience}-proof-pack.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(path)
