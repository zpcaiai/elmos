# Competitive Claim Rules

Allowed:
"On suite X, revision Y, with model Z and N repetitions, Elmos showed lower median wall-clock than Pi."

Not allowed without broader evidence:
"Elmos is universally faster than Pi."
"Elmos is the strongest coding agent."

Any claim must state benchmark mode:
- matched-model harness comparison
- native-product comparison
