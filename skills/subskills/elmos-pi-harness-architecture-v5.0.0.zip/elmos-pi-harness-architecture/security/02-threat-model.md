# Threat Model

Primary threats:
- prompt injection from repository files
- malicious skill/package
- exfiltration via network/tool
- shell injection
- path traversal
- secret leakage
- cross-tenant access
- dependency poisoning
- destructive DB command
- CI/CD credential misuse
- compromised MCP/tool server
- model hallucinated privilege

Controls:
- untrusted-content labels
- instruction provenance
- tool permission boundary
- argument validation
- sandbox
- egress allowlist
- ephemeral credentials
- per-task secret scope
- approval gates
- package signatures
- immutable audit
- tenant-aware authorization on every data access
