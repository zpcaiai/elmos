# Enterprise Security Architecture

Never trust repository content, packages, tool output, model output, user archives, generated scripts or external tool servers.

Controls: sandbox execution, default-deny network, scoped mounts, secret broker, parameter-level permissions, approval gates, signed packages, SBOM/scanning, prompt-injection defense with provenance, SQL guardrails, audit logs, tenant isolation, quotas, egress policy, artifact malware scanning, supply-chain review.

Approval levels: L0 read/test; L1 scoped code edits; L2 dependency/schema/network/CI changes; L3 production deployment/credentials/destructive DB actions.
