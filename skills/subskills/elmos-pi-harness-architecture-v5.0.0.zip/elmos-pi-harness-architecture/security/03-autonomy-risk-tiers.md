# Autonomy Risk Tiers
A0 read-only: search/index/inspect.
A1 reversible workspace mutation: edits/tests/build.
A2 controlled integration: dependency/schema/CI changes.
A3 external production side effects: deploy, credentials, destructive DB.

A3 defaults to explicit approval. Model output cannot grant itself authority.
