from enum import Enum
class ApprovalActionKind(str,Enum):
    EXEC_COMMAND="EXEC_COMMAND"; WRITE_STDIN="WRITE_STDIN"; NETWORK="NETWORK"
    FILE_MUTATION="FILE_MUTATION"; BROWSER_ACTION="BROWSER_ACTION"; CREDENTIAL_USE="CREDENTIAL_USE"
    COMPUTER_USE="COMPUTER_USE"
def child_approval(parent_call_id,action_kind):
    return {"parent_call_id":parent_call_id,"action_kind":action_kind,"does_not_mutate_parent_lifecycle":True}
