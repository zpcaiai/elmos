from dataclasses import dataclass
@dataclass(frozen=True)
class SessionInheritancePolicy:
    inherit_managed_execution_policy:bool=True; inherit_environment_constraints:bool=True
    inherit_user_instructions:bool=False; inherit_extensions:bool=False
    inherit_mcp_servers:bool=False; inherit_multi_agent_behavior:bool=False
