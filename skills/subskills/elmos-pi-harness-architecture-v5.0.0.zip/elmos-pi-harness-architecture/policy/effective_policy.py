def intersect_sets(*policies):
    ps=[set(p) for p in policies if p is not None]
    if not ps: return set()
    r=ps[0]
    for p in ps[1:]: r&=p
    return r
def effective_policy(tenant,harness,environment,tool): return intersect_sets(tenant,harness,environment,tool)
def escalation_allowed(current,requested,hard_denies):
    return not bool(set(requested)&set(hard_denies)) and set(current).issubset(set(requested))
