# Production Semantic Cache Backend

Recommended:
- metadata/index: PostgreSQL or Redis
- payloads: object storage
- semantic candidates: pgvector/vector backend

Each entry records exact key, equivalence level, revision/fingerprint, policy version,
validation evidence, artifact ref, last use and invalidation reason.

Nearest-neighbor search only proposes candidates. Equivalence validation decides reuse.
