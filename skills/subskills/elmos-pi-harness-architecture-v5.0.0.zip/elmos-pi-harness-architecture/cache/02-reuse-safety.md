# Cache Reuse Safety

Classify entries:
- immutable-content safe
- revision-scoped
- environment-scoped
- task-scoped
- non-reusable

Invalidate on relevant changes to:
- source content
- dependency lockfile
- compiler/runtime version
- environment variables affecting behavior
- test fixtures
- DB schema
- tool version
- policy version

Record why a hit was considered safe.
