# Semantic Cache

Semantic cache is allowed only when an equivalence validator can justify reuse.

Possible reusable classes:
- equivalent repository question over identical revision
- transformation plan over equivalent structural preconditions
- resolver result over unchanged source/classpath
- verification result over identical impacted content/environment

Do not reuse executable patches based only on embedding similarity.

## Validation levels
E0 exact content identity
E1 structural identity
E2 semantic precondition equivalence
E3 model-judged similarity only

Mutation-sensitive reuse requires E0-E2 plus downstream verification.
