# Runtime Semantic Cache Backend

Recommended topology:

- Redis: hot metadata, TTL, hit counters, candidate IDs
- PostgreSQL: authoritative audit metadata, equivalence level, invalidation history
- Object store: large cached payloads
- pgvector/vector service: semantic candidate search only

Nearest-neighbor search proposes candidates; equivalence validation authorizes reuse.
