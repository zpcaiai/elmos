# Cache Hierarchy

L0 in-process metadata cache
L1 task-local cache
L2 tenant/project shared cache
L3 content-addressed artifact cache
L4 semantic transformation cache

Cacheable domains:
- prompt stable prefix
- model responses when request identity/policy allows
- tool outputs
- build dependencies
- repo parsing/index fragments
- embeddings
- resolver results
- test results keyed by code/environment
- deterministic transformation results

Never reuse solely by filename or natural-language similarity.
Correctness-sensitive reuse requires revision/content/environment keys.
