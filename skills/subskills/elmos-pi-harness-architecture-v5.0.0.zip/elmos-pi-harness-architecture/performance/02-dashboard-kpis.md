# Unified Performance Dashboard

Top KPIs:
- validated success rate
- cost per validated success
- p50/p95 machine wall-clock
- cache hit ratio
- crash-resume success
- active policy version

Also show router mix/fallbacks, cache savings/invalidation, ETA calibration,
benchmark confidence intervals and raw run IDs.
