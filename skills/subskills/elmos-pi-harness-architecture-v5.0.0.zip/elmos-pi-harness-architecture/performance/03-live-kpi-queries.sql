select system_name,
 sum(cost_usd)/nullif(sum(case when validated_success then 1 else 0 end),0) as cost_per_success
from benchmark_case_result group by system_name;

select system_name,
 avg(case when validated_success then 1.0 else 0.0 end) as success_rate
from benchmark_case_result group by system_name;

select system_name,
 sum(cached_tokens)::numeric/nullif(sum(input_tokens),0) as cached_input_ratio
from benchmark_case_result group by system_name;
