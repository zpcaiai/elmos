# Performance Architecture

## Control loops
1. Routing loop: task → model choice → verified outcome → policy update
2. Cache loop: request → cache decision → hit/miss → reuse safety → telemetry
3. Concurrency loop: queue/latency/provider health → parallelism
4. Verification loop: diff/impact/risk → targeted gates → escalation
5. ETA loop: task features + historical stages → runtime interval
6. Auto-tuning loop: benchmark → candidate policy → shadow → canary → promote/rollback

## Primary objective
Minimize expected cost and machine wall-clock per **validated successful task**,
subject to quality, security, SLA and budget constraints.
