# Claim Invalidation

Claims must be invalidated or downgraded when relevant dimensions change:
- Elmos version
- competing product version
- model/provider version
- task-suite version
- verifier-pack version
- repository revision
- environment class
- benchmark mode

Historical claims remain auditable but are marked STALE when scope no longer matches current product state.
