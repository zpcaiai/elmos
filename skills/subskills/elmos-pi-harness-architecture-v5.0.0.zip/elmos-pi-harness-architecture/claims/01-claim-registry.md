# Claim Registry

Every competitive/product claim records evidence level, evidence IDs, exact scope,
system/model/provider versions and invalidation conditions.

Examples must be scoped to the measured suite/repository/configuration.
