# Task Suite Versioning

A suite version pins:
- task text
- repository revision
- verifier commands
- timeout/budget
- expected artifacts
- anti-gaming policy

Changing any of these creates a new suite version.

Do not mix results from incompatible suite versions in one comparison without explicit normalization.
