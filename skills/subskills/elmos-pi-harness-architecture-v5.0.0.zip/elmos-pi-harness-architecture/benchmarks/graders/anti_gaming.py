SUSPICIOUS=["@Disabled","@Ignore","pytest.skip","test.skip(","describe.skip(","it.skip(","xdescribe(","xit("]

def scan_diff(diff_text):
    findings=[]
    for token in SUSPICIOUS:
        if token in diff_text:
            findings.append({"type":"possible_test_suppression","token":token})
    deleted=[
      line for line in diff_text.splitlines()
      if line.startswith("-") and ("assert" in line.lower() or "@Test" in line)
    ]
    if deleted:
        findings.append({"type":"deleted_test_assertions","count":len(deleted)})
    return findings
