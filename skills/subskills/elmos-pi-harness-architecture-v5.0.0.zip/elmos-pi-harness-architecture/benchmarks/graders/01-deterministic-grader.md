# Deterministic Grader Protocol

Validated success requires objective verification: compile, tests, API/schema compatibility,
static assertions, and task-specific thresholds.

An LLM judge may supplement qualitative review but cannot override deterministic failure.

Anti-gaming checks detect disabled/deleted/weakened tests and retain the full patch.
