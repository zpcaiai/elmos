# Automatic Canary Controller

Stages: 1% → 5% → 20% → 50% → 100%.

Advance only when minimum sample count is met, validated success is non-inferior,
there is no correctness/security incident, and cost/latency stay within guardrails.

Hard correctness guardrail violation triggers immediate rollback.
