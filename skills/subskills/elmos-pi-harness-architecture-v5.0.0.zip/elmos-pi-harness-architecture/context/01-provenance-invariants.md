# Typed Context / Provenance Invariants
Preserve provenance across merge, truncate, compaction, replay, fork, model switch and recovery.
Child-only developer instructions cannot leak to parent.
Only authoritative root-user context may establish user authorization; summaries/reviews cannot upgrade it.
