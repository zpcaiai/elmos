from dataclasses import dataclass,replace
@dataclass(frozen=True)
class ContextEnvelope:
    content:object; role:str; kind:str; producer:str; source:str; trust:str; scope:str
    parent_execution_id:str|None=None; retention_policy:str="durable"; replay_policy:str="preserve"
def transform(item,content=None):
    return replace(item,content=item.content if content is None else content)
