# Chaos Certification Matrix

Scenarios:
API/worker/index-worker kill, PostgreSQL restart, Redis outage, object-store outage,
Temporal outage, primary model outage/rate-limit, sandbox kill, client disconnect,
duplicate activity delivery.

Measure recovery success/time, duplicate side effects, data loss, billing reconciliation
and final verification integrity.

Certified scenarios require zero known data-loss and unsafe duplicate-side-effect events.
