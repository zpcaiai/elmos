# Benchmark Readiness Gate

Before first public/internal competitive report:

- [ ] adapter CLI flags validated on installed versions
- [ ] capability discovery recorded
- [ ] common model confirmed for matched-model subset
- [ ] benchmark repo/task revisions pinned
- [ ] verification scripts deterministic
- [ ] environment fingerprint recorded
- [ ] manual interventions disabled or counted
- [ ] repetitions >= 5 for initial comparative suite
- [ ] missing metrics remain null
- [ ] raw stdout/stderr/diffs/evidence retained
