# Chaos Certification Bundle

Per scenario retain injector/version, injection timing, 50-100 repetitions, workflow IDs,
recovery distribution, final verification, duplicate-side-effect audit, data-loss audit,
billing reconciliation and evidence manifest.

Any unexplained data loss or unsafe duplicate side effect is a hard failure.
