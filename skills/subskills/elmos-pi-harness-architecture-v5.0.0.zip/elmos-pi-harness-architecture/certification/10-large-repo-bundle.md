# Large Repository Certification Bundle

For each repo retain immutable identity/revision, LOC method, baseline build/tests,
graph statistics, task suite, repeated runs, machine wall-clock, cost, full verification,
failure/recovery evidence, rollback proof and immutable manifest.

Portfolio target: >=3 repos >500k LOC, including >=1 >1M LOC.
