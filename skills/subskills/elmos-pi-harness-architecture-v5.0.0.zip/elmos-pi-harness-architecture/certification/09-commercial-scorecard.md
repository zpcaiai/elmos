# Commercial Evidence Scorecard

Quality: validated success, regression-free success, repair loops.
Performance: p50/p95 machine wall-clock, cost/success, cache savings.
Reliability: resume success, duplicate side effects, data loss, billing reconciliation.
Scale: certified LOC/modules/index throughput.
Economics: revenue/task, contribution margin/task, model cost share.
Evidence: maturity E0-E7, repetitions, artifact completeness.
