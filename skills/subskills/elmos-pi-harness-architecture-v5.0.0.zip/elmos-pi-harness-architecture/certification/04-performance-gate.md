# Performance Certification Gate

PASS requires:
- validated success non-inferior
- no regression-escape increase
- cost/success within target
- p95 machine wall-clock within target
- cache correctness incidents = 0
- recovery SLO met
- sample floor met
- raw evidence retained
- configuration pinned

Faster but less correct does not pass.
