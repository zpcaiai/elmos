# v2.8 First Real Benchmark Release Gate

To publish Evidence Report v1:
- [ ] installed versions captured
- [ ] CLI flags validated
- [ ] smoke tests pass
- [ ] repository/task revisions pinned
- [ ] environment fingerprint recorded
- [ ] >=5 repetitions per compared system/case
- [ ] matched-model eligibility documented
- [ ] native-product configuration documented
- [ ] missing metrics remain null
- [ ] manual interventions counted
- [ ] evidence completeness passes
- [ ] claims restricted to measured scope

Chaos:
- [ ] one scenario has >=50 completed repetitions
- [ ] zero data-loss events
- [ ] zero unsafe duplicate-side-effect events
