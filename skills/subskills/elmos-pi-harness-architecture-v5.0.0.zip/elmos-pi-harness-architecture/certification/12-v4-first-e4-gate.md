# v4.0 First Real E4 Gate

PASS requires:
- real Elmos runtime discovered
- exact runtime version captured
- model/provider captured
- immutable repo revision
- real task execution
- stdout/stderr/diff retained
- deterministic verifier result
- evidence manifest hash
- durable Campaign/Job/Run lineage

If any runtime prerequisite is unavailable, status is BLOCKED.
