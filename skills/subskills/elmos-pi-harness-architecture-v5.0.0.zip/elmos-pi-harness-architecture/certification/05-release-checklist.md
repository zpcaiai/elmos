# v2.6 Evidence Release Checklist

- [ ] infrastructure versions pinned
- [ ] benchmark suite revision pinned
- [ ] harness versions pinned
- [ ] model/provider versions recorded
- [ ] at least 3 repetitions per ordinary case
- [ ] chaos cases repeated 50–100 times for certification
- [ ] raw diffs and verification evidence stored
- [ ] manual intervention explicitly counted
- [ ] statistical summary generated
- [ ] large-repo claims use qualified repos
- [ ] matched-model and native-product modes separated
- [ ] no unsupported superiority claim
