# Competitive Harness Proof

For claims comparing Elmos with Pi, Codex, Claude Code, OpenCode or another harness, record:
exact versions, model/provider, repo/revision, task cases, permissions/network, budgets,
environment, repetitions, validated success, regression-free success, cost/success,
wall-clock distribution, cache usage, recovery results, confidence intervals and raw run IDs.

Separate matched-model Harness comparison from native-product-best comparison.
