import threading,time

class HeartbeatController:
    def __init__(self,job_repo,job_id,worker_id,interval_seconds=30,lease_seconds=180):
        self.job_repo=job_repo
        self.job_id=job_id
        self.worker_id=worker_id
        self.interval_seconds=interval_seconds
        self.lease_seconds=lease_seconds
        self.stop_event=threading.Event()
        self.thread=None

    def _loop(self):
        while not self.stop_event.wait(self.interval_seconds):
            ok=self.job_repo.heartbeat(
              self.job_id,self.worker_id,self.lease_seconds)
            if not ok:
                break

    def start(self):
        self.thread=threading.Thread(target=self._loop,daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=self.interval_seconds+1)
