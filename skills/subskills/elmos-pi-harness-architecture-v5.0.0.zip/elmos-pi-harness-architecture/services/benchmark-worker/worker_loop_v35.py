import uuid
from .heartbeat import HeartbeatController
from services.campaign_api.job_failure import classify_failure

class DurableWorker:
    def __init__(self,job_repo,job_state_repo,executor,worker_id=None):
        self.job_repo=job_repo
        self.job_state_repo=job_state_repo
        self.executor=executor
        self.worker_id=worker_id or str(uuid.uuid4())

    def once(self):
        job=self.job_repo.lease_next(self.worker_id)
        if not job:
            return {"status":"idle"}

        self.job_state_repo.mark_running(job["id"],self.worker_id)
        hb=HeartbeatController(self.job_repo,job["id"],self.worker_id)
        hb.start()
        try:
            result=self.executor(job)
            committed=self.job_repo.complete(
              job["id"],self.worker_id,result["run_id"],result["evidence_uri"])
            return {"status":"completed","job_id":job["id"],"committed":committed}
        except Exception as e:
            status=classify_failure(
              getattr(e,"code","unknown"),job.get("attempt",1))
            self.job_state_repo.mark_failure(
              job["id"],self.worker_id,status,str(e))
            return {"status":status.lower(),"job_id":job["id"],"error":str(e)}
        finally:
            hb.stop()
