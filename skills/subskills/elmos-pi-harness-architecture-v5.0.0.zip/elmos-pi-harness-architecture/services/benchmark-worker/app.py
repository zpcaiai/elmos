from fastapi import FastAPI
from pydantic import BaseModel
from benchmark.execution_runner import execute_case

app = FastAPI(title="elmos-benchmark-worker", version="3.3.0")

class ExecuteRequest(BaseModel):
    system: str
    repo: str
    revision: str
    task: str
    gates: list[dict]
    output_root: str
    repetition: int = 0
    model: str | None = None
    provider: str | None = None

@app.post("/v1/execute")
def execute(req: ExecuteRequest):
    return execute_case(
        system=req.system,
        repo=req.repo,
        revision=req.revision,
        task=req.task,
        gates=req.gates,
        output_root=req.output_root,
        repetition=req.repetition,
        model=req.model,
        provider=req.provider
    )

@app.get("/livez")
def livez():
    return {"status":"ok"}

@app.get("/readyz")
def readyz():
    return {"status":"ready"}
