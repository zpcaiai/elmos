import time, uuid

class WorkerLoop:
    def __init__(self,job_repo,executor,worker_id=None,poll_seconds=2):
        self.job_repo=job_repo
        self.executor=executor
        self.worker_id=worker_id or str(uuid.uuid4())
        self.poll_seconds=poll_seconds

    def once(self):
        job=self.job_repo.lease_next(self.worker_id)
        if not job:
            return {"status":"idle"}
        try:
            result=self.executor(job)
            committed=self.job_repo.complete(job["id"],self.worker_id,result["run_id"],result["evidence_uri"])
            return {"status":"completed","job_id":job["id"],"committed":committed}
        except Exception as e:
            return {"status":"failed","job_id":job["id"],"error":str(e)}

    def run_forever(self):
        while True:
            result=self.once()
            if result["status"]=="idle":
                time.sleep(self.poll_seconds)
