from fastapi import APIRouter
from pydantic import BaseModel
from .finalizer import finalize

router=APIRouter()

class FinalizeRequest(BaseModel):
    target_level:str
    records:list[dict]
    large_repo_certifications:list[dict]=[]
    chaos_certifications:list[dict]=[]
    pilot_acceptance:dict|None=None
    min_repetitions:int=5

@router.post("/v1/campaigns/{campaign_id}/finalize")
def finalize_campaign(campaign_id:str,req:FinalizeRequest):
    result=finalize(req.target_level,req.records,req.large_repo_certifications,
                    req.chaos_certifications,req.pilot_acceptance,req.min_repetitions)
    return {"campaign_id":campaign_id,**result}
