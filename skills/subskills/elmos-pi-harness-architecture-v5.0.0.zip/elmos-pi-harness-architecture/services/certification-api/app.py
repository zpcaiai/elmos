from fastapi import FastAPI
from pydantic import BaseModel
from uuid import uuid4

app=FastAPI(title="elmos-certification-api",version="2.5.0")
certs={}

class CertificationRequest(BaseModel):
    kind:str
    system_version:str
    benchmark_run_ids:list[str]
    evidence_ids:list[str]

@app.post("/v1/certifications")
def create(req:CertificationRequest):
    cid=str(uuid4())
    certs[cid]={"id":cid,"status":"PENDING",**req.model_dump()}
    return certs[cid]

@app.get("/v1/certifications/{cid}")
def get(cid:str):
    return certs.get(cid,{"id":cid,"status":"UNKNOWN"})
