from fastapi import FastAPI

app = FastAPI(title="elmos-performance-dashboard", version="2.4.0")

@app.get("/v1/performance/overview")
def overview():
    return {
        "validated_success_rate": None,
        "cost_per_validated_success": None,
        "p50_wall_clock_ms": None,
        "p95_wall_clock_ms": None,
        "cache_hit_ratio": None,
        "active_policy_version": None
    }

@app.get("/livez")
def livez():
    return {"status": "ok"}

@app.get("/readyz")
def readyz():
    return {"status": "ready"}
