# Java Resolver Sidecar

Target implementation:
- Java 17+
- Eclipse JDT or javac compiler APIs
- JSON-RPC/HTTP interface
- repository/project classpath loading
- fully-qualified symbol resolution
- method invocation target resolution
- inheritance/implementation graph
- annotation extraction

The sidecar is isolated from the Python control plane and returns normalized semantic references.
