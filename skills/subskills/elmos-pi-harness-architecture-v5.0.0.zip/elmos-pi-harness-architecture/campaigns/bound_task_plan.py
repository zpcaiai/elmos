import hashlib,json

def build(runtime_binding,repo_revision,task_case,task_text,suite_version,verifier_pack_version,envelope):
    plan={
      "runtime_binding":runtime_binding,
      "repo_revision":repo_revision,
      "task_case":task_case,
      "task_text":task_text,
      "suite_version":suite_version,
      "verifier_pack_version":verifier_pack_version,
      "execution_envelope":envelope
    }
    plan["plan_sha256"]=hashlib.sha256(
      json.dumps(plan,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    return plan
