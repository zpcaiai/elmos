# Campaign Resume / Recovery

On API or worker restart:
1. load non-terminal campaigns
2. inspect latest transition event
3. verify referenced evidence artifacts still exist
4. inspect run/worktree status
5. reconstruct next admissible transition
6. retry only idempotent/incomplete steps
7. never repeat completed external side effects without idempotency proof

Campaign durable state is authoritative; in-memory worker state is disposable.
