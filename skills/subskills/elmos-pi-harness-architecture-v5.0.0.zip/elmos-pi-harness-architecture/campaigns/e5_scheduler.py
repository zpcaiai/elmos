def schedule(binding_hash,repo_revision,task_case,repetitions=5):
    return [{
      "repetition":i,
      "binding_hash":binding_hash,
      "repo_revision":repo_revision,
      "task_case":task_case,
      "status":"PLANNED"
    } for i in range(repetitions)]

def drift_free(rows):
    if not rows: return False
    key=(rows[0]["binding_hash"],rows[0]["repo_revision"],rows[0]["task_case"])
    return all((r["binding_hash"],r["repo_revision"],r["task_case"])==key for r in rows)
