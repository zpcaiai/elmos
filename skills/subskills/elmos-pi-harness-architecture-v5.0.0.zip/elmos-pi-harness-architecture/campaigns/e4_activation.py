from runtime.health import check as check_health

def activate(runtime_binding, repo_revision, task_case, suite_version, verifier_pack_version):
    blockers = []

    health = check_health(runtime_binding)
    if not health.get("healthy"):
        blockers.append("runtime_unhealthy")

    for key, value in {
        "repo_revision": repo_revision,
        "task_case": task_case,
        "suite_version": suite_version,
        "verifier_pack_version": verifier_pack_version
    }.items():
        if not value:
            blockers.append(f"missing_{key}")

    return {
        "state": "READY" if not blockers else "BLOCKED",
        "blockers": blockers,
        "runtime_health": health
    }
