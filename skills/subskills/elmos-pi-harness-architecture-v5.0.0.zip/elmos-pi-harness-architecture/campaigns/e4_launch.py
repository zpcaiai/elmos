from runtime.admission_diagnostics import diagnose

def launch(admission_inputs,executor):
    diag=diagnose(**admission_inputs)
    if not diag["ready"]:
        return {"status":"BLOCKED","diagnostics":diag}
    try:
        record=executor()
        if record.get("status")!="EXECUTED":
            return {"status":"FAILED","reason":"executor_did_not_execute","record":record}
        return {"status":"EXECUTED","record":record,"diagnostics":diag}
    except Exception as e:
        return {"status":"FAILED","reason":"execution_exception","error":str(e),"diagnostics":diag}
