from campaigns.e5_scheduler import schedule

def launch_from_e4(e4_record, binding_hash, repetitions=5):
    required = ["run_id","system_version","model","provider","repo_revision","task_case","evidence_level"]
    missing = [k for k in required if not e4_record.get(k)]
    if missing:
        return {"ready":False,"missing":missing}

    if e4_record["evidence_level"] != "E4":
        return {"ready":False,"missing":["first_run_not_e4"]}

    return {
        "ready":True,
        "freeze":{
            "system_version":e4_record["system_version"],
            "model":e4_record["model"],
            "provider":e4_record["provider"],
            "repo_revision":e4_record["repo_revision"],
            "task_case":e4_record["task_case"],
            "binding_hash":binding_hash
        },
        "runs":schedule(binding_hash,e4_record["repo_revision"],e4_record["task_case"],repetitions)
    }
