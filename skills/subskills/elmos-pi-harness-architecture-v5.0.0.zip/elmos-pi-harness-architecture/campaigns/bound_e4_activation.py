from runtime.repository_binding import validate as validate_repo

def activate(connector,repo_path,revision,task_case,suite_version,verifier_pack_version):
    blockers=[]
    identity=None

    try:
        identity=connector.identity()
    except Exception:
        blockers.append("runtime_identity_failed")

    health=connector.health()
    if not health.get("healthy"):
        blockers.append("runtime_unhealthy")

    repo=validate_repo(repo_path,revision)
    if not repo.get("valid"):
        blockers.extend(repo.get("blockers",[]))

    for k,v in {
        "task_case":task_case,
        "suite_version":suite_version,
        "verifier_pack_version":verifier_pack_version
    }.items():
        if not v:
            blockers.append(f"missing_{k}")

    return {
        "state":"READY" if not blockers else "BLOCKED",
        "blockers":sorted(set(blockers)),
        "runtime_identity":identity.__dict__ if identity else None,
        "runtime_health":health,
        "repository":repo
    }
