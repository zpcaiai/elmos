# E4 Failure Taxonomy

BLOCKED:
- runtime unavailable
- connector invalid
- repo revision mismatch
- missing model/provider
- verifier unavailable

FAILED_EXECUTION:
- runtime invoked but task execution failed

FAILED_VERIFICATION:
- runtime executed; deterministic verifier failed

E4_ADMITTED:
- runtime executed
- verifier completed
- evidence sealed
- lineage persisted

A failed verification is still valuable E4-grade run evidence; validated_success=false.
