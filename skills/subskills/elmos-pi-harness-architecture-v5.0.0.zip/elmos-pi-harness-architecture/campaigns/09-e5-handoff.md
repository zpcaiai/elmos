# E5 Handoff

After the first real E4 succeeds:

1. freeze runtime version/model/provider
2. freeze repo revision/task/suite/verifier
3. repeat the exact configuration 5 times
4. reject any configuration drift
5. ensure each repetition is E4
6. compute success/latency/cost statistics
7. persist E5 summary
8. register only scoped claims
