# Campaign Execution Idempotency

Logical job key = SHA256(campaign + system + repo revision + task case + repetition).

Duplicate planning does not duplicate logical jobs. Expired leases can be reclaimed.
Worker completion requires lease ownership. Evidence artifacts are immutable.
At-least-once execution is safe only when external side effects are independently idempotent.
