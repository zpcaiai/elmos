def build(e4_record,repetitions=5):
    required=["system_version","model","provider","repo_revision","task_case"]
    missing=[k for k in required if not e4_record.get(k)]
    if missing:
        return {"ready":False,"missing":missing}
    freeze={k:e4_record[k] for k in required}
    return {
      "ready":True,
      "freeze":freeze,
      "runs":[{"repetition":i,"status":"PLANNED","freeze":freeze} for i in range(repetitions)]
    }
