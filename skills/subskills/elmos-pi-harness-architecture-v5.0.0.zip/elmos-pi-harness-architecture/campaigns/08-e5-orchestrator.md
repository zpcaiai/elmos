# First Real Elmos E5 Orchestrator

Target:
5 verified E4 repetitions for the same task/suite/repository configuration.

Per repetition:
1. create isolated worktree
2. execute real Elmos
3. retain stdout/stderr/diff
4. deterministic verifier
5. hash manifest
6. persist Campaign/Job/Run/E4 lineage

E5 only when all 5 runs satisfy configuration equivalence and E4 requirements.
