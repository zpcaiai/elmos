import hashlib, json

def build(campaign_id, system, system_version, model, provider, repo_revision, task_case, repetition):
    payload = {
        "campaign_id": campaign_id,
        "system": system,
        "system_version": system_version,
        "model": model,
        "provider": provider,
        "repo_revision": repo_revision,
        "task_case": task_case,
        "repetition": repetition
    }
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()
