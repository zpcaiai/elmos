from campaigns.logical_run_identity import build as logical_run_id

def plan(campaign_id, frozen, repetitions=5):
    rows = []
    for i in range(repetitions):
        rows.append({
            "repetition": i,
            "logical_run_id": logical_run_id(
                campaign_id=campaign_id,
                system="elmos",
                system_version=frozen["system_version"],
                model=frozen["model"],
                provider=frozen["provider"],
                repo_revision=frozen["repo_revision"],
                task_case=frozen["task_case"],
                repetition=i
            ),
            "frozen": frozen,
            "status": "PLANNED"
        })
    return rows

def drift_report(rows):
    if not rows:
        return {"valid": False, "reason": "empty"}
    baseline = rows[0]["frozen"]
    mismatches = []
    for i, row in enumerate(rows[1:], start=1):
        if row["frozen"] != baseline:
            mismatches.append({"index": i, "expected": baseline, "actual": row["frozen"]})
    return {"valid": not mismatches, "mismatches": mismatches}
