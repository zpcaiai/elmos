from runtime.elmos_bridge import ElmosBridge

class E4ExecutionController:
    def __init__(self, identity, binding, verifier, evidence_writer):
        self.identity = identity
        self.binding = binding
        self.verifier = verifier
        self.evidence_writer = evidence_writer

    def execute(self, repo_path, task_text, task_case, revision, timeout_seconds=3600):
        bridge = ElmosBridge(self.identity)
        result = bridge.execute(repo_path, task_text, timeout_seconds)

        if not result.executed:
            return {"status": "BLOCKED", "reason": "runtime_not_executed"}

        verification = self.verifier(repo_path)

        record = {
            "status": "EXECUTED",
            "system": "elmos",
            "system_version": result.version,
            "model": result.model,
            "provider": result.provider,
            "repo_revision": revision,
            "task_case": task_case,
            "wall_clock_ms": result.wall_clock_ms,
            "validated_success": bool(verification.get("passed")),
            "verification": verification,
            "manual_interventions": 0
        }

        evidence = self.evidence_writer(record, result)
        record.update(evidence)
        record["evidence_level"] = "E4" if record["validated_success"] else "E4"
        return record
