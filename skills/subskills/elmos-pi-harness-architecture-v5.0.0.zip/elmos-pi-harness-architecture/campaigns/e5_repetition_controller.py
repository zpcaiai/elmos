from benchmark.run_group_validator import validate_group
from campaigns.e5_orchestrator import evaluate_e5

def plan(repetitions=5):
    return [{"repetition": i, "status": "PLANNED"} for i in range(repetitions)]

def evaluate(records, min_repetitions=5):
    group = validate_group(records)
    if not group.get("valid"):
        return {"ready": False, "reason": "configuration_drift", "details": group}

    return evaluate_e5(records, min_repetitions=min_repetitions)
