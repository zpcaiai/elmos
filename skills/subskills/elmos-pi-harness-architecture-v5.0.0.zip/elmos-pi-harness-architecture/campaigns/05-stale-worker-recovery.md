# Stale Worker Recovery

Expired leases are reclaimable. Before rerun, inspect immutable evidence from prior attempts.
If a valid completed run exists, reconcile it instead of rerunning.
Retain attempt numbers, old worker IDs, errors and evidence for audit.
