def decide(existing_lineage, current_binding_hash, existing_binding_hash=None):
    if not existing_lineage:
        return {"action":"execute"}

    if existing_binding_hash and existing_binding_hash != current_binding_hash:
        return {"action":"execute_new_scope","reason":"binding_changed"}

    if existing_lineage.get("evidence_level") in {"E4","E5","E6","E7"}:
        return {"action":"reuse_existing_evidence","run_id":existing_lineage.get("run_id")}

    return {"action":"inspect_incomplete_run"}
