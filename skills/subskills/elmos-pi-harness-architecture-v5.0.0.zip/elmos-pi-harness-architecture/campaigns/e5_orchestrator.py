from collections import defaultdict

def group_key(record):
    return (
        record.get("system"),
        record.get("system_version"),
        record.get("repo_revision"),
        record.get("task_case"),
        record.get("model"),
        record.get("provider"),
        record.get("suite_version"),
        record.get("verifier_pack_version")
    )

def evaluate_e5(records, min_repetitions=5):
    groups=defaultdict(list)
    for r in records:
        groups[group_key(r)].append(r)

    blockers=[]
    summaries=[]
    for key,rows in groups.items():
        if len(rows)<min_repetitions:
            blockers.append({"group":str(key),"reason":"insufficient_repetitions"})
        non_e4=[r.get("run_id") for r in rows if r.get("evidence_level") not in {"E4","E5","E6","E7"}]
        if non_e4:
            blockers.append({"group":str(key),"reason":"contains_non_e4","run_ids":non_e4})
        summaries.append({
            "group":str(key),
            "runs":len(rows),
            "validated_success_rate":sum(1 for r in rows if r.get("validated_success"))/len(rows)
        })
    return {"ready":not blockers,"blockers":blockers,"groups":summaries}
