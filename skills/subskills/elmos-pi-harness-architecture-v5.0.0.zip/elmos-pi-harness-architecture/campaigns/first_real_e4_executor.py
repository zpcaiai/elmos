from __future__ import annotations
from pathlib import Path
import uuid, json, hashlib, subprocess
from runtime.elmos_identity import discover
from runtime.elmos_bridge import ElmosBridge
from benchmark.verifier import verify

def _sha256(path: Path):
    h=hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()

def git_diff(repo_path: str):
    p=subprocess.run(["git","diff","--binary"],cwd=repo_path,text=True,capture_output=True)
    return p.stdout

def execute(repo_path, revision, task_case, task_text, gates, output_dir, timeout_seconds=3600):
    identity = discover()
    bridge = ElmosBridge(identity)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    if identity.transport == "none" or not identity.version:
        status = {
            "status":"BLOCKED",
            "reason":"real_elmos_runtime_unavailable",
            "identity":identity.__dict__,
            "repo_revision":revision,
            "task_case":task_case
        }
        (out/"blocked.json").write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding="utf-8")
        return status

    run_id=str(uuid.uuid4())
    result=bridge.execute(repo_path,task_text,timeout_seconds)

    (out/"stdout.txt").write_text(result.stdout,encoding="utf-8")
    (out/"stderr.txt").write_text(result.stderr,encoding="utf-8")
    (out/"diff.patch").write_text(git_diff(repo_path),encoding="utf-8")

    verification=verify(repo_path,gates)
    record={
        "status":"EXECUTED",
        "run_id":run_id,
        "system":"elmos",
        "system_version":result.version,
        "model":result.model,
        "provider":result.provider,
        "repo_revision":revision,
        "task_case":task_case,
        "validated_success":bool(result.executed and verification["passed"]),
        "wall_clock_ms":result.wall_clock_ms,
        "verification":verification,
        "evidence_level":"E4",
        "manual_interventions":0
    }
    (out/"run.json").write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8")

    manifest_files=[]
    for name in ["stdout.txt","stderr.txt","diff.patch","run.json"]:
        p=out/name
        manifest_files.append({"path":name,"sha256":_sha256(p),"bytes":p.stat().st_size})
    manifest={"run_id":run_id,"files":manifest_files}
    raw=json.dumps(manifest,sort_keys=True).encode()
    manifest["sha256"]=hashlib.sha256(raw).hexdigest()
    (out/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")

    record["evidence_manifest"]=str(out/"manifest.json")
    return record
