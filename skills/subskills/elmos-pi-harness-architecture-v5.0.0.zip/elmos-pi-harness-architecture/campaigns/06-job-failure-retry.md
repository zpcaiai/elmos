# Job Failure / Retry Lifecycle

QUEUED → LEASED → RUNNING → COMPLETED

Failure paths:
RUNNING → RETRYABLE
RUNNING → FAILED
RETRYABLE → QUEUED
FAILED → ABANDONED

Retry policy considers:
- attempt count
- failure class
- evidence already produced
- idempotency
- budget remaining
- deterministic/non-deterministic cause

Never blindly retry destructive or non-idempotent external actions.
