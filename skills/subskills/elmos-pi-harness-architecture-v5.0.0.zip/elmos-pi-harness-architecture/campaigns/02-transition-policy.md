# Campaign Transition Policy

DRAFT→PREFLIGHT requires campaign config.
PREFLIGHT→ENV_LOCKED requires environment fingerprint + infrastructure versions.
ENV_LOCKED→ADAPTER_VALIDATED requires adapter smoke evidence.
ADAPTER_VALIDATED→REPO_VALIDATED requires immutable revision + baseline build/tests.
REPO_VALIDATED→TASKS_VALIDATED requires task suite + verifier pack.
TASKS_VALIDATED→RUNNING requires execution workspace.
RUNNING→VERIFYING requires real run IDs.
VERIFYING→NORMALIZING requires deterministic verification.
NORMALIZING→ANALYZING requires normalized records.
ANALYZING→REPORT_READY requires statistics + sample floor.
REPORT_READY→RELEASED requires approved scoped claims.
