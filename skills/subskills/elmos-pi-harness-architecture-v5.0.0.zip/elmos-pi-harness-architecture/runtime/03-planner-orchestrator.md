# Planner and Multi-Agent Orchestrator

Requirement → milestones → workstreams → tasks → atomic actions → validation.

Task fields: objective, dependencies, outputs, acceptance checks, model tier, tool permissions, token/time budget, mutation scope.

Patterns: Pipeline, Fan-out/Fan-in, Expert Pool, Producer-Reviewer, Supervisor, Hierarchical Delegation, Speculative Parallel Solve, Red/Blue Team, Migration Wave, Map-Reduce Repo Sweep, Shadow Execution, Canary Transformation.

Each sub-agent receives isolated context, minimal tools, scope-limited worktree, budget and artifact handoff contract. Merge through diffs, typed artifacts, tests, reviewer score and deterministic conflict rules—not prose consensus.
