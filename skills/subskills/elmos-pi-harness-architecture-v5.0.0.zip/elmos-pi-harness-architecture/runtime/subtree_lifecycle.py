def archive_plan(root_execution_id,descendants):
    live=[d for d in descendants if d.get("runnable")]
    return {"root_execution_id":root_execution_id,
      "steps":["quiesce_descendants","cancel_or_unload_runtime","persist_descendant_archive_state","persist_root_archive_state"],
      "live_descendant_count":len(live),"invariant":"no runnable descendant after parent archive"}
