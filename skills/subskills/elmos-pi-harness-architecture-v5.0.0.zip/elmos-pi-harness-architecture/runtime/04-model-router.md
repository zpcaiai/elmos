# Multi-Model Router

Optimize quality × reliability × latency × cost × cacheability.

Routing dimensions: complexity, language/framework, context size, tool-use reliability, reasoning need, structured-output reliability, SLA, price, availability, tenant policy, historical success.

T0 tiny/cheap: classify/extract/trivial edits.
T1 economical coding: isolated fixes/docs/tests.
T2 strong coding: multi-file changes/refactors/debugging.
T3 frontier reasoning: architecture, ambiguous migrations, hard failures, high-risk review.

Advanced: confidence escalation, best-of-N only where valuable, heterogeneous parallel models, separate judge/generator, downgrade after plan stabilization, provider fallback, cache-aware routing, per-language empirical ranking.

Persist task features → model → outcome → tokens → cost → latency → verification score for policy learning.
