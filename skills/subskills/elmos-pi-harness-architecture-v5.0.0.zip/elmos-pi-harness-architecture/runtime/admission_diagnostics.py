def diagnose(identity=None,connector=None,repo=None,binding=None,verifier=None):
    checks={
      "runtime_identity":bool(identity and identity.get("version")),
      "connector_conformance":bool(connector and connector.get("passed")),
      "repository_binding":bool(repo and repo.get("valid")),
      "runtime_binding":bool(binding and binding.get("ready")),
      "verifier_binding":bool(verifier)
    }
    blockers=[k for k,v in checks.items() if not v]
    return {"ready":not blockers,"checks":checks,"blockers":blockers}
