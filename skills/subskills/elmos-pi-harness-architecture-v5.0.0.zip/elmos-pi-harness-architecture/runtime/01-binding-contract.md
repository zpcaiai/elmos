# Repository / Task Binding

A real E4 run is bound to:

- repository identity
- immutable revision
- task case/version
- exact task text
- verifier pack/version
- Elmos runtime version
- model/provider
- timeout/resource envelope

Changing any binding dimension creates a new benchmark scope.
