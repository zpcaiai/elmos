from runtime.connectors.conformance import run_conformance
from runtime.repository_binding import validate as validate_repo

def admit(connector,repo_path,revision,task_case,suite_version,verifier_pack_version):
    blockers=[]
    conf=run_conformance(connector,repo_path)
    if not conf.get("passed"):
        blockers.append("connector_conformance_failed")

    repo=validate_repo(repo_path,revision)
    if not repo.get("valid"):
        blockers.extend(repo.get("blockers",[]))

    for key,val in {
      "task_case":task_case,
      "suite_version":suite_version,
      "verifier_pack_version":verifier_pack_version
    }.items():
        if not val: blockers.append(f"missing_{key}")

    return {
      "admitted":not blockers,
      "blockers":sorted(set(blockers)),
      "connector":conf,
      "repository":repo
    }
