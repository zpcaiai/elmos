import subprocess, urllib.request

def check(binding):
    if binding["transport"] == "cli":
        binary = binding.get("binary")
        if not binary:
            return {"healthy": False, "reason": "missing_binary"}
        try:
            p = subprocess.run([binary, "--version"], text=True, capture_output=True, timeout=10)
            return {"healthy": p.returncode == 0, "returncode": p.returncode}
        except Exception as e:
            return {"healthy": False, "reason": str(e)}

    if binding["transport"] == "http":
        endpoint = binding.get("health_endpoint")
        if not endpoint:
            return {"healthy": False, "reason": "missing_health_endpoint"}
        try:
            with urllib.request.urlopen(endpoint, timeout=10) as r:
                return {"healthy": 200 <= r.status < 300, "status": r.status}
        except Exception as e:
            return {"healthy": False, "reason": str(e)}

    return {"healthy": False, "reason": "unsupported_transport"}
