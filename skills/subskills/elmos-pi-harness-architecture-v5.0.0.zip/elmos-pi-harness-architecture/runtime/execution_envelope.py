from dataclasses import dataclass,asdict

@dataclass(frozen=True)
class ExecutionEnvelope:
    timeout_seconds:int
    max_cost_usd:float|None
    network_policy:str
    cpu_class:str
    memory_class:str
    allow_manual_intervention:bool=False

def freeze(**kwargs):
    env=ExecutionEnvelope(**kwargs)
    return asdict(env)
