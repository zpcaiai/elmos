from dataclasses import dataclass

@dataclass
class ConnectorRetryPolicy:
    max_attempts: int = 3
    base_delay_seconds: float = 1.0
    max_delay_seconds: float = 15.0

def delay_for(attempt,policy=ConnectorRetryPolicy()):
    return min(policy.base_delay_seconds*(2**max(attempt-1,0)),policy.max_delay_seconds)
