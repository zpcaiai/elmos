# Deterministic Transformation Engine

Use parsers/CST/AST + symbol/type resolution + Semantic IR + transformation recipes + compile + differential validation.

LLMs handle ambiguity, architecture, missing recipe synthesis, explanations and repair; deterministic recipes handle repetitive known rewrites.

Each recipe declares source pattern, preconditions, transform, postconditions, rollback, tests, version compatibility, confidence.

A Golden Route requires repeated runs, multiple repos, low variance, measurable savings, reproducible rollback and evidence packages.
