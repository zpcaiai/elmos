def child_recovery(child,parent,environment_ok,permission_intersection_ok):
    if not parent or not parent.get("loaded"): return {"allowed":False,"reason":"runtime_owner_unavailable"}
    if child.get("runtime_owner_id")!=parent.get("execution_id"): return {"allowed":False,"reason":"owner_mismatch"}
    if not environment_ok: return {"allowed":False,"reason":"environment_drift"}
    if not permission_intersection_ok: return {"allowed":False,"reason":"permission_intersection_failed"}
    return {"allowed":True,"restore_child_local":["model","provider","reasoning","role"],
            "inherit_from_parent":["execution_policy","mcp_extensions"]}
