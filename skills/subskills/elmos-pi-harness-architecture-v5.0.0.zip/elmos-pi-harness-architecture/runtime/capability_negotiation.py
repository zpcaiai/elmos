REQUIRED_E4={"identity","health","execute","stdout","stderr","diff","deterministic_verifier"}

def negotiate(capabilities):
    available={k for k,v in capabilities.items() if v}
    missing=sorted(REQUIRED_E4-available)
    return {"e4_capable":not missing,"missing":missing,"available":sorted(available)}
