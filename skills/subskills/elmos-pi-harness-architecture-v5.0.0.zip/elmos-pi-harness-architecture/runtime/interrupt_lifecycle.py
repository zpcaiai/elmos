def interrupt_sequence(transcript_flushed,hooks_complete,abort_emitted):
    blockers=[]
    if not transcript_flushed: blockers.append("transcript_not_flushed")
    if abort_emitted and not hooks_complete: blockers.append("abort_before_interrupt_hooks")
    return {"valid":not blockers,"blockers":blockers}
def repeated_interrupt(state):
    return {"idempotent":state in {"INTERRUPT_REQUESTED","INTERRUPT_HOOKS","ABORTED","SUSPENDED"}}
