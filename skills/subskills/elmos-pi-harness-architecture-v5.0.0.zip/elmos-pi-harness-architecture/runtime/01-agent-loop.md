# SOTA Agent Loop

OBSERVE → CONTEXT → PLAN → SELECT_SKILL → ROUTE_MODEL → ACT → VERIFY → DIAGNOSE → REPAIR_OR_REPLAN → CHECKPOINT → DONE

Maintain explicit world state: goal, repo state, DAG, completed nodes, hypotheses, failures, constraints.

Failure classes: environment, dependency, syntax/type, regression, semantic behavior, flaky tests, permission/policy, model/tool format, external service, budget/time. Each class owns retry budget, alternate tool/model, escalation, checkpoint strategy.

Support immediate steering, queued follow-up, task pause, fork, and durable cancel.
