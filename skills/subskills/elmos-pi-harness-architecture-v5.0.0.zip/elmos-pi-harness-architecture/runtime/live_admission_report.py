from datetime import datetime, timezone

def build(identity, connector_result, repo_binding, engine_probe, binding_hash):
    blockers = []
    if not identity or not identity.get("version"):
        blockers.append("missing_runtime_identity")
    if not connector_result or not connector_result.get("passed"):
        blockers.append("connector_conformance_failed")
    if not repo_binding or not repo_binding.get("valid"):
        blockers.append("repository_binding_failed")
    if not engine_probe or not engine_probe.get("valid"):
        blockers.append("host_engine_probe_failed")
    if not binding_hash:
        blockers.append("missing_binding_hash")

    return {
        "state": "READY" if not blockers else "BLOCKED",
        "blockers": blockers,
        "identity": identity,
        "connector": connector_result,
        "repository": repo_binding,
        "engine_probe": engine_probe,
        "binding_hash": binding_hash,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
