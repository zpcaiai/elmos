def can_handoff(state,durable_barrier_complete,live_descendants):
    blockers=[]
    if state not in {"SUSPENDING","SUSPENDED","HANDOFF_READY"}: blockers.append("invalid_state")
    if not durable_barrier_complete: blockers.append("durable_barrier_incomplete")
    if live_descendants: blockers.append("live_descendants")
    return {"allowed":not blockers,"blockers":blockers}
def recover_same_execution(execution_id,checkpoint_execution_id):
    return {"allowed":execution_id==checkpoint_execution_id}
