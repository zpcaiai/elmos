# Semantic Context Engine

## Goal
Beat naive RAG/full-repo prompting with structural evidence.

## Sources
Requirement, tenant/project instructions, active skills, repo graph, symbols/references, dependency edges, changed files, failures, build metadata, traces, historical decisions, validated patches, domain constraints.

## Repository Graph
Nodes: repo, module, file, symbol, endpoint, table, topic, test, build target, service, artifact.
Edges: imports, calls, implements, extends, reads/writes, produces/consumes, tests, deploys, depends-on, configures.

## Ranking
Semantic relevance + graph proximity + recency + failure evidence + mutation impact + dependency + authority − token cost.

## Progressive disclosure
Load skill name/description first, then SKILL.md, then references/examples only when needed.

## Cache layout
Stable prefix: system contract, policies, package manifests, stable instructions. Dynamic suffix: current task, targeted code context, recent evidence.
