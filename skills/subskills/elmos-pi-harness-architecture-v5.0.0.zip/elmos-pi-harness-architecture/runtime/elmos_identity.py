from dataclasses import dataclass, asdict
import os, subprocess, shutil, json, urllib.request

@dataclass
class RuntimeIdentity:
    transport: str
    version: str | None
    model: str | None
    provider: str | None
    endpoint: str | None
    binary: str | None
    metadata: dict

def _cli_identity(binary: str):
    p = subprocess.run([binary, "--version"], text=True, capture_output=True, timeout=15)
    version = (p.stdout or p.stderr).strip().splitlines()[0] if (p.stdout or p.stderr).strip() else None
    return RuntimeIdentity(
        transport="cli",
        version=version,
        model=os.getenv("ELMOS_MODEL"),
        provider=os.getenv("ELMOS_PROVIDER"),
        endpoint=None,
        binary=binary,
        metadata={"version_command": [binary, "--version"]}
    )

def _http_identity(endpoint: str):
    req = urllib.request.Request(endpoint.rstrip("/") + "/version", method="GET")
    with urllib.request.urlopen(req, timeout=10) as r:
        payload = json.loads(r.read().decode("utf-8"))
    return RuntimeIdentity(
        transport="http",
        version=payload.get("version"),
        model=payload.get("model"),
        provider=payload.get("provider"),
        endpoint=endpoint,
        binary=None,
        metadata=payload
    )

def discover():
    endpoint = os.getenv("ELMOS_API_URL")
    if endpoint:
        try:
            return _http_identity(endpoint)
        except Exception as e:
            http_error = str(e)
    else:
        http_error = None

    binary = os.getenv("ELMOS_CLI") or shutil.which("elmos")
    if binary:
        try:
            return _cli_identity(binary)
        except Exception as e:
            return RuntimeIdentity(
                transport="cli", version=None, model=None, provider=None,
                endpoint=None, binary=binary, metadata={"error": str(e)}
            )

    return RuntimeIdentity(
        transport="none", version=None, model=None, provider=None,
        endpoint=endpoint, binary=None,
        metadata={"reason":"no_elmos_runtime_found","http_error":http_error}
    )

if __name__ == "__main__":
    print(json.dumps(asdict(discover()), ensure_ascii=False, indent=2))
