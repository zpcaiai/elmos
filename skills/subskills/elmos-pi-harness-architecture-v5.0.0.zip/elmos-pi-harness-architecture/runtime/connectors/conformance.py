def run_conformance(connector, repo_path):
    results={}

    try:
        ident=connector.identity()
        results["identity"]={
            "passed":bool(ident.version and ident.model and ident.provider),
            "transport":ident.transport,
            "version":ident.version,
            "model":ident.model,
            "provider":ident.provider
        }
    except Exception as e:
        results["identity"]={"passed":False,"error":str(e)}

    health=connector.health()
    results["health"]={"passed":bool(health.get("healthy")),"details":health}

    try:
        run=connector.execute(repo_path,"Return a no-op response for connector conformance.",30)
        results["execute"]={
            "passed":bool(run.executed),
            "exit_code":run.exit_code,
            "wall_clock_ms":run.wall_clock_ms
        }
    except Exception as e:
        results["execute"]={"passed":False,"error":str(e)}

    return {
        "passed":all(x.get("passed") for x in results.values()),
        "results":results
    }
