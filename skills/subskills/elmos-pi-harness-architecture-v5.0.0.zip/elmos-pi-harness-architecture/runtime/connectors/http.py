import urllib.request, json, time
from .base import RuntimeConnector, ConnectorIdentity, ConnectorExecution

class HttpRuntimeConnector(RuntimeConnector):
    def __init__(self,endpoint):
        self.endpoint=endpoint.rstrip("/")

    def _get_json(self,path,timeout=10):
        with urllib.request.urlopen(self.endpoint+path,timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def identity(self):
        data=self._get_json("/version")
        return ConnectorIdentity(
            "http",data["version"],data["model"],data["provider"],data
        )

    def health(self):
        try:
            with urllib.request.urlopen(self.endpoint+"/readyz",timeout=10) as r:
                return {"healthy":200 <= r.status < 300,"status":r.status}
        except Exception as e:
            return {"healthy":False,"reason":str(e)}

    def execute(self,repo_path,task,timeout_seconds):
        payload=json.dumps({
            "repo_path":repo_path,"task":task,"timeout_seconds":timeout_seconds
        }).encode("utf-8")
        req=urllib.request.Request(
            self.endpoint+"/v1/tasks",data=payload,
            headers={"Content-Type":"application/json"},method="POST"
        )
        started=time.perf_counter()
        with urllib.request.urlopen(req,timeout=timeout_seconds) as r:
            data=json.loads(r.read().decode("utf-8"))
        return ConnectorExecution(
            True,data.get("exit_code",0),int((time.perf_counter()-started)*1000),
            json.dumps(data,ensure_ascii=False),"",data
        )
