import subprocess, time
from .base import RuntimeConnector, ConnectorIdentity, ConnectorExecution

class CliRuntimeConnector(RuntimeConnector):
    def __init__(self, binary, model, provider):
        self.binary=binary
        self.model=model
        self.provider=provider

    def identity(self):
        p=subprocess.run([self.binary,"--version"],text=True,capture_output=True,timeout=10)
        version=(p.stdout or p.stderr).strip().splitlines()[0]
        return ConnectorIdentity("cli",version,self.model,self.provider,{"binary":self.binary})

    def health(self):
        try:
            p=subprocess.run([self.binary,"--version"],text=True,capture_output=True,timeout=10)
            return {"healthy":p.returncode==0,"returncode":p.returncode}
        except Exception as e:
            return {"healthy":False,"reason":str(e)}

    def execute(self,repo_path,task,timeout_seconds):
        cmd=[self.binary,"run","--task",task,"--json","--model",self.model,"--provider",self.provider]
        started=time.perf_counter()
        p=subprocess.run(cmd,cwd=repo_path,text=True,capture_output=True,timeout=timeout_seconds)
        return ConnectorExecution(
            True,p.returncode,int((time.perf_counter()-started)*1000),
            p.stdout,p.stderr,{"command":cmd}
        )
