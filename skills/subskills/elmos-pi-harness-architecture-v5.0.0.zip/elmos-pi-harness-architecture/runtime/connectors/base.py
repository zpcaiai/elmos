from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

@dataclass
class ConnectorIdentity:
    transport: str
    version: str
    model: str
    provider: str
    metadata: dict[str, Any]

@dataclass
class ConnectorExecution:
    executed: bool
    exit_code: int | None
    wall_clock_ms: int
    stdout: str
    stderr: str
    raw: dict[str, Any]

class RuntimeConnector(ABC):
    @abstractmethod
    def identity(self) -> ConnectorIdentity: ...

    @abstractmethod
    def health(self) -> dict[str, Any]: ...

    @abstractmethod
    def execute(self, repo_path: str, task: str, timeout_seconds: int) -> ConnectorExecution: ...
