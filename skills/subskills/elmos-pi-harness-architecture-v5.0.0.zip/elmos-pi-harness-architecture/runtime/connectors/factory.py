def build_connector(binding):
    transport=binding["transport"]
    if transport=="cli":
        from .cli import CliRuntimeConnector
        return CliRuntimeConnector(
            binding["binary"],binding["model"],binding["provider"]
        )
    if transport=="http":
        from .http import HttpRuntimeConnector
        return HttpRuntimeConnector(binding["endpoint"])
    raise ValueError(f"unsupported transport: {transport}")
