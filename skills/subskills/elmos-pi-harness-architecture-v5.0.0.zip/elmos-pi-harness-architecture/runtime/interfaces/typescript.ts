export type TaskStatus =
  | "CREATED" | "QUEUED" | "PLANNING" | "RUNNING" | "VERIFYING"
  | "WAITING_APPROVAL" | "PAUSED" | "CANCEL_REQUESTED"
  | "CANCELLED" | "FAILED" | "SUCCEEDED";

export interface ModelRequest {
  taskId: string;
  nodeId?: string;
  messages: unknown[];
  tools?: ToolSchema[];
  responseSchema?: unknown;
  maxTokens?: number;
  reasoningLevel?: "low" | "medium" | "high" | "max";
}

export interface ModelResponse {
  provider: string;
  model: string;
  output: unknown;
  toolCalls: ToolCall[];
  usage: {
    inputTokens: number;
    outputTokens: number;
    cachedInputTokens?: number;
    costUsd?: number;
  };
  latencyMs: number;
}

export interface ModelProvider {
  id(): string;
  invoke(req: ModelRequest, signal: AbortSignal): Promise<ModelResponse>;
  supports(capability: string): boolean;
}

export interface ToolSchema {
  name: string;
  description: string;
  inputSchema: unknown;
  riskLevel: "L0" | "L1" | "L2" | "L3";
}

export interface ToolCall {
  id: string;
  name: string;
  args: unknown;
}

export interface ToolRuntime {
  execute(call: ToolCall, ctx: ToolExecutionContext): Promise<ToolResult>;
}

export interface ToolExecutionContext {
  taskId: string;
  nodeId?: string;
  idempotencyKey: string;
  sandboxProfile: string;
  permissionScope: unknown;
  timeoutMs: number;
}

export interface ToolResult {
  status: "completed" | "failed" | "denied" | "timed_out";
  stdoutArtifactId?: string;
  stderrArtifactId?: string;
  resultArtifactId?: string;
}

export interface ContextSegment {
  kind: string;
  contentRef: string;
  score: number;
  estimatedTokens: number;
  provenance: unknown;
}

export interface ContextBuilder {
  build(taskId: string, nodeId: string, budgetTokens: number): Promise<ContextSegment[]>;
}
