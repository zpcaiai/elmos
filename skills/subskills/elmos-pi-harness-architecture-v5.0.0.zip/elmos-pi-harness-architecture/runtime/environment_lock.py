import json, hashlib, platform, os, subprocess

def _cmd(cmd):
    try:
        p = subprocess.run(cmd, text=True, capture_output=True, timeout=10)
        return (p.stdout or p.stderr).strip()
    except Exception:
        return None

def build(runtime_binding, repo_revision, task_case, suite_version, verifier_pack_version):
    payload = {
        "runtime_binding": runtime_binding,
        "repo_revision": repo_revision,
        "task_case": task_case,
        "suite_version": suite_version,
        "verifier_pack_version": verifier_pack_version,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
        "git_version": _cmd(["git", "--version"]),
        "python_version": platform.python_version()
    }
    payload["sha256"] = hashlib.sha256(
        json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()
    return payload
