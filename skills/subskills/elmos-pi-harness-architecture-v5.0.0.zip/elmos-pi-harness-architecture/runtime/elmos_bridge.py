from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import subprocess, time, json, urllib.request, os

@dataclass
class ElmosExecutionResult:
    executed: bool
    transport: str
    version: str | None
    model: str | None
    provider: str | None
    wall_clock_ms: int
    stdout: str
    stderr: str
    raw: dict

class ElmosBridge:
    def __init__(self, identity):
        self.identity = identity

    def execute(self, repo_path: str, task: str, timeout_seconds: int = 3600):
        if self.identity.transport == "cli":
            return self._execute_cli(repo_path, task, timeout_seconds)
        if self.identity.transport == "http":
            return self._execute_http(repo_path, task, timeout_seconds)
        return ElmosExecutionResult(
            executed=False, transport="none", version=None, model=None, provider=None,
            wall_clock_ms=0, stdout="", stderr="",
            raw={"status":"BLOCKED","reason":"no_elmos_runtime"}
        )

    def _execute_cli(self, repo_path, task, timeout_seconds):
        cmd = [self.identity.binary, "run", "--task", task, "--json"]
        if self.identity.model:
            cmd += ["--model", self.identity.model]
        if self.identity.provider:
            cmd += ["--provider", self.identity.provider]

        started = time.perf_counter()
        p = subprocess.run(
            cmd, cwd=repo_path, text=True, capture_output=True, timeout=timeout_seconds
        )
        return ElmosExecutionResult(
            executed=True,
            transport="cli",
            version=self.identity.version,
            model=self.identity.model,
            provider=self.identity.provider,
            wall_clock_ms=int((time.perf_counter()-started)*1000),
            stdout=p.stdout,
            stderr=p.stderr,
            raw={"command":cmd,"exit_code":p.returncode}
        )

    def _execute_http(self, repo_path, task, timeout_seconds):
        payload = json.dumps({
            "repo_path": repo_path,
            "task": task,
            "timeout_seconds": timeout_seconds
        }).encode("utf-8")
        req = urllib.request.Request(
            self.identity.endpoint.rstrip("/") + "/v1/tasks",
            data=payload,
            headers={"Content-Type":"application/json"},
            method="POST"
        )
        started = time.perf_counter()
        with urllib.request.urlopen(req, timeout=timeout_seconds) as r:
            response = json.loads(r.read().decode("utf-8"))
        return ElmosExecutionResult(
            executed=True,
            transport="http",
            version=self.identity.version,
            model=response.get("model") or self.identity.model,
            provider=response.get("provider") or self.identity.provider,
            wall_clock_ms=int((time.perf_counter()-started)*1000),
            stdout=json.dumps(response, ensure_ascii=False),
            stderr="",
            raw=response
        )
