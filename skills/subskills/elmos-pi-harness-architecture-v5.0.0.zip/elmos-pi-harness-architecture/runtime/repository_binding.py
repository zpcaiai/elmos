from pathlib import Path
import subprocess

def validate(repo_path, expected_revision):
    repo=Path(repo_path)
    blockers=[]
    if not repo.exists():
        blockers.append("repo_not_found")
        return {"valid":False,"blockers":blockers}

    try:
        p=subprocess.run(
            ["git","rev-parse","HEAD"],cwd=repo,text=True,capture_output=True,timeout=10
        )
        actual=p.stdout.strip() if p.returncode==0 else None
    except Exception:
        actual=None

    if not actual:
        blockers.append("not_git_repository")
    elif actual != expected_revision:
        blockers.append("revision_mismatch")

    return {"valid":not blockers,"blockers":blockers,"actual_revision":actual}
