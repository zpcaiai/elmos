from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class RuntimeBinding:
    transport: str
    version: str
    model: str
    provider: str
    binary: str | None = None
    endpoint: str | None = None
    health_endpoint: str | None = None

def bind(identity, model=None, provider=None):
    resolved_model = model or identity.model
    resolved_provider = provider or identity.provider

    blockers = []
    if identity.transport not in {"cli", "http"}:
        blockers.append("unsupported_transport")
    if not identity.version:
        blockers.append("missing_runtime_version")
    if not resolved_model:
        blockers.append("missing_model")
    if not resolved_provider:
        blockers.append("missing_provider")

    if blockers:
        return {"ready": False, "blockers": blockers}

    binding = RuntimeBinding(
        transport=identity.transport,
        version=identity.version,
        model=resolved_model,
        provider=resolved_provider,
        binary=identity.binary,
        endpoint=identity.endpoint,
        health_endpoint=(identity.endpoint.rstrip("/") + "/readyz") if identity.endpoint else None
    )
    return {"ready": True, "binding": asdict(binding)}
