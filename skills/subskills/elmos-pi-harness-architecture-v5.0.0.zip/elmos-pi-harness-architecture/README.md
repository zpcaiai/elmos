# elmos-pi-harness-architecture v5.0.0

**Execution Kernel Convergence Edition**

v5.0 is a structural milestone. It merges the v4.8 evidence runtime with the v4.9
Ownership / TypedContext / Timeline / Policy / Lifecycle model.

The result is a unified Harness Runtime Kernel rather than parallel subsystems.

Key additions:
- `ExecutionKernel`
- ownership transaction + epoch
- timeline-based recovery
- typed artifact projection
- runtime connection-state API
- effect-level approval journal
- interrupt/suspend handoff coordinator
- parent-owned child recovery
- fail-closed policy mapping
- E4/E5 evidence projection from execution timeline
