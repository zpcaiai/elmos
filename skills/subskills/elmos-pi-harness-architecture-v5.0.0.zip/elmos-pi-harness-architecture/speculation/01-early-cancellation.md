# Speculative Early Cancellation

Branches emit incremental evidence:
- compile status
- test pass/fail
- verifier score
- cost spent
- expected remaining time

Cancel a loser when:
- another branch is already validated and materially better
- branch hits deterministic failure
- verifier confidence gap exceeds threshold
- remaining expected value is lower than incremental cost

Never cancel solely because a model self-reports confidence.
