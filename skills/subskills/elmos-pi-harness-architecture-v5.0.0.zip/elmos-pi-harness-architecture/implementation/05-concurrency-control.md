# Tenant Concurrency Control

Default product policy:
- maximum 3 simultaneously RUNNING root tasks per account/tenant unless plan overrides it.

Implementation:
1. acquire tenant execution permit before workflow enters RUNNING;
2. permit stored in durable semaphore table or Redis with DB reconciliation;
3. heartbeat permits;
4. reclaim expired permit after workflow liveness check;
5. child DAG nodes do not consume root-task permits but obey per-task agent concurrency budget.

Never enforce this only in UI.
