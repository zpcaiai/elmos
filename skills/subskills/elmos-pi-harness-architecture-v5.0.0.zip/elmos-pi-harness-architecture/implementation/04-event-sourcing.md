# Event Sourcing and Recovery

## Storage pattern

Authoritative history:
`task_event`

Derived state:
- task snapshot
- DAG snapshot
- billing summary
- verification summary
- execution UI state

## Event envelope

```json
{
  "event_id": "uuid",
  "sequence": 12345,
  "tenant_id": "uuid",
  "project_id": "uuid",
  "task_id": "uuid",
  "node_id": "uuid",
  "event_type": "tool.completed",
  "timestamp": "RFC3339",
  "correlation_id": "uuid",
  "causation_id": "uuid",
  "payload_version": 1,
  "payload": {}
}
```

## Crash recovery

1. scheduler detects expired lease
2. load latest checkpoint
3. replay subsequent events
4. inspect side-effect journal
5. determine:
   - already completed → mark complete
   - safely retryable → requeue
   - uncertain external side effect → require reconciliation
6. continue from last safe point

## Checkpoint policy

Checkpoint on:
- completed DAG node
- expensive model turn
- approved side effect
- large artifact produced
- before/after schema migration
- every N minutes for long-running nodes
