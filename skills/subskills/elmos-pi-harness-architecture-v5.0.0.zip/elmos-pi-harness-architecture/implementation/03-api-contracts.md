# Core API Contracts

## POST /v1/tasks

Request:
```json
{
  "project_id": "uuid",
  "objective": "string",
  "inputs": [],
  "constraints": {},
  "budgets": {
    "max_cost_usd": 20,
    "max_wall_clock_seconds": 5400
  },
  "execution": {
    "max_parallel_agents": 4,
    "model_policy": "auto"
  }
}
```

Response:
```json
{
  "task_id": "uuid",
  "status": "CREATED",
  "estimated_wall_clock_seconds": 1800
}
```

## POST /v1/tasks/{id}/pause
## POST /v1/tasks/{id}/resume
## POST /v1/tasks/{id}/cancel
## POST /v1/tasks/{id}/branch
## GET  /v1/tasks/{id}
## GET  /v1/tasks/{id}/events
## GET  /v1/tasks/{id}/artifacts
## GET  /v1/tasks/{id}/trace
## GET  /v1/tasks/{id}/cost
## GET  /v1/tasks/{id}/verification

## Model Router

POST /internal/model-route

Input:
- task features
- context size
- required capabilities
- budget/SLA
- tenant model constraints

Output:
- primary model
- fallback chain
- max reasoning effort
- max token budget
- parallel strategy

## Tool Runtime

POST /internal/tools/execute

Required:
- task_id
- tool
- args
- permission_scope
- idempotency_key
- timeout_ms
- sandbox_profile

All tool calls return artifact references instead of embedding large outputs.
