# Implementation Principles

1. Kernel is domain-agnostic.
2. State correctness may not depend on process memory.
3. Events are immutable; views are materialized.
4. Every external side effect has idempotency strategy.
5. Every tool runs under explicit permissions.
6. Context is composed from evidence, not dumped wholesale.
7. Skills are progressively disclosed.
8. Provider/model is replaceable without changing agent logic.
9. Verification gates determine completion.
10. Wall-clock ETA is machine-runtime ETA, not person-days.
11. Multi-tenant quotas are enforced centrally.
12. Every task supports pause, resume, cancel, retry, replay.
13. Every production mutation has provenance and audit.
