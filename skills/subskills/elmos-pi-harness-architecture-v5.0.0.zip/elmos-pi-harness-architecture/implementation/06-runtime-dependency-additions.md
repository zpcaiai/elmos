# v1.5 Runtime Dependency Additions

Add to runtime-core:
- PyYAML
- optional Tree-sitter core and language grammars
- optional vector database / pgvector adapter
- optional language-server/compiler resolvers

Do not make all language grammars mandatory in the minimal kernel image.
Use plugin/package isolation so customers install only required language packs.
