# Epic Breakdown

## EPIC-01 Agent Kernel
Goal: deterministic agent lifecycle independent of models/providers.

Features:
- provider-neutral request/response contract
- tool-call loop
- streaming
- steering/follow-up queue
- lifecycle events
- cancellation
- run limits

## EPIC-02 Semantic Context Engine
Goal: construct minimal high-value context for large repositories.

Features:
- repo indexing
- AST/symbol extraction
- dependency graph
- change-impact graph
- failure-evidence retrieval
- skill progressive disclosure
- cache-aware context packing
- context provenance

## EPIC-03 Durable Task DAG
Goal: long-running resilient execution.

Features:
- DAG scheduler
- leases/heartbeats
- checkpoints
- pause/resume/cancel
- classified retries
- crash recovery
- exactly-once or idempotent side effects
- per-account max concurrent tasks policy

## EPIC-04 Verification & Auto-Repair
Goal: prove correctness automatically.

Features:
- compile/lint/unit/integration/E2E
- security/perf/UI tests
- test selection
- failure diagnosis
- auto-repair loop
- evidence report
- regression gates

## EPIC-05 Model Router
Goal: maximize quality/reliability/cost performance.

Features:
- model capability registry
- task classification
- routing policy
- fallback
- confidence escalation
- heterogeneous parallel solve
- judge/generator separation
- online routing telemetry

## EPIC-06 Multi-Agent Runtime
Goal: safe parallel engineering.

Features:
- supervisor
- producer-reviewer
- fanout/fanin
- expert pool
- speculative solve
- worktree isolation
- artifact handoff
- merge adjudication

## EPIC-07 Transformation Engine
Goal: deterministic high-volume migrations.

Features:
- parser/CST/AST adapters
- Semantic IR
- rule DSL
- recipe registry
- reversible rewrite
- compile/test validation
- differential runtime

## EPIC-08 Enterprise Security
Goal: enterprise-grade isolation and governance.

Features:
- sandbox
- secret broker
- approval policy
- tool parameter policy
- package signing
- tenant isolation
- audit
- egress control
- injection defense

## EPIC-09 Observability & Economics
Goal: full execution and business visibility.

Features:
- OpenTelemetry traces
- logs/metrics
- task ETA
- token/cost ledger
- revenue attribution
- margin
- cache metrics
- SLO dashboards

## EPIC-10 Golden Routes & Certification
Goal: repeatable paid repository transformations.

Features:
- Spring modernization route
- >500k LOC certification
- >1M LOC certification
- benchmark baselines
- production release gates
