# ExecutionTimeline + ArtifactStore + Projection
Timeline is the canonical fact source. Typed artifacts are independent durable outputs.
UI/history/reports are reconstructable projections. Verify pagination replay equivalence,
realtime ordering after recovery and artifact identity idempotency.
