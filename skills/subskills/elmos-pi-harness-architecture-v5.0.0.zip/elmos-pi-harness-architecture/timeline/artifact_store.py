class ArtifactIdentityError(RuntimeError): pass
class InMemoryArtifactStore:
    def __init__(self): self.rows={}
    def put(self,thread_id,artifact_type,identity_key,payload):
        key=(thread_id,artifact_type,identity_key)
        if key in self.rows and self.rows[key]!=payload: raise ArtifactIdentityError("identity collision")
        self.rows[key]=payload; return key
