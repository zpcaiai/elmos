def recover_projection(events):
    state = {
        "lifecycle_state": "CREATED",
        "runtime_owner_id": None,
        "ownership_epoch": 0,
        "runtime_states": {},
        "artifacts": [],
        "verification": None
    }

    for event in sorted(events, key=lambda e: e["sequence"]):
        t = event["event_type"]
        p = event.get("payload", {})

        if t.startswith("execution."):
            mapping = {
                "execution.started": "RUNNING",
                "execution.interrupt_requested": "INTERRUPT_REQUESTED",
                "execution.suspending": "SUSPENDING",
                "execution.suspended": "SUSPENDED",
                "execution.handoff_ready": "HANDOFF_READY",
                "execution.completed": "COMPLETED",
                "execution.aborted": "ABORTED",
                "execution.failed": "FAILED",
            }
            if t in mapping:
                state["lifecycle_state"] = mapping[t]

        if t == "execution.owner_transferred":
            state["runtime_owner_id"] = p.get("runtime_owner_id")
            state["ownership_epoch"] = p.get("ownership_epoch", state["ownership_epoch"])

        if t == "tool.runtime_state_observed":
            state["runtime_states"][p["adapter_id"]] = p["runtime_state"]

        if t == "artifact.created":
            state["artifacts"].append(p)

        if t == "verification.completed":
            state["verification"] = p

    return state
