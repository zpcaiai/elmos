from dataclasses import dataclass
@dataclass(frozen=True)
class TimelineEvent:
    sequence:int; execution_id:str; event_type:str; payload:dict
def paginate(events,offset=0,limit=100,active_realtime_session_at_page_start=None):
    page=events[offset:offset+limit]
    return {"items":[e.__dict__ for e in page],
      "next_offset":offset+len(page) if offset+len(page)<len(events) else None,
      "activeRealtimeSessionAtPageStart":active_realtime_session_at_page_start}
