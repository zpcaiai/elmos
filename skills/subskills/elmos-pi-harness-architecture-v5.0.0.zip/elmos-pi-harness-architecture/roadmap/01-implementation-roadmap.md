# Implementation Roadmap

P0 Minimal Kernel: provider abstraction, agent loop, tools, events, package manifest, CLI/RPC/SDK. Gate: reproducible task across >=3 providers.

P1 Context Engine: repo indexing, symbol graph, progressive skills, context ranking, cache partitioning. Gate: token reduction without quality loss.

P2 Durable DAG: DAG, checkpoints, pause/resume/cancel, leases, recovery. Gate: injected failures auto-recover.

P3 Verification Runtime: compile/lint/unit/integration/security, targeted tests, evidence bundles. Gate: no success without required evidence.

P4 Model Router: classification, tiering, fallback, accounting, policy learning. Gate: equal/higher success at lower blended cost than fixed-frontier baseline.

P5 Transformation Engine: AST/CST, Semantic IR, recipes, rollback, differential tests. Gate: first repeatable Spring Golden Route.

P6 Enterprise Security: sandbox, secret broker, approvals, signed packages, audit, tenant isolation. Gate: red-team passes.

P7 Large Repository Certification: >=3 repos >500k LOC, >=1 >1M LOC. Gate: paid-repeatable Golden Route candidate.

P8 Commercial GA: billing, SLA, admin, private deployment, diagnostics, compliance. Gate: customers can buy, operate, audit, renew.
