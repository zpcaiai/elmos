# 16-Week Implementation Plan

## Weeks 1–2: P0 Kernel
- provider-neutral runtime
- tool runtime
- event bus
- artifacts
- CLI/RPC
Gate: 3-provider reproducibility

## Weeks 3–4: P1 Context
- parser adapters
- symbol/dependency graph
- skill loader
- cache-aware packing
Gate: lower token use without quality loss

## Weeks 5–6: P2 Durable DAG
- scheduler
- checkpoints
- lease
- pause/resume/cancel
- recovery
Gate: chaos tests pass

## Weeks 7–8: P3 Verification
- compile/lint/unit/integration
- evidence model
- auto-repair
Gate: no unverified success

## Weeks 9–10: P4 Router + P6 Multi-Agent
- model registry
- routing
- fallback
- producer/reviewer
- fanout/fanin
Gate: lower blended cost at same/better quality

## Weeks 11–12: P5 Transformation
- Java/Spring AST pipeline
- recipe DSL
- IR skeleton
Gate: repeatable migration slice

## Weeks 13–14: P6 Security + Observability
- sandbox
- approval
- OTel
- billing
Gate: red-team suite passes

## Weeks 15–16: P7 Pilot Golden Route
- 500k+ LOC pilot
- failure injection
- runtime/cost benchmark
Gate: commercial pilot evidence pack
