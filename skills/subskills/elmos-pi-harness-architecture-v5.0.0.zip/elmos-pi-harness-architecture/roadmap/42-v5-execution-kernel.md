# v5.0 Roadmap

Completed in this package:
- ExecutionKernel aggregate
- durable ownership protocol
- timeline recovery
- projection layer
- runtime-state control plane
- effect-level approval journal
- interrupt/suspend coordinator
- parent-authoritative child recovery
- versioned fail-closed adapter policy mappings
- evidence projection from timeline

Next:
1. merge v5 kernel into actual Elmos main runtime
2. dual-write existing session/task storage
3. run replay-equivalence/property tests
4. migrate real E4/E5 execution onto the kernel
5. only then remove legacy session/task authoritative state
