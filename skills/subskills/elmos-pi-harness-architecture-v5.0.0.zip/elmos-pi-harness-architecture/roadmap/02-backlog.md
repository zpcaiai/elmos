# Engineering Backlog

## Kernel
- [ ] AgentRuntime interfaces
- [ ] provider adapters
- [ ] ToolRuntime idempotency
- [ ] event versioning
- [ ] package loader
- [ ] RPC/SDK

## Context
- [ ] parser adapters
- [ ] symbol/dependency graph
- [ ] context ranker
- [ ] progressive skill loader
- [ ] compaction
- [ ] cache keys

## Orchestration
- [ ] DAG scheduler
- [ ] sub-agent isolation
- [ ] fan-out/supervisor/reviewer
- [ ] budget enforcement

## Reliability
- [ ] checkpoint store
- [ ] worker lease
- [ ] classified retry
- [ ] crash injection/resume tests

## Verification
- [ ] compile/lint/unit/integration/UI/perf/security
- [ ] evidence report

## Transformation
- [ ] Semantic IR
- [ ] recipe DSL
- [ ] Java/Spring parser
- [ ] rewrite engine
- [ ] differential harness

## Commercial
- [ ] cost ledger
- [ ] machine wall-clock ETA
- [ ] pricing policy
- [ ] margin dashboard
- [ ] enterprise admin
