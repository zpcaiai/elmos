# v2 Commercial SOTA Roadmap
GA blockers:
- production JDT classpath resolution
- robust LSP lifecycle
- real Spring semantic AST rewrites
- distributed benchmark workers
- first >500k LOC paid pilot
- >1M LOC certification candidate
- security red-team
- billing reconciliation
- certification dashboard
- SLA dashboards

v2.1: learned router, speculative execution, semantic cache, distributed indexing,
incremental verification and benchmark-driven auto-tuning.
