# v4.0 Roadmap

Added:
- dual CLI/HTTP runtime identity
- Elmos runtime bridge
- repository/task binding contract
- first real E4 executor
- persistence service contract
- strict BLOCKED/EXECUTED semantics
- first-E4 campaign template
- E5 handoff
- PostgreSQL evidence CI
- runtime identity persistence

v4.1 target:
- bind an actual Elmos runtime
- run first real repository task to E4
- persist PostgreSQL lineage
- repeat 5x to E5
- only then onboard competitor adapters
