# Automatic Rollback

Rollback triggers:
- validated success regression
- regression escape increase
- cost/success regression
- p95 wall-clock regression
- recovery reliability regression
- cache correctness incident
- provider error amplification

Rollback restores the previous active policy/artifact pointer and records immutable cause/evidence.
