# Runtime Auto-Tuning Event Loop

task.completed / benchmark.completed / policy evaluations / SLO regressions
→ ingest verified outcomes
→ update KPI windows
→ evaluate candidate vs baseline
→ shadow
→ canary
→ promote or rollback
→ emit immutable rollout event.

This loop cannot modify security or approval policy.
