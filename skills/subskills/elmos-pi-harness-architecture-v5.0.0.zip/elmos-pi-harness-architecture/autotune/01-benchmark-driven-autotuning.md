# Benchmark-Driven Auto-Tuning

Candidate knobs:
- router weights
- context fusion weights
- reranker top-k
- graph expansion hops
- speculative threshold
- verification escalation threshold
- concurrency
- cache TTL/policy

Lifecycle:
offline benchmark
→ shadow policy
→ canary
→ statistical comparison
→ promote or rollback

Never let online tuning alter security/approval boundaries.
