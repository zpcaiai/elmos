# Shadow / Canary Policy Promotion

1. offline evaluation
2. shadow execution on production-like traffic
3. compare counterfactual decision/outcome estimates
4. limited canary
5. benchmark + production SLO review
6. promote or rollback

Automatic rollback triggers:
- validated success regression
- cost/success regression beyond threshold
- p95 wall-clock regression
- recovery/SLA regression
- cache correctness violation
