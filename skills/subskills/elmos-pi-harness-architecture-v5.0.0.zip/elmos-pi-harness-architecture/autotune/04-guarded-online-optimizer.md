# Guarded Online Policy Optimizer

Allowed knobs:
- model/router weights
- context top-k
- graph hops
- speculative threshold
- concurrency
- cache TTL
- verification ordering

Forbidden:
- security policy
- tenant authorization
- mandatory release gates
- destructive-action approval

Lifecycle:
candidate → offline benchmark → shadow → canary → promote/rollback.
