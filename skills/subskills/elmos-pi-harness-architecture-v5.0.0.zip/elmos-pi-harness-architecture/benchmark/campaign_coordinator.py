from dataclasses import dataclass, asdict
from pathlib import Path
import json, uuid, time

@dataclass
class Campaign:
    id: str
    name: str
    mode: str
    repetitions: int
    systems: list[str]
    status: str = "CREATED"

def create_campaign(name, mode, repetitions, systems, output_dir):
    c = Campaign(str(uuid.uuid4()), name, mode, repetitions, systems)
    out = Path(output_dir) / c.id
    out.mkdir(parents=True, exist_ok=True)
    payload = {**asdict(c), "created_at": time.time()}
    (out / "campaign.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return payload

def expected_run_count(campaign, case_count):
    return len(campaign["systems"]) * int(campaign["repetitions"]) * int(case_count)
