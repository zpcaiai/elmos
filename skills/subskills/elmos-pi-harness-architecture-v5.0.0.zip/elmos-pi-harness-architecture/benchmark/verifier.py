from dataclasses import dataclass, asdict
from pathlib import Path
import subprocess, time

@dataclass
class Verification:
    name:str
    passed:bool
    returncode:int|None
    wall_clock_ms:int
    stdout:str
    stderr:str

def verify(repo_path, gates):
    results=[]
    for gate in gates:
        started=time.perf_counter()
        try:
            p=subprocess.run(
                gate["command"],cwd=repo_path,text=True,capture_output=True,
                timeout=gate.get("timeout_seconds",900)
            )
            result=Verification(
                gate["name"],p.returncode==0,p.returncode,
                int((time.perf_counter()-started)*1000),
                p.stdout[-12000:],p.stderr[-12000:]
            )
        except subprocess.TimeoutExpired as e:
            result=Verification(
                gate["name"],False,None,
                int((time.perf_counter()-started)*1000),
                str(e.stdout or "")[-12000:],str(e.stderr or "")[-12000:]
            )
        results.append(asdict(result))
        if not result.passed and gate.get("fail_fast",True):
            break
    return {
      "passed": all(x["passed"] for x in results),
      "gates":results
    }
