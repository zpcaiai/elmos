from pathlib import Path
import tempfile
from benchmark.adapters import ADAPTERS
from benchmark.adapter_base import RunConfig

def smoke(system, repo_path, revision, task="Inspect the repository and summarize it briefly."):
    adapter = ADAPTERS[system]()
    profile = adapter.discover()
    if profile.version is None:
        return {"system": system, "status": "not_installed_or_unavailable"}

    with tempfile.TemporaryDirectory(prefix=f"elmos-bench-{system}-") as td:
        try:
            result = adapter.run(
                RunConfig(
                    repo_path=repo_path,
                    revision=revision,
                    task=task,
                    timeout_seconds=180
                ),
                Path(td)
            )
            return {
                "system": system,
                "version": result.version,
                "status": "timed_out" if result.timed_out else "completed",
                "exit_code": result.exit_code,
                "wall_clock_ms": result.wall_clock_ms
            }
        except Exception as e:
            return {"system": system, "status": "failed", "error": str(e)}
