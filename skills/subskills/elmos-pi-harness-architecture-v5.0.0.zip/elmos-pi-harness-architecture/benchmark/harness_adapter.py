from dataclasses import dataclass
from abc import ABC, abstractmethod
from typing import Any

@dataclass
class HarnessRunConfig:
    system_name: str
    system_version: str
    model: str | None
    provider: str | None
    repo_path: str
    revision: str
    task: str
    wall_clock_limit_s: int
    max_cost_usd: float | None
    environment: dict[str, Any]

@dataclass
class HarnessRunResult:
    validated_success: bool
    wall_clock_ms: int
    input_tokens: int
    output_tokens: int
    cached_tokens: int
    cost_usd: float
    tool_calls: int
    repair_loops: int
    manual_interventions: int
    evidence: dict[str, Any]

class HarnessAdapter(ABC):
    @abstractmethod
    def run(self, config: HarnessRunConfig) -> HarnessRunResult:
        ...

class ExternalCliHarnessAdapter(HarnessAdapter):
    def __init__(self, command_builder):
        self.command_builder = command_builder

    def run(self, config: HarnessRunConfig) -> HarnessRunResult:
        raise NotImplementedError("Bind to isolated CLI runner and evidence collector")
