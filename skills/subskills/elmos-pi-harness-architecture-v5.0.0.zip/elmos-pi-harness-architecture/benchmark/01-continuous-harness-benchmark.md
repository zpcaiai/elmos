# Continuous Harness Benchmark Service

Runs:
- nightly smoke suite
- weekly representative suite
- release-blocking suite
- large-repo certification suite

Each run pins:
- repo revision
- task version
- system version
- model/provider
- tool permissions
- budget
- environment fingerprint

Outputs:
- raw traces
- evidence
- per-case metrics
- aggregate confidence intervals
- baseline deltas

Promotion decisions must reference a benchmark run ID.
