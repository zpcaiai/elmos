from __future__ import annotations
from dataclasses import dataclass, field, asdict
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any
import subprocess, time, os, json, hashlib

@dataclass
class CapabilityProfile:
    system_name: str
    version: str | None = None
    supports_model_override: bool = False
    supports_noninteractive: bool = False
    supports_json_output: bool = False
    supports_tool_policy: bool = False
    supports_token_metrics: bool = False
    supports_cost_metrics: bool = False
    notes: list[str] = field(default_factory=list)

@dataclass
class RunConfig:
    repo_path: str
    revision: str
    task: str
    timeout_seconds: int = 3600
    model: str | None = None
    provider: str | None = None
    max_cost_usd: float | None = None
    environment: dict[str, str] = field(default_factory=dict)

@dataclass
class NormalizedRun:
    system: str
    version: str | None
    revision: str
    task: str
    exit_code: int | None
    timed_out: bool
    wall_clock_ms: int
    stdout_path: str
    stderr_path: str
    input_tokens: int | None = None
    output_tokens: int | None = None
    cached_tokens: int | None = None
    cost_usd: float | None = None
    tool_calls: int | None = None
    manual_interventions: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

class HarnessAdapter(ABC):
    name: str

    @abstractmethod
    def discover(self) -> CapabilityProfile:
        ...

    @abstractmethod
    def build_command(self, config: RunConfig) -> list[str]:
        ...

    def parse_metrics(self, stdout: str, stderr: str) -> dict[str, Any]:
        return {}

    def run(self, config: RunConfig, output_dir: Path) -> NormalizedRun:
        output_dir.mkdir(parents=True, exist_ok=True)
        command = self.build_command(config)
        env = os.environ.copy()
        env.update(config.environment)

        stdout_path = output_dir / f"{self.name}.stdout.txt"
        stderr_path = output_dir / f"{self.name}.stderr.txt"

        started = time.perf_counter()
        timed_out = False
        exit_code = None
        stdout = ""
        stderr = ""

        try:
            p = subprocess.run(
                command,
                cwd=config.repo_path,
                env=env,
                text=True,
                capture_output=True,
                timeout=config.timeout_seconds
            )
            exit_code = p.returncode
            stdout = p.stdout
            stderr = p.stderr
        except subprocess.TimeoutExpired as e:
            timed_out = True
            stdout = e.stdout or ""
            stderr = e.stderr or ""

        wall_clock_ms = int((time.perf_counter() - started) * 1000)
        stdout_path.write_text(stdout, encoding="utf-8", errors="ignore")
        stderr_path.write_text(stderr, encoding="utf-8", errors="ignore")

        metrics = self.parse_metrics(stdout, stderr)
        profile = self.discover()

        return NormalizedRun(
            system=self.name,
            version=profile.version,
            revision=config.revision,
            task=config.task,
            exit_code=exit_code,
            timed_out=timed_out,
            wall_clock_ms=wall_clock_ms,
            stdout_path=str(stdout_path),
            stderr_path=str(stderr_path),
            input_tokens=metrics.get("input_tokens"),
            output_tokens=metrics.get("output_tokens"),
            cached_tokens=metrics.get("cached_tokens"),
            cost_usd=metrics.get("cost_usd"),
            tool_calls=metrics.get("tool_calls"),
            metadata={
                "command": command,
                "capabilities": asdict(profile),
                "metrics_observed": sorted(metrics.keys())
            }
        )

def command_version(command: list[str]) -> str | None:
    try:
        p = subprocess.run(command, text=True, capture_output=True, timeout=10)
        text = (p.stdout or p.stderr).strip()
        return text.splitlines()[0] if text else None
    except Exception:
        return None
