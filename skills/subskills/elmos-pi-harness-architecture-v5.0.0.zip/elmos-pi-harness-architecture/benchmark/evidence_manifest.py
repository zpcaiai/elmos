from pathlib import Path
import hashlib, json

def sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def build(root:Path):
    files=[]
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.name!="manifest.json":
            files.append({
              "path":str(p.relative_to(root)),
              "sha256":sha256(p),
              "bytes":p.stat().st_size
            })
    manifest={"files":files}
    (root/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    return manifest
