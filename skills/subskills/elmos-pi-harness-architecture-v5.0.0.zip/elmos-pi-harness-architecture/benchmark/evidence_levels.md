# Evidence Maturity

- E0 — benchmark/campaign planned
- E1 — environment and versions validated
- E2 — adapter smoke test passed
- E3 — real run completed and raw stdout/stderr/diff captured
- E4 — deterministic verifier establishes pass/fail
- E5 — required repetitions completed and statistics generated
- E6 — large-repo/chaos certification complete

Rules:
- architecture screenshots are not benchmark evidence
- a smoke test is not a quality benchmark
- a single successful run is not a comparative claim
- only verified runs enter success-rate statistics
