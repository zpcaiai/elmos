# Benchmark Warehouse

Dimensions:
system/version, model/provider, task, repository/revision, environment, policy version.

Facts:
validated success, regression-free success, tokens/cache, cost, machine wall-clock,
tool calls, repair loops, recovery events and verification results.

Raw evidence stays immutable in artifact storage.
