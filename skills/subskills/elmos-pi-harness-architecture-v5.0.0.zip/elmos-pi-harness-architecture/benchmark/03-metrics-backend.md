# Benchmark Metrics Backend

Store:
- suite/run/case/repetition IDs
- repo revision
- environment fingerprint
- system/model/tool configuration
- success/failure
- tokens/cost/cache
- machine wall-clock
- verification evidence
- raw artifact refs

Dashboard data is derived; raw benchmark evidence remains immutable.
