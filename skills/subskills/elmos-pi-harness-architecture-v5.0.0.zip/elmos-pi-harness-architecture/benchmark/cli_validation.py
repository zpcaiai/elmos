from dataclasses import dataclass, asdict
import subprocess, shutil, json

@dataclass
class CliValidation:
    system: str
    binary: str
    installed: bool
    version: str | None
    validated_flags: list[str]
    missing_flags: list[str]

def _run(cmd):
    try:
        p = subprocess.run(cmd, text=True, capture_output=True, timeout=15)
        return p.returncode, (p.stdout or p.stderr)
    except Exception as e:
        return 999, str(e)

def validate(system, binary, expected_flags):
    if shutil.which(binary) is None:
        return CliValidation(system, binary, False, None, [], list(expected_flags))
    _, version_text = _run([binary, "--version"])
    _, help_text = _run([binary, "--help"])
    validated = [f for f in expected_flags if help_text and f in help_text]
    missing = [f for f in expected_flags if f not in validated]
    version = version_text.strip().splitlines()[0] if version_text.strip() else None
    return CliValidation(system, binary, True, version, validated, missing)

DEFAULT_VALIDATIONS = [
    ("elmos","elmos",["run","--task","--json"]),
    ("pi","pi",["--model"]),
    ("codex","codex",["exec","--model"]),
    ("claude-code","claude",["-p","--model"]),
    ("opencode","opencode",["run","--model"]),
]

def validate_all():
    return [asdict(validate(*x)) for x in DEFAULT_VALIDATIONS]

if __name__ == "__main__":
    print(json.dumps(validate_all(), ensure_ascii=False, indent=2))
