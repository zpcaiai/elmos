import argparse, json, time
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", required=True)
    ap.add_argument("--system", action="append", required=True)
    ap.add_argument("--repetitions", type=int, default=3)
    ap.add_argument("--output", default="./benchmark-output")
    args = ap.parse_args()

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    manifest = {
        "suite": args.suite,
        "systems": args.system,
        "repetitions": args.repetitions,
        "status": "scaffold",
        "created_at": time.time()
    }
    (out / "run.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest))

if __name__ == "__main__":
    main()
