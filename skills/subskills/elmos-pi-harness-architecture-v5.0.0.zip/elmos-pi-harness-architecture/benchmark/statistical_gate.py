import math

def wilson(successes,n,z=1.96):
    if n==0: return None
    p=successes/n
    d=1+z*z/n
    center=(p+z*z/(2*n))/d
    margin=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/d
    return [center-margin,center+margin]

def summarize_success(rows):
    n=len(rows)
    s=sum(1 for r in rows if r.get("validated_success"))
    return {"n":n,"successes":s,"rate":s/n if n else None,"wilson95":wilson(s,n)}

def evidence_ready(rows,min_repetitions=5):
    if len(rows)<min_repetitions:
        return False,"insufficient_repetitions"
    if any(r.get("evidence_level") not in {"E4","E5","E6"} for r in rows):
        return False,"unverified_run"
    return True,"ready"
