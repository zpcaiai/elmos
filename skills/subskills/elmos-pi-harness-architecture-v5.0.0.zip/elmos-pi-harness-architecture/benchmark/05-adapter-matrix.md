# Harness Adapter Matrix

Adapters:
- Elmos native API/CLI
- Pi CLI
- Codex CLI/task runtime
- Claude Code CLI
- OpenCode CLI

Normalize where observable:
- timestamps
- exit status
- model/provider
- token/cost usage
- tool calls
- repository diff
- verification evidence
- manual interventions

Unavailable metrics must be marked unavailable; never invent them.
