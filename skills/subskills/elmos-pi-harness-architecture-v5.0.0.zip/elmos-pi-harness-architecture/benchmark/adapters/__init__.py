from .elmos import ElmosAdapter
from .pi import PiAdapter
from .codex import CodexAdapter
from .claude_code import ClaudeCodeAdapter
from .opencode import OpenCodeAdapter

ADAPTERS = {
    "elmos": ElmosAdapter,
    "pi": PiAdapter,
    "codex": CodexAdapter,
    "claude-code": ClaudeCodeAdapter,
    "opencode": OpenCodeAdapter,
}
