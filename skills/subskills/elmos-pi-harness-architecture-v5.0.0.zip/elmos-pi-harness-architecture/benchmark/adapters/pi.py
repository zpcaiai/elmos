from benchmark.adapter_base import HarnessAdapter, CapabilityProfile, RunConfig, command_version

class PiAdapter(HarnessAdapter):
    name = "pi"

    def discover(self):
        version = command_version(["pi", "--version"])
        return CapabilityProfile(
            system_name=self.name,
            version=version,
            supports_model_override=True,
            supports_noninteractive=True,
            supports_json_output=False,
            notes=["Exact CLI flags must be validated against installed Pi version before certification."]
        )

    def build_command(self, config: RunConfig):
        cmd = ["pi", config.task]
        if config.model:
            cmd += ["--model", config.model]
        return cmd
