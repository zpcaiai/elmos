from benchmark.adapter_base import HarnessAdapter,CapabilityProfile,RunConfig,command_version

class RealElmosAdapter(HarnessAdapter):
    name="elmos"

    def discover(self):
        version=command_version(["elmos","--version"])
        return CapabilityProfile(
          system_name="elmos",version=version,
          supports_model_override=True,
          supports_noninteractive=True,
          supports_json_output=True,
          supports_tool_policy=True,
          supports_token_metrics=True,
          supports_cost_metrics=True,
          notes=[] if version else ["elmos executable unavailable"]
        )

    def build_command(self,config:RunConfig):
        cmd=["elmos","run","--task",config.task,"--json"]
        if config.model: cmd+=["--model",config.model]
        if config.provider: cmd+=["--provider",config.provider]
        return cmd
