from benchmark.adapter_base import HarnessAdapter, CapabilityProfile, RunConfig, command_version

class CodexAdapter(HarnessAdapter):
    name = "codex"

    def discover(self):
        return CapabilityProfile(
            system_name=self.name,
            version=command_version(["codex", "--version"]),
            supports_model_override=True,
            supports_noninteractive=True,
            notes=["Adapter flags must be validated against the installed Codex CLI version."]
        )

    def build_command(self, config: RunConfig):
        cmd = ["codex", "exec", config.task]
        if config.model:
            cmd += ["--model", config.model]
        return cmd
