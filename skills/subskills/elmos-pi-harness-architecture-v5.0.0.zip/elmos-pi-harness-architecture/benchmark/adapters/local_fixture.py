import time
from pathlib import Path
from benchmark.adapter_base import HarnessAdapter,CapabilityProfile,HarnessRunResult

class LocalFixtureAdapter(HarnessAdapter):
    name="local-fixture"

    def discover(self):
        return CapabilityProfile(
          system_name=self.name,version="1.0.0",
          supports_noninteractive=True,supports_json_output=True)

    def build_command(self,config):
        return []

    def run(self,config,output_dir):
        started=time.perf_counter()
        p=Path(config.repo_path)/"calculator.py"
        p.write_text("def add(a,b):\n    return a+b\n",encoding="utf-8")
        return HarnessRunResult(
          validated_success=False,
          wall_clock_ms=int((time.perf_counter()-started)*1000),
          input_tokens=0,output_tokens=0,cached_tokens=0,cost_usd=0.0,
          tool_calls=1,repair_loops=0,evidence={"fixture":True})
