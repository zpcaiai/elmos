# Real Elmos E4 Handoff Gate
1. exact `elmos` version resolves
2. noninteractive invocation validated
3. model/provider captured
4. isolated Git worktree
5. stdout/stderr/diff retained
6. manual intervention explicit
7. deterministic verifier owns validated_success
8. evidence manifest hashed
9. Campaign/Job/Run lineage persisted
