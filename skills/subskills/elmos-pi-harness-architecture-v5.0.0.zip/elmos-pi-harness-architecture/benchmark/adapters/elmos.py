from benchmark.adapter_base import HarnessAdapter, CapabilityProfile, RunConfig, command_version

class ElmosAdapter(HarnessAdapter):
    name = "elmos"

    def discover(self):
        return CapabilityProfile(
            system_name=self.name,
            version=command_version(["elmos", "--version"]),
            supports_model_override=True,
            supports_noninteractive=True,
            supports_json_output=True,
            supports_tool_policy=True,
            supports_token_metrics=True,
            supports_cost_metrics=True,
        )

    def build_command(self, config: RunConfig):
        cmd = ["elmos", "run", "--task", config.task, "--json"]
        if config.model:
            cmd += ["--model", config.model]
        if config.provider:
            cmd += ["--provider", config.provider]
        return cmd
