from benchmark.adapter_base import HarnessAdapter, CapabilityProfile, RunConfig, command_version

class OpenCodeAdapter(HarnessAdapter):
    name = "opencode"

    def discover(self):
        return CapabilityProfile(
            system_name=self.name,
            version=command_version(["opencode", "--version"]),
            supports_model_override=True,
            supports_noninteractive=True,
            notes=["Adapter flags must be validated against the installed OpenCode version."]
        )

    def build_command(self, config: RunConfig):
        cmd = ["opencode", "run", config.task]
        if config.model:
            cmd += ["--model", config.model]
        return cmd
