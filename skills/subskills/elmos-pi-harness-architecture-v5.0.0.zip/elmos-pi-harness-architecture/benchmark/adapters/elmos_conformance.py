REQUIRED_FIELDS={"system","version","revision","task","wall_clock_ms","stdout_path","stderr_path","manual_interventions","metadata"}

def validate_normalized_run(run):
    data=run.__dict__ if hasattr(run,"__dict__") else dict(run)
    missing=sorted(k for k in REQUIRED_FIELDS if k not in data)
    errors=[]
    if data.get("system")!="elmos": errors.append("system_must_be_elmos")
    if not data.get("version"): errors.append("missing_version")
    if data.get("manual_interventions") is None: errors.append("manual_interventions_must_be_explicit")
    return {"valid":not missing and not errors,"missing":missing,"errors":errors}
