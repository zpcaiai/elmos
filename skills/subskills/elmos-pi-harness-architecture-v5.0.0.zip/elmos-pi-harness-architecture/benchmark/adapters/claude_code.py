from benchmark.adapter_base import HarnessAdapter, CapabilityProfile, RunConfig, command_version

class ClaudeCodeAdapter(HarnessAdapter):
    name = "claude-code"

    def discover(self):
        return CapabilityProfile(
            system_name=self.name,
            version=command_version(["claude", "--version"]),
            supports_model_override=True,
            supports_noninteractive=True,
            notes=["Adapter flags must be validated against the installed Claude Code version."]
        )

    def build_command(self, config: RunConfig):
        cmd = ["claude", "-p", config.task]
        if config.model:
            cmd += ["--model", config.model]
        return cmd
