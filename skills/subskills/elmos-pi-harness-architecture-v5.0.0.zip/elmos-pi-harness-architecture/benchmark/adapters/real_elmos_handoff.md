# Real Elmos Adapter Handoff

Replace the local fixture only after persistent E4 plumbing is green.

The real adapter must expose exact version/model/provider, run ID, wall-clock,
stdout/stderr, diff, token/cost metrics where observable, tool calls and manual interventions.
Deterministic verification—not the adapter—owns `validated_success`.
