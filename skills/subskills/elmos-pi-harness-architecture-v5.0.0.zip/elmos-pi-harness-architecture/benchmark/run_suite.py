from __future__ import annotations
from pathlib import Path
import json, uuid
from benchmark.adapters import ADAPTERS
from benchmark.adapter_base import RunConfig
from benchmark.environment_fingerprint import fingerprint

def run_case(system, repo_path, revision, task, output_root, repetition=0, model=None, provider=None):
    adapter = ADAPTERS[system]()
    run_id = str(uuid.uuid4())
    out = Path(output_root) / run_id
    config = RunConfig(
        repo_path=repo_path,
        revision=revision,
        task=task,
        model=model,
        provider=provider,
    )
    result = adapter.run(config, out)
    record = {
        "run_id": run_id,
        "repetition": repetition,
        "environment": fingerprint(),
        **result.__dict__,
    }
    (out / "normalized.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    return record
