from benchmark.elmos_preflight import preflight

def evaluate(repo_revision=None, model=None, provider=None):
    pf=preflight()
    blockers=[]
    if not pf.get("installed"):
        blockers.append("elmos_executable_not_found")
    if not pf.get("eligible_real_e4"):
        blockers.append("cli_contract_not_validated")
    if not repo_revision:
        blockers.append("missing_pinned_repo_revision")
    if not model:
        blockers.append("missing_model")
    if not provider:
        blockers.append("missing_provider")
    return {
        "eligible": not blockers,
        "blockers": sorted(set(blockers)),
        "preflight": pf,
        "repo_revision": repo_revision,
        "model": model,
        "provider": provider
    }
