REQUIRED_EQUIVALENCE_FIELDS=[
  "system","system_version","repo_revision","task_case","model","provider",
  "suite_version","verifier_pack_version"
]

def validate_group(records):
    if not records:
        return {"valid":False,"reason":"empty_group"}
    baseline={k:records[0].get(k) for k in REQUIRED_EQUIVALENCE_FIELDS}
    mismatches=[]
    for i,r in enumerate(records[1:],start=1):
        for k,v in baseline.items():
            if r.get(k)!=v:
                mismatches.append({"index":i,"field":k,"expected":v,"actual":r.get(k)})
    return {"valid":not mismatches,"baseline":baseline,"mismatches":mismatches}
