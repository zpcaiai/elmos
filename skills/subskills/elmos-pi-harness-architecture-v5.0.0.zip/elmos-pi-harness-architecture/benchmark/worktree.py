from pathlib import Path
import subprocess, uuid, shutil

def run(cmd,cwd=None):
    p=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True)
    if p.returncode:
        raise RuntimeError(p.stderr or p.stdout)
    return p.stdout.strip()

class BenchmarkWorktree:
    def __init__(self, repo:Path, revision:str, root:Path):
        self.repo=repo; self.revision=revision; self.root=root
        self.id=str(uuid.uuid4())
        self.path=root/self.id

    def create(self):
        self.root.mkdir(parents=True,exist_ok=True)
        run(["git","worktree","add","--detach",str(self.path),self.revision],cwd=self.repo)
        return self.path

    def cleanup(self):
        try:
            run(["git","worktree","remove","--force",str(self.path)],cwd=self.repo)
        except Exception:
            shutil.rmtree(self.path,ignore_errors=True)
