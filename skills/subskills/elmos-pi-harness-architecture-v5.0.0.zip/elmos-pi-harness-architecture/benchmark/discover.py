import json
from dataclasses import asdict
from benchmark.adapters import ADAPTERS

def discover_all():
    result = {}
    for name, cls in ADAPTERS.items():
        try:
            result[name] = asdict(cls().discover())
        except Exception as e:
            result[name] = {"system_name": name, "error": str(e)}
    return result

if __name__ == "__main__":
    print(json.dumps(discover_all(), ensure_ascii=False, indent=2))
