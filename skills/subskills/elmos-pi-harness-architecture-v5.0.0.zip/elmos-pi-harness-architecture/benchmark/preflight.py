from dataclasses import asdict
from benchmark.cli_validation import validate_all

def preflight():
    rows=validate_all()
    eligible_native=[]
    eligible_matched=[]
    for r in rows:
        if not r["installed"]:
            continue
        eligible_native.append(r["system"])
        if "--model" in r["validated_flags"] or r["system"]=="elmos":
            eligible_matched.append(r["system"])
    return {
      "validations":rows,
      "eligible_native":eligible_native,
      "eligible_matched_model":eligible_matched
    }

if __name__=="__main__":
    import json
    print(json.dumps(preflight(),ensure_ascii=False,indent=2))
