import shutil,subprocess,json

def preflight():
    binary=shutil.which("elmos")
    result={"installed":bool(binary),"binary":binary,"version":None,"help":None}
    if not binary:
        result["eligible_real_e4"]=False
        result["reason"]="elmos_executable_not_found"
        return result
    for flag,cmd in [("version",[binary,"--version"]),("help",[binary,"--help"])]:
        p=subprocess.run(cmd,text=True,capture_output=True,timeout=15)
        result[flag]=(p.stdout or p.stderr).strip()[:20000]
    help_text=result["help"] or ""
    required=["run","--task","--json"]
    result["required_flags"]={x:(x in help_text) for x in required}
    result["eligible_real_e4"]=all(result["required_flags"].values())
    if not result["eligible_real_e4"]:
        result["reason"]="required_cli_contract_not_validated"
    return result

if __name__=="__main__":
    print(json.dumps(preflight(),indent=2))
