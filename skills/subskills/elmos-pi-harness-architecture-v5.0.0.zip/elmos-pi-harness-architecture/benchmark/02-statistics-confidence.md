# Benchmark Statistics & Confidence

Repeated benchmark reports should include mean, median, dispersion, confidence interval,
run count and failure count.

Prefer paired comparisons for same task/revision across systems.

Do not claim superiority from tiny samples.
Every dashboard statistic must link to raw benchmark run IDs.
