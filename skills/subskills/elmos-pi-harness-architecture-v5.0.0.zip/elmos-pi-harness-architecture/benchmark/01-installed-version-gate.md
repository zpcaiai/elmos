# Installed Version / Flag Validation Gate

Before competitive execution:
- binary present
- exact version captured
- `--help` captured
- noninteractive invocation verified
- model-override flag verified for matched-model mode

If a common model cannot be selected, exclude that product from matched-model ranking and keep it in native-product reporting.
