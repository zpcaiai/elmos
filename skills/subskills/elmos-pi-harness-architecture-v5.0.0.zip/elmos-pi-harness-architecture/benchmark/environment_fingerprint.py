import platform, os, json, hashlib, subprocess

def _cmd(cmd):
    try:
        p = subprocess.run(cmd, text=True, capture_output=True, timeout=10)
        return (p.stdout or p.stderr).strip()
    except Exception:
        return None

def fingerprint():
    data = {
        "platform": platform.platform(),
        "python": platform.python_version(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
        "docker": _cmd(["docker", "--version"]),
        "git": _cmd(["git", "--version"]),
    }
    data["fingerprint_sha256"] = hashlib.sha256(
        json.dumps(data, sort_keys=True).encode()
    ).hexdigest()
    return data
