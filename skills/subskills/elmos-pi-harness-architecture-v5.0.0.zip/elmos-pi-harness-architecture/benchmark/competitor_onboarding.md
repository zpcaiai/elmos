# Competitor Adapter Onboarding Readiness

After first real Elmos E5:

Onboard Pi / Codex / Claude Code / OpenCode one at a time.

For each:
- exact executable/version
- noninteractive mode
- model override support
- repository isolation
- stdout/stderr retention
- diff retention
- metrics availability
- deterministic verifier compatibility
- manual intervention count
- evidence manifest

Matched-model comparison only includes systems that truly support the selected common model.
