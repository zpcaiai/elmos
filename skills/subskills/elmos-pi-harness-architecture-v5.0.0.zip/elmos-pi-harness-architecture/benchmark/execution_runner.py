from pathlib import Path
import json, uuid, time, subprocess
from benchmark.adapters import ADAPTERS
from benchmark.adapter_base import RunConfig
from benchmark.worktree import BenchmarkWorktree
from benchmark.verifier import verify
from benchmark.evidence_manifest import build as build_manifest
from benchmark.environment_fingerprint import fingerprint

def git_diff(path):
    p=subprocess.run(["git","diff","--binary"],cwd=path,text=True,capture_output=True)
    return p.stdout

def execute_case(system,repo,revision,task,gates,output_root,repetition=0,model=None,provider=None):
    run_id=str(uuid.uuid4())
    out=Path(output_root)/run_id
    out.mkdir(parents=True,exist_ok=True)

    wt=BenchmarkWorktree(Path(repo),revision,Path(output_root)/"_worktrees")
    worktree=wt.create()
    started=time.perf_counter()

    try:
        adapter=ADAPTERS[system]()
        result=adapter.run(
            RunConfig(
              repo_path=str(worktree),revision=revision,task=task,
              model=model,provider=provider
            ),
            out
        )
        (out/"diff.patch").write_text(git_diff(worktree),encoding="utf-8")
        verification=verify(worktree,gates)
        record={
          "run_id":run_id,
          "system":system,
          "system_version":result.version,
          "repo_revision":revision,
          "task_case":task,
          "repetition":repetition,
          "validated_success":bool(verification["passed"] and not result.timed_out),
          "wall_clock_ms":int((time.perf_counter()-started)*1000),
          "harness_wall_clock_ms":result.wall_clock_ms,
          "input_tokens":result.input_tokens,
          "output_tokens":result.output_tokens,
          "cached_tokens":result.cached_tokens,
          "cost_usd":result.cost_usd,
          "tool_calls":result.tool_calls,
          "manual_interventions":result.manual_interventions,
          "verification":verification,
          "environment":fingerprint(),
          "evidence_level":"E4"
        }
        (out/"result.json").write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8")
        build_manifest(out)
        return record
    finally:
        wt.cleanup()
