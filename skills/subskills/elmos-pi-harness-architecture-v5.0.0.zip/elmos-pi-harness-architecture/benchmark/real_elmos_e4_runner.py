from pathlib import Path
import json
from benchmark.elmos_preflight import preflight
from benchmark.execution_runner import execute_case

def run_real_elmos(repo,revision,task,gates,output_root,model=None,provider=None):
    pf=preflight()
    if not pf.get("eligible_real_e4"):
        return {"status":"BLOCKED","preflight":pf}
    record=execute_case(
      system="elmos",repo=repo,revision=revision,task=task,gates=gates,
      output_root=output_root,repetition=0,model=model,provider=provider)
    return {"status":"EXECUTED","preflight":pf,"record":record}
