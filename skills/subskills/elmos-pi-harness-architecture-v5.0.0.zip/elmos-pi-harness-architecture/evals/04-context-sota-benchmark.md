# Context SOTA Benchmark

## Compare strategies
A. full repository / brute context
B. lexical only
C. embedding only
D. lexical + embedding
E. lexical + embedding + graph
F. E + learned reranker + budget optimizer + cache optimizer

## Primary KPI
Cost per successful repository task.

## Secondary KPIs
- success rate
- token count
- cache hit ratio
- repair loops
- wall-clock runtime
- impacted-symbol recall
- impacted-test recall
- false-positive context ratio

## Promotion rule
A new context strategy becomes default only if it improves cost per successful task without
statistically meaningful quality regression on large-repository benchmarks.
