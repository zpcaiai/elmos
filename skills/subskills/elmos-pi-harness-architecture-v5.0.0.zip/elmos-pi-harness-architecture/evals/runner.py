from __future__ import annotations
from dataclasses import dataclass, asdict
import time, json

@dataclass
class BenchmarkResult:
    name: str
    success: bool
    wall_clock_ms: int
    input_tokens: int = 0
    output_tokens: int = 0
    cached_tokens: int = 0
    cost_usd: float = 0.0
    repair_loops: int = 0

def run_case(name, fn):
    started=time.perf_counter()
    try:
        meta=fn() or {}
        success=True
    except Exception as e:
        meta={"error":str(e)}
        success=False
    result=BenchmarkResult(
        name=name,
        success=success,
        wall_clock_ms=int((time.perf_counter()-started)*1000),
        input_tokens=int(meta.get("input_tokens",0)),
        output_tokens=int(meta.get("output_tokens",0)),
        cached_tokens=int(meta.get("cached_tokens",0)),
        cost_usd=float(meta.get("cost_usd",0)),
        repair_loops=int(meta.get("repair_loops",0)),
    )
    return result
