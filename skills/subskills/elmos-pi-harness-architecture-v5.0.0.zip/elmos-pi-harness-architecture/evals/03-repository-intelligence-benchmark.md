# Repository Intelligence Benchmark

Compare:
- full-repo prompting
- lexical-only retrieval
- embedding-only retrieval
- hybrid graph-aware retrieval

Metrics:
- task success
- context tokens per success
- redundant-context ratio
- symbol recall@k
- impacted-file recall
- prompt-cache hit ratio
- repair-loop count
- indexing throughput
- p95 context build latency

Dataset:
- >=3 repositories >500k LOC
- >=1 repository >1M LOC
