# Compiler-Grade Semantic Benchmark

Compare heuristic graph vs compiler/language-service enriched graph.

Measure:
- symbol resolution accuracy
- call-target precision/recall
- impacted-file recall
- impacted-test recall
- context token reduction
- verification wall-clock reduction
- task success
- regression escape rate

Promotion criteria:
- no increase in regression escape rate,
- better impact recall,
- lower context or verification cost,
- acceptable indexing/resolution latency.
