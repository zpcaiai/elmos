# Distributed Benchmark Scheduler
run → repository → task case → repetition → shard

Requirements:
- deterministic IDs
- revision pinning
- resumable shards
- worker lease/heartbeat
- bounded concurrency
- per-system isolation
- raw artifact retention
- incomplete runs remain visible

Production implementation should reuse Elmos durable TaskRuntime/Temporal.
