# Benchmark Suite

Never claim SOTA from demos; benchmark the whole harness.

Public baselines: SWE-bench, Terminal-Bench, language compile/test tasks, frontend tasks, migrations, dependency upgrades.

## ELMOS-LARGE-REPO
Minimum 3 repos >500k LOC and at least 1 >1M LOC. Measure success, regression, wall-clock, token cost, retries, context efficiency, recovery, human intervention.

## ELMOS-RECOVERY
Inject worker kill, service restart, network interruption, provider timeout, partial artifact upload and DB failover.

## ELMOS-SECURITY
Prompt injection, malicious repo instructions, secret exfiltration, package poisoning, destructive shell.

GA gates: >95% resume success after injected failures; zero cross-tenant leakage; deterministic billing reconciliation; reproducible audit; <2% benchmark regression between releases; all critical security tests pass.
