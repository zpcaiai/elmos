from pathlib import Path
import json, statistics

def aggregate(root: Path):
    rows=[json.loads(p.read_text()) for p in root.glob("*.json")]
    completed=[r for r in rows if r.get("status")=="completed"]
    runtimes=[r.get("wall_clock_ms",0) for r in completed]
    return {
        "total_shards":len(rows),
        "completed_shards":len(completed),
        "failed_shards":len(rows)-len(completed),
        "success_rate":len(completed)/max(len(rows),1),
        "runtime_p50_ms":statistics.median(runtimes) if runtimes else None,
        "runtime_max_ms":max(runtimes) if runtimes else None
    }
