# Performance KPIs

Quality: task success, compile pass, test pass, regression-free rate, reviewer acceptance, migration equivalence.
Context: useful-context ratio, context hit, prompt-cache hit, tokens/success, redundant-read ratio.
Execution: p50/p95 wall-clock, tool latency, recovery time, retry amplification, parallel efficiency.
Cost: cost/success, cost/KLOC changed, frontier-model share, cache savings.
Reliability: crash recovery, duplicate side effects, checkpoint age, reconnect completion.
Commercial: gross margin/task, ARR expansion, paid Golden Route conversion, SLA attainment.
