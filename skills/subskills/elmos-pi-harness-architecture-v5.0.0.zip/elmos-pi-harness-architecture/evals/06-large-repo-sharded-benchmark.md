# Large Repository Sharded Benchmark

Dataset floor:
- >=3 repositories over 500k LOC
- >=1 repository over 1M LOC

Properties:
- stable shard IDs
- revision pinning
- resumable execution
- per-shard cost/token/runtime
- aggregate success/failure accounting
- injected worker failure recovery

Primary KPI: cost per successful validated repository task.
