# Performance Regression Gates

Compare against pinned baseline.

Block promotion when:
- validated success materially regresses
- regression escape rate increases
- p95 wall-clock exceeds allowed threshold
- cost/success materially worsens
- cache correctness violation occurs
- recovery reliability regresses

Performance improvements must be measured over repeated representative tasks.
