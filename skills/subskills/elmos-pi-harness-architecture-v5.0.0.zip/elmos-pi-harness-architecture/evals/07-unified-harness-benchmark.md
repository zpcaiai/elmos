# Unified Harness Benchmark

Compare Elmos, Pi, Claude Code, Codex and OpenCode.

Where technically possible hold constant:
- model
- repository revision
- task
- tool permissions
- network access
- token/cost budget
- wall-clock limit
- compute
- repetitions

If identical configuration is impossible, report product-level results separately.

Metrics:
- validated task success
- regression-free success
- input/output/cached tokens
- machine wall-clock
- tool calls
- repair loops
- cost per successful task
- crash/resume success
- context tokens
- symbol/impact recall
- impacted-test recall

Never reduce results to an unexplained Tier List. Preserve raw configuration and run evidence.
