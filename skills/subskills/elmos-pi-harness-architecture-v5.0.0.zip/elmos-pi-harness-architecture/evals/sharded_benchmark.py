from dataclasses import dataclass, asdict
from pathlib import Path
import json, time

@dataclass
class Shard:
    id: str
    repo: str
    revision: str
    task_file: str
    start: int
    end: int

class ShardStore:
    def __init__(self, root: Path):
        self.root=root
        root.mkdir(parents=True,exist_ok=True)

    def path(self, shard_id):
        return self.root/f"{shard_id}.json"

    def load(self, shard_id):
        p=self.path(shard_id)
        return json.loads(p.read_text()) if p.exists() else None

    def save(self, shard_id, payload):
        self.path(shard_id).write_text(json.dumps(payload,indent=2),encoding="utf-8")

def run_shard(shard, fn, store):
    old=store.load(shard.id)
    if old and old.get("status")=="completed":
        return old

    started=time.perf_counter()
    try:
        result=fn(shard)
        payload={
            "status":"completed","shard":asdict(shard),
            "wall_clock_ms":int((time.perf_counter()-started)*1000),
            "result":result
        }
    except Exception as e:
        payload={
            "status":"failed","shard":asdict(shard),
            "wall_clock_ms":int((time.perf_counter()-started)*1000),
            "error":str(e)
        }
    store.save(shard.id,payload)
    return payload
