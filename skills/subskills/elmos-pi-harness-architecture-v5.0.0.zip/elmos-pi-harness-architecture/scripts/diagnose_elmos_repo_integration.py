from pathlib import Path
import argparse, json, importlib.util

REQUIRED=[
  "elmos_runtime/runtime_port.py",
  "elmos_runtime/config.py",
  "elmos_runtime/http_service.py",
  "elmos_runtime/cli_shim.py",
  "elmos_runtime/synthetic_gate.py",
  "elmos_runtime/self_test.py"
]

def diagnose(host_repo: Path):
    checks={}
    for rel in REQUIRED:
        checks[rel]=(host_repo/rel).exists()

    host_binding=host_repo/"elmos_runtime/host_engine_binding.py"
    checks["host_engine_binding"]=host_binding.exists()

    env_doc=host_repo/"elmos_runtime/README.md"
    checks["runtime_docs"]=env_doc.exists()

    blockers=[k for k,v in checks.items() if not v]
    return {"ready":not blockers,"checks":checks,"blockers":blockers}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--host-repo",required=True)
    args=ap.parse_args()
    result=diagnose(Path(args.host_repo))
    print(json.dumps(result,indent=2))
    raise SystemExit(0 if result["ready"] else 2)

if __name__=="__main__":
    main()
