from __future__ import annotations
from pathlib import Path
import argparse, json, subprocess, hashlib, uuid, time

def git_head(repo: Path):
    p=subprocess.run(["git","rev-parse","HEAD"],cwd=repo,text=True,capture_output=True)
    return p.stdout.strip() if p.returncode==0 else None

def run():
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo",required=True)
    ap.add_argument("--revision",required=True)
    ap.add_argument("--task-case",required=True)
    ap.add_argument("--task",required=True)
    ap.add_argument("--verifier-command",nargs="+",required=True)
    ap.add_argument("--output-root",default=".elmos-evidence")
    args=ap.parse_args()

    repo=Path(args.repo)
    blockers=[]
    actual=git_head(repo)
    if actual!=args.revision:
        blockers.append("revision_mismatch")

    bootstrap=subprocess.run(
      ["python",str(Path(__file__).with_name("elmos_runtime_bootstrap.py"))],
      text=True,capture_output=True)
    try:
        runtime=json.loads(bootstrap.stdout)
    except Exception:
        runtime={"ok":False,"reason":"bootstrap_invalid"}

    if not runtime.get("ok"):
        blockers.append("runtime_not_ready")

    if blockers:
        print(json.dumps({"status":"BLOCKED","blockers":blockers,"runtime":runtime,
                          "actual_revision":actual},indent=2))
        return 2

    run_id=str(uuid.uuid4())
    out=Path(args.output_root)/run_id
    out.mkdir(parents=True,exist_ok=True)

    # Runtime invocation is intentionally delegated to the installed Elmos CLI contract.
    cmd=["elmos","run","--task",args.task,"--json"]
    started=time.perf_counter()
    p=subprocess.run(cmd,cwd=repo,text=True,capture_output=True)
    wall_ms=int((time.perf_counter()-started)*1000)

    (out/"stdout.txt").write_text(p.stdout,encoding="utf-8")
    (out/"stderr.txt").write_text(p.stderr,encoding="utf-8")

    verify=subprocess.run(args.verifier_command,cwd=repo,text=True,capture_output=True)
    verification={
      "passed":verify.returncode==0,
      "returncode":verify.returncode,
      "stdout":verify.stdout,
      "stderr":verify.stderr
    }
    (out/"verification.json").write_text(json.dumps(verification,indent=2),encoding="utf-8")

    record={
      "run_id":run_id,"status":"EXECUTED","system":"elmos",
      "repo_revision":args.revision,"task_case":args.task_case,
      "wall_clock_ms":wall_ms,"runtime_exit_code":p.returncode,
      "verification":verification,
      "validated_success":verification["passed"],
      "evidence_level":"E4"
    }
    (out/"run.json").write_text(json.dumps(record,indent=2),encoding="utf-8")

    print(json.dumps(record,indent=2))
    return 0

if __name__=="__main__":
    raise SystemExit(run())
