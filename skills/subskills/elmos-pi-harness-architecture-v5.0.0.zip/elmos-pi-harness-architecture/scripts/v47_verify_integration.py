from pathlib import Path
import argparse, json, subprocess

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--host-repo",required=True)
    args=ap.parse_args()
    host=Path(args.host_repo)

    checks={}

    diag=subprocess.run(
        ["python",str(Path(__file__).with_name("diagnose_elmos_repo_integration.py")),
         "--host-repo",str(host)],
        text=True,capture_output=True
    )
    checks["integration_files"]=diag.returncode==0

    bind=subprocess.run(
        ["python",str(Path(__file__).with_name("verify_host_engine_binding.py")),
         "--host-repo",str(host)],
        text=True,capture_output=True
    )
    checks["host_binding"]=bind.returncode==0

    result={"ready":all(checks.values()),"checks":checks}
    print(json.dumps(result,indent=2))
    raise SystemExit(0 if result["ready"] else 2)

if __name__=="__main__":
    main()
