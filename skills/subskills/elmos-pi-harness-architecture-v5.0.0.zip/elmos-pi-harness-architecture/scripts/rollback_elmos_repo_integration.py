from pathlib import Path
import argparse, json, shutil

def rollback(host_repo: Path):
    receipt_path=host_repo/".elmos-integration-receipt.json"
    if not receipt_path.exists():
        raise RuntimeError("integration receipt not found")

    receipt=json.loads(receipt_path.read_text(encoding="utf-8"))
    backup_root=Path(receipt["backup_root"]) if receipt.get("backup_root") else None

    for op in reversed(receipt["operations"]):
        dst=Path(op["target"])
        if op["action"]=="create":
            if dst.exists():
                dst.unlink()
        elif op["action"]=="replace":
            backup=backup_root/Path(op["target"]).relative_to(host_repo)
            if not backup.exists():
                raise RuntimeError(f"missing backup: {backup}")
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(backup,dst)

    return {"rolled_back":True,"host_repo":str(host_repo)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--host-repo",required=True)
    args=ap.parse_args()
    print(json.dumps(rollback(Path(args.host_repo)),indent=2))

if __name__=="__main__":
    main()
