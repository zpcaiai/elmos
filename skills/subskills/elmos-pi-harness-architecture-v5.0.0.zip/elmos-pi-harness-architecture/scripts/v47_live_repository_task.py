from __future__ import annotations
from pathlib import Path
import argparse, subprocess, json, uuid, time, hashlib, os

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def git_head(repo):
    p = subprocess.run(["git","rev-parse","HEAD"], cwd=repo, text=True, capture_output=True)
    return p.stdout.strip() if p.returncode == 0 else None

def git_diff(repo):
    p = subprocess.run(["git","diff","--binary"], cwd=repo, text=True, capture_output=True)
    return p.stdout

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--revision", required=True)
    ap.add_argument("--task-case", required=True)
    ap.add_argument("--task", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--provider", required=True)
    ap.add_argument("--verifier-command", nargs="+", required=True)
    ap.add_argument("--output-root", default=".elmos-evidence")
    args = ap.parse_args()

    repo = Path(args.repo)
    actual_revision = git_head(repo)
    blockers = []
    if actual_revision != args.revision:
        blockers.append("revision_mismatch")

    runtime = subprocess.run(
        ["python", str(Path(__file__).with_name("elmos_runtime_bootstrap.py"))],
        text=True, capture_output=True
    )
    try:
        runtime_status = json.loads(runtime.stdout)
    except Exception:
        runtime_status = {"ok": False, "reason": "runtime_bootstrap_invalid"}

    if not runtime_status.get("ok"):
        blockers.append("runtime_not_ready")

    if blockers:
        print(json.dumps({
            "status": "BLOCKED",
            "blockers": blockers,
            "runtime": runtime_status,
            "actual_revision": actual_revision
        }, ensure_ascii=False, indent=2))
        return 2

    run_id = str(uuid.uuid4())
    out = Path(args.output_root) / run_id
    out.mkdir(parents=True, exist_ok=True)

    cmd = [
        "elmos","run",
        "--task", args.task,
        "--json",
        "--model", args.model,
        "--provider", args.provider
    ]

    started = time.perf_counter()
    p = subprocess.run(cmd, cwd=repo, text=True, capture_output=True)
    wall_ms = int((time.perf_counter()-started)*1000)

    (out/"stdout.txt").write_text(p.stdout, encoding="utf-8")
    (out/"stderr.txt").write_text(p.stderr, encoding="utf-8")
    (out/"diff.patch").write_text(git_diff(repo), encoding="utf-8")

    verifier = subprocess.run(args.verifier_command, cwd=repo, text=True, capture_output=True)
    verification = {
        "passed": verifier.returncode == 0,
        "returncode": verifier.returncode,
        "stdout": verifier.stdout,
        "stderr": verifier.stderr
    }
    (out/"verification.json").write_text(
        json.dumps(verification, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    record = {
        "run_id": run_id,
        "status": "EXECUTED",
        "system": "elmos",
        "model": args.model,
        "provider": args.provider,
        "repo_revision": args.revision,
        "task_case": args.task_case,
        "wall_clock_ms": wall_ms,
        "runtime_exit_code": p.returncode,
        "validated_success": verification["passed"],
        "verification": verification,
        "manual_interventions": 0,
        "evidence_level": "E4"
    }
    (out/"run.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")

    files = []
    for name in ["stdout.txt","stderr.txt","diff.patch","verification.json","run.json"]:
        fp = out/name
        files.append({
            "path": name,
            "sha256": sha256_file(fp),
            "bytes": fp.stat().st_size
        })

    manifest = {"run_id": run_id, "files": files}
    manifest_raw = json.dumps(manifest, sort_keys=True, ensure_ascii=False).encode()
    manifest["sha256"] = hashlib.sha256(manifest_raw).hexdigest()
    (out/"manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps({
        "status":"EXECUTED",
        "run_id":run_id,
        "validated_success":verification["passed"],
        "evidence_level":"E4",
        "manifest_sha256":manifest["sha256"],
        "output_dir":str(out)
    }, ensure_ascii=False, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
