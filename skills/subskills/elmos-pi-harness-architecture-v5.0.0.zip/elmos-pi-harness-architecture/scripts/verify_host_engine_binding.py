from pathlib import Path
import argparse, json, ast

def verify(host_repo: Path):
    path = host_repo / "elmos_runtime/host_engine_binding.py"
    if not path.exists():
        return {"valid": False, "blockers": ["host_engine_binding_missing"]}

    text = path.read_text(encoding="utf-8")
    blockers = []

    if "raise HostBindingError" in text and "resolve_host_engine" in text:
        blockers.append("binding_still_placeholder")

    if "mock" in text.lower() and "production benchmark mode" not in text.lower():
        blockers.append("possible_mock_binding")

    try:
        ast.parse(text)
    except SyntaxError as e:
        blockers.append(f"syntax_error:{e}")

    return {"valid": not blockers, "blockers": blockers, "path": str(path)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host-repo", required=True)
    args = ap.parse_args()
    result = verify(Path(args.host_repo))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["valid"] else 2)

if __name__ == "__main__":
    main()
