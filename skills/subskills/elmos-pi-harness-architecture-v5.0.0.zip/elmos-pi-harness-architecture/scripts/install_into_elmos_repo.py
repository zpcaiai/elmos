from __future__ import annotations
from pathlib import Path
import argparse, json, shutil, hashlib, time

def sha256(path: Path):
    h=hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()

def install(package_root: Path, host_repo: Path, dry_run=False):
    patch_dir=package_root/"integration/elmos-main-repo-patch"
    manifest=json.loads((patch_dir/"integration_manifest.json").read_text(encoding="utf-8"))

    if not (host_repo/".git").exists():
        raise RuntimeError("host repo must be a Git repository")

    operations=[]
    backup_root=host_repo/".elmos-integration-backup"/str(int(time.time()))

    for item in manifest["files"]:
        src=patch_dir/item["source"]
        dst=host_repo/item["target"]
        op={"source":str(src),"target":str(dst),"source_sha256":sha256(src),"action":"create"}

        if dst.exists():
            op["action"]="replace"
            op["original_sha256"]=sha256(dst)

        operations.append(op)

        if dry_run:
            continue

        if dst.exists():
            backup=backup_root/item["target"]
            backup.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(dst,backup)

        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,dst)

    receipt={
        "manifest_version":manifest["version"],
        "host_repo":str(host_repo.resolve()),
        "dry_run":dry_run,
        "operations":operations,
        "backup_root":str(backup_root) if not dry_run else None
    }

    receipt_path=host_repo/".elmos-integration-receipt.json"
    if not dry_run:
        receipt_path.write_text(json.dumps(receipt,indent=2),encoding="utf-8")

    return receipt

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--host-repo",required=True)
    ap.add_argument("--dry-run",action="store_true")
    args=ap.parse_args()

    package_root=Path(__file__).resolve().parents[1]
    result=install(package_root,Path(args.host_repo),args.dry_run)
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()
