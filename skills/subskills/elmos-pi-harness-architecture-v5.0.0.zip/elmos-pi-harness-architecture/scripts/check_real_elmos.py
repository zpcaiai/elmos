import json
from benchmark.elmos_preflight import preflight

if __name__=="__main__":
    result=preflight()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result.get("eligible_real_e4") else 2)
