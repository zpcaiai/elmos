import argparse, json
from campaigns.e5_batch_operator import plan

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--campaign-id", required=True)
    ap.add_argument("--system-version", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--provider", required=True)
    ap.add_argument("--repo-revision", required=True)
    ap.add_argument("--task-case", required=True)
    ap.add_argument("--repetitions", type=int, default=5)
    args = ap.parse_args()

    frozen = {
        "system_version": args.system_version,
        "model": args.model,
        "provider": args.provider,
        "repo_revision": args.repo_revision,
        "task_case": args.task_case
    }
    print(json.dumps(plan(args.campaign_id, frozen, args.repetitions), ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
