import argparse,json,subprocess
from pathlib import Path

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo",required=True)
    ap.add_argument("--revision",required=True)
    ap.add_argument("--task-case",required=True)
    ap.add_argument("--task",required=True)
    ap.add_argument("--verifier-pack",required=True)
    args=ap.parse_args()

    repo=Path(args.repo)
    p=subprocess.run(["git","rev-parse","HEAD"],cwd=repo,text=True,capture_output=True)
    actual=p.stdout.strip() if p.returncode==0 else None
    blockers=[]
    if actual!=args.revision: blockers.append("revision_mismatch")

    runtime=subprocess.run(
      ["python","scripts/elmos_runtime_bootstrap.py"],
      text=True,capture_output=True)
    try: runtime_status=json.loads(runtime.stdout)
    except Exception: runtime_status={"ok":False,"reason":"runtime_bootstrap_invalid"}

    if not runtime_status.get("ok"): blockers.append("runtime_not_ready")
    result={
      "ready":not blockers,"blockers":blockers,
      "repo_revision":actual,"runtime":runtime_status,
      "task_case":args.task_case,"verifier_pack":args.verifier_pack}
    print(json.dumps(result,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result["ready"] else 2)

if __name__=="__main__":
    main()
