import argparse,json,os,subprocess,urllib.request,shutil

def cli(binary):
    p=subprocess.run([binary,"--version"],text=True,capture_output=True,timeout=15)
    return {"transport":"cli","binary":binary,"version":(p.stdout or p.stderr).strip(),"ok":p.returncode==0}

def http(endpoint):
    with urllib.request.urlopen(endpoint.rstrip("/")+"/version",timeout=10) as r:
        identity=json.loads(r.read().decode())
    with urllib.request.urlopen(endpoint.rstrip("/")+"/readyz",timeout=10) as r:
        ready=json.loads(r.read().decode())
    return {"transport":"http","endpoint":endpoint,"identity":identity,"ready":ready,
            "ok":bool(ready.get("ready",ready.get("status")=="ready"))}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--cli")
    ap.add_argument("--api-url")
    args=ap.parse_args()
    if args.api_url:
        result=http(args.api_url)
    else:
        binary=args.cli or os.getenv("ELMOS_CLI") or shutil.which("elmos")
        result={"ok":False,"reason":"elmos_cli_not_found"} if not binary else cli(binary)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result.get("ok") else 2)

if __name__=="__main__":
    main()
