# ETA Training / Calibration

Train on actual Elmos machine wall-clock outcomes.

Split by repository lineage.

Evaluate:
- MAE
- MAPE
- P50 coverage
- P90 coverage
- pinball loss
- calibration by repo size and task class

Activate only after calibration thresholds pass.
