def evaluate_calibration(predictions):
    if not predictions:
        return {"status": "no_data"}
    n = len(predictions)
    p50_hits = sum(1 for x in predictions if x["actual"] <= x["p50"])
    p90_hits = sum(1 for x in predictions if x["actual"] <= x["p90"])
    mae = sum(abs(x["actual"] - x["p50"]) for x in predictions) / n
    return {
        "rows": n,
        "p50_coverage": p50_hits / n,
        "p90_coverage": p90_hits / n,
        "mae_seconds": mae
    }
