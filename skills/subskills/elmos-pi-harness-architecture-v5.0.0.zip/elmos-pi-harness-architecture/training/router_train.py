import json
from pathlib import Path

def load_records(path):
    return [json.loads(p.read_text()) for p in Path(path).glob("*.json")]

def train(records):
    if len(records) < 100:
        return {"status": "insufficient_data", "rows": len(records)}
    return {
        "status": "adapter_required",
        "rows": len(records),
        "artifact_type": "router_model",
        "recommended_next": "train gradient-boosted ranker or contextual-bandit warm start"
    }
