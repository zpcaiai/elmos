# Router Training Job

Pipeline:
1. validate verified training records
2. split by repository/task family to reduce leakage
3. evaluate current rules baseline
4. train ranker/classifier
5. calibrate
6. offline benchmark
7. package immutable artifact
8. shadow
9. canary
10. activate or rollback

Reward derives from post-verification outcomes, not model self-confidence.
