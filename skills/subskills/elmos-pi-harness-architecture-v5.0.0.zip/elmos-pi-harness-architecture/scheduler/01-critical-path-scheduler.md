# Critical-Path DAG Scheduler

## Goal
Minimize total machine wall-clock rather than merely maximizing worker utilization.

## Node metadata
- expected_duration_ms
- dependencies
- resource class
- model/provider requirements
- verification risk
- cache probability
- retry probability
- cost estimate

## Priority
Critical-path nodes receive priority over equally-ready non-critical work.

Priority components:
- critical-path membership
- remaining path duration
- downstream fanout
- verification risk
- estimated unblock value
- tenant SLA urgency

## Rules
- never violate DAG dependencies
- never exceed tenant concurrency limits
- never oversubscribe scarce model/provider quotas blindly
- preemption is allowed only for resumable/idempotent work
