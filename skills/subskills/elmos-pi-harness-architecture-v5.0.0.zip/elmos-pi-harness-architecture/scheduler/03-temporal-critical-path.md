# Temporal-Aware Critical-Path Scheduling

Temporal remains the durable workflow engine; Elmos owns dynamic priority policy.

Flow:
workflow materializes ready nodes
→ compute remaining critical path
→ score nodes by criticality, remaining duration, unblock value, SLA urgency and scarcity
→ dispatch to resource-specific queues
→ observe runtime
→ recompute priorities after completions/failures.

Dynamic scheduling decisions should be represented by deterministic activity results/policy versions
rather than mutating workflow history semantics.
