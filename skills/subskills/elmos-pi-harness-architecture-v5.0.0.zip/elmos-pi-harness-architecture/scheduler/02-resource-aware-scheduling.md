# Resource-Aware Scheduling

Resource classes:
- frontier-model
- economical-model
- cpu-build
- memory-heavy-index
- sandbox
- database-migration
- network-bound

Scheduler must consider:
- provider rate limits
- tenant quotas
- worker capacities
- predicted node duration
- cache-hit probability
- failure/retry probability

Use backpressure rather than uncontrolled queue growth.
