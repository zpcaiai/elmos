# Temporal Priority Routing

Temporal remains the durable workflow engine.

Elmos maps nodes to stable task queues by:
- resource class
- urgency
- tenant/SLA class
- isolation requirement

Example queues:
- elmos-frontier-high
- elmos-frontier-normal
- elmos-economical
- elmos-build
- elmos-index
- elmos-verification

Queue routing policy is versioned and observable.
