# Unit Economics Evidence

Per validated task:
revenue - model/provider - compute - storage - external services - support allocation
= contribution margin.

Report by task class and Golden Route. Never improve margin by silently weakening quality or verification.
