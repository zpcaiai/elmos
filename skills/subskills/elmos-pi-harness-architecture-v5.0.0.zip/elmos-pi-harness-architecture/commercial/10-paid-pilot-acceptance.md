# E7 Paid Pilot / Customer Acceptance

E7 requires a customer-authorized workload, written acceptance criteria,
successful production-like execution, objective acceptance/sign-off,
cost/runtime evidence and residual-risk disclosure.

A paid invoice alone is not technical acceptance.
