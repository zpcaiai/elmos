# Pricing and Unit Economics

Hybrid model: base subscription + usage credits + project/Golden Route pricing + private deployment.

Track per task: revenue - model cost - compute - storage - external services = contribution margin.

Router may be margin-aware but may never silently trade away contracted quality/SLA.
