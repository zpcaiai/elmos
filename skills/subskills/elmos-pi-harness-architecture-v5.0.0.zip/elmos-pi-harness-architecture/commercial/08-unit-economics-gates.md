# Unit Economics
Revenue - model - compute - storage - external services - support allocation = contribution margin.

Track cost/successful task, cost/KLOC, cost/Golden Route, frontier-model share, cache savings,
retry amplification and gross margin.

Router maximizes expected validated success subject to SLA/budget, then optimizes margin.
