# SLA / SLO candidates
- Task API availability >=99.9%
- accepted durable task loss: 0
- task state reconstructibility: 100%
- critical tenant-isolation failures: 0
- billing reconciliation error <0.1%
- supported crash-resume success >=99%

Expose queue time, machine ETA interval, execution time, verification time, cost budget and recovery count.
