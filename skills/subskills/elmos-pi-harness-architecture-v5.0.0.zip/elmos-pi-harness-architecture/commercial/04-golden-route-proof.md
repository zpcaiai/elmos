# Commercial Golden Route Proof

For each sellable Golden Route record:

- qualification criteria
- supported source versions
- supported target versions
- unsupported patterns
- benchmark repos
- success rate
- machine wall-clock runtime distribution
- model/compute cost distribution
- regression rate
- human intervention count
- rollback success
- customer acceptance evidence

A Golden Route becomes a commercial SKU only after repeatability is demonstrated.
