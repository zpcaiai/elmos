# Paid Pilot Acceptance Gate

Required:
- customer-authorized workload
- agreed task scope
- agreed acceptance criteria
- agreed data/provider policy
- baseline captured
- run evidence complete
- deterministic verification passed
- residual risks documented
- customer acceptance recorded

E7 is granted only after objective customer acceptance, not merely after invoice/payment.
