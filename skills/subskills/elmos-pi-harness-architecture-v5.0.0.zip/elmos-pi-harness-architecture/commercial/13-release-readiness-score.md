# Commercial Release Readiness Score

Suggested weighted dimensions:

- 20% validated task quality
- 15% large-repo proof
- 15% recovery/chaos proof
- 15% unit economics
- 10% security/governance
- 10% ETA/SLA confidence
- 10% paid-pilot acceptance
- 5% competitive evidence completeness

Do not use the score to override hard-fail gates.
