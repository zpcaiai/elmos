# Investor-Grade KPIs
Technical: validated success, large-repo success, p50/p95 machine wall-clock, resume success,
context efficiency, benchmark delta.

Economic: cost/success, gross margin, Golden Route ASP, model cost/revenue.

Defensibility: certified recipes, persistent repo graphs, execution/eval corpus,
certified >500k/>1M repos, model portability.

Commercial: paid pilots, conversion, renewal, ACV, time-to-value.
