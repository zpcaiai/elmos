# Investor-Grade Moat Checklist

The product should prove:

1. Repository graph becomes persistent customer-specific intelligence.
2. Transformation recipes are reusable IP.
3. Golden Routes can be sold repeatedly with predictable margin.
4. Model-provider dependence is low.
5. Cost per successful task improves over time.
6. Large-repo success is reproducible.
7. Durable execution reduces operational failure rate.
8. Verification evidence lowers enterprise adoption risk.
9. Domain Packs expand ACV without bloating kernel.
10. Historical execution data improves routing and estimation.

Fundraising claims must be backed by benchmark dashboards and paid customer evidence.
