def begin(effect_id, action_kind, parent_call_id=None, metadata=None):
    return {
        "effect_id": effect_id,
        "action_kind": action_kind,
        "parent_call_id": parent_call_id,
        "status": "PENDING",
        "metadata": metadata or {}
    }

def resolve(effect, approved, resolver):
    out = dict(effect)
    out["status"] = "APPROVED" if approved else "DENIED"
    out["resolver"] = resolver
    return out
