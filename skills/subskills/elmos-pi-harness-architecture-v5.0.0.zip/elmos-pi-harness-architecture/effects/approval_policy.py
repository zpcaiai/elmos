def requires_approval(action_kind, policy):
    explicit = policy.get("actions", {})
    if action_kind in explicit:
        return bool(explicit[action_kind])
    return bool(policy.get("default_require_approval", True))
