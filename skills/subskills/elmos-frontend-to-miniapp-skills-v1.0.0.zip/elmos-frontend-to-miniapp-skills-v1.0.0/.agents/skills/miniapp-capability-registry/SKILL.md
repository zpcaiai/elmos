---
name: miniapp-capability-registry
description: Resolve source capabilities against a versioned registry for WeChat,
  Alipay, Douyin, and Xiaohongshu, producing A-E compatibility classifications, permissions,
  backend needs, fallbacks, and review risks. Use before target generation.
license: Proprietary
metadata:
  package: elmos.frontend-to-miniapp.skills
  version: 1.0.0
  stage: planning
  task_ids:
  - MAPP-013
  - MAPP-014
  maturity: implementation-ready
---

# miniapp-capability-registry

## 目标

把登录、支付、分享、媒体、地图、设备、内容、电商等能力映射为平台可执行计划。

## 何时使用

- IR 中出现平台能力
- 平台 API 或审核规则变化
- 需要决定 native/adapter/redesign/unsupported

## 输入

- semantic-ir.json
- capability registry entries
- platform profiles
- conversion policy

输入必须来自固定的仓库修订或带内容哈希的任务产物。发现缺失字段时，先输出结构化阻断项；不要凭空补齐平台权限、业务规则或凭证。

## 输出

- capability-resolution.json
- compatibility-findings.json
- required-permissions.json
- backend-requirements.json

所有 JSON 输出必须通过本包 `schemas/` 中对应的 Draft 2020-12 Schema；所有生成文件必须进入 artifact index，并记录源修订、规则版本与内容哈希。

## 依赖技能

- miniapp-semantic-ir

## 执行流程

1. 匹配 source_patterns 与 IR capability，不使用仅靠名称的模糊猜测。
2. 按平台与工具链版本解析 support、adapter、permission、review、backend 和 fallback。
3. 输出 A 原生等价、B 适配等价、C 重构、D 人工决策、E 不可实现分类。
4. 对账户、类目、地区、资质或审核依赖标记 permission-dependent。
5. 检查能力组合冲突，例如登录、支付与用户身份体系不一致。
6. 为 C/D/E 生成决策问题、可选方案、成本和测试要求。
7. 记录注册表版本和官方资料更新时间，便于后续漂移检查。

## 强制规则

- 不把 include_transfers 类似的检索开关误当语义结论；同理，API 存在不代表账户已获权限
- 平台能力必须版本化
- 无法确认的平台状态归 D 而非 A/B

通用规则：

- 不得声称“转换完成”而没有编译、测试和证据。
- 不得在客户端代码、日志、报告或 fixture 中写入真实平台密钥。
- 不得静默删除功能、事件、权限、数据流或错误处理。
- 生成步骤必须确定性；同一输入和规则版本应产生相同规范化输出。
- 外部工具链、账户权限、平台审核或真实支付不可用时，输出 `blocked` 及证据，不得伪造成功。
- 任何有副作用的动作必须有幂等键、审批状态和回滚/补偿策略。

## 验收门禁

- IR capability 100% 有解析结果
- C/D/E 100% 进入报告
- 权限与后端依赖完整

## 常见失败与升级条件

- 注册表过期
- 官方文档冲突
- 账户权限未知
- 能力组合无等价实现

遇到以下任一条件必须停止自动执行并升级到 orchestrator：需要真实支付/退款/发布、需要扩大权限、需要降低安全或质量门禁、连续两次产生等价补丁、达到最大修复次数、或无法证明行为等价。

## 任务追踪

- 任务 ID：MAPP-013, MAPP-014
- 输出状态：`not_started | running | blocked | failed | passed | approved`
- 每次执行记录：输入哈希、输出哈希、工具版本、开始/结束时间、系统墙钟运行时、成本、失败分类与下一恢复点。
- 不使用人工人日替代系统实际运行时；需要 ETA 时报告机器墙钟 ETA 及置信区间。

## 附带资源

- `references/contract.md`：接口、幂等、可观测性和测试契约。
- `assets/output-contract.yaml`：本技能要求的输出文件与最低门禁。
- `examples/invocation.md`：Codex 与 Claude Code 调用示例。
- 包级 Schema、模板和实施文档位于仓库根目录的 `schemas/`、`templates/`、`docs/`。

## 完成定义

只有当本技能的全部必需输出存在、Schema 验证通过、门禁结果有证据、阻断项被显式披露，并且上游 orchestrator 已接收 artifact index 后，状态才可标记为 `passed`。
