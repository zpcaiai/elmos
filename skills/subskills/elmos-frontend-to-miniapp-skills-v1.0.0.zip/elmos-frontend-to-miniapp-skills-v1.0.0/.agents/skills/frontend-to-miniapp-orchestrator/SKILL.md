---
name: frontend-to-miniapp-orchestrator
description: Orchestrate repository-level conversion from Vue, React, Flutter, H5,
  Taro, uni-app, or an existing miniapp into WeChat, Alipay, Douyin, and Xiaohongshu
  miniapps. Use for end-to-end planning, checkpoints, gates, repair loops, and final
  evidence; do not use for an isolated adapter implementation.
license: Proprietary
metadata:
  package: elmos.frontend-to-miniapp.skills
  version: 1.0.0
  stage: orchestration
  task_ids:
  - MAPP-001
  - MAPP-002
  maturity: implementation-ready
---

# frontend-to-miniapp-orchestrator

## 目标

把一次前端跨端转换拆成可恢复、可审计的阶段任务，并确保任何功能差异、平台限制和人工审批点都被显式记录。

## 何时使用

- 转换整个前端项目到一个或多个小程序平台
- 继续、恢复或复盘一次中断的转换任务
- 汇总各分析、代码生成、测试和发布子技能的输出

## 输入

- conversion-request.json（符合 schemas/conversion-request.schema.json）
- 源仓库路径或只读快照
- 目标平台、质量阈值与降级策略
- 任务检查点与历史证据（恢复任务时）

输入必须来自固定的仓库修订或带内容哈希的任务产物。发现缺失字段时，先输出结构化阻断项；不要凭空补齐平台权限、业务规则或凭证。

## 输出

- runs/<run-id>/state.json
- runs/<run-id>/plan.json
- runs/<run-id>/artifacts-index.json
- 最终 migration-evidence.json 与兼容性报告

所有 JSON 输出必须通过本包 `schemas/` 中对应的 Draft 2020-12 Schema；所有生成文件必须进入 artifact index，并记录源修订、规则版本与内容哈希。

## 依赖技能

- 无；可作为入口或独立发现技能执行

## 执行流程

1. 验证请求、源版本和目标平台，不接受缺失的目标、未固定的源提交或明文密钥。
2. 调用 source-framework-detector 生成项目清单与框架置信度；低置信度时保持多候选，不擅自选定。
3. 按检测结果并行调用 Vue、React、Flutter 或其他源适配器，汇合为版本化 Semantic IR。
4. 调用能力注册表、组件映射、状态事件生命周期、样式布局和依赖迁移技能形成平台计划。
5. 按目标平台隔离代码生成工作区；共享业务核心只能通过明确的 shared contract 复用。
6. 执行静态验证、官方工具链构建、差分测试、视觉回归、隐私安全扫描与性能门禁。
7. 对可自动修复的问题进入有界修复循环；达到次数、风险或重复补丁阈值时停止并升级。
8. 汇总证据、风险和未支持项；支付、隐私、权限、上架等动作必须等待授权审批。
9. 将每个阶段状态、输入摘要、输出哈希、成本与失败原因写入任务存档，保证幂等恢复。

## 强制规则

- 默认禁止用 WebView、全页面 Canvas 或截图替代原生转换；任何例外必须在请求中显式允许并记录批准。
- 禁止静默删除源功能。所有不能等价实现的项必须分类为 C/D/E 并进入报告。
- 每个阶段以内容哈希作为幂等键；不得重复执行已经通过且输入未变化的副作用步骤。
- 发布不是默认动作；构建、预览、上传、提交审核和正式发布是不同审批级别。

通用规则：

- 不得声称“转换完成”而没有编译、测试和证据。
- 不得在客户端代码、日志、报告或 fixture 中写入真实平台密钥。
- 不得静默删除功能、事件、权限、数据流或错误处理。
- 生成步骤必须确定性；同一输入和规则版本应产生相同规范化输出。
- 外部工具链、账户权限、平台审核或真实支付不可用时，输出 `blocked` 及证据，不得伪造成功。
- 任何有副作用的动作必须有幂等键、审批状态和回滚/补偿策略。

## 验收门禁

- 请求 Schema 通过
- 所有目标平台均有明确计划
- 关键流程 100% 通过
- 无未披露 C/D/E 项
- 证据包完整且可重放

## 常见失败与升级条件

- 框架置信度不足
- 源仓库不完整或无法固定版本
- 平台凭证缺失
- 官方工具链不可用
- 修复循环不收敛

遇到以下任一条件必须停止自动执行并升级到 orchestrator：需要真实支付/退款/发布、需要扩大权限、需要降低安全或质量门禁、连续两次产生等价补丁、达到最大修复次数、或无法证明行为等价。

## 任务追踪

- 任务 ID：MAPP-001, MAPP-002
- 输出状态：`not_started | running | blocked | failed | passed | approved`
- 每次执行记录：输入哈希、输出哈希、工具版本、开始/结束时间、系统墙钟运行时、成本、失败分类与下一恢复点。
- 不使用人工人日替代系统实际运行时；需要 ETA 时报告机器墙钟 ETA 及置信区间。

## 附带资源

- `references/contract.md`：接口、幂等、可观测性和测试契约。
- `assets/output-contract.yaml`：本技能要求的输出文件与最低门禁。
- `examples/invocation.md`：Codex 与 Claude Code 调用示例。
- 包级 Schema、模板和实施文档位于仓库根目录的 `schemas/`、`templates/`、`docs/`。

## 完成定义

只有当本技能的全部必需输出存在、Schema 验证通过、门禁结果有证据、阻断项被显式披露，并且上游 orchestrator 已接收 artifact index 后，状态才可标记为 `passed`。
