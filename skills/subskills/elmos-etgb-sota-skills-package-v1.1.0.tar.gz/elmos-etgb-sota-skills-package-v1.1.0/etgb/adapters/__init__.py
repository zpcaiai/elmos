"""Execution adapters for ETGB."""
