from dataclasses import dataclass

@dataclass(frozen=True)
class ExecutionAuthority:
    environment_id: str
    workspace_id: str
    permission_profile_id: str
    policy_snapshot_hash: str
    fencing_token: int
    allowed_tools: frozenset[str]

    def authorize(self,tool_id:str,environment_id:str,workspace_id:str,fencing_token:int)->None:
        if environment_id!=self.environment_id or workspace_id!=self.workspace_id:
            raise PermissionError('AUTHORITY_SCOPE_MISMATCH')
        if fencing_token!=self.fencing_token:
            raise PermissionError('FENCING_REJECTED')
        if tool_id not in self.allowed_tools:
            raise PermissionError('TOOL_DENIED')
