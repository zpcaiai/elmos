from enum import StrEnum

class Decision(StrEnum):
    DENY='DENY'; ASK_USER='ASK_USER'; REQUIRE_ESCALATION='REQUIRE_ESCALATION'
    REQUIRE_SECOND_REVIEW='REQUIRE_SECOND_REVIEW'; MODIFY_INPUT='MODIFY_INPUT'; ALLOW='ALLOW'

_PRIORITY=list(Decision)

def aggregate_decisions(decisions: list[Decision]) -> Decision:
    if not decisions:
        return Decision.DENY
    return min(decisions,key=_PRIORITY.index)
