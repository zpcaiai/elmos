from dataclasses import dataclass

@dataclass(frozen=True)
class GateResult:
    gate_id: str
    status: str

class AcceptanceGate:
    def decide(self,results:list[GateResult],open_findings:list[dict],rollback_ready:bool,health:dict)->str:
        if any(r.status=='BLOCKED' for r in results): return 'BLOCKED'
        if any(r.status=='FAIL' for r in results): return 'REJECTED'
        if any(f.get('status')=='OPEN' and f.get('severity') in {'P0','P1'} for f in open_findings): return 'REJECTED'
        if not rollback_ready: return 'REJECTED'
        if not all(health.get(k) is True for k in ('livez','readyz','metrics','version')): return 'REJECTED'
        return 'ACCEPTED'
