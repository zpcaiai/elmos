import hashlib, json

def build_cache_key(**parts)->str:
    required={'repo_snapshot_sha','task_spec_hash','workflow_version','skill_versions','policy_hash','tool_schema_versions','model_profile'}
    missing=required-parts.keys()
    if missing: raise ValueError(f'CACHE_KEY_INCOMPLETE: {sorted(missing)}')
    raw=json.dumps(parts,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    return hashlib.sha256(raw).hexdigest()
