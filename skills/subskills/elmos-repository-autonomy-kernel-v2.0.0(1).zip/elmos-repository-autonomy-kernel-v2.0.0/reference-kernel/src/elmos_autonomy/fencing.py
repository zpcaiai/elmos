from dataclasses import dataclass

@dataclass(frozen=True)
class Lease:
    resource_id: str
    owner_id: str
    fencing_token: int

class LeaseGuard:
    def __init__(self): self._tokens: dict[str,int]={}
    def acquire(self,resource_id:str,owner_id:str)->Lease:
        token=self._tokens.get(resource_id,0)+1
        self._tokens[resource_id]=token
        return Lease(resource_id,owner_id,token)
    def assert_current(self,lease:Lease)->None:
        current=self._tokens.get(lease.resource_id)
        if current!=lease.fencing_token:
            raise PermissionError('FENCING_REJECTED')
