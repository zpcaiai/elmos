import pytest
from elmos_autonomy.state_machine import RunState, transition
from elmos_autonomy.policy import Decision, aggregate_decisions
from elmos_autonomy.fencing import LeaseGuard
from elmos_autonomy.completion import AcceptanceGate, GateResult
from elmos_autonomy.cache_key import build_cache_key

def test_illegal_direct_cancel():
    with pytest.raises(ValueError): transition(RunState.EXECUTING,RunState.CANCELLED)

def test_cancel_request_is_legal():
    assert transition(RunState.EXECUTING,RunState.CANCEL_REQUESTED)==RunState.CANCEL_REQUESTED

def test_policy_deny_wins():
    assert aggregate_decisions([Decision.ALLOW,Decision.MODIFY_INPUT,Decision.DENY])==Decision.DENY

def test_empty_policy_is_fail_closed():
    assert aggregate_decisions([])==Decision.DENY

def test_stale_worker_rejected():
    g=LeaseGuard(); old=g.acquire('ws','a'); new=g.acquire('ws','b')
    with pytest.raises(PermissionError): g.assert_current(old)
    g.assert_current(new)

def test_completion_needs_health_and_rollback():
    gate=AcceptanceGate()
    ok=[GateResult('build','PASS')]
    health={'livez':True,'readyz':True,'metrics':True,'version':True}
    assert gate.decide(ok,[],True,health)=='ACCEPTED'
    assert gate.decide(ok,[],False,health)=='REJECTED'

def test_open_p1_blocks():
    gate=AcceptanceGate(); health={'livez':True,'readyz':True,'metrics':True,'version':True}
    assert gate.decide([GateResult('build','PASS')],[{'severity':'P1','status':'OPEN'}],True,health)=='REJECTED'

def test_cache_key_stable():
    args=dict(repo_snapshot_sha='a',task_spec_hash='b',workflow_version='2',skill_versions={'x':'1'},policy_hash='p',tool_schema_versions={'t':'1'},model_profile='m')
    assert build_cache_key(**args)==build_cache_key(**args)

def test_cache_key_requires_all_parts():
    with pytest.raises(ValueError): build_cache_key(repo_snapshot_sha='a')
