package elmos.autonomy.model_routing

default eligible := false

eligible if {
  input.model.eval_status == "PASS"
  input.model.privacy_mode in input.step.allowed_privacy_modes
  input.model.max_context >= input.step.required_context
  input.model.risk_ceiling >= input.step.risk_level
}

deny_reason := "high-risk task cannot use unevaluated model" if {
  input.step.risk_level in {"HIGH","CRITICAL"}
  input.model.eval_status != "PASS"
}
