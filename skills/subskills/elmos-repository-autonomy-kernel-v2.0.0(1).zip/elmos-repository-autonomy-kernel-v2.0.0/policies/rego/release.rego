package elmos.autonomy.release

default deployment_complete := false

deployment_complete if {
  every gate in input.mandatory_gates { gate.status == "PASS" }
  count([f | f := input.findings[_]; f.status == "OPEN"; f.severity in {"P0","P1"}]) == 0
  input.rollback_ready == true
  input.health.livez == true
  input.health.readyz == true
  input.health.metrics == true
  input.health.version == true
}
