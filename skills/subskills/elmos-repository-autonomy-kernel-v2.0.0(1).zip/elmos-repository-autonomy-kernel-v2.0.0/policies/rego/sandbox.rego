package elmos.autonomy.sandbox

default allow_network := false

default allow_path := false

allow_network if input.destination in input.authority.network_scopes
allow_path if startswith(input.path, input.authority.workspace_root)

deny_reason := "secret requested during secretless analysis phase" if {
  input.phase == "ANALYZE"
  count(input.secret_scopes) > 0
}
