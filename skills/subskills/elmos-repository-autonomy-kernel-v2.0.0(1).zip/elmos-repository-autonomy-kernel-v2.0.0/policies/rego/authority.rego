package elmos.autonomy.authority

default allow := false

allow if {
  input.authority.environment_id == input.request.environment_id
  input.authority.workspace_id == input.request.workspace_id
  input.authority.fencing_token == input.request.fencing_token
  input.request.tool_id in input.authority.allowed_tools
}

deny_reason := "thread-global authority is forbidden" if {
  input.request.authority_source == "conversation"
}
