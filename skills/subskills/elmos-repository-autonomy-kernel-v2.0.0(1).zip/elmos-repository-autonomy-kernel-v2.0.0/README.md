# Elmos Repository Autonomy Kernel v2.0.0

**定位：** 基于 Claude Code 公开可观察的 Harness、Command、Agent、Skill、Hook、Plugin、MCP、Review、Sandbox、Background Session、Cache、Recovery 等设计思想，结合 Elmos 的仓库级生成、转换、迁移、重构、测试与商业交付要求，形成独立实现的顶级商业生产工具技能包。

> 本包不复制 Anthropic 专有实现代码。Claude Code 仓库并未公开完整核心运行时；本包只抽象公开插件、Skills、Hooks、工作流、开发容器、评审范式和变更记录中体现的一般性工程思想，并为 Elmos 重新设计协议与实现边界。

## 1. 交付规模

```text
31 Skills                         P0/P1/P2 = 16 / 10 / 5
155 per-skill files               每个 Skill 5 个文件
20 global JSON Schemas            跨语言核心契约
4 PostgreSQL migrations           PostgreSQL 17
4 OpenAPI contracts               Control / Executor / Registry / Eval
4 OPA/Rego policy modules         Authority / Sandbox / Release / Routing
7 Harness adapters                Claude Code、Codex、Agent SDK 等
3 Golden Route examples           Spring、跨语言、仓库级重构
Python reference kernel           可运行的状态机/策略/栅栏/验收骨架
Deployment & operations           Helm、K8s、CI、Runbook、P05 门
Evaluation & certification        E1–E5、Chaos、KPI、Scorecard
```

## 2. 核心升级

```text
Prompt-driven coding
        ↓
Harness-native repository execution
        ↓
Durable, governed, evidence-backed software factory
        ↓
Commercially certifiable repository autonomy platform
```

### 系统真相分层

| 内容 | 真相来源 |
|---|---|
| 用户交互 | Conversation transcript |
| 可恢复工作记忆 | Context Ledger / Model State |
| 执行状态 | PostgreSQL Run / Step / Event |
| 源代码变化 | Git / ChangeGraph |
| 大对象产出 | S3-compatible Artifact Store |
| 判断依据 | Evidence Store |
| 最终完成 | Independent Acceptance Decision |

## 3. 31 Skills

### P0：生产可靠性和语义正确性

1. `task-spec-delta-compiler`
2. `durable-run-orchestrator`
3. `execution-authority-kernel`
4. `typed-tool-runtime`
5. `policy-hook-kernel`
6. `two-phase-secretless-sandbox`
7. `workspace-lease-fencing`
8. `artifact-evidence-protocol`
9. `repository-census`
10. `incremental-semantic-index`
11. `semantic-ir-compiler`
12. `changegraph-vcs`
13. `validation-dag`
14. `independent-verification-mesh`
15. `evidence-release-gate`
16. `contract-compatibility-engine`

### P1：效率、成本、安全和平台化

17. `prefix-stable-context-planner`
18. `lazy-tool-loader`
19. `model-state-continuity`
20. `multi-agent-worktree-coordinator`
21. `phase-aware-model-router`
22. `layered-cache-fabric`
23. `cost-eta-observability`
24. `tiered-security-assurance`
25. `session-time-travel`
26. `capability-package-registry`

### P2：自进化、模型竞争和生态壁垒

27. `demonstration-to-skill`
28. `auto-improvement-inbox-and-skill-curator`
29. `agent-arena`
30. `repository-model-elo`
31. `repository-gym-golden-routes`

## 4. 7+1 Capability Packs

| Pack | 作用 |
|---|---|
| P00 | Harness-native Software Factory Master |
| P01 | Runtime SPI、Session、Tool、Permissions、Sandbox、Recovery |
| P02 | Repository Intelligence、AST/LSP、Graphs、Evidence、Context |
| P03 | Generation、Transformation、Migration、Semantic IR、ChangeGraph |
| P04 | DAG、Multi-Agent、Worktree、Review、Proof-of-Work |
| P05 | Coverage、Differential、E2E、Repair、Security、Evidence Gate、Deployment Complete |
| P06 | Model/Provider Routing、Privacy、Cost、Cache、Fallback、Auditor |
| P07 | Rules、Learning、Skill Curation、Arena、ELO、Repository Gym |

## 5. 生产硬约束

- PostgreSQL 17。
- Python 3.11 参考内核。
- Kubernetes 1.30。
- OpenTelemetry 1.x。
- S3-compatible object storage。
- Kafka、NATS 或 Redpanda 兼容事件总线。
- 每个顶层账号默认最多 3 个并发项目任务。
- ETA 必须报告机器实际 wall-clock seconds，并单独报告人工等价工作量与 HITL 等待时间。
- 生产发布必须通过 `P05_DEPLOYMENT_COMPLETE`。
- Provider/Harness Adapter 默认 fail-closed，并在 Release 时运行 Conformance Suite。
- 所有写操作使用 Workspace/Environment-owned authority 与 Fencing Token。
- `INTERRUPTED`、`FAILED`、`PARTIAL`、`SUCCEEDED` 语义严格分离。

## 6. 快速验证

```bash
cd elmos-repository-autonomy-kernel-v2.0.0
python3 scripts/validate_package.py
python3 scripts/generate_catalog.py
python3 scripts/run_reference_kernel_demo.py

python3 -m pip install -r requirements-dev.txt
make test
```

## 7. 安装到 Elmos 主仓库

```bash
./scripts/install.sh /path/to/elmos
```

默认映射：

```text
skills/                       → <elmos>/skills/repository-autonomy-kernel/
contracts/                    → <elmos>/contracts/repository-autonomy/
workflows/                    → <elmos>/workflows/golden-routes/
policies/                     → <elmos>/policies/repository-autonomy/
db/migration/                 → <elmos>/db/migration/
harness-adapters/             → <elmos>/harness-adapters/
reference-kernel/             → <elmos>/reference/repository-autonomy-kernel/
```

## 8. 诚实边界

包结构、Schema、测试和静态一致性通过，并不等于已经在目标 Elmos 主仓库、真实企业代码库或百万行 Golden Route 上完成生产认证。真实上线仍必须完成适配、集成测试、故障注入、性能压测、E1–E5 认证和实际客户仓库验证。
