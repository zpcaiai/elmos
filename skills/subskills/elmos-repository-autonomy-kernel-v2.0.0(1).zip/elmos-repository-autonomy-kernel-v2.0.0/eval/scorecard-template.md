# Repository Autonomy Scorecard

| Dimension | Metric | Target | Actual | Evidence |
|---|---|---:|---:|---|
| Correctness | Semantic equivalence | TBD | | |
| Reliability | Resume success | TBD | | |
| Quality | Escaped P0/P1 | 0 | | |
| Cost | Cost per successful run | TBD | | |
| ETA | P80 error | TBD | | |
| Security | Tenant boundary regressions | 0 | | |
| Autonomy | Human interventions | TBD | | |
| Release | P05_DEPLOYMENT_COMPLETE | required | | |
