# Migration from v1

v1 的 18 Skills 可映射到 v2：

- Task Spec、Repository Census、Durable Orchestrator、Tool Runtime、Policy Bus、Sandbox、Verification、Completion、Fencing 保留并拆细。
- Progressive Context 拆为 Prefix-stable Context、Lazy Tool Loading 和 Model-state Continuity。
- Multi-Agent、Model Router、Cache、Security、Registry、Cost/ETA 升级为完整 P1。
- 新增 Semantic IR、ChangeGraph、Validation DAG、Contract Compatibility、Session Time Travel 和 P2 自进化体系。

数据库必须使用新增 Migration；不要覆盖 v1 历史数据，应通过兼容 View 或离线迁移转换。
