# Deployment Runbook

1. 验证 PostgreSQL 17 Migration。
2. 验证 S3、Event Bus、OTel、Secrets Broker。
3. 部署 Control Plane、Executor Manager、Policy、Registry、Eval 服务。
4. 检查 `/livez`、`/readyz`、`/metrics`、`/version`。
5. 运行 Adapter Conformance。
6. 运行 E1/E2 测试。
7. 灰度执行 Golden Route。
8. 演练 Pause/Resume/Cancel、Executor Takeover、Rollback。
9. 签发 `P05_DEPLOYMENT_COMPLETE`。
10. 才允许生产流量。
