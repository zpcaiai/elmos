# Authority and Security

最终权限由：

```text
ExecutionEnvironment
+ Workspace
+ PermissionProfile snapshot
+ ToolRequest
+ FencingToken
```

共同决定。Conversation、Thread、Prompt、模型或子 Agent 名称均不能成为权限来源。

执行采用 two-phase secretless 模型：

1. 无 Secrets 的分析与规划。
2. 仅在批准后，为具体 Tool Request 绑定最小范围、短时 Secrets。

所有 Provider/Harness Adapter 在语义无法映射时 fail-closed。
