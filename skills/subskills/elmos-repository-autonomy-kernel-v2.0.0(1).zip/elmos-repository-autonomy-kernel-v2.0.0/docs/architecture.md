# Architecture

```text
Web-first Control Plane / API / CLI / IDE Companion
                    │
          Task Spec Delta Compiler
                    │
           Durable Orchestrator
       ┌────────────┼─────────────┐
 Context Planner  Model Router  Approval
       │             │             │
 Lazy Tool Loader ─ Authority ─ Policy Hooks
                    │
          Typed Tool Runtime
                    │
 Two-Phase Secretless Sandbox + Worktree Lease/Fencing
                    │
 Semantic Index / IR / ChangeGraph / Artifact-Evidence
                    │
 Validation DAG + Independent Verification + Security
                    │
 Evidence Release Gate + Deploy + P05 Certification
                    │
 Arena / ELO / Repository Gym / Skill Curation
```

Elmos 保持 Web-first 企业平台定位；IDE Companion、CLI 和 Private Runner 是辅助入口，不把产品重心转成完整 Cursor 类 IDE。
