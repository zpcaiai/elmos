# Claude Code 设计思想到 Elmos 的独立抽象

| 公开可观察模式 | Elmos v2 独立实现 |
|---|---|
| Commands / Agents / Skills / Hooks / MCP / Plugins 分层 | 7+1 Capability Packs + Registry + Tool ABI + Policy Hook Kernel |
| Feature development 先探索、澄清、设计、实现、Review | TaskSpec Delta + Census + Semantic Index + Plan + Approval + Validation DAG |
| 多 Reviewer 并行并二次验证 Finding | Independent Verification Mesh |
| 高信号 Review，避免低置信噪声 | Finding confidence + reproducer + validator confirmation |
| Hook 生命周期控制 | Rego + deterministic rules + model policies |
| Ralph 式有界循环 | Durable Repair Loop + maxRepairCycles + PARTIAL semantics |
| Skill progressive disclosure | Prefix-stable Context + Lazy Skill/Tool Loading |
| Devcontainer + network allowlist | Two-phase Secretless Sandbox + K8s default deny |
| Session resume/background/fork | Model-state Continuity + Session Time Travel + Lease/Fencing |
| Prompt cache TTL / subagent cache | Layered Cache Fabric |
| Model picker / cost / effort / subagents | Phase-aware Model Router + Cost/ETA + ELO |
| Plugin validation and marketplaces | Signed Capability Package Registry + Conformance |
