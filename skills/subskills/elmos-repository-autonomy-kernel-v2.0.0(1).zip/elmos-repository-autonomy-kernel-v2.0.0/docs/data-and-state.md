# Data and State

- PostgreSQL：Run、Step、Event、Lease、Policy、Tool、Finding、Acceptance、Cost、Package、Eval。
- S3：Repository Snapshot、Patch、IR、日志、报告、构建物、回滚包。
- Event Bus：异步状态、Executor 任务、Telemetry 和 Notification。
- OpenTelemetry：Trace、Metric、Log、Audit correlation。
- Git/ChangeGraph：源代码和语义变更历史。

Event Store 使用单调 `sequence_no`；所有 Materialized State 可由事件重建。
