#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'reference-kernel/src'))
from elmos_autonomy import RunState,transition,Decision,aggregate_decisions,LeaseGuard,AcceptanceGate,build_cache_key
from elmos_autonomy.completion import GateResult
print('transition',transition(RunState.CREATED,RunState.DISCOVERING))
print('policy',aggregate_decisions([Decision.ALLOW,Decision.DENY]))
g=LeaseGuard(); old=g.acquire('workspace','worker-a'); new=g.acquire('workspace','worker-b')
try: g.assert_current(old)
except PermissionError as e: print('stale-worker',str(e))
health={'livez':True,'readyz':True,'metrics':True,'version':True}
print('acceptance',AcceptanceGate().decide([GateResult('build','PASS')],[],True,health))
print('cache-key',build_cache_key(repo_snapshot_sha='a',task_spec_hash='b',workflow_version='2',skill_versions={'x':'2'},policy_hash='p',tool_schema_versions={'t':'2'},model_profile='m')[:16])
