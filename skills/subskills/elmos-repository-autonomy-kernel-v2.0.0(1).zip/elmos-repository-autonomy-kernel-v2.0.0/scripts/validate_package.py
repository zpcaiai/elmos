#!/usr/bin/env python3
from pathlib import Path
import argparse, json, re, sys

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(); parser.add_argument('--strict',action='store_true'); args=parser.parse_args()
errors=[]; warnings=[]

def count(pattern): return len(list(ROOT.glob(pattern)))
expected={
 'skills/*/SKILL.md':31,
 'skills/*/contract.yaml':31,
 'skills/*/inputs.schema.json':31,
 'skills/*/outputs.schema.json':31,
 'skills/*/acceptance.yaml':31,
 'contracts/schemas/*.schema.json':20,
 'db/migration/*.sql':4,
 'contracts/openapi/*.yaml':4,
 'policies/rego/*.rego':4,
 'harness-adapters/*/adapter.yaml':7,
 'golden-routes/*/route.yaml':3,
 'capability-packs/*/pack.yaml':8,
}
for pat,n in expected.items():
    actual=count(pat)
    if actual!=n: errors.append(f'{pat}: expected {n}, got {actual}')

skill_dirs=sorted((ROOT/'skills').iterdir())
ids=set(); priorities={'P0':0,'P1':0,'P2':0}
for d in skill_dirs:
    if not d.is_dir(): continue
    files=[p.name for p in d.iterdir() if p.is_file()]
    if len(files)!=5: errors.append(f'{d.name}: expected exactly 5 files, got {len(files)}')
    text=(d/'SKILL.md').read_text(encoding='utf-8')
    for field in ['name','id','description','version','priority','capabilityPack']:
        m=re.search(rf'^{field}:\s*(.+)$',text,re.M)
        if not m: errors.append(f'{d.name}: missing {field}')
        elif field=='id':
            sid=m.group(1).strip(); ids.add(sid)
            if sid!=d.name: errors.append(f'{d.name}: id mismatch {sid}')
        elif field=='priority':
            p=m.group(1).strip(); priorities[p]=priorities.get(p,0)+1
    c=(d/'contract.yaml').read_text(encoding='utf-8')
    if 'threadGlobalAuthorityAllowed: false' not in c: errors.append(f'{d.name}: authority not fail-closed')
    for j in ['inputs.schema.json','outputs.schema.json']:
        try: json.loads((d/j).read_text(encoding='utf-8'))
        except Exception as e: errors.append(f'{d.name}/{j}: {e}')

if priorities!={'P0':16,'P1':10,'P2':5}: errors.append(f'priority counts wrong: {priorities}')
for p in (ROOT/'contracts/schemas').glob('*.json'):
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'{p}: {e}')

manifest=(ROOT/'PACKAGE_MANIFEST.yaml').read_text(encoding='utf-8')
for needle in ['topLevelAccountConcurrency: 3','etaUnit: machine-wall-clock-seconds','releaseGate: P05_DEPLOYMENT_COMPLETE','adapterFailureMode: fail-closed']:
    if needle not in manifest: errors.append(f'manifest missing: {needle}')

for p in (ROOT/'harness-adapters').glob('*/adapter.yaml'):
    t=p.read_text(encoding='utf-8')
    if 'failureMode: fail-closed' not in t: errors.append(f'{p}: not fail-closed')
    if 'threadGlobalAuthorityAllowed: false' not in t: errors.append(f'{p}: thread-global authority allowed')

print('Skill files:',count('skills/*/*'))
print('Priority:',priorities)
for pat,n in expected.items(): print(f'{pat}: {count(pat)}')
for w in warnings: print('WARNING',w)
for e in errors: print('ERROR',e)
if errors: sys.exit(1)
print('PACKAGE_VALIDATION_PASS')
