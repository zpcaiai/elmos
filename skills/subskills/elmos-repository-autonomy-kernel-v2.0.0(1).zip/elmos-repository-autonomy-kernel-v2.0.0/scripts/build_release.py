#!/usr/bin/env python3
from pathlib import Path
import zipfile,tarfile,hashlib
ROOT=Path(__file__).resolve().parents[1]
out=ROOT.parent
zip_path=out/(ROOT.name+'.zip'); tar_path=out/(ROOT.name+'.tar.gz')
for p in [zip_path,tar_path]:
 if p.exists(): p.unlink()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(ROOT.rglob('*')):
  if f.is_file(): z.write(f,arcname=f'{ROOT.name}/{f.relative_to(ROOT)}')
with tarfile.open(tar_path,'w:gz') as t: t.add(ROOT,arcname=ROOT.name)
for p in [zip_path,tar_path]: print(p,hashlib.sha256(p.read_bytes()).hexdigest())
