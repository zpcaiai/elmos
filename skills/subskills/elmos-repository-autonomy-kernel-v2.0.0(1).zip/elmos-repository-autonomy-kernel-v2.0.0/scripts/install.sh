#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then echo "Usage: $0 /path/to/elmos"; exit 2; fi
TARGET=$(cd "$1" && pwd)
ROOT=$(cd "$(dirname "$0")/.." && pwd)
mkdir -p "$TARGET/skills/repository-autonomy-kernel" "$TARGET/contracts/repository-autonomy" "$TARGET/workflows/golden-routes" "$TARGET/policies/repository-autonomy" "$TARGET/harness-adapters" "$TARGET/reference/repository-autonomy-kernel"
cp -R "$ROOT/skills/." "$TARGET/skills/repository-autonomy-kernel/"
cp -R "$ROOT/contracts/." "$TARGET/contracts/repository-autonomy/"
cp -R "$ROOT/workflows/." "$TARGET/workflows/golden-routes/"
cp -R "$ROOT/policies/." "$TARGET/policies/repository-autonomy/"
cp -R "$ROOT/harness-adapters/." "$TARGET/harness-adapters/"
cp -R "$ROOT/reference-kernel/." "$TARGET/reference/repository-autonomy-kernel/"
mkdir -p "$TARGET/db/migration"
cp "$ROOT"/db/migration/*.sql "$TARGET/db/migration/"
echo "Installed into $TARGET"
