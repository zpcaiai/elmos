#!/usr/bin/env python3
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
items=[]
for p in sorted((ROOT/'skills').glob('*/SKILL.md')):
 text=p.read_text(encoding='utf-8')
 def f(k):
  m=re.search(rf'^{k}:\s*(.+)$',text,re.M); return m.group(1).strip() if m else None
 mission=re.search(r'## Mission\n\n(.+?)\n\n##',text,re.S)
 items.append({'id':f('id'),'name':f('name'),'version':f('version'),'priority':f('priority'),'pack':f('capabilityPack'),'description':f('description'),'mission':' '.join(mission.group(1).split()) if mission else '', 'path':str(p.relative_to(ROOT))})
(ROOT/'catalog.json').write_text(json.dumps({'package':'elmos-repository-autonomy-kernel','version':'2.0.0','skills':items},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('catalog.json generated')
