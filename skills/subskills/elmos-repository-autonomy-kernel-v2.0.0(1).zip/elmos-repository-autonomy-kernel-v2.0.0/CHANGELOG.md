# CHANGELOG

## 2.0.0

- 从 18-Skill Harness 包升级为 31-Skill Repository Autonomy Kernel。
- 引入 7+1 Capability Pack 架构。
- 新增 Spec Delta、Execution Authority、Two-phase Secretless Sandbox、Semantic IR、ChangeGraph、Validation DAG、Contract Compatibility。
- 新增 Prefix-stable Context、Lazy Tool Loading、Model-state Continuity、Session Time Travel。
- 新增 Demonstration-to-Skill、Auto-improvement Inbox、Skill Curator、Agent Arena、Repository-model ELO、Repository Gym。
- 新增 20 JSON Schemas、4 PostgreSQL migrations、4 OpenAPI、4 Rego、7 Harness adapters、3 Golden Routes。
- 新增 Python reference kernel、部署资源、E1–E5 认证和 P05 Deployment Complete Gate。
