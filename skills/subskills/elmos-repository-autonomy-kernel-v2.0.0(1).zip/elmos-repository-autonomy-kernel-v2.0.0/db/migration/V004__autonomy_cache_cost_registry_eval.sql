create table autonomy_cache_entries (
  cache_entry_id uuid primary key,
  tenant_id uuid not null,
  cache_layer text not null,
  key_hash text not null,
  content_hash text not null,
  storage_uri text,
  provenance jsonb not null,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  unique(tenant_id,cache_layer,key_hash)
);
create table autonomy_cost_events (
  cost_event_id uuid primary key,
  tenant_id uuid not null,
  account_id uuid not null,
  run_id uuid references autonomy_runs(run_id),
  step_id text,
  category text not null,
  provider text,
  model_id text,
  quantity numeric(24,8) not null,
  unit text not null,
  unit_price numeric(24,12),
  total_cost_usd numeric(24,12),
  pricing_profile_version text,
  occurred_at timestamptz not null default now()
);
create table autonomy_capability_packages (
  package_id uuid primary key,
  name text not null,
  version text not null,
  content_hash text not null,
  manifest jsonb not null,
  signature jsonb,
  state text not null,
  created_at timestamptz not null default now(),
  unique(name,version)
);
create table autonomy_adapter_conformance (
  adapter_id text not null,
  adapter_version text not null,
  suite_version text not null,
  status text not null,
  report_artifact_id uuid references autonomy_artifacts(artifact_id),
  tested_at timestamptz not null default now(),
  primary key(adapter_id,adapter_version,suite_version)
);
create table autonomy_eval_runs (
  eval_run_id uuid primary key,
  suite_id text not null,
  candidate_id text not null,
  task_segment text not null,
  result jsonb not null,
  cost_usd numeric(24,12),
  wall_clock_ms bigint,
  created_at timestamptz not null default now()
);
create table autonomy_elo_ratings (
  candidate_id text not null,
  task_segment text not null,
  rating numeric(12,4) not null,
  uncertainty numeric(12,4) not null,
  sample_count bigint not null,
  updated_at timestamptz not null default now(),
  primary key(candidate_id,task_segment)
);
