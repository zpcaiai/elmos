# Claude Agent SDK adapter

maps sessions, subagents, permissions, MCP and streaming.

Production enablement requires passing every case in `conformance/conformance-suite.yaml`. Adapter errors are fail-closed; the runtime must not silently downgrade `INTERRUPTED`, `PARTIAL`, permissions, or tool errors.
