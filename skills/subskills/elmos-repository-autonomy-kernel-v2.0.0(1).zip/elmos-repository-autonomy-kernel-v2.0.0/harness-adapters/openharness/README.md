# OpenHarness adapter

maps executor lifecycle, workspace, events and recovery.

Production enablement requires passing every case in `conformance/conformance-suite.yaml`. Adapter errors are fail-closed; the runtime must not silently downgrade `INTERRUPTED`, `PARTIAL`, permissions, or tool errors.
