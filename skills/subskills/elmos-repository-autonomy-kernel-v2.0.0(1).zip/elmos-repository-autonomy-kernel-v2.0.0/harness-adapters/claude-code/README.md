# Claude Code CLI/Plugin/Hook adapter

supports commands, agents, skills, hooks, MCP and interruption mapping.

Production enablement requires passing every case in `conformance/conformance-suite.yaml`. Adapter errors are fail-closed; the runtime must not silently downgrade `INTERRUPTED`, `PARTIAL`, permissions, or tool errors.
