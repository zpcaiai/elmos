# IMPLEMENTATION TASKS

## P0

- [ ] 将 20 个 Schema 接入 Elmos Schema Registry 并生成 Java/TypeScript/Python 类型。
- [ ] 将 Run/Step/Event/Artifact/Evidence/Lease 数据表合并到主数据库 Migration。
- [ ] 实现 Durable Orchestrator、Authority Kernel、Typed Tool Runtime、Policy Hooks。
- [ ] 实现 Workspace/Environment-owned authority、two-phase secretless sandbox、Lease/Fencing。
- [ ] 实现 Repository Census、Incremental Semantic Index、Semantic IR、ChangeGraph。
- [ ] 实现 Validation DAG、Verification Mesh、Evidence Release Gate、Contract Compatibility。

## P1

- [ ] 实现 Prefix-stable Context、Lazy Tool Loading、Model-state Continuity。
- [ ] 实现 Multi-Agent Worktree Coordinator、Phase-aware Model Router。
- [ ] 实现 Layered Cache、Cost/ETA、Tiered Security、Session Time Travel。
- [ ] 实现 Capability Package Registry 和 Adapter Conformance。

## P2

- [ ] 建立 Demonstration-to-Skill 和 Auto-improvement Inbox。
- [ ] 建立 Skill Curator、Agent Arena、Repository-model ELO。
- [ ] 建立 Repository Gym 和真实大型仓库 Golden Routes。

## Release

- [ ] `/livez`、`/readyz`、`/metrics`、`/version`。
- [ ] 数据库 Migration、备份、恢复和 Replay 演练。
- [ ] P05_DEPLOYMENT_COMPLETE。
- [ ] E1–E5 生产认证。
