# NOTICE

Elmos Repository Autonomy Kernel v2.0.0 是独立设计的架构、契约、Skills、策略、参考代码和测试包。

- 不包含 Claude Code 核心运行时源码。
- 不复制 Anthropic 专有代码。
- 仅吸收公开可观察的一般性工程思想：组件化 Skills、生命周期 Hooks、最小工具权限、仓库先理解后修改、独立验证、高信号 Review、分层安全、Sandbox、恢复、缓存和后台任务治理。
- 第三方 SDK、模型、Harness 和协议适配必须分别完成许可证、商业条款、数据处理与安全审查。
