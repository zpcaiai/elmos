from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]

def test_exact_skill_count_and_files():
 dirs=[p for p in (ROOT/'skills').iterdir() if p.is_dir()]
 assert len(dirs)==31
 assert sum(len([f for f in d.iterdir() if f.is_file()]) for d in dirs)==155
 assert all(len([f for f in d.iterdir() if f.is_file()])==5 for d in dirs)

def test_priority_counts():
 counts={'P0':0,'P1':0,'P2':0}
 for p in (ROOT/'skills').glob('*/SKILL.md'):
  m=re.search(r'^priority:\s*(P[012])$',p.read_text(),re.M); counts[m.group(1)]+=1
 assert counts=={'P0':16,'P1':10,'P2':5}

def test_global_artifact_counts():
 assert len(list((ROOT/'contracts/schemas').glob('*.schema.json')))==20
 assert len(list((ROOT/'db/migration').glob('*.sql')))==4
 assert len(list((ROOT/'contracts/openapi').glob('*.yaml')))==4
 assert len(list((ROOT/'policies/rego').glob('*.rego')))==4
 assert len(list((ROOT/'harness-adapters').glob('*/adapter.yaml')))==7
 assert len(list((ROOT/'golden-routes').glob('*/route.yaml')))==3

def test_all_json_is_valid():
 for p in ROOT.rglob('*.json'): json.loads(p.read_text())

def test_release_gate_present():
 assert 'P05_DEPLOYMENT_COMPLETE' in (ROOT/'PACKAGE_MANIFEST.yaml').read_text()
 assert 'P05_DEPLOYMENT_COMPLETE' in (ROOT/'workflows/repository-autonomy-master.yaml').read_text()

def test_adapter_fail_closed():
 for p in (ROOT/'harness-adapters').glob('*/adapter.yaml'):
  text=p.read_text(); assert 'failureMode: fail-closed' in text; assert 'threadGlobalAuthorityAllowed: false' in text

def test_account_concurrency_and_eta_contract():
 text=(ROOT/'PACKAGE_MANIFEST.yaml').read_text()
 assert 'topLevelAccountConcurrency: 3' in text
 assert 'etaUnit: machine-wall-clock-seconds' in text

def test_no_skill_directory_name_mismatch():
 for p in (ROOT/'skills').glob('*/SKILL.md'):
  m=re.search(r'^id:\s*(.+)$',p.read_text(),re.M)
  assert m.group(1).strip()==p.parent.name
