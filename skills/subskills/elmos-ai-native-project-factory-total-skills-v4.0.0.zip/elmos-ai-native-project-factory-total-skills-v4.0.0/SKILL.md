---
name: elmos-ai-native-project-factory-total-skills
description: Total Skills package for generating, migrating, validating, operating and independently certifying polyglot AI-native systems across frameworks, data stores, protocols and deployment environments.
version: 4.0.0
status: production-implementation-and-certification-contract
route_owner: domain-pack.project-generation
routable: false
---

# Elmos AI-Native Project Factory Total Skills v4.0.0

This package consolidates **362** non-routable implementation Skills and **275** replaceable Adapters under the existing 16 v3 routable entry points. It never creates a ninth Kernel or a shadow source of Goal, semantic, execution, proof or completion truth.

## Required execution discipline

1. Freeze exact Goal, RevisionSet, authority, policy, toolchain, model, data and target versions.
2. Compile repository, AI, protocol and data semantics; emit explicit gaps and Proof Obligations.
3. Prefer deterministic transformations; bound all generative repair.
4. Execute in K7 with tenant isolation, lease/fencing, idempotency and side-effect reconciliation.
5. Run target-native QA and independent K6 verification.
6. Seal evidence and require an independent K8 E0-E5/P05 decision.

## Non-claim

Package PASS is not product PROD, native conformance, customer acceptance or certification.
