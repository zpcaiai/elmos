# Adapter Index — v4.0.0

Total replaceable Adapters: **275**. Adapters never own canonical semantics or completion truth.

## Adapter kinds

| Kind | Count |
|---|---:|
| `agent-framework` | 2 |
| `agent-platform` | 1 |
| `agent-sdk` | 9 |
| `agent-workflow-framework` | 1 |
| `ai-platform` | 1 |
| `ai-ui-sdk` | 1 |
| `analytics-database` | 1 |
| `analytics-dialect` | 1 |
| `analytics-engine` | 1 |
| `analytics-tool` | 1 |
| `api-contract` | 2 |
| `api-fuzzing` | 1 |
| `api-gateway` | 1 |
| `api-runtime` | 1 |
| `api-testing` | 1 |
| `api-workflow` | 1 |
| `artifact-metadata` | 1 |
| `assistant-gateway` | 1 |
| `assurance-standard` | 3 |
| `attestation-standard` | 1 |
| `authorization` | 3 |
| `automation-platform` | 1 |
| `bom-standard` | 2 |
| `build-system` | 1 |
| `cdc-tool` | 1 |
| `certificate-runtime` | 1 |
| `chaos` | 2 |
| `code-quality` | 1 |
| `coding-agent` | 7 |
| `coding-agent-platform` | 1 |
| `coding-harness` | 3 |
| `coding-orchestrator` | 1 |
| `compliance-standard` | 1 |
| `component-runtime` | 1 |
| `contract-testing` | 1 |
| `data-agent-framework` | 2 |
| `data-catalog` | 2 |
| `data-lineage` | 1 |
| `data-orchestration` | 3 |
| `data-quality` | 2 |
| `database-backup` | 1 |
| `database-dialect` | 8 |
| `database-proxy` | 1 |
| `dev-environment` | 1 |
| `distributed-sql` | 7 |
| `distributed-storage` | 1 |
| `document-database` | 1 |
| `durable-runtime` | 1 |
| `edge-inference` | 4 |
| `enterprise-ai-framework` | 2 |
| `eval-observability` | 3 |
| `event-contract` | 2 |
| `event-runtime` | 1 |
| `fault-injection` | 1 |
| `feature-management` | 1 |
| `federated-sql` | 1 |
| `formal-verifier` | 4 |
| `gitops` | 2 |
| `governance-standard` | 1 |
| `graph-database` | 1 |
| `graph-rag` | 2 |
| `graph-runtime` | 2 |
| `hardware-key` | 1 |
| `hermetic-environment` | 1 |
| `identity` | 1 |
| `infrastructure-as-code` | 2 |
| `infrastructure-control-plane` | 1 |
| `interaction-protocol` | 1 |
| `interactive-ui` | 2 |
| `key-value` | 2 |
| `language-compiler` | 6 |
| `language-runtime` | 1 |
| `lightweight-agent-sdk` | 2 |
| `load-testing` | 1 |
| `local-model-serving` | 1 |
| `log-store` | 1 |
| `managed-messaging` | 3 |
| `managed-runtime` | 4 |
| `management-system-standard` | 1 |
| `messaging` | 5 |
| `metrics` | 1 |
| `metrics-store` | 1 |
| `microvm` | 1 |
| `migration-source` | 4 |
| `migration-tool` | 2 |
| `model-gateway` | 2 |
| `model-serving` | 7 |
| `multi-agent-framework` | 2 |
| `mutation-testing` | 2 |
| `network-security` | 1 |
| `object-storage` | 1 |
| `observability` | 1 |
| `observability-ui` | 1 |
| `online-schema-change` | 2 |
| `pipeline-framework` | 1 |
| `plugin-platform` | 1 |
| `plugin-ui` | 1 |
| `policy-engine` | 3 |
| `programming-optimization-framework` | 1 |
| `proof-assistant` | 1 |
| `protocol` | 5 |
| `quality-standard` | 2 |
| `realtime-ai` | 1 |
| `realtime-analytics` | 2 |
| `realtime-transport` | 1 |
| `registry` | 1 |
| `rpc-runtime` | 1 |
| `rpc-schema` | 1 |
| `runtime-security` | 1 |
| `sandbox` | 2 |
| `sandbox-runtime` | 1 |
| `schema-contract` | 1 |
| `schema-migration` | 1 |
| `schema-registry` | 3 |
| `search` | 2 |
| `search-vector` | 1 |
| `secret-key-runtime` | 1 |
| `security-privacy-standard` | 1 |
| `security-scanner` | 1 |
| `service-mesh` | 1 |
| `service-virtualization` | 1 |
| `signing` | 1 |
| `skill-format` | 1 |
| `solution-architecture` | 1 |
| `sql-dialect` | 4 |
| `sql-tool` | 3 |
| `static-analysis` | 2 |
| `stream-processing` | 1 |
| `supply-chain` | 1 |
| `supply-chain-assessment` | 1 |
| `supply-chain-intelligence` | 1 |
| `supply-chain-scanner` | 1 |
| `symbolic-execution` | 1 |
| `table-format` | 3 |
| `telemetry` | 1 |
| `telemetry-pipeline` | 1 |
| `test-runtime` | 1 |
| `time-series` | 3 |
| `tool-protocol` | 1 |
| `tool-runtime` | 1 |
| `trace-store` | 1 |
| `transparency` | 2 |
| `typed-agent-sdk` | 1 |
| `ui-testing` | 1 |
| `update-security` | 1 |
| `vector-database` | 2 |
| `vector-store` | 4 |
| `visual-agent-platform` | 2 |
| `visual-platform` | 1 |
| `visual-rag-platform` | 2 |
| `vulnerability-standard` | 1 |
| `warehouse` | 2 |
| `wasm-runtime` | 2 |
| `wide-column` | 1 |
| `wire-schema` | 2 |
| `workload-identity` | 1 |

## Adapters

- **`a2a`** — Agent2Agent Protocol (`protocol`); profile: `target-adapters/a2a/version-support.yaml`; conformance: `target-adapters/a2a/conformance.yaml`
- **`a2a-v1`** — A2A v1 (`protocol`); profile: `target-adapters/a2a-v1/version-support.yaml`; conformance: `target-adapters/a2a-v1/conformance.yaml`
- **`a2ui-v1`** — A2UI v1 (`interactive-ui`); profile: `target-adapters/a2ui-v1/version-support.yaml`; conformance: `target-adapters/a2ui-v1/conformance.yaml`
- **`acp-v1`** — Agent Client Protocol v1 (`protocol`); profile: `target-adapters/acp-v1/version-support.yaml`; conformance: `target-adapters/acp-v1/conformance.yaml`
- **`ag-ui`** — AG-UI (`interaction-protocol`); profile: `target-adapters/ag-ui/version-support.yaml`; conformance: `target-adapters/ag-ui/conformance.yaml`
- **`agent-skills-standard`** — Agent Skills Standard (`skill-format`); profile: `target-adapters/agent-skills-standard/version-support.yaml`; conformance: `target-adapters/agent-skills-standard/conformance.yaml`
- **`agentic-resource-discovery`** — Agentic Resource Discovery (`registry`); profile: `target-adapters/agentic-resource-discovery/version-support.yaml`; conformance: `target-adapters/agentic-resource-discovery/conformance.yaml`
- **`agno`** — Agno (`agent-platform`); profile: `target-adapters/agno/version-support.yaml`; conformance: `target-adapters/agno/conformance.yaml`
- **`aider`** — Aider (`coding-agent`); profile: `target-adapters/aider/version-support.yaml`; conformance: `target-adapters/aider/conformance.yaml`
- **`airflow`** — Apache Airflow (`data-orchestration`); profile: `target-adapters/airflow/version-support.yaml`; conformance: `target-adapters/airflow/conformance.yaml`
- **`alloy`** — Alloy (`formal-verifier`); profile: `target-adapters/alloy/version-support.yaml`; conformance: `target-adapters/alloy/conformance.yaml`
- **`apache-avro`** — Apache Avro (`wire-schema`); profile: `target-adapters/apache-avro/version-support.yaml`; conformance: `target-adapters/apache-avro/conformance.yaml`
- **`apache-calcite`** — Apache Calcite (`sql-tool`); profile: `target-adapters/apache-calcite/version-support.yaml`; conformance: `target-adapters/apache-calcite/conformance.yaml`
- **`apache-druid`** — Apache Druid (`realtime-analytics`); profile: `target-adapters/apache-druid/version-support.yaml`; conformance: `target-adapters/apache-druid/conformance.yaml`
- **`apache-flink`** — Apache Flink (`stream-processing`); profile: `target-adapters/apache-flink/version-support.yaml`; conformance: `target-adapters/apache-flink/conformance.yaml`
- **`apache-hudi`** — Apache Hudi (`table-format`); profile: `target-adapters/apache-hudi/version-support.yaml`; conformance: `target-adapters/apache-hudi/conformance.yaml`
- **`apache-iceberg`** — Apache Iceberg (`table-format`); profile: `target-adapters/apache-iceberg/version-support.yaml`; conformance: `target-adapters/apache-iceberg/conformance.yaml`
- **`apache-pinot`** — Apache Pinot (`realtime-analytics`); profile: `target-adapters/apache-pinot/version-support.yaml`; conformance: `target-adapters/apache-pinot/conformance.yaml`
- **`apache-pulsar`** — Apache Pulsar (`messaging`); profile: `target-adapters/apache-pulsar/version-support.yaml`; conformance: `target-adapters/apache-pulsar/conformance.yaml`
- **`apache-thrift`** — Apache Thrift (`rpc-schema`); profile: `target-adapters/apache-thrift/version-support.yaml`; conformance: `target-adapters/apache-thrift/conformance.yaml`
- **`apicurio-registry`** — Apicurio Registry (`schema-registry`); profile: `target-adapters/apicurio-registry/version-support.yaml`; conformance: `target-adapters/apicurio-registry/conformance.yaml`
- **`arazzo-1.1`** — Arazzo 1.1 (`api-workflow`); profile: `target-adapters/arazzo-1.1/version-support.yaml`; conformance: `target-adapters/arazzo-1.1/conformance.yaml`
- **`argocd`** — Argo CD (`gitops`); profile: `target-adapters/argocd/version-support.yaml`; conformance: `target-adapters/argocd/conformance.yaml`
- **`arize-phoenix`** — Arize Phoenix (`eval-observability`); profile: `target-adapters/arize-phoenix/version-support.yaml`; conformance: `target-adapters/arize-phoenix/conformance.yaml`
- **`asyncapi-3.1`** — AsyncAPI 3.1 (`event-contract`); profile: `target-adapters/asyncapi-3.1/version-support.yaml`; conformance: `target-adapters/asyncapi-3.1/conformance.yaml`
- **`atlas-schema`** — Atlas Database Schema-as-Code (`schema-migration`); profile: `target-adapters/atlas-schema/version-support.yaml`; conformance: `target-adapters/atlas-schema/conformance.yaml`
- **`autogen-compat`** — Microsoft AutoGen (`migration-source`); profile: `target-adapters/autogen-compat/version-support.yaml`; conformance: `target-adapters/autogen-compat/conformance.yaml`
- **`aws-bedrock-agentcore`** — AWS Bedrock AgentCore (`managed-runtime`); profile: `target-adapters/aws-bedrock-agentcore/version-support.yaml`; conformance: `target-adapters/aws-bedrock-agentcore/conformance.yaml`
- **`aws-msk`** — Amazon MSK (`managed-messaging`); profile: `target-adapters/aws-msk/version-support.yaml`; conformance: `target-adapters/aws-msk/conformance.yaml`
- **`azure-event-hubs`** — Azure Event Hubs (`managed-messaging`); profile: `target-adapters/azure-event-hubs/version-support.yaml`; conformance: `target-adapters/azure-event-hubs/conformance.yaml`
- **`bazel`** — Bazel (`build-system`); profile: `target-adapters/bazel/version-support.yaml`; conformance: `target-adapters/bazel/conformance.yaml`
- **`bentoml`** — BentoML (`model-serving`); profile: `target-adapters/bentoml/version-support.yaml`; conformance: `target-adapters/bentoml/conformance.yaml`
- **`bigquery-dialect`** — Google BigQuery (`database-dialect`); profile: `target-adapters/bigquery-dialect/version-support.yaml`; conformance: `target-adapters/bigquery-dialect/conformance.yaml`
- **`browser-computer-use`** — Browser / computer-use adapters (`tool-runtime`); profile: `target-adapters/browser-computer-use/version-support.yaml`; conformance: `target-adapters/browser-computer-use/conformance.yaml`
- **`buf-schema-registry`** — Buf Schema Registry and Breaking Change (`schema-registry`); profile: `target-adapters/buf-schema-registry/version-support.yaml`; conformance: `target-adapters/buf-schema-registry/conformance.yaml`
- **`camel-ai`** — CAMEL-AI (`multi-agent-framework`); profile: `target-adapters/camel-ai/version-support.yaml`; conformance: `target-adapters/camel-ai/conformance.yaml`
- **`cassandra-scylla`** — Cassandra/ScyllaDB (`wide-column`); profile: `target-adapters/cassandra-scylla/version-support.yaml`; conformance: `target-adapters/cassandra-scylla/conformance.yaml`
- **`cbmc-klee`** — CBMC/KLEE (`symbolic-execution`); profile: `target-adapters/cbmc-klee/version-support.yaml`; conformance: `target-adapters/cbmc-klee/conformance.yaml`
- **`cedar-policy`** — Cedar Policy (`authorization`); profile: `target-adapters/cedar-policy/version-support.yaml`; conformance: `target-adapters/cedar-policy/conformance.yaml`
- **`ceph`** — Ceph (`distributed-storage`); profile: `target-adapters/ceph/version-support.yaml`; conformance: `target-adapters/ceph/conformance.yaml`
- **`cert-manager`** — cert-manager (`certificate-runtime`); profile: `target-adapters/cert-manager/version-support.yaml`; conformance: `target-adapters/cert-manager/conformance.yaml`
- **`chaos-mesh`** — Chaos Mesh (`chaos`); profile: `target-adapters/chaos-mesh/version-support.yaml`; conformance: `target-adapters/chaos-mesh/conformance.yaml`
- **`chatgpt-apps-sdk`** — OpenAI ChatGPT Apps/Plugins SDK (`plugin-ui`); profile: `target-adapters/chatgpt-apps-sdk/version-support.yaml`; conformance: `target-adapters/chatgpt-apps-sdk/conformance.yaml`
- **`chroma`** — Chroma (`vector-database`); profile: `target-adapters/chroma/version-support.yaml`; conformance: `target-adapters/chroma/conformance.yaml`
- **`cilium`** — Cilium (`network-security`); profile: `target-adapters/cilium/version-support.yaml`; conformance: `target-adapters/cilium/conformance.yaml`
- **`claude-code`** — Claude Code (`coding-agent`); profile: `target-adapters/claude-code/version-support.yaml`; conformance: `target-adapters/claude-code/conformance.yaml`
- **`clickhouse-dialect`** — ClickHouse (`database-dialect`); profile: `target-adapters/clickhouse-dialect/version-support.yaml`; conformance: `target-adapters/clickhouse-dialect/conformance.yaml`
- **`clickhouse-server`** — ClickHouse Server (`analytics-database`); profile: `target-adapters/clickhouse-server/version-support.yaml`; conformance: `target-adapters/clickhouse-server/conformance.yaml`
- **`cline-roo`** — Cline / Roo Code (`coding-agent`); profile: `target-adapters/cline-roo/version-support.yaml`; conformance: `target-adapters/cline-roo/conformance.yaml`
- **`cloudevents-1.0`** — CloudEvents 1.0 (`event-contract`); profile: `target-adapters/cloudevents-1.0/version-support.yaml`; conformance: `target-adapters/cloudevents-1.0/conformance.yaml`
- **`cockroachdb`** — CockroachDB (`distributed-sql`); profile: `target-adapters/cockroachdb/version-support.yaml`; conformance: `target-adapters/cockroachdb/conformance.yaml`
- **`codeql`** — CodeQL (`static-analysis`); profile: `target-adapters/codeql/version-support.yaml`; conformance: `target-adapters/codeql/conformance.yaml`
- **`codex`** — OpenAI Codex (`coding-agent`); profile: `target-adapters/codex/version-support.yaml`; conformance: `target-adapters/codex/conformance.yaml`
- **`confluent-schema-registry`** — Schema Registry (`schema-registry`); profile: `target-adapters/confluent-schema-registry/version-support.yaml`; conformance: `target-adapters/confluent-schema-registry/conformance.yaml`
- **`continue`** — Continue (`coding-agent`); profile: `target-adapters/continue/version-support.yaml`; conformance: `target-adapters/continue/conformance.yaml`
- **`coreml`** — Apple Core ML (`edge-inference`); profile: `target-adapters/coreml/version-support.yaml`; conformance: `target-adapters/coreml/conformance.yaml`
- **`coze-studio`** — Coze Studio (`visual-agent-platform`); profile: `target-adapters/coze-studio/version-support.yaml`; conformance: `target-adapters/coze-studio/conformance.yaml`
- **`crewai`** — CrewAI (`multi-agent-framework`); profile: `target-adapters/crewai/version-support.yaml`; conformance: `target-adapters/crewai/conformance.yaml`
- **`crossplane`** — Crossplane (`infrastructure-control-plane`); profile: `target-adapters/crossplane/version-support.yaml`; conformance: `target-adapters/crossplane/conformance.yaml`
- **`cyclonedx-v1.7`** — CycloneDX v1.7 (`bom-standard`); profile: `target-adapters/cyclonedx-v1.7/version-support.yaml`; conformance: `target-adapters/cyclonedx-v1.7/conformance.yaml`
- **`dafny`** — Dafny (`formal-verifier`); profile: `target-adapters/dafny/version-support.yaml`; conformance: `target-adapters/dafny/conformance.yaml`
- **`dagster`** — Dagster (`data-orchestration`); profile: `target-adapters/dagster/version-support.yaml`; conformance: `target-adapters/dagster/conformance.yaml`
- **`dameng`** — Dameng Database (`sql-dialect`); profile: `target-adapters/dameng/version-support.yaml`; conformance: `target-adapters/dameng/conformance.yaml`
- **`databricks-agents`** — Databricks Agents (`managed-runtime`); profile: `target-adapters/databricks-agents/version-support.yaml`; conformance: `target-adapters/databricks-agents/conformance.yaml`
- **`databricks-sql`** — Databricks SQL (`warehouse`); profile: `target-adapters/databricks-sql/version-support.yaml`; conformance: `target-adapters/databricks-sql/conformance.yaml`
- **`datahub`** — DataHub (`data-catalog`); profile: `target-adapters/datahub/version-support.yaml`; conformance: `target-adapters/datahub/conformance.yaml`
- **`db2-dialect`** — IBM Db2 (`database-dialect`); profile: `target-adapters/db2-dialect/version-support.yaml`; conformance: `target-adapters/db2-dialect/conformance.yaml`
- **`dbt`** — dbt (`analytics-tool`); profile: `target-adapters/dbt/version-support.yaml`; conformance: `target-adapters/dbt/conformance.yaml`
- **`debezium`** — Debezium (`cdc-tool`); profile: `target-adapters/debezium/version-support.yaml`; conformance: `target-adapters/debezium/conformance.yaml`
- **`deepseek-harness`** — DeepSeek Harness (`coding-harness`); profile: `target-adapters/deepseek-harness/version-support.yaml`; conformance: `target-adapters/deepseek-harness/conformance.yaml`
- **`delta-lake`** — Delta Lake (`table-format`); profile: `target-adapters/delta-lake/version-support.yaml`; conformance: `target-adapters/delta-lake/conformance.yaml`
- **`devcontainer`** — Development Containers (`dev-environment`); profile: `target-adapters/devcontainer/version-support.yaml`; conformance: `target-adapters/devcontainer/conformance.yaml`
- **`dify`** — Dify (`visual-platform`); profile: `target-adapters/dify/version-support.yaml`; conformance: `target-adapters/dify/conformance.yaml`
- **`dotnet-roslyn`** — Roslyn / .NET (`language-compiler`); profile: `target-adapters/dotnet-roslyn/version-support.yaml`; conformance: `target-adapters/dotnet-roslyn/conformance.yaml`
- **`dspy`** — DSPy (`programming-optimization-framework`); profile: `target-adapters/dspy/version-support.yaml`; conformance: `target-adapters/dspy/conformance.yaml`
- **`duckdb`** — DuckDB (`analytics-dialect`); profile: `target-adapters/duckdb/version-support.yaml`; conformance: `target-adapters/duckdb/conformance.yaml`
- **`dynamodb`** — Amazon DynamoDB (`key-value`); profile: `target-adapters/dynamodb/version-support.yaml`; conformance: `target-adapters/dynamodb/conformance.yaml`
- **`elasticsearch`** — Elasticsearch (`search`); profile: `target-adapters/elasticsearch/version-support.yaml`; conformance: `target-adapters/elasticsearch/conformance.yaml`
- **`envoy-gateway`** — Envoy Gateway (`api-gateway`); profile: `target-adapters/envoy-gateway/version-support.yaml`; conformance: `target-adapters/envoy-gateway/conformance.yaml`
- **`falco`** — Falco (`runtime-security`); profile: `target-adapters/falco/version-support.yaml`; conformance: `target-adapters/falco/conformance.yaml`
- **`fastgpt`** — FastGPT (`visual-rag-platform`); profile: `target-adapters/fastgpt/version-support.yaml`; conformance: `target-adapters/fastgpt/conformance.yaml`
- **`firecracker`** — Firecracker (`microvm`); profile: `target-adapters/firecracker/version-support.yaml`; conformance: `target-adapters/firecracker/conformance.yaml`
- **`flowise-compat`** — Flowise (`migration-source`); profile: `target-adapters/flowise-compat/version-support.yaml`; conformance: `target-adapters/flowise-compat/conformance.yaml`
- **`flux`** — Flux CD (`gitops`); profile: `target-adapters/flux/version-support.yaml`; conformance: `target-adapters/flux/conformance.yaml`
- **`flyway`** — Flyway (`migration-tool`); profile: `target-adapters/flyway/version-support.yaml`; conformance: `target-adapters/flyway/conformance.yaml`
- **`gatekeeper`** — OPA Gatekeeper (`policy-engine`); profile: `target-adapters/gatekeeper/version-support.yaml`; conformance: `target-adapters/gatekeeper/conformance.yaml`
- **`gaussdb`** — GaussDB/openGauss (`sql-dialect`); profile: `target-adapters/gaussdb/version-support.yaml`; conformance: `target-adapters/gaussdb/conformance.yaml`
- **`gemini-cli`** — Gemini CLI (`coding-agent`); profile: `target-adapters/gemini-cli/version-support.yaml`; conformance: `target-adapters/gemini-cli/conformance.yaml`
- **`gh-ost`** — gh-ost (`online-schema-change`); profile: `target-adapters/gh-ost/version-support.yaml`; conformance: `target-adapters/gh-ost/conformance.yaml`
- **`go-compiler`** — Go toolchain (`language-compiler`); profile: `target-adapters/go-compiler/version-support.yaml`; conformance: `target-adapters/go-compiler/conformance.yaml`
- **`google-adk-go`** — Google ADK (`agent-sdk`); profile: `target-adapters/google-adk-go/version-support.yaml`; conformance: `target-adapters/google-adk-go/conformance.yaml`
- **`google-adk-java`** — Google ADK (`agent-sdk`); profile: `target-adapters/google-adk-java/version-support.yaml`; conformance: `target-adapters/google-adk-java/conformance.yaml`
- **`google-adk-python`** — Google ADK (`agent-sdk`); profile: `target-adapters/google-adk-python/version-support.yaml`; conformance: `target-adapters/google-adk-python/conformance.yaml`
- **`google-adk-typescript`** — Google ADK (`agent-sdk`); profile: `target-adapters/google-adk-typescript/version-support.yaml`; conformance: `target-adapters/google-adk-typescript/conformance.yaml`
- **`google-gemini-enterprise-agent-platform`** — Google Enterprise Agent Platform (`managed-runtime`); profile: `target-adapters/google-gemini-enterprise-agent-platform/version-support.yaml`; conformance: `target-adapters/google-gemini-enterprise-agent-platform/conformance.yaml`
- **`google-pubsub`** — Google Cloud Pub/Sub (`managed-messaging`); profile: `target-adapters/google-pubsub/version-support.yaml`; conformance: `target-adapters/google-pubsub/conformance.yaml`
- **`grafana`** — Grafana (`observability-ui`); profile: `target-adapters/grafana/version-support.yaml`; conformance: `target-adapters/grafana/conformance.yaml`
- **`grafeas`** — Grafeas Metadata API (`artifact-metadata`); profile: `target-adapters/grafeas/version-support.yaml`; conformance: `target-adapters/grafeas/conformance.yaml`
- **`graphql`** — GraphQL (`api-runtime`); profile: `target-adapters/graphql/version-support.yaml`; conformance: `target-adapters/graphql/conformance.yaml`
- **`great-expectations`** — Great Expectations (`data-quality`); profile: `target-adapters/great-expectations/version-support.yaml`; conformance: `target-adapters/great-expectations/conformance.yaml`
- **`grpc`** — gRPC/Protobuf (`rpc-runtime`); profile: `target-adapters/grpc/version-support.yaml`; conformance: `target-adapters/grpc/conformance.yaml`
- **`guac-supply-chain`** — GUAC Supply-chain Graph (`supply-chain-intelligence`); profile: `target-adapters/guac-supply-chain/version-support.yaml`; conformance: `target-adapters/guac-supply-chain/conformance.yaml`
- **`gvisor`** — gVisor (`sandbox`); profile: `target-adapters/gvisor/version-support.yaml`; conformance: `target-adapters/gvisor/conformance.yaml`
- **`hashicorp-vault`** — HashiCorp Vault (`secret-key-runtime`); profile: `target-adapters/hashicorp-vault/version-support.yaml`; conformance: `target-adapters/hashicorp-vault/conformance.yaml`
- **`haystack-python`** — Haystack (`pipeline-framework`); profile: `target-adapters/haystack-python/version-support.yaml`; conformance: `target-adapters/haystack-python/conformance.yaml`
- **`huggingface-tgi`** — Hugging Face TGI (`model-serving`); profile: `target-adapters/huggingface-tgi/version-support.yaml`; conformance: `target-adapters/huggingface-tgi/conformance.yaml`
- **`ietf-rats-rfc9334`** — IETF RATS RFC 9334 (`attestation-standard`); profile: `target-adapters/ietf-rats-rfc9334/version-support.yaml`; conformance: `target-adapters/ietf-rats-rfc9334/conformance.yaml`
- **`in-toto-attestation`** — in-toto Attestation (`assurance-standard`); profile: `target-adapters/in-toto-attestation/version-support.yaml`; conformance: `target-adapters/in-toto-attestation/conformance.yaml`
- **`influxdb`** — InfluxDB (`time-series`); profile: `target-adapters/influxdb/version-support.yaml`; conformance: `target-adapters/influxdb/conformance.yaml`
- **`iso-iec-25010-25040`** — ISO/IEC SQuaRE 25010/25040 (`quality-standard`); profile: `target-adapters/iso-iec-25010-25040/version-support.yaml`; conformance: `target-adapters/iso-iec-25010-25040/conformance.yaml`
- **`iso-iec-42001-42006`** — ISO/IEC 42001 + 42006 (`management-system-standard`); profile: `target-adapters/iso-iec-42001-42006/version-support.yaml`; conformance: `target-adapters/iso-iec-42001-42006/conformance.yaml`
- **`istio`** — Istio (`service-mesh`); profile: `target-adapters/istio/version-support.yaml`; conformance: `target-adapters/istio/conformance.yaml`
- **`java-21-compiler`** — OpenJDK javac / Java 21 (`language-compiler`); profile: `target-adapters/java-21-compiler/version-support.yaml`; conformance: `target-adapters/java-21-compiler/conformance.yaml`
- **`jooq-parser`** — jOOQ Parser/Interpreter (`sql-tool`); profile: `target-adapters/jooq-parser/version-support.yaml`; conformance: `target-adapters/jooq-parser/conformance.yaml`
- **`json-schema-2020-12`** — JSON Schema Draft 2020-12 (`schema-contract`); profile: `target-adapters/json-schema-2020-12/version-support.yaml`; conformance: `target-adapters/json-schema-2020-12/conformance.yaml`
- **`k6`** — Grafana k6 (`load-testing`); profile: `target-adapters/k6/version-support.yaml`; conformance: `target-adapters/k6/conformance.yaml`
- **`kafka`** — Apache Kafka (`messaging`); profile: `target-adapters/kafka/version-support.yaml`; conformance: `target-adapters/kafka/conformance.yaml`
- **`kata-containers`** — Kata Containers (`sandbox`); profile: `target-adapters/kata-containers/version-support.yaml`; conformance: `target-adapters/kata-containers/conformance.yaml`
- **`keycloak`** — Keycloak (`identity`); profile: `target-adapters/keycloak/version-support.yaml`; conformance: `target-adapters/keycloak/conformance.yaml`
- **`kingbase`** — KingbaseES (`sql-dialect`); profile: `target-adapters/kingbase/version-support.yaml`; conformance: `target-adapters/kingbase/conformance.yaml`
- **`kotlin-analysis`** — Kotlin Analysis API (`language-compiler`); profile: `target-adapters/kotlin-analysis/version-support.yaml`; conformance: `target-adapters/kotlin-analysis/conformance.yaml`
- **`kserve`** — KServe (`model-serving`); profile: `target-adapters/kserve/version-support.yaml`; conformance: `target-adapters/kserve/conformance.yaml`
- **`kyverno`** — Kyverno (`policy-engine`); profile: `target-adapters/kyverno/version-support.yaml`; conformance: `target-adapters/kyverno/conformance.yaml`
- **`langchain-python`** — LangChain (`agent-sdk`); profile: `target-adapters/langchain-python/version-support.yaml`; conformance: `target-adapters/langchain-python/conformance.yaml`
- **`langchain-typescript`** — LangChain (`agent-sdk`); profile: `target-adapters/langchain-typescript/version-support.yaml`; conformance: `target-adapters/langchain-typescript/conformance.yaml`
- **`langchain4j`** — LangChain4j (`enterprise-ai-framework`); profile: `target-adapters/langchain4j/version-support.yaml`; conformance: `target-adapters/langchain4j/conformance.yaml`
- **`langflow`** — Langflow (`visual-agent-platform`); profile: `target-adapters/langflow/version-support.yaml`; conformance: `target-adapters/langflow/conformance.yaml`
- **`langgraph-python`** — LangGraph (`graph-runtime`); profile: `target-adapters/langgraph-python/version-support.yaml`; conformance: `target-adapters/langgraph-python/conformance.yaml`
- **`langgraph-typescript`** — LangGraph (`graph-runtime`); profile: `target-adapters/langgraph-typescript/version-support.yaml`; conformance: `target-adapters/langgraph-typescript/conformance.yaml`
- **`langsmith`** — LangSmith (`eval-observability`); profile: `target-adapters/langsmith/version-support.yaml`; conformance: `target-adapters/langsmith/conformance.yaml`
- **`lean4`** — Lean 4 (`proof-assistant`); profile: `target-adapters/lean4/version-support.yaml`; conformance: `target-adapters/lean4/conformance.yaml`
- **`liquibase`** — Liquibase (`migration-tool`); profile: `target-adapters/liquibase/version-support.yaml`; conformance: `target-adapters/liquibase/conformance.yaml`
- **`litellm`** — LiteLLM (`model-gateway`); profile: `target-adapters/litellm/version-support.yaml`; conformance: `target-adapters/litellm/conformance.yaml`
- **`litmuschaos`** — LitmusChaos (`chaos`); profile: `target-adapters/litmuschaos/version-support.yaml`; conformance: `target-adapters/litmuschaos/conformance.yaml`
- **`llama-cpp`** — llama.cpp (`edge-inference`); profile: `target-adapters/llama-cpp/version-support.yaml`; conformance: `target-adapters/llama-cpp/conformance.yaml`
- **`llama-stack`** — Llama Stack (`ai-platform`); profile: `target-adapters/llama-stack/version-support.yaml`; conformance: `target-adapters/llama-stack/conformance.yaml`
- **`llamaindex-python`** — LlamaIndex (`data-agent-framework`); profile: `target-adapters/llamaindex-python/version-support.yaml`; conformance: `target-adapters/llamaindex-python/conformance.yaml`
- **`llamaindex-typescript`** — LlamaIndex (`data-agent-framework`); profile: `target-adapters/llamaindex-typescript/version-support.yaml`; conformance: `target-adapters/llamaindex-typescript/conformance.yaml`
- **`loki`** — Grafana Loki (`log-store`); profile: `target-adapters/loki/version-support.yaml`; conformance: `target-adapters/loki/conformance.yaml`
- **`mastra`** — Mastra (`agent-workflow-framework`); profile: `target-adapters/mastra/version-support.yaml`; conformance: `target-adapters/mastra/conformance.yaml`
- **`mcp`** — Model Context Protocol (`protocol`); profile: `target-adapters/mcp/version-support.yaml`; conformance: `target-adapters/mcp/conformance.yaml`
- **`mcp-2026-07-28`** — MCP 2026-07-28 (`protocol`); profile: `target-adapters/mcp-2026-07-28/version-support.yaml`; conformance: `target-adapters/mcp-2026-07-28/conformance.yaml`
- **`mcp-apps`** — MCP Apps (`interactive-ui`); profile: `target-adapters/mcp-apps/version-support.yaml`; conformance: `target-adapters/mcp-apps/conformance.yaml`
- **`microsoft-agent-framework-dotnet`** — Microsoft Agent Framework (`agent-framework`); profile: `target-adapters/microsoft-agent-framework-dotnet/version-support.yaml`; conformance: `target-adapters/microsoft-agent-framework-dotnet/conformance.yaml`
- **`microsoft-agent-framework-python`** — Microsoft Agent Framework (`agent-framework`); profile: `target-adapters/microsoft-agent-framework-python/version-support.yaml`; conformance: `target-adapters/microsoft-agent-framework-python/conformance.yaml`
- **`microsoft-foundry-agent-service`** — Microsoft Foundry Agent Service (`managed-runtime`); profile: `target-adapters/microsoft-foundry-agent-service/version-support.yaml`; conformance: `target-adapters/microsoft-foundry-agent-service/conformance.yaml`
- **`microsoft-graphrag`** — Microsoft GraphRAG (`graph-rag`); profile: `target-adapters/microsoft-graphrag/version-support.yaml`; conformance: `target-adapters/microsoft-graphrag/conformance.yaml`
- **`milvus`** — Milvus (`vector-store`); profile: `target-adapters/milvus/version-support.yaml`; conformance: `target-adapters/milvus/conformance.yaml`
- **`mimir`** — Grafana Mimir (`metrics-store`); profile: `target-adapters/mimir/version-support.yaml`; conformance: `target-adapters/mimir/conformance.yaml`
- **`minio`** — MinIO (`object-storage`); profile: `target-adapters/minio/version-support.yaml`; conformance: `target-adapters/minio/conformance.yaml`
- **`mlflow-genai`** — MLflow GenAI (`eval-observability`); profile: `target-adapters/mlflow-genai/version-support.yaml`; conformance: `target-adapters/mlflow-genai/conformance.yaml`
- **`mongodb`** — MongoDB (`document-database`); profile: `target-adapters/mongodb/version-support.yaml`; conformance: `target-adapters/mongodb/conformance.yaml`
- **`mutmut`** — mutmut Python Mutation Testing (`mutation-testing`); profile: `target-adapters/mutmut/version-support.yaml`; conformance: `target-adapters/mutmut/conformance.yaml`
- **`mysql-mariadb-dialect`** — MySQL / MariaDB (`database-dialect`); profile: `target-adapters/mysql-mariadb-dialect/version-support.yaml`; conformance: `target-adapters/mysql-mariadb-dialect/conformance.yaml`
- **`n8n-ai`** — n8n AI (`automation-platform`); profile: `target-adapters/n8n-ai/version-support.yaml`; conformance: `target-adapters/n8n-ai/conformance.yaml`
- **`nats-jetstream`** — NATS JetStream (`messaging`); profile: `target-adapters/nats-jetstream/version-support.yaml`; conformance: `target-adapters/nats-jetstream/conformance.yaml`
- **`neo4j-database`** — Neo4j Database (`graph-database`); profile: `target-adapters/neo4j-database/version-support.yaml`; conformance: `target-adapters/neo4j-database/conformance.yaml`
- **`neo4j-graphrag`** — Neo4j GraphRAG (`graph-rag`); profile: `target-adapters/neo4j-graphrag/version-support.yaml`; conformance: `target-adapters/neo4j-graphrag/conformance.yaml`
- **`nist-ai-rmf-genai`** — NIST AI RMF + Generative AI Profile (`governance-standard`); profile: `target-adapters/nist-ai-rmf-genai/version-support.yaml`; conformance: `target-adapters/nist-ai-rmf-genai/conformance.yaml`
- **`nist-csf-privacy-ssdf`** — NIST CSF / Privacy Framework / SSDF (`security-privacy-standard`); profile: `target-adapters/nist-csf-privacy-ssdf/version-support.yaml`; conformance: `target-adapters/nist-csf-privacy-ssdf/conformance.yaml`
- **`nix`** — Nix (`hermetic-environment`); profile: `target-adapters/nix/version-support.yaml`; conformance: `target-adapters/nix/conformance.yaml`
- **`nvidia-triton`** — NVIDIA Triton Inference Server (`model-serving`); profile: `target-adapters/nvidia-triton/version-support.yaml`; conformance: `target-adapters/nvidia-triton/conformance.yaml`
- **`oceanbase-mysql`** — OceanBase MySQL mode (`distributed-sql`); profile: `target-adapters/oceanbase-mysql/version-support.yaml`; conformance: `target-adapters/oceanbase-mysql/conformance.yaml`
- **`oceanbase-oracle`** — OceanBase Oracle mode (`distributed-sql`); profile: `target-adapters/oceanbase-oracle/version-support.yaml`; conformance: `target-adapters/oceanbase-oracle/conformance.yaml`
- **`ollama`** — Ollama (`local-model-serving`); profile: `target-adapters/ollama/version-support.yaml`; conformance: `target-adapters/ollama/conformance.yaml`
- **`onnx-runtime`** — ONNX Runtime (`edge-inference`); profile: `target-adapters/onnx-runtime/version-support.yaml`; conformance: `target-adapters/onnx-runtime/conformance.yaml`
- **`opa`** — Open Policy Agent (`policy-engine`); profile: `target-adapters/opa/version-support.yaml`; conformance: `target-adapters/opa/conformance.yaml`
- **`openai-agents-python`** — OpenAI Agents SDK (`agent-sdk`); profile: `target-adapters/openai-agents-python/version-support.yaml`; conformance: `target-adapters/openai-agents-python/conformance.yaml`
- **`openai-agents-typescript`** — OpenAI Agents SDK (`agent-sdk`); profile: `target-adapters/openai-agents-typescript/version-support.yaml`; conformance: `target-adapters/openai-agents-typescript/conformance.yaml`
- **`openai-plugins`** — OpenAI Plugins (`plugin-platform`); profile: `target-adapters/openai-plugins/version-support.yaml`; conformance: `target-adapters/openai-plugins/conformance.yaml`
- **`openai-realtime`** — OpenAI Realtime API (`realtime-ai`); profile: `target-adapters/openai-realtime/version-support.yaml`; conformance: `target-adapters/openai-realtime/conformance.yaml`
- **`openapi-3.1`** — OpenAPI 3.1 (`api-contract`); profile: `target-adapters/openapi-3.1/version-support.yaml`; conformance: `target-adapters/openapi-3.1/conformance.yaml`
- **`openapi-3.2`** — OpenAPI 3.2 (`api-contract`); profile: `target-adapters/openapi-3.2/version-support.yaml`; conformance: `target-adapters/openapi-3.2/conformance.yaml`
- **`openapi-tools`** — OpenAPI tool adapters (`tool-protocol`); profile: `target-adapters/openapi-tools/version-support.yaml`; conformance: `target-adapters/openapi-tools/conformance.yaml`
- **`openclaw`** — OpenClaw (`assistant-gateway`); profile: `target-adapters/openclaw/version-support.yaml`; conformance: `target-adapters/openclaw/conformance.yaml`
- **`opencode`** — OpenCode (`coding-agent`); profile: `target-adapters/opencode/version-support.yaml`; conformance: `target-adapters/opencode/conformance.yaml`
- **`openfeature`** — OpenFeature (`feature-management`); profile: `target-adapters/openfeature/version-support.yaml`; conformance: `target-adapters/openfeature/conformance.yaml`
- **`openfga`** — OpenFGA (`authorization`); profile: `target-adapters/openfga/version-support.yaml`; conformance: `target-adapters/openfga/conformance.yaml`
- **`openhands`** — OpenHands (`coding-agent-platform`); profile: `target-adapters/openhands/version-support.yaml`; conformance: `target-adapters/openhands/conformance.yaml`
- **`openharness`** — OpenHarness (`coding-harness`); profile: `target-adapters/openharness/version-support.yaml`; conformance: `target-adapters/openharness/conformance.yaml`
- **`openinference-compatible`** — OpenInference Compatible (`telemetry`); profile: `target-adapters/openinference-compatible/version-support.yaml`; conformance: `target-adapters/openinference-compatible/conformance.yaml`
- **`openlineage`** — OpenLineage (`data-lineage`); profile: `target-adapters/openlineage/version-support.yaml`; conformance: `target-adapters/openlineage/conformance.yaml`
- **`openmetadata`** — OpenMetadata (`data-catalog`); profile: `target-adapters/openmetadata/version-support.yaml`; conformance: `target-adapters/openmetadata/conformance.yaml`
- **`openrouter`** — OpenRouter (`model-gateway`); profile: `target-adapters/openrouter/version-support.yaml`; conformance: `target-adapters/openrouter/conformance.yaml`
- **`opensearch`** — OpenSearch (`search`); profile: `target-adapters/opensearch/version-support.yaml`; conformance: `target-adapters/opensearch/conformance.yaml`
- **`openssf-scorecard`** — OpenSSF Scorecard (`supply-chain-assessment`); profile: `target-adapters/openssf-scorecard/version-support.yaml`; conformance: `target-adapters/openssf-scorecard/conformance.yaml`
- **`opentelemetry`** — OpenTelemetry (`observability`); profile: `target-adapters/opentelemetry/version-support.yaml`; conformance: `target-adapters/opentelemetry/conformance.yaml`
- **`oracle-dialect`** — Oracle Database (`database-dialect`); profile: `target-adapters/oracle-dialect/version-support.yaml`; conformance: `target-adapters/oracle-dialect/conformance.yaml`
- **`oscal-v1.1.2`** — NIST OSCAL v1.1.2 (`compliance-standard`); profile: `target-adapters/oscal-v1.1.2/version-support.yaml`; conformance: `target-adapters/oscal-v1.1.2/conformance.yaml`
- **`osv-openvex`** — OSV + OpenVEX (`vulnerability-standard`); profile: `target-adapters/osv-openvex/version-support.yaml`; conformance: `target-adapters/osv-openvex/conformance.yaml`
- **`otel-collector`** — OpenTelemetry Collector (`telemetry-pipeline`); profile: `target-adapters/otel-collector/version-support.yaml`; conformance: `target-adapters/otel-collector/conformance.yaml`
- **`pact`** — Pact (`contract-testing`); profile: `target-adapters/pact/version-support.yaml`; conformance: `target-adapters/pact/conformance.yaml`
- **`pgbackrest`** — pgBackRest (`database-backup`); profile: `target-adapters/pgbackrest/version-support.yaml`; conformance: `target-adapters/pgbackrest/conformance.yaml`
- **`pgbouncer`** — PgBouncer (`database-proxy`); profile: `target-adapters/pgbouncer/version-support.yaml`; conformance: `target-adapters/pgbouncer/conformance.yaml`
- **`pgvector`** — pgvector (`vector-store`); profile: `target-adapters/pgvector/version-support.yaml`; conformance: `target-adapters/pgvector/conformance.yaml`
- **`pi`** — Pi coding agent (`coding-harness`); profile: `target-adapters/pi/version-support.yaml`; conformance: `target-adapters/pi/conformance.yaml`
- **`pinecone`** — Pinecone (`vector-database`); profile: `target-adapters/pinecone/version-support.yaml`; conformance: `target-adapters/pinecone/conformance.yaml`
- **`pitest`** — PIT Mutation Testing (`mutation-testing`); profile: `target-adapters/pitest/version-support.yaml`; conformance: `target-adapters/pitest/conformance.yaml`
- **`pkcs11-hsm`** — PKCS#11 HSM (`hardware-key`); profile: `target-adapters/pkcs11-hsm/version-support.yaml`; conformance: `target-adapters/pkcs11-hsm/conformance.yaml`
- **`playwright`** — Playwright (`ui-testing`); profile: `target-adapters/playwright/version-support.yaml`; conformance: `target-adapters/playwright/conformance.yaml`
- **`postgresql-dialect`** — PostgreSQL (`database-dialect`); profile: `target-adapters/postgresql-dialect/version-support.yaml`; conformance: `target-adapters/postgresql-dialect/conformance.yaml`
- **`prefect`** — Prefect (`data-orchestration`); profile: `target-adapters/prefect/version-support.yaml`; conformance: `target-adapters/prefect/conformance.yaml`
- **`prometheus`** — Prometheus (`metrics`); profile: `target-adapters/prometheus/version-support.yaml`; conformance: `target-adapters/prometheus/conformance.yaml`
- **`protobuf-editions`** — Protocol Buffers Editions (`wire-schema`); profile: `target-adapters/protobuf-editions/version-support.yaml`; conformance: `target-adapters/protobuf-editions/conformance.yaml`
- **`pt-online-schema-change`** — Percona pt-online-schema-change (`online-schema-change`); profile: `target-adapters/pt-online-schema-change/version-support.yaml`; conformance: `target-adapters/pt-online-schema-change/conformance.yaml`
- **`pulumi`** — Pulumi (`infrastructure-as-code`); profile: `target-adapters/pulumi/version-support.yaml`; conformance: `target-adapters/pulumi/conformance.yaml`
- **`pydanticai-python`** — PydanticAI (`typed-agent-sdk`); profile: `target-adapters/pydanticai-python/version-support.yaml`; conformance: `target-adapters/pydanticai-python/conformance.yaml`
- **`python-3-semantic`** — CPython / Python 3 (`language-runtime`); profile: `target-adapters/python-3-semantic/version-support.yaml`; conformance: `target-adapters/python-3-semantic/conformance.yaml`
- **`qdrant`** — Qdrant (`vector-store`); profile: `target-adapters/qdrant/version-support.yaml`; conformance: `target-adapters/qdrant/conformance.yaml`
- **`questdb`** — QuestDB (`time-series`); profile: `target-adapters/questdb/version-support.yaml`; conformance: `target-adapters/questdb/conformance.yaml`
- **`qwen-agent`** — Qwen-Agent (`agent-sdk`); profile: `target-adapters/qwen-agent/version-support.yaml`; conformance: `target-adapters/qwen-agent/conformance.yaml`
- **`rabbitmq`** — RabbitMQ (`messaging`); profile: `target-adapters/rabbitmq/version-support.yaml`; conformance: `target-adapters/rabbitmq/conformance.yaml`
- **`ragflow`** — RAGFlow (`visual-rag-platform`); profile: `target-adapters/ragflow/version-support.yaml`; conformance: `target-adapters/ragflow/conformance.yaml`
- **`ray-serve`** — Ray Serve (`model-serving`); profile: `target-adapters/ray-serve/version-support.yaml`; conformance: `target-adapters/ray-serve/conformance.yaml`
- **`redis`** — Redis (`key-value`); profile: `target-adapters/redis/version-support.yaml`; conformance: `target-adapters/redis/conformance.yaml`
- **`redpanda`** — Redpanda (`messaging`); profile: `target-adapters/redpanda/version-support.yaml`; conformance: `target-adapters/redpanda/conformance.yaml`
- **`redshift`** — Amazon Redshift (`warehouse`); profile: `target-adapters/redshift/version-support.yaml`; conformance: `target-adapters/redshift/conformance.yaml`
- **`rekor-transparency-log`** — Sigstore Rekor (`transparency`); profile: `target-adapters/rekor-transparency-log/version-support.yaml`; conformance: `target-adapters/rekor-transparency-log/conformance.yaml`
- **`rest-assured`** — REST Assured (`api-testing`); profile: `target-adapters/rest-assured/version-support.yaml`; conformance: `target-adapters/rest-assured/conformance.yaml`
- **`rustc-mir`** — rustc / MIR (`language-compiler`); profile: `target-adapters/rustc-mir/version-support.yaml`; conformance: `target-adapters/rustc-mir/conformance.yaml`
- **`sacm-v2.3`** — OMG SACM v2.3 (`assurance-standard`); profile: `target-adapters/sacm-v2.3/version-support.yaml`; conformance: `target-adapters/sacm-v2.3/conformance.yaml`
- **`schemathesis`** — Schemathesis (`api-fuzzing`); profile: `target-adapters/schemathesis/version-support.yaml`; conformance: `target-adapters/schemathesis/conformance.yaml`
- **`scitt-rfc9943`** — IETF SCITT Architecture RFC 9943 (`transparency`); profile: `target-adapters/scitt-rfc9943/version-support.yaml`; conformance: `target-adapters/scitt-rfc9943/conformance.yaml`
- **`semantic-kernel-compat`** — Microsoft Semantic Kernel (`migration-source`); profile: `target-adapters/semantic-kernel-compat/version-support.yaml`; conformance: `target-adapters/semantic-kernel-compat/conformance.yaml`
- **`semgrep`** — Semgrep (`static-analysis`); profile: `target-adapters/semgrep/version-support.yaml`; conformance: `target-adapters/semgrep/conformance.yaml`
- **`sglang`** — SGLang (`model-serving`); profile: `target-adapters/sglang/version-support.yaml`; conformance: `target-adapters/sglang/conformance.yaml`
- **`sigstore-cosign-v3`** — Sigstore Cosign v3 (`signing`); profile: `target-adapters/sigstore-cosign-v3/version-support.yaml`; conformance: `target-adapters/sigstore-cosign-v3/conformance.yaml`
- **`sigstore-slsa`** — Sigstore/SLSA (`supply-chain`); profile: `target-adapters/sigstore-slsa/version-support.yaml`; conformance: `target-adapters/sigstore-slsa/conformance.yaml`
- **`singlestore`** — SingleStore (`distributed-sql`); profile: `target-adapters/singlestore/version-support.yaml`; conformance: `target-adapters/singlestore/conformance.yaml`
- **`slsa-v1.2`** — SLSA v1.2 (`assurance-standard`); profile: `target-adapters/slsa-v1.2/version-support.yaml`; conformance: `target-adapters/slsa-v1.2/conformance.yaml`
- **`smolagents`** — smolagents (`lightweight-agent-sdk`); profile: `target-adapters/smolagents/version-support.yaml`; conformance: `target-adapters/smolagents/conformance.yaml`
- **`snowflake-dialect`** — Snowflake (`database-dialect`); profile: `target-adapters/snowflake-dialect/version-support.yaml`; conformance: `target-adapters/snowflake-dialect/conformance.yaml`
- **`soda-core`** — Soda Core (`data-quality`); profile: `target-adapters/soda-core/version-support.yaml`; conformance: `target-adapters/soda-core/conformance.yaml`
- **`sonarqube`** — SonarQube (`code-quality`); profile: `target-adapters/sonarqube/version-support.yaml`; conformance: `target-adapters/sonarqube/conformance.yaml`
- **`spark-sql`** — Apache Spark SQL (`analytics-engine`); profile: `target-adapters/spark-sql/version-support.yaml`; conformance: `target-adapters/spark-sql/conformance.yaml`
- **`spdx-v3.0`** — SPDX v3.0 (`bom-standard`); profile: `target-adapters/spdx-v3.0/version-support.yaml`; conformance: `target-adapters/spdx-v3.0/conformance.yaml`
- **`spicedb`** — SpiceDB (`authorization`); profile: `target-adapters/spicedb/version-support.yaml`; conformance: `target-adapters/spicedb/conformance.yaml`
- **`spiffe-spire`** — SPIFFE/SPIRE (`workload-identity`); profile: `target-adapters/spiffe-spire/version-support.yaml`; conformance: `target-adapters/spiffe-spire/conformance.yaml`
- **`spring-ai-java`** — Spring AI (`enterprise-ai-framework`); profile: `target-adapters/spring-ai-java/version-support.yaml`; conformance: `target-adapters/spring-ai-java/conformance.yaml`
- **`sqlglot`** — SQLGlot (`sql-tool`); profile: `target-adapters/sqlglot/version-support.yaml`; conformance: `target-adapters/sqlglot/conformance.yaml`
- **`sqlite`** — SQLite (`sql-dialect`); profile: `target-adapters/sqlite/version-support.yaml`; conformance: `target-adapters/sqlite/conformance.yaml`
- **`sqlserver-dialect`** — Microsoft SQL Server (`database-dialect`); profile: `target-adapters/sqlserver-dialect/version-support.yaml`; conformance: `target-adapters/sqlserver-dialect/conformance.yaml`
- **`strands-agents`** — Strands Agents (`lightweight-agent-sdk`); profile: `target-adapters/strands-agents/version-support.yaml`; conformance: `target-adapters/strands-agents/conformance.yaml`
- **`swarm-compat`** — OpenAI Swarm (`migration-source`); profile: `target-adapters/swarm-compat/version-support.yaml`; conformance: `target-adapters/swarm-compat/conformance.yaml`
- **`syft-grype`** — Syft and Grype (`supply-chain-scanner`); profile: `target-adapters/syft-grype/version-support.yaml`; conformance: `target-adapters/syft-grype/conformance.yaml`
- **`symphony`** — OpenAI Symphony (`coding-orchestrator`); profile: `target-adapters/symphony/version-support.yaml`; conformance: `target-adapters/symphony/conformance.yaml`
- **`tempo`** — Grafana Tempo (`trace-store`); profile: `target-adapters/tempo/version-support.yaml`; conformance: `target-adapters/tempo/conformance.yaml`
- **`temporal-durable-execution`** — Temporal Durable Execution (`durable-runtime`); profile: `target-adapters/temporal-durable-execution/version-support.yaml`; conformance: `target-adapters/temporal-durable-execution/conformance.yaml`
- **`tensorflow-lite`** — TensorFlow Lite (`edge-inference`); profile: `target-adapters/tensorflow-lite/version-support.yaml`; conformance: `target-adapters/tensorflow-lite/conformance.yaml`
- **`terraform`** — Terraform (`infrastructure-as-code`); profile: `target-adapters/terraform/version-support.yaml`; conformance: `target-adapters/terraform/conformance.yaml`
- **`testcontainers`** — Testcontainers (`test-runtime`); profile: `target-adapters/testcontainers/version-support.yaml`; conformance: `target-adapters/testcontainers/conformance.yaml`
- **`tidb`** — TiDB (`distributed-sql`); profile: `target-adapters/tidb/version-support.yaml`; conformance: `target-adapters/tidb/conformance.yaml`
- **`timescaledb`** — TimescaleDB (`time-series`); profile: `target-adapters/timescaledb/version-support.yaml`; conformance: `target-adapters/timescaledb/conformance.yaml`
- **`tla-plus`** — TLA+ (`formal-verifier`); profile: `target-adapters/tla-plus/version-support.yaml`; conformance: `target-adapters/tla-plus/conformance.yaml`
- **`toxiproxy`** — Toxiproxy (`fault-injection`); profile: `target-adapters/toxiproxy/version-support.yaml`; conformance: `target-adapters/toxiproxy/conformance.yaml`
- **`trino-presto`** — Trino/Presto (`federated-sql`); profile: `target-adapters/trino-presto/version-support.yaml`; conformance: `target-adapters/trino-presto/conformance.yaml`
- **`trivy`** — Trivy (`security-scanner`); profile: `target-adapters/trivy/version-support.yaml`; conformance: `target-adapters/trivy/conformance.yaml`
- **`tuf-v1.0.33`** — The Update Framework v1.0.33 (`update-security`); profile: `target-adapters/tuf-v1.0.33/version-support.yaml`; conformance: `target-adapters/tuf-v1.0.33/conformance.yaml`
- **`typescript-compiler`** — TypeScript Compiler API (`language-compiler`); profile: `target-adapters/typescript-compiler/version-support.yaml`; conformance: `target-adapters/typescript-compiler/conformance.yaml`
- **`universal-rag`** — Elmos Universal RAG (`solution-architecture`); profile: `target-adapters/universal-rag/version-support.yaml`; conformance: `target-adapters/universal-rag/conformance.yaml`
- **`vercel-ai-sdk`** — Vercel AI SDK (`ai-ui-sdk`); profile: `target-adapters/vercel-ai-sdk/version-support.yaml`; conformance: `target-adapters/vercel-ai-sdk/conformance.yaml`
- **`vespa`** — Vespa (`search-vector`); profile: `target-adapters/vespa/version-support.yaml`; conformance: `target-adapters/vespa/conformance.yaml`
- **`vitess`** — Vitess (`distributed-sql`); profile: `target-adapters/vitess/version-support.yaml`; conformance: `target-adapters/vitess/conformance.yaml`
- **`vllm`** — vLLM (`model-serving`); profile: `target-adapters/vllm/version-support.yaml`; conformance: `target-adapters/vllm/conformance.yaml`
- **`wasi-preview2`** — WASI Preview 2 (`sandbox-runtime`); profile: `target-adapters/wasi-preview2/version-support.yaml`; conformance: `target-adapters/wasi-preview2/conformance.yaml`
- **`wasm-component-model`** — WebAssembly Component Model and WIT (`component-runtime`); profile: `target-adapters/wasm-component-model/version-support.yaml`; conformance: `target-adapters/wasm-component-model/conformance.yaml`
- **`wasmedge`** — WasmEdge (`wasm-runtime`); profile: `target-adapters/wasmedge/version-support.yaml`; conformance: `target-adapters/wasmedge/conformance.yaml`
- **`wasmtime`** — Wasmtime (`wasm-runtime`); profile: `target-adapters/wasmtime/version-support.yaml`; conformance: `target-adapters/wasmtime/conformance.yaml`
- **`wcag-2.2`** — W3C WCAG 2.2 (`quality-standard`); profile: `target-adapters/wcag-2.2/version-support.yaml`; conformance: `target-adapters/wcag-2.2/conformance.yaml`
- **`weaviate`** — Weaviate (`vector-store`); profile: `target-adapters/weaviate/version-support.yaml`; conformance: `target-adapters/weaviate/conformance.yaml`
- **`webhook`** — Webhook delivery (`event-runtime`); profile: `target-adapters/webhook/version-support.yaml`; conformance: `target-adapters/webhook/conformance.yaml`
- **`webrtc-sip`** — WebRTC/SIP (`realtime-transport`); profile: `target-adapters/webrtc-sip/version-support.yaml`; conformance: `target-adapters/webrtc-sip/conformance.yaml`
- **`wiremock`** — WireMock (`service-virtualization`); profile: `target-adapters/wiremock/version-support.yaml`; conformance: `target-adapters/wiremock/conformance.yaml`
- **`yugabytedb`** — YugabyteDB (`distributed-sql`); profile: `target-adapters/yugabytedb/version-support.yaml`; conformance: `target-adapters/yugabytedb/conformance.yaml`
- **`z3`** — Z3 SMT Solver (`formal-verifier`); profile: `target-adapters/z3/version-support.yaml`; conformance: `target-adapters/z3/conformance.yaml`
