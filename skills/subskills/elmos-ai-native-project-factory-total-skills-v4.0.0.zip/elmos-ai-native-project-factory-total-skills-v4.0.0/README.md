# Elmos AI-Native Project Factory — Total Skills v4.0.0

## Package result

This is the **single consolidated package** for generating, migrating, validating, operating and independently certifying AI-native projects across languages, frameworks, protocols, databases, data platforms and deployment environments.

```text
8 canonical K1–K8 kernels
+ existing 5 Domain Packs and 3 cross-cutting products
+ 362 non-routable implementation Skills
+ 275 replaceable Adapters
+ 0 new routable entry points
= one proof-driven project-generation extension
```

The package preserves the existing **16 v3 routable entry points**. Every component uses `route_owner: domain-pack.project-generation` and `routable: false`; no Skill, Adapter, model, worker or UI becomes a shadow owner of Goal, semantic truth, execution authority, proof or completion.

## Inventory

| Asset | Count |
|---|---:|
| Skills | 362 |
| Per-Skill contract/implementation files | 4,706 |
| Adapters | 275 |
| Per-Adapter files | 2,200 |
| JSON Schemas / examples | 171 / 171 |
| OpenAPI / AsyncAPI contracts | 11 |
| Durable workflows | 58 |
| Rego policies / policy fixtures | 56 / 56 |
| PostgreSQL migrations | 24 |
| Commercial Golden Routes | 38 |
| Implementation batches / tasks | 51 / 502 |
| Reference modules / tests | 47 / 182 |
| Unique normalized implementation signatures | 362 |
| Native fixture files | 43 |
| Architecture and implementation documents | 54 |

## Capability fabrics

1. **AI-Native Project Factory** — Dify, RAG, LangChain/LangGraph, Spring AI, OpenAI Agents, Google ADK, Microsoft Agent Framework, Pi, Harness, OpenClaw and other target families.
2. **Portable Skills, Plugins and Agent Protocols** — Agent Skills IR, OpenAI Plugins/ChatGPT Apps, MCP 2026, A2A v1, ACP, A2UI/AG-UI and cross-host conformance.
3. **Polyglot Deep Semantic Routes** — compiler-native frontends, language/framework profiles, ABI/FFI, concurrency memory models, serialization, source maps, Wasm Component/WIT and target backends.
4. **Database and Data Semantic Fabric** — SQL dialects/routines, ORM, relational/NoSQL/search/graph/vector/time-series/stream/lakehouse IR, CDC, schema evolution, dual execution, cutover and rollback.
5. **API, Event and Distributed Consistency** — OpenAPI 3.2, Arazzo 1.1, AsyncAPI, CloudEvents, gRPC/Protobuf, GraphQL, webhook, schema registry, ordering, idempotency, saga and distributed invariants.
6. **Model Lifecycle and Serving** — model artifact provenance, quantization/hardware profiles, inference engines, KServe/Triton/Ray Serve, canary/shadow/rollback, realtime, voice, multimodal and edge AI.
7. **Knowledge, Retrieval and Memory** — GraphRAG, knowledge graphs, source trust, federated retrieval, citations, embedding/reranker lifecycle, memory consolidation, conflict and deletion semantics.
8. **Full-spectrum Automated QA** — Proof-to-Validation DAG, covering arrays, contract/integration/E2E, differential, record/replay, property/metamorphic/mutation/fuzz, chaos, statistical performance, flake governance and counterexample promotion.
9. **Formal Assurance** — verifier portfolio routing, SMT/symbolic execution, TLA+/Alloy, protocol model checking, probabilistic verification, Lean/Dafny bridges and structured assurance cases.
10. **Zero-trust and Supply-chain Security** — workload identity, mTLS/delegation, confidential computing, eBPF runtime behavior, SBOM/AIBOM, SLSA/Sigstore/in-toto/TUF, SCITT transparency, VEX/KEV and admission attestation.
11. **Platform Engineering and SRE** — GitOps, IaC, Kubernetes operators, multi-region failover, SLO/error budgets, DR, environment parity, observability privacy/cardinality, supportability and incident automation.
12. **Commercial Productization and Governance** — multi-tenant SaaS, billing/entitlements, accessibility/i18n, analytics/experiments, legal/compliance profiles, post-market monitoring, audit export, residual-risk and waiver governance.
13. **Safe Learning and Improvement** — production feedback to eval datasets, benchmark contamination controls, arena/model routing, isolated self-improvement, canary promotion and independent recertification.
14. **Independent E0–E5/P05 Certification Authority** — clean-room build, native conformance lab, customer holdout, WORM/Merkle evidence, HSM key ceremony, certificate admission, transparency, drift revocation and re-certification.

## Skill and Adapter contract depth

Each Skill contains 13 files:

```text
agent-skills/runtime/<skill>/
├── SKILL.md
├── contract.yaml
├── implementation.yaml
├── domain-model.yaml
├── api-contract.yaml
├── version-support.yaml
├── native-test-matrix.yaml
├── threat-model.yaml
├── observability.yaml
├── acceptance.yaml
├── evidence.yaml
├── references/IMPLEMENTATION_GUIDE.md
└── scripts/validate_artifacts.py
```

Each Adapter contains eight files covering identity, capability map, lowering, exact-version support, native conformance, threat model and deployment profile.

## Install

```bash
# Small canonical foundation: 40 Skills
./install.sh --repo /path/to/elmos --host both --profile core

# Production-priority closure including dependencies: 306 Skills
./install.sh --repo /path/to/elmos --host both --profile p0

# Entire package: 362 Skills
./install.sh --repo /path/to/elmos --host both --profile all
```

Supported hosts are Codex (`.agents/skills/`), Claude Code (`.claude/skills/`) or both. Installation writes a hash-bound receipt. Uninstall removes only unchanged installed files, preserves local modifications and restores force-install backups when safe.

## Validate

```bash
./validate.sh
python3 scripts/validate_archive.py ../elmos-ai-native-project-factory-total-skills-v4.0.0.zip
python3 scripts/validate_archive.py ../elmos-ai-native-project-factory-total-skills-v4.0.0.tar.gz
```

The strict package validator checks inventory, frontmatter, K1–K8 ownership, dependency DAGs, implementation depth, native probes, Schema examples, workflows, policies, migration ordering, Golden Routes, traceability, secrets, Python/shell syntax and 182 executable reference tests.

## Recommended first production implementation wave

```text
1. Freeze v3 ownership, RevisionSet, Evidence and Certification contracts.
2. Implement Requirement/AI-SIR → LangGraph Python + Spring AI Java.
3. Implement Oracle/SQL Server/MySQL → PostgreSQL DB-SIR and dual execution.
4. Add one NoSQL/vector/lakehouse route with snapshot+CDC+schema-evolution evidence.
5. Connect Proof Obligation Graph → Validation DAG → counterexample repair.
6. Establish a clean-room Certification Lab, WORM evidence and K8 signer.
7. Certify one >500k LOC customer-like repository route before broadening targets.
```

## Production boundary

Package validation proves that this distributable contract is structurally coherent, deeply specified, safely installable and backed by executable reference semantics. It does **not** prove that the Elmos source repository has implemented the runtime or that any external framework, compiler, database, cloud, protocol, model or customer route is certified.

The following remain evidence-gated in the target environment:

- live PostgreSQL 17 migrations, RLS, backup/restore and recovery;
- OPA/Rego execution;
- real compiler/framework/database/protocol/cloud native conformance;
- images, SBOM/AIBOM, signatures, provenance, runtime attestation and Kubernetes admission;
- multi-region load/soak/chaos/DR;
- customer hidden holdouts, E5 and P05;
- independent external legal, regulatory, ISO or accredited certification.
