# Skill Index — v4.0.0

Total component Skills: **362**. All are `routable: false` and owned by `domain-pack.project-generation`.

## Capability groups

| Group | Count |
|---|---:|
| `adapter-sdk` | 1 |
| `architecture-api-first` | 1 |
| `architecture-boundaries` | 1 |
| `architecture-commercial` | 1 |
| `architecture-decisions` | 1 |
| `architecture-documentation` | 1 |
| `architecture-domain` | 1 |
| `architecture-enterprise-identity` | 1 |
| `architecture-marketplace` | 1 |
| `architecture-regeneration` | 1 |
| `architecture-saas` | 1 |
| `assurance` | 7 |
| `assurance-scitt-transparency` | 1 |
| `benchmark-certification` | 1 |
| `certification` | 1 |
| `certification-acceptance` | 1 |
| `certification-assurance-case` | 1 |
| `certification-audit` | 1 |
| `certification-authority` | 2 |
| `certification-change-control` | 1 |
| `certification-deployment` | 1 |
| `certification-deployment-admission` | 1 |
| `certification-evidence` | 1 |
| `certification-governance` | 3 |
| `certification-key-management` | 1 |
| `certification-lab` | 2 |
| `certification-lifecycle` | 1 |
| `certification-risk` | 1 |
| `certification-transparency` | 1 |
| `commercial-assurance` | 3 |
| `compatibility` | 2 |
| `control` | 2 |
| `data-cdc-assurance` | 1 |
| `data-distributed-consistency` | 1 |
| `data-distributed-sql` | 1 |
| `data-extension` | 1 |
| `data-governance` | 2 |
| `data-graph-ir` | 1 |
| `data-lakehouse-ir` | 1 |
| `data-lifecycle` | 1 |
| `data-lineage` | 1 |
| `data-nosql-ir` | 1 |
| `data-online-migration` | 1 |
| `data-privacy` | 1 |
| `data-quality` | 1 |
| `data-query-optimization` | 1 |
| `data-resilience` | 1 |
| `data-route-planning` | 1 |
| `data-routine-service-extraction` | 1 |
| `data-search-ir` | 1 |
| `data-security-equivalence` | 1 |
| `data-stream-ir` | 1 |
| `data-vector-ir` | 1 |
| `data-vector-migration` | 1 |
| `data-warehouse-certification` | 1 |
| `database-assurance` | 3 |
| `database-certification` | 1 |
| `database-data-migration` | 1 |
| `database-ir` | 4 |
| `database-migration` | 1 |
| `database-performance` | 1 |
| `database-profile` | 1 |
| `database-transformation` | 1 |
| `deployment` | 1 |
| `enterprise-edge-certification` | 1 |
| `evaluation` | 4 |
| `evaluation-drift` | 2 |
| `event-assurance` | 1 |
| `event-consistency` | 1 |
| `event-contract-generation` | 1 |
| `event-contract-ir` | 1 |
| `event-protocol-gateway` | 1 |
| `event-replay` | 1 |
| `event-saga` | 1 |
| `event-schema-registry` | 1 |
| `event-service-virtualization` | 1 |
| `event-webhook` | 1 |
| `evidence` | 1 |
| `finops` | 1 |
| `finops-estimation` | 1 |
| `finops-optimization` | 1 |
| `finops-provider-capacity` | 1 |
| `formal-counterexample` | 1 |
| `formal-distributed` | 1 |
| `formal-probabilistic` | 1 |
| `formal-proof-assistant` | 1 |
| `formal-protocol` | 1 |
| `formal-routing` | 1 |
| `formal-symbolic` | 1 |
| `formal-tcb` | 1 |
| `golden-route` | 10 |
| `governance` | 7 |
| `governance-content-safety` | 1 |
| `governance-continuous-compliance` | 1 |
| `governance-continuous-control` | 1 |
| `governance-data-residency` | 1 |
| `governance-impact` | 1 |
| `governance-incident-reporting` | 1 |
| `governance-post-market` | 1 |
| `governance-procurement` | 1 |
| `governance-regulatory-monitor` | 1 |
| `identity-authorization` | 3 |
| `identity-discovery` | 2 |
| `import` | 1 |
| `incident-certification` | 1 |
| `incident-response` | 1 |
| `interaction-approval-ux` | 1 |
| `interaction-explainability` | 1 |
| `interaction-human-factors` | 1 |
| `interaction-ui` | 2 |
| `knowledge-citation` | 1 |
| `knowledge-federated-retrieval` | 1 |
| `knowledge-graph` | 1 |
| `knowledge-graphrag` | 1 |
| `knowledge-index-lifecycle` | 1 |
| `knowledge-memory-lifecycle` | 1 |
| `knowledge-temporal` | 1 |
| `knowledge-trust` | 1 |
| `learning-arena` | 1 |
| `learning-canary` | 1 |
| `learning-feedback` | 1 |
| `learning-promotion` | 1 |
| `learning-safety` | 1 |
| `learning-telemetry` | 1 |
| `lifecycle` | 3 |
| `model-artifact-provenance` | 1 |
| `model-cache` | 1 |
| `model-capacity` | 1 |
| `model-computer-use` | 1 |
| `model-edge` | 1 |
| `model-fallback-assurance` | 1 |
| `model-license` | 1 |
| `model-optimization` | 1 |
| `model-realtime` | 1 |
| `model-release` | 1 |
| `model-retrieval-lifecycle` | 1 |
| `model-routing-optimization` | 1 |
| `model-serving-generation` | 1 |
| `model-serving-profile` | 1 |
| `model-training` | 1 |
| `multi-agent` | 3 |
| `observability` | 2 |
| `operations-certification` | 1 |
| `operations-performance` | 1 |
| `operations-readiness` | 1 |
| `operations-reliability` | 1 |
| `operations-resilience` | 1 |
| `planning` | 3 |
| `platform-build-cache` | 1 |
| `platform-capacity` | 1 |
| `platform-dependency-lifecycle` | 1 |
| `platform-dev-environment` | 1 |
| `platform-finops` | 1 |
| `platform-gitops` | 1 |
| `platform-golden-path` | 1 |
| `platform-iac` | 1 |
| `platform-incident` | 1 |
| `platform-kubernetes-operator` | 1 |
| `platform-multiregion` | 1 |
| `platform-observability` | 1 |
| `platform-openfeature-delivery` | 1 |
| `platform-support` | 1 |
| `platform-sustainability` | 1 |
| `platform-sustainable-ai` | 1 |
| `polyglot-assurance` | 2 |
| `polyglot-backend` | 1 |
| `polyglot-certification` | 1 |
| `polyglot-concurrency` | 1 |
| `polyglot-contract-evolution` | 1 |
| `polyglot-framework` | 1 |
| `polyglot-frontend` | 1 |
| `polyglot-lifecycle` | 1 |
| `polyglot-lineage` | 1 |
| `polyglot-native-boundary` | 1 |
| `polyglot-operability` | 1 |
| `polyglot-performance` | 1 |
| `polyglot-route` | 1 |
| `polyglot-rules` | 1 |
| `polyglot-scale` | 1 |
| `polyglot-semantic-profile` | 1 |
| `polyglot-toolchain` | 1 |
| `polyglot-value-semantics` | 1 |
| `polyglot-wasm-component` | 1 |
| `polyglot-wire` | 1 |
| `product-analytics` | 1 |
| `product-localization` | 1 |
| `product-operator-portal` | 1 |
| `product-quality` | 3 |
| `productivity-assurance` | 1 |
| `prompt-engineering` | 3 |
| `protocol` | 1 |
| `protocol-acp` | 1 |
| `protocol-bridge` | 1 |
| `protocol-openai-apps` | 1 |
| `protocol-openapi-arazzo` | 1 |
| `protocol-runtime` | 1 |
| `protocol-sdk-codegen` | 1 |
| `protocol-tool-quality` | 1 |
| `protocol-versioning` | 1 |
| `qa-assurance` | 1 |
| `qa-benchmark-integrity` | 1 |
| `qa-chaos-governance` | 1 |
| `qa-client-platform` | 1 |
| `qa-contract` | 1 |
| `qa-coverage` | 1 |
| `qa-deep-verification` | 1 |
| `qa-diagnostics` | 1 |
| `qa-differential` | 1 |
| `qa-environment` | 1 |
| `qa-execution` | 1 |
| `qa-fixtures` | 1 |
| `qa-learning` | 1 |
| `qa-orchestration` | 1 |
| `qa-performance` | 1 |
| `qa-planning` | 1 |
| `qa-protocol-fuzz` | 1 |
| `qa-quality` | 1 |
| `qa-record-replay` | 1 |
| `qa-resilience` | 1 |
| `qa-selection` | 1 |
| `qa-static-analysis` | 1 |
| `qa-statistical` | 1 |
| `qa-test-data` | 1 |
| `qa-ui` | 1 |
| `quality-certification` | 1 |
| `rag-data-plane` | 3 |
| `rag-retrieval` | 1 |
| `runtime-admission` | 1 |
| `runtime-platform` | 10 |
| `runtime-safety` | 3 |
| `security-assurance` | 1 |
| `security-authorization` | 1 |
| `security-confidential` | 1 |
| `security-egress` | 1 |
| `security-generated-code` | 1 |
| `security-policy-audit` | 1 |
| `security-rag-memory` | 2 |
| `security-redteam` | 1 |
| `security-runtime` | 1 |
| `security-secrets` | 1 |
| `security-supply-chain` | 3 |
| `security-tenant-crypto` | 1 |
| `security-wasi-sandbox` | 1 |
| `security-zero-trust` | 1 |
| `semantic-ir` | 11 |
| `skill-plugin-compiler` | 2 |
| `specification` | 1 |
| `supply-chain-attestation` | 1 |
| `supply-chain-compliance` | 1 |
| `supply-chain-update` | 1 |
| `supply-chain-vulnerability` | 1 |
| `target-generator` | 25 |
| `transformation` | 4 |

## Skills

### `elmos-a2a-v1-agent-card-trust-compiler`

- **Purpose:** Compile, sign, verify, rotate and revoke A2A v1 Agent Cards that bind identity, capabilities, interfaces, tenant scope and trust evidence.
- **Group/Priority/Risk:** `identity-discovery` / `P0` / `critical`
- **Kernels:** K1, K3, K6, K8
- **Dependencies:** `elmos-ai-tool-protocol-compiler`, `elmos-ai-security-governance-compiler`
- **Path:** `agent-skills/runtime/elmos-a2a-v1-agent-card-trust-compiler/SKILL.md`

### `elmos-accessibility-conformance-certifier`

- **Purpose:** Generate and independently verify WCAG 2.2 AA-oriented accessibility evidence for web, generated UI, operator consoles and agent-created interactive components.
- **Group/Priority/Risk:** `product-quality` / `P0` / `critical`
- **Kernels:** K1, K5, K6, K8
- **Dependencies:** `elmos-ai-quality-model-evaluation-compiler`, `elmos-mcp-apps-a2ui-generator`
- **Path:** `agent-skills/runtime/elmos-accessibility-conformance-certifier/SKILL.md`

### `elmos-admin-operator-portal-generator`

- **Purpose:** Generate tenant administration, run control, approvals, evidence, cost, incident and certification views with least privilege and auditability.
- **Group/Priority/Risk:** `product-operator-portal` / `P1` / `critical`
- **Kernels:** K1, K2, K3, K5, K6
- **Dependencies:** `elmos-ai-operator-console-generator`, `elmos-enterprise-identity-sso-scim-generator`
- **Path:** `agent-skills/runtime/elmos-admin-operator-portal-generator/SKILL.md`

### `elmos-adversarial-model-tool-memory-redteam-orchestrator`

- **Purpose:** Coordinate multi-stage attacks across prompts, retrieval, memory, tools, protocols, identity and side effects with reproducible campaigns.
- **Group/Priority/Risk:** `security-redteam` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-prompt-tool-security-redteam`, `elmos-rag-memory-poisoning-verifier`
- **Path:** `agent-skills/runtime/elmos-adversarial-model-tool-memory-redteam-orchestrator/SKILL.md`

### `elmos-agent-approval-workflow-ux-generator`

- **Purpose:** Generate clear preview, diff, risk, evidence, confirmation, expiry, rejection and recovery interfaces for human-controlled actions.
- **Group/Priority/Risk:** `interaction-approval-ux` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-human-oversight-consent-contract-compiler`, `elmos-agent-human-ux-safety-verifier`
- **Path:** `agent-skills/runtime/elmos-agent-approval-workflow-ux-generator/SKILL.md`

### `elmos-agent-arena-route-model-evaluator`

- **Purpose:** Run controlled multi-agent/model/route competitions on hidden tasks using independent oracles, cost, safety and reproducibility evidence.
- **Group/Priority/Risk:** `learning-arena` / `P1` / `high`
- **Kernels:** K1, K2, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-judge-calibration-stochastic-assurance`, `elmos-benchmark-contamination-leakage-detector`
- **Path:** `agent-skills/runtime/elmos-agent-arena-route-model-evaluator/SKILL.md`

### `elmos-agent-client-protocol-acp-adapter-generator`

- **Purpose:** Generate ACP v1 agents and clients for local/remote coding-agent integration with sessions, capabilities, tool-call updates, permissions and extensibility.
- **Group/Priority/Risk:** `protocol-acp` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-target-coding-agent-harness-family-generator`, `elmos-ai-tool-protocol-compiler`
- **Path:** `agent-skills/runtime/elmos-agent-client-protocol-acp-adapter-generator/SKILL.md`

### `elmos-agent-human-ux-safety-verifier`

- **Purpose:** Verify that agent interfaces communicate uncertainty, intent, side effects, approvals, reversibility and recovery without dark patterns or misleading automation.
- **Group/Priority/Risk:** `interaction-ui` / `P1` / `high`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-human-oversight-consent-contract-compiler`, `elmos-mcp-apps-a2ui-generator`
- **Path:** `agent-skills/runtime/elmos-agent-human-ux-safety-verifier/SKILL.md`

### `elmos-agent-memory-consolidation-forgetting-controller`

- **Purpose:** Consolidate episodic memory into semantic/procedural memory while preserving provenance, uncertainty, consent, retention and deliberate forgetting.
- **Group/Priority/Risk:** `knowledge-memory-lifecycle` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-context-memory-governor`, `elmos-ai-retention-erasure-verifier`
- **Path:** `agent-skills/runtime/elmos-agent-memory-consolidation-forgetting-controller/SKILL.md`

### `elmos-agent-protocol-version-negotiation-governor`

- **Purpose:** Govern exact MCP, A2A, ACP and UI protocol versions, extensions, downgrade, deprecation and evidence invalidation.
- **Group/Priority/Risk:** `protocol-versioning` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-mcp-2026-profile-compiler`, `elmos-a2a-v1-agent-card-trust-compiler`
- **Path:** `agent-skills/runtime/elmos-agent-protocol-version-negotiation-governor/SKILL.md`

### `elmos-agent-registry-resource-discovery-governor`

- **Purpose:** Discover, verify, policy-filter, pin and continuously monitor agents, Skills, tools, MCP servers, models and related agentic resources.
- **Group/Priority/Risk:** `identity-discovery` / `P0` / `critical`
- **Kernels:** K2, K3, K6, K7
- **Dependencies:** `elmos-a2a-v1-agent-card-trust-compiler`, `elmos-ai-target-portfolio-planner`
- **Path:** `agent-skills/runtime/elmos-agent-registry-resource-discovery-governor/SKILL.md`

### `elmos-agent-skill-ir-compiler`

- **Purpose:** Compile portable Agent Skill packages into a host-neutral semantic IR covering trigger intent, instructions, tools, resources, authority, tests, evidence and version constraints.
- **Group/Priority/Risk:** `skill-plugin-compiler` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6
- **Dependencies:** `elmos-ai-sir-compiler`, `elmos-ai-tool-protocol-compiler`
- **Path:** `agent-skills/runtime/elmos-agent-skill-ir-compiler/SKILL.md`

### `elmos-agent-skill-mcp-supply-chain-certifier`

- **Purpose:** Certify Skills, plugins and MCP servers with publisher identity, signatures, SBOM/AIBOM, reproducible builds, permission diffs and static/dynamic behavior evidence.
- **Group/Priority/Risk:** `security-supply-chain` / `P0` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-agent-skill-ir-compiler`, `elmos-ai-supply-chain-performance-resilience-certifier`
- **Path:** `agent-skills/runtime/elmos-agent-skill-mcp-supply-chain-certifier/SKILL.md`

### `elmos-agent-skill-portability-emitter`

- **Purpose:** Lower Skill IR into Agent Skills, Codex, Claude Code, Pi, OpenClaw, Gemini CLI, Continue and OpenCode packages while preserving semantics and recording every host-specific gap.
- **Group/Priority/Risk:** `skill-plugin-compiler` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-agent-skill-ir-compiler`, `elmos-ai-target-adapter-sdk`
- **Path:** `agent-skills/runtime/elmos-agent-skill-portability-emitter/SKILL.md`

### `elmos-agent-skill-trigger-evaluator`

- **Purpose:** Measure whether a Skill activates for the right requests and improves task success without unacceptable false activation, latency or token overhead.
- **Group/Priority/Risk:** `evaluation` / `P0` / `high`
- **Kernels:** K1, K4, K6, K8
- **Dependencies:** `elmos-agent-skill-ir-compiler`, `elmos-ai-assurance-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-agent-skill-trigger-evaluator/SKILL.md`

### `elmos-agent-workload-delegated-identity-controller`

- **Purpose:** Separate human, logical agent, runtime workload and downstream delegated identities using short-lived workload credentials and policy-bound token exchange.
- **Group/Priority/Risk:** `identity-authorization` / `P0` / `critical`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-ai-security-governance-compiler`, `elmos-ai-tool-authority-policy-generator`
- **Path:** `agent-skills/runtime/elmos-agent-workload-delegated-identity-controller/SKILL.md`

### `elmos-ai-agent-contract-compiler`

- **Purpose:** Represent agent roles, delegation, handoff, supervision, termination, permissions, context and responsibility boundaries independently of a target SDK.
- **Group/Priority/Risk:** `semantic-ir` / `P0` / `critical`
- **Kernels:** K3, K4, K6
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-agent-contract-compiler/SKILL.md`

### `elmos-ai-artifact-provenance-packager`

- **Purpose:** Package source inputs, AI-SIR, target profiles, generated revisions, traces, test results, policies, approvals and limits into a tamper-evident evidence graph.
- **Group/Priority/Risk:** `evidence` / `P0` / `critical`
- **Kernels:** K6, K7, K8
- **Dependencies:** `elmos-ai-config-secret-materializer`
- **Path:** `agent-skills/runtime/elmos-ai-artifact-provenance-packager/SKILL.md`

### `elmos-ai-assurance-contract-compiler`

- **Purpose:** Compile golden data sets, trace invariants, output schemas, security properties, retrieval metrics, differential tolerances, release thresholds and accepted evidence classes.
- **Group/Priority/Risk:** `semantic-ir` / `P0` / `critical`
- **Kernels:** K1, K3, K6, K8
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-assurance-contract-compiler/SKILL.md`

### `elmos-ai-bom-provenance-generator`

- **Purpose:** Generate a signed AI BOM covering models, datasets, prompts, Skills, tools, MCP servers, adapters, libraries, images, policies and evidence lineage.
- **Group/Priority/Risk:** `security-supply-chain` / `P0` / `critical`
- **Kernels:** K2, K6, K8
- **Dependencies:** `elmos-ai-artifact-provenance-packager`, `elmos-agent-skill-mcp-supply-chain-certifier`
- **Path:** `agent-skills/runtime/elmos-ai-bom-provenance-generator/SKILL.md`

### `elmos-ai-cache-semantic-consistency-verifier`

- **Purpose:** Verify prompt, model, tool, retrieval, build and transformation caches against semantic keys, tenant isolation, freshness and evidence invalidation.
- **Group/Priority/Risk:** `runtime-safety` / `P1` / `critical`
- **Kernels:** K2, K6, K7
- **Dependencies:** `elmos-ai-runtime-operations-compiler`, `elmos-ai-provider-behavior-fingerprint-recertifier`
- **Path:** `agent-skills/runtime/elmos-ai-cache-semantic-consistency-verifier/SKILL.md`

### `elmos-ai-capability-negotiator`

- **Purpose:** Resolve required semantics against versioned target capability profiles, producing supported, emulated, conditional, unsupported and blocked decisions with explicit lowering obligations.
- **Group/Priority/Risk:** `planning` / `P0` / `critical`
- **Kernels:** K3, K4, K6, K8
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-capability-negotiator/SKILL.md`

### `elmos-ai-compatibility-drift-monitor`

- **Purpose:** Detect target/API/DSL/plugin/runtime/model capability drift, invalidate stale evidence and trigger bounded regeneration or recertification.
- **Group/Priority/Risk:** `lifecycle` / `P1` / `high`
- **Kernels:** K2, K3, K6, K8
- **Dependencies:** `elmos-ai-target-adapter-sdk`, `elmos-ai-unsupported-feature-ledger`
- **Path:** `agent-skills/runtime/elmos-ai-compatibility-drift-monitor/SKILL.md`

### `elmos-ai-compliance-profile-compiler`

- **Purpose:** Compile jurisdiction, industry and customer control profiles into executable policies, evidence requirements, human decisions and unresolved legal obligations.
- **Group/Priority/Risk:** `governance` / `P0` / `critical`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-ai-security-governance-compiler`, `elmos-ai-assurance-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-compliance-profile-compiler/SKILL.md`

### `elmos-ai-config-secret-materializer`

- **Purpose:** Generate environment schemas, secret references, configuration validation and deployment-time materialization without embedding credentials in generated code or evidence.
- **Group/Priority/Risk:** `transformation` / `P0` / `critical`
- **Kernels:** K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-ai-security-governance-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-config-secret-materializer/SKILL.md`

### `elmos-ai-content-provenance-labeling-controller`

- **Purpose:** Generate provenance metadata, disclosures, watermarks or content credentials and verify that transformations preserve required labels.
- **Group/Priority/Risk:** `governance` / `P1` / `high`
- **Kernels:** K3, K5, K6, K8
- **Dependencies:** `elmos-ai-compliance-profile-compiler`, `elmos-ai-artifact-provenance-packager`
- **Path:** `agent-skills/runtime/elmos-ai-content-provenance-labeling-controller/SKILL.md`

### `elmos-ai-context-memory-governor`

- **Purpose:** Generate context assembly, prefix-stable caching, compaction, memory write/read policy, conflict resolution, deletion propagation and privacy controls.
- **Group/Priority/Risk:** `runtime-platform` / `P0` / `critical`
- **Kernels:** K4, K5, K6, K7
- **Dependencies:** `elmos-ai-memory-semantic-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-context-memory-governor/SKILL.md`

### `elmos-ai-cost-pricing-sla-contract-compiler`

- **Purpose:** Compile machine wall-clock, token, compute, storage, network, provider and support economics into enforceable quotes, budgets, SLAs and settlement evidence.
- **Group/Priority/Risk:** `finops` / `P1` / `critical`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-ai-observability-finops-generator`, `elmos-ai-runaway-loop-economic-dos-guard`
- **Path:** `agent-skills/runtime/elmos-ai-cost-pricing-sla-contract-compiler/SKILL.md`

### `elmos-ai-cross-framework-differential-validator`

- **Purpose:** Compare source and target or multiple generated targets by typed observations, partial-order trace constraints, state invariants, side effects, grounding and tolerances.
- **Group/Priority/Risk:** `assurance` / `P0` / `critical`
- **Kernels:** K6, K8
- **Dependencies:** `elmos-ai-normalized-agent-trace-recorder`
- **Path:** `agent-skills/runtime/elmos-ai-cross-framework-differential-validator/SKILL.md`

### `elmos-ai-data-contract-quality-governor`

- **Purpose:** Define and enforce contracts for training, evaluation, retrieval, memory and tool data with freshness, completeness, distribution and ownership controls.
- **Group/Priority/Risk:** `data-governance` / `P1` / `critical`
- **Kernels:** K1, K2, K6
- **Dependencies:** `elmos-ai-eval-dataset-governor`, `elmos-rag-corpus-connector-cdc-governor`
- **Path:** `agent-skills/runtime/elmos-ai-data-contract-quality-governor/SKILL.md`

### `elmos-ai-dependency-version-resolver`

- **Purpose:** Resolve framework, runtime, provider, plugin, model, database and deployment dependencies against compatibility, support, license, vulnerability and reproducibility policy.
- **Group/Priority/Risk:** `transformation` / `P0` / `critical`
- **Kernels:** K2, K5, K6, K8
- **Dependencies:** `elmos-ai-multi-target-lowering-planner`
- **Path:** `agent-skills/runtime/elmos-ai-dependency-version-resolver/SKILL.md`

### `elmos-ai-deployment-pack-generator`

- **Purpose:** Generate local, Docker, Kubernetes, Helm and infrastructure profiles with health endpoints, migrations, secret references, network policy, autoscaling, backup and rollback.
- **Group/Priority/Risk:** `runtime-platform` / `P0` / `critical`
- **Kernels:** K5, K6, K7, K8
- **Dependencies:** `elmos-ai-multitenant-control-plane-generator`, `elmos-ai-observability-finops-generator`
- **Path:** `agent-skills/runtime/elmos-ai-deployment-pack-generator/SKILL.md`

### `elmos-ai-durable-runtime-integrator`

- **Purpose:** Integrate generated projects with durable workflow, checkpoints, replay, pause/resume/cancel, leases, fencing, outbox and side-effect reconciliation.
- **Group/Priority/Risk:** `runtime-platform` / `P0` / `critical`
- **Kernels:** K5, K6, K7
- **Dependencies:** `elmos-ai-runtime-operations-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-durable-runtime-integrator/SKILL.md`

### `elmos-ai-e0-e5-certifier`

- **Purpose:** Issue an independent bounded completion decision only when the exact RevisionSet, obligations, evidence freshness, side effects and E0–E5 gates satisfy policy.
- **Group/Priority/Risk:** `certification` / `P0` / `critical`
- **Kernels:** K8
- **Dependencies:** `elmos-ai-cross-framework-differential-validator`, `elmos-ai-rag-retrieval-grounding-certifier`, `elmos-ai-graph-liveness-side-effect-verifier`, `elmos-ai-prompt-tool-security-redteam`, `elmos-ai-supply-chain-performance-resilience-certifier`
- **Path:** `agent-skills/runtime/elmos-ai-e0-e5-certifier/SKILL.md`

### `elmos-ai-eval-dataset-governor`

- **Purpose:** Govern versioned evaluation datasets from provenance and consent through deduplication, labels, holdout isolation, contamination detection, retention and release.
- **Group/Priority/Risk:** `evaluation` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K8
- **Dependencies:** `elmos-ai-assurance-contract-compiler`, `elmos-ai-provider-data-residency-controller`
- **Path:** `agent-skills/runtime/elmos-ai-eval-dataset-governor/SKILL.md`

### `elmos-ai-generated-project-conformance-validator`

- **Purpose:** Execute adapter-native import, build, start, schema, tool, state, persistence, API and deployment conformance suites against the exact generated revision.
- **Group/Priority/Risk:** `assurance` / `P0` / `critical`
- **Kernels:** K6, K8
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-ai-generated-project-conformance-validator/SKILL.md`

### `elmos-ai-generated-project-upgrader`

- **Purpose:** Upgrade generated projects when target frameworks, adapters, models or platform contracts drift, preserving user-owned changes through source lineage and three-way semantic merge.
- **Group/Priority/Risk:** `lifecycle` / `P1` / `critical`
- **Kernels:** K2, K3, K5, K6
- **Dependencies:** `elmos-ai-compatibility-drift-monitor`, `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-ai-generated-project-upgrader/SKILL.md`

### `elmos-ai-golden-route-autogen-sk-to-agent-framework`

- **Purpose:** Migrate AutoGen or Semantic Kernel agent applications to Microsoft Agent Framework while preserving tools, sessions, workflows, human gates and telemetry contracts.
- **Group/Priority/Risk:** `golden-route` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-target-microsoft-agent-framework-generator`, `elmos-ai-source-project-importer`, `elmos-ai-roundtrip-migration-controller`, `elmos-ai-e0-e5-certifier`
- **Path:** `agent-skills/runtime/elmos-ai-golden-route-autogen-sk-to-agent-framework/SKILL.md`

### `elmos-ai-golden-route-business-requirement-multitarget`

- **Purpose:** Execute Business Requirement → AI-SIR → Dify prototype + LangGraph production runtime + Spring AI enterprise service + OpenClaw channel gateway.
- **Group/Priority/Risk:** `golden-route` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-target-dify-project-generator`, `elmos-target-langgraph-project-generator`, `elmos-target-spring-ai-project-generator`, `elmos-target-openclaw-assistant-generator`, `elmos-ai-e0-e5-certifier`
- **Path:** `agent-skills/runtime/elmos-ai-golden-route-business-requirement-multitarget/SKILL.md`

### `elmos-ai-golden-route-continuous-agent-certification`

- **Purpose:** Certify the loop from privacy-filtered production traces to versioned evals, calibrated judges, behavior fingerprints, shadow rollout and recertification.
- **Group/Priority/Risk:** `golden-route` / `P1` / `critical`
- **Kernels:** K2, K4, K6, K7, K8
- **Dependencies:** `elmos-ai-online-shadow-eval-controller`, `elmos-ai-provider-behavior-fingerprint-recertifier`, `elmos-ai-eval-dataset-governor`
- **Path:** `agent-skills/runtime/elmos-ai-golden-route-continuous-agent-certification/SKILL.md`

### `elmos-ai-golden-route-dify-to-production-code`

- **Purpose:** Import a Dify DSL and plugins, recover AI-SIR, generate LangGraph and Spring AI production implementations, and differentially validate supported behavior.
- **Group/Priority/Risk:** `golden-route` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-target-dify-project-generator`, `elmos-target-langgraph-project-generator`, `elmos-target-spring-ai-project-generator`, `elmos-ai-roundtrip-migration-controller`, `elmos-ai-e0-e5-certifier`
- **Path:** `agent-skills/runtime/elmos-ai-golden-route-dify-to-production-code/SKILL.md`

### `elmos-ai-golden-route-langchain-to-langgraph`

- **Purpose:** Modernize an existing LangChain repository to LangGraph with explicit state, persistence, interrupts, durable execution and behavior-differential evidence.
- **Group/Priority/Risk:** `golden-route` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-target-langchain-project-generator`, `elmos-target-langgraph-project-generator`, `elmos-ai-roundtrip-migration-controller`, `elmos-ai-e0-e5-certifier`
- **Path:** `agent-skills/runtime/elmos-ai-golden-route-langchain-to-langgraph/SKILL.md`

### `elmos-ai-golden-route-managed-runtime`

- **Purpose:** Certify portability from framework-native projects to a selected managed agent cloud with identity, observability, rollback and tested exit strategy.
- **Group/Priority/Risk:** `golden-route` / `P1` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-managed-agent-cloud-deployment-generator`, `elmos-eval-observability-platform-integrator`, `elmos-ai-bom-provenance-generator`
- **Path:** `agent-skills/runtime/elmos-ai-golden-route-managed-runtime/SKILL.md`

### `elmos-ai-golden-route-mcp-2026-modernization`

- **Purpose:** Certify migration of a legacy MCP server to the 2026-07-28 profile with stateless core, Tasks, Apps/Skills extensions and enterprise authorization.
- **Group/Priority/Risk:** `golden-route` / `P1` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-mcp-tasks-durable-bridge`, `elmos-mcp-apps-a2ui-generator`, `elmos-mcp-enterprise-authorization-controller`
- **Path:** `agent-skills/runtime/elmos-ai-golden-route-mcp-2026-modernization/SKILL.md`

### `elmos-ai-golden-route-portable-skill`

- **Purpose:** Certify repository or runbook to portable Skill IR and host packages across Agent Skills, OpenAI Plugin, Codex, Claude Code, Pi and OpenClaw.
- **Group/Priority/Risk:** `golden-route` / `P1` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-agent-skill-portability-emitter`, `elmos-agent-skill-trigger-evaluator`, `elmos-agent-skill-mcp-supply-chain-certifier`
- **Path:** `agent-skills/runtime/elmos-ai-golden-route-portable-skill/SKILL.md`

### `elmos-ai-golden-route-repository-to-coding-harness`

- **Purpose:** Analyze a repository and generate repository-specific Pi, Harness, OpenCode/Codex/Claude/Gemini skills, authority policies, workflows and verification gates.
- **Group/Priority/Risk:** `golden-route` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-target-pi-package-generator`, `elmos-target-deepseek-harness-generator`, `elmos-target-openharness-generator`, `elmos-target-coding-agent-harness-family-generator`, `elmos-ai-e0-e5-certifier`
- **Path:** `agent-skills/runtime/elmos-ai-golden-route-repository-to-coding-harness/SKILL.md`

### `elmos-ai-golden-route-trusted-cross-org-agent`

- **Purpose:** Certify signed A2A discovery, workload identity, delegated authority and auditable cross-organization task execution.
- **Group/Priority/Risk:** `golden-route` / `P1` / `critical`
- **Kernels:** K1, K3, K6, K7, K8
- **Dependencies:** `elmos-a2a-v1-agent-card-trust-compiler`, `elmos-agent-registry-resource-discovery-governor`, `elmos-agent-workload-delegated-identity-controller`
- **Path:** `agent-skills/runtime/elmos-ai-golden-route-trusted-cross-org-agent/SKILL.md`

### `elmos-ai-graph-liveness-side-effect-verifier`

- **Purpose:** Verify graph termination or bounded continuation, deadlock freedom within the declared envelope, serializable checkpoints, retry-safe side effects and compensation coverage.
- **Group/Priority/Risk:** `assurance` / `P0` / `critical`
- **Kernels:** K6, K8
- **Dependencies:** `elmos-ai-workflow-state-machine-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-graph-liveness-side-effect-verifier/SKILL.md`

### `elmos-ai-incident-kill-switch-controller`

- **Purpose:** Execute tenant, agent, tool, provider, Skill, prompt, memory and credential shutdown while preserving evidence and reconciling active side effects.
- **Group/Priority/Risk:** `incident-response` / `P0` / `critical`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-ai-runaway-loop-economic-dos-guard`, `elmos-ai-durable-runtime-integrator`
- **Path:** `agent-skills/runtime/elmos-ai-incident-kill-switch-controller/SKILL.md`

### `elmos-ai-incident-regulatory-reporting-controller`

- **Purpose:** Coordinate technical triage, legal/compliance review, deadlines, evidence, customer communication and regulator-ready reporting for AI incidents.
- **Group/Priority/Risk:** `governance-incident-reporting` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-security-incident-psirt-disclosure-controller`, `elmos-regulatory-obligation-effective-date-monitor`
- **Path:** `agent-skills/runtime/elmos-ai-incident-regulatory-reporting-controller/SKILL.md`

### `elmos-ai-interaction-channel-compiler`

- **Purpose:** Normalize web chat, API, SSE, WebSocket, CLI/TUI, mobile, enterprise messaging, voice/realtime, AG-UI and generative UI interaction contracts.
- **Group/Priority/Risk:** `semantic-ir` / `P0` / `high`
- **Kernels:** K3, K6
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-interaction-channel-compiler/SKILL.md`

### `elmos-ai-judge-calibration-stochastic-assurance`

- **Purpose:** Calibrate LLM judges against authoritative labels, quantify uncertainty and bias, and prevent probabilistic judgments from becoming unbounded completion evidence.
- **Group/Priority/Risk:** `evaluation` / `P0` / `critical`
- **Kernels:** K4, K6, K8
- **Dependencies:** `elmos-ai-eval-dataset-governor`, `elmos-ai-assurance-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-judge-calibration-stochastic-assurance/SKILL.md`

### `elmos-ai-mcp-a2a-gateway-generator`

- **Purpose:** Generate MCP client/server and A2A agent-card/task gateway projects with discovery, schema validation, identity, authority, transport, audit and protocol conformance.
- **Group/Priority/Risk:** `runtime-platform` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-tool-protocol-compiler`, `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-ai-mcp-a2a-gateway-generator/SKILL.md`

### `elmos-ai-memory-semantic-compiler`

- **Purpose:** Separate turn, thread, session, user, organization, episodic, semantic, procedural and repository memory with lifecycle, privacy and conflict semantics.
- **Group/Priority/Risk:** `semantic-ir` / `P0` / `high`
- **Kernels:** K3, K6, K7
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-memory-semantic-compiler/SKILL.md`

### `elmos-ai-model-contract-compiler`

- **Purpose:** Model provider-neutral inference, embedding, reranking, structured output, routing, fallback, budget, data handling and determinism requirements.
- **Group/Priority/Risk:** `semantic-ir` / `P0` / `critical`
- **Kernels:** K3, K6, K7
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-model-contract-compiler/SKILL.md`

### `elmos-ai-model-provider-availability-resilience-controller`

- **Purpose:** Control provider health, regional routing, retries, hedging, fallback, rate limits and circuit breakers while preserving capability and data-policy constraints.
- **Group/Priority/Risk:** `runtime-safety` / `P1` / `critical`
- **Kernels:** K4, K6, K7
- **Dependencies:** `elmos-ai-model-routing-fallback-generator`, `elmos-ai-provider-data-residency-controller`
- **Path:** `agent-skills/runtime/elmos-ai-model-provider-availability-resilience-controller/SKILL.md`

### `elmos-ai-model-routing-fallback-generator`

- **Purpose:** Generate policy-driven model/provider routing, fallback, hedging, retry, rate-limit, structured-output and budget controls with data-handling constraints.
- **Group/Priority/Risk:** `runtime-platform` / `P0` / `critical`
- **Kernels:** K4, K5, K6, K7
- **Dependencies:** `elmos-ai-model-contract-compiler`, `elmos-ai-provider-data-residency-controller`
- **Path:** `agent-skills/runtime/elmos-ai-model-routing-fallback-generator/SKILL.md`

### `elmos-ai-multi-target-lowering-planner`

- **Purpose:** Plan shared and target-specific lowering stages, preserve common assets, assign semantic-gap obligations and prevent divergent target truth.
- **Group/Priority/Risk:** `transformation` / `P0` / `critical`
- **Kernels:** K3, K4, K5, K6
- **Dependencies:** `elmos-ai-target-adapter-sdk`, `elmos-ai-capability-negotiator`
- **Path:** `agent-skills/runtime/elmos-ai-multi-target-lowering-planner/SKILL.md`

### `elmos-ai-multitenant-control-plane-generator`

- **Purpose:** Generate tenant, project, goal, run, quota, concurrency, identity, RLS, audit and operator APIs for safely hosting generated AI solutions.
- **Group/Priority/Risk:** `runtime-platform` / `P0` / `critical`
- **Kernels:** K5, K6, K7
- **Dependencies:** `elmos-ai-durable-runtime-integrator`, `elmos-ai-tool-authority-policy-generator`
- **Path:** `agent-skills/runtime/elmos-ai-multitenant-control-plane-generator/SKILL.md`

### `elmos-ai-normalized-agent-trace-recorder`

- **Purpose:** Record framework-neutral input, routing, retrieval, model, tool, approval, state, side-effect, evidence and output events with causal and revision binding.
- **Group/Priority/Risk:** `assurance` / `P0` / `critical`
- **Kernels:** K6, K7
- **Dependencies:** `elmos-ai-generated-project-conformance-validator`
- **Path:** `agent-skills/runtime/elmos-ai-normalized-agent-trace-recorder/SKILL.md`

### `elmos-ai-observability-finops-generator`

- **Purpose:** Generate OpenTelemetry traces, normalized agent spans, model/tool usage ledgers, cache metrics, budget enforcement, machine wall-clock ETA and SLO dashboards.
- **Group/Priority/Risk:** `runtime-platform` / `P0` / `high`
- **Kernels:** K5, K6, K7, K8
- **Dependencies:** `elmos-ai-runtime-operations-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-observability-finops-generator/SKILL.md`

### `elmos-ai-online-shadow-eval-controller`

- **Purpose:** Run privacy-safe, no-side-effect production shadow evaluation with paired comparison, promotion thresholds, canary control and automatic rollback.
- **Group/Priority/Risk:** `evaluation-drift` / `P0` / `critical`
- **Kernels:** K6, K7, K8
- **Dependencies:** `elmos-ai-provider-behavior-fingerprint-recertifier`, `elmos-ai-normalized-agent-trace-recorder`
- **Path:** `agent-skills/runtime/elmos-ai-online-shadow-eval-controller/SKILL.md`

### `elmos-ai-operator-console-generator`

- **Purpose:** Generate an operator console for runs, graphs, checkpoints, approvals, traces, costs, feature gaps, proof obligations, evidence and certificate status.
- **Group/Priority/Risk:** `runtime-platform` / `P1` / `high`
- **Kernels:** K5, K6, K7, K8
- **Dependencies:** `elmos-ai-multitenant-control-plane-generator`, `elmos-ai-artifact-provenance-packager`
- **Path:** `agent-skills/runtime/elmos-ai-operator-console-generator/SKILL.md`

### `elmos-ai-policy-as-code-compiler`

- **Purpose:** Compile governance and security decisions into versioned Rego or equivalent policies with tests, simulation, staged rollout and explanation artifacts.
- **Group/Priority/Risk:** `governance` / `P1` / `critical`
- **Kernels:** K1, K5, K6, K7
- **Dependencies:** `elmos-ai-compliance-profile-compiler`, `elmos-ai-tool-authority-policy-generator`
- **Path:** `agent-skills/runtime/elmos-ai-policy-as-code-compiler/SKILL.md`

### `elmos-ai-project-factory-orchestrator`

- **Purpose:** Compile a business goal or existing AI repository into a governed, resumable, multi-target generation program with explicit proof obligations and release gates.
- **Group/Priority/Risk:** `control` / `P0` / `critical`
- **Kernels:** K1, K4, K7, K8
- **Dependencies:** `elmos-ai-e0-e5-certifier`
- **Path:** `agent-skills/runtime/elmos-ai-project-factory-orchestrator/SKILL.md`

### `elmos-ai-project-repository-emitter`

- **Purpose:** Emit complete repository structures, source code, schemas, prompts, tools, tests, deployment assets, runbooks and evidence hooks from approved lowering plans.
- **Group/Priority/Risk:** `transformation` / `P0` / `critical`
- **Kernels:** K5, K6
- **Dependencies:** `elmos-ai-dependency-version-resolver`
- **Path:** `agent-skills/runtime/elmos-ai-project-repository-emitter/SKILL.md`

### `elmos-ai-prompt-tool-security-redteam`

- **Purpose:** Run prompt-injection, indirect-injection, tool-confusion, authority escalation, data-exfiltration, memory-poisoning, cross-tenant and unsafe-code-execution campaigns.
- **Group/Priority/Risk:** `assurance` / `P0` / `critical`
- **Kernels:** K6, K7, K8
- **Dependencies:** `elmos-ai-tool-authority-policy-generator`, `elmos-ai-generated-project-conformance-validator`
- **Path:** `agent-skills/runtime/elmos-ai-prompt-tool-security-redteam/SKILL.md`

### `elmos-ai-provider-behavior-fingerprint-recertifier`

- **Purpose:** Fingerprint model/provider behavior with versioned probes and invalidate evidence when tool calling, schema compliance, safety, latency or accounting drifts.
- **Group/Priority/Risk:** `evaluation-drift` / `P0` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-ai-judge-calibration-stochastic-assurance`, `elmos-ai-compatibility-drift-monitor`
- **Path:** `agent-skills/runtime/elmos-ai-provider-behavior-fingerprint-recertifier/SKILL.md`

### `elmos-ai-provider-data-residency-controller`

- **Purpose:** Enforce provider eligibility, customer VPC/private endpoint, zero-retention requirements, geographic residency, BYOK and sensitive-data routing decisions.
- **Group/Priority/Risk:** `runtime-platform` / `P0` / `critical`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-ai-security-governance-compiler`, `elmos-ai-model-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-provider-data-residency-controller/SKILL.md`

### `elmos-ai-quality-model-evaluation-compiler`

- **Purpose:** Compile measurable product, service, data and AI quality characteristics into requirements, metrics, evaluation modules and release evidence.
- **Group/Priority/Risk:** `quality-certification` / `P0` / `critical`
- **Kernels:** K1, K3, K6, K8
- **Dependencies:** `elmos-ai-assurance-contract-compiler`, `elmos-performance-statistical-gate`, `elmos-ai-system-impact-assessment-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-quality-model-evaluation-compiler/SKILL.md`

### `elmos-ai-rag-retrieval-grounding-certifier`

- **Purpose:** Certify ingestion correctness, ACL enforcement, retrieval recall/ranking, citation precision, faithfulness, abstention, freshness, deletion and performance.
- **Group/Priority/Risk:** `assurance` / `P0` / `critical`
- **Kernels:** K6, K8
- **Dependencies:** `elmos-ai-cross-framework-differential-validator`, `elmos-ai-rag-semantic-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-rag-retrieval-grounding-certifier/SKILL.md`

### `elmos-ai-rag-semantic-compiler`

- **Purpose:** Model the full ingestion, parsing, chunking, ACL, indexing, retrieval, reranking, context packing, grounding, citation, abstention, synchronization and evaluation lifecycle.
- **Group/Priority/Risk:** `semantic-ir` / `P0` / `critical`
- **Kernels:** K2, K3, K6
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-rag-semantic-compiler/SKILL.md`

### `elmos-ai-regulated-decision-explainability-packager`

- **Purpose:** Package decision inputs, evidence, rules, model contribution, uncertainty, oversight and appeal artifacts for regulated or high-impact decisions.
- **Group/Priority/Risk:** `governance` / `P1` / `critical`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-ai-compliance-profile-compiler`, `elmos-human-oversight-consent-contract-compiler`, `elmos-ai-system-model-card-generator`
- **Path:** `agent-skills/runtime/elmos-ai-regulated-decision-explainability-packager/SKILL.md`

### `elmos-ai-requirement-contract-compiler`

- **Purpose:** Recover and normalize business, interaction, data, security, latency, cost, residency, operability and acceptance requirements into an executable AI solution contract.
- **Group/Priority/Risk:** `specification` / `P0` / `critical`
- **Kernels:** K1, K2, K6
- **Dependencies:** none
- **Path:** `agent-skills/runtime/elmos-ai-requirement-contract-compiler/SKILL.md`

### `elmos-ai-retention-erasure-verifier`

- **Purpose:** Enforce and verify retention, legal hold, export and deletion across prompts, traces, datasets, vector indexes, memories, caches, artifacts and backups.
- **Group/Priority/Risk:** `data-governance` / `P1` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-ai-provider-data-residency-controller`, `elmos-rag-acl-freshness-deletion-verifier`
- **Path:** `agent-skills/runtime/elmos-ai-retention-erasure-verifier/SKILL.md`

### `elmos-ai-revision-set-freezer`

- **Purpose:** Freeze the exact source, requirements, AI-SIR, target profiles, model/tool policies, adapter digests, templates, data sets and verification configuration used by a generation run.
- **Group/Priority/Risk:** `control` / `P0` / `critical`
- **Kernels:** K1, K7, K8
- **Dependencies:** `elmos-ai-target-portfolio-planner`
- **Path:** `agent-skills/runtime/elmos-ai-revision-set-freezer/SKILL.md`

### `elmos-ai-roundtrip-migration-controller`

- **Purpose:** Control import→AI-SIR→target→re-import round trips and cross-ecosystem migrations while making information loss and manual preservation points explicit.
- **Group/Priority/Risk:** `lifecycle` / `P1` / `critical`
- **Kernels:** K3, K5, K6, K8
- **Dependencies:** `elmos-ai-source-project-importer`, `elmos-ai-cross-framework-differential-validator`
- **Path:** `agent-skills/runtime/elmos-ai-roundtrip-migration-controller/SKILL.md`

### `elmos-ai-runaway-loop-economic-dos-guard`

- **Purpose:** Enforce step, token, tool, cost, wall-clock, fanout and side-effect budgets while detecting retry storms, delegation loops and fallback cascades.
- **Group/Priority/Risk:** `runtime-safety` / `P0` / `critical`
- **Kernels:** K6, K7, K8
- **Dependencies:** `elmos-ai-runtime-operations-compiler`, `elmos-ai-graph-liveness-side-effect-verifier`
- **Path:** `agent-skills/runtime/elmos-ai-runaway-loop-economic-dos-guard/SKILL.md`

### `elmos-ai-runtime-operations-compiler`

- **Purpose:** Represent durable execution, scheduling, queueing, worker ownership, cancellation, backpressure, telemetry, cache, cost, ETA, rollback and operations requirements.
- **Group/Priority/Risk:** `semantic-ir` / `P0` / `critical`
- **Kernels:** K3, K6, K7
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-runtime-operations-compiler/SKILL.md`

### `elmos-ai-secret-credential-lifecycle-controller`

- **Purpose:** Broker short-lived model, tool, database and cloud credentials with least privilege, rotation, revocation, leak detection and incident integration.
- **Group/Priority/Risk:** `identity-authorization` / `P1` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-agent-workload-delegated-identity-controller`, `elmos-ai-incident-kill-switch-controller`
- **Path:** `agent-skills/runtime/elmos-ai-secret-credential-lifecycle-controller/SKILL.md`

### `elmos-ai-security-governance-compiler`

- **Purpose:** Compile identity, tenant isolation, tool authority, secret, data boundary, injection defense, PII, approval, audit, retention, sandbox and egress policies.
- **Group/Priority/Risk:** `semantic-ir` / `P0` / `critical`
- **Kernels:** K1, K3, K6, K7, K8
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-security-governance-compiler/SKILL.md`

### `elmos-ai-sir-compiler`

- **Purpose:** Compile solution contracts and recovered repositories into the canonical AI Solution Semantic IR without treating any external framework API as semantic authority.
- **Group/Priority/Risk:** `semantic-ir` / `P0` / `critical`
- **Kernels:** K2, K3, K6
- **Dependencies:** `elmos-ai-revision-set-freezer`, `elmos-ai-model-contract-compiler`, `elmos-ai-agent-contract-compiler`, `elmos-ai-workflow-state-machine-compiler`, `elmos-ai-tool-protocol-compiler`, `elmos-ai-rag-semantic-compiler`, `elmos-ai-memory-semantic-compiler`, `elmos-ai-interaction-channel-compiler`, `elmos-ai-security-governance-compiler`, `elmos-ai-runtime-operations-compiler`, `elmos-ai-assurance-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-sir-compiler/SKILL.md`

### `elmos-ai-solution-archetype-selector`

- **Purpose:** Select one or more solution archetypes—RAG, agentic RAG, multi-agent workflow, coding harness, personal assistant, data agent, realtime agent or automation—using evidence rather than framework popularity.
- **Group/Priority/Risk:** `planning` / `P0` / `high`
- **Kernels:** K1, K4, K8
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-solution-archetype-selector/SKILL.md`

### `elmos-ai-source-project-importer`

- **Purpose:** Inspect and import existing visual DSLs, agent SDK repositories, RAG systems, harness packages and deployment descriptors into evidence-backed AI-SIR.
- **Group/Priority/Risk:** `import` / `P0` / `critical`
- **Kernels:** K2, K3, K6
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-source-project-importer/SKILL.md`

### `elmos-ai-supply-chain-performance-resilience-certifier`

- **Purpose:** Verify SBOM, provenance, dependency policy, image integrity, latency, throughput, resource bounds, load shedding, provider outage, worker loss and disaster recovery.
- **Group/Priority/Risk:** `assurance` / `P0` / `critical`
- **Kernels:** K6, K8
- **Dependencies:** `elmos-ai-deployment-pack-generator`, `elmos-ai-generated-project-conformance-validator`
- **Path:** `agent-skills/runtime/elmos-ai-supply-chain-performance-resilience-certifier/SKILL.md`

### `elmos-ai-synthetic-test-simulation-generator`

- **Purpose:** Generate privacy-safe synthetic scenarios, tool simulators, user personas and fault environments with measurable realism and coverage limits.
- **Group/Priority/Risk:** `evaluation` / `P1` / `high`
- **Kernels:** K4, K5, K6
- **Dependencies:** `elmos-ai-eval-dataset-governor`, `elmos-ai-assurance-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-synthetic-test-simulation-generator/SKILL.md`

### `elmos-ai-system-impact-assessment-compiler`

- **Purpose:** Compile lifecycle impact assessments covering affected people, rights, safety, accessibility, environment, misuse, distributional effects and mitigation ownership.
- **Group/Priority/Risk:** `governance-impact` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K8
- **Dependencies:** `elmos-ai-compliance-profile-compiler`, `elmos-ai-system-model-card-generator`, `elmos-human-oversight-consent-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-system-impact-assessment-compiler/SKILL.md`

### `elmos-ai-system-model-card-generator`

- **Purpose:** Generate evidence-backed system/model cards describing intended use, limits, evaluations, risks, data, oversight, deployment envelope and change history.
- **Group/Priority/Risk:** `governance` / `P1` / `high`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-ai-compliance-profile-compiler`, `elmos-ai-bom-provenance-generator`
- **Path:** `agent-skills/runtime/elmos-ai-system-model-card-generator/SKILL.md`

### `elmos-ai-target-adapter-sdk`

- **Purpose:** Define the only supported extension seam for target detection, capability profiling, lowering, emission, import, conformance, upgrade and evidence capture.
- **Group/Priority/Risk:** `adapter-sdk` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-sir-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-target-adapter-sdk/SKILL.md`

### `elmos-ai-target-portfolio-planner`

- **Purpose:** Choose a target portfolio that separates prototype, production runtime, enterprise service, channels, coding harness and infrastructure targets while minimizing lock-in and unsupported semantics.
- **Group/Priority/Risk:** `planning` / `P0` / `critical`
- **Kernels:** K1, K4, K5, K8
- **Dependencies:** `elmos-ai-solution-archetype-selector`, `elmos-ai-capability-negotiator`
- **Path:** `agent-skills/runtime/elmos-ai-target-portfolio-planner/SKILL.md`

### `elmos-ai-tenant-memory-isolation-verifier`

- **Purpose:** Prove isolation of session, user, organization, episodic, semantic and procedural memory across storage, cache, retrieval and trace boundaries.
- **Group/Priority/Risk:** `security-rag-memory` / `P1` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-ai-memory-semantic-compiler`, `elmos-rag-memory-poisoning-verifier`
- **Path:** `agent-skills/runtime/elmos-ai-tenant-memory-isolation-verifier/SKILL.md`

### `elmos-ai-tool-authority-policy-generator`

- **Purpose:** Generate environment-owned, attachment-owned and request-scoped tool authority policies with path/parameter constraints, approval gates and deny-by-default behavior.
- **Group/Priority/Risk:** `runtime-platform` / `P0` / `critical`
- **Kernels:** K6, K7, K8
- **Dependencies:** `elmos-ai-security-governance-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-tool-authority-policy-generator/SKILL.md`

### `elmos-ai-tool-contract-compatibility-verifier`

- **Purpose:** Verify schema, semantics, effects, idempotency, authorization and error compatibility as tools and MCP/OpenAPI providers evolve.
- **Group/Priority/Risk:** `compatibility` / `P1` / `critical`
- **Kernels:** K3, K6, K8
- **Dependencies:** `elmos-ai-tool-protocol-compiler`, `elmos-model-response-schema-evolution-controller`
- **Path:** `agent-skills/runtime/elmos-ai-tool-contract-compatibility-verifier/SKILL.md`

### `elmos-ai-tool-protocol-compiler`

- **Purpose:** Normalize function tools, MCP, A2A, OpenAPI, CLI, database, browser, filesystem, code execution and computer-use contracts with typed side-effect and authority semantics.
- **Group/Priority/Risk:** `semantic-ir` / `P0` / `critical`
- **Kernels:** K3, K6, K7
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-tool-protocol-compiler/SKILL.md`

### `elmos-ai-unsupported-feature-ledger`

- **Purpose:** Record every unsupported, partially represented, emulated, runtime-monitored or waived feature and block silent degradation.
- **Group/Priority/Risk:** `governance` / `P0` / `critical`
- **Kernels:** K3, K6, K8
- **Dependencies:** `elmos-ai-capability-negotiator`
- **Path:** `agent-skills/runtime/elmos-ai-unsupported-feature-ledger/SKILL.md`

### `elmos-ai-workflow-state-machine-compiler`

- **Purpose:** Compile nodes, edges, branches, loops, joins, interrupts, approvals, retries, compensation, checkpointing and liveness constraints into a durable workflow IR.
- **Group/Priority/Risk:** `semantic-ir` / `P0` / `critical`
- **Kernels:** K3, K6, K7
- **Dependencies:** `elmos-ai-requirement-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-ai-workflow-state-machine-compiler/SKILL.md`

### `elmos-api-authz-rbac-abac-rebac-equivalence-verifier`

- **Purpose:** Verify authorization semantics across source/target frameworks and policy engines, including field, row, relationship and contextual decisions.
- **Group/Priority/Risk:** `security-authorization` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-tool-authority-policy-generator`, `elmos-ai-cross-framework-differential-validator`
- **Path:** `agent-skills/runtime/elmos-api-authz-rbac-abac-rebac-equivalence-verifier/SKILL.md`

### `elmos-api-consumer-driven-contract-verifier`

- **Purpose:** Generate and execute provider/consumer contracts for APIs, tools and events, including version negotiation, errors, auth and deployment compatibility.
- **Group/Priority/Risk:** `qa-contract` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-ai-tool-contract-compatibility-verifier`, `elmos-api-event-contract-ir-compiler`
- **Path:** `agent-skills/runtime/elmos-api-consumer-driven-contract-verifier/SKILL.md`

### `elmos-api-event-contract-ir-compiler`

- **Purpose:** Compile REST, GraphQL, gRPC, Webhook and event-driven interfaces into a unified contract IR including identity, ordering, effects, errors and compatibility.
- **Group/Priority/Risk:** `event-contract-ir` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-ai-tool-protocol-compiler`, `elmos-ai-tool-contract-compatibility-verifier`
- **Path:** `agent-skills/runtime/elmos-api-event-contract-ir-compiler/SKILL.md`

### `elmos-api-first-contract-generation-controller`

- **Purpose:** Generate OpenAPI, AsyncAPI, GraphQL and gRPC contracts, mock/simulator assets, server/client stubs and compatibility gates before implementation.
- **Group/Priority/Risk:** `architecture-api-first` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6
- **Dependencies:** `elmos-api-event-contract-ir-compiler`, `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-api-first-contract-generation-controller/SKILL.md`

### `elmos-api-sdk-codegen-conformance-certifier`

- **Purpose:** Generate and certify multi-language SDKs, examples and documentation from API/workflow contracts with compatibility, auth, error, streaming and retry semantics intact.
- **Group/Priority/Risk:** `protocol-sdk-codegen` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-openapi-arazzo-workflow-compiler`, `elmos-generated-api-event-schema-evolution-controller`
- **Path:** `agent-skills/runtime/elmos-api-sdk-codegen-conformance-certifier/SKILL.md`

### `elmos-architecture-decision-record-governor`

- **Purpose:** Create, link, supersede and validate ADRs against requirements, evidence, implementation and operational outcomes.
- **Group/Priority/Risk:** `architecture-decisions` / `P1` / `high`
- **Kernels:** K1, K2, K3, K5, K6
- **Dependencies:** `elmos-domain-driven-architecture-synthesizer`, `elmos-ai-artifact-provenance-packager`
- **Path:** `agent-skills/runtime/elmos-architecture-decision-record-governor/SKILL.md`

### `elmos-asyncapi-cloudevents-generator`

- **Purpose:** Generate versioned AsyncAPI and CloudEvents-compatible contracts, bindings, examples, code stubs and conformance tests from Event Contract IR.
- **Group/Priority/Risk:** `event-contract-generation` / `P0` / `high`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-api-event-contract-ir-compiler`, `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-asyncapi-cloudevents-generator/SKILL.md`

### `elmos-authoritative-oracle-registry`

- **Purpose:** Register compiler, protocol, database, contract, property, runtime and human authorities with independence, scope, confidence, freshness and conflict rules.
- **Group/Priority/Risk:** `qa-assurance` / `P0` / `critical`
- **Kernels:** K1, K3, K6, K8
- **Dependencies:** `elmos-proof-to-validation-dag-compiler`
- **Path:** `agent-skills/runtime/elmos-authoritative-oracle-registry/SKILL.md`

### `elmos-backward-compatible-regeneration-merge-controller`

- **Purpose:** Regenerate projects after requirement/template/framework changes using semantic three-way merge, user-region ownership and compatibility gates.
- **Group/Priority/Risk:** `architecture-regeneration` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6
- **Dependencies:** `elmos-ai-generated-project-upgrader`, `elmos-code-generation-source-map-roundtrip-verifier`
- **Path:** `agent-skills/runtime/elmos-backward-compatible-regeneration-merge-controller/SKILL.md`

### `elmos-benchmark-contamination-leakage-detector`

- **Purpose:** Detect public, training, repository, prompt and evaluator contamination in hidden benchmarks and customer holdouts.
- **Group/Priority/Risk:** `qa-benchmark-integrity` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-benchmark-integrity-large-repository-certifier`, `elmos-ai-eval-dataset-governor`
- **Path:** `agent-skills/runtime/elmos-benchmark-contamination-leakage-detector/SKILL.md`

### `elmos-benchmark-integrity-large-repository-certifier`

- **Purpose:** Certify repository-scale productivity and correctness on hidden, contamination-checked, representative repositories including >500k and >1M LOC cases.
- **Group/Priority/Risk:** `benchmark-certification` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K8
- **Dependencies:** `elmos-test-matrix-covering-array-planner`, `elmos-customer-holdout-acceptance-controller`, `elmos-performance-statistical-gate`
- **Path:** `agent-skills/runtime/elmos-benchmark-integrity-large-repository-certifier/SKILL.md`

### `elmos-billing-quota-entitlement-generator`

- **Purpose:** Generate prepaid/usage/project billing, entitlement, quota, reservation, settlement and dispute evidence from machine usage ledgers.
- **Group/Priority/Risk:** `architecture-commercial` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6
- **Dependencies:** `elmos-ai-cost-pricing-sla-contract-compiler`, `elmos-cost-allocation-chargeback-showback-controller`
- **Path:** `agent-skills/runtime/elmos-billing-quota-entitlement-generator/SKILL.md`

### `elmos-browser-computer-use-safety-certifier`

- **Purpose:** Certify perception, action bounding, confirmation, domain allowlists, sensitive-field handling, rollback and visual evidence for browser/computer-use agents.
- **Group/Priority/Risk:** `model-computer-use` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-prompt-tool-security-redteam`, `elmos-human-oversight-consent-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-browser-computer-use-safety-certifier/SKILL.md`

### `elmos-budget-aware-quality-slo-optimizer`

- **Purpose:** Select model, test, retrieval, cache and infrastructure plans that maximize verified quality under hard cost, latency, risk and residency constraints.
- **Group/Priority/Risk:** `finops-optimization` / `P1` / `critical`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-model-routing-quality-cost-latency-optimizer`, `elmos-release-test-budget-risk-optimizer`
- **Path:** `agent-skills/runtime/elmos-budget-aware-quality-slo-optimizer/SKILL.md`

### `elmos-capacity-autoscaling-backpressure-planner`

- **Purpose:** Plan end-to-end queues, concurrency, rate limits, autoscaling, load shedding and admission control across agents, tools, stores and models.
- **Group/Priority/Risk:** `platform-capacity` / `P0` / `critical`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-capacity-soak-efficiency-certifier`, `elmos-ai-runaway-loop-economic-dos-guard`
- **Path:** `agent-skills/runtime/elmos-capacity-autoscaling-backpressure-planner/SKILL.md`

### `elmos-capacity-soak-efficiency-certifier`

- **Purpose:** Certify sustained throughput, concurrency, queue stability, resource leaks, cache behavior, model/provider limits and unit economics at declared capacity.
- **Group/Priority/Risk:** `operations-performance` / `P0` / `critical`
- **Kernels:** K2, K6, K8
- **Dependencies:** `elmos-performance-statistical-gate`, `elmos-slo-error-budget-release-governor`
- **Path:** `agent-skills/runtime/elmos-capacity-soak-efficiency-certifier/SKILL.md`

### `elmos-carbon-energy-efficiency-profiler`

- **Purpose:** Measure and optimize energy, accelerator utilization, region/time scheduling and carbon estimates without compromising correctness, privacy or SLA.
- **Group/Priority/Risk:** `platform-sustainability` / `P1` / `high`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-capacity-soak-efficiency-certifier`, `elmos-model-routing-quality-cost-latency-optimizer`
- **Path:** `agent-skills/runtime/elmos-carbon-energy-efficiency-profiler/SKILL.md`

### `elmos-cdc-exactly-once-ordering-verifier`

- **Purpose:** Verify source log capture, snapshot boundary, schema change, ordering, deduplication, tombstone and offset recovery for CDC pipelines.
- **Group/Priority/Risk:** `data-cdc-assurance` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-data-snapshot-cdc-controller`, `elmos-sql-dual-execution-oracle`
- **Path:** `agent-skills/runtime/elmos-cdc-exactly-once-ordering-verifier/SKILL.md`

### `elmos-certificate-deployment-admission-controller`

- **Purpose:** Admit deployment only when artifact, environment, policy, evidence freshness and independent certificate exactly match the requested production envelope.
- **Group/Priority/Risk:** `certification-deployment-admission` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-independent-k8-certificate-signer`, `elmos-runtime-admission-attestation-controller`
- **Path:** `agent-skills/runtime/elmos-certificate-deployment-admission-controller/SKILL.md`

### `elmos-certificate-drift-revocation-controller`

- **Purpose:** Continuously map code, model, data, policy, adapter, database, environment and vulnerability drift to evidence invalidation, certificate narrowing, suspension or revocation.
- **Group/Priority/Risk:** `certification-lifecycle` / `P0` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-ai-compatibility-drift-monitor`, `elmos-ai-e0-e5-certifier`
- **Path:** `agent-skills/runtime/elmos-certificate-drift-revocation-controller/SKILL.md`

### `elmos-certification-key-ceremony-hsm-controller`

- **Purpose:** Operate signer key generation, quorum activation, rotation, backup, compromise response and audit for independent K8 certificates.
- **Group/Priority/Risk:** `certification-key-management` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-independent-k8-certificate-signer`, `elmos-certification-policy-practice-authority`
- **Path:** `agent-skills/runtime/elmos-certification-key-ceremony-hsm-controller/SKILL.md`

### `elmos-certification-policy-practice-authority`

- **Purpose:** Define versioned certificate policies and certification practice statements for assurance levels, evidence classes, validity, revocation, audits and signer operations.
- **Group/Priority/Risk:** `certification-governance` / `P0` / `critical`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-certification-scope-compiler`, `elmos-certifier-independence-competence-governor`
- **Path:** `agent-skills/runtime/elmos-certification-policy-practice-authority/SKILL.md`

### `elmos-certification-scope-compiler`

- **Purpose:** Compile precise system, route, deployment, tenant, jurisdiction, assurance, exclusions and validity envelopes before any production certification run.
- **Group/Priority/Risk:** `certification-authority` / `P0` / `critical`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-ai-assurance-contract-compiler`, `elmos-ai-compliance-profile-compiler`
- **Path:** `agent-skills/runtime/elmos-certification-scope-compiler/SKILL.md`

### `elmos-certification-transparency-log-notary`

- **Purpose:** Publish append-only, privacy-safe certificate, revocation, signer and evidence-root events with inclusion and consistency proofs for independent verification.
- **Group/Priority/Risk:** `certification-transparency` / `P0` / `critical`
- **Kernels:** K6, K7, K8
- **Dependencies:** `elmos-independent-k8-certificate-signer`, `elmos-software-update-trust-root-governor`
- **Path:** `agent-skills/runtime/elmos-certification-transparency-log-notary/SKILL.md`

### `elmos-certifier-independence-competence-governor`

- **Purpose:** Enforce separation of duties, conflict-of-interest controls, assessor competence, witnessed reviews, rotation and audit trails for certification decisions.
- **Group/Priority/Risk:** `certification-governance` / `P0` / `critical`
- **Kernels:** K1, K7, K8
- **Dependencies:** `elmos-certification-scope-compiler`, `elmos-human-oversight-consent-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-certifier-independence-competence-governor/SKILL.md`

### `elmos-chaos-experiment-safety-governor`

- **Purpose:** Plan and authorize bounded failure injection with blast-radius, abort, observability, side-effect and restoration controls.
- **Group/Priority/Risk:** `qa-chaos-governance` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-chaos-recovery-verification-controller`, `elmos-human-oversight-consent-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-chaos-experiment-safety-governor/SKILL.md`

### `elmos-chaos-recovery-verification-controller`

- **Purpose:** Inject worker, process, network, storage, provider, database and region failures and verify checkpoint, fencing, reconciliation, RTO/RPO and safe degradation.
- **Group/Priority/Risk:** `qa-resilience` / `P0` / `critical`
- **Kernels:** K6, K7, K8
- **Dependencies:** `elmos-ai-durable-runtime-integrator`, `elmos-contract-integration-e2e-controller`
- **Path:** `agent-skills/runtime/elmos-chaos-recovery-verification-controller/SKILL.md`

### `elmos-chatgpt-apps-sdk-project-generator`

- **Purpose:** Generate MCP-backed ChatGPT plugin/app projects with tool plans, optional MCP Apps UI, CSP, authentication, submission metadata and review tests.
- **Group/Priority/Risk:** `protocol-openai-apps` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-openai-plugin-project-generator`, `elmos-mcp-apps-a2ui-generator`
- **Path:** `agent-skills/runtime/elmos-chatgpt-apps-sdk-project-generator/SKILL.md`

### `elmos-clean-room-reproducible-builder`

- **Purpose:** Rebuild release candidates in an isolated certification environment from frozen source, lockfiles and declared inputs, producing independent artifact and provenance evidence.
- **Group/Priority/Risk:** `certification-lab` / `P0` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-ai-revision-set-freezer`, `elmos-ai-supply-chain-performance-resilience-certifier`
- **Path:** `agent-skills/runtime/elmos-clean-room-reproducible-builder/SKILL.md`

### `elmos-code-generation-source-map-roundtrip-verifier`

- **Purpose:** Verify source-to-IR-to-target lineage, symbol identity, comments, diagnostics, coverage and debugger mappings across regeneration and reverse import.
- **Group/Priority/Risk:** `polyglot-lineage` / `P0` / `critical`
- **Kernels:** K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-target-language-backend-emitter`, `elmos-ai-roundtrip-migration-controller`
- **Path:** `agent-skills/runtime/elmos-code-generation-source-map-roundtrip-verifier/SKILL.md`

### `elmos-compiler-codemod-rule-corpus-governor`

- **Purpose:** Curate deterministic rewrite rules, fixtures, semantic preservation contracts, provenance, coverage, conflict handling and promotion across language routes.
- **Group/Priority/Risk:** `polyglot-rules` / `P0` / `critical`
- **Kernels:** K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-target-language-backend-emitter`, `elmos-counterexample-regression-promoter`
- **Path:** `agent-skills/runtime/elmos-compiler-codemod-rule-corpus-governor/SKILL.md`

### `elmos-compiler-frontend-conformance-certifier`

- **Purpose:** Certify compiler-native, lossless and runtime-assisted source frontends against language conformance corpora before their facts may become semantic authority.
- **Group/Priority/Risk:** `polyglot-frontend` / `P0` / `critical`
- **Kernels:** K2, K3, K6, K8
- **Dependencies:** `elmos-language-semantic-profile-compiler`, `elmos-ai-generated-project-conformance-validator`
- **Path:** `agent-skills/runtime/elmos-compiler-frontend-conformance-certifier/SKILL.md`

### `elmos-confidential-computing-attestation-controller`

- **Purpose:** Verify enclave/TEE identity, measurement, nonce freshness, workload/image binding, key release and evidence appraisal for sensitive execution.
- **Group/Priority/Risk:** `security-confidential` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-runtime-admission-attestation-controller`, `elmos-customer-vpc-runner-attestation-certifier`
- **Path:** `agent-skills/runtime/elmos-confidential-computing-attestation-controller/SKILL.md`

### `elmos-content-safety-policy-classifier-orchestrator`

- **Purpose:** Compose deterministic rules, provider classifiers, custom models and human escalation under versioned safety policy and measurable error trade-offs.
- **Group/Priority/Risk:** `governance-content-safety` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-security-governance-compiler`, `elmos-ai-judge-calibration-stochastic-assurance`
- **Path:** `agent-skills/runtime/elmos-content-safety-policy-classifier-orchestrator/SKILL.md`

### `elmos-continuous-control-monitoring-engine`

- **Purpose:** Continuously evaluate runtime, security, compliance, quality, SLO and certification controls against current evidence and trigger restriction, incident or recertification.
- **Group/Priority/Risk:** `governance-continuous-control` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-runtime-policy-continuous-compliance-monitor`, `elmos-certificate-drift-revocation-controller`
- **Path:** `agent-skills/runtime/elmos-continuous-control-monitoring-engine/SKILL.md`

### `elmos-contract-integration-e2e-controller`

- **Purpose:** Generate and run provider/consumer, API, event, tool, MCP/A2A, database integration and end-to-end journey suites against real dependencies.
- **Group/Priority/Risk:** `qa-execution` / `P0` / `critical`
- **Kernels:** K5, K6, K7
- **Dependencies:** `elmos-test-fixture-data-factory`, `elmos-ai-generated-project-conformance-validator`
- **Path:** `agent-skills/runtime/elmos-contract-integration-e2e-controller/SKILL.md`

### `elmos-contract-smt-symbolic-execution-verifier`

- **Purpose:** Verify data, authorization, transformation and routine contracts with SMT and symbolic execution under explicit path and resource bounds.
- **Group/Priority/Risk:** `formal-symbolic` / `P0` / `critical`
- **Kernels:** K3, K4, K6, K8
- **Dependencies:** `elmos-semantic-gap-obligation-generator`, `elmos-sql-routine-trigger-ir-compiler`
- **Path:** `agent-skills/runtime/elmos-contract-smt-symbolic-execution-verifier/SKILL.md`

### `elmos-cost-allocation-chargeback-showback-controller`

- **Purpose:** Allocate model, compute, storage, network, database and support costs to tenant, project, route and feature with explainable reconciliation.
- **Group/Priority/Risk:** `platform-finops` / `P1` / `high`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-observability-finops-generator`, `elmos-ai-cost-pricing-sla-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-cost-allocation-chargeback-showback-controller/SKILL.md`

### `elmos-counterexample-regression-promoter`

- **Purpose:** Promote minimized verifier, fuzz, differential, security and production incident counterexamples into governed permanent regression assets and rule-improvement candidates.
- **Group/Priority/Risk:** `qa-learning` / `P0` / `critical`
- **Kernels:** K4, K5, K6, K8
- **Dependencies:** `elmos-property-metamorphic-mutation-fuzz-controller`, `elmos-flake-quarantine-governor`, `elmos-cross-language-database-differential-runner`
- **Path:** `agent-skills/runtime/elmos-counterexample-regression-promoter/SKILL.md`

### `elmos-counterexample-to-rule-skill-promotion-controller`

- **Purpose:** Turn verified recurring counterexamples into deterministic rules, tests, Skills or adapter improvements through isolated review, canary and rollback.
- **Group/Priority/Risk:** `learning-promotion` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-compiler-codemod-rule-corpus-governor`, `elmos-user-feedback-issue-to-eval-dataset-pipeline`
- **Path:** `agent-skills/runtime/elmos-counterexample-to-rule-skill-promotion-controller/SKILL.md`

### `elmos-coverage-semantic-obligation-mapper`

- **Purpose:** Map line, branch, mutation, state, protocol, data, security and scenario coverage to Proof Obligations instead of optimizing a single percentage.
- **Group/Priority/Risk:** `qa-coverage` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-proof-to-validation-dag-compiler`, `elmos-property-metamorphic-mutation-fuzz-controller`
- **Path:** `agent-skills/runtime/elmos-coverage-semantic-obligation-mapper/SKILL.md`

### `elmos-cross-language-concurrency-memory-model-verifier`

- **Purpose:** Verify that generated or migrated code preserves happens-before, atomicity, cancellation, scheduling and shared-state invariants across incompatible language runtimes.
- **Group/Priority/Risk:** `polyglot-concurrency` / `P0` / `critical`
- **Kernels:** K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-language-semantic-profile-compiler`, `elmos-polyglot-differential-runtime`
- **Path:** `agent-skills/runtime/elmos-cross-language-concurrency-memory-model-verifier/SKILL.md`

### `elmos-cross-language-database-differential-runner`

- **Purpose:** Run joint source/target application and source/target database scenarios to detect interaction defects that isolated code or SQL tests miss.
- **Group/Priority/Risk:** `qa-differential` / `P0` / `critical`
- **Kernels:** K3, K6, K7
- **Dependencies:** `elmos-polyglot-differential-runtime`, `elmos-sql-dual-execution-oracle`
- **Path:** `agent-skills/runtime/elmos-cross-language-database-differential-runner/SKILL.md`

### `elmos-cross-language-numeric-time-unicode-conformance-suite`

- **Purpose:** Generate and execute edge-case corpora for overflow, decimal, NaN, timezone, calendar, collation, normalization, grapheme and locale behavior across target languages.
- **Group/Priority/Risk:** `polyglot-value-semantics` / `P0` / `critical`
- **Kernels:** K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-language-semantic-profile-compiler`, `elmos-semantic-gap-obligation-generator`
- **Path:** `agent-skills/runtime/elmos-cross-language-numeric-time-unicode-conformance-suite/SKILL.md`

### `elmos-cross-language-serialization-wire-compatibility-verifier`

- **Purpose:** Preserve JSON, Protobuf, Avro, MessagePack and custom wire contracts across language generators, including defaults, unknown fields, precision, ordering and schema evolution.
- **Group/Priority/Risk:** `polyglot-wire` / `P0` / `critical`
- **Kernels:** K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-tool-contract-compatibility-verifier`, `elmos-polyglot-differential-runtime`
- **Path:** `agent-skills/runtime/elmos-cross-language-serialization-wire-compatibility-verifier/SKILL.md`

### `elmos-cross-store-polyglot-persistence-route-planner`

- **Purpose:** Select relational, document, key-value, graph, search, vector and lakehouse targets per bounded context using workload, semantics, reversibility and operational evidence.
- **Group/Priority/Risk:** `data-route-planning` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-target-portfolio-planner`, `elmos-database-dialect-profile-registry`
- **Path:** `agent-skills/runtime/elmos-cross-store-polyglot-persistence-route-planner/SKILL.md`

### `elmos-customer-holdout-acceptance-controller`

- **Purpose:** Govern hidden customer scenarios, independent labels, contamination controls, execution, review and cryptographic acceptance for commercial Golden Routes.
- **Group/Priority/Risk:** `certification-acceptance` / `P0` / `critical`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-native-conformance-lab-controller`, `elmos-ai-eval-dataset-governor`
- **Path:** `agent-skills/runtime/elmos-customer-holdout-acceptance-controller/SKILL.md`

### `elmos-customer-vpc-runner-attestation-certifier`

- **Purpose:** Certify customer-hosted runners for identity, isolation, data residency, network, secrets, toolchain, evidence delivery and recovery without requiring source exfiltration.
- **Group/Priority/Risk:** `enterprise-edge-certification` / `P0` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-runtime-admission-attestation-controller`, `elmos-agent-workload-delegated-identity-controller`
- **Path:** `agent-skills/runtime/elmos-customer-vpc-runner-attestation-certifier/SKILL.md`

### `elmos-data-lineage-impact-governor`

- **Purpose:** Collect and verify dataset, column, model, prompt, retrieval and generated-artifact lineage so changes invalidate every affected route and certificate.
- **Group/Priority/Risk:** `data-lineage` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-artifact-provenance-packager`, `elmos-certificate-drift-revocation-controller`
- **Path:** `agent-skills/runtime/elmos-data-lineage-impact-governor/SKILL.md`

### `elmos-data-quality-contract-anomaly-verifier`

- **Purpose:** Define and enforce completeness, freshness, validity, uniqueness, distribution, drift and business-invariant contracts for operational, RAG and evaluation data.
- **Group/Priority/Risk:** `data-quality` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-data-contract-quality-governor`, `elmos-test-fixture-data-factory`
- **Path:** `agent-skills/runtime/elmos-data-quality-contract-anomaly-verifier/SKILL.md`

### `elmos-data-retention-archive-tiering-controller`

- **Purpose:** Compile retention, legal hold, hot/warm/cold tiering, archive verification and deletion propagation across databases, object stores, indexes, caches and backups.
- **Group/Priority/Risk:** `data-lifecycle` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-retention-erasure-verifier`, `elmos-data-lineage-impact-governor`
- **Path:** `agent-skills/runtime/elmos-data-retention-archive-tiering-controller/SKILL.md`

### `elmos-data-snapshot-cdc-controller`

- **Purpose:** Execute initial snapshots, change data capture, ordering, deduplication, tombstones, gap detection and final reconciliation for database migration.
- **Group/Priority/Risk:** `database-data-migration` / `P0` / `critical`
- **Kernels:** K2, K5, K6, K7
- **Dependencies:** `elmos-database-schema-migration-planner`, `elmos-ai-durable-runtime-integrator`
- **Path:** `agent-skills/runtime/elmos-data-snapshot-cdc-controller/SKILL.md`

### `elmos-data-sovereignty-residency-route-controller`

- **Purpose:** Route data, models, logs, backups and support access across regions/providers under residency, transfer, encryption and deletion policy.
- **Group/Priority/Risk:** `governance-data-residency` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-provider-data-residency-controller`, `elmos-cross-store-polyglot-persistence-route-planner`
- **Path:** `agent-skills/runtime/elmos-data-sovereignty-residency-route-controller/SKILL.md`

### `elmos-database-backup-pitr-failover-certifier`

- **Purpose:** Certify backups, point-in-time recovery, replica promotion, consistency, encryption, retention and application reconnect behavior for every stateful target.
- **Group/Priority/Risk:** `data-resilience` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-disaster-recovery-business-continuity-certifier`, `elmos-database-cutover-rollback-certifier`
- **Path:** `agent-skills/runtime/elmos-database-backup-pitr-failover-certifier/SKILL.md`

### `elmos-database-cutover-rollback-certifier`

- **Purpose:** Certify snapshot/CDC reconciliation, write freeze or dual-write, final cutover, rollback window and source retirement with no unexplained data loss.
- **Group/Priority/Risk:** `database-certification` / `P0` / `critical`
- **Kernels:** K5, K6, K7, K8
- **Dependencies:** `elmos-data-snapshot-cdc-controller`, `elmos-transaction-locking-equivalence-verifier`, `elmos-ai-e0-e5-certifier`
- **Path:** `agent-skills/runtime/elmos-database-cutover-rollback-certifier/SKILL.md`

### `elmos-database-dialect-profile-registry`

- **Purpose:** Govern exact database engine, version, compatibility mode, charset, collation, driver, extension and operational semantic profiles.
- **Group/Priority/Risk:** `database-profile` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K6
- **Dependencies:** `elmos-ai-target-portfolio-planner`, `elmos-ai-compatibility-drift-monitor`
- **Path:** `agent-skills/runtime/elmos-database-dialect-profile-registry/SKILL.md`

### `elmos-database-extension-compatibility-governor`

- **Purpose:** Inventory and govern database extensions, plugins, collations, procedural languages and managed-service restrictions during dialect selection and migration.
- **Group/Priority/Risk:** `data-extension` / `P0` / `high`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-database-dialect-profile-registry`, `elmos-sql-semantic-gap-analyzer`
- **Path:** `agent-skills/runtime/elmos-database-extension-compatibility-governor/SKILL.md`

### `elmos-database-performance-plan-certifier`

- **Purpose:** Certify representative query plans, latency, throughput, resource use, statistics sensitivity and capacity under target database versions and data distributions.
- **Group/Priority/Risk:** `database-performance` / `P0` / `critical`
- **Kernels:** K2, K6, K8
- **Dependencies:** `elmos-sql-dual-execution-oracle`, `elmos-performance-statistical-gate`
- **Path:** `agent-skills/runtime/elmos-database-performance-plan-certifier/SKILL.md`

### `elmos-database-schema-migration-planner`

- **Purpose:** Plan expand/contract, online DDL, dependency order, backfill, validation, compatibility windows and reversible schema migrations.
- **Group/Priority/Risk:** `database-migration` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-sql-catalog-ir-compiler`, `elmos-sql-dialect-lowering-engine`
- **Path:** `agent-skills/runtime/elmos-database-schema-migration-planner/SKILL.md`

### `elmos-database-security-authorization-equivalence-verifier`

- **Purpose:** Verify roles, grants, row/column security, masking, encryption, auditing and privileged routines remain equivalent or explicitly strengthened across database routes.
- **Group/Priority/Risk:** `data-security-equivalence` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-database-dialect-profile-registry`, `elmos-api-authz-rbac-abac-rebac-equivalence-verifier`
- **Path:** `agent-skills/runtime/elmos-database-security-authorization-equivalence-verifier/SKILL.md`

### `elmos-dependency-malware-provenance-quarantine-controller`

- **Purpose:** Detect suspicious packages, build scripts, binaries and publisher changes; quarantine artifacts pending provenance and behavior review.
- **Group/Priority/Risk:** `security-supply-chain` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-vulnerability-vex-kev-response-governor`, `elmos-agent-skill-mcp-supply-chain-certifier`
- **Path:** `agent-skills/runtime/elmos-dependency-malware-provenance-quarantine-controller/SKILL.md`

### `elmos-dependency-update-renovation-controller`

- **Purpose:** Continuously propose, test and promote dependency, framework and toolchain upgrades with semantic impact, security and rollback evidence.
- **Group/Priority/Risk:** `platform-dependency-lifecycle` / `P0` / `critical`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-generated-project-upgrader`, `elmos-vulnerability-vex-kev-response-governor`
- **Path:** `agent-skills/runtime/elmos-dependency-update-renovation-controller/SKILL.md`

### `elmos-deterministic-record-replay-model-tool-harness`

- **Purpose:** Capture normalized model, tool, retrieval, clock, randomness and external observations for deterministic debugging and bounded regression replay.
- **Group/Priority/Risk:** `qa-record-replay` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-ai-normalized-agent-trace-recorder`, `elmos-ai-durable-runtime-integrator`
- **Path:** `agent-skills/runtime/elmos-deterministic-record-replay-model-tool-harness/SKILL.md`

### `elmos-devcontainer-nix-hermetic-environment-generator`

- **Purpose:** Generate reproducible local and CI development environments with pinned toolchains, services, policies and offline verification.
- **Group/Priority/Risk:** `platform-dev-environment` / `P1` / `high`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-hermetic-build-environment-attestation-controller`, `elmos-polyglot-build-toolchain-orchestrator`
- **Path:** `agent-skills/runtime/elmos-devcontainer-nix-hermetic-environment-generator/SKILL.md`

### `elmos-disaster-recovery-business-continuity-certifier`

- **Purpose:** Certify backup, restore, regional failover, dependency loss, key recovery, evidence continuity and documented RTO/RPO under business continuity scenarios.
- **Group/Priority/Risk:** `operations-resilience` / `P0` / `critical`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-chaos-recovery-verification-controller`, `elmos-production-deployment-certifier`
- **Path:** `agent-skills/runtime/elmos-disaster-recovery-business-continuity-certifier/SKILL.md`

### `elmos-distributed-consistency-invariant-verifier`

- **Purpose:** Verify business invariants across services, stores, caches and event streams under concurrency, partitions, retries and failover.
- **Group/Priority/Risk:** `event-consistency` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-transaction-locking-equivalence-verifier`, `elmos-proof-to-validation-dag-compiler`
- **Path:** `agent-skills/runtime/elmos-distributed-consistency-invariant-verifier/SKILL.md`

### `elmos-distributed-invariant-tla-alloy-verifier`

- **Purpose:** Encode leases, fencing, outbox, replication, saga and multi-agent coordination models for bounded exhaustive verification.
- **Group/Priority/Risk:** `formal-distributed` / `P0` / `critical`
- **Kernels:** K3, K4, K6, K8
- **Dependencies:** `elmos-ai-durable-runtime-integrator`, `elmos-distributed-consistency-invariant-verifier`
- **Path:** `agent-skills/runtime/elmos-distributed-invariant-tla-alloy-verifier/SKILL.md`

### `elmos-distributed-sql-sharding-placement-compiler`

- **Purpose:** Compile sharding, locality, replica, consistency, rebalance, global index and distributed transaction semantics for distributed SQL targets.
- **Group/Priority/Risk:** `data-distributed-sql` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-database-dialect-profile-registry`, `elmos-transaction-locking-equivalence-verifier`
- **Path:** `agent-skills/runtime/elmos-distributed-sql-sharding-placement-compiler/SKILL.md`

### `elmos-domain-driven-architecture-synthesizer`

- **Purpose:** Recover domains, bounded contexts, aggregates, policies and integration contracts, then generate explicit architecture candidates and trade-offs.
- **Group/Priority/Risk:** `architecture-domain` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6
- **Dependencies:** `elmos-ai-requirement-contract-compiler`, `elmos-ai-solution-archetype-selector`
- **Path:** `agent-skills/runtime/elmos-domain-driven-architecture-synthesizer/SKILL.md`

### `elmos-dual-write-outbox-saga-consistency-verifier`

- **Purpose:** Verify atomic publication, outbox relay, inbox deduplication, saga compensation and cross-store business invariants during migration and steady-state operation.
- **Group/Priority/Risk:** `data-distributed-consistency` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-data-snapshot-cdc-controller`, `elmos-ai-graph-liveness-side-effect-verifier`
- **Path:** `agent-skills/runtime/elmos-dual-write-outbox-saga-consistency-verifier/SKILL.md`

### `elmos-embedding-reranker-model-lifecycle-governor`

- **Purpose:** Govern embedding/reranker selection, versioning, dimensionality, index compatibility, re-embedding, evaluation and rollback.
- **Group/Priority/Risk:** `model-retrieval-lifecycle` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-rag-semantic-compiler`, `elmos-vector-database-index-ir-compiler`
- **Path:** `agent-skills/runtime/elmos-embedding-reranker-model-lifecycle-governor/SKILL.md`

### `elmos-enterprise-assurance-dossier-generator`

- **Purpose:** Generate an evidence-backed, redacted and versioned customer procurement dossier covering architecture, security, privacy, AI governance, quality, resilience, supply chain and certification status.
- **Group/Priority/Risk:** `commercial-assurance` / `P0` / `high`
- **Kernels:** K1, K2, K6, K8
- **Dependencies:** `elmos-external-audit-oscal-evidence-exporter`, `elmos-independent-k8-certificate-signer`, `elmos-operability-support-readiness-certifier`, `elmos-ai-system-impact-assessment-compiler`, `elmos-privacy-impact-consent-purpose-verifier`, `elmos-open-source-license-ip-compliance-certifier`, `elmos-vulnerability-vex-kev-response-governor`
- **Path:** `agent-skills/runtime/elmos-enterprise-assurance-dossier-generator/SKILL.md`

### `elmos-enterprise-identity-sso-scim-generator`

- **Purpose:** Generate OIDC/SAML SSO, SCIM lifecycle, group/role mapping, session, MFA, service identity and break-glass integration.
- **Group/Priority/Risk:** `architecture-enterprise-identity` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6
- **Dependencies:** `elmos-agent-workload-delegated-identity-controller`, `elmos-zero-trust-service-identity-policy-compiler`
- **Path:** `agent-skills/runtime/elmos-enterprise-identity-sso-scim-generator/SKILL.md`

### `elmos-environment-parity-config-drift-certifier`

- **Purpose:** Compare development, test, certification and production environments across images, flags, policies, dependencies, data features and managed-service parameters.
- **Group/Priority/Risk:** `operations-certification` / `P0` / `critical`
- **Kernels:** K2, K6, K8
- **Dependencies:** `elmos-production-deployment-certifier`, `elmos-ai-compatibility-drift-monitor`
- **Path:** `agent-skills/runtime/elmos-environment-parity-config-drift-certifier/SKILL.md`

### `elmos-eu-ai-act-post-market-monitoring-controller`

- **Purpose:** Generate risk-based post-market monitoring, logging, feedback, incident, corrective action and evidence workflows for applicable AI systems.
- **Group/Priority/Risk:** `governance-post-market` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-regulatory-obligation-effective-date-monitor`, `elmos-ai-system-impact-assessment-compiler`
- **Path:** `agent-skills/runtime/elmos-eu-ai-act-post-market-monitoring-controller/SKILL.md`

### `elmos-eval-observability-platform-integrator`

- **Purpose:** Integrate MLflow, Phoenix, LangSmith and OpenInference-compatible systems while retaining Elmos evidence, tenant, privacy and completion authority.
- **Group/Priority/Risk:** `observability` / `P1` / `high`
- **Kernels:** K2, K6, K7
- **Dependencies:** `elmos-genai-telemetry-profile-compiler`, `elmos-ai-eval-dataset-governor`
- **Path:** `agent-skills/runtime/elmos-eval-observability-platform-integrator/SKILL.md`

### `elmos-event-replay-idempotency-certifier`

- **Purpose:** Certify deterministic replay, deduplication, snapshot restore, side-effect suppression and audit equivalence for event-sourced and stream-processing systems.
- **Group/Priority/Risk:** `event-replay` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-deterministic-record-replay-model-tool-harness`, `elmos-ai-durable-runtime-integrator`
- **Path:** `agent-skills/runtime/elmos-event-replay-idempotency-certifier/SKILL.md`

### `elmos-event-stream-storage-ir-compiler`

- **Purpose:** Compile topics, partitions, keys, ordering, retention, compaction, consumer groups, offsets and transactional publication semantics.
- **Group/Priority/Risk:** `data-stream-ir` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-tool-protocol-compiler`, `elmos-data-snapshot-cdc-controller`
- **Path:** `agent-skills/runtime/elmos-event-stream-storage-ir-compiler/SKILL.md`

### `elmos-evidence-worm-merkle-sealer`

- **Purpose:** Seal commands, inputs, artifacts, traces, proof results and approvals into immutable evidence bundles with chain of custody, Merkle roots, retention and legal hold.
- **Group/Priority/Risk:** `certification-evidence` / `P0` / `critical`
- **Kernels:** K6, K7, K8
- **Dependencies:** `elmos-ai-artifact-provenance-packager`
- **Path:** `agent-skills/runtime/elmos-evidence-worm-merkle-sealer/SKILL.md`

### `elmos-explainability-decision-recourse-generator`

- **Purpose:** Generate bounded explanations, evidence links, uncertainty, counterfactuals and appeal/recourse paths for AI-assisted decisions.
- **Group/Priority/Risk:** `interaction-explainability` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-regulated-decision-explainability-packager`, `elmos-agent-human-ux-safety-verifier`
- **Path:** `agent-skills/runtime/elmos-explainability-decision-recourse-generator/SKILL.md`

### `elmos-external-audit-oscal-evidence-exporter`

- **Purpose:** Export scoped controls, implementations, assessment plans, results, findings, POA&M and evidence references in OSCAL-compatible and auditor-friendly packages.
- **Group/Priority/Risk:** `certification-audit` / `P0` / `high`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-structured-assurance-case-compiler`, `elmos-certifier-independence-competence-governor`, `elmos-ai-compliance-profile-compiler`
- **Path:** `agent-skills/runtime/elmos-external-audit-oscal-evidence-exporter/SKILL.md`

### `elmos-fault-localization-root-cause-synthesizer`

- **Purpose:** Correlate counterexamples, traces, diffs, changes and dependency graphs to rank root causes and bounded repair locations without becoming the correctness oracle.
- **Group/Priority/Risk:** `qa-diagnostics` / `P1` / `high`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-counterexample-regression-promoter`, `elmos-ai-normalized-agent-trace-recorder`
- **Path:** `agent-skills/runtime/elmos-fault-localization-root-cause-synthesizer/SKILL.md`

### `elmos-federated-retrieval-data-source-router`

- **Purpose:** Route queries across private, remote, SQL, search, graph and vector sources under capability, authorization, freshness, latency and cost constraints.
- **Group/Priority/Risk:** `knowledge-federated-retrieval` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-capability-negotiator`, `elmos-agent-registry-resource-discovery-governor`
- **Path:** `agent-skills/runtime/elmos-federated-retrieval-data-source-router/SKILL.md`

### `elmos-ffi-abi-native-boundary-certifier`

- **Purpose:** Model and certify calling conventions, layout, ownership, lifetime, error, thread and binary compatibility at JNI, P/Invoke, C ABI, WebAssembly and native-library boundaries.
- **Group/Priority/Risk:** `polyglot-native-boundary` / `P0` / `critical`
- **Kernels:** K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-language-semantic-profile-compiler`, `elmos-compiler-frontend-conformance-certifier`
- **Path:** `agent-skills/runtime/elmos-ffi-abi-native-boundary-certifier/SKILL.md`

### `elmos-fine-tuning-adapter-training-pipeline-generator`

- **Purpose:** Generate governed SFT, preference, distillation and PEFT/LoRA pipelines with data lineage, evaluation, safety, reproducibility and promotion gates.
- **Group/Priority/Risk:** `model-training` / `P1` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-eval-dataset-governor`, `elmos-ai-bom-provenance-generator`
- **Path:** `agent-skills/runtime/elmos-fine-tuning-adapter-training-pipeline-generator/SKILL.md`

### `elmos-flake-quarantine-governor`

- **Purpose:** Detect, classify, quarantine and remediate flaky tests without allowing retries or quarantine to make critical release gates falsely green.
- **Group/Priority/Risk:** `qa-quality` / `P0` / `high`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-test-matrix-covering-array-planner`
- **Path:** `agent-skills/runtime/elmos-flake-quarantine-governor/SKILL.md`

### `elmos-formal-counterexample-to-regression-compiler`

- **Purpose:** Translate solver and model-checker traces into deterministic unit, integration, concurrency and fault tests with exact assumptions.
- **Group/Priority/Risk:** `formal-counterexample` / `P0` / `critical`
- **Kernels:** K3, K4, K6, K8
- **Dependencies:** `elmos-counterexample-regression-promoter`, `elmos-protocol-state-machine-model-checker`
- **Path:** `agent-skills/runtime/elmos-formal-counterexample-to-regression-compiler/SKILL.md`

### `elmos-formal-method-selection-router`

- **Purpose:** Select SMT, symbolic execution, model checking, proof assistant, abstract interpretation or runtime monitoring per obligation, language and assurance envelope.
- **Group/Priority/Risk:** `formal-routing` / `P0` / `critical`
- **Kernels:** K3, K4, K6, K8
- **Dependencies:** `elmos-ai-assurance-contract-compiler`, `elmos-authoritative-oracle-registry`
- **Path:** `agent-skills/runtime/elmos-formal-method-selection-router/SKILL.md`

### `elmos-framework-runtime-bridge-compiler`

- **Purpose:** Compile framework lifecycle, dependency injection, routing, state, transaction, security, streaming and observability semantics across language targets.
- **Group/Priority/Risk:** `polyglot-framework` / `P0` / `critical`
- **Kernels:** K2, K3, K5, K6
- **Dependencies:** `elmos-language-semantic-profile-compiler`, `elmos-ai-workflow-state-machine-compiler`
- **Path:** `agent-skills/runtime/elmos-framework-runtime-bridge-compiler/SKILL.md`

### `elmos-genai-telemetry-profile-compiler`

- **Purpose:** Compile versioned OpenTelemetry/OpenInference-compatible GenAI traces, metrics and logs with privacy, cardinality, sampling, cost and evidence-binding rules.
- **Group/Priority/Risk:** `observability` / `P0` / `high`
- **Kernels:** K2, K6, K7
- **Dependencies:** `elmos-ai-observability-finops-generator`, `elmos-ai-normalized-agent-trace-recorder`
- **Path:** `agent-skills/runtime/elmos-genai-telemetry-profile-compiler/SKILL.md`

### `elmos-generated-api-event-schema-evolution-controller`

- **Purpose:** Govern versioning and compatibility for generated REST, GraphQL, gRPC, event and tool contracts across regeneration, migration and rolling deployment.
- **Group/Priority/Risk:** `polyglot-contract-evolution` / `P0` / `critical`
- **Kernels:** K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-tool-contract-compatibility-verifier`, `elmos-model-response-schema-evolution-controller`
- **Path:** `agent-skills/runtime/elmos-generated-api-event-schema-evolution-controller/SKILL.md`

### `elmos-generated-code-secure-defaults-verifier`

- **Purpose:** Verify authentication, authorization, validation, cryptography, logging, headers, network and dependency defaults in every generated repository.
- **Group/Priority/Risk:** `security-generated-code` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-generated-project-conformance-validator`, `elmos-static-analysis-multilanguage-security-orchestrator`
- **Path:** `agent-skills/runtime/elmos-generated-code-secure-defaults-verifier/SKILL.md`

### `elmos-generated-project-documentation-diagram-runbook-generator`

- **Purpose:** Generate evidence-linked architecture, API, data flow, threat, deployment, operations and recovery documentation that updates incrementally.
- **Group/Priority/Risk:** `architecture-documentation` / `P1` / `high`
- **Kernels:** K1, K2, K3, K5, K6
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-enterprise-assurance-dossier-generator`
- **Path:** `agent-skills/runtime/elmos-generated-project-documentation-diagram-runbook-generator/SKILL.md`

### `elmos-generated-project-telemetry-learning-governor`

- **Purpose:** Use privacy-governed production telemetry to improve templates, routes and tests while preserving tenant boundaries, consent and independent validation.
- **Group/Priority/Risk:** `learning-telemetry` / `P1` / `critical`
- **Kernels:** K1, K2, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-observability-cardinality-privacy-governor`, `elmos-user-feedback-issue-to-eval-dataset-pipeline`
- **Path:** `agent-skills/runtime/elmos-generated-project-telemetry-learning-governor/SKILL.md`

### `elmos-generated-repository-maintainability-evolution-certifier`

- **Purpose:** Certify generated repositories for analyzability, modularity, testability, changeability, ownership, documentation, upgradeability and bounded technical debt.
- **Group/Priority/Risk:** `product-quality` / `P0` / `high`
- **Kernels:** K2, K3, K6, K8
- **Dependencies:** `elmos-ai-quality-model-evaluation-compiler`, `elmos-polyglot-route-matrix-governor`, `elmos-ai-generated-project-upgrader`
- **Path:** `agent-skills/runtime/elmos-generated-repository-maintainability-evolution-certifier/SKILL.md`

### `elmos-gitops-argocd-flux-release-controller`

- **Purpose:** Generate signed declarative release, environment promotion, health, rollback and drift reconciliation workflows.
- **Group/Priority/Risk:** `platform-gitops` / `P0` / `critical`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-production-deployment-certifier`, `elmos-ai-artifact-provenance-packager`
- **Path:** `agent-skills/runtime/elmos-gitops-argocd-flux-release-controller/SKILL.md`

### `elmos-gpu-accelerator-capacity-scheduler`

- **Purpose:** Schedule heterogeneous GPUs/NPUs, model replicas, batching and preemption under memory, topology, fairness, SLO and cost constraints.
- **Group/Priority/Risk:** `model-capacity` / `P1` / `high`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-capacity-autoscaling-backpressure-planner`, `elmos-model-serving-runtime-profile-compiler`
- **Path:** `agent-skills/runtime/elmos-gpu-accelerator-capacity-scheduler/SKILL.md`

### `elmos-graph-database-semantic-ir-compiler`

- **Purpose:** Compile property graph, RDF, ontology, traversal, constraint and transaction semantics for Neo4j, Gremlin and SPARQL-class targets.
- **Group/Priority/Risk:** `data-graph-ir` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-sql-catalog-ir-compiler`, `elmos-ai-rag-semantic-compiler`
- **Path:** `agent-skills/runtime/elmos-graph-database-semantic-ir-compiler/SKILL.md`

### `elmos-graphrag-pipeline-certifier`

- **Purpose:** Certify graph construction, community/entity retrieval, path grounding, citations, updates, deletion and performance for GraphRAG implementations.
- **Group/Priority/Risk:** `knowledge-graphrag` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-knowledge-graph-ontology-ir-compiler`, `elmos-ai-rag-retrieval-grounding-certifier`
- **Path:** `agent-skills/runtime/elmos-graphrag-pipeline-certifier/SKILL.md`

### `elmos-hermetic-build-environment-attestation-controller`

- **Purpose:** Attest builder image, kernel, toolchain, network policy, inputs, identity and isolation so clean-room results can be trusted beyond a build log.
- **Group/Priority/Risk:** `supply-chain-attestation` / `P0` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-clean-room-reproducible-builder`, `elmos-agent-workload-delegated-identity-controller`
- **Path:** `agent-skills/runtime/elmos-hermetic-build-environment-attestation-controller/SKILL.md`

### `elmos-hermetic-remote-build-cache-governor`

- **Purpose:** Govern remote execution and build caches with content addressing, toolchain/environment keys, tenant isolation, provenance and poisoning detection.
- **Group/Priority/Risk:** `platform-build-cache` / `P0` / `critical`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-hermetic-build-environment-attestation-controller`, `elmos-monorepo-build-graph-sharding-optimizer`
- **Path:** `agent-skills/runtime/elmos-hermetic-remote-build-cache-governor/SKILL.md`

### `elmos-human-factors-cognitive-load-evaluator`

- **Purpose:** Evaluate operator comprehension, interruption, trust calibration, alert fatigue, approval quality and recovery performance for agentic systems.
- **Group/Priority/Risk:** `interaction-human-factors` / `P1` / `high`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-agent-human-ux-safety-verifier`, `elmos-ai-quality-model-evaluation-compiler`
- **Path:** `agent-skills/runtime/elmos-human-factors-cognitive-load-evaluator/SKILL.md`

### `elmos-human-oversight-consent-contract-compiler`

- **Purpose:** Compile auditable human oversight contracts for high-risk decisions, dual control, consent scope, approval TTL, escalation, revocation and parameter binding.
- **Group/Priority/Risk:** `governance` / `P0` / `critical`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-ai-security-governance-compiler`, `elmos-ai-workflow-state-machine-compiler`
- **Path:** `agent-skills/runtime/elmos-human-oversight-consent-contract-compiler/SKILL.md`

### `elmos-i18n-l10n-conformance-verifier`

- **Purpose:** Verify Unicode, locale, language, timezone, calendar, plural, number, currency, collation, bidirectional text and translated UX across generated projects.
- **Group/Priority/Risk:** `product-quality` / `P1` / `high`
- **Kernels:** K2, K3, K6
- **Dependencies:** `elmos-ai-quality-model-evaluation-compiler`, `elmos-language-semantic-profile-compiler`, `elmos-ai-interaction-channel-compiler`
- **Path:** `agent-skills/runtime/elmos-i18n-l10n-conformance-verifier/SKILL.md`

### `elmos-incident-command-runbook-automation-generator`

- **Purpose:** Generate role-based incident workflows, diagnostics, communications, mitigations, evidence preservation and recovery gates.
- **Group/Priority/Risk:** `platform-incident` / `P0` / `critical`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-incident-kill-switch-controller`, `elmos-security-incident-psirt-disclosure-controller`
- **Path:** `agent-skills/runtime/elmos-incident-command-runbook-automation-generator/SKILL.md`

### `elmos-incident-postmortem-recertification-controller`

- **Purpose:** Convert production incidents into evidence-preserving timelines, root-cause claims, corrective actions, regression assets and mandatory certificate impact decisions.
- **Group/Priority/Risk:** `incident-certification` / `P0` / `critical`
- **Kernels:** K1, K4, K6, K8
- **Dependencies:** `elmos-ai-incident-kill-switch-controller`, `elmos-certificate-drift-revocation-controller`, `elmos-counterexample-regression-promoter`
- **Path:** `agent-skills/runtime/elmos-incident-postmortem-recertification-controller/SKILL.md`

### `elmos-independent-k8-certificate-signer`

- **Purpose:** Sign, publish or refuse completion certificates from sealed assurance cases under current certificate policy, authorized signer identity and exact evidence root.
- **Group/Priority/Risk:** `certification-authority` / `P0` / `critical`
- **Kernels:** K8
- **Dependencies:** `elmos-structured-assurance-case-compiler`, `elmos-waiver-expiry-governor`, `elmos-certification-policy-practice-authority`, `elmos-ai-e0-e5-certifier`
- **Path:** `agent-skills/runtime/elmos-independent-k8-certificate-signer/SKILL.md`

### `elmos-inference-cache-prefix-kv-consistency-controller`

- **Purpose:** Govern prompt/result/prefix/KV caches with exact key semantics, tenant isolation, model/version binding, invalidation and quality evidence.
- **Group/Priority/Risk:** `model-cache` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-cache-semantic-consistency-verifier`, `elmos-model-serving-runtime-profile-compiler`
- **Path:** `agent-skills/runtime/elmos-inference-cache-prefix-kv-consistency-controller/SKILL.md`

### `elmos-inference-engine-deployment-generator`

- **Purpose:** Generate KServe, Triton, Ray Serve, vLLM, SGLang, TGI and equivalent deployments with exact images, model artifacts, probes, scaling and rollback.
- **Group/Priority/Risk:** `model-serving-generation` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-model-serving-runtime-profile-compiler`, `elmos-ai-deployment-pack-generator`
- **Path:** `agent-skills/runtime/elmos-inference-engine-deployment-generator/SKILL.md`

### `elmos-knowledge-graph-ontology-ir-compiler`

- **Purpose:** Compile ontology, entities, relations, temporal validity, provenance, constraints and alignment into a framework-neutral Knowledge IR.
- **Group/Priority/Risk:** `knowledge-graph` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-graph-database-semantic-ir-compiler`, `elmos-ai-rag-semantic-compiler`
- **Path:** `agent-skills/runtime/elmos-knowledge-graph-ontology-ir-compiler/SKILL.md`

### `elmos-knowledge-source-trust-scoring-governor`

- **Purpose:** Govern source identity, ownership, editorial quality, freshness, corroboration, conflict and revocation signals without turning heuristic trust into proof.
- **Group/Priority/Risk:** `knowledge-trust` / `P1` / `high`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-agent-registry-resource-discovery-governor`, `elmos-ai-assurance-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-knowledge-source-trust-scoring-governor/SKILL.md`

### `elmos-kubernetes-ai-workload-operator-generator`

- **Purpose:** Generate controllers/CRDs for agent, retrieval and model-serving workloads with reconciliation, status, finalizers, upgrades and tenancy.
- **Group/Priority/Risk:** `platform-kubernetes-operator` / `P0` / `critical`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-deployment-pack-generator`, `elmos-model-serving-runtime-profile-compiler`
- **Path:** `agent-skills/runtime/elmos-kubernetes-ai-workload-operator-generator/SKILL.md`

### `elmos-lakehouse-table-format-ir-compiler`

- **Purpose:** Compile snapshots, manifests, partition evolution, row-level deletes, schema evolution, transaction logs and reader/writer feature compatibility across Iceberg, Delta and Hudi.
- **Group/Priority/Risk:** `data-lakehouse-ir` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-sql-catalog-ir-compiler`, `elmos-data-snapshot-cdc-controller`
- **Path:** `agent-skills/runtime/elmos-lakehouse-table-format-ir-compiler/SKILL.md`

### `elmos-language-runtime-performance-portability-profiler`

- **Purpose:** Characterize latency, throughput, startup, memory, GC, scheduling and native-image behavior so route selection reflects runtime economics rather than syntax alone.
- **Group/Priority/Risk:** `polyglot-performance` / `P1` / `high`
- **Kernels:** K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-polyglot-route-certifier`, `elmos-performance-statistical-gate`
- **Path:** `agent-skills/runtime/elmos-language-runtime-performance-portability-profiler/SKILL.md`

### `elmos-language-semantic-profile-compiler`

- **Purpose:** Compile exact-version language semantics for types, nullability, numeric behavior, Unicode, exceptions, concurrency, ownership, async, reflection, FFI and build/runtime boundaries.
- **Group/Priority/Risk:** `polyglot-semantic-profile` / `P0` / `critical`
- **Kernels:** K2, K3, K6
- **Dependencies:** `elmos-ai-sir-compiler`, `elmos-polyglot-route-matrix-governor`
- **Path:** `agent-skills/runtime/elmos-language-semantic-profile-compiler/SKILL.md`

### `elmos-localization-cultural-policy-adapter`

- **Purpose:** Adapt generated language, UI, examples, safety and workflow policy to locale while preserving core semantics and avoiding unsupported cultural assumptions.
- **Group/Priority/Risk:** `product-localization` / `P1` / `high`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-i18n-l10n-conformance-verifier`, `elmos-ai-compliance-profile-compiler`
- **Path:** `agent-skills/runtime/elmos-localization-cultural-policy-adapter/SKILL.md`

### `elmos-managed-agent-cloud-deployment-generator`

- **Purpose:** Generate portable deployments to AWS, Google, Microsoft and Databricks managed agent runtimes with identity, network, observability, evidence and exit plans.
- **Group/Priority/Risk:** `deployment` / `P1` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-deployment-pack-generator`, `elmos-agent-workload-delegated-identity-controller`, `elmos-genai-telemetry-profile-compiler`
- **Path:** `agent-skills/runtime/elmos-managed-agent-cloud-deployment-generator/SKILL.md`

### `elmos-mcp-2026-profile-compiler`

- **Purpose:** Compile exact-version MCP 2026-07-28 capability profiles for stateless core, extensions, Tasks, routing, caching, authorization and deprecation behavior.
- **Group/Priority/Risk:** `protocol` / `P0` / `critical`
- **Kernels:** K1, K3, K6, K7
- **Dependencies:** `elmos-ai-tool-protocol-compiler`, `elmos-ai-capability-negotiator`
- **Path:** `agent-skills/runtime/elmos-mcp-2026-profile-compiler/SKILL.md`

### `elmos-mcp-a2a-acp-bridge-conformance-verifier`

- **Purpose:** Verify bridges among tool, agent-to-agent and editor-agent protocols without authority, lifecycle, content or cancellation loss.
- **Group/Priority/Risk:** `protocol-bridge` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-mcp-a2a-gateway-generator`, `elmos-agent-client-protocol-acp-adapter-generator`
- **Path:** `agent-skills/runtime/elmos-mcp-a2a-acp-bridge-conformance-verifier/SKILL.md`

### `elmos-mcp-apps-a2ui-generator`

- **Purpose:** Generate secure interactive agent interfaces for MCP Apps, A2UI and AG-UI from a common Interaction IR with capability negotiation and recoverable UI state.
- **Group/Priority/Risk:** `interaction-ui` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-mcp-2026-profile-compiler`, `elmos-ai-interaction-channel-compiler`
- **Path:** `agent-skills/runtime/elmos-mcp-apps-a2ui-generator/SKILL.md`

### `elmos-mcp-enterprise-authorization-controller`

- **Purpose:** Generate and verify OAuth/OIDC, client registration, delegated consent, audience restriction, token exchange, revocation and enterprise-managed MCP authorization.
- **Group/Priority/Risk:** `identity-authorization` / `P0` / `critical`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-mcp-2026-profile-compiler`, `elmos-ai-security-governance-compiler`
- **Path:** `agent-skills/runtime/elmos-mcp-enterprise-authorization-controller/SKILL.md`

### `elmos-mcp-tasks-durable-bridge`

- **Purpose:** Bridge MCP Tasks to Elmos durable runs with monotonic state, checkpointing, pause/resume/cancel, lease fencing, mid-flight input and side-effect reconciliation.
- **Group/Priority/Risk:** `protocol-runtime` / `P0` / `critical`
- **Kernels:** K3, K6, K7, K8
- **Dependencies:** `elmos-mcp-2026-profile-compiler`, `elmos-ai-durable-runtime-integrator`
- **Path:** `agent-skills/runtime/elmos-mcp-tasks-durable-bridge/SKILL.md`

### `elmos-message-ordering-delivery-semantics-verifier`

- **Purpose:** Verify at-most-once, at-least-once, effectively-once, partition ordering, redelivery, dead-letter and backpressure behavior.
- **Group/Priority/Risk:** `event-assurance` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-event-stream-storage-ir-compiler`, `elmos-ai-graph-liveness-side-effect-verifier`
- **Path:** `agent-skills/runtime/elmos-message-ordering-delivery-semantics-verifier/SKILL.md`

### `elmos-mobile-desktop-cross-platform-test-controller`

- **Purpose:** Test generated iOS, Android, Flutter, macOS, Windows and web clients across device, OS, network, permission and lifecycle matrices.
- **Group/Priority/Risk:** `qa-client-platform` / `P1` / `high`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-ui-visual-regression-journey-certifier`, `elmos-i18n-l10n-conformance-verifier`
- **Path:** `agent-skills/runtime/elmos-mobile-desktop-cross-platform-test-controller/SKILL.md`

### `elmos-model-fallback-semantic-degradation-verifier`

- **Purpose:** Verify that provider/model fallback preserves required schemas, tool behavior, safety, language, memory and task quality or blocks explicitly.
- **Group/Priority/Risk:** `model-fallback-assurance` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-model-routing-fallback-generator`, `elmos-ai-provider-behavior-fingerprint-recertifier`
- **Path:** `agent-skills/runtime/elmos-model-fallback-semantic-degradation-verifier/SKILL.md`

### `elmos-model-license-usage-restriction-governor`

- **Purpose:** Parse and enforce model, dataset, weight, API and output usage restrictions across generation, deployment, redistribution and customer delivery.
- **Group/Priority/Risk:** `model-license` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-open-source-license-ip-compliance-certifier`, `elmos-ai-bom-provenance-generator`
- **Path:** `agent-skills/runtime/elmos-model-license-usage-restriction-governor/SKILL.md`

### `elmos-model-provider-credit-quota-availability-controller`

- **Purpose:** Track subscription/credit/quota, real-time usage, rate limits, regional availability and failover capacity across model providers.
- **Group/Priority/Risk:** `finops-provider-capacity` / `P0` / `critical`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-ai-model-provider-availability-resilience-controller`, `elmos-cost-allocation-chargeback-showback-controller`
- **Path:** `agent-skills/runtime/elmos-model-provider-credit-quota-availability-controller/SKILL.md`

### `elmos-model-provider-procurement-contract-evaluator`

- **Purpose:** Evaluate provider SLA, data use, retention, residency, indemnity, deprecation, quota, pricing and exit terms against technical requirements.
- **Group/Priority/Risk:** `governance-procurement` / `P1` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-provider-data-residency-controller`, `elmos-ai-cost-pricing-sla-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-model-provider-procurement-contract-evaluator/SKILL.md`

### `elmos-model-quantization-hardware-compatibility-certifier`

- **Purpose:** Certify precision conversion, kernel availability, numerical quality, latency, memory, portability and fallback across accelerator targets.
- **Group/Priority/Risk:** `model-optimization` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-model-serving-runtime-profile-compiler`, `elmos-ai-quality-model-evaluation-compiler`
- **Path:** `agent-skills/runtime/elmos-model-quantization-hardware-compatibility-certifier/SKILL.md`

### `elmos-model-response-schema-evolution-controller`

- **Purpose:** Manage backward/forward compatibility of model response and tool argument schemas across model, provider and framework upgrades.
- **Group/Priority/Risk:** `compatibility` / `P1` / `critical`
- **Kernels:** K3, K5, K6, K8
- **Dependencies:** `elmos-structured-output-contract-verifier`, `elmos-ai-compatibility-drift-monitor`
- **Path:** `agent-skills/runtime/elmos-model-response-schema-evolution-controller/SKILL.md`

### `elmos-model-routing-quality-cost-latency-optimizer`

- **Purpose:** Optimize model/provider routing under quality, safety, latency, residency, quota and cost constraints with shadow evidence and bounded fallback.
- **Group/Priority/Risk:** `model-routing-optimization` / `P1` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-model-routing-fallback-generator`, `elmos-ai-online-shadow-eval-controller`
- **Path:** `agent-skills/runtime/elmos-model-routing-quality-cost-latency-optimizer/SKILL.md`

### `elmos-model-serving-canary-shadow-rollback-controller`

- **Purpose:** Run no-side-effect shadow, bounded canary, traffic splitting, quality/SLO comparison and atomic rollback for model-server changes.
- **Group/Priority/Risk:** `model-release` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-online-shadow-eval-controller`, `elmos-inference-engine-deployment-generator`
- **Path:** `agent-skills/runtime/elmos-model-serving-canary-shadow-rollback-controller/SKILL.md`

### `elmos-model-serving-runtime-profile-compiler`

- **Purpose:** Compile exact model-server, accelerator, protocol, batching, cache, scheduler, autoscaling and observability capabilities for self-hosted and managed runtimes.
- **Group/Priority/Risk:** `model-serving-profile` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-model-contract-compiler`, `elmos-ai-target-adapter-sdk`
- **Path:** `agent-skills/runtime/elmos-model-serving-runtime-profile-compiler/SKILL.md`

### `elmos-model-weight-artifact-provenance-certifier`

- **Purpose:** Certify model weights, tokenizer, adapters, quantization, conversion and serving artifacts from source through registry, build, signature and deployment.
- **Group/Priority/Risk:** `model-artifact-provenance` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-bom-provenance-generator`, `elmos-model-license-usage-restriction-governor`
- **Path:** `agent-skills/runtime/elmos-model-weight-artifact-provenance-certifier/SKILL.md`

### `elmos-modular-monolith-microservice-boundary-analyzer`

- **Purpose:** Evaluate coupling, change cadence, data ownership, latency, transaction and team boundaries before extracting or merging services.
- **Group/Priority/Risk:** `architecture-boundaries` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6
- **Dependencies:** `elmos-domain-driven-architecture-synthesizer`, `elmos-ai-source-project-importer`
- **Path:** `agent-skills/runtime/elmos-modular-monolith-microservice-boundary-analyzer/SKILL.md`

### `elmos-monorepo-build-graph-sharding-optimizer`

- **Purpose:** Partition million-file polyglot repositories into dependency-safe analysis, generation, build and verification shards with cache-aware critical-path scheduling.
- **Group/Priority/Risk:** `polyglot-scale` / `P1` / `high`
- **Kernels:** K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-polyglot-build-toolchain-orchestrator`, `elmos-capacity-autoscaling-backpressure-planner`
- **Path:** `agent-skills/runtime/elmos-monorepo-build-graph-sharding-optimizer/SKILL.md`

### `elmos-multi-agent-budget-scheduler`

- **Purpose:** Allocate model, tool, latency, fanout and cost budgets across agent teams using priority, uncertainty, critical path and verified task-fit.
- **Group/Priority/Risk:** `multi-agent` / `P1` / `high`
- **Kernels:** K4, K6, K7
- **Dependencies:** `elmos-multi-agent-topology-delegation-compiler`, `elmos-ai-runaway-loop-economic-dos-guard`
- **Path:** `agent-skills/runtime/elmos-multi-agent-budget-scheduler/SKILL.md`

### `elmos-multi-agent-deadlock-consensus-verifier`

- **Purpose:** Verify multi-agent workflows for deadlock, livelock, split-brain, contradictory decisions, duplicate work and bounded consensus behavior.
- **Group/Priority/Risk:** `multi-agent` / `P1` / `critical`
- **Kernels:** K3, K6, K8
- **Dependencies:** `elmos-multi-agent-topology-delegation-compiler`, `elmos-ai-graph-liveness-side-effect-verifier`
- **Path:** `agent-skills/runtime/elmos-multi-agent-deadlock-consensus-verifier/SKILL.md`

### `elmos-multi-agent-topology-delegation-compiler`

- **Purpose:** Compile supervisor, peer, hierarchy, market and graph topologies with explicit responsibilities, delegation authority, state ownership and termination contracts.
- **Group/Priority/Risk:** `multi-agent` / `P1` / `critical`
- **Kernels:** K1, K3, K4, K7
- **Dependencies:** `elmos-ai-agent-contract-compiler`, `elmos-ai-workflow-state-machine-compiler`, `elmos-agent-workload-delegated-identity-controller`
- **Path:** `agent-skills/runtime/elmos-multi-agent-topology-delegation-compiler/SKILL.md`

### `elmos-multi-region-active-active-failover-certifier`

- **Purpose:** Certify routing, data replication, session/memory ownership, consistency, failover, failback and regional isolation for AI services.
- **Group/Priority/Risk:** `platform-multiregion` / `P0` / `critical`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-disaster-recovery-business-continuity-certifier`, `elmos-ai-provider-data-residency-controller`
- **Path:** `agent-skills/runtime/elmos-multi-region-active-active-failover-certifier/SKILL.md`

### `elmos-multi-tenant-saas-foundation-generator`

- **Purpose:** Generate tenant identity, isolation, provisioning, quotas, data boundaries, audit, lifecycle and operational controls for commercial AI services.
- **Group/Priority/Risk:** `architecture-saas` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6
- **Dependencies:** `elmos-ai-multitenant-control-plane-generator`, `elmos-ai-security-governance-compiler`
- **Path:** `agent-skills/runtime/elmos-multi-tenant-saas-foundation-generator/SKILL.md`

### `elmos-multimodal-document-intelligence-generator`

- **Purpose:** Generate document ingestion systems for text, layout, tables, figures, scans, audio and video with typed provenance and quality-aware retrieval artifacts.
- **Group/Priority/Risk:** `rag-data-plane` / `P1` / `high`
- **Kernels:** K2, K3, K5, K6
- **Dependencies:** `elmos-rag-corpus-connector-cdc-governor`, `elmos-ai-rag-semantic-compiler`
- **Path:** `agent-skills/runtime/elmos-multimodal-document-intelligence-generator/SKILL.md`

### `elmos-native-conformance-lab-controller`

- **Purpose:** Operate independent exact-version labs for frameworks, protocols, languages, databases and cloud runtimes with repeatable fixtures and authoritative native commands.
- **Group/Priority/Risk:** `certification-lab` / `P0` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-clean-room-reproducible-builder`, `elmos-ai-generated-project-conformance-validator`
- **Path:** `agent-skills/runtime/elmos-native-conformance-lab-controller/SKILL.md`

### `elmos-network-egress-data-exfiltration-certifier`

- **Purpose:** Certify destination, protocol, payload, DNS, proxy and data-loss controls for every model, tool, connector and generated deployment.
- **Group/Priority/Risk:** `security-egress` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-provider-data-residency-controller`, `elmos-ai-prompt-tool-security-redteam`
- **Path:** `agent-skills/runtime/elmos-network-egress-data-exfiltration-certifier/SKILL.md`

### `elmos-nondeterministic-statistical-reliability-verifier`

- **Purpose:** Estimate success, failure, flake and quality distributions for agents and distributed systems using repeated trials, confidence bounds and sequential tests.
- **Group/Priority/Risk:** `qa-statistical` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-ai-judge-calibration-stochastic-assurance`, `elmos-performance-statistical-gate`
- **Path:** `agent-skills/runtime/elmos-nondeterministic-statistical-reliability-verifier/SKILL.md`

### `elmos-nosql-document-keyvalue-ir-compiler`

- **Purpose:** Compile document, key-value, wide-column and aggregate-store schemas, access paths, consistency, TTL, indexing and update semantics into a store-neutral persistence IR.
- **Group/Priority/Risk:** `data-nosql-ir` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-orm-persistence-ir-compiler`, `elmos-ai-data-contract-quality-governor`
- **Path:** `agent-skills/runtime/elmos-nosql-document-keyvalue-ir-compiler/SKILL.md`

### `elmos-observability-cardinality-privacy-governor`

- **Purpose:** Govern trace/metric/log schemas, sampling, cardinality, redaction, retention and tenant access for AI and polyglot systems.
- **Group/Priority/Risk:** `platform-observability` / `P0` / `critical`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-genai-telemetry-profile-compiler`, `elmos-privacy-impact-consent-purpose-verifier`
- **Path:** `agent-skills/runtime/elmos-observability-cardinality-privacy-governor/SKILL.md`

### `elmos-on-device-edge-ai-project-generator`

- **Purpose:** Generate Core ML, TensorFlow Lite, ONNX Runtime, llama.cpp and edge deployments with resource, privacy, update and offline behavior contracts.
- **Group/Priority/Risk:** `model-edge` / `P1` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-model-quantization-hardware-compatibility-certifier`, `elmos-ai-target-portfolio-planner`
- **Path:** `agent-skills/runtime/elmos-on-device-edge-ai-project-generator/SKILL.md`

### `elmos-online-schema-change-backfill-controller`

- **Purpose:** Execute expand/contract, online DDL, dual-read/write, throttled backfill, validation and cleanup without violating availability or data invariants.
- **Group/Priority/Risk:** `data-online-migration` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-database-schema-migration-planner`, `elmos-data-snapshot-cdc-controller`
- **Path:** `agent-skills/runtime/elmos-online-schema-change-backfill-controller/SKILL.md`

### `elmos-open-source-license-ip-compliance-certifier`

- **Purpose:** Certify software, model, dataset, prompt, generated asset and documentation licensing, attribution, redistribution and policy compatibility.
- **Group/Priority/Risk:** `supply-chain-compliance` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K8
- **Dependencies:** `elmos-ai-bom-provenance-generator`, `elmos-ai-data-contract-quality-governor`
- **Path:** `agent-skills/runtime/elmos-open-source-license-ip-compliance-certifier/SKILL.md`

### `elmos-openai-plugin-project-generator`

- **Purpose:** Generate a complete OpenAI Plugin project containing Skills, remote MCP server, optional MCP Apps UI, authentication, evaluations, packaging and submission evidence.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-agent-skill-portability-emitter`, `elmos-ai-mcp-a2a-gateway-generator`, `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-openai-plugin-project-generator/SKILL.md`

### `elmos-openapi-arazzo-workflow-compiler`

- **Purpose:** Compile API operations, links, callbacks, security, examples and multi-step workflows into exact OpenAPI and Arazzo contracts with executable client/server conformance.
- **Group/Priority/Risk:** `protocol-openapi-arazzo` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-api-event-contract-ir-compiler`, `elmos-generated-api-event-schema-evolution-controller`
- **Path:** `agent-skills/runtime/elmos-openapi-arazzo-workflow-compiler/SKILL.md`

### `elmos-openapi-graphql-grpc-protocol-gateway-generator`

- **Purpose:** Generate governed gateways and adapters among REST/OpenAPI, GraphQL and gRPC while preserving auth, streaming, errors, deadlines and compatibility.
- **Group/Priority/Risk:** `event-protocol-gateway` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-api-event-contract-ir-compiler`, `elmos-ai-target-adapter-sdk`
- **Path:** `agent-skills/runtime/elmos-openapi-graphql-grpc-protocol-gateway-generator/SKILL.md`

### `elmos-openfeature-progressive-delivery-safety-controller`

- **Purpose:** Generate and govern feature-flag evaluation, targeting, exposure, shadow, canary, rollback and kill-switch controls for generated AI systems.
- **Group/Priority/Risk:** `platform-openfeature-delivery` / `P0` / `critical`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-model-serving-canary-shadow-rollback-controller`, `elmos-gitops-argocd-flux-release-controller`
- **Path:** `agent-skills/runtime/elmos-openfeature-progressive-delivery-safety-controller/SKILL.md`

### `elmos-operability-support-readiness-certifier`

- **Purpose:** Certify ownership, on-call, alerts, runbooks, dashboards, diagnostic safety, support access, maintenance and incident communications before commercial launch.
- **Group/Priority/Risk:** `operations-readiness` / `P0` / `critical`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-slo-error-budget-release-governor`, `elmos-disaster-recovery-business-continuity-certifier`, `elmos-ai-operator-console-generator`
- **Path:** `agent-skills/runtime/elmos-operability-support-readiness-certifier/SKILL.md`

### `elmos-orm-persistence-ir-compiler`

- **Purpose:** Compile ORM mappings, identity generation, cascades, lazy/eager loading, optimistic locking, transactions, native queries and migrations across Java, Python, TypeScript, .NET, Go and Rust.
- **Group/Priority/Risk:** `database-ir` / `P0` / `critical`
- **Kernels:** K2, K3, K6
- **Dependencies:** `elmos-language-semantic-profile-compiler`, `elmos-sql-catalog-ir-compiler`
- **Path:** `agent-skills/runtime/elmos-orm-persistence-ir-compiler/SKILL.md`

### `elmos-performance-statistical-gate`

- **Purpose:** Evaluate latency, throughput, resource, quality and cost regressions with representative workloads, confidence intervals, power analysis and sequential decisions.
- **Group/Priority/Risk:** `qa-performance` / `P0` / `critical`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-ai-observability-finops-generator`, `elmos-test-matrix-covering-array-planner`
- **Path:** `agent-skills/runtime/elmos-performance-statistical-gate/SKILL.md`

### `elmos-platform-engineering-golden-path-generator`

- **Purpose:** Generate self-service application and AI workload golden paths with templates, policies, scorecards, paved-road services and escape hatches.
- **Group/Priority/Risk:** `platform-golden-path` / `P0` / `critical`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-project-factory-orchestrator`, `elmos-operability-support-readiness-certifier`
- **Path:** `agent-skills/runtime/elmos-platform-engineering-golden-path-generator/SKILL.md`

### `elmos-policy-decision-explainability-audit-verifier`

- **Purpose:** Verify that authorization, safety, routing and certification decisions expose policy version, inputs, rationale and counterfactuals without leaking sensitive rules.
- **Group/Priority/Risk:** `security-policy-audit` / `P1` / `high`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-policy-as-code-compiler`, `elmos-explainability-decision-recourse-generator`
- **Path:** `agent-skills/runtime/elmos-policy-decision-explainability-audit-verifier/SKILL.md`

### `elmos-polyglot-build-toolchain-orchestrator`

- **Purpose:** Provision and execute hermetic Maven, Gradle, pip/uv, npm/pnpm, dotnet, Go and Cargo toolchains with exact locks, caches, sandboxes and reproducible logs.
- **Group/Priority/Risk:** `polyglot-toolchain` / `P0` / `critical`
- **Kernels:** K2, K6, K7
- **Dependencies:** `elmos-compiler-frontend-conformance-certifier`, `elmos-ai-durable-runtime-integrator`
- **Path:** `agent-skills/runtime/elmos-polyglot-build-toolchain-orchestrator/SKILL.md`

### `elmos-polyglot-differential-runtime`

- **Purpose:** Execute source and target systems under the same scenarios and compare normalized API, state, trace, tool, data, timing and side-effect semantics.
- **Group/Priority/Risk:** `polyglot-assurance` / `P0` / `critical`
- **Kernels:** K3, K6, K7
- **Dependencies:** `elmos-semantic-gap-obligation-generator`, `elmos-ai-cross-framework-differential-validator`, `elmos-polyglot-build-toolchain-orchestrator`
- **Path:** `agent-skills/runtime/elmos-polyglot-differential-runtime/SKILL.md`

### `elmos-polyglot-route-certifier`

- **Purpose:** Issue bounded route certificates only after exact frontend, backend, framework bridge, native build, differential, security, recovery, upgrade and rollback evidence closes required obligations.
- **Group/Priority/Risk:** `polyglot-certification` / `P0` / `critical`
- **Kernels:** K6, K8
- **Dependencies:** `elmos-polyglot-differential-runtime`, `elmos-polyglot-upgrade-controller`, `elmos-ai-e0-e5-certifier`
- **Path:** `agent-skills/runtime/elmos-polyglot-route-certifier/SKILL.md`

### `elmos-polyglot-route-matrix-governor`

- **Purpose:** Govern exact source-language, target-language, framework, runtime and toolchain route envelopes without treating an N×N matrix as independently trustworthy translators.
- **Group/Priority/Risk:** `polyglot-route` / `P0` / `critical`
- **Kernels:** K1, K3, K6, K8
- **Dependencies:** `elmos-ai-target-portfolio-planner`, `elmos-ai-compatibility-drift-monitor`
- **Path:** `agent-skills/runtime/elmos-polyglot-route-matrix-governor/SKILL.md`

### `elmos-polyglot-upgrade-controller`

- **Purpose:** Upgrade certified language/framework routes across compiler, runtime and dependency versions with impact analysis, incremental proof invalidation and reversible rollout.
- **Group/Priority/Risk:** `polyglot-lifecycle` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-polyglot-differential-runtime`, `elmos-ai-compatibility-drift-monitor`
- **Path:** `agent-skills/runtime/elmos-polyglot-upgrade-controller/SKILL.md`

### `elmos-privacy-impact-consent-purpose-verifier`

- **Purpose:** Compile and verify data purpose, legal/organizational basis, consent, minimization, retention, disclosure, provider use and data-subject control across AI workflows.
- **Group/Priority/Risk:** `commercial-assurance` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K8
- **Dependencies:** `elmos-ai-provider-data-residency-controller`, `elmos-ai-retention-erasure-verifier`, `elmos-human-oversight-consent-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-privacy-impact-consent-purpose-verifier/SKILL.md`

### `elmos-probabilistic-reliability-statistical-model-checker`

- **Purpose:** Verify probabilistic availability, retry, queue, provider and agent success claims with stochastic models and simulation evidence.
- **Group/Priority/Risk:** `formal-probabilistic` / `P1` / `high`
- **Kernels:** K3, K4, K6, K8
- **Dependencies:** `elmos-nondeterministic-statistical-reliability-verifier`, `elmos-capacity-soak-efficiency-certifier`
- **Path:** `agent-skills/runtime/elmos-probabilistic-reliability-statistical-model-checker/SKILL.md`

### `elmos-product-analytics-telemetry-experiment-governor`

- **Purpose:** Generate privacy-safe product analytics, feature flags and experiments with metric definitions, guardrails, exposure logging and decision evidence.
- **Group/Priority/Risk:** `product-analytics` / `P1` / `high`
- **Kernels:** K1, K2, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-quality-model-evaluation-compiler`, `elmos-privacy-impact-consent-purpose-verifier`
- **Path:** `agent-skills/runtime/elmos-product-analytics-telemetry-experiment-governor/SKILL.md`

### `elmos-production-change-control-recertification-gate`

- **Purpose:** Map code, model, prompt, data, policy, infrastructure and vendor changes to risk, approvals, evidence invalidation and incremental/full recertification.
- **Group/Priority/Risk:** `certification-change-control` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-certificate-drift-revocation-controller`, `elmos-proof-to-validation-dag-compiler`
- **Path:** `agent-skills/runtime/elmos-production-change-control-recertification-gate/SKILL.md`

### `elmos-production-deployment-certifier`

- **Purpose:** Certify exact images, manifests, policies, secrets, data migrations, probes, scaling, telemetry and rollback in a production-equivalent or approved production environment.
- **Group/Priority/Risk:** `certification-deployment` / `P0` / `critical`
- **Kernels:** K6, K7, K8
- **Dependencies:** `elmos-native-conformance-lab-controller`, `elmos-ai-deployment-pack-generator`
- **Path:** `agent-skills/runtime/elmos-production-deployment-certifier/SKILL.md`

### `elmos-productivity-value-stream-scorecard`

- **Purpose:** Measure Elmos commercial productivity through delivery throughput, instability, rework, verified automation yield, machine wall-clock, cost and developer experience rather than token volume.
- **Group/Priority/Risk:** `productivity-assurance` / `P1` / `high`
- **Kernels:** K1, K2, K6, K8
- **Dependencies:** `elmos-ai-observability-finops-generator`, `elmos-benchmark-integrity-large-repository-certifier`
- **Path:** `agent-skills/runtime/elmos-productivity-value-stream-scorecard/SKILL.md`

### `elmos-project-estimation-machine-eta-calibrator`

- **Purpose:** Estimate and continuously calibrate machine wall-clock, queue, retry, token, compute and verification duration for repository-scale generation and certification.
- **Group/Priority/Risk:** `finops-estimation` / `P1` / `high`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-ai-cost-pricing-sla-contract-compiler`, `elmos-productivity-value-stream-scorecard`
- **Path:** `agent-skills/runtime/elmos-project-estimation-machine-eta-calibrator/SKILL.md`

### `elmos-prompt-program-ir-compiler`

- **Purpose:** Compile prompts into typed, versioned programs with parameters, roles, examples, tool visibility, output schemas, safety policies, lineage and tests.
- **Group/Priority/Risk:** `prompt-engineering` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6
- **Dependencies:** `elmos-ai-model-contract-compiler`, `elmos-ai-tool-protocol-compiler`
- **Path:** `agent-skills/runtime/elmos-prompt-program-ir-compiler/SKILL.md`

### `elmos-prompt-registry-experiment-controller`

- **Purpose:** Operate prompt registries, controlled experiments, review gates, canaries, rollback and evidence-based promotion without bypassing canonical Prompt Program IR.
- **Group/Priority/Risk:** `prompt-engineering` / `P1` / `high`
- **Kernels:** K4, K6, K7, K8
- **Dependencies:** `elmos-prompt-program-ir-compiler`, `elmos-ai-online-shadow-eval-controller`
- **Path:** `agent-skills/runtime/elmos-prompt-registry-experiment-controller/SKILL.md`

### `elmos-prompt-skill-adapter-canary-promotion-governor`

- **Purpose:** Stage behavioral configuration changes through offline, shadow, canary and broad rollout with exact version, metrics and rollback.
- **Group/Priority/Risk:** `learning-canary` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-online-shadow-eval-controller`, `elmos-counterexample-to-rule-skill-promotion-controller`
- **Path:** `agent-skills/runtime/elmos-prompt-skill-adapter-canary-promotion-governor/SKILL.md`

### `elmos-proof-assistant-lean-dafny-bridge`

- **Purpose:** Generate reviewable theorem/contract skeletons, connect verified lemmas to code artifacts and preserve trusted-kernel and assumption evidence.
- **Group/Priority/Risk:** `formal-proof-assistant` / `P1` / `critical`
- **Kernels:** K3, K4, K6, K8
- **Dependencies:** `elmos-formal-method-selection-router`, `elmos-structured-assurance-case-compiler`
- **Path:** `agent-skills/runtime/elmos-proof-assistant-lean-dafny-bridge/SKILL.md`

### `elmos-proof-to-validation-dag-compiler`

- **Purpose:** Compile Proof Obligation Graphs into dependency-aware validation DAGs with verifier independence, fixtures, resource budgets, retries and evidence gates.
- **Group/Priority/Risk:** `qa-orchestration` / `P0` / `critical`
- **Kernels:** K1, K4, K6, K7
- **Dependencies:** `elmos-ai-assurance-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-proof-to-validation-dag-compiler/SKILL.md`

### `elmos-property-metamorphic-mutation-fuzz-controller`

- **Purpose:** Discover deep semantic defects through generated properties, metamorphic relations, mutation testing and coverage-guided fuzzing with minimized counterexamples.
- **Group/Priority/Risk:** `qa-deep-verification` / `P0` / `critical`
- **Kernels:** K4, K6, K7
- **Dependencies:** `elmos-authoritative-oracle-registry`, `elmos-test-fixture-data-factory`
- **Path:** `agent-skills/runtime/elmos-property-metamorphic-mutation-fuzz-controller/SKILL.md`

### `elmos-protocol-conformance-fuzzing-controller`

- **Purpose:** Generate grammar, stateful and adversarial fuzz campaigns for MCP, A2A, ACP, HTTP, gRPC, WebSocket and event protocols.
- **Group/Priority/Risk:** `qa-protocol-fuzz` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-ai-mcp-a2a-gateway-generator`, `elmos-property-metamorphic-mutation-fuzz-controller`
- **Path:** `agent-skills/runtime/elmos-protocol-conformance-fuzzing-controller/SKILL.md`

### `elmos-protocol-state-machine-model-checker`

- **Purpose:** Compile workflow, MCP/A2A/ACP and service protocols into executable state models and verify reachability, safety, liveness, cancellation and recovery.
- **Group/Priority/Risk:** `formal-protocol` / `P0` / `critical`
- **Kernels:** K3, K4, K6, K8
- **Dependencies:** `elmos-ai-workflow-state-machine-compiler`, `elmos-ai-graph-liveness-side-effect-verifier`
- **Path:** `agent-skills/runtime/elmos-protocol-state-machine-model-checker/SKILL.md`

### `elmos-query-plan-regression-autotuning-governor`

- **Purpose:** Detect plan regressions and propose bounded statistics, index, partition or query changes under proof, rollback and workload constraints.
- **Group/Priority/Risk:** `data-query-optimization` / `P1` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-database-performance-plan-certifier`, `elmos-ai-online-shadow-eval-controller`
- **Path:** `agent-skills/runtime/elmos-query-plan-regression-autotuning-governor/SKILL.md`

### `elmos-rag-acl-freshness-deletion-verifier`

- **Purpose:** Prove that retrieval observes point-in-time authorization, freshness limits, retention and verified deletion across all indexes, caches and memories.
- **Group/Priority/Risk:** `rag-data-plane` / `P1` / `critical`
- **Kernels:** K2, K6, K8
- **Dependencies:** `elmos-rag-corpus-connector-cdc-governor`, `elmos-rag-memory-poisoning-verifier`
- **Path:** `agent-skills/runtime/elmos-rag-acl-freshness-deletion-verifier/SKILL.md`

### `elmos-rag-citation-provenance-chain-verifier`

- **Purpose:** Verify every answer claim through chunk, document version, source system, ACL, transformation and retrieval lineage with tamper evidence.
- **Group/Priority/Risk:** `knowledge-citation` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-rag-retrieval-grounding-certifier`, `elmos-data-lineage-impact-governor`
- **Path:** `agent-skills/runtime/elmos-rag-citation-provenance-chain-verifier/SKILL.md`

### `elmos-rag-corpus-connector-cdc-governor`

- **Purpose:** Generate reliable corpus connectors with snapshots, change data capture, resumable sync, deduplication, ordering, tombstones and reindex governance.
- **Group/Priority/Risk:** `rag-data-plane` / `P1` / `critical`
- **Kernels:** K2, K5, K6, K7
- **Dependencies:** `elmos-ai-rag-semantic-compiler`, `elmos-ai-durable-runtime-integrator`
- **Path:** `agent-skills/runtime/elmos-rag-corpus-connector-cdc-governor/SKILL.md`

### `elmos-rag-memory-poisoning-verifier`

- **Purpose:** Detect and contain malicious documents, cross-tenant contamination, memory poisoning, citation laundering, stale facts and deletion failures.
- **Group/Priority/Risk:** `security-rag-memory` / `P0` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-ai-rag-semantic-compiler`, `elmos-ai-prompt-tool-security-redteam`
- **Path:** `agent-skills/runtime/elmos-rag-memory-poisoning-verifier/SKILL.md`

### `elmos-rag-query-planner-optimizer`

- **Purpose:** Compile evidence-aware retrieval plans across rewrite, decomposition, hybrid search, filters, rerank, graph traversal, context packing and abstention budgets.
- **Group/Priority/Risk:** `rag-retrieval` / `P1` / `high`
- **Kernels:** K3, K4, K6, K7
- **Dependencies:** `elmos-ai-rag-semantic-compiler`, `elmos-ai-rag-retrieval-grounding-certifier`
- **Path:** `agent-skills/runtime/elmos-rag-query-planner-optimizer/SKILL.md`

### `elmos-realtime-voice-multimodal-agent-generator`

- **Purpose:** Generate low-latency audio/video/text agents with session, turn-taking, interruption, tool use, consent, safety and fallback contracts.
- **Group/Priority/Risk:** `model-realtime` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-interaction-channel-compiler`, `elmos-ai-durable-runtime-integrator`
- **Path:** `agent-skills/runtime/elmos-realtime-voice-multimodal-agent-generator/SKILL.md`

### `elmos-regulatory-obligation-effective-date-monitor`

- **Purpose:** Track versioned jurisdictional obligations, effective dates, guidance and product scope; trigger human legal review and technical control changes.
- **Group/Priority/Risk:** `governance-regulatory-monitor` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-compliance-profile-compiler`, `elmos-certificate-drift-revocation-controller`
- **Path:** `agent-skills/runtime/elmos-regulatory-obligation-effective-date-monitor/SKILL.md`

### `elmos-release-test-budget-risk-optimizer`

- **Purpose:** Select PR, nightly, release and certification suites under wall-clock and cost budgets while preserving mandatory critical obligations.
- **Group/Priority/Risk:** `qa-selection` / `P1` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-test-matrix-covering-array-planner`, `elmos-productivity-value-stream-scorecard`
- **Path:** `agent-skills/runtime/elmos-release-test-budget-risk-optimizer/SKILL.md`

### `elmos-retrieval-index-build-compaction-governor`

- **Purpose:** Govern full/incremental index builds, segment merge, compaction, replicas, consistency, resource budgets and rollback across retrieval stores.
- **Group/Priority/Risk:** `knowledge-index-lifecycle` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-rag-corpus-connector-cdc-governor`, `elmos-vector-database-index-ir-compiler`
- **Path:** `agent-skills/runtime/elmos-retrieval-index-build-compaction-governor/SKILL.md`

### `elmos-risk-acceptance-residual-risk-governor`

- **Purpose:** Govern explicit risk ownership, rationale, compensating controls, customer disclosure, expiry and certificate impact without converting acceptance into proof.
- **Group/Priority/Risk:** `certification-risk` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-waiver-expiry-governor`, `elmos-structured-assurance-case-compiler`
- **Path:** `agent-skills/runtime/elmos-risk-acceptance-residual-risk-governor/SKILL.md`

### `elmos-runtime-admission-attestation-controller`

- **Purpose:** Admit only signed, policy-conformant, vulnerability-acceptable and attested artifacts/configurations into execution environments.
- **Group/Priority/Risk:** `runtime-admission` / `P0` / `critical`
- **Kernels:** K6, K7, K8
- **Dependencies:** `elmos-hermetic-build-environment-attestation-controller`, `elmos-software-update-trust-root-governor`, `elmos-ai-tool-authority-policy-generator`
- **Path:** `agent-skills/runtime/elmos-runtime-admission-attestation-controller/SKILL.md`

### `elmos-runtime-policy-continuous-compliance-monitor`

- **Purpose:** Evaluate deployed configuration, identity, network, data, model and evidence state continuously against versioned policies and certification scope.
- **Group/Priority/Risk:** `governance-continuous-compliance` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-policy-as-code-compiler`, `elmos-production-change-control-recertification-gate`
- **Path:** `agent-skills/runtime/elmos-runtime-policy-continuous-compliance-monitor/SKILL.md`

### `elmos-runtime-sandbox-ebpf-behavior-verifier`

- **Purpose:** Enforce and observe filesystem, process, network, syscall, device and resource behavior of untrusted generators, adapters and tools.
- **Group/Priority/Risk:** `security-runtime` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-prompt-tool-security-redteam`, `elmos-runtime-admission-attestation-controller`
- **Path:** `agent-skills/runtime/elmos-runtime-sandbox-ebpf-behavior-verifier/SKILL.md`

### `elmos-saga-workflow-compensation-compiler`

- **Purpose:** Compile long-running distributed business transactions into durable saga state machines with explicit compensation, irreversible steps and human gates.
- **Group/Priority/Risk:** `event-saga` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-ai-workflow-state-machine-compiler`, `elmos-ai-durable-runtime-integrator`
- **Path:** `agent-skills/runtime/elmos-saga-workflow-compensation-compiler/SKILL.md`

### `elmos-schema-registry-compatibility-controller`

- **Purpose:** Govern Avro, Protobuf, JSON Schema and event schema registration, subject naming, compatibility modes, migration and rollback.
- **Group/Priority/Risk:** `event-schema-registry` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-generated-api-event-schema-evolution-controller`, `elmos-cross-language-serialization-wire-compatibility-verifier`
- **Path:** `agent-skills/runtime/elmos-schema-registry-compatibility-controller/SKILL.md`

### `elmos-scitt-evidence-transparency-receipt-publisher`

- **Purpose:** Publish signed evidence statements and verification receipts to an append-only transparency service while preserving tenant privacy, revocation and certificate lineage.
- **Group/Priority/Risk:** `assurance-scitt-transparency` / `P1` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-evidence-worm-merkle-sealer`, `elmos-ai-artifact-provenance-packager`
- **Path:** `agent-skills/runtime/elmos-scitt-evidence-transparency-receipt-publisher/SKILL.md`

### `elmos-search-engine-query-index-ir-compiler`

- **Purpose:** Compile analyzer, tokenizer, mapping, relevance, aggregation, vector-hybrid, alias and shard semantics across Elasticsearch/OpenSearch-class systems.
- **Group/Priority/Risk:** `data-search-ir` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-rag-semantic-compiler`, `elmos-sql-query-ir-compiler`
- **Path:** `agent-skills/runtime/elmos-search-engine-query-index-ir-compiler/SKILL.md`

### `elmos-secretless-broker-breakglass-controller`

- **Purpose:** Issue short-lived scoped credentials, eliminate static secrets, and govern audited emergency access with dual control and automatic expiry.
- **Group/Priority/Risk:** `security-secrets` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-secret-credential-lifecycle-controller`, `elmos-human-oversight-consent-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-secretless-broker-breakglass-controller/SKILL.md`

### `elmos-security-control-coverage-defeater-analyzer`

- **Purpose:** Map threats to preventive, detective, responsive and recovery controls, identify defeaters and prevent checkbox coverage claims.
- **Group/Priority/Risk:** `security-assurance` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-structured-assurance-case-compiler`, `elmos-ai-system-impact-assessment-compiler`
- **Path:** `agent-skills/runtime/elmos-security-control-coverage-defeater-analyzer/SKILL.md`

### `elmos-security-incident-psirt-disclosure-controller`

- **Purpose:** Coordinate vulnerability intake, triage, embargo, remediation, customer notification, advisory publication, CVE/VEX updates and post-incident evidence.
- **Group/Priority/Risk:** `commercial-assurance` / `P0` / `critical`
- **Kernels:** K1, K2, K7, K8
- **Dependencies:** `elmos-ai-incident-kill-switch-controller`, `elmos-vulnerability-vex-kev-response-governor`, `elmos-ai-system-model-card-generator`
- **Path:** `agent-skills/runtime/elmos-security-incident-psirt-disclosure-controller/SKILL.md`

### `elmos-self-improvement-change-isolation-certifier`

- **Purpose:** Certify that learned prompts, rules, Skills and adapters are isolated, reviewable, reversible and cannot alter their own verifier or completion authority.
- **Group/Priority/Risk:** `learning-safety` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-counterexample-to-rule-skill-promotion-controller`, `elmos-certifier-independence-competence-governor`
- **Path:** `agent-skills/runtime/elmos-self-improvement-change-isolation-certifier/SKILL.md`

### `elmos-semantic-gap-obligation-generator`

- **Purpose:** Convert language, framework and runtime mismatches into explicit preservation, emulation, monitoring or rejection obligations instead of silent best-effort conversion.
- **Group/Priority/Risk:** `polyglot-assurance` / `P0` / `critical`
- **Kernels:** K1, K3, K6
- **Dependencies:** `elmos-language-semantic-profile-compiler`, `elmos-framework-runtime-bridge-compiler`, `elmos-ai-assurance-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-semantic-gap-obligation-generator/SKILL.md`

### `elmos-sensitive-data-masking-tokenization-certifier`

- **Purpose:** Generate and verify deterministic/non-deterministic masking, tokenization, format preservation, referential integrity and re-identification controls across environments.
- **Group/Priority/Risk:** `data-privacy` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-privacy-impact-consent-purpose-verifier`, `elmos-test-fixture-data-factory`
- **Path:** `agent-skills/runtime/elmos-sensitive-data-masking-tokenization-certifier/SKILL.md`

### `elmos-service-virtualization-contract-simulator`

- **Purpose:** Generate deterministic simulators for unavailable services, brokers, tools and failure modes without letting mocks masquerade as native certification.
- **Group/Priority/Risk:** `event-service-virtualization` / `P1` / `high`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-ai-synthetic-test-simulation-generator`, `elmos-contract-integration-e2e-controller`
- **Path:** `agent-skills/runtime/elmos-service-virtualization-contract-simulator/SKILL.md`

### `elmos-slo-error-budget-release-governor`

- **Purpose:** Govern release and promotion decisions using service-level objectives, error budgets, quality/cost objectives, burn rates and customer commitments.
- **Group/Priority/Risk:** `operations-reliability` / `P0` / `critical`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-ai-observability-finops-generator`, `elmos-production-deployment-certifier`
- **Path:** `agent-skills/runtime/elmos-slo-error-budget-release-governor/SKILL.md`

### `elmos-software-update-trust-root-governor`

- **Purpose:** Secure Skill, adapter, policy, model-profile and runtime updates using threshold roles, delegated trust, rollback/freeze protection and signed metadata.
- **Group/Priority/Risk:** `supply-chain-update` / `P0` / `critical`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-ai-bom-provenance-generator`, `elmos-ai-secret-credential-lifecycle-controller`
- **Path:** `agent-skills/runtime/elmos-software-update-trust-root-governor/SKILL.md`

### `elmos-source-target-debuggability-observability-verifier`

- **Purpose:** Verify that generated targets retain actionable logs, traces, metrics, stack attribution, correlation, replay and safe debugging comparable to the source system.
- **Group/Priority/Risk:** `polyglot-operability` / `P1` / `high`
- **Kernels:** K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-genai-telemetry-profile-compiler`, `elmos-code-generation-source-map-roundtrip-verifier`
- **Path:** `agent-skills/runtime/elmos-source-target-debuggability-observability-verifier/SKILL.md`

### `elmos-sql-catalog-ir-compiler`

- **Purpose:** Compile catalogs, schemas, tables, types, defaults, generated values, constraints, indexes, partitions, views, roles, grants and RLS into DB-SIR.
- **Group/Priority/Risk:** `database-ir` / `P0` / `critical`
- **Kernels:** K2, K3, K6
- **Dependencies:** `elmos-ai-sir-compiler`, `elmos-database-dialect-profile-registry`
- **Path:** `agent-skills/runtime/elmos-sql-catalog-ir-compiler/SKILL.md`

### `elmos-sql-dialect-lowering-engine`

- **Purpose:** Lower DB-SIR into target DDL, DML and routines through deterministic rules, vendor profiles and bounded synthesis with reversible lineage.
- **Group/Priority/Risk:** `database-transformation` / `P0` / `critical`
- **Kernels:** K3, K5, K6
- **Dependencies:** `elmos-sql-semantic-gap-analyzer`, `elmos-ai-target-adapter-sdk`
- **Path:** `agent-skills/runtime/elmos-sql-dialect-lowering-engine/SKILL.md`

### `elmos-sql-dual-execution-oracle`

- **Purpose:** Run source and target SQL against real engines with equivalent fixtures and compare results, errors, state, trigger effects and transaction outcomes.
- **Group/Priority/Risk:** `database-assurance` / `P0` / `critical`
- **Kernels:** K3, K6, K7
- **Dependencies:** `elmos-sql-dialect-lowering-engine`, `elmos-data-snapshot-cdc-controller`, `elmos-authoritative-oracle-registry`
- **Path:** `agent-skills/runtime/elmos-sql-dual-execution-oracle/SKILL.md`

### `elmos-sql-query-ir-compiler`

- **Purpose:** Compile DML and query semantics including joins, CTEs, windows, aggregates, merge/upsert, returning, JSON, temporal, geospatial and ordering into typed Query IR.
- **Group/Priority/Risk:** `database-ir` / `P0` / `critical`
- **Kernels:** K2, K3, K6
- **Dependencies:** `elmos-sql-catalog-ir-compiler`
- **Path:** `agent-skills/runtime/elmos-sql-query-ir-compiler/SKILL.md`

### `elmos-sql-routine-trigger-ir-compiler`

- **Purpose:** Compile stored procedures, functions, packages, triggers, cursors, handlers, exceptions, dynamic SQL, session state and transaction control into Routine IR.
- **Group/Priority/Risk:** `database-ir` / `P0` / `critical`
- **Kernels:** K2, K3, K6
- **Dependencies:** `elmos-sql-query-ir-compiler`
- **Path:** `agent-skills/runtime/elmos-sql-routine-trigger-ir-compiler/SKILL.md`

### `elmos-sql-semantic-gap-analyzer`

- **Purpose:** Identify dialect differences in NULL/empty string, numeric precision, time, Unicode, collation, coercion, locking, transaction DDL, sequence visibility and procedural behavior.
- **Group/Priority/Risk:** `database-assurance` / `P0` / `critical`
- **Kernels:** K1, K3, K6
- **Dependencies:** `elmos-sql-query-ir-compiler`, `elmos-sql-routine-trigger-ir-compiler`, `elmos-orm-persistence-ir-compiler`, `elmos-ai-assurance-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-sql-semantic-gap-analyzer/SKILL.md`

### `elmos-static-analysis-multilanguage-security-orchestrator`

- **Purpose:** Route compiler diagnostics, SAST, dependency, secret, IaC and custom semantic analyses across generated polyglot repositories with normalized evidence.
- **Group/Priority/Risk:** `qa-static-analysis` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-compiler-frontend-conformance-certifier`, `elmos-ai-prompt-tool-security-redteam`
- **Path:** `agent-skills/runtime/elmos-static-analysis-multilanguage-security-orchestrator/SKILL.md`

### `elmos-stored-routine-service-extraction-compiler`

- **Purpose:** Extract stored procedures, functions, packages and triggers into governed services while preserving transaction, error, lock, idempotency and side-effect semantics.
- **Group/Priority/Risk:** `data-routine-service-extraction` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-sql-routine-trigger-ir-compiler`, `elmos-sql-dialect-lowering-engine`
- **Path:** `agent-skills/runtime/elmos-stored-routine-service-extraction-compiler/SKILL.md`

### `elmos-structured-assurance-case-compiler`

- **Purpose:** Compile auditable claims, arguments, assumptions, contexts, defeaters and evidence into SACM/GSN-compatible assurance cases for engineering and independent review.
- **Group/Priority/Risk:** `certification-assurance-case` / `P0` / `critical`
- **Kernels:** K1, K3, K6, K8
- **Dependencies:** `elmos-certification-scope-compiler`, `elmos-evidence-worm-merkle-sealer`
- **Path:** `agent-skills/runtime/elmos-structured-assurance-case-compiler/SKILL.md`

### `elmos-structured-output-contract-verifier`

- **Purpose:** Verify model and framework structured outputs against exact schemas, semantic constraints, evolution rules, repair bounds and adversarial malformed cases.
- **Group/Priority/Risk:** `prompt-engineering` / `P0` / `critical`
- **Kernels:** K3, K6, K8
- **Dependencies:** `elmos-prompt-program-ir-compiler`, `elmos-ai-assurance-contract-compiler`
- **Path:** `agent-skills/runtime/elmos-structured-output-contract-verifier/SKILL.md`

### `elmos-supportability-diagnostics-bundle-generator`

- **Purpose:** Generate privacy-safe self-service diagnostic bundles with versions, health, topology, recent errors and evidence links for customer support.
- **Group/Priority/Risk:** `platform-support` / `P1` / `high`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-operability-support-readiness-certifier`, `elmos-enterprise-assurance-dossier-generator`
- **Path:** `agent-skills/runtime/elmos-supportability-diagnostics-bundle-generator/SKILL.md`

### `elmos-sustainable-ai-energy-carbon-efficiency-certifier`

- **Purpose:** Measure and certify energy, accelerator utilization, embodied/operational carbon assumptions and efficiency trade-offs without weakening required quality, safety or resilience.
- **Group/Priority/Risk:** `platform-sustainable-ai` / `P1` / `high`
- **Kernels:** K1, K6, K7, K8
- **Dependencies:** `elmos-carbon-energy-efficiency-profiler`, `elmos-model-serving-runtime-profile-compiler`
- **Path:** `agent-skills/runtime/elmos-sustainable-ai-energy-carbon-efficiency-certifier/SKILL.md`

### `elmos-target-coding-agent-harness-family-generator`

- **Purpose:** Generate OpenHands, OpenCode, Codex, Claude Code, Gemini CLI, Cline/Roo, Continue and Aider repository skills, plugins, commands, rules and orchestration policies.
- **Group/Priority/Risk:** `target-generator` / `P1` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-ai-tool-authority-policy-generator`
- **Path:** `agent-skills/runtime/elmos-target-coding-agent-harness-family-generator/SKILL.md`

### `elmos-target-crewai-generator`

- **Purpose:** Generate Crew and Flow projects with role contracts, tasks, event-driven control, state persistence, tool policies and evaluation.
- **Group/Priority/Risk:** `target-generator` / `P1` / `high`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-crewai-generator/SKILL.md`

### `elmos-target-deepseek-harness-generator`

- **Purpose:** Generate Cordis-based plugins, services, events, lifecycle effects, bundles, profiles and patch layers with hot-unload and authority conformance tests.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-deepseek-harness-generator/SKILL.md`

### `elmos-target-dify-project-generator`

- **Purpose:** Generate and import/export Dify Chatflow, Workflow, Agent, knowledge-pipeline and plugin projects with deterministic layout, dependency manifests and unsupported-node accounting.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-ai-roundtrip-migration-controller`
- **Path:** `agent-skills/runtime/elmos-target-dify-project-generator/SKILL.md`

### `elmos-target-google-adk-generator`

- **Purpose:** Generate Python, TypeScript, Java/Kotlin and Go ADK projects with agent teams, workflow agents, A2A, evaluation, sessions, artifacts and deployment profiles.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-google-adk-generator/SKILL.md`

### `elmos-target-haystack-generator`

- **Purpose:** Generate component, pipeline, document-store, agent, toolset and human-loop projects with pipeline serialization and evaluation evidence.
- **Group/Priority/Risk:** `target-generator` / `P1` / `high`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-ai-rag-semantic-compiler`
- **Path:** `agent-skills/runtime/elmos-target-haystack-generator/SKILL.md`

### `elmos-target-langchain-project-generator`

- **Purpose:** Generate typed Python and TypeScript LangChain applications for model, tool, retriever, middleware and short-horizon agent composition with migration hooks to LangGraph.
- **Group/Priority/Risk:** `target-generator` / `P0` / `high`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-langchain-project-generator/SKILL.md`

### `elmos-target-langchain4j-generator`

- **Purpose:** Generate Java AI services with models, tools, RAG, MCP, agentic modules and Spring Boot integration, including Spring AI comparison and migration evidence.
- **Group/Priority/Risk:** `target-generator` / `P1` / `high`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-langchain4j-generator/SKILL.md`

### `elmos-target-langgraph-project-generator`

- **Purpose:** Generate typed graph applications with state schemas, subgraphs, checkpointers, stores, interrupts, durable execution, streaming, human gates and liveness validation.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-ai-graph-liveness-side-effect-verifier`
- **Path:** `agent-skills/runtime/elmos-target-langgraph-project-generator/SKILL.md`

### `elmos-target-language-backend-emitter`

- **Purpose:** Emit buildable target repositories from semantic IR using deterministic code generation, bounded synthesis and target-native package, error, concurrency and ownership conventions.
- **Group/Priority/Risk:** `polyglot-backend` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-language-semantic-profile-compiler`, `elmos-ai-target-adapter-sdk`
- **Path:** `agent-skills/runtime/elmos-target-language-backend-emitter/SKILL.md`

### `elmos-target-lightweight-agent-sdk-family-generator`

- **Purpose:** Generate Strands Agents, Agno, smolagents, DSPy, Qwen-Agent and CAMEL projects through a shared lightweight-agent contract and explicit capability limitations.
- **Group/Priority/Risk:** `target-generator` / `P1` / `high`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-lightweight-agent-sdk-family-generator/SKILL.md`

### `elmos-target-llamaindex-generator`

- **Purpose:** Generate Python and TypeScript document-intelligence, agentic RAG, extraction, workflow and knowledge-assistant projects with explicit data lifecycle contracts.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-ai-rag-semantic-compiler`
- **Path:** `agent-skills/runtime/elmos-target-llamaindex-generator/SKILL.md`

### `elmos-target-mastra-generator`

- **Purpose:** Generate TypeScript agent, graph workflow, memory, human approval and deployment projects with framework-neutral trace and tool contracts.
- **Group/Priority/Risk:** `target-generator` / `P1` / `high`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-mastra-generator/SKILL.md`

### `elmos-target-microsoft-agent-framework-generator`

- **Purpose:** Generate .NET and Python projects with typed agents, sessions, graph workflows, human-in-the-loop, telemetry and migration assets from AutoGen or Semantic Kernel.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-microsoft-agent-framework-generator/SKILL.md`

### `elmos-target-openai-agents-sdk-generator`

- **Purpose:** Generate Python and TypeScript agent projects with tools, handoffs, guardrails, sessions, tracing, MCP, structured outputs and realtime integration contracts.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-openai-agents-sdk-generator/SKILL.md`

### `elmos-target-openclaw-assistant-generator`

- **Purpose:** Generate isolated OpenClaw gateway/workspace configurations, agents, skills, plugins, channels, sandbox policies, pairing, service and recovery assets.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-ai-tool-authority-policy-generator`
- **Path:** `agent-skills/runtime/elmos-target-openclaw-assistant-generator/SKILL.md`

### `elmos-target-openharness-generator`

- **Purpose:** Generate provider, tool, skill, plugin, hook, permission, memory, session and multi-agent extensions against the OpenHarness adapter contract.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-openharness-generator/SKILL.md`

### `elmos-target-pi-package-generator`

- **Purpose:** Generate complete Pi packages containing extensions, custom tools, skills, prompt templates, themes, repository conventions, RPC/SDK embedding and load tests.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-pi-package-generator/SKILL.md`

### `elmos-target-pydanticai-generator`

- **Purpose:** Generate type-safe Python agents, dependency injection, structured output, graph state machines, MCP and durable execution integrations.
- **Group/Priority/Risk:** `target-generator` / `P1` / `high`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-pydanticai-generator/SKILL.md`

### `elmos-target-ragflow-generator`

- **Purpose:** Generate document-centric RAGFlow projects, ingestion settings, knowledge bases, agent workflows, APIs and deployment integration while retaining a portable RAG contract.
- **Group/Priority/Risk:** `target-generator` / `P1` / `high`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-ai-rag-semantic-compiler`
- **Path:** `agent-skills/runtime/elmos-target-ragflow-generator/SKILL.md`

### `elmos-target-spring-ai-project-generator`

- **Purpose:** Generate enterprise Spring Boot AI services with ChatClient, Advisors, RAG, VectorStore, tools, MCP, memory, security, observability, Testcontainers and deployment assets.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-spring-ai-project-generator/SKILL.md`

### `elmos-target-symphony-workflow-generator`

- **Purpose:** Generate repository-versioned workflow policy, work-item adapters, isolated workspace contracts, retry/backoff, proof-of-work and handoff artifacts for coding orchestration.
- **Group/Priority/Risk:** `target-generator` / `P0` / `high`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`
- **Path:** `agent-skills/runtime/elmos-target-symphony-workflow-generator/SKILL.md`

### `elmos-target-universal-rag-project-generator`

- **Purpose:** Generate production RAG repositories spanning ingestion, parsing, ACL-aware indexing, hybrid retrieval, reranking, grounded answering, administration, evaluation and operations.
- **Group/Priority/Risk:** `target-generator` / `P0` / `critical`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-ai-rag-semantic-compiler`
- **Path:** `agent-skills/runtime/elmos-target-universal-rag-project-generator/SKILL.md`

### `elmos-target-vercel-ai-sdk-generator`

- **Purpose:** Generate AI-native web applications with typed streaming, tool calling, generative UI, framework adapters, server routes and backend-agent contracts.
- **Group/Priority/Risk:** `target-generator` / `P1` / `high`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-ai-interaction-channel-compiler`
- **Path:** `agent-skills/runtime/elmos-target-vercel-ai-sdk-generator/SKILL.md`

### `elmos-target-visual-agent-platform-family-generator`

- **Purpose:** Generate or migrate Langflow, Coze Studio, FastGPT and n8n AI projects through platform-specific adapters without making visual DSLs the canonical source of truth.
- **Group/Priority/Risk:** `target-generator` / `P1` / `high`
- **Kernels:** K3, K5, K6, K7
- **Dependencies:** `elmos-ai-project-repository-emitter`, `elmos-ai-roundtrip-migration-controller`
- **Path:** `agent-skills/runtime/elmos-target-visual-agent-platform-family-generator/SKILL.md`

### `elmos-template-marketplace-package-lifecycle-governor`

- **Purpose:** Govern reusable templates, Skills, adapters and archetypes through publisher identity, compatibility, signing, review, distribution, update and revocation.
- **Group/Priority/Risk:** `architecture-marketplace` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6
- **Dependencies:** `elmos-agent-skill-mcp-supply-chain-certifier`, `elmos-ai-target-adapter-sdk`
- **Path:** `agent-skills/runtime/elmos-template-marketplace-package-lifecycle-governor/SKILL.md`

### `elmos-temporal-knowledge-memory-conflict-resolver`

- **Purpose:** Resolve contradictory, stale and time-scoped facts across documents, tools, user memory and organizational knowledge with provenance and policy.
- **Group/Priority/Risk:** `knowledge-temporal` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-memory-semantic-compiler`, `elmos-rag-acl-freshness-deletion-verifier`
- **Path:** `agent-skills/runtime/elmos-temporal-knowledge-memory-conflict-resolver/SKILL.md`

### `elmos-tenant-cryptographic-key-isolation-controller`

- **Purpose:** Generate and verify per-tenant envelope encryption, KMS/HSM policy, rotation, revocation, backup and cryptographic erasure.
- **Group/Priority/Risk:** `security-tenant-crypto` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-ai-multitenant-control-plane-generator`, `elmos-ai-retention-erasure-verifier`
- **Path:** `agent-skills/runtime/elmos-tenant-cryptographic-key-isolation-controller/SKILL.md`

### `elmos-terraform-pulumi-crossplane-infra-generator`

- **Purpose:** Generate portable infrastructure definitions from Deployment IR with state, policy, drift, secret and rollback controls.
- **Group/Priority/Risk:** `platform-iac` / `P0` / `critical`
- **Kernels:** K1, K2, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-deployment-pack-generator`, `elmos-ai-policy-as-code-compiler`
- **Path:** `agent-skills/runtime/elmos-terraform-pulumi-crossplane-infra-generator/SKILL.md`

### `elmos-test-data-privacy-synthetic-generation-certifier`

- **Purpose:** Generate representative synthetic/subset data with privacy guarantees, referential integrity, rare-case coverage and measured fidelity.
- **Group/Priority/Risk:** `qa-test-data` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-test-fixture-data-factory`, `elmos-sensitive-data-masking-tokenization-certifier`
- **Path:** `agent-skills/runtime/elmos-test-data-privacy-synthetic-generation-certifier/SKILL.md`

### `elmos-test-environment-service-virtualization-controller`

- **Purpose:** Provision reproducible ephemeral environments, real infrastructure where required, bounded simulators where allowed and explicit fidelity evidence.
- **Group/Priority/Risk:** `qa-environment` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-native-conformance-lab-controller`, `elmos-service-virtualization-contract-simulator`
- **Path:** `agent-skills/runtime/elmos-test-environment-service-virtualization-controller/SKILL.md`

### `elmos-test-fixture-data-factory`

- **Purpose:** Generate deterministic, privacy-safe, versioned fixtures and edge corpora with referential integrity, data distributions, provenance and deletion rules.
- **Group/Priority/Risk:** `qa-fixtures` / `P0` / `critical`
- **Kernels:** K2, K5, K6, K7
- **Dependencies:** `elmos-test-matrix-covering-array-planner`, `elmos-ai-data-contract-quality-governor`
- **Path:** `agent-skills/runtime/elmos-test-fixture-data-factory/SKILL.md`

### `elmos-test-matrix-covering-array-planner`

- **Purpose:** Select risk-weighted PR, nightly, release and certification matrices across language, framework, database, provider, OS, architecture and deployment dimensions.
- **Group/Priority/Risk:** `qa-planning` / `P0` / `high`
- **Kernels:** K1, K4, K6
- **Dependencies:** `elmos-proof-to-validation-dag-compiler`
- **Path:** `agent-skills/runtime/elmos-test-matrix-covering-array-planner/SKILL.md`

### `elmos-tool-discovery-description-quality-evaluator`

- **Purpose:** Evaluate tool naming, descriptions, schemas, examples and annotations for correct selection, non-selection and safe argument formation.
- **Group/Priority/Risk:** `protocol-tool-quality` / `P0` / `high`
- **Kernels:** K1, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-tool-protocol-compiler`, `elmos-agent-skill-trigger-evaluator`
- **Path:** `agent-skills/runtime/elmos-tool-discovery-description-quality-evaluator/SKILL.md`

### `elmos-transaction-locking-equivalence-verifier`

- **Purpose:** Verify isolation, lock acquisition, deadlock, savepoint, constraint timing, sequence visibility and concurrent business invariants across database engines.
- **Group/Priority/Risk:** `database-assurance` / `P0` / `critical`
- **Kernels:** K3, K6, K7
- **Dependencies:** `elmos-sql-dual-execution-oracle`
- **Path:** `agent-skills/runtime/elmos-transaction-locking-equivalence-verifier/SKILL.md`

### `elmos-trusted-computing-base-minimization-governor`

- **Purpose:** Inventory, minimize and version the compilers, solvers, runtimes, policies, signers and assumptions trusted by each certificate.
- **Group/Priority/Risk:** `formal-tcb` / `P0` / `critical`
- **Kernels:** K3, K4, K6, K8
- **Dependencies:** `elmos-certification-scope-compiler`, `elmos-ai-bom-provenance-generator`
- **Path:** `agent-skills/runtime/elmos-trusted-computing-base-minimization-governor/SKILL.md`

### `elmos-ui-visual-regression-journey-certifier`

- **Purpose:** Certify generated web, desktop and agent UI through visual diffs, semantic journeys, responsive layouts, accessibility and cross-browser behavior.
- **Group/Priority/Risk:** `qa-ui` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K6, K7, K8
- **Dependencies:** `elmos-accessibility-conformance-certifier`, `elmos-contract-integration-e2e-controller`
- **Path:** `agent-skills/runtime/elmos-ui-visual-regression-journey-certifier/SKILL.md`

### `elmos-user-feedback-issue-to-eval-dataset-pipeline`

- **Purpose:** Convert support, incidents, ratings and corrected outcomes into governed counterexamples and evaluation data with consent, deduplication and holdout protection.
- **Group/Priority/Risk:** `learning-feedback` / `P0` / `critical`
- **Kernels:** K1, K2, K4, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-eval-dataset-governor`, `elmos-counterexample-regression-promoter`
- **Path:** `agent-skills/runtime/elmos-user-feedback-issue-to-eval-dataset-pipeline/SKILL.md`

### `elmos-vector-database-index-ir-compiler`

- **Purpose:** Compile embedding schema, metric, normalization, filter, index algorithm, consistency, namespace, deletion and recall/latency envelopes across vector stores.
- **Group/Priority/Risk:** `data-vector-ir` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ai-rag-semantic-compiler`, `elmos-rag-acl-freshness-deletion-verifier`
- **Path:** `agent-skills/runtime/elmos-vector-database-index-ir-compiler/SKILL.md`

### `elmos-vector-store-migration-benchmark-controller`

- **Purpose:** Migrate embeddings and metadata among vector stores while preserving ACLs, recall, latency, freshness, deletion and cost envelopes.
- **Group/Priority/Risk:** `data-vector-migration` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-vector-database-index-ir-compiler`, `elmos-ai-rag-retrieval-grounding-certifier`
- **Path:** `agent-skills/runtime/elmos-vector-store-migration-benchmark-controller/SKILL.md`

### `elmos-vulnerability-vex-kev-response-governor`

- **Purpose:** Correlate SBOM/AIBOM components with advisories, exploitability, CISA KEV, reachability and runtime evidence to drive risk-based remediation and certificate impact.
- **Group/Priority/Risk:** `supply-chain-vulnerability` / `P0` / `critical`
- **Kernels:** K2, K6, K7, K8
- **Dependencies:** `elmos-ai-bom-provenance-generator`, `elmos-ai-supply-chain-performance-resilience-certifier`
- **Path:** `agent-skills/runtime/elmos-vulnerability-vex-kev-response-governor/SKILL.md`

### `elmos-waiver-expiry-governor`

- **Purpose:** Control exceptional waivers with explicit claim scope, rationale, compensating controls, owner, approvals, expiry and automatic certificate impact.
- **Group/Priority/Risk:** `certification-governance` / `P0` / `critical`
- **Kernels:** K1, K6, K8
- **Dependencies:** `elmos-certification-scope-compiler`, `elmos-ai-policy-as-code-compiler`
- **Path:** `agent-skills/runtime/elmos-waiver-expiry-governor/SKILL.md`

### `elmos-warehouse-lakehouse-migration-certifier`

- **Purpose:** Certify semantic, performance, governance and cost migration among warehouses and open table formats using dual execution and workload replay.
- **Group/Priority/Risk:** `data-warehouse-certification` / `P0` / `critical`
- **Kernels:** K1, K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-database-performance-plan-certifier`, `elmos-lakehouse-table-format-ir-compiler`
- **Path:** `agent-skills/runtime/elmos-warehouse-lakehouse-migration-certifier/SKILL.md`

### `elmos-wasi-sandbox-capability-certifier`

- **Purpose:** Certify filesystem, network, clock, randomness, environment, secret and process capabilities for WASI workloads under deny-by-default runtime policy.
- **Group/Priority/Risk:** `security-wasi-sandbox` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-wasm-component-wit-portability-compiler`, `elmos-runtime-sandbox-ebpf-behavior-verifier`
- **Path:** `agent-skills/runtime/elmos-wasi-sandbox-capability-certifier/SKILL.md`

### `elmos-wasm-component-wit-portability-compiler`

- **Purpose:** Compile polyglot components, worlds, interfaces, resources, ownership and canonical ABI contracts into portable WebAssembly Component Model artifacts with native round-trip evidence.
- **Group/Priority/Risk:** `polyglot-wasm-component` / `P0` / `critical`
- **Kernels:** K2, K3, K5, K6, K7, K8
- **Dependencies:** `elmos-ffi-abi-native-boundary-certifier`, `elmos-cross-language-serialization-wire-compatibility-verifier`
- **Path:** `agent-skills/runtime/elmos-wasm-component-wit-portability-compiler/SKILL.md`

### `elmos-webhook-delivery-security-reliability-controller`

- **Purpose:** Generate and verify webhook signing, replay protection, delivery retries, ordering, endpoint rotation, observability and dead-letter handling.
- **Group/Priority/Risk:** `event-webhook` / `P0` / `critical`
- **Kernels:** K1, K3, K5, K6, K7
- **Dependencies:** `elmos-api-event-contract-ir-compiler`, `elmos-ai-secret-credential-lifecycle-controller`
- **Path:** `agent-skills/runtime/elmos-webhook-delivery-security-reliability-controller/SKILL.md`

### `elmos-zero-trust-service-identity-policy-compiler`

- **Purpose:** Compile workload identity, mTLS, audience, delegation, authorization and rotation policies for agents, tools, services and customer runners.
- **Group/Priority/Risk:** `security-zero-trust` / `P0` / `critical`
- **Kernels:** K1, K2, K6, K7, K8
- **Dependencies:** `elmos-agent-workload-delegated-identity-controller`, `elmos-ai-policy-as-code-compiler`
- **Path:** `agent-skills/runtime/elmos-zero-trust-service-identity-policy-compiler/SKILL.md`
