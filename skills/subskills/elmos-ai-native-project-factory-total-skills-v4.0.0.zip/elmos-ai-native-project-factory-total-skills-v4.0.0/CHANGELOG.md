# Changelog

## 4.0.0 — 2026-08-28

- Merged the complete v3 AI-Native Project Factory baseline into one Total Skills package.
- Added 162 implementation Skills covering deep polyglot semantics, multi-store/lakehouse data, event consistency, model serving/realtime/edge, knowledge, full QA, formal assurance, zero-trust, platform engineering, product architecture, governance, FinOps and safe learning.
- Added 150 protocol, data, serving, formal, security, infrastructure and QA Adapters.
- Added executable schemas/examples, durable workflows, Rego policies/tests, PostgreSQL migrations, commercial Golden Routes, implementation tasks and reference tests.
- Preserved K1–K8 ownership, 16 routable entries, fail-closed critical decisions and independent K8 certification.

## Compatibility

This is additive at the component layer. Existing Skill names remain valid. The package does not promote any legacy component into an independent route owner.
