# References and Version-Pinning Rules

The package design is informed by official specifications and primary project documentation. These references define capability families; they are not production pins.

## Protocol and API foundations

- Model Context Protocol specification `2026-07-28`: https://modelcontextprotocol.io/specification/2026-07-28
- Agent2Agent Protocol v1 and signed Agent Cards: https://a2a-protocol.org/latest/specification/
- Agent Client Protocol: https://agentclientprotocol.com/
- OpenAI Plugins and Apps SDK: https://developers.openai.com/plugins
- OpenAPI Specification v3.2.0: https://spec.openapis.org/oas/v3.2.0.html
- Arazzo Specification v1.1.0: https://spec.openapis.org/arazzo/v1.1.0.html
- AsyncAPI Specification: https://www.asyncapi.com/docs/reference/specification/latest
- CloudEvents: https://cloudevents.io/
- WebAssembly Component Model: https://component-model.bytecodealliance.org/
- WASI: https://wasi.dev/

## Data, model serving and observability

- OpenTelemetry GenAI semantic conventions: https://opentelemetry.io/docs/specs/semconv/gen-ai/
- OpenLineage: https://openlineage.io/docs/
- Apache Iceberg specification: https://iceberg.apache.org/spec/
- Delta Lake protocol: https://github.com/delta-io/delta/blob/master/PROTOCOL.md
- KServe: https://kserve.github.io/website/
- NVIDIA Triton Inference Server: https://docs.nvidia.com/deeplearning/triton-inference-server/user-guide/docs/
- Ray Serve: https://docs.ray.io/en/latest/serve/
- OpenFeature: https://openfeature.dev/specification/

## Security, provenance and transparency

- SLSA specification: https://slsa.dev/spec/
- Sigstore/Cosign: https://www.sigstore.dev/
- in-toto: https://in-toto.io/
- The Update Framework: https://theupdateframework.io/
- SPIFFE/SPIRE: https://spiffe.io/
- SCITT architecture, RFC 9943: https://www.rfc-editor.org/rfc/rfc9943.html
- OWASP GenAI Security Project: https://genai.owasp.org/
- NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
- ISO/IEC 42001 overview: https://www.iso.org/standard/81230.html

## Release rule

A URL, project name, broad compatibility claim or `latest` tag is never production evidence. Every production certificate must bind:

```text
exact specification/runtime/database/framework/model version
+ artifact/container/adapter/toolchain digest
+ conformance corpus and verifier digest
+ policy bundle and environment profile
+ assumptions, waivers and evidence freshness
```

An upstream change invalidates only the dependent evidence subgraph. Critical invalidated evidence blocks release until the affected Validation DAG is rerun and K8 issues a new bounded decision.
