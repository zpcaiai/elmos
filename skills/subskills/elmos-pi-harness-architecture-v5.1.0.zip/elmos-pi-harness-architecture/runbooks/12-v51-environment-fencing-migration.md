# v5.1 Migration Runbook
1. introduce EnvironmentRef for every Turn/Tool execution
2. capture AuthoritySnapshot when environment/MCP runtime is published
3. stop reading thread-global permission state from adapters
4. persist sandbox overrides at environment scope
5. add executor_generation and connection_epoch
6. split reconnect vs replacement paths
7. fence late RPC/process/callback/artifact results
8. add WorkspaceLease around managed worktrees
9. negotiate protocol capabilities on adapter connect
10. migrate ToolResult to typed content union
11. isolate upstream API rename churn inside adapters
12. add invariants/property tests
