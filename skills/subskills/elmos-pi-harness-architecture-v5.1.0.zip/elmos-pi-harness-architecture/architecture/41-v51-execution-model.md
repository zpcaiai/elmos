# Execution Model v5.1

`Execution = Identity + Ownership + Environment + Authority + Timeline + Artifacts + Lifecycle + Effects + Evidence`

Environment and Ownership are explicit first-class concepts.
Permissions, Workspace, Executor, MCP and ToolResult must not be derived from a global Session.
