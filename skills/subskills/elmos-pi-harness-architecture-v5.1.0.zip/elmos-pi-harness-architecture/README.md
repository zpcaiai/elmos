# elmos-pi-harness-architecture v5.1.0

**Environment-Owned Authority, Executor Fencing & Workspace Lease Edition**

This release integrates the supplied 2026-08-25–26 Harness-native changes:

- authority belongs to the concrete Environment / Attachment, not thread-global permission state
- remote executor replacement requires explicit generation fencing
- workspace ownership becomes durable metadata, not just a cwd
- replay/tool adapters negotiate protocol capabilities
- tool results remain typed content
- upstream API names stay isolated inside adapters

Canonical authority path:

`ToolInvocation -> EnvironmentRef -> AuthoritySnapshot -> EffectivePolicy`
