# WorkspaceOwner / WorkspaceLease

A workspace is not just a path.
Identity includes workspace_id, owner_execution_id, generation, repository_id, base_revision and lifecycle_state.

Invariants: no-clobber ownership, same-owner idempotent bind, stale-owner fencing,
explicit parent/subagent scope, crash takeover with generation increment.
