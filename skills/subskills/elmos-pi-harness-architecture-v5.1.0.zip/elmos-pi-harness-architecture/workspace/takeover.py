def can_takeover(existing_lease, requester_execution_id, stale_owner, durable_checkpoint_ready):
    blockers=[]
    if not stale_owner: blockers.append("owner_not_stale")
    if not durable_checkpoint_ready: blockers.append("checkpoint_not_ready")
    if requester_execution_id == existing_lease.owner_execution_id:
        blockers.append("same_owner_should_resume_not_takeover")
    return {"allowed": not blockers, "blockers": blockers,
            "next_generation": existing_lease.generation + 1 if not blockers else existing_lease.generation}
