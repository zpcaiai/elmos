from dataclasses import dataclass
@dataclass(frozen=True)
class WorkspaceLease:
    workspace_id: str
    owner_execution_id: str
    generation: int
    repository_id: str
    base_revision: str
    lifecycle_state: str

def bind(existing, requested):
    if existing is None:
        return {"bound": True, "lease": requested}
    if (existing.owner_execution_id == requested.owner_execution_id and
        existing.repository_id == requested.repository_id and
        existing.base_revision == requested.base_revision):
        return {"bound": True, "lease": existing, "idempotent": True}
    return {"bound": False, "reason": "workspace_owned_by_other_execution"}
