---
name: elmos-pi-harness-architecture
description: >
  Environment-Owned Authority, Executor Fencing & Workspace Lease Edition.
  Extends the Execution Kernel with environment-owned authority snapshots,
  executor generation fencing, durable workspace ownership, protocol capability negotiation,
  typed tool-result transport, and adapter API version isolation.
version: 5.1.0
license: Proprietary
---
# Elmos Pi Harness Architecture — Environment-Owned Authority, Executor Fencing & Workspace Lease Edition

## Canonical model

`Execution = Identity + Ownership + Environment + Authority + Timeline + Artifacts + Lifecycle + Effects + Evidence`

## P0 additions

1. Environment-owned / Attachment-owned authority
2. AuthoritySnapshot per Tool/MCP/Executor capability
3. TurnEnvironment-bound sandbox policy
4. Executor replacement lifecycle with generation fencing
5. Remote callback/result fencing by executor_generation
6. WorkspaceLease / WorkspaceOwner
7. stale-owner fencing and crash takeover
8. session-resume preservation of environment sandbox overrides

## P1 additions

1. Protocol capability negotiation
2. History mode + pagination + consistency model
3. typed ToolResult union
4. schema dialect negotiation
5. adapter API version isolation
6. upstream type rename isolation via InstructionEnvelope

## Hard invariants

- tool authority is derived from owner environment ∩ upper-layer policy
- authority can never widen because of agent switch, resume or MCP refresh
- replaced executors cannot publish late state/results
- different executions cannot concurrently write the same managed workspace
- tool results remain typed internally and are never stringified by adapters
