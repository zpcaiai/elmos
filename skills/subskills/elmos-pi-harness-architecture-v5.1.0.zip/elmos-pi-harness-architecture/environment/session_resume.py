def restore_environment(snapshot, current_config):
    if snapshot["environment_id"] != current_config["environment_id"]:
        return {"restored": False, "reason": "environment_identity_changed"}
    restored = dict(current_config)
    restored["sandbox_overrides"] = snapshot.get("sandbox_overrides", {})
    restored["permission_profile_version"] = snapshot.get("permission_profile_version")
    return {"restored": True, "environment": restored}
