def effective_turn_policy(turn_environment, tenant_policy, harness_policy):
    env_allowed = set(turn_environment["authority"]["allowed"])
    env_denied = set(turn_environment["authority"].get("denied", []))
    allowed = env_allowed & set(tenant_policy["allowed"]) & set(harness_policy["allowed"])
    denied = env_denied | set(tenant_policy.get("denied", [])) | set(harness_policy.get("denied", []))
    return {"allowed": sorted(allowed - denied), "denied": sorted(denied),
            "sandbox_overrides": turn_environment.get("sandbox_overrides", {})}
