from dataclasses import dataclass

@dataclass(frozen=True)
class EnvironmentRef:
    environment_id: str
    owner_execution_id: str
    generation: int
    environment_type: str
