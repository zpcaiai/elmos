# Typed ToolResult
Internal Tool/MCP results remain typed content: text, media, encrypted and unknown/forward-compatible content.
Adapters must not stringify structured content into JSON blobs before orchestration/model layers.
