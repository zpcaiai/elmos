from dataclasses import dataclass
from typing import Any
@dataclass(frozen=True)
class TextContent: text: str
@dataclass(frozen=True)
class MediaContent: media_type: str; uri: str|None; data_ref: str|None
@dataclass(frozen=True)
class EncryptedContent: ciphertext_ref: str; algorithm: str
@dataclass(frozen=True)
class UnknownContent: raw: Any
TypedContent = TextContent | MediaContent | EncryptedContent | UnknownContent
@dataclass(frozen=True)
class ToolResult:
    call_id: str
    items: tuple[TypedContent, ...]
    metadata: dict
