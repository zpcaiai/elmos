# P0 Acceptance Tests

- [ ] Same task runs successfully on at least 3 model providers.
- [ ] Provider fallback works without task corruption.
- [ ] Tool schema validation rejects malformed input.
- [ ] Cancellation interrupts model/tool work.
- [ ] Events are emitted in deterministic lifecycle order.
- [ ] RPC and SDK observe identical task state.
- [ ] Tool outputs larger than threshold are stored as artifacts.
