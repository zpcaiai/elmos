# Acceptance
- [ ] Python functions/classes become graph nodes.
- [ ] graph node IDs are stable within a revision.
- [ ] ignored/vendor/build directories are excluded.
- [ ] context selection obeys hard token budget.
- [ ] stable and dynamic prompt segments are separated.
- [ ] selected context has provenance metadata.
- [ ] graph expansion supports change-impact analysis.
- [ ] re-indexing unchanged revision is idempotent/cacheable.
