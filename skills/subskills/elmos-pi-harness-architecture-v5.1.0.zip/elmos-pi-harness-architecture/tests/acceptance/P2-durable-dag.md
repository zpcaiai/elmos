# P2 Durable DAG Acceptance Tests

- [ ] Kill worker during tool call; task recovers safely.
- [ ] Kill scheduler; task state persists.
- [ ] Resume paused task from last safe checkpoint.
- [ ] Cancel task with children; descendants terminate deterministically.
- [ ] Retry does not duplicate side effects.
- [ ] Expired lease is reclaimed.
- [ ] Account concurrency limit is enforced.
- [ ] Client disconnect does not stop server-side task.
