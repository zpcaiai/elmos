# v3.0 Acceptance

- [ ] benchmark tasks pin repository revisions.
- [ ] deterministic grader controls validated success.
- [ ] anti-gaming scan detects common test suppression.
- [ ] E5 claims require repeated verified runs.
- [ ] E6 claims require large-repo or chaos certification.
- [ ] E7 requires customer acceptance evidence.
- [ ] claims include scope and evidence IDs.
- [ ] unit economics uses validated task outcomes.
- [ ] proof packs contain no unscoped superiority claims.
