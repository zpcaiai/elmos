create table if not exists execution_environment(
  environment_id uuid primary key,
  execution_id uuid not null,
  owner_execution_id uuid not null,
  generation bigint not null default 0,
  environment_type text not null,
  config jsonb not null,
  sandbox_overrides jsonb not null default '{}'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create table if not exists authority_snapshot(
  id uuid primary key,
  authority_owner_id uuid not null,
  environment_id uuid not null references execution_environment(environment_id),
  permission_profile_version text not null,
  allowed_capabilities jsonb not null,
  denied_capabilities jsonb not null,
  sandbox_overrides jsonb not null default '{}'::jsonb,
  created_at timestamptz default now()
);
create table if not exists executor_connection(
  environment_id uuid not null references execution_environment(environment_id),
  executor_id text not null,
  executor_generation bigint not null,
  connection_epoch bigint not null,
  state text not null,
  retired boolean not null default false,
  updated_at timestamptz default now(),
  primary key(environment_id,executor_id,executor_generation)
);
create table if not exists workspace_lease(
  workspace_id text primary key,
  owner_execution_id uuid not null,
  generation bigint not null,
  repository_id text not null,
  base_revision text not null,
  lifecycle_state text not null,
  metadata jsonb not null default '{}'::jsonb,
  updated_at timestamptz default now()
);
create table if not exists protocol_capability_snapshot(
  id uuid primary key,
  adapter_id text not null,
  protocol_version text not null,
  capabilities jsonb not null,
  created_at timestamptz default now()
);
