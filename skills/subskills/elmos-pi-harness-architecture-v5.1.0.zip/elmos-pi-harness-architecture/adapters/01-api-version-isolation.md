# Adapter API Version Isolation
Upstream type names never enter Elmos Harness SPI.
A rename such as Codex `UserInstructions` → `Instructions` is handled inside the Codex Adapter only.
Elmos keeps its stable `InstructionEnvelope` contract.
