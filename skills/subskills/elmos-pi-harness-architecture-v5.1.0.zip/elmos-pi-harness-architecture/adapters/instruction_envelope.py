from dataclasses import dataclass
@dataclass(frozen=True)
class InstructionEnvelope:
    text: str
    source: str
    scope: str
    provenance: dict
