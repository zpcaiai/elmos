def map_instruction(upstream_instruction):
    from adapters.instruction_envelope import InstructionEnvelope
    text = getattr(upstream_instruction, "text", None) or str(upstream_instruction)
    return InstructionEnvelope(text=text, source="codex", scope="adapter",
        provenance={"upstream_type": type(upstream_instruction).__name__})
