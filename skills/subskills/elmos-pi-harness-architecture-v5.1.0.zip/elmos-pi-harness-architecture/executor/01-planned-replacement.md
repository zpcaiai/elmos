# Planned Executor Replacement

Two paths:
- ReconnectSameExecutor
- ReplaceExecutor

Replacement protocol:
1. re-query registry
2. detect identity/generation change
3. retire old session/connection attempt
4. fence old callbacks/RPC/artifact uploads
5. connect replacement
6. perform live status probe
7. publish new active generation

Every ToolCall/process/RPC/callback/artifact upload carries executor_generation.
Late results from old generations are discarded.
