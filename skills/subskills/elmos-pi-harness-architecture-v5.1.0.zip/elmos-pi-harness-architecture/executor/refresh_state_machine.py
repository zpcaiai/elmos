def refresh(current, registry_identity, connection_healthy):
    if current is None:
        return {"action": "CONNECT_NEW", "next_generation": registry_identity.generation}
    same = current.executor_id == registry_identity.executor_id and current.generation == registry_identity.generation
    if same and connection_healthy:
        return {"action": "REUSE_CONNECTION", "next_generation": current.generation}
    if same:
        return {"action": "RECONNECT_SAME_EXECUTOR", "next_generation": current.generation}
    return {"action": "REPLACE_EXECUTOR", "retire_generation": current.generation,
            "next_generation": registry_identity.generation, "requires_live_status_probe": True}
