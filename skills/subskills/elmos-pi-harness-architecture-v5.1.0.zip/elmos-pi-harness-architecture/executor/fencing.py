def accept_message(message_generation, active_generation):
    return {"accepted": message_generation == active_generation,
            "reason": None if message_generation == active_generation else "stale_executor_generation"}

def fence_payload(payload, executor_id, generation):
    out = dict(payload)
    out["executor_id"] = executor_id
    out["executor_generation"] = generation
    return out
