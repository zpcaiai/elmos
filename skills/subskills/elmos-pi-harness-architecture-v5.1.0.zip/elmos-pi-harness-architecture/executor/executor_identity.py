from dataclasses import dataclass
@dataclass(frozen=True)
class ExecutorIdentity:
    executor_id: str
    generation: int
    registry_revision: str | None = None
