from abc import ABC, abstractmethod

class RerankerProvider(ABC):
    @abstractmethod
    def score(self, query, documents): ...

class FeatureFallbackReranker(RerankerProvider):
    def score(self, query, documents):
        q=set(query.lower().split())
        return [len(q & set(d.lower().split()))/max(len(q),1) for d in documents]

class CrossEncoderProvider(RerankerProvider):
    def __init__(self, model):
        self.model=model

    def score(self, query, documents):
        pairs=[(query,d) for d in documents]
        return [float(v) for v in self.model.predict(pairs)]
