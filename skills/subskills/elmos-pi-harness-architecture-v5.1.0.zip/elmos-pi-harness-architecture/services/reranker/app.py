from fastapi import FastAPI
from pydantic import BaseModel
from providers import FeatureFallbackReranker

app=FastAPI(title="reranker-service",version="1.9.0")
provider=FeatureFallbackReranker()

class Candidate(BaseModel):
    id: str
    text: str

class Request(BaseModel):
    query: str
    candidates: list[Candidate]
    top_k: int = 20

@app.get("/health")
def health(): return {"status":"ok","version":"1.9.0"}

@app.post("/rerank")
def rerank(req: Request):
    scores=provider.score(req.query,[c.text for c in req.candidates])
    rows=sorted(zip(req.candidates,scores),key=lambda x:x[1],reverse=True)[:req.top_k]
    return {"results":[{"id":c.id,"score":s} for c,s in rows]}
