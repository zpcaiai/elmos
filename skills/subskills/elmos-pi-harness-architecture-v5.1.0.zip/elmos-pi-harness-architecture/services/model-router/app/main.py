from fastapi import FastAPI
from pydantic import BaseModel
from typing import Any
from elmos_runtime_core.model_registry import candidates

app=FastAPI(title="model-router",version="1.3.0")

class RouteRequest(BaseModel):
    task_id: str
    required_capabilities: list[str] = ["coding"]
    task_features: dict[str, Any] = {}
    budget_usd: float | None = None
    preferred_provider: str | None = None

@app.get("/livez")
def livez(): return {"status":"ok"}
@app.get("/readyz")
def readyz(): return {"status":"ready"}
@app.get("/version")
def version(): return {"version":"1.3.0"}

@app.post("/internal/model-route")
def route(req: RouteRequest):
    cs=candidates(set(req.required_capabilities))
    if req.preferred_provider:
        preferred=[x for x in cs if x.provider==req.preferred_provider]
        if preferred: cs=preferred
    if not cs:
        return {"task_id":req.task_id,"error":"no_eligible_model"}
    cs=sorted(cs,key=lambda m:(-int(m.tier[1:]),m.relative_cost))
    chosen=cs[0]
    return {
      "task_id":req.task_id,
      "provider":chosen.provider,
      "model":chosen.model,
      "tier":chosen.tier,
      "fallback_chain":[{"provider":m.provider,"model":m.model} for m in cs[1:3]],
      "reason":{"policy":"capability_then_tier_cost"}
    }
