class JobRepository:
    def __init__(self, connection_factory):
        self.connection_factory=connection_factory

    def insert_jobs(self,jobs):
        with self.connection_factory() as conn:
            for j in jobs:
                conn.execute(
                    '''insert into benchmark_execution_job(
                    id,idempotency_key,campaign_id,system_name,repo_revision,task_case_id,repetition,status)
                    values(%s,%s,%s,%s,%s,%s,%s,%s) on conflict(idempotency_key) do nothing''',
                    (j["id"],j["idempotency_key"],j["campaign_id"],j["system_name"],
                     j["repo_revision"],j["task_case_id"],j["repetition"],j["status"]))
            conn.commit()

    def lease_next(self,worker_id,lease_seconds=180):
        with self.connection_factory() as conn:
            row=conn.execute(
                '''select id from benchmark_execution_job
                   where status='QUEUED'
                      or (status in ('LEASED','RUNNING') and lease_expires_at < now())
                   order by created_at for update skip locked limit 1'''
            ).fetchone()
            if not row:
                conn.commit(); return None
            job=conn.execute(
                '''update benchmark_execution_job set status='LEASED',lease_owner=%s,
                   lease_expires_at=now()+(%s * interval '1 second'),
                   attempt=attempt+1,updated_at=now()
                   where id=%s returning id,campaign_id,system_name,repo_revision,
                   task_case_id,repetition,attempt''',
                (worker_id,lease_seconds,row[0])).fetchone()
            conn.commit()
        return {"id":str(job[0]),"campaign_id":str(job[1]),"system_name":job[2],
                "repo_revision":job[3],"task_case_id":job[4],"repetition":job[5],"attempt":job[6]}

    def heartbeat(self,job_id,worker_id,lease_seconds=180):
        with self.connection_factory() as conn:
            row=conn.execute(
                '''update benchmark_execution_job set lease_expires_at=now()+(%s * interval '1 second'),
                   updated_at=now() where id=%s and lease_owner=%s
                   and status in ('LEASED','RUNNING') returning id''',
                (lease_seconds,job_id,worker_id)).fetchone()
            conn.commit()
        return bool(row)

    def complete(self,job_id,worker_id,run_id,evidence_uri):
        with self.connection_factory() as conn:
            row=conn.execute(
                '''update benchmark_execution_job set status='COMPLETED',run_id=%s,evidence_uri=%s,
                   lease_expires_at=null,updated_at=now()
                   where id=%s and lease_owner=%s returning id''',
                (run_id,evidence_uri,job_id,worker_id)).fetchone()
            conn.commit()
        return bool(row)
