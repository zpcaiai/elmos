from uuid import uuid4

class CampaignService:
    def __init__(self, campaign_repo, job_repo):
        self.campaign_repo=campaign_repo
        self.job_repo=job_repo

    def create_campaign(self,payload):
        campaign={
          "id":str(uuid4()),
          "state":"DRAFT",
          **payload
        }
        return self.campaign_repo.create(campaign)

    def get_campaign(self,campaign_id):
        return self.campaign_repo.get(campaign_id)

    def transition(self,campaign_id,state,evidence_ids,note=None):
        return self.campaign_repo.update_state(campaign_id,state,evidence_ids,note)
