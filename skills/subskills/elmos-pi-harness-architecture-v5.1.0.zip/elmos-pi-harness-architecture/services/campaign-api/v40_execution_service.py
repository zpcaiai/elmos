class V40ExecutionService:
    def __init__(self, campaign_repo, job_repo, evidence_store):
        self.campaign_repo=campaign_repo
        self.job_repo=job_repo
        self.evidence_store=evidence_store

    def persist_e4(self, campaign_id, job_id, record, manifest_uri, manifest_sha256):
        if record.get("status")!="EXECUTED":
            raise ValueError("only executed runs can persist E4")
        if record.get("evidence_level")!="E4":
            raise ValueError("record is not E4")
        return self.evidence_store.persist_e4(
            campaign_id, job_id, record, manifest_uri, manifest_sha256
        )
