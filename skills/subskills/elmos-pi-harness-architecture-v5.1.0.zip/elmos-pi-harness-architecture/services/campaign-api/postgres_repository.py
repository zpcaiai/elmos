from __future__ import annotations
import json
from .repository import CampaignRepository

class PostgresCampaignRepository(CampaignRepository):
    def __init__(self, connection_factory):
        self.connection_factory = connection_factory

    def create(self, campaign):
        with self.connection_factory() as conn:
            row = conn.execute(
                '''
                insert into evidence_campaign(
                  id,name,mode,state,suite_name,suite_version,verifier_pack_version,
                  systems,repositories,repetitions,target_evidence_level
                ) values (%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s::jsonb,%s,%s)
                returning id,name,mode,state,suite_name,suite_version,verifier_pack_version,
                          systems,repositories,repetitions,target_evidence_level
                ''',
                (
                    campaign["id"], campaign["name"], campaign["mode"], campaign["state"],
                    campaign["suite_name"], campaign["suite_version"], campaign["verifier_pack_version"],
                    json.dumps(campaign["systems"]), json.dumps(campaign["repositories"]),
                    campaign["repetitions"], campaign["target_evidence_level"]
                )
            ).fetchone()
            conn.commit()
        return campaign

    def get(self, campaign_id):
        with self.connection_factory() as conn:
            row = conn.execute(
                "select id,name,mode,state,suite_name,suite_version,verifier_pack_version,systems,repositories,repetitions,target_evidence_level from evidence_campaign where id=%s",
                (campaign_id,)
            ).fetchone()
        if not row:
            return None
        return {
            "id": str(row[0]), "name": row[1], "mode": row[2], "state": row[3],
            "suite_name": row[4], "suite_version": row[5], "verifier_pack_version": row[6],
            "systems": row[7], "repositories": row[8], "repetitions": row[9],
            "target_evidence_level": row[10]
        }

    def update_state(self, campaign_id, state, evidence_ids, note=None):
        current = self.get(campaign_id)
        if not current:
            raise KeyError(campaign_id)
        with self.connection_factory() as conn:
            conn.execute("update evidence_campaign set state=%s where id=%s", (state,campaign_id))
            conn.execute(
                "insert into campaign_transition_event(campaign_id,from_state,to_state,evidence_ids,note) values(%s,%s,%s,%s::jsonb,%s)",
                (campaign_id,current["state"],state,json.dumps(evidence_ids),note)
            )
            conn.commit()
        current["state"] = state
        return current

    def append_transition(self, campaign_id, from_state, to_state, evidence_ids, note=None):
        with self.connection_factory() as conn:
            conn.execute(
                "insert into campaign_transition_event(campaign_id,from_state,to_state,evidence_ids,note) values(%s,%s,%s,%s::jsonb,%s)",
                (campaign_id,from_state,to_state,json.dumps(evidence_ids),note)
            )
            conn.commit()

    def list_incomplete(self):
        terminal = ("RELEASED","CLAIM_REJECTED")
        with self.connection_factory() as conn:
            rows = conn.execute(
                "select id,name,state from evidence_campaign where state <> all(%s)",
                (list(terminal),)
            ).fetchall()
        return [{"id":str(r[0]),"name":r[1],"state":r[2]} for r in rows]
