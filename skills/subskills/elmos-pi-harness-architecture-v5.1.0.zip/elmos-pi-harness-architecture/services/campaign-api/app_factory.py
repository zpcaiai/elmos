from fastapi import FastAPI,HTTPException
from pydantic import BaseModel

def create_app(service):
    app=FastAPI(title="elmos-campaign-api",version="3.5.0")

    class CampaignCreate(BaseModel):
        name:str
        mode:str
        systems:list[str]
        suite_name:str
        suite_version:str
        verifier_pack_version:str
        repositories:list[str]
        repetitions:int=5
        target_evidence_level:str="E5"

    class Transition(BaseModel):
        state:str
        evidence_ids:list[str]=[]
        note:str|None=None

    @app.post("/v1/campaigns")
    def create(req:CampaignCreate):
        return service.create_campaign(req.model_dump())

    @app.get("/v1/campaigns/{cid}")
    def get(cid:str):
        c=service.get_campaign(cid)
        if not c:
            raise HTTPException(404,"campaign not found")
        return c

    @app.post("/v1/campaigns/{cid}/transition")
    def transition(cid:str,req:Transition):
        return service.transition(cid,req.state,req.evidence_ids,req.note)

    @app.get("/livez")
    def livez():
        return {"status":"ok"}

    @app.get("/readyz")
    def readyz():
        return {"status":"ready"}

    return app
