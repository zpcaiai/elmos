import os

def build_connection_factory():
    try:
        import psycopg
    except ImportError as exc:
        raise RuntimeError("psycopg is required") from exc
    dsn=os.getenv("DATABASE_URL")
    if not dsn:
        raise RuntimeError("DATABASE_URL is required")
    return lambda: psycopg.connect(dsn)

def build_services():
    from services.campaign_api.postgres_repository import PostgresCampaignRepository
    from services.campaign_api.job_repository import JobRepository
    from services.campaign_api.service import CampaignService
    factory=build_connection_factory()
    campaign_repo=PostgresCampaignRepository(factory)
    job_repo=JobRepository(factory)
    return {
      "connection_factory":factory,
      "campaign_repo":campaign_repo,
      "job_repo":job_repo,
      "campaign_service":CampaignService(campaign_repo,job_repo)
    }
