from evidence.finalizers import finalize_e5, finalize_e6, finalize_e7

def finalize(target_level,records,large_repo=None,chaos=None,pilot=None,min_repetitions=5):
    if target_level=="E5":
        return finalize_e5(records,min_repetitions)
    if target_level=="E6":
        return finalize_e6(records,large_repo or [],chaos or [],min_repetitions)
    if target_level=="E7":
        return finalize_e7(records,large_repo or [],chaos or [],pilot,min_repetitions)
    raise ValueError("unsupported target level")
