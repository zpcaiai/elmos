from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from uuid import uuid4
from datetime import datetime, timezone

app = FastAPI(title="elmos-campaign-api", version="3.2.0")
campaigns = {}

class CampaignCreate(BaseModel):
    name: str
    mode: str
    systems: list[str]
    suite_name: str
    suite_version: str
    verifier_pack_version: str
    repositories: list[str]
    repetitions: int = 5
    target_evidence_level: str = "E5"

class Transition(BaseModel):
    state: str
    evidence_ids: list[str] = []
    note: str | None = None

@app.post("/v1/campaigns")
def create(req: CampaignCreate):
    cid = str(uuid4())
    campaigns[cid] = {
        "id": cid, "state": "DRAFT",
        "created_at": datetime.now(timezone.utc).isoformat(),
        **req.model_dump()
    }
    return campaigns[cid]

@app.get("/v1/campaigns/{cid}")
def get(cid: str):
    if cid not in campaigns:
        raise HTTPException(404, "campaign not found")
    return campaigns[cid]

@app.post("/v1/campaigns/{cid}/transition")
def transition(cid: str, req: Transition):
    if cid not in campaigns:
        raise HTTPException(404, "campaign not found")
    campaigns[cid]["state"] = req.state
    campaigns[cid]["last_evidence_ids"] = req.evidence_ids
    campaigns[cid]["note"] = req.note
    campaigns[cid]["updated_at"] = datetime.now(timezone.utc).isoformat()
    return campaigns[cid]
