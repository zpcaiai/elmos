class JobAttemptRepository:
    def __init__(self,connection_factory):
        self.connection_factory=connection_factory

    def start(self,job_id,attempt,worker_id):
        with self.connection_factory() as conn:
            row=conn.execute(
              "insert into benchmark_job_attempt(job_id,attempt,worker_id,status) values(%s,%s,%s,'RUNNING') returning id",
              (job_id,attempt,worker_id)).fetchone()
            conn.commit()
        return row[0]

    def finish(self,attempt_id,status,evidence_uri=None,error=None):
        with self.connection_factory() as conn:
            conn.execute(
              "update benchmark_job_attempt set status=%s,evidence_uri=%s,error=%s,completed_at=now() where id=%s",
              (status,evidence_uri,error,attempt_id))
            conn.commit()
