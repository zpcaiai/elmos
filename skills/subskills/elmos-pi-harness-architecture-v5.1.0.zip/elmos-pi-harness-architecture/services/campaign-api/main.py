from services.campaign_api.dependencies import build_services
from services.campaign_api.app_factory import create_app

services=build_services()
app=create_app(services["campaign_service"])
