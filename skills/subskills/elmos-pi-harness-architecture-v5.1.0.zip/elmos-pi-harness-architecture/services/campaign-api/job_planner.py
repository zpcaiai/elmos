from hashlib import sha256
import json, uuid

def stable_job_key(campaign_id, system, repo_revision, task_case_id, repetition):
    raw=json.dumps({
        "campaign_id":campaign_id,"system":system,"repo_revision":repo_revision,
        "task_case_id":task_case_id,"repetition":repetition
    },sort_keys=True).encode()
    return sha256(raw).hexdigest()

def plan_jobs(campaign, repo_revisions, task_case_ids):
    jobs=[]
    for system in campaign["systems"]:
        for revision in repo_revisions:
            for task in task_case_ids:
                for repetition in range(int(campaign["repetitions"])):
                    jobs.append({
                        "id":str(uuid.uuid4()),
                        "idempotency_key":stable_job_key(campaign["id"],system,revision,task,repetition),
                        "campaign_id":campaign["id"],"system_name":system,
                        "repo_revision":revision,"task_case_id":task,
                        "repetition":repetition,"status":"QUEUED"
                    })
    return jobs
