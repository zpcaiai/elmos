class JobRepositoryV35:
    def __init__(self, connection_factory):
        self.connection_factory=connection_factory

    def mark_running(self,job_id,worker_id):
        with self.connection_factory() as conn:
            row=conn.execute(
              '''update benchmark_execution_job set status='RUNNING',updated_at=now()
                 where id=%s and lease_owner=%s and status='LEASED' returning id''',
              (job_id,worker_id)).fetchone()
            conn.commit()
        return bool(row)

    def mark_failure(self,job_id,worker_id,status,error):
        if status not in {"RETRYABLE","FAILED","ABANDONED"}:
            raise ValueError("invalid failure status")
        with self.connection_factory() as conn:
            row=conn.execute(
              '''update benchmark_execution_job
                 set status=%s,last_error=%s,lease_expires_at=null,updated_at=now()
                 where id=%s and lease_owner=%s returning id''',
              (status,error,job_id,worker_id)).fetchone()
            conn.commit()
        return bool(row)

    def requeue(self,job_id):
        with self.connection_factory() as conn:
            row=conn.execute(
              '''update benchmark_execution_job
                 set status='QUEUED',lease_owner=null,lease_expires_at=null,updated_at=now()
                 where id=%s and status='RETRYABLE' returning id''',(job_id,)).fetchone()
            conn.commit()
        return bool(row)
