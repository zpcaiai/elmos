from fastapi import APIRouter,HTTPException
from pydantic import BaseModel

class RetryRequest(BaseModel):
    error_code:str
    budget_remaining_usd:float|None=None
    elapsed_seconds:float|None=None
    max_elapsed_seconds:float|None=None

def build_attempt_router(job_repo,state_repo,retry_policy):
    router=APIRouter()
    @router.post("/v1/jobs/{job_id}/retry")
    def retry(job_id:str,req:RetryRequest):
        job=job_repo.get(job_id) if hasattr(job_repo,"get") else None
        if not job: raise HTTPException(404,"job not found")
        decision=retry_policy(req.error_code,job.get("attempt",0),
          budget_remaining_usd=req.budget_remaining_usd,
          elapsed_seconds=req.elapsed_seconds,max_elapsed_seconds=req.max_elapsed_seconds)
        if decision.retry: state_repo.requeue(job_id)
        return decision.__dict__
    return router
