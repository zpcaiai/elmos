RETRYABLE_ERRORS={
  "worker_crash","provider_timeout","provider_rate_limit","sandbox_lost",
  "transient_network","lease_expired"
}

def classify_failure(error_code,attempt,max_attempts=3):
    if attempt>=max_attempts:
        return "FAILED"
    if error_code in RETRYABLE_ERRORS:
        return "RETRYABLE"
    return "FAILED"
