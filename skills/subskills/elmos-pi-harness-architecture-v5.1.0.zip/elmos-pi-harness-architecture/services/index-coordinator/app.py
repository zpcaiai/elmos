from fastapi import FastAPI
from pydantic import BaseModel
from uuid import uuid4
from elmos_runtime_core.index_partitioner import partition_paths

app = FastAPI(title="elmos-index-coordinator", version="2.3.0")
runs = {}

class IndexRun(BaseModel):
    project_id: str
    revision: str
    changed_paths: list[str]
    max_files_per_shard: int = 500

@app.post("/v1/index-runs")
def create(req: IndexRun):
    rid = str(uuid4())
    shards = partition_paths(req.changed_paths, req.max_files_per_shard)
    for i, s in enumerate(shards):
        s["shard_id"] = f"{rid}:{i}"
        s["status"] = "QUEUED"
    runs[rid] = {
        "id": rid, "project_id": req.project_id, "revision": req.revision,
        "status": "QUEUED", "shards": shards
    }
    return runs[rid]

@app.get("/v1/index-runs/{rid}")
def get(rid: str):
    return runs.get(rid, {"id": rid, "status": "UNKNOWN"})
