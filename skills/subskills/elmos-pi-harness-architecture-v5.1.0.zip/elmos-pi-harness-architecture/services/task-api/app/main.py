from fastapi import FastAPI, HTTPException, Header
from temporalio.client import Client
import os
from elmos_runtime_core.models import TaskCreate
from elmos_runtime_core.db import create_task, get_task

app=FastAPI(title="task-api",version="1.3.0")

@app.get("/livez")
def livez(): return {"status":"ok"}
@app.get("/readyz")
def readyz(): return {"status":"ready"}
@app.get("/version")
def version(): return {"version":"1.3.0"}

@app.post("/v1/tasks")
async def create(req: TaskCreate):
    task_id=create_task({
        "tenant_id":req.tenant_id,
        "project_id":req.project_id,
        "objective":req.objective,
        "model_policy":req.model_policy,
        "max_tokens":req.budgets.max_tokens,
        "max_cost_usd":req.budgets.max_cost_usd
    })
    client=await Client.connect(os.getenv("TEMPORAL_ADDRESS","temporal:7233"))
    await client.start_workflow(
        "RepositoryTaskWorkflow",
        {
          "task_id":task_id,
          "tenant_id":req.tenant_id,
          "project_id":req.project_id,
          "objective":req.objective
        },
        id=f"task-{task_id}",
        task_queue=os.getenv("ELMOS_TASK_QUEUE","elmos-repository-tasks")
    )
    return {"task_id":task_id,"status":"CREATED"}

@app.get("/v1/tasks/{task_id}")
def read_task(task_id: str, x_tenant_id: str = Header(...)):
    row=get_task(task_id,x_tenant_id)
    if not row:
        raise HTTPException(404,"task not found")
    return row
