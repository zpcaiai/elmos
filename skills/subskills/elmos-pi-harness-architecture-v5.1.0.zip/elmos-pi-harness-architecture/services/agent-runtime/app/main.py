from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Any
from elmos_runtime_core.providers import OpenAIProvider, AnthropicProvider, OpenRouterProvider, ProviderError

app=FastAPI(title="agent-runtime",version="1.3.0")

PROVIDERS={
  "openai":OpenAIProvider(),
  "anthropic":AnthropicProvider(),
  "openrouter":OpenRouterProvider(),
}

@app.get("/livez")
def livez(): return {"status":"ok"}
@app.get("/readyz")
def readyz(): return {"status":"ready"}
@app.get("/version")
def version(): return {"version":"1.3.0"}

class AgentRunRequest(BaseModel):
    task_id: str
    provider: str
    model: str
    objective: str
    context: list[dict[str,Any]]=[]
    max_tokens: int=4096

@app.post("/internal/agent/run")
async def run(req: AgentRunRequest):
    p=PROVIDERS.get(req.provider)
    if not p:
        raise HTTPException(400,"unsupported provider")
    messages=[
      {"role":"system","content":"You are an Elmos repository engineering agent. Follow task constraints and produce concise executable engineering actions."},
      {"role":"user","content":req.objective}
    ]
    try:
        result=await p.complete(req.model,messages,max_tokens=req.max_tokens)
    except ProviderError as e:
        raise HTTPException(503,str(e))
    return result.model_dump()
