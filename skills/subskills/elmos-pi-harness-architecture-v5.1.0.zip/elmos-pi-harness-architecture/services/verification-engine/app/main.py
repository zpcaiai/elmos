from fastapi import FastAPI
from pydantic import BaseModel
from pathlib import Path
import subprocess, time

app=FastAPI(title="verification-engine",version="1.3.0")

@app.get("/livez")
def livez(): return {"status":"ok"}
@app.get("/readyz")
def readyz(): return {"status":"ready"}
@app.get("/version")
def version(): return {"version":"1.3.0"}

class Gate(BaseModel):
    name: str
    command: list[str]
    timeout_seconds: int = 600

class VerifyRequest(BaseModel):
    task_id: str
    workspace_path: str
    gates: list[Gate]

@app.post("/internal/verify")
def verify(req: VerifyRequest):
    results=[]
    for gate in req.gates:
        started=time.perf_counter()
        try:
            p=subprocess.run(
                gate.command,cwd=Path(req.workspace_path),capture_output=True,text=True,
                timeout=gate.timeout_seconds
            )
            status="passed" if p.returncode==0 else "failed"
            results.append({
              "gate":gate.name,"status":status,"returncode":p.returncode,
              "duration_ms":int((time.perf_counter()-started)*1000),
              "stdout":p.stdout[-8000:],"stderr":p.stderr[-8000:]
            })
            if status=="failed":
                return {"task_id":req.task_id,"status":"failed","results":results}
        except subprocess.TimeoutExpired as e:
            results.append({"gate":gate.name,"status":"failed","reason":"timeout"})
            return {"task_id":req.task_id,"status":"failed","results":results}
    return {"task_id":req.task_id,"status":"passed","results":results}
