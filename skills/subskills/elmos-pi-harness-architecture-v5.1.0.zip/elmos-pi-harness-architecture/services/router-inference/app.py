from fastapi import FastAPI
from pydantic import BaseModel
from hashlib import sha256
import json

app = FastAPI(title="elmos-router-inference", version="2.3.0")

class RouteRequest(BaseModel):
    eligible_models: list[dict]
    features: dict

@app.post("/route")
def route(req: RouteRequest):
    def score(m):
        quality = float(m.get("historical_success", 0.5))
        cost = float(m.get("relative_cost", 1.0))
        latency = float(m.get("relative_latency", 1.0))
        return quality - 0.15 * cost - 0.10 * latency

    ranked = sorted(req.eligible_models, key=score, reverse=True)
    feature_hash = sha256(json.dumps(req.features, sort_keys=True).encode()).hexdigest()
    return {
        "chosen": ranked[0] if ranked else None,
        "fallback_chain": ranked[1:3],
        "policy_version": "router-inference-v1",
        "feature_hash": feature_hash
    }
