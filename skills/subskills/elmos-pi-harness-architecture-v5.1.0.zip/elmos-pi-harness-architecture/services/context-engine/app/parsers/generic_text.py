import hashlib
from .base import ParserAdapter
from elmos_runtime_core.repo_graph import RepoNode

EXT_LANG={".java":"java",".kt":"kotlin",".go":"go",".rs":"rust",".ts":"typescript",
".tsx":"typescript",".js":"javascript",".jsx":"javascript",".cs":"csharp",".cpp":"cpp",
".c":"c",".h":"c",".hpp":"cpp",".php":"php",".swift":"swift",".m":"objc",".mm":"objc"}

class GenericTextParser(ParserAdapter):
    def supports(self, path): return path.suffix.lower() in EXT_LANG
    def parse(self, root, path):
        rel=str(path.relative_to(root))
        lang=EXT_LANG[path.suffix.lower()]
        fid=hashlib.sha1(f"file:{rel}".encode()).hexdigest()
        return [RepoNode(fid,"file",rel,rel,language=lang)], []
