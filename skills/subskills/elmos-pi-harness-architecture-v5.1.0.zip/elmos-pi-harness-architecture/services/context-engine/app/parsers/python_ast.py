from pathlib import Path
import ast, hashlib
from .base import ParserAdapter
from elmos_runtime_core.repo_graph import RepoNode, RepoEdge

class PythonAstParser(ParserAdapter):
    def supports(self, path): return path.suffix == ".py"

    def parse(self, root, path):
        text = path.read_text(encoding="utf-8", errors="ignore")
        rel = str(path.relative_to(root))
        fid = hashlib.sha1(f"file:{rel}".encode()).hexdigest()
        nodes=[RepoNode(fid,"file",rel,rel,language="python")]
        edges=[]
        try:
            tree=ast.parse(text)
        except SyntaxError:
            return nodes, edges
        for n in ast.walk(tree):
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                qn=f"{rel}:{n.name}"
                sid=hashlib.sha1(f"{qn}:{getattr(n,'lineno',0)}".encode()).hexdigest()
                nodes.append(RepoNode(sid,"class" if isinstance(n,ast.ClassDef) else "function",
                                      qn,rel,getattr(n,"lineno",None),getattr(n,"end_lineno",None),"python"))
                edges.append(RepoEdge(fid,sid,"contains"))
        return nodes, edges
