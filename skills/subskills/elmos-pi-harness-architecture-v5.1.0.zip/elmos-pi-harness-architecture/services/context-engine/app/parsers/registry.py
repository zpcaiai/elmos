from pathlib import Path
from .python_ast import PythonAstParser
from .generic_text import GenericTextParser
from .treesitter_adapter import TreeSitterParser

TREE_SITTER_CONFIG = [
    ("java",{".java"}),
    ("kotlin",{".kt",".kts"}),
    ("typescript",{".ts",".tsx"}),
    ("javascript",{".js",".jsx",".mjs",".cjs"}),
    ("go",{".go"}),
    ("rust",{".rs"}),
    ("csharp",{".cs"}),
    ("cpp",{".cpp",".cc",".cxx",".hpp",".hh",".h"}),
    ("php",{".php"}),
    ("swift",{".swift"}),
    ("objc",{".m",".mm"}),
]

def build_registry(enable_tree_sitter=False):
    parsers=[PythonAstParser()]
    if enable_tree_sitter:
        parsers += [TreeSitterParser(lang,exts) for lang,exts in TREE_SITTER_CONFIG]
    parsers.append(GenericTextParser())
    return parsers
