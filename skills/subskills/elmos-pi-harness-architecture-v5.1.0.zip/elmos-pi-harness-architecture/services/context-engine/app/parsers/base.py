from abc import ABC, abstractmethod

class ParserAdapter(ABC):
    @abstractmethod
    def supports(self, path): ...
    @abstractmethod
    def parse(self, root, path): ...
