from .base import ParserAdapter

class TreeSitterParser(ParserAdapter):
    """Production adapter contract for concrete Tree-sitter grammars."""
    def __init__(self, language, extensions):
        self.language=language
        self.extensions=extensions
    def supports(self, path):
        return path.suffix.lower() in self.extensions
    def parse(self, root, path):
        raise NotImplementedError("Attach concrete grammar and symbol/call extraction")
