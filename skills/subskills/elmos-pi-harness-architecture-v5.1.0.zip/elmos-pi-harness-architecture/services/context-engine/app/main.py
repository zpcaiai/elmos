from fastapi import FastAPI
from pydantic import BaseModel
from pathlib import Path
from .indexer import index_repo

app=FastAPI(title="context-engine",version="1.3.0")

@app.get("/livez")
def livez(): return {"status":"ok"}
@app.get("/readyz")
def readyz(): return {"status":"ready"}
@app.get("/version")
def version(): return {"version":"1.3.0"}

class IndexRequest(BaseModel):
    workspace_path: str

@app.post("/internal/repo/index")
def index(req: IndexRequest):
    nodes=index_repo(Path(req.workspace_path))
    return {"nodes":nodes,"count":len(nodes)}

class ContextRequest(BaseModel):
    task_id: str
    objective: str
    candidates: list[dict] = []
    budget_tokens: int = 16000

@app.post("/internal/context/build")
def context(req: ContextRequest):
    selected=sorted(req.candidates,key=lambda x:x.get("score",0),reverse=True)[:50]
    return {
        "task_id":req.task_id,
        "segments":[{"kind":"task","content":req.objective,"score":1.0},*selected],
        "budget_tokens":req.budget_tokens
    }
