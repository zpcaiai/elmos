from .parsers.python_ast import PythonAstParser
from .parsers.generic_text import GenericTextParser

PARSERS=[PythonAstParser(), GenericTextParser()]
IGNORE_DIRS={".git","node_modules","vendor","dist","build","target",".venv","venv",".idea",".next"}

def index_repo(root):
    nodes, edges = {}, []
    for path in root.rglob("*"):
        if not path.is_file() or any(part in IGNORE_DIRS for part in path.parts):
            continue
        parser=next((p for p in PARSERS if p.supports(path)),None)
        if not parser:
            continue
        try:
            ns, es = parser.parse(root,path)
        except Exception:
            continue
        for n in ns:
            nodes[n.id]=n
        edges.extend(es)
    return list(nodes.values()), edges
