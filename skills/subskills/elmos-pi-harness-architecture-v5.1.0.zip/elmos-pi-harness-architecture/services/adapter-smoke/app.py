from fastapi import FastAPI
from pydantic import BaseModel
from benchmark.smoke_runner import smoke

app = FastAPI(title="elmos-adapter-smoke", version="3.2.0")

class SmokeRequest(BaseModel):
    system: str
    repo_path: str
    revision: str
    task: str = "Inspect the repository and summarize it briefly."

@app.post("/v1/smoke")
def run(req: SmokeRequest):
    return smoke(req.system, req.repo_path, req.revision, req.task)
