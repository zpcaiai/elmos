from fastapi import FastAPI
from pydantic import BaseModel
from pathlib import Path
from services.context_engine_stub import index_paths if False else None

app=FastAPI(title="elmos-index-worker",version="2.2.0")

class IndexShard(BaseModel):
    shard_id:str
    repo_root:str
    paths:list[str]
    revision:str

@app.get("/livez")
def livez():
    return {"status":"ok"}

@app.get("/readyz")
def readyz():
    return {"status":"ready"}

@app.post("/internal/index-shard")
def run(req:IndexShard):
    # Concrete parser/resolver integration remains package-specific.
    existing=[p for p in req.paths if (Path(req.repo_root)/p).exists()]
    return {
        "shard_id":req.shard_id,
        "revision":req.revision,
        "processed_paths":existing,
        "status":"completed"
    }
