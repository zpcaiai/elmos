from fastapi import FastAPI
from pydantic import BaseModel
from uuid import uuid4
from datetime import datetime, timezone

app=FastAPI(title="elmos-continuous-benchmark",version="2.2.0")
runs={}

class Trigger(BaseModel):
    suite:str
    baseline_version:str|None=None
    candidate_version:str

@app.post("/v1/runs")
def trigger(req:Trigger):
    rid=str(uuid4())
    runs[rid]={
      "id":rid,"suite":req.suite,"baseline_version":req.baseline_version,
      "candidate_version":req.candidate_version,"status":"QUEUED",
      "created_at":datetime.now(timezone.utc).isoformat()
    }
    return runs[rid]

@app.get("/v1/runs/{rid}")
def get(rid:str):
    return runs.get(rid,{"id":rid,"status":"UNKNOWN"})
