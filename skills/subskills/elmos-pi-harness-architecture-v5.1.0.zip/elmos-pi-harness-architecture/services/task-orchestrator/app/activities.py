from temporalio import activity
from elmos_runtime_core.db import update_task_status

@activity.defn(name="update_status")
async def update_status_activity(payload: dict):
    update_task_status(payload["task_id"],payload["tenant_id"],payload["status"])
    return payload["status"]

@activity.defn(name="plan_task")
async def plan_task(payload: dict):
    return {
        "steps":[
            {"id":"context","action":"build_context"},
            {"id":"execute","action":"run_agent"},
            {"id":"verify","action":"verify"}
        ]
    }

@activity.defn(name="run_agent")
async def run_agent_activity(payload: dict):
    # Integration point for agent-runtime service.
    return {"status":"completed","changes":[]}

@activity.defn(name="verify")
async def verify_activity(payload: dict):
    # Integration point for verification-engine.
    return {"status":"passed","gates":[{"gate":"contract","status":"passed"}]}
