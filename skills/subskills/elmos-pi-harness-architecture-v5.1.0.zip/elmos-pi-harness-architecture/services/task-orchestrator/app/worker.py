import asyncio, os
from temporalio.client import Client
from temporalio.worker import Worker
from .workflows import RepositoryTaskWorkflow
from .activities import update_status_activity, plan_task, run_agent_activity, verify_activity

async def main():
    client=await Client.connect(os.getenv("TEMPORAL_ADDRESS","temporal:7233"))
    worker=Worker(
        client,
        task_queue=os.getenv("ELMOS_TASK_QUEUE","elmos-repository-tasks"),
        workflows=[RepositoryTaskWorkflow],
        activities=[update_status_activity,plan_task,run_agent_activity,verify_activity]
    )
    await worker.run()

if __name__=="__main__":
    asyncio.run(main())
