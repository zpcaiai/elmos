from fastapi import FastAPI
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
from fastapi.responses import Response
import os

SERVICE_NAME = "task-orchestrator"
VERSION = os.getenv("ELMOS_VERSION", "1.2.0")

app = FastAPI(title=SERVICE_NAME, version=VERSION)

@app.get("/livez")
def livez():
    return {"status":"ok","service":SERVICE_NAME}

@app.get("/readyz")
def readyz():
    return {"status":"ready","service":SERVICE_NAME}

@app.get("/version")
def version():
    return {"service":SERVICE_NAME,"version":VERSION}

@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

from pydantic import BaseModel
from typing import Literal

TaskState = Literal["CREATED","QUEUED","PLANNING","RUNNING","VERIFYING","SUCCEEDED","FAILED"]

class AdvanceRequest(BaseModel):
    task_id: str
    state: TaskState

NEXT = {
    "CREATED":"QUEUED",
    "QUEUED":"PLANNING",
    "PLANNING":"RUNNING",
    "RUNNING":"VERIFYING",
    "VERIFYING":"SUCCEEDED",
}

@app.post("/internal/tasks/advance")
def advance(req: AdvanceRequest):
    return {"task_id":req.task_id,"from":req.state,"to":NEXT.get(req.state, req.state)}
