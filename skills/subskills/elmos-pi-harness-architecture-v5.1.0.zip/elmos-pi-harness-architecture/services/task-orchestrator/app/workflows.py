from datetime import timedelta
from temporalio import workflow
from temporalio.common import RetryPolicy

@workflow.defn
class RepositoryTaskWorkflow:
    def __init__(self):
        self.paused=False
        self.cancelled=False

    @workflow.signal
    async def pause(self):
        self.paused=True

    @workflow.signal
    async def resume(self):
        self.paused=False

    @workflow.signal
    async def cancel(self):
        self.cancelled=True

    @workflow.run
    async def run(self, payload: dict):
        retry=RetryPolicy(maximum_attempts=4)

        await workflow.execute_activity(
            "update_status", {"task_id":payload["task_id"],"tenant_id":payload["tenant_id"],"status":"PLANNING"},
            start_to_close_timeout=timedelta(seconds=30), retry_policy=retry
        )

        await workflow.wait_condition(lambda: not self.paused or self.cancelled)
        if self.cancelled:
            await workflow.execute_activity(
                "update_status", {"task_id":payload["task_id"],"tenant_id":payload["tenant_id"],"status":"CANCELLED"},
                start_to_close_timeout=timedelta(seconds=30)
            )
            return {"status":"CANCELLED"}

        plan = await workflow.execute_activity(
            "plan_task", payload, start_to_close_timeout=timedelta(minutes=5), retry_policy=retry
        )

        await workflow.execute_activity(
            "update_status", {"task_id":payload["task_id"],"tenant_id":payload["tenant_id"],"status":"RUNNING"},
            start_to_close_timeout=timedelta(seconds=30)
        )

        execution = await workflow.execute_activity(
            "run_agent", {**payload,"plan":plan},
            start_to_close_timeout=timedelta(minutes=30), retry_policy=retry
        )

        await workflow.execute_activity(
            "update_status", {"task_id":payload["task_id"],"tenant_id":payload["tenant_id"],"status":"VERIFYING"},
            start_to_close_timeout=timedelta(seconds=30)
        )

        verification = await workflow.execute_activity(
            "verify", {**payload,"execution":execution},
            start_to_close_timeout=timedelta(minutes=15), retry_policy=retry
        )

        final="SUCCEEDED" if verification.get("status")=="passed" else "FAILED"
        await workflow.execute_activity(
            "update_status", {"task_id":payload["task_id"],"tenant_id":payload["tenant_id"],"status":final},
            start_to_close_timeout=timedelta(seconds=30)
        )
        return {"status":final,"verification":verification}
