package ai.elmos.resolver;

import java.util.List;
import java.util.Map;

public record ResolverResult(
    List<Map<String,Object>> symbols,
    List<Map<String,Object>> references,
    List<Map<String,Object>> diagnostics
) {}
