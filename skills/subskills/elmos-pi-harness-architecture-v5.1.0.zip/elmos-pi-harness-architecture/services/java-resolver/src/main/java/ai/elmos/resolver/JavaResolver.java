package ai.elmos.resolver;
import java.nio.file.Path;

public final class JavaResolver {
    private final JdtSemanticExtractor extractor = new JdtSemanticExtractor();
    public ResolverResult resolve(Path projectRoot) {
        return extractor.resolve(projectRoot);
    }
}
