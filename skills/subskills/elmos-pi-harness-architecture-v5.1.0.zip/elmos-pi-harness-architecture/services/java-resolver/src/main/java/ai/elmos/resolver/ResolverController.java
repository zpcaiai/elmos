package ai.elmos.resolver;

import org.springframework.web.bind.annotation.*;
import java.nio.file.Path;
import java.util.Map;

@RestController
public class ResolverController {
    private final JavaResolver resolver = new JavaResolver();

    @GetMapping("/health")
    public Map<String,Object> health() {
        return Map.of("status","ok","service","java-resolver","version","1.8.0");
    }

    @PostMapping("/resolve")
    public ResolverResult resolve(@RequestBody Map<String,Object> payload) {
        String projectRoot = String.valueOf(payload.get("project_root"));
        return resolver.resolve(Path.of(projectRoot));
    }
}
