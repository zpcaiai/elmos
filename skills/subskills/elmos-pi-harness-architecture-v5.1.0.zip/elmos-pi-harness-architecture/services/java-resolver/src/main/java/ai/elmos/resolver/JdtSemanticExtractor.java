package ai.elmos.resolver;

import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.compiler.IProblem;
import org.eclipse.jdt.core.dom.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

public final class JdtSemanticExtractor {
    public ResolverResult resolve(Path projectRoot) {
        List<Map<String,Object>> symbols = new ArrayList<>();
        List<Map<String,Object>> refs = new ArrayList<>();
        List<Map<String,Object>> diagnostics = new ArrayList<>();

        try (Stream<Path> paths = Files.walk(projectRoot)) {
            paths.filter(p -> p.toString().endsWith(".java")).forEach(path -> {
                try {
                    String source = Files.readString(path);
                    ASTParser parser = ASTParser.newParser(AST.JLS21);
                    parser.setResolveBindings(true);
                    parser.setBindingsRecovery(true);
                    parser.setSource(source.toCharArray());
                    parser.setKind(ASTParser.K_COMPILATION_UNIT);

                    @SuppressWarnings("unchecked")
                    Map<String,String> options = JavaCore.getOptions();
                    JavaCore.setComplianceOptions(JavaCore.VERSION_17, options);
                    parser.setCompilerOptions(options);

                    CompilationUnit cu = (CompilationUnit) parser.createAST(null);
                    cu.accept(new ASTVisitor() {
                        @Override
                        public boolean visit(TypeDeclaration node) {
                            ITypeBinding b = node.resolveBinding();
                            symbols.add(Map.of(
                                "kind","type",
                                "qualified_name", b == null ? node.getName().getIdentifier() : b.getQualifiedName(),
                                "file",path.toString(),
                                "line",cu.getLineNumber(node.getStartPosition()),
                                "confidence", b == null ? "unresolved" : "compiler_confirmed"
                            ));
                            return true;
                        }

                        @Override
                        public boolean visit(MethodDeclaration node) {
                            IMethodBinding b = node.resolveBinding();
                            String name = b == null ? node.getName().getIdentifier() :
                                b.getDeclaringClass().getQualifiedName() + "#" + b.getName();
                            symbols.add(Map.of(
                                "kind","method",
                                "qualified_name",name,
                                "file",path.toString(),
                                "line",cu.getLineNumber(node.getStartPosition()),
                                "confidence", b == null ? "unresolved" : "compiler_confirmed"
                            ));
                            return true;
                        }

                        @Override
                        public boolean visit(MethodInvocation node) {
                            IMethodBinding b = node.resolveMethodBinding();
                            Map<String,Object> ref = new HashMap<>();
                            ref.put("reference_kind","method_call");
                            ref.put("source_name",node.getName().getIdentifier());
                            ref.put("target_name", b == null ? null :
                                b.getDeclaringClass().getQualifiedName() + "#" + b.getName());
                            ref.put("confidence",b == null ? "unresolved" : "compiler_confirmed");
                            ref.put("file",path.toString());
                            ref.put("line",cu.getLineNumber(node.getStartPosition()));
                            refs.add(ref);
                            return true;
                        }
                    });

                    for (IProblem p : cu.getProblems()) {
                        if (p.isError()) {
                            diagnostics.add(Map.of(
                                "file",path.toString(),
                                "line",p.getSourceLineNumber(),
                                "message",p.getMessage()
                            ));
                        }
                    }
                } catch (Exception e) {
                    diagnostics.add(Map.of("file",path.toString(),"message",e.toString()));
                }
            });
        } catch (Exception e) {
            diagnostics.add(Map.of("project",projectRoot.toString(),"message",e.toString()));
        }

        return new ResolverResult(symbols, refs, diagnostics);
    }
}
