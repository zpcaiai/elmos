import http from "node:http";
import { resolveProject } from "./index.js";

const server = http.createServer(async (req,res) => {
  if (req.method === "GET" && req.url === "/health") {
    res.writeHead(200, {"content-type":"application/json"});
    res.end(JSON.stringify({status:"ok",service:"typescript-resolver",version:"1.8.0"}));
    return;
  }
  if (req.method === "POST" && req.url === "/resolve") {
    let body="";
    for await (const chunk of req) body += chunk;
    const payload = JSON.parse(body || "{}");
    const result = resolveProject(payload.tsconfig_path);
    res.writeHead(200, {"content-type":"application/json"});
    res.end(JSON.stringify(result));
    return;
  }
  res.writeHead(404); res.end();
});

server.listen(Number(process.env.PORT || 8080));
