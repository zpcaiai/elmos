import ts from "typescript";

export function resolveProject(tsconfigPath: string) {
  const configFile = ts.readConfigFile(tsconfigPath, ts.sys.readFile);
  if (configFile.error) throw new Error("Unable to read tsconfig");

  const parsed = ts.parseJsonConfigFileContent(configFile.config, ts.sys, ts.sys.getCurrentDirectory());
  const program = ts.createProgram(parsed.fileNames, parsed.options);
  const checker = program.getTypeChecker();

  const symbols: any[] = [];
  const references: any[] = [];

  for (const sf of program.getSourceFiles()) {
    if (sf.isDeclarationFile) continue;

    function visit(node: ts.Node) {
      const pos = sf.getLineAndCharacterOfPosition(node.getStart());

      const symbol = checker.getSymbolAtLocation(node);
      if (symbol) {
        symbols.push({
          name: checker.symbolToString(symbol),
          file: sf.fileName,
          line: pos.line + 1,
          kind: ts.SyntaxKind[node.kind],
          confidence: "compiler_confirmed"
        });
      }

      if (ts.isCallExpression(node)) {
        const sig = checker.getResolvedSignature(node);
        const decl = sig?.declaration;
        let target: string | undefined;
        if (decl?.name) {
          const targetSymbol = checker.getSymbolAtLocation(decl.name);
          if (targetSymbol) target = checker.symbolToString(targetSymbol);
        }
        references.push({
          source: node.expression.getText(sf),
          target,
          reference_kind: "call",
          file: sf.fileName,
          line: pos.line + 1,
          confidence: target ? "compiler_confirmed" : "unresolved"
        });
      }

      ts.forEachChild(node, visit);
    }
    visit(sf);
  }

  return { symbols, references };
}
