from fastapi import FastAPI
from pydantic import BaseModel
from uuid import uuid4

app=FastAPI(title="elmos-benchmark-scheduler",version="2.0.0")
runs={}

class Run(BaseModel):
    suite:str
    systems:list[str]
    repetitions:int=3
    max_parallel_shards:int=8

@app.post("/v1/benchmark-runs")
def create(req:Run):
    rid=str(uuid4())
    runs[rid]={"id":rid,"status":"QUEUED",**req.model_dump()}
    return runs[rid]

@app.get("/v1/benchmark-runs/{rid}")
def get(rid:str):
    return runs.get(rid,{"id":rid,"status":"UNKNOWN"})

@app.get("/livez")
def livez(): return {"status":"ok"}
@app.get("/readyz")
def readyz(): return {"status":"ready"}
