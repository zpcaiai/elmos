def verify_tool_authority(invocations):
    violations=[i.get("call_id") for i in invocations if i.get("effective_policy_source") != "environment_owner_intersection"]
    return {"valid": not violations, "violations": violations}

def verify_executor_fencing(events, active_generation):
    stale=[e for e in events if e.get("executor_generation") != active_generation and e.get("accepted")]
    return {"valid": not stale, "stale_accepted": stale}

def verify_workspace_exclusivity(leases):
    owners={}; collisions=[]
    for l in leases:
        key=(l["workspace_id"],l["generation"])
        owner=owners.setdefault(key,l["owner_execution_id"])
        if owner != l["owner_execution_id"]: collisions.append(key)
    return {"valid": not collisions, "collisions": collisions}
