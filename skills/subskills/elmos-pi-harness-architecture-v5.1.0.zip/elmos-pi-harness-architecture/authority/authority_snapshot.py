from dataclasses import dataclass

@dataclass(frozen=True)
class AuthoritySnapshot:
    authority_owner_id: str
    environment_id: str
    permission_profile_version: str
    allowed_capabilities: frozenset[str]
    denied_capabilities: frozenset[str]
    sandbox_overrides: dict

def effective_capabilities(snapshot, upper_policy):
    allowed = set(snapshot.allowed_capabilities) & set(upper_policy.get("allowed", []))
    denied = set(snapshot.denied_capabilities) | set(upper_policy.get("denied", []))
    return sorted(allowed - denied)
