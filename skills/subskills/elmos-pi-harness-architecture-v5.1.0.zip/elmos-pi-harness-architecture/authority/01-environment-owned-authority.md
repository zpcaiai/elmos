# Environment-Owned Authority

Canonical flow:

`ToolInvocation -> EnvironmentRef -> AuthoritySnapshot -> upper policy intersection -> EffectivePolicy`

Rules:
- MCP servers retain owner permission profiles
- authority is captured when runtime/server attachment is published
- unresolved authority fails closed
- refresh/reconnect reuses the owner environment's authority, never thread-global permissions
- session resume restores environment-level sandbox overrides
- switching agents never widens authority
