def resolve(invocation, environment_registry, authority_registry, upper_policy):
    env = environment_registry.get(invocation["environment_id"])
    if env is None:
        return {"allowed": False, "reason": "environment_not_found"}
    snapshot = authority_registry.get(invocation["authority_snapshot_id"])
    if snapshot is None:
        return {"allowed": False, "reason": "authority_snapshot_unresolved"}
    if snapshot.environment_id != env.environment_id:
        return {"allowed": False, "reason": "authority_environment_mismatch"}
    effective = set(snapshot.allowed_capabilities) & set(upper_policy.get("allowed", []))
    effective -= set(snapshot.denied_capabilities)
    effective -= set(upper_policy.get("denied", []))
    required = set(invocation.get("required_capabilities", []))
    if not required.issubset(effective):
        return {"allowed": False, "reason": "capability_denied", "missing": sorted(required - effective)}
    return {
        "allowed": True,
        "effective_capabilities": sorted(effective),
        "authority_owner_id": snapshot.authority_owner_id,
        "environment_id": snapshot.environment_id,
        "permission_profile_version": snapshot.permission_profile_version
    }
