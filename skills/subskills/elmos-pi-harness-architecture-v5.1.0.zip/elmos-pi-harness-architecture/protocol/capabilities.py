from dataclasses import dataclass
@dataclass(frozen=True)
class ProtocolCapabilities:
    history_mode: str
    pagination: bool
    typed_tool_result: bool
    schema_dialect: str
    consistency_model: str
    protocol_version: str
    supports_active_turn_lookup: bool = False
