def negotiate(client, server):
    return {
        "history_mode": server.history_mode if server.history_mode in {"Legacy","Paginated"} else "Legacy",
        "pagination": bool(client.pagination and server.pagination),
        "typed_tool_result": bool(client.typed_tool_result and server.typed_tool_result),
        "schema_dialect": server.schema_dialect,
        "consistency_model": server.consistency_model,
        "protocol_version": server.protocol_version,
        "supports_active_turn_lookup": bool(client.supports_active_turn_lookup and server.supports_active_turn_lookup)
    }
