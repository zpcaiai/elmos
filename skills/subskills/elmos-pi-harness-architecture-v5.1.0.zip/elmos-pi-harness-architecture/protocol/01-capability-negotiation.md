# Protocol Capability Negotiation
Adapters negotiate historyMode, pagination, typedToolResult, schemaDialect,
consistencyModel, protocolVersion and active-turn lookup support.
Provider transport shapes must not leak into orchestration.
