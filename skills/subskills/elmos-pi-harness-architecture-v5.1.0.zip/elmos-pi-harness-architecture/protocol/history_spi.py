def locate_active_turn(capabilities, paginated_lookup, legacy_history):
    if capabilities.get("history_mode") == "Paginated" and capabilities.get("supports_active_turn_lookup"):
        return paginated_lookup()
    return legacy_history.get("active_turn")
