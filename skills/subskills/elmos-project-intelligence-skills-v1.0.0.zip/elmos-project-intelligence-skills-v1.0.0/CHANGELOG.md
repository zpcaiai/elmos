# Changelog

## 1.0.0 — 2026-08-19

- 首次发布 44 个 Elmos Project Intelligence Studio Skills。
- 增加 14 个实施批次、440 条任务和 218 个验收场景。
- 增加在线代码阅读、架构/流程/数据分析、55+ 图表类型、架构文档、PPT、报告包和证据化问答。
- 增加增量缓存、长任务恢复、Artifact 三方合并、Git PR、RBAC、审计、私有化部署和 E1–E5 认证。
- 增加系统 wall-clock ETA P50/P90、Token/计算/存储成本与人工审核量分离模型。
- 提供 Codex/Claude Code 双目标安装、结构校验、安装模拟和打包脚本。
