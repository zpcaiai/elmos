# Split Batch Packages

- Batch 11 — `product-strategy-boundaries` — `elmos-batch-11-product-strategy-boundaries-v2.0.0.zip`
- Batch 12 — `spring-golden-route-contract` — `elmos-batch-12-spring-golden-route-contract-v2.0.0.zip`
- Batch 13 — `repository-scale-standard` — `elmos-batch-13-repository-scale-standard-v2.0.0.zip`
- Batch 14 — `intake-eligibility-estimation` — `elmos-batch-14-intake-eligibility-estimation-v2.0.0.zip`
- Batch 15 — `baseline-repository-intelligence` — `elmos-batch-15-baseline-repository-intelligence-v2.0.0.zip`
- Batch 16 — `planning-deterministic-transformation` — `elmos-batch-16-planning-deterministic-transformation-v2.0.0.zip`
- Batch 17 — `agent-repair-durable-safety` — `elmos-batch-17-agent-repair-durable-safety-v2.0.0.zip`
- Batch 18 — `differential-verification-proof` — `elmos-batch-18-differential-verification-proof-v2.0.0.zip`
- Batch 19 — `data-evidence-observability-economics` — `elmos-batch-19-data-evidence-observability-economics-v2.0.0.zip`
- Batch 20 — `benchmark-certification-l3` — `elmos-batch-20-benchmark-certification-l3-v2.0.0.zip`
- Batch 21 — `commercial-skus-pricing-pilots` — `elmos-batch-21-commercial-skus-pricing-pilots-v2.0.0.zip`
- Batch 22 — `scale-factory-learning-flywheel` — `elmos-batch-22-scale-factory-learning-flywheel-v2.0.0.zip`
