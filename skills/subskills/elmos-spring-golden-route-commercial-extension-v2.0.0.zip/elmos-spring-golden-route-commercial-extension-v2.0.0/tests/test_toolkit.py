import importlib.util,json,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def load(n):
 s=importlib.util.spec_from_file_location(n,ROOT/'scripts'/f'{n}.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
scale=load('repository_scale');bench=load('validate_benchmark_claim');proof=load('generate_completion_proof');quote=load('estimate_quote')
class ToolkitTests(unittest.TestCase):
 def test_erss_boundaries(self):
  self.assertEqual(scale.erss(0),'S0');self.assertEqual(scale.erss(20000),'S1');self.assertEqual(scale.erss(100000),'S2');self.assertEqual(scale.erss(300000),'S3');self.assertEqual(scale.erss(1000000),'S4');self.assertEqual(scale.erss(3000000),'S5')
 def test_repository_scanner_excludes_generated(self):
  with tempfile.TemporaryDirectory() as td:
   r=Path(td);(r/'src/main/java').mkdir(parents=True);(r/'src/main/java/A.java').write_text('class A {}\n'*10);(r/'target/generated').mkdir(parents=True);(r/'target/generated/X.java').write_text('class X {}\n'*100)
   p=scale.analyze(r);self.assertEqual(p['production_sloc'],10);self.assertEqual(p['migration_relevant_loc'],10)
 def test_valid_benchmark(self):
  x=bench.validate(json.loads((ROOT/'examples/benchmark-claim-valid.json').read_text()));self.assertTrue(x['valid'],x)
 def test_invalid_benchmark(self):
  x=bench.validate(json.loads((ROOT/'examples/benchmark-claim-invalid.json').read_text()));self.assertFalse(x['valid']);self.assertTrue(x['errors'])
 def test_completion_requires_evidence(self):
  x=proof.generate(json.loads((ROOT/'examples/run-summary-blocked.json').read_text()));self.assertNotEqual(x['status'],'certified');self.assertEqual(x['unknown_count'],1)
 def test_completion_pass(self):
  x=proof.generate(json.loads((ROOT/'examples/run-summary-pass.json').read_text()));self.assertEqual(x['status'],'certified')
 def test_quote_grows_with_complexity(self):
  a=quote.estimate({'sku':'pilot','mrloc':100000,'rcs':40,'transformation_surface':.2});b=quote.estimate({'sku':'pilot','mrloc':700000,'rcs':80,'transformation_surface':.5});self.assertGreater(b['total'],a['total'])
if __name__=='__main__':unittest.main()
