# Conversation-to-Batch Traceability

| Problem | Batches |
|---|---|
| OpenRewrite 核心特性 | Foundation F01–F05, Batch 16 |
| OpenCode 核心特性 | Foundation F06–F09, Batch 17/19 |
| Elmos 竞争水平 | Batch 11 |
| Spring 付费 Golden Route | Batch 12, 14–18 |
| 小/中/大仓定义 | Batch 13 |
| >500k/>1M 真实性 | Batch 20/22 |
| Static Skills vs implementation | 所有新增 Skill Production-claim boundary |
| Completion Proof | Batch 18/19 |
| 定价、SOW、付费 Pilot | Batch 21 |
| L1–L2 → L3 | Batch 20/21 |
