# Commercial-grade Architecture

```text
Secure Intake / Immutable Snapshot
             ↓
Eligibility + ERSS/RCS + Assessment
             ↓
Baseline Characterization
             ↓
Spring Repository Knowledge Graph
             ↓
Typed Migration DAG
       ┌─────┼─────┐
       ↓     ↓     ↓
    Recipe  Agent Human
       └─────┼─────┘
             ↓
Semantic Patch + Side-effect Ledger
             ↓
Source / Target Runtime Harness
             ↓
API / DB / Security / MQ Differential
             ↓
Quality Gates + Verification Fixpoint
             ↓
Claim–Evidence Ledger
             ↓
Completion Proof
             ↓
Delivery / Rollback / Customer Acceptance
```

Control Plane 自己掌握 durable orchestration、Permission、Lease/Fencing、Evidence、Cost、Tenant Policy；Parser、Recipe、Harness、Provider 保持 Adapter 可替换。
