# Product and Competitive Positioning

## OpenRewrite / Moderne

核心壁垒是无损语义树、类型感知确定性 Recipe、Spring/Java 现代化、大规模代码搜索和多仓企业 Campaign。Elmos 应以 Adapter 复用或兼容，而不是从零重写全部成熟 Java 语义基础设施。

## OpenCode

核心壁垒是开源多模型 Coding Agent 体验、Primary/Subagent、allow/ask/deny、Skill 懒加载、MCP/LSP/Formatter、CLI/TUI/Desktop/Server。Elmos 应借鉴/兼容其生态，但不要正面争夺通用 Coding Agent 心智。

## Elmos

应定位为 **AI-Native Repository Modernization & Conversion OS**。独有价值是完整仓库转换、长任务恢复、跨语言/框架行为等价、Completion Proof、商业交付和从成功 Patch 到认证 Recipe 的飞轮。
