# High-risk Boundaries

- Moderne Source Available/专有 Recipe 的商业使用和咨询转售权；
- 静态 Skills 数量被误当产品实现；
- Legacy Baseline/私有依赖不可重现；
- Agent 删除测试、降低断言或扩大 tolerance 制造绿色；
- Crash recovery 重放生产副作用；
- 客户 Patch 进入跨客户学习但未获授权；
- 大仓库 Graph/Memory/Context 爆炸；
- Eligibility 低置信度却承诺固定价；
- Roadmap 能力进入市场宣传但无 Evidence。
