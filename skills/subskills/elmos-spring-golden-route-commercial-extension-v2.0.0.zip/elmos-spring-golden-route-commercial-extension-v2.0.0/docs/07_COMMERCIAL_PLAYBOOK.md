# Commercial Playbook

## Assessment SKU

仓库 Profile、Baseline、Eligibility、风险、Route、机器 ETA 和报价选项。它是低风险付费入口，不承诺已经完成迁移。

## Pilot SKU

选择代表性垂直切片，执行完整 Golden Route、staging、rollback、Completion Proof 和客户 UAT。没有付费、签署、Proof、clean-room 任一项，不计商业成功。

## Factory SKU

在 Pilot 通过后扩展到全仓或多仓 Campaign，按 wave 独立部署/回滚/证明。

定价使用 ERSS × RCS × Transformation Surface × Verification Depth × Deployment/SLA/License，并用实际模型/Runner/许可/人工成本校准毛利。纯 LOC 定价不足。
