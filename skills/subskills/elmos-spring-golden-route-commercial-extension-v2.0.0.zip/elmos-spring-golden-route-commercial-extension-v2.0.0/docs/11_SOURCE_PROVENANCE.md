# Source Provenance

- OpenRewrite foundation snapshot: `4bc18536d99bb86f1ba0f353643de72ef56dd165` on `main`, core Apache-2.0。
- OpenCode foundation snapshot: `ba72a6ff2b62aaf614b8e745193e86a51be6142c` on `dev`, MIT。
- OpenRewrite/Moderne commercial Recipe usage must follow current official licensing and specific commercial agreements; this package defaults unknown rights to deny。
- Spring target example is dated 2026-08-21; exact target versions must remain in certified Target Profile Registry。
- Existing Elmos validation reports prove static package/schema/installer consistency only and explicitly do not prove target repository workflows, sandboxes, real model calls, customer migrations or production certification。
