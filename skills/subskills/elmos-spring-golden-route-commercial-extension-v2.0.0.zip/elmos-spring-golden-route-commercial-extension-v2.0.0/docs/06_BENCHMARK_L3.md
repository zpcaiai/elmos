# Benchmark and L3 Gate

L3 硬门：≥3 个独立付费客户；≥20 个 unseen accepted repos；S1 成功≥5、S2≥7、Large+≥5；>500k audited MRLOC 成功≥3；>1M≥1；mandatory unknown=0；rollback 与 clean-room repeatability 通过；失败留在分母。

No-Cheating：generated/vendor 不计、branch/fork 不独立、不得隐含人工预修、不得删失败分母、不得 skip/disable mandatory tests、不得让 Agent 读取 holdout、公开 Claim 只能来自签名 manifest/Proof。

运行：

```bash
python3 scripts/validate_benchmark_claim.py examples/benchmark-claim-valid.json
```
