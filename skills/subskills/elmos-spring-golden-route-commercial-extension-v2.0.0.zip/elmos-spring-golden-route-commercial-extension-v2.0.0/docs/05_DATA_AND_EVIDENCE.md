# Data, Evidence and Completion

生产数据层至少包含 Tenant、Project、Repository、Snapshot、Profile、Run、Plan Node、Event、Model Call、Recipe Execution、Tool Execution、Side-effect Ledger、Semantic Patch、Verification Result、Evidence Artifact、Claim、Proof、Quote、Pilot、Benchmark Case 和 Cost Ledger。

所有 PASS 由 Claim–Evidence Ledger 计算。Build success 不能自动等于迁移完成；waiver 不等于 pass；没有 Evidence 的 mandatory claim 必须是 unknown。大 Artifact 进入 CAS/Object Storage，PostgreSQL 保存索引、状态、版本和哈希。
