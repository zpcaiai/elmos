# Implementation Roadmap

1. **Wave 0：产品、Route、许可边界** — Batch 11–12。
2. **Wave 1：可销售 Assessment** — Batch 13–15 的 intake/profile/baseline/eligibility。
3. **Wave 2：确定性迁移内核** — Batch 16，OpenRewrite Adapter + Elmos Native 高频 Recipe。
4. **Wave 3：Durable Repair 与 Verification** — Batch 17–19。
5. **Wave 4：三个独立付费 Pilot** — Batch 21。
6. **Wave 5：大型仓库与 L3** — Batch 20/22。

在 Spring L3 前，应限制无关语言/路线横向扩张；新增路线不得复用 Spring 的 Completion Proof 或 Benchmark Claim。
