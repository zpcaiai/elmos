# Spring Golden Route v1

## Certified lane

首版冻结 Maven multi-module、Spring MVC、Security、Data/JPA/Hibernate、PostgreSQL/MySQL、Flyway/Liquibase，可选 Redis/Kafka。源版本范围与目标 exact patch 由 Route Contract/Target Profile 管理，不由模型自由选择。

示例 Profile 冻结 Java 21 + Spring Boot 4.0.8。它是 2026-08-21 的示例认证 Lane，不是永久“最新版本”。生产 Target Profile 必须经过 corpus、startup、differential 和 security certification。

## Phases

Eligibility → Baseline → Intelligence → Typed DAG → Deterministic Transformation → Compile-driven Repair → Source/Target Differential → Quality Gates → Verification Fixpoint → Completion Proof → Delivery/Rollback。
