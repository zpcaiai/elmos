# Repository Scale and Complexity

MRLOC 只统计第一方生产代码、测试、配置、SQL、构建与迁移脚本；排除 vendor/generated/build outputs/minified/docs。

| ERSS | MRLOC | Label |
|---|---:|---|
| S0 | <20k | Micro |
| S1 | 20k–100k | Small |
| S2 | 100k–300k | Medium |
| S3 | 300k–1M | Large |
| S4 | 1M–3M | Very Large |
| S5 | >3M | Mega |

Strong Large：>500k MRLOC，且 modules≥20、first-party files≥5,000、tests≥2,000、direct dependencies≥100、runtime dimensions≥4。

RCS 100 分由规模25、模块15、依赖15、语言10、框架10、运行10、测试构建10、遗留5 构成。Transformation Surface 和 Semantic Change Count 用于表达真实迁移强度，不能只看 changed LOC。
