#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)";TARGET="${1:-}";PLATFORM="elmos"
[[ -n "$TARGET" ]] || { echo "Usage: $0 /path/to/target --platform elmos|codex|claude|opencode" >&2;exit 2;};shift || true
while [[ $# -gt 0 ]];do case "$1" in --platform) PLATFORM="$2";shift 2;;*) exit 2;;esac;done
case "$PLATFORM" in elmos) DEST="$TARGET/agent-skills/runtime";;codex) DEST="$TARGET/.agents/skills";;claude) DEST="$TARGET/.claude/skills";;opencode) DEST="$TARGET/.opencode/skills";;*) exit 2;;esac
count=0;for d in "$ROOT"/skills/*;do name="$(basename "$d")";if [[ -d "$DEST/$name" ]];then rm -rf "$DEST/$name";count=$((count+1));fi;done;echo "$count skills removed from $DEST"
