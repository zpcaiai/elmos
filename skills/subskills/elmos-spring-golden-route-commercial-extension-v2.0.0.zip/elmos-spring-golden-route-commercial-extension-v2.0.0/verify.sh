#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$ROOT/scripts/validate_package.py"
python3 -m unittest discover -s "$ROOT/tests" -v
python3 "$ROOT/scripts/validate_benchmark_claim.py" "$ROOT/examples/benchmark-claim-valid.json"
if python3 "$ROOT/scripts/validate_benchmark_claim.py" "$ROOT/examples/benchmark-claim-invalid.json" >/dev/null 2>&1;then echo "Invalid benchmark unexpectedly passed" >&2;exit 1;fi
TMP="$(mktemp -d)";trap 'rm -rf "$TMP"' EXIT
"$ROOT/install.sh" "$TMP" --platform codex
"$ROOT/uninstall.sh" "$TMP" --platform codex
echo "PASS: package, tests, benchmark gate and installation smoke tests"
