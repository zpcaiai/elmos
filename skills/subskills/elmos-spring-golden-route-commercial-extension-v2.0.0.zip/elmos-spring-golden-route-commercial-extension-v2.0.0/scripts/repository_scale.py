#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re
from pathlib import Path
from collections import Counter
EXCLUDED={'.git','.hg','.svn','node_modules','vendor','target','build','dist','out','.gradle','.idea','.next','.nuxt','coverage','__pycache__','.venv','venv','bin','obj'}
GENERATED={'generated','gen-src','generated-sources','generated-test-sources','autogen'}
TEST={'test','tests','src/test','spec','specs'}
DOC={'docs','doc','documentation'}
CONFIG={'.xml','.yml','.yaml','.json','.toml','.properties','.sql','.hcl','.tf','.proto','.gradle','.kts','.sh','.ps1'}
LANG={'.java':'java','.kt':'kotlin','.kts':'kotlin','.groovy':'groovy','.py':'python','.cs':'csharp','.ts':'typescript','.tsx':'typescript','.js':'javascript','.jsx':'javascript','.go':'go','.rs':'rust','.cpp':'cpp','.cc':'cpp','.cxx':'cpp','.c':'c','.h':'header','.hpp':'header','.php':'php','.swift':'swift','.m':'objc','.mm':'objcpp','.dart':'dart','.rb':'ruby','.scala':'scala','.vue':'vue','.svelte':'svelte'}
TEXT=set(LANG)|CONFIG|{'.md','.txt','.csv','.graphql','.gql'}
def lines(p):
 try:
  b=p.read_bytes()
  if b'\0' in b[:4096]: return 0
  return b.count(b'\n')+(1 if b and not b.endswith(b'\n') else 0)
 except OSError:return 0
def has(rel,hints):
 low=rel.lower().replace('\\','/');parts=set(low.split('/'));return any(h in low or h in parts for h in hints)
def category(p,root):
 rel=str(p.relative_to(root)).replace('\\','/');parts=set(rel.lower().split('/'))
 if parts&EXCLUDED:return 'excluded'
 if has(rel,GENERATED):return 'generated'
 if has(rel,DOC) or p.suffix.lower() in {'.md','.txt'}:return 'docs'
 if has(rel,TEST):return 'test'
 if p.suffix.lower() in CONFIG or p.name in {'pom.xml','Dockerfile','Makefile','Jenkinsfile'}:return 'config'
 if p.suffix.lower() in LANG:return 'production'
 return 'other'
def erss(v):
 return 'S0' if v<20000 else 'S1' if v<100000 else 'S2' if v<300000 else 'S3' if v<1000000 else 'S4' if v<3000000 else 'S5'
def band(v,bands):
 out=0
 for t,s in bands:
  if v>=t:out=s
 return out
def rcs(mrloc,modules,deps,languages,frameworks,runtime,tests,build_minutes,legacy):
 d={}
 d['scale']=band(mrloc,[(0,2),(20000,5),(100000,10),(300000,15),(500000,20),(1000000,25)])
 d['module_graph']=band(modules,[(0,1),(2,2),(6,5),(21,8),(51,12),(101,15)])
 d['dependency_graph']=band(deps,[(0,1),(50,4),(100,7),(250,10),(500,13),(1000,15)])
 d['languages']=min(10,max(1,languages*2));d['frameworks']=min(10,frameworks);d['runtime_topology']=min(10,runtime)
 d['tests_build']=min(10,band(tests,[(0,1),(500,3),(1500,5),(5000,7),(10000,9)])+band(build_minutes,[(0,0),(5,1),(15,2),(45,3)]));d['legacy']=min(5,legacy)
 return round(sum(d.values()),2),d
def maven_modules(root):return len({str(p.parent.relative_to(root)) for p in root.rglob('pom.xml') if not set(p.relative_to(root).parts)&EXCLUDED})
def deps(root):
 n=0;rx=re.compile(r'<dependency(?:\s|>)')
 for p in root.rglob('pom.xml'):
  if set(p.relative_to(root).parts)&EXCLUDED:continue
  try:n+=len(rx.findall(p.read_text(encoding='utf-8',errors='ignore')))
  except OSError:pass
 return n
def analyze(root,repository_id='local-repository',snapshot_id='local-snapshot',frameworks=0,runtime=0,test_count=0,build_minutes=0,legacy=0):
 root=root.resolve();c=Counter();f=Counter();langs=Counter()
 for p in root.rglob('*'):
  if not p.is_file() or set(p.relative_to(root).parts)&EXCLUDED:continue
  if p.suffix.lower() not in TEXT and p.name not in {'pom.xml','Dockerfile','Makefile','Jenkinsfile'}:continue
  cat=category(p,root);n=lines(p);c['gross_loc']+=n;f['gross']+=1
  if cat in {'excluded','generated','docs'}:c[f'{cat}_loc']+=n;f[cat]+=1;continue
  c['first_party_loc']+=n;f['first_party']+=1;c[f'{cat}_loc']+=n;f[cat]+=1
  if cat in {'production','test','config'}:c['mrloc']+=n
  if cat in {'production','test'}:langs[LANG.get(p.suffix.lower(),'other')]+=n
 mods=maven_modules(root);dep=deps(root);tc=test_count or f['test'];score,dims=rcs(c['mrloc'],mods,dep,len(langs),frameworks,runtime,tc,build_minutes,legacy)
 return {'profile_version':'1.0.0','repository_id':repository_id,'snapshot_id':snapshot_id,'gross_loc':c['gross_loc'],'first_party_loc':c['first_party_loc'],'production_sloc':c['production_loc'],'test_sloc':c['test_loc'],'config_sloc':c['config_loc'],'migration_relevant_loc':c['mrloc'],'erss':erss(c['mrloc']),'rcs':score,'rcs_dimensions':dims,'modules':mods,'first_party_files':f['first_party'],'direct_dependencies':dep,'transitive_dependencies':0,'tests':tc,'framework_families':frameworks,'runtime_integrations':runtime,'languages':dict(langs),'transformation_surface_estimate':None,'audit_status':'provisional','source_family_id':repository_id,'independent_repository_id':repository_id}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('repository',type=Path);ap.add_argument('--repository-id',default='local-repository');ap.add_argument('--snapshot-id',default='local-snapshot');ap.add_argument('--framework-families',type=int,default=0);ap.add_argument('--runtime-integrations',type=int,default=0);ap.add_argument('--tests',type=int,default=0);ap.add_argument('--build-minutes',type=float,default=0);ap.add_argument('--legacy-risk-count',type=int,default=0);ap.add_argument('--output',type=Path);a=ap.parse_args()
 if not a.repository.is_dir():raise SystemExit('repository must be a directory')
 out=analyze(a.repository,a.repository_id,a.snapshot_id,a.framework_families,a.runtime_integrations,a.tests,a.build_minutes,a.legacy_risk_count);text=json.dumps(out,ensure_ascii=False,indent=2)
 if a.output:a.output.write_text(text+'\n',encoding='utf-8')
 else:print(text)
if __name__=='__main__':main()
