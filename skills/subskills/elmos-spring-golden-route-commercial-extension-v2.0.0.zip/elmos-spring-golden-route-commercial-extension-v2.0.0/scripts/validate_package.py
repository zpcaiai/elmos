#!/usr/bin/env python3
from __future__ import annotations
import json,re,sys
from pathlib import Path
from jsonschema import Draft202012Validator
root=Path(__file__).resolve().parents[1];errors=[];m=json.loads((root/'manifest/package.json').read_text(encoding='utf-8'));rx=re.compile(r'^[a-z0-9]+(-[a-z0-9]+)*$');seen=set()
for s in m['skills']:
 p=root/s['path']
 if not p.exists():errors.append(f'missing skill: {p}');continue
 t=p.read_text(encoding='utf-8');n=re.search(r'^name:\s*(.+)$',t,re.M)
 if not t.startswith('---\n'):errors.append(f'frontmatter missing: {p}')
 if not n:errors.append(f'name missing: {p}');continue
 name=n.group(1).strip()
 if name!=s['name'] or name!=p.parent.name:errors.append(f'name mismatch: {p}')
 if not rx.fullmatch(name) or len(name)>64:errors.append(f'invalid name: {name}')
 if name in seen:errors.append(f'duplicate skill: {name}')
 seen.add(name)
 if s['origin']=='commercial-extension':
  for h in ['## Objective','## Required tests','## Required evidence','## Stop, block, or escalate when','## Definition of done','## Production-claim boundary']:
   if h not in t:errors.append(f'{name}: missing {h}')
 c=root/'contracts'/f'{name}.json'
 if not c.exists():errors.append(f'contract missing: {name}')
if len(seen)!=m['skill_count']:errors.append(f'skill count mismatch {len(seen)} != {m["skill_count"]}')
# Contract schemas
schema=json.loads((root/'schemas/skill-contract.schema.json').read_text(encoding='utf-8'));v=Draft202012Validator(schema)
for c in (root/'contracts').glob('*.json'):
 for e in v.iter_errors(json.loads(c.read_text(encoding='utf-8'))):errors.append(f'{c.name}: {e.message}')
# Example schemas
pairs={'repository-profile.json':'repository-profile.schema.json','eligibility-report.json':'eligibility-report.schema.json','target-profile.json':'target-profile.schema.json','evidence-manifest.json':'evidence-manifest.schema.json','completion-proof.json':'completion-proof.schema.json','benchmark-claim-valid.json':'benchmark-claim.schema.json','pricing-quote.json':'pricing-quote.schema.json'}
for ex,sc in pairs.items():
 p=root/'examples'/ex;s=root/'schemas'/sc
 if p.exists() and s.exists():
  vv=Draft202012Validator(json.loads(s.read_text(encoding='utf-8')))
  for e in vv.iter_errors(json.loads(p.read_text(encoding='utf-8'))):errors.append(f'{ex}: {e.message}')
for req in ['database/postgres/001_core.sql','database/postgres/002_execution_evidence.sql','database/postgres/003_commercial_benchmark_rls.sql','workflows/spring-golden-route.yaml','api/openapi.yaml','policies/benchmark-no-cheating.yaml']:
 if not (root/req).exists():errors.append(f'missing required: {req}')
if errors:print('\n'.join(errors));sys.exit(1)
print(f'PASS: {len(seen)} skills; {m["commercial_extension_skill_count"]} commercial extension skills; {m["batch_count"]} batches')
