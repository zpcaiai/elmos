#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from collections import Counter
def validate(claim):
 e=[];cases=claim.get('cases',[])
 if claim.get('paid_independent_customers',0)<3:e.append('paid_independent_customers must be >= 3')
 accepted=[c for c in cases if c.get('accepted_into_denominator')];unseen=[c for c in accepted if c.get('unseen')]
 if len(unseen)<20:e.append(f'unseen accepted repositories must be >=20; got {len(unseen)}')
 ids=[c.get('independent_repository_id') for c in unseen];families=[c.get('source_family_id') for c in unseen]
 if len(set(ids))!=len(ids):e.append('duplicate independent_repository_id')
 if len(set(families))!=len(families):e.append('duplicate source_family_id/fork family')
 success=[c for c in unseen if c.get('outcome')=='success'];cnt=Counter(c.get('erss') for c in success)
 if cnt['S1']<5:e.append(f'S1 successes must be >=5; got {cnt["S1"]}')
 if cnt['S2']<7:e.append(f'S2 successes must be >=7; got {cnt["S2"]}')
 large=sum(cnt[k] for k in ('S3','S4','S5'))
 if large<5:e.append(f'large+ successes must be >=5; got {large}')
 over500=[c for c in success if c.get('mrloc',0)>500000];over1m=[c for c in success if c.get('mrloc',0)>1000000]
 if len(over500)<3:e.append(f'>500k MRLOC successes must be >=3; got {len(over500)}')
 if len(over1m)<1:e.append('>1M MRLOC success required')
 for c in over500:
  if c.get('modules',0)<20 or c.get('first_party_files',0)<5000 or c.get('tests',0)<2000 or c.get('direct_dependencies',0)<100 or c.get('runtime_dimensions',0)<4:e.append(f'{c.get("case_id")}: strong-large complexity requirements failed')
 for c in success:
  if not c.get('mrloc_audited'):e.append(f'{c.get("case_id")}: MRLOC not audited')
  if c.get('completion_status')!='certified':e.append(f'{c.get("case_id")}: not certified')
  if c.get('mandatory_unknown',1)!=0:e.append(f'{c.get("case_id")}: mandatory unknown != 0')
  if not c.get('rollback_verified'):e.append(f'{c.get("case_id")}: rollback not verified')
  if not c.get('clean_room_repeatability'):e.append(f'{c.get("case_id")}: clean-room repeatability missing')
 for c in accepted:
  if c.get('outcome') not in {'success','failed','partial','cancelled','no_go'}:e.append(f'{c.get("case_id")}: invalid denominator outcome')
 return {'valid':not e,'errors':e,'summary':{'accepted':len(accepted),'unseen':len(unseen),'successes':len(success),'s1':cnt['S1'],'s2':cnt['S2'],'large_plus':large,'over_500k':len(over500),'over_1m':len(over1m),'paid_independent_customers':claim.get('paid_independent_customers',0)}}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('claim',type=Path);ap.add_argument('--output',type=Path);a=ap.parse_args();r=validate(json.loads(a.claim.read_text(encoding='utf-8')));t=json.dumps(r,ensure_ascii=False,indent=2)
 if a.output:a.output.write_text(t+'\n',encoding='utf-8')
 else:print(t)
 raise SystemExit(0 if r['valid'] else 1)
if __name__=='__main__':main()
