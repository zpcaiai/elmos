#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,uuid,datetime
from pathlib import Path
RATES={'assessment_base':12000,'pilot_base':35000,'factory_base':80000,'mrloc_per_100k':3500,'rcs_point':350,'surface_100pct':30000,'verification_base':18000,'private_deployment':15000}
def estimate(inp,rates=RATES):
 base=rates[inp['sku']+'_base'];items=[{'code':'BASE','amount':base},{'code':'SCALE','amount':math.ceil(inp['mrloc']/100000)*rates['mrloc_per_100k']},{'code':'COMPLEXITY','amount':round(max(0,inp['rcs']-30)*rates['rcs_point'],2)},{'code':'TRANSFORMATION_SURFACE','amount':round(inp.get('transformation_surface',.2)*rates['surface_100pct'],2)},{'code':'VERIFICATION','amount':round(inp.get('verification_depth',1)*rates['verification_base'],2)}]
 if inp.get('private_deployment'):items.append({'code':'PRIVATE_DEPLOYMENT','amount':rates['private_deployment']})
 return {'quote_version':'1.0.0','quote_id':'quote-'+str(uuid.uuid4()),'sku':inp['sku'],'currency':inp.get('currency','USD'),'inputs':inp,'line_items':items,'total':round(sum(x['amount'] for x in items),2),'confidence':max(.25,min(.95,inp.get('estimate_confidence',.65))),'assumptions':['Illustrative configurable rate card; commercial approval required.','Scope and acceptance contract remain frozen.'],'expires_at':(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(days=30)).isoformat()}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('input',type=Path);ap.add_argument('--output',type=Path);a=ap.parse_args();q=estimate(json.loads(a.input.read_text(encoding='utf-8')));t=json.dumps(q,ensure_ascii=False,indent=2)
 if a.output:a.output.write_text(t+'\n',encoding='utf-8')
 else:print(t)
if __name__=='__main__':main()
