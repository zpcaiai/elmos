#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,hashlib,datetime
from pathlib import Path
def canonical(o):return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def generate(run):
 claims=run.get('mandatory_claims',[]);failed=sum(c.get('status')=='fail' for c in claims);unknown=sum(c.get('status')=='unknown' or not c.get('evidence_refs') for c in claims);rollback=bool(run.get('rollback_verified'));repeat=bool(run.get('clean_room_repeatability'));integrity=run.get('test_integrity_violations',0)==0 and run.get('unowned_changes',0)==0
 status='certified' if failed==0 and unknown==0 and rollback and repeat and integrity else 'failed' if failed else 'blocked' if unknown else 'partial'
 p={'proof_version':'1.0.0','proof_id':run.get('proof_id','proof-'+run['run_id']),'run_id':run['run_id'],'status':status,'mandatory_claims':claims,'optional_claims':run.get('optional_claims',[]),'unknown_count':unknown,'failed_count':failed,'rollback_verified':rollback,'clean_room_repeatability':repeat,'artifact_manifest_sha256':run.get('artifact_manifest_sha256','0'*64),'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expires_at':run.get('expires_at')};p['proof_sha256']=hashlib.sha256(canonical(p)).hexdigest();return p
def md(p):
 x=[f'# Elmos Completion Proof — {p["proof_id"]}','',f'- Run: `{p["run_id"]}`',f'- Status: **{p["status"].upper()}**',f'- Mandatory unknown: {p["unknown_count"]}',f'- Mandatory failed: {p["failed_count"]}',f'- Rollback verified: {p["rollback_verified"]}',f'- Clean-room repeatability: {p["clean_room_repeatability"]}',f'- Proof SHA-256: `{p["proof_sha256"]}`','','## Mandatory claims','']
 x += [f'- **{c.get("status","unknown").upper()}** `{c.get("claim_id")}` — {c.get("description")} — evidence: {", ".join(c.get("evidence_refs",[])) or "NONE"}' for c in p['mandatory_claims']];return '\n'.join(x)+'\n'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('run_summary',type=Path);ap.add_argument('--json-output',type=Path,required=True);ap.add_argument('--md-output',type=Path,required=True);a=ap.parse_args();p=generate(json.loads(a.run_summary.read_text(encoding='utf-8')));a.json_output.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');a.md_output.write_text(md(p),encoding='utf-8');raise SystemExit(0 if p['status']=='certified' else 1)
if __name__=='__main__':main()
