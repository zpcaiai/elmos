-- 001_core.sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE tenants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','deleted')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
  name text NOT NULL, route_contract_version text, created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id,name)
);
CREATE TABLE repositories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
  project_id uuid NOT NULL REFERENCES projects(id), canonical_ref text NOT NULL, source_family_id text,
  created_at timestamptz NOT NULL DEFAULT now(), UNIQUE (tenant_id,canonical_ref)
);
CREATE TABLE repository_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
  repository_id uuid NOT NULL REFERENCES repositories(id), commit_sha text, tree_sha256 text NOT NULL,
  manifest_uri text NOT NULL, manifest_sha256 text NOT NULL,
  status text NOT NULL CHECK (status IN ('creating','ready','failed','deleted')),
  created_at timestamptz NOT NULL DEFAULT now(), UNIQUE (tenant_id,tree_sha256)
);
CREATE TABLE repository_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
  snapshot_id uuid NOT NULL REFERENCES repository_snapshots(id), profile_version text NOT NULL,
  mrloc bigint NOT NULL CHECK (mrloc>=0), erss text NOT NULL CHECK (erss IN ('S0','S1','S2','S3','S4','S5')),
  rcs numeric(5,2) NOT NULL CHECK (rcs BETWEEN 0 AND 100),
  audit_status text NOT NULL CHECK (audit_status IN ('audited','provisional','audit_required')),
  profile jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(snapshot_id,profile_version)
);
CREATE TABLE target_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid REFERENCES tenants(id), profile_key text NOT NULL,
  profile_version text NOT NULL, fingerprint text NOT NULL, profile jsonb NOT NULL,
  certified boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX target_profiles_global_or_tenant_key_idx ON target_profiles
  (COALESCE(tenant_id,'00000000-0000-0000-0000-000000000000'::uuid),profile_key,profile_version);
CREATE TABLE migration_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
  project_id uuid NOT NULL REFERENCES projects(id), snapshot_id uuid NOT NULL REFERENCES repository_snapshots(id),
  target_profile_id uuid NOT NULL REFERENCES target_profiles(id), route_contract_version text NOT NULL,
  acceptance_contract_id text NOT NULL,
  status text NOT NULL CHECK (status IN ('admitted','running','paused','blocked','partial','failed','cancelled','certified')),
  current_phase text, ownership_token bigint NOT NULL DEFAULT 0, owner_id text, lease_expires_at timestamptz,
  admitted_at timestamptz NOT NULL DEFAULT now(), started_at timestamptz, completed_at timestamptz
);
CREATE TABLE migration_plan_nodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
  run_id uuid NOT NULL REFERENCES migration_runs(id), node_key text NOT NULL,
  node_type text NOT NULL CHECK(node_type IN ('recipe','agent','tool','human','verify','delivery')),
  status text NOT NULL CHECK(status IN ('pending','ready','running','waiting','succeeded','failed','blocked','cancelled','unknown')),
  dependencies jsonb NOT NULL DEFAULT '[]'::jsonb, inputs jsonb NOT NULL DEFAULT '{}'::jsonb,
  outputs jsonb NOT NULL DEFAULT '{}'::jsonb, idempotency_key text NOT NULL,
  attempt_count integer NOT NULL DEFAULT 0, started_at timestamptz, settled_at timestamptz,
  UNIQUE(run_id,node_key), UNIQUE(run_id,idempotency_key)
);
CREATE TABLE run_events (
  tenant_id uuid NOT NULL REFERENCES tenants(id), run_id uuid NOT NULL REFERENCES migration_runs(id),
  sequence bigint NOT NULL, event_id uuid NOT NULL DEFAULT gen_random_uuid(), event_type text NOT NULL,
  event_version integer NOT NULL DEFAULT 1, payload jsonb NOT NULL, occurred_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(run_id,sequence), UNIQUE(event_id)
) PARTITION BY HASH (run_id);
CREATE TABLE run_events_p0 PARTITION OF run_events FOR VALUES WITH (MODULUS 4,REMAINDER 0);
CREATE TABLE run_events_p1 PARTITION OF run_events FOR VALUES WITH (MODULUS 4,REMAINDER 1);
CREATE TABLE run_events_p2 PARTITION OF run_events FOR VALUES WITH (MODULUS 4,REMAINDER 2);
CREATE TABLE run_events_p3 PARTITION OF run_events FOR VALUES WITH (MODULUS 4,REMAINDER 3);
CREATE INDEX run_events_tenant_time_idx ON run_events(tenant_id,occurred_at DESC);
CREATE INDEX plan_nodes_run_status_idx ON migration_plan_nodes(run_id,status);
CREATE INDEX profiles_scale_idx ON repository_profiles(erss,rcs);
