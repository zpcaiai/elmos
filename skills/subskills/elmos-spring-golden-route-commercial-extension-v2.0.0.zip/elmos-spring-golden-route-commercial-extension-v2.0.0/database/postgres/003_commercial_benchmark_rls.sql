-- 003_commercial_benchmark_rls.sql
CREATE TABLE commercial_quotes (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 project_id uuid NOT NULL REFERENCES projects(id), quote_version text NOT NULL,
 sku text NOT NULL CHECK(sku IN ('assessment','pilot','factory')), currency text NOT NULL,
 inputs jsonb NOT NULL, line_items jsonb NOT NULL, total numeric(18,2) NOT NULL CHECK(total>=0),
 confidence numeric(5,4) NOT NULL CHECK(confidence BETWEEN 0 AND 1),
 status text NOT NULL CHECK(status IN ('draft','approved','sent','accepted','expired','rejected')),
 expires_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE customer_pilots (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 project_id uuid NOT NULL REFERENCES projects(id), customer_ref text NOT NULL,
 paid boolean NOT NULL DEFAULT false, independent_customer_group text NOT NULL,
 status text NOT NULL CHECK(status IN ('selected','contracted','running','accepted','failed','cancelled')),
 scorecard jsonb NOT NULL DEFAULT '{}'::jsonb, acceptance_evidence_id uuid REFERENCES evidence_artifacts(id),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE benchmark_campaigns (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, policy_version text NOT NULL,
 status text NOT NULL CHECK(status IN ('draft','running','passed','failed','revoked')),
 manifest_uri text, manifest_sha256 text, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE benchmark_cases (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), campaign_id uuid NOT NULL REFERENCES benchmark_campaigns(id),
 independent_repository_id text NOT NULL, source_family_id text NOT NULL, customer_group text,
 snapshot_id uuid REFERENCES repository_snapshots(id), profile_id uuid REFERENCES repository_profiles(id),
 run_id uuid REFERENCES migration_runs(id), unseen boolean NOT NULL, accepted_into_denominator boolean NOT NULL,
 outcome text NOT NULL CHECK(outcome IN ('success','failed','partial','cancelled','no_go')),
 eligible_for_claim boolean NOT NULL DEFAULT false, audit jsonb NOT NULL DEFAULT '{}'::jsonb,
 UNIQUE(campaign_id,independent_repository_id), UNIQUE(campaign_id,source_family_id)
);
CREATE TABLE usage_cost_ledger (
 id bigserial PRIMARY KEY, tenant_id uuid NOT NULL REFERENCES tenants(id), project_id uuid REFERENCES projects(id),
 run_id uuid REFERENCES migration_runs(id), node_id uuid REFERENCES migration_plan_nodes(id),
 cost_type text NOT NULL, quantity numeric(24,6) NOT NULL, unit text NOT NULL,
 unit_price numeric(24,8), currency text, estimated boolean NOT NULL DEFAULT false,
 source_ref text, occurred_at timestamptz NOT NULL DEFAULT now()
);
-- The application must SET LOCAL app.tenant_id at every transaction boundary.
DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY['projects','repositories','repository_snapshots','repository_profiles','migration_runs','migration_plan_nodes','run_events','model_calls','recipe_executions','tool_executions','side_effect_ledger','semantic_patches','verification_results','evidence_artifacts','completion_claims','completion_proofs','commercial_quotes','customer_pilots','usage_cost_ledger'] LOOP
   EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY',t);
   EXECUTE format('CREATE POLICY tenant_isolation_%I ON %I USING (tenant_id = nullif(current_setting(''app.tenant_id'',true),)::uuid) WITH CHECK (tenant_id = nullif(current_setting(app.tenant_id,true),)::uuid)',t,t);
 END LOOP;
END $$;
