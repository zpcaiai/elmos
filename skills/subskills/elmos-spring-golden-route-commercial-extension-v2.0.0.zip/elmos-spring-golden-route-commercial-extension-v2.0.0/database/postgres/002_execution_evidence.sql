-- 002_execution_evidence.sql
CREATE TABLE model_calls (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 run_id uuid NOT NULL REFERENCES migration_runs(id), node_id uuid REFERENCES migration_plan_nodes(id),
 provider text NOT NULL, model text NOT NULL, request_fingerprint text NOT NULL,
 status text NOT NULL CHECK(status IN ('admitted','dispatched','streaming','completed','failed','ambiguous','cancelled')),
 input_tokens bigint, output_tokens bigint, cache_read_tokens bigint, cache_write_tokens bigint,
 estimated_cost numeric(18,6), actual_cost numeric(18,6), started_at timestamptz, completed_at timestamptz
);
CREATE TABLE recipe_executions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 run_id uuid NOT NULL REFERENCES migration_runs(id), node_id uuid REFERENCES migration_plan_nodes(id),
 provider text NOT NULL, recipe_name text NOT NULL, recipe_version text NOT NULL, license_decision_id text NOT NULL,
 cycle integer NOT NULL DEFAULT 1, status text NOT NULL CHECK(status IN ('running','succeeded','failed','blocked')),
 changed_files integer NOT NULL DEFAULT 0, semantic_changes integer NOT NULL DEFAULT 0,
 result_uri text, result_sha256 text, started_at timestamptz NOT NULL DEFAULT now(), completed_at timestamptz
);
CREATE TABLE tool_executions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 run_id uuid NOT NULL REFERENCES migration_runs(id), node_id uuid REFERENCES migration_plan_nodes(id),
 tool_name text NOT NULL, tool_call_id text NOT NULL, input_fingerprint text NOT NULL,
 status text NOT NULL CHECK(status IN ('admitted','authorized','running','succeeded','failed','interrupted','unknown','cancelled')),
 permission_decision jsonb NOT NULL, result_uri text, result_sha256 text, started_at timestamptz, settled_at timestamptz,
 UNIQUE(run_id,tool_call_id)
);
CREATE TABLE side_effect_ledger (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 run_id uuid NOT NULL REFERENCES migration_runs(id), node_id uuid REFERENCES migration_plan_nodes(id),
 idempotency_key text NOT NULL, effect_class text NOT NULL, target_ref text NOT NULL,
 status text NOT NULL CHECK(status IN ('planned','authorized','running','succeeded','failed','interrupted','unknown','reconciled','compensated')),
 external_reference text, reconciliation jsonb, rollback_plan jsonb,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,idempotency_key)
);
CREATE TABLE semantic_patches (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 run_id uuid NOT NULL REFERENCES migration_runs(id), node_id uuid REFERENCES migration_plan_nodes(id),
 executor_type text NOT NULL CHECK(executor_type IN ('recipe','agent','human','tool')), executor_ref text NOT NULL,
 before_tree_sha256 text NOT NULL, after_tree_sha256 text NOT NULL,
 patch_uri text NOT NULL, patch_sha256 text NOT NULL, semantic_summary jsonb NOT NULL,
 owned boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE verification_results (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 run_id uuid NOT NULL REFERENCES migration_runs(id), node_id uuid REFERENCES migration_plan_nodes(id),
 verifier text NOT NULL, scope_key text NOT NULL, mandatory boolean NOT NULL DEFAULT true,
 status text NOT NULL CHECK(status IN ('pass','fail','unknown','waived','running')),
 evidence_uri text, evidence_sha256 text, details jsonb NOT NULL DEFAULT '{}'::jsonb,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(run_id,verifier,scope_key)
);
CREATE TABLE evidence_artifacts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 run_id uuid REFERENCES migration_runs(id), kind text NOT NULL, uri text NOT NULL, sha256 text NOT NULL,
 sensitivity text NOT NULL CHECK(sensitivity IN ('public','internal','confidential','restricted')),
 producer text NOT NULL, schema_version text, metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
 immutable boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now(), deleted_at timestamptz,
 UNIQUE(tenant_id,sha256,uri)
);
CREATE TABLE completion_claims (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 run_id uuid NOT NULL REFERENCES migration_runs(id), claim_key text NOT NULL, description text NOT NULL,
 mandatory boolean NOT NULL DEFAULT true,
 status text NOT NULL CHECK(status IN ('pass','fail','unknown','waived','revoked')),
 waiver jsonb, updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(run_id,claim_key)
);
CREATE TABLE claim_evidence_links (
 claim_id uuid NOT NULL REFERENCES completion_claims(id) ON DELETE CASCADE,
 evidence_id uuid NOT NULL REFERENCES evidence_artifacts(id), relationship text NOT NULL DEFAULT 'supports',
 PRIMARY KEY(claim_id,evidence_id)
);
CREATE TABLE completion_proofs (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 run_id uuid NOT NULL REFERENCES migration_runs(id), proof_version text NOT NULL,
 status text NOT NULL CHECK(status IN ('certified','failed','partial','blocked','unknown','revoked')),
 proof_uri text NOT NULL, proof_sha256 text NOT NULL, artifact_manifest_sha256 text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz, revoked_at timestamptz,
 UNIQUE(run_id,proof_version)
);
CREATE INDEX verification_run_status_idx ON verification_results(run_id,mandatory,status);
CREATE INDEX claims_run_status_idx ON completion_claims(run_id,mandatory,status);
CREATE INDEX evidence_run_kind_idx ON evidence_artifacts(run_id,kind);
CREATE INDEX side_effect_status_idx ON side_effect_ledger(run_id,status);
