# Elmos Spring Golden Route Commercial Skills Package v2.0.0

本包把本次会话以及前一版 OpenRewrite/OpenCode 提炼成果合并成一套商业级实现蓝图。

## Inventory

- **96 new Commercial Skills**；requires `elmos-openrewrite-opencode-skills-v1.0`
- **12 Commercial Batches
- **196 machine-readable contracts**
- **8 JSON Schemas、10 Examples、6 Policies**
- Durable Workflow、OpenAPI、3 个 PostgreSQL/RLS migrations
- 5 个可运行工具：仓库评分、L3 Benchmark 校验、Completion Proof、报价、Package Validator
- Unit/negative/install smoke tests

## Product outcome

```text
Secure Intake → Eligibility/ERSS/RCS → Baseline → Repository Intelligence
→ Typed Migration DAG → Recipe-first → Agent residual repair
→ Durable Tool/Side-effect → Source/Target Differential
→ Verification Fixpoint → Completion Proof → Delivery/Rollback → Paid Acceptance
```

## L3 hard target

- ≥3 independent paid customers
- ≥20 unseen accepted repositories
- S1 successes ≥5; S2 ≥7; Large+ ≥5
- ≥3 successful audited repositories over 500k MRLOC
- ≥1 successful audited repository over 1M MRLOC
- mandatory unknown = 0
- rollback and clean-room repeatability pass
- failures remain in denominator

## Validate

```bash
./verify.sh
```

## Score a repository

```bash
python3 scripts/repository_scale.py /path/to/repo \
  --framework-families 8 --runtime-integrations 10 --build-minutes 25 \
  --output repository-profile.json
```

## Validate a benchmark claim

```bash
python3 scripts/validate_benchmark_claim.py examples/benchmark-claim-valid.json
```

## Generate a Completion Proof

```bash
python3 scripts/generate_completion_proof.py examples/run-summary-pass.json \
  --json-output /tmp/proof.json --md-output /tmp/proof.md
```

## Install

```bash
./install.sh /path/to/elmos --platform elmos
./install.sh /path/to/repo --platform codex
./install.sh /path/to/repo --platform claude
./install.sh /path/to/repo --platform opencode
```

## Recommended implementation order

Batch 11–12 → Batch 13–14 Assessment product → Batch 15–16 deterministic kernel → Batch 17–19 durable verification/evidence → Batch 21 paid pilots → Batch 20/22 L3 certification and scale.

## Critical boundary

Package validation proves only specification/package consistency. It does not prove that an Elmos target repository, customer migration, benchmark, external Provider or production release has implemented or passed these capabilities. Real immutable Evidence is mandatory.
