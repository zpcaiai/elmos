# Source Provenance & Licensing Boundary

Generated: 2026-08-21

- OpenRewrite foundation snapshot: `4bc18536d99bb86f1ba0f353643de72ef56dd165` (`main`), core repository Apache-2.0.
- OpenCode foundation snapshot: `ba72a6ff2b62aaf614b8e745193e86a51be6142c` (`dev`), MIT.
- Moderne Source Available or proprietary Recipe commercial embedding, packaging, consultancy resale or customer-result usage requires the rights stated by the current license/contract. Unknown rights default to deny.
- Spring exact target versions are controlled by a dated, certified Target Profile. `examples/target-profile.json` is a 2026-08-21 example and not an evergreen latest-version promise.
- Existing Elmos static validation reports are treated as package evidence only, not as target-repository implementation, customer migration or production certification evidence.
