# Batch 18: differential-verification-proof

源/目标双运行、API/DB/Security/MQ 差分、Fixpoint 与 Completion Proof。

## Skills

- `ELMOS-GR-057` — `spring-dual-runtime` — 在隔离环境同时运行旧系统和目标系统，并对同一场景提供可比较端点。
- `ELMOS-GR-058` — `spring-api-diff` — 比较 status、headers、body 语义、validation、error shape 和 OpenAPI。
- `ELMOS-GR-059` — `spring-db-diff` — 比较 schema、查询结果、写集合、事务、隔离、锁、retry、rollback 和错误。
- `ELMOS-GR-060` — `spring-security-diff` — 对 anonymous/authenticated/roles、Filter/Method security、CSRF/CORS、JWT/OAuth 做正负差分。
- `ELMOS-GR-061` — `spring-sideeffect-diff` — 比较事件、DLQ/retry、缓存 key/TTL、定时任务和外部调用次数/顺序/契约。
- `ELMOS-GR-062` — `spring-quality-gates` — 在正确性后执行性能 smoke/load、CVE/SBOM、SAST/Secret、配置与可观测性 Gate。
- `ELMOS-GR-063` — `spring-verification-fixpoint` — 在验证失败与 Recipe/Agent Repair 之间循环，直到 mandatory fail/unknown 为零或明确 blocked。
- `ELMOS-GR-064` — `spring-completion-proof` — 把 claims、Evidence、rollback、clean-room、成本和交付 artifact 生成可离线验证证明。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
