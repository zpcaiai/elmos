# Batch 12: spring-golden-route-contract

冻结可报价、可重复、可验收的 Spring Golden Route 产品契约。

## Skills

- `ELMOS-GR-009` — `spring-route-orchestrator` — 编排 Eligibility→Baseline→Intelligence→Plan→Transform→Repair→Verify→Proof→Delivery。
- `ELMOS-GR-010` — `spring-source-profile` — 识别 Java/Spring/Maven/模块/依赖/插件/运行拓扑并保存证据与置信度。
- `ELMOS-GR-011` — `spring-target-profile` — 用认证 Target Profile 锁定 Java、Spring Boot、Framework、Security、Hibernate、Maven 和镜像版本。
- `ELMOS-GR-012` — `spring-maven-multimodule` — 迁移 parent、BOM、plugin management、profiles 和 reactor build。
- `ELMOS-GR-013` — `spring-capability-matrix` — 把 MVC、Security、Data、Batch、Integration、Cloud、Actuator 等能力映射到精确迁移与验证状态。
- `ELMOS-GR-014` — `spring-critical-subroutes` — 为数据/事务、安全、消息、缓存和定时任务建立独立高风险子路线。
- `ELMOS-GR-015` — `spring-unsupported-manager` — 管理反射、字节码、自定义 ClassLoader、私有框架、EJB/JNI 等未认证语义。
- `ELMOS-GR-016` — `spring-delivery-rollback` — 定义 PR、镜像、Migration、Runbook、Evidence、回滚演练和客户接管。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
