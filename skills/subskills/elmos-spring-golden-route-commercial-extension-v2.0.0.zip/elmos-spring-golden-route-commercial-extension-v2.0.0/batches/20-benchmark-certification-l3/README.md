# Batch 20: benchmark-certification-l3

Unseen Repository、No-Cheating、规模门、失败分母、Clean-room 与 L3 Gate。

## Skills

- `ELMOS-GR-073` — `gr-benchmark-corpus` — 建立分层规模、技术组合、风险、holdout 和故障注入的代表性仓库语料。
- `ELMOS-GR-074` — `gr-unseen-policy` — 定义首次接触、无仓库专用预处理、无 holdout 泄漏和家族独立性。
- `ELMOS-GR-075` — `gr-no-cheating` — 自动阻止 generated/vendor 灌水、fork 重复、删失败分母、跳测试、人工预改和伪完成。
- `ELMOS-GR-076` — `gr-size-gate` — 要求 ≥20 unseen；S1≥5、S2≥7、Large+≥5、>500k≥3、>1M≥1。
- `ELMOS-GR-077` — `gr-clean-room` — 从 frozen snapshot 和空白工作区重新运行并比较语义输出、Gate、时间和成本。
- `ELMOS-GR-078` — `gr-failure-denominator` — 所有已接受正式迁移的项目留在分母，区分 Assessment no-go、执行失败、取消与 partial。
- `ELMOS-GR-079` — `gr-l3-gate` — 综合 3 个独立付费客户、20 unseen、规模门、Proof、恢复、重复性与毛利信号。
- `ELMOS-GR-080` — `gr-public-claims` — 对公开 LOC、仓库数、成功率、自动化率、成本和时间声明做 Evidence 认证。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
