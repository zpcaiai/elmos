# Batch 16: planning-deterministic-transformation

Typed DAG、OpenRewrite Adapter、Elmos Native Recipe 与确定性覆盖。

## Skills

- `ELMOS-GR-041` — `spring-migration-dag` — 将迁移拆成 Recipe/Agent/Tool/Human/Verify 节点，声明依赖、权限、副作用、回滚和验收。
- `ELMOS-GR-042` — `spring-openrewrite-adapter` — 通过可替换 SPI 接入 parser、Recipe、DataTable、Diff、统计和错误。
- `ELMOS-GR-043` — `spring-native-recipes` — 独立实现可商业使用的高频 Spring 确定性规则资产。
- `ELMOS-GR-044` — `spring-license-router` — 按许可、能力、质量、成本和客户 entitlement 选择 Native/OpenRewrite/Licensed/Agent。
- `ELMOS-GR-045` — `spring-build-migrator` — 确定性迁移 POM/BOM/plugin/dependency/starter 并验证 convergence。
- `ELMOS-GR-046` — `spring-api-config-migrator` — 迁移 Java API、注解、properties/yaml、starter 和测试配置，输出最小 Diff。
- `ELMOS-GR-047` — `spring-recipe-fixpoint` — 多轮执行直到零语义变化，检测振荡、持续变化和无归因 Diff。
- `ELMOS-GR-048` — `spring-deterministic-share` — 量化并提升 Recipe/编译器/结构化 Tool 自动完成的风险加权比例。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
