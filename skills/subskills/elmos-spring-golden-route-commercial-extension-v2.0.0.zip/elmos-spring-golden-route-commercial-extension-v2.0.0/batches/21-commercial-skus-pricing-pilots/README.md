# Batch 21: commercial-skus-pricing-pilots

Assessment/Pilot/Factory SKU、定价、SOW、客户数据与付费试点。

## Skills

- `ELMOS-GR-081` — `spring-assessment-sku` — 将仓库 Profile、Baseline、Eligibility、风险、路线、ETA 和报价选项包装为固定范围付费产品。
- `ELMOS-GR-082` — `spring-pilot-sku` — 选择代表性服务/垂直切片执行完整 Route、staging、rollback 和 Completion Proof。
- `ELMOS-GR-083` — `spring-factory-sku` — 将已验证 Route 扩展到整个大型仓库或多仓 Campaign。
- `ELMOS-GR-084` — `gr-pricing` — 按 SKU、ERSS、RCS、迁移面、验证深度、部署/SLA、许可和风险计算报价。
- `ELMOS-GR-085` — `gr-sow` — 把支持范围、客户责任、Baseline 历史失败、P0/P1、UAT、Rollback、变更单写成可执行合同数据。
- `ELMOS-GR-086` — `gr-customer-data-ip` — 定义源码、Patch、模型上下文、Recipe 学习、遥测、保留和知识产权边界。
- `ELMOS-GR-087` — `gr-pilot-selection` — 选择有升级预算、测试、代表复杂度、技术 champion 和可控 staging 的首批客户。
- `ELMOS-GR-088` — `gr-pilot-success` — 综合 Proof、客户签署、重复性、确定性率、成本/毛利、人工比例和 Factory 转化。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
