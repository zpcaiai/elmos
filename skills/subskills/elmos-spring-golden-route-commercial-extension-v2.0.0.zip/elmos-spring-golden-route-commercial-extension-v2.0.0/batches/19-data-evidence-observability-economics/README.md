# Batch 19: data-evidence-observability-economics

生产数据模型、Evidence Graph、SLO、成本、ETA、审计与保留。

## Skills

- `ELMOS-GR-065` — `gr-data-model` — 实现多租户、事件化、可恢复、可审计的 PostgreSQL 域模型。
- `ELMOS-GR-066` — `gr-event-catalog` — 定义 intake 到 delivery 的 durable 事件、版本、payload、cursor 和 projection。
- `ELMOS-GR-067` — `gr-evidence-store` — 保存日志、测试、Diff、Trace、图、SBOM、报告等不可变 CAS/Object references。
- `ELMOS-GR-068` — `gr-claim-ledger` — 将每个完成、安全、性能和兼容性声明映射到精确 Evidence。
- `ELMOS-GR-069` — `gr-observability` — 统一 trace_id/job_id/project_id/run_id，记录队列、阶段、模型、工具、缓存、质量和错误预算。
- `ELMOS-GR-070` — `gr-cost-accounting` — 核算 token/cache、Runner、存储、网络、第三方许可和人工触点。
- `ELMOS-GR-071` — `gr-progress-eta` — 从 DAG、critical path、Gate、人工等待和阻塞计算可信进度与 ETA。
- `ELMOS-GR-072` — `gr-audit-retention` — 管理源码、模型上下文、日志、Evidence、账单与 Proof 的访问、保留、删除和 Legal Hold。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
