# Batch 14: intake-eligibility-estimation

仓库接入、资格判断、风险、Baseline、系统 ETA 和报价输入。

## Skills

- `ELMOS-GR-025` — `spring-secure-intake` — 安全接入 Git/压缩包/目录，建立不可变 snapshot 和客户授权范围。
- `ELMOS-GR-026` — `spring-eligibility` — 返回 eligible、eligible_with_warnings、custom_assessment 或 ineligible。
- `ELMOS-GR-027` — `spring-baseline-preflight` — 在冻结环境运行 compile/test/startup，区分历史失败和迁移回归。
- `ELMOS-GR-028` — `spring-legacy-risk` — 识别 XML-heavy、JSP、EJB、SOAP/RMI、JNI、反射、字节码、旧驱动和私有框架。
- `ELMOS-GR-029` — `spring-private-deps` — 验证内部 Maven 仓库、代理、证书、私有 starter、源码和商业许可。
- `ELMOS-GR-030` — `spring-effort-estimate` — 基于 ERSS、RCS、迁移面、Recipe 覆盖、历史数据和验证深度估算机器/人工工作。
- `ELMOS-GR-031` — `spring-runtime-eta` — 预测扫描、迁移、构建、测试和验证的系统墙钟时间并运行中重估。
- `ELMOS-GR-032` — `spring-assessment-report` — 生成可付费 Assessment、风险、路线、ETA、成本与 Pilot 建议。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
