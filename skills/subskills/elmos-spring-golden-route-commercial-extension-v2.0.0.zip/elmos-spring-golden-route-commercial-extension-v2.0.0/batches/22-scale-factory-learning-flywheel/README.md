# Batch 22: scale-factory-learning-flywheel

超大仓、多仓 Campaign、并发、缓存、Patch Mining、Recipe 认证与路线扩张。

## Skills

- `ELMOS-GR-089` — `gr-large-repo` — 为 300k–3M+ MRLOC、多模块、长构建和大测试集实施增量、分片、背压和资源治理。
- `ELMOS-GR-090` — `gr-multirepo` — 跨仓管理共享 API、数据库、库版本、依赖顺序、发布波次和回滚。
- `ELMOS-GR-091` — `gr-capacity` — 对租户、项目、阶段、模型、Sandbox、DB 和外部 Provider 实施公平准入、限流和熔断。
- `ELMOS-GR-092` — `gr-cache` — 建立 Blob→Parse→IR→Graph→Query→Context→Provider 分层缓存和依赖感知失效。
- `ELMOS-GR-093` — `gr-patch-mining` — 从经验证且获授权的 Semantic Patch 聚类重复模式，发现 Recipe candidate。
- `ELMOS-GR-094` — `gr-recipe-certification` — 用跨仓 positive/negative/holdout、幂等、安全、性能与许可 Gate 认证 Recipe。
- `ELMOS-GR-095` — `gr-migration-kg` — 沉淀版本、框架、API、风险、Recipe、Patch、失败、验证和成功率。
- `ELMOS-GR-096` — `gr-route-expansion` — Spring 达到 L3 后，按市场、复用、许可和验证能力扩展 Java→C#、Python、前端/小程序等路线。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
