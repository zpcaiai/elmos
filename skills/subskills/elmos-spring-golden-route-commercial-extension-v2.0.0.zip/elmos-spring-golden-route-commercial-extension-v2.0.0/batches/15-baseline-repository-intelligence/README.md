# Batch 15: baseline-repository-intelligence

不可变基线、Spring 语义图、测试与行为语料、Repository Intelligence。

## Skills

- `ELMOS-GR-033` — `spring-env-snapshot` — 冻结源码、Git、工具链、依赖索引、镜像和配置的可恢复快照。
- `ELMOS-GR-034` — `spring-characterization` — 捕获旧系统 API、数据库、安全、消息、配置、错误、启动和性能行为。
- `ELMOS-GR-035` — `spring-repo-graph` — 构建模块、符号、Bean、Endpoint、数据、事务、安全、消息、配置和测试 typed graph。
- `ELMOS-GR-036` — `spring-bean-flow` — 抽取 DI、Controller/Service/Repository、AOP、profiles 和事务传播/隔离。
- `ELMOS-GR-037` — `spring-data-graph` — 连接 Entity、Repository、JPQL/HQL/native SQL、schema、Migration 和事务。
- `ELMOS-GR-038` — `spring-security-graph` — 抽取 Filter Chain、matcher precedence、OAuth/JWT、method security、CSRF/CORS 和 endpoint policy。
- `ELMOS-GR-039` — `spring-async-graph` — 抽取 Kafka/Rabbit、Redis、Scheduler/Batch、retry/DLQ、TTL 和幂等副作用。
- `ELMOS-GR-040` — `spring-test-corpus` — 映射现有测试到能力并建立独立 holdout、negative 和业务场景。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
