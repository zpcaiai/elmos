# Batch 13: repository-scale-standard

MRLOC、ERSS、RCS、Transformation Surface 与大型仓库真实性标准。

## Skills

- `ELMOS-GR-017` — `repo-mrloc` — 区分 Gross、First-party、Production、Test、Config、Generated/Vendor 并计算 MRLOC。
- `ELMOS-GR-018` — `repo-origin-classifier` — 识别 first-party、generated、vendored、fork copy、fixture、sample 与 build output。
- `ELMOS-GR-019` — `repo-erss` — 定义 S0<20k、S1 20–100k、S2 100–300k、S3 300k–1M、S4 1–3M、S5>3M MRLOC。
- `ELMOS-GR-020` — `repo-rcs` — 计算 100 分 RCS：规模25、模块15、依赖15、语言10、框架10、运行10、测试构建10、遗留5。
- `ELMOS-GR-021` — `repo-transform-surface` — 按受影响类型、方法、API、配置、依赖和测试计算迁移面。
- `ELMOS-GR-022` — `repo-semantic-accounting` — 统计包/类型/方法/API/依赖/配置/Bean/Security/Entity/Test 的真实变换与执行者。
- `ELMOS-GR-023` — `repo-benchmark-profile` — 定义 Benchmark 仓库披露的 MRLOC、RCS、模块、测试、依赖、运行维度、基线和独立性。
- `ELMOS-GR-024` — `repo-scale-report` — 生成技术、销售、报价和客户版本的一致仓库规模复杂度报告。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
