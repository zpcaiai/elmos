# Batch 11: product-strategy-boundaries

产品品类、竞争定位、成熟度、Build-vs-Buy、许可证与范围控制。

## Skills

- `ELMOS-GR-001` — `elmos-product-category` — 将 Elmos 定义为 AI 原生仓库现代化、转换、验证与交付操作系统，而非普通 Coding Agent。
- `ELMOS-GR-002` — `elmos-competitive-positioning` — 建立 OpenRewrite/Moderne、OpenCode 与 Elmos 的证据化竞争矩阵。
- `ELMOS-GR-003` — `elmos-build-buy-partner` — 确定自研、集成、购买商业授权和客户侧执行的能力边界。
- `ELMOS-GR-004` — `elmos-maturity-l1-l5` — 用不可伪造 Evidence 区分架构、原型、付费 Pilot、成熟产品与行业领导者。
- `ELMOS-GR-005` — `elmos-golden-route-priority` — 把主要工程资源集中到 Spring 大型仓库 Golden Route，避免路线无限横向扩张。
- `ELMOS-GR-006` — `elmos-spring-route-boundary` — 冻结首版 Spring Route 支持矩阵、非目标和定制变更机制。
- `ELMOS-GR-007` — `elmos-recipe-license-gate` — 对 OpenRewrite Apache、Moderne Source Available、专有 Recipe 和 Elmos Native Recipe 做商业使用 Gate。
- `ELMOS-GR-008` — `elmos-scope-control` — 防止客户特例侵蚀 Golden Route 的可重复性和毛利。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
