# Batch 17: agent-repair-durable-safety

编译诊断、语义修复 Agent、Durable Session、副作用、恢复、审批与 Sandbox。

## Skills

- `ELMOS-GR-049` — `spring-diagnostic-classifier` — 把 Javac/Maven/Spring 启动错误聚类为 package、signature、type、bean、security、dependency 等根因。
- `ELMOS-GR-050` — `spring-repair-agent` — 只处理确定性规则无法覆盖的业务特定缺口，生成最小可回滚 Patch。
- `ELMOS-GR-051` — `spring-context-slicer` — 从 Graph、源码、配置、测试和决策中选取完成单个修复所需最小上下文。
- `ELMOS-GR-052` — `spring-durable-session` — 持久化 admission、queue/steer、provider turn、tool settlement、resume/interrupt 和 replay cursor。
- `ELMOS-GR-053` — `spring-side-effect-ledger` — 对 Git push、DB migration、deploy、publish 等先登记、授权、执行、settle 和对账。
- `ELMOS-GR-054` — `spring-crash-recovery` — 使用 lease、fencing token、checkpoint 和 external reconciliation 恢复 Worker/网络故障。
- `ELMOS-GR-055` — `spring-human-approval` — 对架构、许可、未知语义和高风险副作用实施结构化审批、拒绝和修正。
- `ELMOS-GR-056` — `spring-sandbox` — 在隔离 Runner 执行不可信构建，Secret 通过短期最小权限 Broker 注入。

## Batch completion gate

- [ ] 每个 Skill 在真实目标仓库产生 required outputs 与 immutable Evidence。
- [ ] 所有 P0/critical unknown 为零，否则 Batch 状态必须是 blocked/partial。
- [ ] Security、license、data、scope 和 customer acceptance 边界通过。
- [ ] Clean-room/replay/failure injection（适用时）通过。
- [ ] 不得用静态包验证代替真实实现验证。
