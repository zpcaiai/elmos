#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-}"; PLATFORM="elmos"; FORCE=0
[[ -n "$TARGET" ]] || { echo "Usage: $0 /path/to/target --platform elmos|codex|claude|opencode [--force]" >&2; exit 2; }
shift || true
while [[ $# -gt 0 ]]; do case "$1" in --platform) PLATFORM="$2";shift 2;;--force) FORCE=1;shift;;*) echo "Unknown arg $1" >&2;exit 2;;esac;done
case "$PLATFORM" in elmos) DEST="$TARGET/agent-skills/runtime";;codex) DEST="$TARGET/.agents/skills";;claude) DEST="$TARGET/.claude/skills";;opencode) DEST="$TARGET/.opencode/skills";;*) echo "Unknown platform" >&2;exit 2;;esac
mkdir -p "$DEST";count=0
for d in "$ROOT"/skills/*; do [[ -d "$d" ]] || continue;name="$(basename "$d")";if [[ -e "$DEST/$name" && "$FORCE" != 1 ]];then echo "Refusing to overwrite $DEST/$name; use --force" >&2;exit 3;fi;rm -rf "$DEST/$name";cp -R "$d" "$DEST/$name";count=$((count+1));done
echo "$count skills installed to $DEST"
