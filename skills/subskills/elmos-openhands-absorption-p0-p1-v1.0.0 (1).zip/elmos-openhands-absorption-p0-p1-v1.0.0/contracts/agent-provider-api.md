# Agent Provider Adapter Contract

```typescript
interface CodingAgentProvider {
  capabilities(): Promise<ProviderCapabilities>;
  start(input: AgentRunInput): Promise<ProviderSession>;
  send(session: ProviderSession, input: AgentTurnInput): AsyncIterable<ProviderEvent>;
  checkpoint(session: ProviderSession): Promise<ProviderCheckpoint>;
  resume(checkpoint: ProviderCheckpoint): Promise<ProviderSession>;
  cancel(session: ProviderSession, reason: string): Promise<void>;
  collectUsage(session: ProviderSession): Promise<ProviderUsage>;
}
```

Provider must not bypass:
- Elmos Action Firewall;
- Elmos Workspace policy;
- Elmos event ledger;
- Elmos evidence and completion gates;
- tenant budget / token / concurrency quotas.

Capability negotiation includes: tool-use, file-edit, shell, browser, MCP/ACP, streaming, reasoning visibility, checkpointability, model selection, max context, parallelism, external network requirements.
