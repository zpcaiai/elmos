# Workspace Provider Contract

```typescript
interface WorkspaceProvider {
  create(spec: WorkspaceSpec): Promise<WorkspaceHandle>;
  exec(handle: WorkspaceHandle, req: ExecRequest): Promise<ExecResult>;
  readFile(handle: WorkspaceHandle, path: string, range?: Range): Promise<BlobRef>;
  writeFile(handle: WorkspaceHandle, path: string, content: BlobRef, expectedHash?: string): Promise<FileWriteResult>;
  applyPatch(handle: WorkspaceHandle, patch: PatchSet): Promise<PatchResult>;
  git(handle: WorkspaceHandle, op: GitOperation): Promise<GitResult>;
  snapshot(handle: WorkspaceHandle, reason: string): Promise<SnapshotRef>;
  restore(snapshot: SnapshotRef): Promise<WorkspaceHandle>;
  exposePort(handle: WorkspaceHandle, spec: PortSpec): Promise<EndpointRef>;
  stats(handle: WorkspaceHandle): Promise<ResourceStats>;
  destroy(handle: WorkspaceHandle): Promise<void>;
}
```

Mandatory semantics:
- every mutating call requires idempotency key;
- path traversal is denied before provider invocation;
- exec has wall-clock/CPU/memory/output limits;
- network is deny-by-default for untrusted tasks;
- snapshots are content-addressed and tenant-scoped;
- provider implementation must pass isolation conformance tests.
