from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
errors=[]
for p in root.glob('skills/*/SKILL.md'):
    txt=p.read_text(encoding='utf-8')
    for h in ['## Purpose','## Production requirements','## Definition of Done','## Testing']:
        if h not in txt: errors.append(f'{p}: missing {h}')
for p in [root/'contracts/execution-event.schema.json', root/'contracts/action-observation.schema.json']:
    try: json.loads(p.read_text())
    except Exception as e: errors.append(f'{p}: {e}')
count=len(list(root.glob('skills/*/SKILL.md')))
if count != 14: errors.append(f'expected 14 skills, got {count}')
if errors:
    print('FAIL')
    print('\n'.join(errors))
    raise SystemExit(1)
print(f'PASS: {count} skills and shared contracts verified')
