# Golden Repo Benchmark

## Required repository classes
- S: <100k LOC, common web/backend stack.
- M: 100k–500k LOC, multi-service.
- L1/L2/L3: three repositories >500k LOC.
- XL: at least one repository >1M LOC or equivalent multi-repo dependency surface.

## Task families
1. cross-module feature implementation;
2. framework/library migration;
3. database schema + backward-compatible rollout;
4. production bug from failing test/log/trace;
5. security remediation;
6. performance regression;
7. frontend behavior + browser acceptance;
8. dependency upgrade with breaking API;
9. multi-agent conflicting changes;
10. crash/recovery mid-execution.

## Metrics
- acceptance pass rate;
- first-pass vs repair-loop pass;
- human intervention minutes;
- wall time;
- token/tool/compute cost;
- regression count;
- unsafe action attempts blocked;
- context cache hit and tokens saved;
- resume success after injected failure;
- evidence completeness;
- diff precision / unnecessary churn proxy.

## Release criterion
No P0/P1 capability is GA solely on toy repos. At minimum, the affected workflow must pass a representative L repository; runtime/recovery/context/provider-routing changes must also run on XL.
