# Production Acceptance Matrix

| Domain | Mandatory acceptance |
|---|---|
| Correctness | Same task replay yields equivalent logical state and no duplicate irreversible side effect |
| Recovery | Kill Agent, Tool worker, Workspace worker, DB connection, Event bus; task resumes or fails deterministically |
| Isolation | Cross-tenant file, secret, cache, event, artifact access attempts all denied |
| Security | Seeded prompt injection/exfiltration/destructive commands blocked according to policy |
| Quality | Agent cannot complete while required gate is failing |
| Scale | Horizontal worker scaling without workflow loss; backpressure protects DB/event bus |
| Cost | Token/tool/compute/storage cost reconcilable to run + node + tenant |
| Audit | Every mutation links Action → Policy Decision → Observation → Evidence |
| Reproducibility | Manifest pins repo commit, package versions, tool images, model/provider and policy version |
| Packages | Unsigned/untrusted package cannot gain undeclared privilege |
| Browser | UI acceptance stores screenshot/video/console/network evidence and can replay scenario |
| Provider | At least 3 provider adapters pass identical conformance tests |

## Failure injection suite
1. Kill process immediately after tool request but before result persistence.
2. Kill process after external mutation but before acknowledgement.
3. Duplicate event delivery.
4. Event reordering at bus consumer layer.
5. Workspace snapshot corruption.
6. Provider 429/5xx and long stall.
7. Object store temporary outage.
8. DB failover during checkpoint.
9. Malicious repo README/issue containing prompt injection.
10. Secret value accidentally printed by subprocess.
11. Dependency install attempts unapproved domain.
12. Agent attempts `rm -rf`, force push, prod DB drop.
13. Two concurrent agents edit same file/symbol.
14. Context condenser drops a previously failed test fact.
15. Plugin version changed between pause and resume.
