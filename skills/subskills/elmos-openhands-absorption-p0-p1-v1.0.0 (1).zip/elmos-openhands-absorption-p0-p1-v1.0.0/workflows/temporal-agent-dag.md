# Temporal Durable Agent DAG

## Workflow invariants
- Workflow state contains references, never large blobs.
- Activities own side effects and expose idempotency keys.
- Every external tool mutation emits pre-action + result event.
- Retries never re-issue irreversible effects without dedupe/compensation.
- Cancellation propagates to child workflows and workspace leases.

## Reference DAG
```text
TaskWorkflow
 ├─ BootstrapWorkspaceActivity
 ├─ BuildRepoIntelligenceActivity
 ├─ PlannerChildWorkflow
 │   └─ outputs immutable plan version
 ├─ ParallelImplementation
 │   ├─ BackendChildWorkflow
 │   ├─ FrontendChildWorkflow
 │   └─ DataInfraChildWorkflow
 ├─ IntegrationChildWorkflow
 ├─ VerificationChildWorkflow
 │   ├─ Build
 │   ├─ Unit
 │   ├─ Integration
 │   ├─ Security
 │   └─ BrowserE2E
 ├─ RepairLoop (bounded by policy/budget)
 ├─ ReviewChildWorkflow
 └─ FinalizeEvidenceActivity
```

## Failure semantics
- Agent crash: resume from ledger + latest checkpoint.
- Workspace loss: restore latest snapshot then verify repo hash.
- Provider outage: pause or route to compatible provider, preserving contract state.
- Tool timeout: retry only if idempotent; otherwise reconcile first.
- Child agent failure: retry, replace provider, or compensate branch/worktree.
