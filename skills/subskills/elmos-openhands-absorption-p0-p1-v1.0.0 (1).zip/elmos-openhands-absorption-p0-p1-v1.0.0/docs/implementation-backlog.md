# Implementation Backlog — Epic / Story Level

This backlog is designed to be copied into Jira/Linear/GitHub Projects. Each epic must ship behind feature flags and pass its Skill's acceptance contract.

## P0-01 Stateless Agent Runtime
**Epic A — Runtime kernel**
- Define `RuntimeTurnInput/Result`, lifecycle enums and single-writer lease model.
- Implement deterministic state transition reducer from event ledger.
- Implement turn supervisor: heartbeat, stuck detection, cancellation and deadline.
- Implement budget guard for time/token/tool/cost.
- Convert provider `done` into `CompletionProposal`.
- Add reference fake model/tool adapters for deterministic unit tests.

**Epic B — Resilience**
- Resume after process death at each turn boundary.
- Ensure model retry cannot duplicate tool side effects.
- Add run/node fencing tokens to prevent split brain.
- Add run-state reconciliation job.

## P0-02 Immutable Event Ledger
**Epic A — Storage**
- Implement append API with per-run monotonic sequence allocation.
- Implement transactional outbox/CDC to event bus.
- Split large payloads into object-store blobs with digest references.
- Implement append-only DB permissions and correction events.
- Implement tenant-scoped indexes and retention partitions.

**Epic B — Projections**
- Current task state projection.
- UI timeline projection.
- Cost/usage projection.
- Verification projection.
- Context-candidate projection.
- Full rebuild command + checksum comparison.

## P0-03 Action–Observation Protocol
- Freeze tool envelope schema and schema-version negotiation.
- Implement Tool Registry and capability metadata.
- Implement Tool Gateway with validation, timeout, cancellation and output caps.
- Implement stdout/stderr artifact offload and secret redaction.
- Implement structured error taxonomy and reconciliation hints.
- Build conformance harness for filesystem, shell, git, build/test and browser tools.
- Add idempotency/reconciliation contract for all mutating operations.

## P0-04 Durable Persistence / Replay
- Define safe-checkpoint semantics and checkpoint cadence policy.
- Implement logical-state + provider + workspace + manifest checkpoint bundle.
- Implement resume coordinator and compatibility validation.
- Implement unfinished-side-effect reconciliation.
- Implement audit-only replay and projection rebuild.
- Implement isolated sandbox re-execution mode.
- Add corrupted snapshot detection/fallback to prior checkpoint.
- Add DR exercise: DB failover + object-store temporary loss + worker death.

## P0-05 Workspace & Sandbox Abstraction
- Implement provider contract and local reference provider.
- Implement Docker hardened provider.
- Implement production isolation provider (Firecracker/gVisor/Kata or approved equivalent).
- Implement workspace lease/heartbeat/reaper.
- Implement image/toolchain digest pinning.
- Implement snapshot/restore + content digest verification.
- Implement per-class egress, mount, CPU/memory/PID/disk quotas.
- Implement Secret Broker injection and revocation.
- Implement warm pool, cold start and recycle policies.
- Build sandbox escape and tenant bleed test suite.

## P0-06 Agent Server / Runtime Plane
- Implement Runtime Gateway APIs and resumable event stream cursors.
- Implement Agent Worker registration/heartbeat/drain.
- Implement Workspace Worker integration and placement.
- Implement admission control/backpressure.
- Implement per-tenant concurrency/token/CPU-minute quotas.
- Implement worker fencing and stale lease recovery.
- Implement region/data-residency aware placement.
- Implement rolling deployment with zero workflow loss.
- Load test active/idle run scaling and event fanout.

## P0-07 Evidence-aware Context Engine
- Define Context Candidate schema with provenance/freshness/security labels.
- Integrate repo graph, symbols, diff, requirements, git history and event ledger.
- Implement role-specific retrieval policies.
- Implement conflict/staleness resolver.
- Implement must-retain fact classifier/rules.
- Implement token-budget packer and model-specific adapters.
- Integrate content-addressed cache and context fingerprinting.
- Build context benchmark: dependency recall, failed-test retention and stale-context rate.
- Add explainability: why each context item was included.

## P0-08 Action Firewall
- Implement Policy Decision Point and Tool Gateway enforcement point.
- Define risk classifier R0–R6 and rule DSL.
- Implement path scope, network egress, command and dependency-install guards.
- Implement secret taint tracking/redaction.
- Implement prompt-injection risk signals from repo/web/tool output.
- Implement human approval workflow for R5/R6 and configurable R4.
- Ledger every policy decision with rule/version/reason.
- Build red-team suite for exfiltration, obfuscation, symlink escape and destructive actions.
- Add emergency global/tenant/package/tool kill switch.

## P0-09 Hooks & Verification Gates
- Implement typed hook registry and deterministic ordering.
- Implement PreTool/PostTool lifecycle integration.
- Implement CompletionProposal and gate evaluation engine.
- Define repo/task-type gate profiles.
- Implement requirement→diff→test→evidence trace graph.
- Implement bounded repair loop and failure escalation.
- Integrate build, unit, integration, lint/typecheck, security, E2E and performance gates.
- Implement explicit waiver with human identity/reason/expiry.
- Build tests proving agent text cannot bypass a failed mandatory gate.

## P1-01 Progressive Skill Disclosure
- Build Skill metadata/embedding index.
- Implement hard-constraint + semantic + historical-success router.
- Implement L0/L1/L2/L3 staged loading.
- Implement per-skill permission declarations and firewall integration.
- Implement skill token accounting and cache.
- Build routing benchmark corpus and top-K recall dashboard.
- Implement conflict resolution and incompatible-skill warnings.
- Add tenant allowlist/private skills.

## P1-02 Commercial Capability Package
- Freeze package manifest, permission and dependency schema.
- Add content digest, signing and publisher identity.
- Generate SBOM and locked dependencies at build time.
- Implement package validation sandbox and conformance test runner.
- Implement registry publish/approve/install/activate/rollback lifecycle.
- Implement resume-time version pinning and compatibility checks.
- Add private registry, tenant pinning and revocation.
- Add vulnerability kill switch and provenance audit UI.
- Prevent active run mutation on package upgrade.

## P1-03 Durable Multi-Agent DAG
- Define child-agent contract: inputs, artifacts, branch/worktree and budget.
- Implement Temporal child workflows and fan-out/fan-in.
- Implement separate worktree/clone strategies and lock rules.
- Implement plan amendment events and dynamic DAG changes.
- Implement child replacement/provider fallback.
- Implement semantic merge/integration workflow.
- Implement compensation/cancel propagation.
- Implement global/per-agent budget and concurrency controls.
- Build race/conflict benchmark with same-file and same-symbol edits.

## P1-04 Agent Provider Adapter Layer
- Freeze provider capability negotiation contract.
- Implement Native Agent adapter first.
- Implement at least two external adapters (e.g. Codex-compatible + Claude/OpenHands-compatible).
- Normalize provider events/usage/errors/checkpoints.
- Implement privacy/residency/cost/benchmark-aware routing.
- Implement provider circuit breakers and fallback.
- Implement shadow evaluation mode.
- Build identical Golden Task conformance suite across providers.
- Ensure external provider cannot bypass policy/evidence via network/workspace restrictions.

## P1-05 Browser / UI Evidence & Replay
- Define Scenario DSL and evidence schema.
- Implement browser session allocation and semantic locator strategy.
- Capture screenshot, video, DOM/accessibility, console and network evidence.
- Correlate frontend actions with backend OTel traces.
- Implement PII/secret masking before persistence.
- Implement semantic replay against new builds.
- Add flake detection/retry classification without hiding real failures.
- Integrate UI evidence into completion gate and PR report.
- Build cross-browser/device profile matrix where product requires it.

## Cross-package commercial epics
### Observability & FinOps
- Unified OTel semantic conventions.
- Provider invoice reconciliation samples.
- Cost dashboard by tenant/project/task/node/provider/model/tool.
- Budget alerts and hard stops.

### Operations
- On-call runbooks for stuck workflow, event lag, workspace leak, provider outage and policy incident.
- Backup/restore exercise.
- Data retention/deletion and tenant export.
- Capacity model for S/M/L/XL repositories.

### Production certification
- Golden Repo suite including at least 3 repositories >500k LOC and one >1M LOC.
- Security red-team signoff.
- Chaos campaign signoff.
- Performance regression baseline.
- Evidence completeness audit.
