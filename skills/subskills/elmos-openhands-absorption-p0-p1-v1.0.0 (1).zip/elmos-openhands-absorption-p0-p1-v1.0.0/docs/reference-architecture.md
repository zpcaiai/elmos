# Reference Architecture

```text
                         ┌──────────────────────────────┐
                         │        Elmos Control Plane   │
                         │ Task API / Tenant / Policy  │
                         └──────────────┬───────────────┘
                                        │
                                   Temporal DAG
                                        │
                ┌───────────────────────┼────────────────────────┐
                │                       │                        │
         Provider Router          Context Engine           Skill Router
                │                       │                        │
       ┌────────┼────────┐              │                        │
       │        │        │              │                        │
     Codex    Claude   Native           │                        │
       │        │        │              │                        │
       └────────┴────────┴──────────────┼────────────────────────┘
                                        │
                                Stateless Agent Runtime
                                        │
                                  Proposed Action
                                        │
                              ┌─────────▼──────────┐
                              │  Action Firewall  │
                              └─────────┬──────────┘
                                        │ allow/approve
                                        ▼
                                  Tool Gateway
                                        │
              ┌─────────────────────────┼─────────────────────────┐
              │                         │                         │
         Workspace API               Browser                  SCM/Cloud
              │                         │                         │
    Local/Docker/FC/K8s/SSH             │                         │
              └─────────────────────────┼─────────────────────────┘
                                        │
                                   Observation
                                        │
                                 Event Ledger
                                        │
             ┌──────────────────────────┼──────────────────────────┐
             │                          │                          │
       Context Projection          Evidence Pack             Cost/Telemetry
             │                          │                          │
             └──────────────────────────┼──────────────────────────┘
                                        │
                                Verification Gates
                                        │
                                pass → PR/Deploy
```

## Control Plane / Runtime Plane Separation

**Control Plane** owns policy, tenancy, scheduling, budgets, provider selection, manifests, approvals and lifecycle.
**Runtime Plane** executes Agents, Tools and Workspaces under leases; it must be replaceable and horizontally scalable.

## Truth Hierarchy

1. Repository commit / workspace snapshot
2. Immutable execution event ledger
3. Test/build/browser/security artifacts
4. Derived projections and summaries
5. LLM-generated narrative

LLM narrative is never the source of truth.

## Mandatory cross-cutting services

- Tenant/AuthZ service
- Secret Broker with short-lived credentials
- Cost Metering
- Artifact Store
- OpenTelemetry Collector
- Policy Decision Point
- Package Registry + signature verification
- Reproducibility Manifest service
