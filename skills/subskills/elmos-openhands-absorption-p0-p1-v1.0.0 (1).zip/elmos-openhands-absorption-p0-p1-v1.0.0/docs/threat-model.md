# Threat Model Baseline

## Primary assets
Source code, secrets, tenant data, build artifacts, production credentials, repository history, model prompts/context, execution evidence and billing data.

## Trust boundaries
User input; repository content; third-party model/provider; capability package; tool server/MCP; sandbox; browser/web content; CI/CD; cloud APIs; object store.

## High-priority threats
- prompt injection leading to unauthorized tool action;
- code/data exfiltration via network, DNS, git, package manager or logs;
- cross-tenant cache/artifact/workspace leakage;
- malicious package/plugin or dependency install script;
- workspace escape / host access;
- replay causing duplicate payment/deploy/delete;
- poisoned context/summary suppressing critical failure;
- provider adapter bypassing policy/evidence;
- long-lived secret persisted in transcript/snapshot;
- forged evidence or gate bypass.

## Mandatory mitigations
Action Firewall, egress allowlist, secret broker, sandbox class policy, immutable ledger, signed packages, content digests, evidence signatures, approval for R5/R6, tenant-scoped encryption and chaos/red-team tests.
