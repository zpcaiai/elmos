-- Elmos P0/P1 core schema (PostgreSQL reference)
CREATE TABLE execution_runs (
  run_id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL,
  project_id UUID NOT NULL,
  task_id UUID NOT NULL,
  parent_run_id UUID,
  status TEXT NOT NULL CHECK (status IN ('queued','running','waiting','blocked','succeeded','failed','cancelled')),
  provider TEXT,
  model TEXT,
  manifest_hash TEXT NOT NULL,
  workspace_id UUID,
  started_at TIMESTAMPTZ,
  finished_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE execution_events (
  tenant_id UUID NOT NULL,
  run_id UUID NOT NULL,
  seq BIGINT NOT NULL,
  event_id UUID NOT NULL,
  event_type TEXT NOT NULL,
  node_id TEXT,
  agent_id TEXT,
  causation_event_id UUID,
  correlation_id UUID,
  idempotency_key TEXT,
  payload JSONB NOT NULL,
  artifact_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
  policy_decision JSONB,
  token_usage JSONB,
  cost_usd NUMERIC(18,8),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, run_id, seq),
  UNIQUE (tenant_id, event_id)
);
CREATE INDEX execution_events_type_idx ON execution_events(tenant_id, run_id, event_type);
CREATE UNIQUE INDEX execution_events_idempotency_idx ON execution_events(tenant_id, run_id, idempotency_key) WHERE idempotency_key IS NOT NULL;

CREATE TABLE execution_checkpoints (
  checkpoint_id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL,
  run_id UUID NOT NULL,
  node_id TEXT,
  event_seq BIGINT NOT NULL,
  repo_commit TEXT,
  workspace_snapshot_ref TEXT,
  state_blob_ref TEXT NOT NULL,
  manifest_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE workspace_leases (
  workspace_id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL,
  run_id UUID NOT NULL,
  provider TEXT NOT NULL,
  isolation_class TEXT NOT NULL,
  state TEXT NOT NULL,
  cpu_limit NUMERIC,
  memory_mb BIGINT,
  disk_mb BIGINT,
  network_policy_id TEXT,
  lease_expires_at TIMESTAMPTZ NOT NULL,
  snapshot_ref TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE policy_decisions (
  decision_id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL,
  run_id UUID NOT NULL,
  action_event_id UUID NOT NULL,
  risk_level TEXT NOT NULL,
  decision TEXT NOT NULL CHECK (decision IN ('allow','deny','require_approval')),
  rules JSONB NOT NULL,
  reason TEXT,
  approved_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE verification_results (
  verification_id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL,
  run_id UUID NOT NULL,
  gate_name TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pass','fail','skip','error')),
  evidence_refs JSONB NOT NULL,
  metrics JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE capability_packages (
  package_name TEXT NOT NULL,
  version TEXT NOT NULL,
  digest TEXT NOT NULL,
  signature TEXT,
  manifest JSONB NOT NULL,
  trust_level TEXT NOT NULL,
  published_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (package_name, version)
);
