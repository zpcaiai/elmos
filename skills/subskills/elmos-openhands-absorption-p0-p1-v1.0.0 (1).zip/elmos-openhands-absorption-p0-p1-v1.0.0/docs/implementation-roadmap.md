# Implementation Roadmap

## Phase 0 — Contracts freeze (Week 0–2 equivalent scope)
- Freeze Event Envelope, Action/Observation, Workspace, Provider Adapter and Package Manifest contracts.
- Define versioning/backward-compatibility rules.
- Establish threat model and tenant isolation requirements.
- Create baseline Golden Repos: small, medium, large, polyglot.

## Phase 1 — Runtime truth & recovery
Implement P0-01..P0-04 first. Exit criteria:
- every action is evented;
- crash at any tool boundary can resume without duplicate side effects;
- deterministic replay reconstructs logical task state;
- event loss = 0 under injected worker death.

## Phase 2 — Execution isolation & scale
Implement P0-05..P0-06. Exit criteria:
- local/dev + Docker + production sandbox provider;
- workspace lease/snapshot/restore;
- 1000 concurrent idle runs and target active-run concurrency without tenant bleed;
- worker rolling restart has no task loss.

## Phase 3 — Context, security and quality
Implement P0-07..P0-09. Exit criteria:
- role-specific context projection;
- policy blocks all seeded exfiltration/destructive scenarios;
- task cannot finish when mandatory verification gates fail.

## Phase 4 — Capability extensibility
Implement P1-01..P1-04. Exit criteria:
- skills load progressively;
- signed capability packages install/uninstall safely;
- multi-agent DAG survives parent/child worker loss;
- at least 3 provider adapters run the same contract test suite.

## Phase 5 — UI evidence and production certification
Implement P1-05 plus E2E evidence pack. Exit criteria:
- replayable browser evidence;
- requirement→change→test→evidence traceability;
- signed execution manifest;
- E1–E5 production certification suite passes.

## Recommended dependency DAG
```text
P0-02 Event Ledger ─┬─> P0-01 Runtime ─> P0-03 Tool Protocol
                    └─> P0-04 Replay
P0-03 ─> P0-08 Firewall ─> P0-09 Gates
P0-05 Workspace ─> P0-06 Runtime Plane
P0-02 + Repo Intelligence ─> P0-07 Context
P0-07 ─> P1-01 Skill Router
P1-01 + P0-08 ─> P1-02 Packages
P0-01 + P0-04 + Temporal ─> P1-03 Agent DAG
P0-03 + P0-06 ─> P1-04 Provider Adapters
P0-03 + P0-09 ─> P1-05 Browser Evidence
```
