# Production SLO Baseline

These are starting targets and must be tuned against Elmos workload classes.

| Capability | Initial production target |
|---|---|
| Control-plane API availability | 99.95% monthly |
| Acknowledged event durability | no acknowledged event loss |
| Event append p95 | < 100 ms excluding cross-region replication |
| Agent stream resume | client can reconnect by cursor without losing committed events |
| Task recovery after worker crash | p95 < 60 s excluding large workspace restore |
| Policy decision p95 | < 50 ms for cached local policy, < 250 ms with risk model |
| Workspace allocation warm p95 | < 10 s |
| Cross-tenant isolation | zero tolerated violations |
| Duplicate irreversible side effects after retry | zero tolerated |
| Cost attribution reconciliation error | < 1% on sampled billable usage |
| Verification false-success | zero tolerated for mandatory deterministic gates |
| Package provenance coverage | 100% activated third-party packages |

## Workload classes
- S: <100k LOC, single service
- M: 100k–500k LOC
- L: 500k–1M LOC
- XL: >1M LOC / monorepo / multi-repo

SLO dashboards must segment by workload class, provider/model and sandbox class.
