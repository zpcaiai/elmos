# Observability & FinOps Specification

## Trace identity
Every span/event/log MUST include where applicable:
`tenant_id, project_id, task_id, run_id, node_id, agent_id, provider, model, workspace_id, tool_name, package_version`.

## Core dashboards
1. **Fleet health** — queue depth, active runs, worker leases, workspace allocation, stuck runs.
2. **Agent quality** — completion rate, repair-loop depth, gate failures, regression reopen rate.
3. **Provider** — latency, error/429, token cache hit, cost/successful task, failover rate.
4. **Sandbox** — cold/warm start, CPU/memory saturation, network denial, escape alerts.
5. **Context** — retrieved tokens, compressed tokens, cache hit, stale-context incidents.
6. **Security** — policy deny/approval, secret taint, prompt injection, exfiltration attempts.
7. **FinOps** — revenue/cost/gross margin by tenant/project/task/provider/model.

## Cost ledger
Each billable unit is appended as a cost event:
- model input/cached/output/reasoning tokens;
- provider session fee;
- sandbox CPU-second/memory-GB-second/disk/network;
- object storage bytes and retrieval;
- browser minute/video storage;
- external API/tool charge.

Cost reconciliation job compares sampled Elmos usage to provider invoices. Variance >1% creates incident.

## Alerts
- task stuck > policy threshold;
- event consumer lag threatens RTO;
- workspace lease orphan;
- cross-tenant authorization denial spike;
- provider failure/latency circuit-breaker threshold;
- cost runaway vs task budget;
- verification false-success detector;
- package revocation or signature failure.
