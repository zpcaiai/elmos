# Operational Runbooks

## Stuck workflow
1. Inspect Temporal workflow and latest committed event sequence.
2. Verify current node lease/fencing token.
3. Check provider/tool/workspace heartbeat.
4. Reconcile unfinished Action without blindly retrying side effect.
5. Resume from latest safe checkpoint or mark blocked with evidence.

## Provider outage
- open circuit breaker;
- preserve task state and workspace lease/snapshot;
- if policy permits, route compatible node to fallback provider;
- record provider-switch event and manifest amendment;
- rerun verification after provider handoff.

## Workspace loss
- fence lost workspace lease;
- restore latest snapshot;
- validate repo commit and content digests;
- replay logical events after snapshot;
- rerun affected verification gates.

## Suspected secret exfiltration
- immediately revoke short-lived credential;
- isolate workspace and disable egress;
- preserve forensic artifacts;
- identify event/action/policy decision chain;
- rotate impacted long-lived upstream secret if any;
- tenant notification and incident workflow per contract.

## Corrupted projection
- stop projector;
- rebuild from immutable ledger into shadow tables;
- checksum/semantic compare;
- atomically swap projection after validation.

## Package revocation
- prevent new activations;
- identify active runs using affected digest;
- pause at next safe boundary;
- migrate only if compatibility and security policy allow, else rollback/fail safely.
