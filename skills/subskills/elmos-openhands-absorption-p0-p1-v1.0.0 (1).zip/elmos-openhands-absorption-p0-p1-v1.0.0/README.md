# Elmos OpenHands Absorption — P0/P1 Production Skills Package v1.0.0

本包把 OpenHands 中最值得吸收的 Agent Runtime 思想升级为 **Elmos 商业级 Software Engineering Control Plane**。目标不是复制 OpenHands，而是把其 SDK/Runtime 优点与 Elmos 的 Temporal、Repository Intelligence、Verification Fabric、缓存、多租户、成本核算和生产认证体系组合起来。

## 能力范围

### P0 — 必须先落地
1. Stateless Agent Runtime
2. Immutable Execution Event Ledger
3. Action–Observation Tool Protocol
4. Durable Persistence / Checkpoint / Replay
5. Workspace & Sandbox Abstraction
6. Agent Server / Distributed Runtime Plane
7. Evidence-aware Context / Condenser Engine
8. Action Firewall / Security Analyzer
9. Hooks / Verification Completion Gates

### P1 — 紧随 P0
10. Progressive Skill Disclosure
11. Commercial Capability Package / Plugin System
12. Durable Multi-Agent Delegation DAG
13. Agent Provider Adapter / ACP Layer
14. Browser/UI Evidence & Replay

## 商业生产标准

本包要求每个能力至少满足：

- 明确模块边界与 API 契约
- 可版本化 Schema
- 幂等、可恢复、可重放
- 多租户强隔离
- 权限与安全策略前置
- OpenTelemetry trace / metric / log
- 单任务、单节点 Token/模型/工具/基础设施成本归集
- SLA/SLO 与容量压测
- Golden Path + Failure Injection
- 可审计 Evidence Pack
- 数据保留与删除策略
- 灰度、迁移、回滚方案

## 推荐代码模块

```text
elmos/
├── control-plane/
│   ├── task-api/
│   ├── scheduler/
│   ├── policy/
│   └── tenancy/
├── runtime-plane/
│   ├── agent-runtime/
│   ├── agent-server/
│   ├── tool-gateway/
│   └── workspace-manager/
├── intelligence/
│   ├── repo-graph/
│   ├── context-engine/
│   ├── skill-router/
│   └── provider-router/
├── evidence/
│   ├── event-ledger/
│   ├── artifact-store/
│   ├── verification/
│   └── replay/
└── platform/
    ├── observability/
    ├── cost-metering/
    ├── secrets-broker/
    └── package-registry/
```

## 推荐技术边界

- **Temporal**：任务、节点、重试、等待、人审、补偿、跨小时/跨天恢复。
- **PostgreSQL**：任务元数据、事件索引、策略、租户、成本、版本信息。
- **Kafka / NATS JetStream**：高吞吐事件分发，不作为唯一事实源。
- **S3-compatible Object Storage**：大日志、视频、截图、构建产物、trace blobs。
- **OpenTelemetry**：跨 Agent、Tool、Sandbox、CI、Browser 统一 tracing。
- **Content-addressed Cache**：代码上下文、索引、依赖解析、测试结果、构建中间状态。
- **Firecracker/gVisor/Kata/K8s**：不可信代码与多租户隔离。

## 实现原则

1. **事件账本是事实源，LLM Context 只是投影。**
2. **Agent 是可替换决策器，Runtime 才是系统核心。**
3. **任何产生副作用的工具调用必须先过 Action Firewall。**
4. **任何任务完成必须提供 Evidence，不接受自报完成。**
5. **任何长任务都必须支持 Resume/Cancel/Replay。**
6. **任何外部 Coding Agent 都只能作为 Provider，不能绕过 Elmos Policy/Evidence。**
7. **任何 Skill/Plugin 都必须有权限声明、版本锁定、测试与供应链签名。**

## 目录说明

- `skills/*/SKILL.md`：14 个可实施 Skill。
- `docs/`：总架构、数据模型、运行模型、迁移路线。
- `contracts/`：统一 API / Event / Tool / Workspace 契约。
- `policies/`：风险等级、多租户、网络、Secret、完成门策略。
- `workflows/`：Temporal DAG 与关键工作流。
- `tests/`：生产验收矩阵、故障注入、安全和容量验收。
