# Skill Index

- **P0-01 Stateless Agent Runtime** — 将 Agent 核心收敛为无状态、可重放的决策执行循环，状态外置到任务状态机、事件账本与工作区。  → `skills/P0-01-stateless-agent-runtime/SKILL.md`
- **P0-02 Immutable Execution Event Ledger** — 建立强类型、仅追加、可审计、可投影的项目执行事件账本，作为任务事实源。  → `skills/P0-02-immutable-event-ledger/SKILL.md`
- **P0-03 Action–Observation Tool Protocol** — 统一 Agent→Tool 的 Action 与 Runtime→Agent 的 Observation 协议，覆盖命令、文件、浏览器、测试、Git、云资源等工具。  → `skills/P0-03-action-observation-protocol/SKILL.md`
- **P0-04 Durable Persistence, Checkpoint & Replay** — 实现项目/任务/节点级持久化、幂等恢复、断点续跑、事件重放、快照与灾难恢复。  → `skills/P0-04-durable-persistence-replay/SKILL.md`
- **P0-05 Workspace & Sandbox Abstraction** — 抽象 Local/Docker/Firecracker/Kubernetes/SSH/企业私有环境，并以策略选择隔离强度、快照和资源配额。  → `skills/P0-05-workspace-abstraction/SKILL.md`
- **P0-06 Agent Server & Distributed Runtime Plane** — 将 Agent Worker、Workspace Worker 与控制面分离，提供远程执行、流式事件、弹性伸缩、多租户和任务租约。  → `skills/P0-06-agent-server-runtime-plane/SKILL.md`
- **P0-07 Evidence-aware Context / Condenser Engine** — 把完整事实账本投影为按角色、阶段、模型优化的上下文视图，结合仓库图、缓存、失败证据与动态压缩。  → `skills/P0-07-evidence-aware-context-engine/SKILL.md`
- **P0-08 Action Firewall & Security Analyzer** — 在任何工具执行前做 Schema、RBAC、路径、网络、Secret、Prompt Injection、数据外泄与破坏性风险控制。  → `skills/P0-08-action-firewall-security/SKILL.md`
- **P0-09 Hooks & Verification Gates** — 通过 Pre/Post Tool Hook 与 Completion Gate 强制 Build/Test/E2E/Security/Requirement Trace 通过后才能完成任务。  → `skills/P0-09-hooks-verification-gates/SKILL.md`
- **P1-01 Progressive Skill Disclosure & Skill Router** — Skill 仅暴露元数据，按任务语义和阶段动态路由、按需加载正文/脚本/示例，控制上下文成本。  → `skills/P1-01-progressive-skill-disclosure/SKILL.md`
- **P1-02 Commercial Capability Package / Plugin System** — 把 Skills、Agents、Tools、MCP、Hooks、Policies、Schemas、Evals、Benchmarks 和 Migrations 封装为可签名、版本化、可认证能力包。  → `skills/P1-02-capability-package/SKILL.md`
- **P1-03 Durable Multi-Agent Delegation DAG** — 把同步 sub-agent delegation 升级为 Temporal 驱动的耐久异步 DAG，支持 fan-out/fan-in、租约、取消、补偿和并发隔离。  → `skills/P1-03-durable-agent-dag/SKILL.md`
- **P1-04 Agent Provider Adapter / ACP Layer** — 将 Codex、Claude Code、OpenHands、OpenCode、Gemini CLI、Junie 等外部 Coding Agent 统一接入 Elmos Control Plane。  → `skills/P1-04-agent-provider-adapters/SKILL.md`
- **P1-05 Browser / UI Evidence & Replay** — 记录 UI/E2E 会话、截图、视频、DOM/Console/Network 证据，并形成可重放、可审计的项目验收 Evidence Pack。  → `skills/P1-05-browser-evidence-replay/SKILL.md`
