# P0-08 — Action Firewall & Security Analyzer

## Purpose
在任何工具执行前做 Schema、RBAC、路径、网络、Secret、Prompt Injection、数据外泄与破坏性风险控制。

## Priority
**P0**

## Why this exists
本 Skill 将能力实现为 Elmos 的平台级生产组件，目标不是 demo agent，而是可在多租户、大型仓库、长任务、真实副作用和企业审计环境中运行。

## Inputs
- `tenant_id / project_id / task_id / run_id / node_id`
- repository revision / workspace reference
- task requirement + acceptance criteria
- execution manifest + policy version
- provider/model/skill capability constraints
- budget / deadline / isolation class

## Outputs
- typed events and immutable artifact references
- machine-readable status/result
- cost/usage/telemetry
- checkpoint/replay metadata where applicable
- evidence required by downstream verification

### Policy engine stages
1. schema/type validation;
2. authentication/tenant RBAC;
3. capability grant;
4. filesystem scope;
5. network/egress;
6. secret taint/exfiltration analysis;
7. destructive command analysis;
8. prompt-injection context risk;
9. budget/concurrency;
10. human approval if required.

### Enforcement architecture
Policy Decision Point is separate from Tool Gateway Policy Enforcement Point. Every decision is ledgered with rule/version/reason.

### Secrets
Agent receives opaque secret handles where possible; workspace gets short-lived scoped credential; outputs pass redaction/taint filter.

### Mandatory red-team cases
prompt injection in README, dependency scripts, webpage, test fixture and tool output; credential exfiltration via curl/DNS/git; shell obfuscation; symlink/path traversal; package install hooks.



## Production requirements
- **Durability**: any state required after process loss must be externalized; no correctness dependency on in-memory state.
- **Idempotency**: every mutating boundary has idempotency key, reconciliation path and retry semantics.
- **Tenancy**: tenant ID is mandatory in storage keys, events, cache keys, artifacts and authorization decisions.
- **Observability**: every operation carries `trace_id/run_id/node_id/agent_id/tenant_id` and emits OTel spans.
- **Cost**: record model tokens, provider charges, sandbox CPU/memory/time, artifact storage and external tool charges.
- **Security**: least privilege, short-lived credentials, deny-by-default egress for untrusted execution.
- **Versioning**: external contracts use semantic schema versions with backward-compatibility window.
- **Evidence**: success claims require machine-verifiable artifacts, not natural-language declarations.


## Failure modes to implement explicitly
1. Worker/process crash at every boundary.
2. Duplicate request/event delivery.
3. Timeout and partial tool result.
4. Provider 429/5xx/outage.
5. Workspace disappearance/corruption.
6. User cancellation during side effect.
7. Tenant quota/budget exhaustion.
8. Schema/package version mismatch.
9. Security policy denial or approval timeout.
10. Evidence/artifact store temporary outage.

## Observability
Required metrics:
- request/turn count and latency p50/p95/p99;
- success/failure/retry/cancel/block rates;
- queue/lease time;
- token/input/cache/output usage;
- tool CPU/memory/wall time;
- direct and allocated cost per run/node/tenant;
- policy/gate denial counts;
- recovery/replay counts;
- artifact/event storage volume.

Required tracing spans follow:
`task → workflow-node → agent-turn → context-build → model-call → policy-decision → tool-call → observation → checkpoint → verification`.

## Security acceptance
- no cross-tenant identifiers may resolve resources without authorization;
- no plaintext secret persisted in event payload/context/artifact;
- all privileged actions are attributable to user/agent/package/policy version;
- unsafe package/script/tool content cannot bypass Tool Gateway;
- least-privilege credential TTL shorter than workspace lease unless policy exception.

## Testing
### Unit
Schema validation, state transitions, policy branches, timeout/cancel, serialization/version compatibility.

### Contract
Golden input/output fixtures and provider/tool/workspace conformance.

### Integration
Postgres + event bus + object store + Temporal + sandbox in disposable environment.

### Chaos
Kill/restart at side-effect boundaries, network partitions, duplicated deliveries, stale checkpoints.

### Security
Prompt injection, data exfiltration, path traversal, symlink escape, secret leakage and destructive command attempts.

### Performance
Load test at expected production concurrency plus 2× burst; define saturation and backpressure behavior.

## Definition of Done
- [ ] Public/internal API contract versioned and documented.
- [ ] DB migrations reversible or compensated.
- [ ] All mutations idempotent/reconcilable.
- [ ] Tenant isolation test suite passes.
- [ ] Failure injection suite passes.
- [ ] OTel traces join end-to-end.
- [ ] Cost attribution reconciles with provider/infrastructure bill sample.
- [ ] Security review and threat model signed off.
- [ ] Runbook for incident/recovery/rollback exists.
- [ ] Golden repository benchmark demonstrates target success rate.
- [ ] No task can report unsupported success without required evidence.

## Implementation task breakdown
1. Freeze types/contracts and versioning policy.
2. Implement in-memory reference adapter for deterministic tests.
3. Implement PostgreSQL/object-store production persistence if applicable.
4. Add Temporal integration and lifecycle semantics.
5. Add multi-tenant authorization and policy enforcement.
6. Add OpenTelemetry and cost metering.
7. Add failure injection + security tests.
8. Add migration/rollback/runbook.
9. Run Golden Repo benchmark and publish acceptance report.
10. Enable feature flag → canary tenants → general availability.

## Dependencies
See `docs/implementation-roadmap.md` dependency DAG. This Skill must consume shared contracts from `/contracts` rather than inventing private incompatible envelopes.

## Tags
security, policy, action-firewall
