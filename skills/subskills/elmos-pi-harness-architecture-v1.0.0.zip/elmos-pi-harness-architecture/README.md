# elmos-pi-harness-architecture v1.0.0

Production-grade Skills Package for building Elmos into a SOTA repository-level software engineering harness.

**Positioning:** Pi-style minimal/extensible harness core + durable execution + semantic repository intelligence + deterministic transformations + autonomous verification + enterprise operations.

## Package map
- `SKILL.md` master contract
- `architecture/` target architecture and kernel boundaries
- `runtime/` agent loop, context, planner, router, transformations
- `data/` persistent schema and event model
- `security/` enterprise controls
- `evals/` benchmark and production gates
- `commercial/` moat and unit economics
- `roadmap/` milestones and go/no-go gates
- `examples/` package/workflow samples

## SOTA thesis
Performance comes from the system, not a single model: context selection, decomposition, model routing, reliable tools, verification, recovery, deterministic transforms, and continuous evals.
