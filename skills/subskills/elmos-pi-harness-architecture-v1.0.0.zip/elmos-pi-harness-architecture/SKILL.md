---
name: elmos-pi-harness-architecture
description: Build Elmos as a SOTA repository-level software engineering harness by absorbing Pi's minimal/extensible agent runtime and extending it with durable execution, semantic repo context, multi-agent orchestration, model routing, deterministic transformations, verification, observability, enterprise security, and commercial-grade governance.
version: 1.0.0
license: Proprietary
---

# Elmos Pi Harness Architecture

## Mission
Turn Elmos into a **Repository Engineering Operating System** rather than a single coding agent.

## Pi capabilities to absorb
1. Minimal agent loop with a small trusted core.
2. Unified multi-provider model abstraction.
3. Tree-structured sessions and branching.
4. Context engineering hooks.
5. Progressive-disclosure skills.
6. Prompt templates and reusable workflows.
7. Extensions for tools, commands, events, UI, providers.
8. Packages bundling extensions + skills + prompts.
9. Interactive, print/JSON, RPC, and SDK modes.
10. Mid-session model switching.
11. Steering/follow-up during execution.
12. Self-extension of the harness.

## Elmos extensions beyond Pi
1. Durable, resumable, multi-tenant task DAGs.
2. Semantic Repository Graph (AST + symbols + dependencies + runtime evidence).
3. Hierarchical planner and dynamic replanning.
4. Native sub-agent orchestration with budgets and isolation.
5. Multi-model routing and speculative parallelism.
6. Deterministic AST/IR transformations.
7. Automatic compile/test/lint/security/performance/UI validation.
8. Recovery after network/server failure.
9. Cost, token, ETA and business-margin accounting.
10. Enterprise policy, approvals, sandboxing and audit.
11. Golden-route certification for >500k and >1M LOC repositories.
12. Benchmark harness and regression gates.

## Execution loop
Observe → Build Context → Plan/Select Skill → Route Model → Execute Tool → Validate → Diagnose → Repair/Replan → Checkpoint → Continue/Complete

## Non-negotiable rules
- Kernel remains domain-agnostic.
- Long-running state never lives only in process memory.
- Every mutation is attributable, diffable, reversible where feasible, auditable.
- Context is selected, not dumped.
- Skills are progressively disclosed.
- Model choice is decoupled from agent logic.
- Verification is first-class.
- Large-repo workflows are incremental.
- Machine wall-clock ETA is reported separately from human effort.
- Pause/resume/cancel and crash recovery are mandatory.
- Customer-visible results carry provenance and validation evidence.
