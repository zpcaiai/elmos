# Batch 01 Gate — semantic-kernel

OpenRewrite 的 LST/Parser/Visitor 思想转成 Elmos 的跨语言无损语义内核。

## Required checks

- [ ] All SKILL.md frontmatter/schema validations pass.
- [ ] All P0 capabilities in this batch have automated tests.
- [ ] No unresolved critical/security failures.
- [ ] Metrics and provenance are emitted for E2E run.
- [ ] Failure injection covers at least one non-happy path per Skill.

## Skills

- [ ] `lossless-semantic-ir` acceptance criteria all pass.
- [ ] `rich-type-attribution` acceptance criteria all pass.
- [ ] `semantic-marker-metadata` acceptance criteria all pass.
- [ ] `cursor-execution-context` acceptance criteria all pass.
- [ ] `immutable-tree-transform` acceptance criteria all pass.
- [ ] `parser-roundtrip-fidelity` acceptance criteria all pass.
- [ ] `parser-capability-contract` acceptance criteria all pass.
- [ ] `native-parser-adapter` acceptance criteria all pass.
- [ ] `version-aware-parser` acceptance criteria all pass.
- [ ] `multi-format-source-model` acceptance criteria all pass.
