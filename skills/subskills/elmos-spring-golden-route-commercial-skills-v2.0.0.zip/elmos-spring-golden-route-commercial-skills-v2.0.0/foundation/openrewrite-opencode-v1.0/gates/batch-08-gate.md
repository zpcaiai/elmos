# Batch 08 Gate — recovery-safety-tools

Snapshot/恢复、副作用安全、强类型 Tool 与权限控制。

## Required checks

- [ ] All SKILL.md frontmatter/schema validations pass.
- [ ] All P0 capabilities in this batch have automated tests.
- [ ] No unresolved critical/security failures.
- [ ] Metrics and provenance are emitted for E2E run.
- [ ] Failure injection covers at least one non-happy path per Skill.

## Skills

- [ ] `git-snapshot-revert` acceptance criteria all pass.
- [ ] `session-retry-run-state` acceptance criteria all pass.
- [ ] `side-effect-interruption-fencing` acceptance criteria all pass.
- [ ] `post-crash-continuation-recovery` acceptance criteria all pass.
- [ ] `typed-tool-registry` acceptance criteria all pass.
- [ ] `schema-validated-tool-io` acceptance criteria all pass.
- [ ] `wildcard-permission-engine` acceptance criteria all pass.
- [ ] `command-resource-policy` acceptance criteria all pass.
- [ ] `doom-loop-human-intervention` acceptance criteria all pass.
- [ ] `structured-task-and-question-tools` acceptance criteria all pass.
