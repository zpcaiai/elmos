# Batch 10 Gate — elmos-fusion

把 OpenRewrite + OpenCode 机制融合成 Elmos 独有的 Repository Engineering OS。

## Required checks

- [ ] All SKILL.md frontmatter/schema validations pass.
- [ ] All P0 capabilities in this batch have automated tests.
- [ ] No unresolved critical/security failures.
- [ ] Metrics and provenance are emitted for E2E run.
- [ ] Failure injection covers at least one non-happy path per Skill.

## Skills

- [ ] `deterministic-first-router` acceptance criteria all pass.
- [ ] `recipe-agent-hybrid-planner` acceptance criteria all pass.
- [ ] `semantic-context-provider` acceptance criteria all pass.
- [ ] `semantic-patch-and-evidence-ledger` acceptance criteria all pass.
- [ ] `verification-fixpoint-completion-proof` acceptance criteria all pass.
- [ ] `migration-knowledge-graph` acceptance criteria all pass.
- [ ] `successful-patch-to-recipe-learning` acceptance criteria all pass.
- [ ] `hierarchical-context-and-repo-cache` acceptance criteria all pass.
- [ ] `side-effect-ledger-and-recovery-fencing` acceptance criteria all pass.
- [ ] `skill-marketplace-certification` acceptance criteria all pass.
