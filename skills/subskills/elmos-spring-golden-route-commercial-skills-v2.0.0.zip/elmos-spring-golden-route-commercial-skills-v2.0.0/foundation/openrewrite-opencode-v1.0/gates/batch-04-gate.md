# Batch 04 Gate — dependency-quality-intelligence

依赖/锁文件确定性更新、解析质量、TCK、测试与证据。

## Required checks

- [ ] All SKILL.md frontmatter/schema validations pass.
- [ ] All P0 capabilities in this batch have automated tests.
- [ ] No unresolved critical/security failures.
- [ ] Metrics and provenance are emitted for E2E run.
- [ ] Failure injection covers at least one non-happy path per Skill.

## Skills

- [ ] `build-model-intelligence` acceptance criteria all pass.
- [ ] `native-dependency-resolution` acceptance criteria all pass.
- [ ] `minimal-lockfile-delta` acceptance criteria all pass.
- [ ] `package-metadata-ladder` acceptance criteria all pass.
- [ ] `dependency-credential-propagation` acceptance criteria all pass.
- [ ] `lockfile-accuracy-contract` acceptance criteria all pass.
- [ ] `parser-tck` acceptance criteria all pass.
- [ ] `transformation-before-after-tests` acceptance criteria all pass.
- [ ] `transformation-benchmarks` acceptance criteria all pass.
- [ ] `parse-failure-evidence` acceptance criteria all pass.
