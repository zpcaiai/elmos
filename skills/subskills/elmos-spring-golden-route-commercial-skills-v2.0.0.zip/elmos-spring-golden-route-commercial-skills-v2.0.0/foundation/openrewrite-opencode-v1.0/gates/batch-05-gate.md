# Batch 05 Gate — repository-intelligence-cross-runtime

预计算仓库知识、跨语言 RPC、数据本地化与 Token 降本。

## Required checks

- [ ] All SKILL.md frontmatter/schema validations pass.
- [ ] All P0 capabilities in this batch have automated tests.
- [ ] No unresolved critical/security failures.
- [ ] Metrics and provenance are emitted for E2E run.
- [ ] Failure injection covers at least one non-happy path per Skill.

## Skills

- [ ] `rewrite-rpc-runtime` acceptance criteria all pass.
- [ ] `mirrored-rpc-capabilities` acceptance criteria all pass.
- [ ] `cross-runtime-data-sink` acceptance criteria all pass.
- [ ] `rpc-process-isolation` acceptance criteria all pass.
- [ ] `repository-knowledge-precompute` acceptance criteria all pass.
- [ ] `architecture-context-extractor` acceptance criteria all pass.
- [ ] `dependency-and-library-usage-index` acceptance criteria all pass.
- [ ] `coding-and-error-pattern-miner` acceptance criteria all pass.
- [ ] `method-and-test-quality-index` acceptance criteria all pass.
- [ ] `semantic-token-context-query` acceptance criteria all pass.
