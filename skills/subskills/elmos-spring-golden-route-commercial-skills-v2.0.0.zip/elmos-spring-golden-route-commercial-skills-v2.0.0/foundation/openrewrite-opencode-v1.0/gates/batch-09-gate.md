# Batch 09 Gate — integration-provider-platform

Skills/MCP/LSP/Provider/Config/Workspace/多客户端平台层。

## Required checks

- [ ] All SKILL.md frontmatter/schema validations pass.
- [ ] All P0 capabilities in this batch have automated tests.
- [ ] No unresolved critical/security failures.
- [ ] Metrics and provenance are emitted for E2E run.
- [ ] Failure injection covers at least one non-happy path per Skill.

## Skills

- [ ] `lazy-skill-discovery` acceptance criteria all pass.
- [ ] `mcp-gateway-oauth-context-budget` acceptance criteria all pass.
- [ ] `lsp-diagnostics-and-navigation` acceptance criteria all pass.
- [ ] `post-edit-format-and-patch` acceptance criteria all pass.
- [ ] `provider-model-abstraction` acceptance criteria all pass.
- [ ] `portable-request-vs-local-behavior` acceptance criteria all pass.
- [ ] `model-run-vs-provider-turn` acceptance criteria all pass.
- [ ] `stream-usage-cost-cache-runtime` acceptance criteria all pass.
- [ ] `hierarchical-enterprise-config` acceptance criteria all pass.
- [ ] `workspace-control-plane-and-multi-client` acceptance criteria all pass.
