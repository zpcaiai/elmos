# Batch 02 Gate — recipe-runtime

把确定性代码变换、组合、扫描和 fixpoint 收敛变成 Elmos 的主执行路径。

## Required checks

- [ ] All SKILL.md frontmatter/schema validations pass.
- [ ] All P0 capabilities in this batch have automated tests.
- [ ] No unresolved critical/security failures.
- [ ] Metrics and provenance are emitted for E2E run.
- [ ] Failure injection covers at least one non-happy path per Skill.

## Skills

- [ ] `deterministic-recipe-engine` acceptance criteria all pass.
- [ ] `recipe-composition-graph` acceptance criteria all pass.
- [ ] `recipe-preconditions` acceptance criteria all pass.
- [ ] `scanning-recipe-accumulator` acceptance criteria all pass.
- [ ] `scan-generate-edit-lifecycle` acceptance criteria all pass.
- [ ] `multi-cycle-fixpoint` acceptance criteria all pass.
- [ ] `recipe-option-schema` acceptance criteria all pass.
- [ ] `recipe-descriptor-introspection` acceptance criteria all pass.
- [ ] `recipe-change-attribution` acceptance criteria all pass.
- [ ] `recipe-effort-estimation` acceptance criteria all pass.
