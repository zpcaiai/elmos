# Batch 03 Gate — recipe-ecosystem-patterns

Recipe Marketplace、数据表、模板匹配和语义搜索。

## Required checks

- [ ] All SKILL.md frontmatter/schema validations pass.
- [ ] All P0 capabilities in this batch have automated tests.
- [ ] No unresolved critical/security failures.
- [ ] Metrics and provenance are emitted for E2E run.
- [ ] Failure injection covers at least one non-happy path per Skill.

## Skills

- [ ] `recipe-data-table` acceptance criteria all pass.
- [ ] `recipe-marketplace` acceptance criteria all pass.
- [ ] `recipe-bundle-resolver` acceptance criteria all pass.
- [ ] `recipe-marketplace-validation` acceptance criteria all pass.
- [ ] `semantic-template-engine` acceptance criteria all pass.
- [ ] `constrained-capture-matching` acceptance criteria all pass.
- [ ] `variadic-pattern-matching` acceptance criteria all pass.
- [ ] `dynamic-template-builder` acceptance criteria all pass.
- [ ] `lenient-semantic-comparator` acceptance criteria all pass.
- [ ] `semantic-search-engine` acceptance criteria all pass.
