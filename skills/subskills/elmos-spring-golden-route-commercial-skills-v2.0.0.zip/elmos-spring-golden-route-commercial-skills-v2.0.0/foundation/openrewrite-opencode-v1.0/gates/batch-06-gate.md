# Batch 06 Gate — agent-runtime

OpenCode Agent/Subagent/角色与任务分解机制的 Elmos 化。

## Required checks

- [ ] All SKILL.md frontmatter/schema validations pass.
- [ ] All P0 capabilities in this batch have automated tests.
- [ ] No unresolved critical/security failures.
- [ ] Metrics and provenance are emitted for E2E run.
- [ ] Failure injection covers at least one non-happy path per Skill.

## Skills

- [ ] `agent-registry` acceptance criteria all pass.
- [ ] `primary-subagent-hierarchy` acceptance criteria all pass.
- [ ] `plan-explore-scout-agents` acceptance criteria all pass.
- [ ] `hidden-system-agents` acceptance criteria all pass.
- [ ] `per-agent-model-routing` acceptance criteria all pass.
- [ ] `agent-step-budget` acceptance criteria all pass.
- [ ] `parallel-subagent-execution` acceptance criteria all pass.
- [ ] `parent-child-session-graph` acceptance criteria all pass.
- [ ] `agent-command-playbooks` acceptance criteria all pass.
- [ ] `safe-agent-role-switching` acceptance criteria all pass.
