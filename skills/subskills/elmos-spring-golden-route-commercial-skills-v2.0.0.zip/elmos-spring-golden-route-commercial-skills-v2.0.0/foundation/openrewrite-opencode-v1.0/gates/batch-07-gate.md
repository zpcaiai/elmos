# Batch 07 Gate — durable-session-context

Durable Session、事件流、上下文 epoch、压缩和断线重连。

## Required checks

- [ ] All SKILL.md frontmatter/schema validations pass.
- [ ] All P0 capabilities in this batch have automated tests.
- [ ] No unresolved critical/security failures.
- [ ] Metrics and provenance are emitted for E2E run.
- [ ] Failure injection covers at least one non-happy path per Skill.

## Skills

- [ ] `durable-session-inbox` acceptance criteria all pass.
- [ ] `queue-steer-delivery` acceptance criteria all pass.
- [ ] `session-event-sourcing` acceptance criteria all pass.
- [ ] `session-run-coordinator` acceptance criteria all pass.
- [ ] `wake-resume-interrupt` acceptance criteria all pass.
- [ ] `provider-turn-persistence` acceptance criteria all pass.
- [ ] `durable-tool-settlement` acceptance criteria all pass.
- [ ] `context-epoch` acceptance criteria all pass.
- [ ] `context-compaction` acceptance criteria all pass.
- [ ] `reconnect-safe-history` acceptance criteria all pass.
