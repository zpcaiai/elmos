# Priority Roadmap

## Wave A — P0 semantic & deterministic foundation
Batch 01 + 02 + core of 04.

Exit gate:
- lossless parse/print on target language corpus
- type-aware semantic queries
- deterministic recipe before/after tests
- fixpoint convergence detection
- change attribution with zero unowned edits

## Wave B — P0 repository intelligence & runtime
Batch 05 + 06.

Exit gate:
- precomputed repository context can answer architecture/dependency/code-usage questions
- Agent receives semantic slices rather than broad file dumps
- primary/subagent DAG and per-agent model/permission routing work

## Wave C — P0 durable execution and safety
Batch 07 + 08.

Exit gate:
- crash/reconnect simulation passes
- tool calls settle durably
- snapshot/revert passes on dirty worktrees
- duplicated requests do not duplicate side effects
- permissions block before handler execution

## Wave D — P0 Elmos fusion
Batch 10.

Exit gate:
- one repository modernization scenario runs Recipe→Agent→Verify→Repair→CompletionProof end-to-end
- no task can reach completed with unknown mandatory checks
- successful repeated patches enter candidate Recipe pipeline

## Wave E — P1 ecosystem/platform
Batch 03 + 09.

Exit gate:
- Recipe/Skill marketplace supports lazy bundles and certification
- MCP/LSP/provider/config/workspace adapters are capability-negotiated
- context/tool catalogs stay within configured token budgets
