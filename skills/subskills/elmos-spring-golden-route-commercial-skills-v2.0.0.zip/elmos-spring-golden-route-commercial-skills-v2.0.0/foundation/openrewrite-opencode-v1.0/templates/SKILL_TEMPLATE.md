---
name: example-skill
description: One precise sentence describing when and why to use this skill.
license: "Elmos skill specification"
compatibility: "elmos,codex,claude-code,opencode"
metadata:
  batch: "XX"
  priority: "P1"
  source_projects: "derived"
  spec_version: "1.0.0"
---

# Example Skill

## Goal
...

## Capabilities to implement
- ...

## Non-negotiable contract
- ...

## Execution workflow
1. ...

## Implementation tasks
- [ ] ...

## Acceptance criteria
- [ ] ...

## Elmos integration points
- `...`

## Upstream inspiration
- ...
