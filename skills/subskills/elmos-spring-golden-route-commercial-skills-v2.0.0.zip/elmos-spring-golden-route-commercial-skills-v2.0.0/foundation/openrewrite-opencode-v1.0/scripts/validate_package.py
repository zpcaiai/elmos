#!/usr/bin/env python3
from pathlib import Path
import re, sys, json

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root/"manifest/skills-index.json").read_text(encoding="utf-8"))
errors = []
seen = set()
rx = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")

for skill in manifest["skills"]:
    p = root / skill["path"]
    if not p.exists():
        errors.append(f"missing: {p}")
        continue
    text = p.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        errors.append(f"frontmatter missing: {p}")
    m = re.search(r"^name:\s*(.+)$", text, re.M)
    if not m:
        errors.append(f"name missing: {p}")
        continue
    name = m.group(1).strip()
    if name != skill["name"] or name != p.parent.name:
        errors.append(f"name mismatch: {p}")
    if not rx.fullmatch(name) or len(name) > 64:
        errors.append(f"invalid skill name: {name}")
    if name in seen:
        errors.append(f"duplicate skill name: {name}")
    seen.add(name)
    if "## Acceptance criteria" not in text:
        errors.append(f"acceptance missing: {name}")
    if "## Upstream inspiration" not in text:
        errors.append(f"source provenance missing: {name}")

if len(seen) != manifest["skill_count"]:
    errors.append(f"count mismatch: {len(seen)} != {manifest['skill_count']}")

if errors:
    print("\n".join(errors))
    sys.exit(1)
print(f"OK: {len(seen)} skills validated; feature matrix={manifest['feature_count']} derived features")
