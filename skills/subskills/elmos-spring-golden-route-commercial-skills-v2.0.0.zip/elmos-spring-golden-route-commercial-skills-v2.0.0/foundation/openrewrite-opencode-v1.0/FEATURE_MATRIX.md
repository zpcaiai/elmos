# Feature Matrix

下面将上游机制映射到 Elmos Skill。一个 Skill 可以吸收多个上游特性，因此 Feature 数量高于 Skill 数量。

| # | Upstream-derived feature | Elmos skill | Batch | Priority | Source |
|---:|---|---|---:|---|---|
| 1 | 保留 AST 结构、空白、注释、源位置与打印所需信息 | `lossless-semantic-ir` | 01 | P0 | openrewrite |
| 2 | 将符号、类型、作用域、导入、继承和调用关系作为一等语义 | `lossless-semantic-ir` | 01 | P0 | openrewrite |
| 3 | 支持 SourceFile 创建、修改、删除而不丢失非目标文本 | `lossless-semantic-ir` | 01 | P0 | openrewrite |
| 4 | 允许语言专属节点通过扩展类型而不是降级成 Unknown | `lossless-semantic-ir` | 01 | P0 | openrewrite |
| 5 | 对标识符、调用、字段、泛型、继承等建立稳定类型引用 | `rich-type-attribution` | 01 | P0 | openrewrite |
| 6 | 区分未知、未实现、解析失败，禁止已知节点退化成 Unknown | `rich-type-attribution` | 01 | P0 | openrewrite |
| 7 | 支持缺失类型信息时的显式降级策略和置信度 | `rich-type-attribution` | 01 | P0 | openrewrite |
| 8 | 向 Recipe/Agent 暴露 type-aware 查询而非纯文本猜测 | `rich-type-attribution` | 01 | P0 | openrewrite |
| 9 | Marker 与语法树结构解耦，可增删而不破坏打印 | `semantic-marker-metadata` | 01 | P0 | openrewrite |
| 10 | 记录 Git provenance、构建信息、搜索命中和 Recipe provenance | `semantic-marker-metadata` | 01 | P0 | openrewrite |
| 11 | 支持序列化、版本化和跨运行比较 | `semantic-marker-metadata` | 01 | P0 | openrewrite |
| 12 | 禁止把执行期元数据硬编码进语言 AST | `semantic-marker-metadata` | 01 | P0 | openrewrite |
| 13 | Cursor 可访问父链、根级共享状态和当前节点语义 | `cursor-execution-context` | 01 | P0 | openrewrite |
| 14 | ExecutionContext 管理运行级状态、错误、缓存和数据表 sink | `cursor-execution-context` | 01 | P0 | openrewrite |
| 15 | 每 cycle 创建安全 root context，避免静态 visitor 泄漏状态 | `cursor-execution-context` | 01 | P0 | openrewrite |
| 16 | 共享 type/template cache 但显式清理运行期消息 | `cursor-execution-context` | 01 | P0 | openrewrite |
| 17 | visitor 不原地修改节点 | `immutable-tree-transform` | 01 | P0 | openrewrite |
| 18 | 删除、替换、新增有统一返回语义 | `immutable-tree-transform` | 01 | P0 | openrewrite |
| 19 | 结构共享减少不必要复制 | `immutable-tree-transform` | 01 | P0 | openrewrite |
| 20 | 变更归属到具体 recipe/visitor，支持差异追踪 | `immutable-tree-transform` | 01 | P0 | openrewrite |
| 21 | 未修改源码 parse/print 后字节或规范化等价 | `parser-roundtrip-fidelity` | 01 | P0 | openrewrite |
| 22 | 保留注释、空白、换行、编码和非语义 token | `parser-roundtrip-fidelity` | 01 | P0 | openrewrite |
| 23 | 对无法解析片段使用显式 Quark/Unknown 边界而非静默删除 | `parser-roundtrip-fidelity` | 01 | P0 | openrewrite |
| 24 | 每种语言维护 round-trip corpus 与回归用例 | `parser-roundtrip-fidelity` | 01 | P0 | openrewrite |
| 25 | 声明 syntax/type/printer/template/refactor 支持级别 | `parser-capability-contract` | 01 | P0 | openrewrite |
| 26 | 运行前 capability negotiation，禁止调用不支持能力 | `parser-capability-contract` | 01 | P0 | openrewrite |
| 27 | 按语言版本和框架版本选择 parser | `parser-capability-contract` | 01 | P0 | openrewrite |
| 28 | 能力缺失返回结构化原因和替代路径 | `parser-capability-contract` | 01 | P0 | openrewrite |
| 29 | 定义 Parser→IR、IR→Printer、Type Attribution 三个独立适配面 | `native-parser-adapter` | 01 | P0 | openrewrite |
| 30 | 优先利用语言官方/成熟 parser 的准确性 | `native-parser-adapter` | 01 | P0 | openrewrite |
| 31 | 适配器可独立升级和做兼容性测试 | `native-parser-adapter` | 01 | P0 | openrewrite |
| 32 | parser 失败保留原始源码和可诊断证据 | `native-parser-adapter` | 01 | P0 | openrewrite |
| 33 | 识别 language level、编译目标和实验语法 | `version-aware-parser` | 01 | P0 | openrewrite |
| 34 | 支持同语言多 parser 版本并存 | `version-aware-parser` | 01 | P0 | openrewrite |
| 35 | 变换前验证目标版本是否能表达新语法 | `version-aware-parser` | 01 | P0 | openrewrite |
| 36 | 版本升级 Recipe 与 parser 升级解耦 | `version-aware-parser` | 01 | P0 | openrewrite |
| 37 | 覆盖 Maven/Gradle、JSON/YAML/XML/TOML/HCL/Properties/Protobuf/Docker 等类别 | `multi-format-source-model` | 01 | P0 | openrewrite |
| 38 | 配置节点同样支持无损 parse/print 与 Recipe | `multi-format-source-model` | 01 | P0 | openrewrite |
| 39 | 代码变换与 build/config 变换可组成一个事务 | `multi-format-source-model` | 01 | P0 | openrewrite |
| 40 | 跨文件引用通过统一 SourceFile ID 和 provenance 关联 | `multi-format-source-model` | 01 | P0 | openrewrite |
| 41 | Recipe 具名、可描述、可版本化、可配置 | `deterministic-recipe-engine` | 02 | P0 | openrewrite |
| 42 | Recipe 返回确定 changeset，不依赖模型随机性 | `deterministic-recipe-engine` | 02 | P0 | openrewrite |
| 43 | 优先把机械性迁移、API 替换、安全修复交给 Recipe | `deterministic-recipe-engine` | 02 | P0 | openrewrite |
| 44 | LLM 仅处理规则无法覆盖的语义歧义 | `deterministic-recipe-engine` | 02 | P0 | openrewrite |
| 45 | Recipe 可包含子 Recipe 并形成有向组合图 | `recipe-composition-graph` | 02 | P0 | openrewrite |
| 46 | 保留触发变更的 recipe stack | `recipe-composition-graph` | 02 | P0 | openrewrite |
| 47 | 支持顺序、条件、互斥和聚合组合 | `recipe-composition-graph` | 02 | P0 | openrewrite |
| 48 | 组合图可静态检查循环与未满足依赖 | `recipe-composition-graph` | 02 | P0 | openrewrite |
| 49 | 前置条件与真正 edit visitor 分离 | `recipe-preconditions` | 02 | P0 | openrewrite |
| 50 | precondition 可组合 AND/OR/NOT | `recipe-preconditions` | 02 | P0 | openrewrite |
| 51 | 未满足时保持源码零修改 | `recipe-preconditions` | 02 | P0 | openrewrite |
| 52 | 输出为何跳过的结构化证据 | `recipe-preconditions` | 02 | P0 | openrewrite |
| 53 | scan 阶段只收集事实与异常 | `scanning-recipe-accumulator` | 02 | P0 | openrewrite |
| 54 | Accumulator 可汇总跨文件符号、依赖和框架使用 | `scanning-recipe-accumulator` | 02 | P0 | openrewrite |
| 55 | generate/edit 读取同一聚合状态 | `scanning-recipe-accumulator` | 02 | P0 | openrewrite |
| 56 | 支持跨模块迁移需要的全局视图 | `scanning-recipe-accumulator` | 02 | P0 | openrewrite |
| 57 | scan 构建事实和决策输入 | `scan-generate-edit-lifecycle` | 02 | P0 | openrewrite |
| 58 | generate 创建适配器/配置/测试等新文件 | `scan-generate-edit-lifecycle` | 02 | P0 | openrewrite |
| 59 | edit 对现有源码做最小修改 | `scan-generate-edit-lifecycle` | 02 | P0 | openrewrite |
| 60 | 阶段间有不可变 checkpoint 和审计数据 | `scan-generate-edit-lifecycle` | 02 | P0 | openrewrite |
| 61 | 支持 minCycles/maxCycles | `multi-cycle-fixpoint` | 02 | P0 | openrewrite |
| 62 | Recipe 可声明变更是否触发下一轮 | `multi-cycle-fixpoint` | 02 | P0 | openrewrite |
| 63 | 每轮记录变化集合和统计 | `multi-cycle-fixpoint` | 02 | P0 | openrewrite |
| 64 | 到达上限仍未收敛时失败并输出振荡证据 | `multi-cycle-fixpoint` | 02 | P0 | openrewrite |
| 65 | 参数包含名称、类型、描述、示例、必填、合法值 | `recipe-option-schema` | 02 | P0 | openrewrite |
| 66 | 支持从字段/构造器/配置声明生成 descriptor | `recipe-option-schema` | 02 | P0 | openrewrite |
| 67 | 运行前 schema 验证并 fail-fast | `recipe-option-schema` | 02 | P0 | openrewrite |
| 68 | UI/CLI/Agent 可由同一 schema 自动生成输入 | `recipe-option-schema` | 02 | P0 | openrewrite |
| 69 | 无需实例化全部逻辑即可浏览目录 | `recipe-descriptor-introspection` | 02 | P0 | openrewrite |
| 70 | descriptor 包含 displayName/description/tags/options/dataTables | `recipe-descriptor-introspection` | 02 | P0 | openrewrite |
| 71 | 可用于搜索、文档和 Agent tool definition | `recipe-descriptor-introspection` | 02 | P0 | openrewrite |
| 72 | descriptor 与实际实现做完整性校验 | `recipe-descriptor-introspection` | 02 | P0 | openrewrite |
| 73 | before/after 与 recipe stack 一起保存 | `recipe-change-attribution` | 02 | P0 | openrewrite |
| 74 | 无 Recipe provenance 的意外变更视为框架错误 | `recipe-change-attribution` | 02 | P0 | openrewrite |
| 75 | 输出 Git-style diff 与语义位置 | `recipe-change-attribution` | 02 | P0 | openrewrite |
| 76 | 新建/删除/二进制/忽略空白有统一处理 | `recipe-change-attribution` | 02 | P0 | openrewrite |
| 77 | Recipe 可声明 estimated effort per occurrence | `recipe-effort-estimation` | 02 | P0 | openrewrite |
| 78 | 按 changeset 聚合潜在人工节省 | `recipe-effort-estimation` | 02 | P0 | openrewrite |
| 79 | 同时记录机器 wall-clock、token、CPU 和模型费用 | `recipe-effort-estimation` | 02 | P0 | openrewrite |
| 80 | 用于 ROI、调度优先级与客户账单解释 | `recipe-effort-estimation` | 02 | P0 | openrewrite |
| 81 | 表 schema 和列描述由 Recipe 声明 | `recipe-data-table` | 03 | P1 | openrewrite |
| 82 | 支持 InMemory/CSV/NoOp/自定义 sink | `recipe-data-table` | 03 | P1 | openrewrite |
| 83 | 数据表与 changeset 同一 run ID 关联 | `recipe-data-table` | 03 | P1 | openrewrite |
| 84 | 适合依赖清单、搜索命中、错误、质量指标等大结果 | `recipe-data-table` | 03 | P1 | openrewrite |
| 85 | 按 ecosystem/package/name/category 建立目录 | `recipe-marketplace` | 03 | P1 | openrewrite |
| 86 | 支持版本无关 catalog 与 resolved/requested version | `recipe-marketplace` | 03 | P1 | openrewrite |
| 87 | Recipe 可出现在多个分类而保持唯一身份 | `recipe-marketplace` | 03 | P1 | openrewrite |
| 88 | 未知 metadata 保留以支持向前兼容 | `recipe-marketplace` | 03 | P1 | openrewrite |
| 89 | 核心只依赖 ecosystem resolver 接口 | `recipe-bundle-resolver` | 03 | P1 | openrewrite |
| 90 | 先 resolve bundle，再 describe/prepare Recipe | `recipe-bundle-resolver` | 03 | P1 | openrewrite |
| 91 | 仅在实际执行时加载实现，降低启动和上下文成本 | `recipe-bundle-resolver` | 03 | P1 | openrewrite |
| 92 | 新生态通过插件增加而不修改核心 | `recipe-bundle-resolver` | 03 | P1 | openrewrite |
| 93 | 检测目录存在但实现缺失的 phantom recipe | `recipe-marketplace-validation` | 03 | P1 | openrewrite |
| 94 | 检测实现存在但目录漏登记的 missing recipe | `recipe-marketplace-validation` | 03 | P1 | openrewrite |
| 95 | 校验 displayName/description/schema 规范 | `recipe-marketplace-validation` | 03 | P1 | openrewrite |
| 96 | CI 中阻止 stale marketplace 发布 | `recipe-marketplace-validation` | 03 | P1 | openrewrite |
| 97 | pattern 和 template 均先解析为语义树 | `semantic-template-engine` | 03 | P1 | openrewrite |
| 98 | 模板参数保留 AST 类型和格式语义 | `semantic-template-engine` | 03 | P1 | openrewrite |
| 99 | 支持上下文声明辅助 type attribution | `semantic-template-engine` | 03 | P1 | openrewrite |
| 100 | 替换后再次走 parser/printer 质量门禁 | `semantic-template-engine` | 03 | P1 | openrewrite |
| 101 | capture 支持类型/值/符号/父链约束 | `constrained-capture-matching` | 03 | P1 | openrewrite |
| 102 | 约束可用 and/or/not 组合 | `constrained-capture-matching` | 03 | P1 | openrewrite |
| 103 | capture 属性可深层访问并用于模板 | `constrained-capture-matching` | 03 | P1 | openrewrite |
| 104 | 结构匹配和语义过滤分两阶段以提升效率 | `constrained-capture-matching` | 03 | P1 | openrewrite |
| 105 | zero-or-more/one-or-more capture | `variadic-pattern-matching` | 03 | P1 | openrewrite |
| 106 | 序列捕获保持原顺序和 formatting | `variadic-pattern-matching` | 03 | P1 | openrewrite |
| 107 | 支持前后锚点避免贪婪误匹配 | `variadic-pattern-matching` | 03 | P1 | openrewrite |
| 108 | 用于 API 参数扩展、包装语句和批量注解迁移 | `variadic-pattern-matching` | 03 | P1 | openrewrite |
| 109 | Builder API 与 template literal 共用底层解析 | `dynamic-template-builder` | 03 | P1 | openrewrite |
| 110 | 静态片段与动态 code fragment 时间语义明确 | `dynamic-template-builder` | 03 | P1 | openrewrite |
| 111 | 允许基于 capture 结果生成不同代码结构 | `dynamic-template-builder` | 03 | P1 | openrewrite |
| 112 | 动态生成仍必须通过 parser 和 schema 校验 | `dynamic-template-builder` | 03 | P1 | openrewrite |
| 113 | 严格/宽松模式显式配置 | `lenient-semantic-comparator` | 03 | P1 | openrewrite |
| 114 | 仅对声明的 type-related 字段允许 unknown wildcard | `lenient-semantic-comparator` | 03 | P1 | openrewrite |
| 115 | 结构、名称、常量等其它语义仍严格比较 | `lenient-semantic-comparator` | 03 | P1 | openrewrite |
| 116 | 记录宽松匹配的置信度和验证要求 | `lenient-semantic-comparator` | 03 | P1 | openrewrite |
| 117 | 按类型、方法签名、继承、注解、API 使用搜索 | `semantic-search-engine` | 03 | P1 | openrewrite |
| 118 | 查询返回最小语义切片而不是整个文件 | `semantic-search-engine` | 03 | P1 | openrewrite |
| 119 | 搜索结果可输出 DataTable 和 Search Marker | `semantic-search-engine` | 03 | P1 | openrewrite |
| 120 | 结果可直接驱动 Recipe/Agent 规划 | `semantic-search-engine` | 03 | P1 | openrewrite |
| 121 | Maven/Gradle/npm/Python 等 manifest 与源码语义关联 | `build-model-intelligence` | 04 | P0 | openrewrite |
| 122 | 区分直接、传递、约束、插件和 BOM | `build-model-intelligence` | 04 | P0 | openrewrite |
| 123 | 识别 repository/index、镜像和凭据需求 | `build-model-intelligence` | 04 | P0 | openrewrite |
| 124 | 变换后自动验证构建图一致性 | `build-model-intelligence` | 04 | P0 | openrewrite |
| 125 | 通过 HTTP/index metadata 完成解析 | `native-dependency-resolution` | 04 | P0 | openrewrite |
| 126 | 宿主统一注入代理、TLS、凭据和缓存 | `native-dependency-resolution` | 04 | P0 | openrewrite |
| 127 | 避免临时目录丢失项目级 package manager 配置 | `native-dependency-resolution` | 04 | P0 | openrewrite |
| 128 | 解析失败必须给出包/索引/版本级结构化原因 | `native-dependency-resolution` | 04 | P0 | openrewrite |
| 129 | 只移动目标包及其依赖约束真正迫使变化的节点 | `minimal-lockfile-delta` | 04 | P0 | openrewrite |
| 130 | 未受影响 entry 尽量字节级保持 | `minimal-lockfile-delta` | 04 | P0 | openrewrite |
| 131 | 可解释为何某个 transitive pin 被迫改变 | `minimal-lockfile-delta` | 04 | P0 | openrewrite |
| 132 | 减少遗留依赖导致的无关失败面 | `minimal-lockfile-delta` | 04 | P0 | openrewrite |
| 133 | 优先标准 metadata sidecar/API | `package-metadata-ladder` | 04 | P0 | openrewrite |
| 134 | 其次 Range read 包内 metadata | `package-metadata-ladder` | 04 | P0 | openrewrite |
| 135 | 再退到完整包下载 | `package-metadata-ladder` | 04 | P0 | openrewrite |
| 136 | 无法可信获取时 fail loud，绝不猜测依赖 | `package-metadata-ladder` | 04 | P0 | openrewrite |
| 137 | 配置优先级显式且可审计 | `dependency-credential-propagation` | 04 | P0 | openrewrite, opencode |
| 138 | 凭据不写入锁文件、日志或模型上下文 | `dependency-credential-propagation` | 04 | P0 | openrewrite, opencode |
| 139 | 按 host/scopes 最小授权 | `dependency-credential-propagation` | 04 | P0 | openrewrite, opencode |
| 140 | 所有网络访问经统一 transport/policy layer | `dependency-credential-propagation` | 04 | P0 | openrewrite, opencode |
| 141 | 目标 package manager 的 verify/deploy 等价检查通过 | `lockfile-accuracy-contract` | 04 | P0 | openrewrite |
| 142 | artifact digest 来自可信索引 | `lockfile-accuracy-contract` | 04 | P0 | openrewrite |
| 143 | 内部 dependency constraints 自洽 | `lockfile-accuracy-contract` | 04 | P0 | openrewrite |
| 144 | 无法证明正确时不输出新 lock | `lockfile-accuracy-contract` | 04 | P0 | openrewrite |
| 145 | 覆盖语言规范和真实项目 corpus | `parser-tck` | 04 | P0 | openrewrite |
| 146 | 同语言不同实现/版本共享测试用例 | `parser-tck` | 04 | P0 | openrewrite |
| 147 | 检测 parser/printer/type attribution 回归 | `parser-tck` | 04 | P0 | openrewrite |
| 148 | TCK 结果进入能力注册和发布门禁 | `parser-tck` | 04 | P0 | openrewrite |
| 149 | 正例、反例、边界、幂等性全覆盖 | `transformation-before-after-tests` | 04 | P0 | openrewrite |
| 150 | 同一 Recipe 二次运行应无变化或满足显式多 cycle 契约 | `transformation-before-after-tests` | 04 | P0 | openrewrite |
| 151 | 异常输入保持源码并输出错误证据 | `transformation-before-after-tests` | 04 | P0 | openrewrite |
| 152 | fixture 可自动生成回归最小化样本 | `transformation-before-after-tests` | 04 | P0 | openrewrite |
| 153 | 记录 parse/scan/edit/print/verify 分段耗时 | `transformation-benchmarks` | 04 | P0 | openrewrite, opencode |
| 154 | 大仓库关注首次构建与增量运行 | `transformation-benchmarks` | 04 | P0 | openrewrite, opencode |
| 155 | 测内存、CPU、I/O、token、cache hit | `transformation-benchmarks` | 04 | P0 | openrewrite, opencode |
| 156 | 性能回归超过阈值阻止核心发布 | `transformation-benchmarks` | 04 | P0 | openrewrite, opencode |
| 157 | 保留原始文本、位置、parser/version 和异常链 | `parse-failure-evidence` | 04 | P0 | openrewrite |
| 158 | 失败节点不被静默删除或自动改写 | `parse-failure-evidence` | 04 | P0 | openrewrite |
| 159 | 聚合 ParseFailures DataTable | `parse-failure-evidence` | 04 | P0 | openrewrite |
| 160 | 可触发 parser fallback 或 Agent 专门修复但需人工/验证边界 | `parse-failure-evidence` | 04 | P0 | openrewrite |
| 161 | Host 与语言 runtime 分离进程生命周期 | `rewrite-rpc-runtime` | 05 | P0 | openrewrite |
| 162 | 协议覆盖 prepare/visit/batch/generate/print 等语义操作 | `rewrite-rpc-runtime` | 05 | P0 | openrewrite |
| 163 | 消息 schema 可版本协商 | `rewrite-rpc-runtime` | 05 | P0 | openrewrite |
| 164 | 远端失败转换为结构化错误而非死锁 | `rewrite-rpc-runtime` | 05 | P0 | openrewrite |
| 165 | 本地开放接口与 wire-level closed enum 分离 | `mirrored-rpc-capabilities` | 05 | P0 | openrewrite |
| 166 | 发送最小可序列化 descriptor/config | `mirrored-rpc-capabilities` | 05 | P0 | openrewrite |
| 167 | capability negotiation 在执行前完成 | `mirrored-rpc-capabilities` | 05 | P0 | openrewrite |
| 168 | 不支持的自定义宿主实现明确降级或失败 | `mirrored-rpc-capabilities` | 05 | P0 | openrewrite |
| 169 | 避免逐行结果穿越 RPC | `cross-runtime-data-sink` | 05 | P0 | openrewrite |
| 170 | CSV/对象存储等 sink 由各 runtime 本地实现 | `cross-runtime-data-sink` | 05 | P0 | openrewrite |
| 171 | header/schema mismatch fail-loud | `cross-runtime-data-sink` | 05 | P0 | openrewrite |
| 172 | 压缩/归档放在 run 结束后统一执行 | `cross-runtime-data-sink` | 05 | P0 | openrewrite |
| 173 | 每个并发单元拥有隔离 runtime 或严格租约 | `rpc-process-isolation` | 05 | P0 | openrewrite |
| 174 | RPC 测试强制 timeout | `rpc-process-isolation` | 05 | P0 | openrewrite |
| 175 | 进程崩溃不污染其它 task | `rpc-process-isolation` | 05 | P0 | openrewrite |
| 176 | 临时工作目录和句柄在 run 完成后回收 | `rpc-process-isolation` | 05 | P0 | openrewrite |
| 177 | 生成 architecture/dependency/library/error/test/method 等索引 | `repository-knowledge-precompute` | 05 | P0 | openrewrite |
| 178 | 索引按 Git tree/文件 hash 增量更新 | `repository-knowledge-precompute` | 05 | P0 | openrewrite |
| 179 | Agent 优先查询结构化上下文，源码仅作按需下钻 | `repository-knowledge-precompute` | 05 | P0 | openrewrite |
| 180 | 所有预计算结果带生成器版本和 provenance | `repository-knowledge-precompute` | 05 | P0 | openrewrite |
| 181 | 模块、服务、数据库、消息、外部调用形成 typed graph | `architecture-context-extractor` | 05 | P0 | openrewrite |
| 182 | 可导出 CALM/JSON/图数据库表示 | `architecture-context-extractor` | 05 | P0 | openrewrite |
| 183 | 架构变更前后可 diff | `architecture-context-extractor` | 05 | P0 | openrewrite |
| 184 | 用于影响分析和迁移规划 | `architecture-context-extractor` | 05 | P0 | openrewrite |
| 185 | dependency list 与 symbol/API usage 关联 | `dependency-and-library-usage-index` | 05 | P0 | openrewrite |
| 186 | 区分 declared-but-unused 与 transitive-used | `dependency-and-library-usage-index` | 05 | P0 | openrewrite |
| 187 | 支持按 library/version/feature 查询使用点 | `dependency-and-library-usage-index` | 05 | P0 | openrewrite |
| 188 | 为升级 Recipe 计算 blast radius | `dependency-and-library-usage-index` | 05 | P0 | openrewrite |
| 189 | 统计 dominant patterns 与例外 | `coding-and-error-pattern-miner` | 05 | P0 | openrewrite |
| 190 | 按模块/语言分层而不是全仓一刀切 | `coding-and-error-pattern-miner` | 05 | P0 | openrewrite |
| 191 | 给 Agent 返回少量代表性示例 | `coding-and-error-pattern-miner` | 05 | P0 | openrewrite |
| 192 | 模式变化可触发 Context Epoch 更新 | `coding-and-error-pattern-miner` | 05 | P0 | openrewrite |
| 193 | 方法描述、复杂度、依赖、测试映射可查询 | `method-and-test-quality-index` | 05 | P0 | openrewrite |
| 194 | 识别高复杂度/低覆盖/脆弱测试热点 | `method-and-test-quality-index` | 05 | P0 | openrewrite |
| 195 | 迁移优先级结合业务 blast radius | `method-and-test-quality-index` | 05 | P0 | openrewrite |
| 196 | 变换后比较质量指标是否恶化 | `method-and-test-quality-index` | 05 | P0 | openrewrite |
| 197 | 大 CSV/索引禁止整表塞入模型 | `semantic-token-context-query` | 05 | P0 | openrewrite, opencode |
| 198 | 按任务 query/filter/project 返回必要行 | `semantic-token-context-query` | 05 | P0 | openrewrite, opencode |
| 199 | 估算每个候选上下文的 token 成本 | `semantic-token-context-query` | 05 | P0 | openrewrite, opencode |
| 200 | 在准确性预算内优先使用便宜结构化上下文 | `semantic-token-context-query` | 05 | P0 | openrewrite, opencode |
| 201 | Agent 声明 id/description/mode/model/prompt/permissions/limits | `agent-registry` | 06 | P0 | opencode |
| 202 | 支持 project/global/managed 来源合并 | `agent-registry` | 06 | P0 | opencode |
| 203 | 选择前做 capability 与 permission 校验 | `agent-registry` | 06 | P0 | opencode |
| 204 | Agent 配置变更可热重载但必须进入 Context Epoch | `agent-registry` | 06 | P0 | opencode |
| 205 | Primary 持有主任务状态 | `primary-subagent-hierarchy` | 06 | P0 | opencode |
| 206 | Subagent 获取最小委派上下文并返回结构化产物 | `primary-subagent-hierarchy` | 06 | P0 | opencode |
| 207 | 子任务默认不污染主上下文 | `primary-subagent-hierarchy` | 06 | P0 | opencode |
| 208 | 父子 Session 形成可导航 DAG/tree | `primary-subagent-hierarchy` | 06 | P0 | opencode |
| 209 | Plan 默认禁止写操作 | `plan-explore-scout-agents` | 06 | P0 | opencode |
| 210 | Explore 只访问本仓搜索/读取/LSP | `plan-explore-scout-agents` | 06 | P0 | opencode |
| 211 | Scout 只访问外部文档/依赖缓存 | `plan-explore-scout-agents` | 06 | P0 | opencode |
| 212 | Build 只有在计划和权限满足后才获得写能力 | `plan-explore-scout-agents` | 06 | P0 | opencode |
| 213 | 系统 Agent 不出现在普通角色选择器 | `hidden-system-agents` | 06 | P0 | opencode |
| 214 | 默认使用 cheaper/small model | `hidden-system-agents` | 06 | P0 | opencode |
| 215 | 输出有固定 schema 而非自由文本 | `hidden-system-agents` | 06 | P0 | opencode |
| 216 | 系统 Agent 无不必要文件写权限 | `hidden-system-agents` | 06 | P0 | opencode |
| 217 | 模型选择从 Agent 配置继承并可 task override | `per-agent-model-routing` | 06 | P0 | opencode |
| 218 | 探索/摘要优先便宜模型，架构/复杂修复可升级模型 | `per-agent-model-routing` | 06 | P0 | opencode |
| 219 | 模型切换在 provider-turn safe boundary 生效 | `per-agent-model-routing` | 06 | P0 | opencode |
| 220 | 记录每次路由理由和实际成本 | `per-agent-model-routing` | 06 | P0 | opencode |
| 221 | 每 Agent/任务配置 max steps/turns | `agent-step-budget` | 06 | P0 | opencode |
| 222 | 接近上限时输出剩余工作和阻塞点 | `agent-step-budget` | 06 | P0 | opencode |
| 223 | 达到上限是显式 stop reason 而非伪装成功 | `agent-step-budget` | 06 | P0 | opencode |
| 224 | 预算可由复杂度/费用策略动态调整 | `agent-step-budget` | 06 | P0 | opencode |
| 225 | Planner 显式标记 dependency-free subtasks | `parallel-subagent-execution` | 06 | P0 | opencode |
| 226 | 并发有租户/项目/模型/工具多级上限 | `parallel-subagent-execution` | 06 | P0 | opencode |
| 227 | 结果按 task ID/依赖拓扑稳定合并 | `parallel-subagent-execution` | 06 | P0 | opencode |
| 228 | 任何共享副作用必须串行或幂等 | `parallel-subagent-execution` | 06 | P0 | opencode |
| 229 | child session 记录 parent/task/delegation contract | `parent-child-session-graph` | 06 | P0 | opencode |
| 230 | 父 Agent 只接收结构化 summary/artifacts | `parent-child-session-graph` | 06 | P0 | opencode |
| 231 | 支持跳转查看子 Agent 完整证据 | `parent-child-session-graph` | 06 | P0 | opencode |
| 232 | 取消父任务时按策略传播到子任务 | `parent-child-session-graph` | 06 | P0 | opencode |
| 233 | 模板支持位置参数和结构化输入 | `agent-command-playbooks` | 06 | P0 | opencode |
| 234 | 可绑定特定 Agent/model | `agent-command-playbooks` | 06 | P0 | opencode |
| 235 | 可引用文件、测试输出和预计算上下文 | `agent-command-playbooks` | 06 | P0 | opencode |
| 236 | 高风险 shell interpolation 仍经过 permission engine | `agent-command-playbooks` | 06 | P0 | opencode |
| 237 | 当前 tool call/side effect 不被中途换角色重放 | `safe-agent-role-switching` | 06 | P0 | opencode |
| 238 | 下一个 turn 使用新 Agent 的权限和上下文 | `safe-agent-role-switching` | 06 | P0 | opencode |
| 239 | 切换事件持久化并可审计 | `safe-agent-role-switching` | 06 | P0 | opencode |
| 240 | 禁止通过角色切换绕过既有 deny policy | `safe-agent-role-switching` | 06 | P0 | opencode |
| 241 | message id 幂等，精确重试返回同一 admission | `durable-session-inbox` | 07 | P0 | opencode |
| 242 | admission 与 model-visible history 分离 | `durable-session-inbox` | 07 | P0 | opencode |
| 243 | pending input 在 crash/reconnect 后仍存在 | `durable-session-inbox` | 07 | P0 | opencode |
| 244 | promotion 与可见消息写入原子提交 | `durable-session-inbox` | 07 | P0 | opencode |
| 245 | steer 在下一 provider-turn safe boundary 合并 | `queue-steer-delivery` | 07 | P0 | opencode |
| 246 | queue FIFO，在当前 drain 结束时逐条提升 | `queue-steer-delivery` | 07 | P0 | opencode |
| 247 | 交付模式持久化并可观察 | `queue-steer-delivery` | 07 | P0 | opencode |
| 248 | 设置 backlog/batch 上限防止无界输入 | `queue-steer-delivery` | 07 | P0 | opencode |
| 249 | 事件拥有单调 aggregate sequence | `session-event-sourcing` | 07 | P0 | opencode |
| 250 | projection 可从事件重建消息、tool 状态和运行状态 | `session-event-sourcing` | 07 | P0 | opencode |
| 251 | live delta 与 durable event 明确分离 | `session-event-sourcing` | 07 | P0 | opencode |
| 252 | schema 演进有版本和 replay 测试 | `session-event-sourcing` | 07 | P0 | opencode |
| 253 | 重复 resume 加入正在运行的 drain | `session-run-coordinator` | 07 | P0 | opencode |
| 254 | 重复 wake 合并为后续一次 wake | `session-run-coordinator` | 07 | P0 | opencode |
| 255 | 同 Session provider turn 保持序列化 | `session-run-coordinator` | 07 | P0 | opencode |
| 256 | 多 Session 并发受全局资源调度器控制 | `session-run-coordinator` | 07 | P0 | opencode |
| 257 | wake 只在存在可提升工作时触发 provider | `wake-resume-interrupt` | 07 | P0 | opencode |
| 258 | resume 可显式驱动 idle session | `wake-resume-interrupt` | 07 | P0 | opencode |
| 259 | interrupt 等待本进程 runner 清理但保留 durable inbox | `wake-resume-interrupt` | 07 | P0 | opencode |
| 260 | 所有操作幂等或有明确重复语义 | `wake-resume-interrupt` | 07 | P0 | opencode |
| 261 | 每次 turn 请求/模型/上下文指纹持久化 | `provider-turn-persistence` | 07 | P0 | opencode |
| 262 | 模型输出 durable boundary 后才进入后续 tool/continuation | `provider-turn-persistence` | 07 | P0 | opencode |
| 263 | model switch 不错误复用 provider-native metadata | `provider-turn-persistence` | 07 | P0 | opencode |
| 264 | 支持精确区分 dispatch unknown 与 completed | `provider-turn-persistence` | 07 | P0 | opencode |
| 265 | tool call durable-before-execute | `durable-tool-settlement` | 07 | P0 | opencode |
| 266 | settlement 关联 assistant message + tool call identity | `durable-tool-settlement` | 07 | P0 | opencode |
| 267 | crash 后 running call 标记 interrupted，禁止静默重放 | `durable-tool-settlement` | 07 | P0 | opencode |
| 268 | continuation 只读取已 settlement 的历史 | `durable-tool-settlement` | 07 | P0 | opencode |
| 269 | baseline 包含环境、项目规则、Agent/Skill 可见性等来源 | `context-epoch` | 07 | P0 | opencode |
| 270 | 每个 source 独立 fingerprint/availability | `context-epoch` | 07 | P0 | opencode |
| 271 | 变化以 chronological system update 提交 | `context-epoch` | 07 | P0 | opencode |
| 272 | compaction/location move 可生成新 baseline | `context-epoch` | 07 | P0 | opencode |
| 273 | 按 context window - reserved headroom 预算触发 | `context-compaction` | 07 | P0 | opencode |
| 274 | rolling summary + bounded recent context | `context-compaction` | 07 | P0 | opencode |
| 275 | 只有 compaction 完成事件才切换 active boundary | `context-compaction` | 07 | P0 | opencode |
| 276 | provider overflow 可触发一次受控补救 compaction | `context-compaction` | 07 | P0 | opencode |
| 277 | cursor 只由持久事件推进 | `reconnect-safe-history` | 07 | P0 | opencode |
| 278 | 先订阅 wake 再 replay，避免 replay/tail race | `reconnect-safe-history` | 07 | P0 | opencode |
| 279 | ephemeral token delta 不伪装为 durable cursor | `reconnect-safe-history` | 07 | P0 | opencode |
| 280 | 有限 history API 支持分页且序列严格递增 | `reconnect-safe-history` | 07 | P0 | opencode |
| 281 | 不污染用户现有分支和 index | `git-snapshot-revert` | 08 | P0 | opencode |
| 282 | 可 track tree hash、生成 patch、restore、revert、full diff | `git-snapshot-revert` | 08 | P0 | opencode |
| 283 | 复用原仓 object database/index 降低超大仓首次 hash 成本 | `git-snapshot-revert` | 08 | P0 | opencode |
| 284 | 忽略文件、大文件、symlink/longpath 有明确策略 | `git-snapshot-revert` | 08 | P0 | opencode |
| 285 | 区分可重试 provider 错误、tool 错误、用户取消和不可恢复错误 | `session-retry-run-state` | 08 | P0 | opencode |
| 286 | 重试 attempt 有独立 ID 与原因 | `session-retry-run-state` | 08 | P0 | opencode |
| 287 | 绝不跨 durable side-effect boundary 盲目重试 | `session-retry-run-state` | 08 | P0 | opencode |
| 288 | run state 可在 UI/API/恢复逻辑中统一读取 | `session-retry-run-state` | 08 | P0 | opencode |
| 289 | 执行前持久化 idempotency key 与 side-effect class | `side-effect-interruption-fencing` | 08 | P0 | opencode |
| 290 | 进程丢失时默认 interrupted/unknown，而非自动 replay | `side-effect-interruption-fencing` | 08 | P0 | opencode |
| 291 | 支持外部系统 reconciliation 检查是否已成功 | `side-effect-interruption-fencing` | 08 | P0 | opencode |
| 292 | 只有证明安全才允许 retry | `side-effect-interruption-fencing` | 08 | P0 | opencode |
| 293 | 区分 input promoted、provider dispatched、assistant durable、tool started/settled 等断点 | `post-crash-continuation-recovery` | 08 | P0 | opencode |
| 294 | 恢复算法基于 durable evidence 决定 resume/retry/manual reconcile | `post-crash-continuation-recovery` | 08 | P0 | opencode |
| 295 | 集群 ownership 使用 lease/fencing token | `post-crash-continuation-recovery` | 08 | P0 | opencode |
| 296 | 任何歧义副作用进入人工/外部对账路径 | `post-crash-continuation-recovery` | 08 | P0 | opencode |
| 297 | 定义 name/description/input/output/structured output/permission | `typed-tool-registry` | 08 | P0 | opencode |
| 298 | definition 与 executable handler 分离 | `typed-tool-registry` | 08 | P0 | opencode |
| 299 | tool name/schema 注册时验证 | `typed-tool-registry` | 08 | P0 | opencode |
| 300 | registry 支持按 Agent/policy/context 动态 materialize | `typed-tool-registry` | 08 | P0 | opencode |
| 301 | 模型参数 decode 失败不执行 handler | `schema-validated-tool-io` | 08 | P0 | opencode |
| 302 | handler 输出 encode 失败标记 tool failure | `schema-validated-tool-io` | 08 | P0 | opencode |
| 303 | 结构化结果与 model-visible text/file 可分别定义 | `schema-validated-tool-io` | 08 | P0 | opencode |
| 304 | 错误包含字段级路径而非模糊字符串 | `schema-validated-tool-io` | 08 | P0 | opencode |
| 305 | 全局/项目/Agent/会话/保存规则分层 | `wildcard-permission-engine` | 08 | P0 | opencode |
| 306 | 默认缺失 Agent 权限可配置 deny-by-default | `wildcard-permission-engine` | 08 | P0 | opencode |
| 307 | 通配模式支持 tool、文件、命令和外部目录 | `wildcard-permission-engine` | 08 | P0 | opencode |
| 308 | permission decision 记录命中规则与来源 | `wildcard-permission-engine` | 08 | P0 | opencode |
| 309 | 例如 git diff allow、git push ask、rm -rf deny | `command-resource-policy` | 08 | P0 | opencode |
| 310 | 路径规范化后再匹配防 traversal | `command-resource-policy` | 08 | P0 | opencode |
| 311 | 外部目录单独 permission | `command-resource-policy` | 08 | P0 | opencode |
| 312 | 高危资源支持 never-save 与双确认策略 | `command-resource-policy` | 08 | P0 | opencode |
| 313 | 基于相同错误、相同 patch、相同 tool args 的循环指纹 | `doom-loop-human-intervention` | 08 | P0 | opencode |
| 314 | 连续无进展达到阈值触发 stop reason | `doom-loop-human-intervention` | 08 | P0 | opencode |
| 315 | 允许 question/approval/correction 进入下一 turn | `doom-loop-human-intervention` | 08 | P0 | opencode |
| 316 | 不得通过无限换模型掩盖逻辑死循环 | `doom-loop-human-intervention` | 08 | P0 | opencode |
| 317 | 任务有状态/owner/dependency/evidence，而非纯 Markdown checkbox | `structured-task-and-question-tools` | 08 | P0 | opencode |
| 318 | 问题可提供候选选项和自定义输入 | `structured-task-and-question-tools` | 08 | P0 | opencode |
| 319 | 回答持久化并绑定决策节点 | `structured-task-and-question-tools` | 08 | P0 | opencode |
| 320 | 子 Agent 默认无权修改主任务列表，除非显式委派 | `structured-task-and-question-tools` | 08 | P0 | opencode |
| 321 | 支持 project/global/兼容路径向上发现到 git root | `lazy-skill-discovery` | 09 | P1 | opencode |
| 322 | Skill 名称/目录/frontmatter 做严格验证 | `lazy-skill-discovery` | 09 | P1 | opencode |
| 323 | deny 的 Skill 对模型完全隐藏 | `lazy-skill-discovery` | 09 | P1 | opencode |
| 324 | 兼容 Claude/OpenCode/Elmos 路径但以统一内部 ID 去重 | `lazy-skill-discovery` | 09 | P1 | opencode |
| 325 | local command/cwd/env 与 remote URL/header/OAuth 分离 | `mcp-gateway-oauth-context-budget` | 09 | P1 | opencode |
| 326 | 支持 OAuth discovery/DCR/credential lifecycle | `mcp-gateway-oauth-context-budget` | 09 | P1 | opencode |
| 327 | MCP server/tool 可按 Agent 开关和 wildcard policy | `mcp-gateway-oauth-context-budget` | 09 | P1 | opencode |
| 328 | 只 materialize 当前任务需要的工具 schema，控制 token | `mcp-gateway-oauth-context-budget` | 09 | P1 | opencode |
| 329 | definition/reference/implementation/symbol/call hierarchy 接口 | `lsp-diagnostics-and-navigation` | 09 | P1 | opencode |
| 330 | 文件类型按需启动语言 server | `lsp-diagnostics-and-navigation` | 09 | P1 | opencode |
| 331 | 与 CLI lint/typecheck 的准确性/成本可动态选择 | `lsp-diagnostics-and-navigation` | 09 | P1 | opencode |
| 332 | LSP 版本/内存/同步异常可自动降级 | `lsp-diagnostics-and-navigation` | 09 | P1 | opencode |
| 333 | 按 extension/config 自动选择 formatter | `post-edit-format-and-patch` | 09 | P1 | opencode |
| 334 | custom formatter 支持 env/command/FILE placeholder | `post-edit-format-and-patch` | 09 | P1 | opencode |
| 335 | format 只作用于 changed files 且有 timeout | `post-edit-format-and-patch` | 09 | P1 | opencode |
| 336 | apply_patch add/update/move/delete 统一路径校验与 permission | `post-edit-format-and-patch` | 09 | P1 | opencode |
| 337 | 部署凭据/endpoint 与生成参数分离 | `provider-model-abstraction` | 09 | P1 | opencode |
| 338 | Model 携带 capability/pricing/defaults | `provider-model-abstraction` | 09 | P1 | opencode |
| 339 | Provider quirks 收敛在 protocol/transform layer | `provider-model-abstraction` | 09 | P1 | opencode |
| 340 | 模型可替换而 durable session 不依赖厂商对象 | `provider-model-abstraction` | 09 | P1 | opencode |
| 341 | Request 可持久化、hash、replay | `portable-request-vs-local-behavior` | 09 | P1 | opencode |
| 342 | handler 运行时绑定并做 schema 兼容检查 | `portable-request-vs-local-behavior` | 09 | P1 | opencode |
| 343 | provider-hosted tool 与 local tool 使用不同类型 | `portable-request-vs-local-behavior` | 09 | P1 | opencode |
| 344 | 禁止把闭包/credential 塞进 durable request | `portable-request-vs-local-behavior` | 09 | P1 | opencode |
| 345 | 普通短任务可用 complete run | `model-run-vs-provider-turn` | 09 | P1 | opencode |
| 346 | Elmos durable runtime 使用 one-turn API 自己持久化/settle/continue | `model-run-vs-provider-turn` | 09 | P1 | opencode |
| 347 | stop condition 和 turn count 显式 | `model-run-vs-provider-turn` | 09 | P1 | opencode |
| 348 | tool 并发有界且 settlement 顺序确定 | `model-run-vs-provider-turn` | 09 | P1 | opencode |
| 349 | normalize text/reasoning/tool/usage/finish event | `stream-usage-cost-cache-runtime` | 09 | P1 | opencode |
| 350 | input/output/cache-read/cache-write token 分项 | `stream-usage-cost-cache-runtime` | 09 | P1 | opencode |
| 351 | provider/request/chunk timeout 分离 | `stream-usage-cost-cache-runtime` | 09 | P1 | opencode |
| 352 | cache policy/fingerprint 可观测并进入成本路由 | `stream-usage-cost-cache-runtime` | 09 | P1 | opencode |
| 353 | 配置 merge 而不是整体替换 | `hierarchical-enterprise-config` | 09 | P1 | opencode |
| 354 | 每个 resolved value 可追踪来源/precedence | `hierarchical-enterprise-config` | 09 | P1 | opencode |
| 355 | JSON Schema 提供校验和自动完成 | `hierarchical-enterprise-config` | 09 | P1 | opencode |
| 356 | MDM/系统 managed policy 可禁止项目覆盖安全项 | `hierarchical-enterprise-config` | 09 | P1 | opencode |
| 357 | Workspace adapter 隔离本地/远程执行环境 | `workspace-control-plane-and-multi-client` | 09 | P1 | opencode |
| 358 | 同一 Session API 支持 headless 和交互客户端 | `workspace-control-plane-and-multi-client` | 09 | P1 | opencode |
| 359 | 后台 job 与前台 session 生命周期分离 | `workspace-control-plane-and-multi-client` | 09 | P1 | opencode |
| 360 | 服务发现/CORS/auth/SDK schema 统一由 control plane 管理 | `workspace-control-plane-and-multi-client` | 09 | P1 | opencode |
| 361 | 规则命中优先级高于自由生成 | `deterministic-first-router` | 10 | P0 | openrewrite, opencode |
| 362 | 按 confidence/capability/expected cost 选择 Recipe、Agent 或 Hybrid | `deterministic-first-router` | 10 | P0 | openrewrite, opencode |
| 363 | 同类 LLM 成功模式可逐步降低到确定性规则 | `deterministic-first-router` | 10 | P0 | openrewrite, opencode |
| 364 | 路由结果带可解释证据 | `deterministic-first-router` | 10 | P0 | openrewrite, opencode |
| 365 | Planner 输出 typed DAG 而非自然语言清单 | `recipe-agent-hybrid-planner` | 10 | P0 | openrewrite, opencode |
| 366 | 每节点声明 executor/inputs/outputs/side-effect/rollback | `recipe-agent-hybrid-planner` | 10 | P0 | openrewrite, opencode |
| 367 | 确定性节点可缓存和复用 | `recipe-agent-hybrid-planner` | 10 | P0 | openrewrite, opencode |
| 368 | LLM 节点只接收必要 semantic slice | `recipe-agent-hybrid-planner` | 10 | P0 | openrewrite, opencode |
| 369 | Context query 以任务意图和 symbol graph 为入口 | `semantic-context-provider` | 10 | P0 | openrewrite, opencode |
| 370 | 优先返回结构化摘要+定位而非整文件 | `semantic-context-provider` | 10 | P0 | openrewrite, opencode |
| 371 | 每片上下文有 token estimate/freshness/provenance | `semantic-context-provider` | 10 | P0 | openrewrite, opencode |
| 372 | 变化进入 Context Epoch 和 cache invalidation | `semantic-context-provider` | 10 | P0 | openrewrite, opencode |
| 373 | Recipe/Agent/Tool 都生成统一 Patch IR | `semantic-patch-and-evidence-ledger` | 10 | P0 | openrewrite, opencode |
| 374 | 记录 before/after symbol/type/config facts | `semantic-patch-and-evidence-ledger` | 10 | P0 | openrewrite, opencode |
| 375 | patch 可归因、可回滚、可比较 | `semantic-patch-and-evidence-ledger` | 10 | P0 | openrewrite, opencode |
| 376 | 无 evidence 的修改不能进入完成态 | `semantic-patch-and-evidence-ledger` | 10 | P0 | openrewrite, opencode |
| 377 | Recipe fixpoint、compile、lint、unit/integration/UI/perf/security 可组合 | `verification-fixpoint-completion-proof` | 10 | P0 | openrewrite, opencode |
| 378 | 失败自动路由到 repair node 并有循环上限 | `verification-fixpoint-completion-proof` | 10 | P0 | openrewrite, opencode |
| 379 | 最终 completion proof 包含需求→实现→测试→证据映射 | `verification-fixpoint-completion-proof` | 10 | P0 | openrewrite, opencode |
| 380 | 未验证项必须显示 unknown，而不能当 pass | `verification-fixpoint-completion-proof` | 10 | P0 | openrewrite, opencode |
| 381 | 实体包括 symbol/framework/version/rule/test/failure/evidence | `migration-knowledge-graph` | 10 | P0 | openrewrite, opencode |
| 382 | Recipe applicability 和历史成功率可查询 | `migration-knowledge-graph` | 10 | P0 | openrewrite, opencode |
| 383 | 新项目 scan 先匹配已知迁移路径 | `migration-knowledge-graph` | 10 | P0 | openrewrite, opencode |
| 384 | 知识节点有来源版本和置信度 | `migration-knowledge-graph` | 10 | P0 | openrewrite, opencode |
| 385 | 聚类相似 semantic patches 而非纯文本 diff | `successful-patch-to-recipe-learning` | 10 | P0 | openrewrite, opencode |
| 386 | 自动生成 pattern/precondition/template 候选 | `successful-patch-to-recipe-learning` | 10 | P0 | openrewrite, opencode |
| 387 | 必须通过跨仓 corpus、反例、幂等和安全认证 | `successful-patch-to-recipe-learning` | 10 | P0 | openrewrite, opencode |
| 388 | 未认证候选只作为建议，不自动执行 | `successful-patch-to-recipe-learning` | 10 | P0 | openrewrite, opencode |
| 389 | key 包含 git tree/file hash、parser/skill/rule/model/context 版本 | `hierarchical-context-and-repo-cache` | 10 | P0 | openrewrite, opencode |
| 390 | 局部文件变化只失效受影响 symbol/dependency slice | `hierarchical-context-and-repo-cache` | 10 | P0 | openrewrite, opencode |
| 391 | 区分 deterministic cache 与 model cache | `hierarchical-context-and-repo-cache` | 10 | P0 | openrewrite, opencode |
| 392 | 持续测 hit rate、节省 token、错误复用率 | `hierarchical-context-and-repo-cache` | 10 | P0 | openrewrite, opencode |
| 393 | 数据库/部署/Git push/发布等操作先登记 ledger | `side-effect-ledger-and-recovery-fencing` | 10 | P0 | opencode |
| 394 | Worker ownership 有 lease + fencing token | `side-effect-ledger-and-recovery-fencing` | 10 | P0 | opencode |
| 395 | 恢复先查询外部真实状态再决定 retry/complete | `side-effect-ledger-and-recovery-fencing` | 10 | P0 | opencode |
| 396 | rollback/compensation 也作为有证据的 durable step | `side-effect-ledger-and-recovery-fencing` | 10 | P0 | opencode |
| 397 | 目录支持 ecosystem/category/version/team/compatibility | `skill-marketplace-certification` | 10 | P0 | openrewrite, opencode |
| 398 | bundle lazy resolve，依赖和权限声明机器可读 | `skill-marketplace-certification` | 10 | P0 | openrewrite, opencode |
| 399 | 认证覆盖 schema、测试、性能、安全、license、适用性 | `skill-marketplace-certification` | 10 | P0 | openrewrite, opencode |
| 400 | 生产 Agent 默认只看到通过认证且权限允许的 Skill | `skill-marketplace-certification` | 10 | P0 | openrewrite, opencode |
