# Batch 04: dependency-quality-intelligence

依赖/锁文件确定性更新、解析质量、TCK、测试与证据。

## Skills

- `build-model-intelligence` — 解析构建工具、依赖图、插件、仓库和语言级别形成统一 Build IR。
- `native-dependency-resolution` — 尽量在 Elmos 内原生解析依赖，而不是依赖目标机器安装包管理器。
- `minimal-lockfile-delta` — 锁文件更新默认采用最小变更，而非全图重新解析。
- `package-metadata-ladder` — 按低成本到高成本逐级获取包依赖和哈希元数据。
- `dependency-credential-propagation` — 把仓库、代理和私有索引凭据作为宿主能力安全传入解析器。
- `lockfile-accuracy-contract` — 生成锁文件必须满足可验证、可部署、真哈希和 fail-loud 契约。
- `parser-tck` — 为每种 parser 建立共享语法/语义/打印兼容性测试套件。
- `transformation-before-after-tests` — Recipe 必须用明确 before/after/unchanged fixtures 测试。
- `transformation-benchmarks` — 对 parser、Recipe、语义索引和大仓运行建立持续性能基准。
- `parse-failure-evidence` — 解析/反序列化失败必须成为可查询的一等证据。
