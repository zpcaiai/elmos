# Batch 10: elmos-fusion

把 OpenRewrite + OpenCode 机制融合成 Elmos 独有的 Repository Engineering OS。

## Skills

- `deterministic-first-router` — 任务先判断能否用 Recipe/语义查询解决，再决定是否调用 LLM。
- `recipe-agent-hybrid-planner` — 一个迁移计划可混合确定性 Recipe、Agent coding、Tool、人工审批和验证。
- `semantic-context-provider` — 将 LST、预计算索引、LSP、Git 和测试证据统一成按需上下文服务。
- `semantic-patch-and-evidence-ledger` — 每次修改同时保存文本 diff、语义变化、执行者、验证和原因。
- `verification-fixpoint-completion-proof` — 以可证明的零剩余违规/测试通过/需求覆盖替代 Agent 自报完成。
- `migration-knowledge-graph` — 把源/目标语言、框架、版本、API、Recipe 和失败模式沉淀成迁移知识图。
- `successful-patch-to-recipe-learning` — 把经大量验证的 Agent 修复候选抽象为可复用 Recipe。
- `hierarchical-context-and-repo-cache` — 把 parser/LST/index/query/summary/provider prompt cache 组合成分层缓存。
- `side-effect-ledger-and-recovery-fencing` — 把 Tool 副作用、幂等键、reconciliation 和 cluster fencing 统一起来。
- `skill-marketplace-certification` — 将 Skill/Recipe/Agent/Tool Bundle 纳入统一目录、版本、依赖、权限和认证体系。
