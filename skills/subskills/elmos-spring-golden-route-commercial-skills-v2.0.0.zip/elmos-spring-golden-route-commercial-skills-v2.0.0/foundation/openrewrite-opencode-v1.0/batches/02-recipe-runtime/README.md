# Batch 02: recipe-runtime

把确定性代码变换、组合、扫描和 fixpoint 收敛变成 Elmos 的主执行路径。

## Skills

- `deterministic-recipe-engine` — 把可重复迁移从 LLM 写代码下沉为类型感知、可测试的确定性 Recipe。
- `recipe-composition-graph` — 支持 Recipe 嵌套、组合、依赖与父子 provenance。
- `recipe-preconditions` — 变换前先做类型、框架、文件和版本前置判断，降低误改。
- `scanning-recipe-accumulator` — 先全仓扫描和聚合事实，再生成/修改文件。
- `scan-generate-edit-lifecycle` — 为大型迁移固定 scan、generate、edit 三阶段执行顺序。
- `multi-cycle-fixpoint` — Recipe 多轮执行直到不再产生变化或显式达到收敛条件。
- `recipe-option-schema` — Recipe 参数成为强类型 schema，而不是散落在 prompt 中。
- `recipe-descriptor-introspection` — 对 Recipe、子 Recipe、参数、数据表、维护者和来源做运行时自描述。
- `recipe-change-attribution` — 任何源码变更都必须能回答“哪条规则为何改了这里”。
- `recipe-effort-estimation` — 把每个自动修复的人工替代工作量和自动运行成本量化。
