# Batch 06: agent-runtime

OpenCode Agent/Subagent/角色与任务分解机制的 Elmos 化。

## Skills

- `agent-registry` — 把 Agent 作为可配置、可发现、可禁用的一等运行实体。
- `primary-subagent-hierarchy` — 区分主交互 Agent 与专职子 Agent，形成清晰责任边界。
- `plan-explore-scout-agents` — 把只读规划、本仓探索、外部依赖研究拆成不同权限角色。
- `hidden-system-agents` — 压缩、标题、摘要、质量判定等后台系统任务使用隐藏 Agent。
- `per-agent-model-routing` — 不同角色使用不同模型、temperature、reasoning 与成本预算。
- `agent-step-budget` — 限制 Agent agentic iteration/turn，避免失控循环和成本爆炸。
- `parallel-subagent-execution` — 把互不依赖的搜索、分析、测试任务并行化，但结果确定性归并。
- `parent-child-session-graph` — 子 Agent 拥有独立可回放会话，并保留父任务关系。
- `agent-command-playbooks` — 把重复开发流程包装成带参数、模型、Agent 和上下文引用的命令宏。
- `safe-agent-role-switching` — 运行中切换 Agent/模型只能在安全 provider-turn 边界完成。
