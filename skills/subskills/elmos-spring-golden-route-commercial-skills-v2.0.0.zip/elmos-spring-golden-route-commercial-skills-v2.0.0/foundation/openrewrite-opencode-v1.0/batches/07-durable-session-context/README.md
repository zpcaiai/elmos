# Batch 07: durable-session-context

Durable Session、事件流、上下文 epoch、压缩和断线重连。

## Skills

- `durable-session-inbox` — 用户输入先持久化 admission，再由 runner 安全 promotion 到模型历史。
- `queue-steer-delivery` — 区分排队输入和下一安全边界立即 steer 的交互语义。
- `session-event-sourcing` — Session 的关键状态转换使用持久事件序列而不是仅内存状态。
- `session-run-coordinator` — 同一 Session 串行 drain，不同 Session 并行。
- `wake-resume-interrupt` — 将新输入唤醒、显式继续和中断清理定义成不同操作。
- `provider-turn-persistence` — 把单次 provider turn 作为 durable runtime 的最小模型执行原语。
- `durable-tool-settlement` — Tool call 在执行前投影，结果/失败/中断也持久化后再继续模型。
- `context-epoch` — 持久化模型看到的 privileged context baseline，并增量追踪变化。
- `context-compaction` — 上下文超预算前生成结构化 checkpoint，而完整 transcript 仍永久保留。
- `reconnect-safe-history` — 提供 durable replay cursor + live tail，客户端断线后无缝续传。
