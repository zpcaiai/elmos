# Batch 01: semantic-kernel

OpenRewrite 的 LST/Parser/Visitor 思想转成 Elmos 的跨语言无损语义内核。

## Skills

- `lossless-semantic-ir` — 建立跨语言、可往返打印、保留格式/注释/语义的统一源码表示。
- `rich-type-attribution` — 把类型归因从“可选附加信息”提升为迁移和搜索的基础设施。
- `semantic-marker-metadata` — 用非侵入 Marker 附着构建、Git、框架、搜索和变换证据。
- `cursor-execution-context` — 提供树遍历上下文、跨 visitor 状态共享和生命周期消息总线。
- `immutable-tree-transform` — 所有变换以不可变树返回值表达，形成可比较、可回放的 patch provenance。
- `parser-roundtrip-fidelity` — 建立 parse→print 的无损往返质量门禁。
- `parser-capability-contract` — 把每个语言适配器的语法、类型、打印、模板、版本能力显式声明。
- `native-parser-adapter` — 允许 ANTLR、编译器 API、Prism、Tree-sitter 等不同原生解析器映射到统一 IR。
- `version-aware-parser` — 按 Java/语言版本、语法特性和项目工具链选择兼容解析环境。
- `multi-format-source-model` — 将代码、构建脚本、配置、数据格式和基础设施文件统一纳入变换图。
