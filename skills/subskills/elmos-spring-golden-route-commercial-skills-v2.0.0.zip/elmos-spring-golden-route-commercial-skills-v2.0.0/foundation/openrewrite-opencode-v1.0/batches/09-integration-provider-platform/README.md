# Batch 09: integration-provider-platform

Skills/MCP/LSP/Provider/Config/Workspace/多客户端平台层。

## Skills

- `lazy-skill-discovery` — Skill 只向 Agent 暴露 name/description，正文按需加载并受权限控制。
- `mcp-gateway-oauth-context-budget` — 统一管理本地/远程 MCP、OAuth、超时、工具可见性和上下文成本。
- `lsp-diagnostics-and-navigation` — 将 LSP 作为可选诊断/导航 provider，而不是强依赖。
- `post-edit-format-and-patch` — 文件修改后按项目实际 formatter 规范化，并统一生成可审计 patch。
- `provider-model-abstraction` — 把 Provider Definition、Configured Provider、Model、Protocol 清晰分层。
- `portable-request-vs-local-behavior` — 可序列化请求/工具定义与本地 executable handler/hooks 强制分离。
- `model-run-vs-provider-turn` — 高层完整 tool loop 与低层单 provider turn 两套 API 明确分工。
- `stream-usage-cost-cache-runtime` — 统一 provider stream 事件、token/cost、超时和 cache key 行为。
- `hierarchical-enterprise-config` — Remote→Global→Project→Inline→Managed 配置合并，并支持不可覆盖企业策略。
- `workspace-control-plane-and-multi-client` — 把 workspace、server、SDK、CLI/TUI/Web/Desktop/ACP 等客户端与执行后端解耦。
