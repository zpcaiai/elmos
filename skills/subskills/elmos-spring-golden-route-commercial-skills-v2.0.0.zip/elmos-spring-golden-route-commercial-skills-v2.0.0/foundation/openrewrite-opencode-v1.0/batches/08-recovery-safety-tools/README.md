# Batch 08: recovery-safety-tools

Snapshot/恢复、副作用安全、强类型 Tool 与权限控制。

## Skills

- `git-snapshot-revert` — 用独立 Git object/index 体系为 Agent 修改提供高效 checkpoint/diff/restore/revert。
- `session-retry-run-state` — 把 retry/backoff、运行状态和 terminal reason 从 prompt 逻辑下沉为 runtime。
- `side-effect-interruption-fencing` — 任何有副作用 tool 在 crash/interrupt 后必须进入不确定状态隔离。
- `post-crash-continuation-recovery` — 补强 OpenCode 尚未完全解决的 crash 后 continuation，作为 Elmos 生产级能力。
- `typed-tool-registry` — 所有内建、MCP、CLI、数据库、部署工具统一成强类型 Tool Definition。
- `schema-validated-tool-io` — Tool 输入和输出在模型边界强制 schema 校验。
- `wildcard-permission-engine` — action × resource × ruleset 使用 allow/ask/deny 和 last-match 规则。
- `command-resource-policy` — Shell、文件、网络、Git、DB、部署等按具体资源而非仅工具名授权。
- `doom-loop-human-intervention` — 检测 Agent 重复失败/重复 tool call，并在正确时机转入人工决策。
- `structured-task-and-question-tools` — Todo、问题、审批和用户选择使用结构化协议。
