# Batch 03: recipe-ecosystem-patterns

Recipe Marketplace、数据表、模板匹配和语义搜索。

## Skills

- `recipe-data-table` — Recipe 运行可输出结构化分析表而不把结果塞进日志。
- `recipe-marketplace` — 建立可发现、分层分类、可版本化的确定性变换市场。
- `recipe-bundle-resolver` — 通过两阶段 Resolver→Reader 懒加载 Maven/NPM/YAML 等 Recipe bundle。
- `recipe-marketplace-validation` — 目录内容、实现和 bundle 必须双向完整一致。
- `semantic-template-engine` — 用可解析代码模板完成语义替换，而不是字符串拼接。
- `constrained-capture-matching` — 结构匹配后追加运行时语义约束。
- `variadic-pattern-matching` — 支持参数、语句、注解等变长序列的通配捕获。
- `dynamic-template-builder` — 支持运行时条件、循环和可复用片段构造模板。
- `lenient-semantic-comparator` — 类型信息不完整时允许受控宽松匹配，而不是完全退化到文本。
- `semantic-search-engine` — 为 Agent 提供 type-aware、symbol-aware、recipe-aware 查询接口。
