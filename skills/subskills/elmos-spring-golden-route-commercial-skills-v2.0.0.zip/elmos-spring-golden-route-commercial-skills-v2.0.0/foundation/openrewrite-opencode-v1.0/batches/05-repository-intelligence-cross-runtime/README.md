# Batch 05: repository-intelligence-cross-runtime

预计算仓库知识、跨语言 RPC、数据本地化与 Token 降本。

## Skills

- `rewrite-rpc-runtime` — 让不同语言实现的 parser/recipe 通过统一协议参与 Elmos 变换。
- `mirrored-rpc-capabilities` — 跨 RPC 只暴露每个 runtime 都能重现的闭合集能力。
- `cross-runtime-data-sink` — 大规模 Recipe 数据留在运行地写入共享 sink，只跨 RPC 传 sink 配置。
- `rpc-process-isolation` — 跨语言 runtime 做任务级/线程级隔离、超时、清理和死锁防护。
- `repository-knowledge-precompute` — 在 Agent 之前预计算仓库结构化知识，减少逐文件探索。
- `architecture-context-extractor` — 从代码/配置/依赖提取可机器查询的架构图和边界。
- `dependency-and-library-usage-index` — 不仅知道装了什么依赖，还知道在哪里、怎样被实际使用。
- `coding-and-error-pattern-miner` — 从仓库提取真实命名、错误处理、日志和约定，供生成代码遵循。
- `method-and-test-quality-index` — 为方法复杂度、职责、测试映射和 flaky 风险建立结构化索引。
- `semantic-token-context-query` — 用 SQL/图查询从预计算上下文中选最小 token 语义切片。
