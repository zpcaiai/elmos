# Source Provenance & License Notes

本包主要抽取**行为契约、架构思想和工程机制**，没有复制上游实现源码。

## openrewrite

- Repository: https://github.com/openrewrite/rewrite
- Branch scanned: `main`
- Snapshot commit: `4bc18536d99bb86f1ba0f353643de72ef56dd165`
- Upstream license: `Apache-2.0`
- Key source areas:
  - `README.md`
  - `CLAUDE.md`
  - `rewrite-core/src/main/java/org/openrewrite/Recipe.java`
  - `rewrite-core/src/main/java/org/openrewrite/RecipeScheduler.java`
  - `rewrite-core/src/main/java/org/openrewrite/Result.java`
  - `doc/adr/0006-recipe-marketplace-csv-format.md`
  - `doc/adr/0007-javascript-templating-enhancements.md`
  - `doc/adr/0008-rpc-data-table-stores.md`
  - `doc/adr/0009-native-python-lock-regeneration.md`
  - `doc/adr/0010-native-uv-lock-delta-resolution.md`
  - `doc/adr/0011-native-node-lock-regeneration.md`
  - `doc/adr/0012-ruby-parsing-via-prism.md`
  - `.moderne/context/`

## opencode

- Repository: https://github.com/anomalyco/opencode
- Branch scanned: `dev`
- Snapshot commit: `ba72a6ff2b62aaf614b8e745193e86a51be6142c`
- Upstream license: `MIT`
- Key source areas:
  - `README.md`
  - `specs/v2/session.md`
  - `packages/core/src/agent.ts`
  - `packages/core/src/permission.ts`
  - `packages/core/src/tool/tool.ts`
  - `packages/opencode/src/session/`
  - `packages/opencode/src/snapshot/index.ts`
  - `packages/opencode/src/provider/`
  - `packages/opencode/src/control-plane/`
  - `packages/llm/DESIGN.md`
  - `packages/web/src/content/docs/agents.mdx`
  - `packages/web/src/content/docs/skills.mdx`
  - `packages/web/src/content/docs/tools.mdx`
  - `packages/web/src/content/docs/mcp-servers.mdx`
  - `packages/web/src/content/docs/lsp.mdx`
  - `packages/web/src/content/docs/formatters.mdx`
  - `packages/web/src/content/docs/config.mdx`
  - `packages/web/src/content/docs/rules.mdx`
  - `packages/web/src/content/docs/commands.mdx`

## Important boundary

- OpenRewrite core is Apache-2.0, but the broader Moderne commercial platform has separate capabilities/licensing; do not assume all Moderne functionality is covered by the OpenRewrite OSS license.
- OpenCode repository snapshot inspected here is MIT.
- If Elmos later copies, modifies, vendors, links, or redistributes upstream code/assets, run a separate legal/license review and preserve required notices/attribution.
- Architectural ideas and independently implemented behavior should still keep provenance notes for maintainability.
