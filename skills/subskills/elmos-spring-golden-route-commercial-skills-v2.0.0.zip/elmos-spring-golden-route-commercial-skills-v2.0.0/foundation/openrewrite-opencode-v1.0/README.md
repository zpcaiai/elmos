# Elmos × OpenRewrite × OpenCode Skills Package v1.0

本包把 OpenRewrite 与 OpenCode 中对 Elmos 有价值的机制抽取为 **100 个可实现、可测试、可验收的 SKILL.md**，分为 10 个批次。

> 目标不是 fork/改名两个项目，而是把它们的强项提升为 Elmos 自己稳定的架构契约：
> **Semantic Transformation Kernel + Agent Execution Harness + Durable Verification & Learning Layer**。

## Snapshot

- OpenRewrite: `4bc18536d99bb86f1ba0f353643de72ef56dd165` on `main`
- OpenCode: `ba72a6ff2b62aaf614b8e745193e86a51be6142c` on `dev`
- Package generated: 2026-08-21
- Skills: **100**
- Batches: **10**

## Recommended target architecture

```text
Requirement / Project Constraints
            │
            ▼
   Deterministic-first Router
            │
       Typed Task DAG
      ┌─────┼─────────┐
      ▼     ▼         ▼
   Recipe  Agent     Human
      │     │          │
      └─────┴──────────┘
            │
     Universal Semantic IR
    / LST / Build IR / KG
            │
     Semantic Patch IR
            │
  Durable Tool + Side-effect Ledger
            │
    Compile / Test / Evals
            │
      Verification Fixpoint
            │
      Completion Proof
            │
 Repository Knowledge + Recipe Learning
```

## Batch map

| Batch | Theme | What Elmos gains |
|---|---|---|
| 01 | Semantic Kernel | 无损语义树、类型、Marker、Parser Adapter |
| 02 | Recipe Runtime | 确定性变换、组合、扫描、Fixpoint、归因 |
| 03 | Recipe Ecosystem & Patterns | Marketplace、模板、约束匹配、语义搜索 |
| 04 | Dependency & Quality | 原生依赖解析、最小锁文件变更、TCK、测试 |
| 05 | Repository Intelligence & RPC | 预计算仓库知识、跨语言运行、Token 降本 |
| 06 | Agent Runtime | Primary/Subagent、角色、预算、并行与会话图 |
| 07 | Durable Session & Context | Inbox/Event Sourcing/Context Epoch/Compaction |
| 08 | Recovery, Safety & Tools | Snapshot、恢复、副作用 fencing、Tool/权限 |
| 09 | Integration & Provider Platform | Skills/MCP/LSP/Provider/Config/Workspace |
| 10 | Elmos Fusion | Recipe+Agent 混合、完成证明、自学习、缓存 |

## How to consume

### Codex / Claude Code
按批次提供 `batches/<batch>/<skill>/SKILL.md`。P0 建议先实施 01、02、04、05、06、07、08、10，再扩展 03、09。

### OpenCode-compatible discovery
每个 Skill 均使用兼容的 `name/description/license/compatibility/metadata` frontmatter，可复制到项目的 skills 目录后按需发现。

### Elmos native
读取 `manifest/skills-index.json` 和 `manifest/dependency-graph.json`，由 Elmos 自己的 Skill Registry 做版本、权限、依赖、认证和懒加载。

## Completion rule

任何 Batch 不以“Agent 说完成了”为完成条件。完成必须由本包每个 Skill 的 **Acceptance criteria** + 批次 E2E gate 共同证明。
