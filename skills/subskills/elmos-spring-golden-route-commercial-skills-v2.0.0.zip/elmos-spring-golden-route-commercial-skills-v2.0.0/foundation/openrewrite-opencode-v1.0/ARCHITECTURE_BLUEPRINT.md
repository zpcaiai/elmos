# Architecture Blueprint

## 1. Split the system into four planes

### Semantic Plane
Owns parsing, lossless IR, type attribution, source markers, build/config models, semantic search and precomputed repository knowledge.

### Transformation Plane
Owns deterministic recipes, semantic patterns/templates, recipe composition, fixpoint cycles, changesets and provenance.

### Agent Execution Plane
Owns agent roles, model routing, durable sessions, provider turns, tool settlement, permissions, snapshots, retry/recovery and side-effect fencing.

### Evidence & Learning Plane
Owns verification, completion proofs, run data tables, cost/quality metrics, migration knowledge graph, cache analytics and candidate-recipe certification.

## 2. Key public boundaries

```text
ParserAdapter
  parse(SourceInput, ParseContext) -> SemanticSource

SemanticQuery
  execute(Query, RepositorySnapshot) -> SemanticSlice

Recipe
  scan / generate / edit -> ChangeSet

TaskPlan
  nodes: RecipeNode | AgentNode | ToolNode | HumanNode | VerifyNode

ProviderTurn
  request(portable) -> normalized durable events

Tool
  definition(serializable) + handler(process-local)

Verification
  evidence -> Pass | Fail | Unknown

CompletionProof
  requirements + patches + tests + evidence + unresolved
```

## 3. Deterministic-first policy

1. Search existing certified Recipe.
2. Try semantic pattern/template.
3. Use typed Tool or compiler/LSP diagnostic.
4. Use Agent only for ambiguity/novel reasoning.
5. Verify every change.
6. Mine repeated successful semantic patches into Recipe candidates.
7. Certify before enabling automatic production use.

## 4. Durable execution invariants

- No external side effect before durable intent record.
- No continuation before tool settlement is durable.
- Crash never means “retry everything”.
- Provider-dispatch ambiguity is a first-class state.
- A reconnecting client consumes durable events by cursor.
- Cluster workers require ownership lease/fencing.
- Completion can be Pass, Fail, Partial, Blocked, Unknown — never fabricated.

## 5. Cache layers

```text
Blob/File hash
  -> Parse cache
    -> Lossless Semantic IR cache
      -> Symbol/type/dependency index
        -> Semantic query cache
          -> Repository summary/context cache
            -> Provider prompt/cache-key layer
```

Invalidation should be dependency-aware, not whole-repository by default.
