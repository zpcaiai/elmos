# P0 Top-30 Implementation Checklist

如果不想一次实施 100 个 Skill，先按下面 30 个打通 Elmos 主链路：

- [ ] 01. `lossless-semantic-ir` — 建立跨语言、可往返打印、保留格式/注释/语义的统一源码表示。
- [ ] 02. `rich-type-attribution` — 把类型归因从“可选附加信息”提升为迁移和搜索的基础设施。
- [ ] 03. `parser-roundtrip-fidelity` — 建立 parse→print 的无损往返质量门禁。
- [ ] 04. `deterministic-recipe-engine` — 把可重复迁移从 LLM 写代码下沉为类型感知、可测试的确定性 Recipe。
- [ ] 05. `recipe-preconditions` — 变换前先做类型、框架、文件和版本前置判断，降低误改。
- [ ] 06. `scan-generate-edit-lifecycle` — 为大型迁移固定 scan、generate、edit 三阶段执行顺序。
- [ ] 07. `multi-cycle-fixpoint` — Recipe 多轮执行直到不再产生变化或显式达到收敛条件。
- [ ] 08. `recipe-change-attribution` — 任何源码变更都必须能回答“哪条规则为何改了这里”。
- [ ] 09. `build-model-intelligence` — 解析构建工具、依赖图、插件、仓库和语言级别形成统一 Build IR。
- [ ] 10. `minimal-lockfile-delta` — 锁文件更新默认采用最小变更，而非全图重新解析。
- [ ] 11. `parser-tck` — 为每种 parser 建立共享语法/语义/打印兼容性测试套件。
- [ ] 12. `repository-knowledge-precompute` — 在 Agent 之前预计算仓库结构化知识，减少逐文件探索。
- [ ] 13. `semantic-token-context-query` — 用 SQL/图查询从预计算上下文中选最小 token 语义切片。
- [ ] 14. `agent-registry` — 把 Agent 作为可配置、可发现、可禁用的一等运行实体。
- [ ] 15. `plan-explore-scout-agents` — 把只读规划、本仓探索、外部依赖研究拆成不同权限角色。
- [ ] 16. `per-agent-model-routing` — 不同角色使用不同模型、temperature、reasoning 与成本预算。
- [ ] 17. `parallel-subagent-execution` — 把互不依赖的搜索、分析、测试任务并行化，但结果确定性归并。
- [ ] 18. `durable-session-inbox` — 用户输入先持久化 admission，再由 runner 安全 promotion 到模型历史。
- [ ] 19. `session-event-sourcing` — Session 的关键状态转换使用持久事件序列而不是仅内存状态。
- [ ] 20. `provider-turn-persistence` — 把单次 provider turn 作为 durable runtime 的最小模型执行原语。
- [ ] 21. `durable-tool-settlement` — Tool call 在执行前投影，结果/失败/中断也持久化后再继续模型。
- [ ] 22. `context-epoch` — 持久化模型看到的 privileged context baseline，并增量追踪变化。
- [ ] 23. `context-compaction` — 上下文超预算前生成结构化 checkpoint，而完整 transcript 仍永久保留。
- [ ] 24. `git-snapshot-revert` — 用独立 Git object/index 体系为 Agent 修改提供高效 checkpoint/diff/restore/revert。
- [ ] 25. `post-crash-continuation-recovery` — 补强 OpenCode 尚未完全解决的 crash 后 continuation，作为 Elmos 生产级能力。
- [ ] 26. `typed-tool-registry` — 所有内建、MCP、CLI、数据库、部署工具统一成强类型 Tool Definition。
- [ ] 27. `wildcard-permission-engine` — action × resource × ruleset 使用 allow/ask/deny 和 last-match 规则。
- [ ] 28. `deterministic-first-router` — 任务先判断能否用 Recipe/语义查询解决，再决定是否调用 LLM。
- [ ] 29. `semantic-patch-and-evidence-ledger` — 每次修改同时保存文本 diff、语义变化、执行者、验证和原因。
- [ ] 30. `verification-fixpoint-completion-proof` — 以可证明的零剩余违规/测试通过/需求覆盖替代 Agent 自报完成。
