# ELMOS Language Packs Batch 86–90

Contains 60 Skills and five individual Batch ZIPs.
