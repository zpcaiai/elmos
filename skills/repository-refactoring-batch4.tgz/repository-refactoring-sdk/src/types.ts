/**
 * The wire types of the repository-refactoring runtime.
 *
 * These mirror the Python core's envelope exactly.  Two conventions here are
 * deliberate and load-bearing:
 *
 * * `Status` has no "unknown" member and no default.  A caller must handle
 *   `blocked` and `rejected` explicitly; there is no shape of this type in
 *   which an undecided run reads as a successful one.
 * * every "did it pass" field that the core may leave undecided is typed
 *   `boolean | null`, never `boolean`.  `null` means *not decided*, and
 *   collapsing it to `false` — or worse to `true` — is exactly the bug these
 *   types exist to prevent.
 */

/** Terminal status of one Skill invocation. */
export type Status = "succeeded" | "blocked" | "rejected" | "failed";

/** Blast radius of a change, R0 (inert) through R4 (irreversible/critical). */
export type RiskClass = "R0" | "R1" | "R2" | "R3" | "R4";

/** How a failure should be handled by the orchestrator. */
export type FailureClass =
  | "transient"
  | "retryable"
  | "terminal"
  | "approval-required"
  | "capability-missing";

/** Adapter capability tiers. L0 is "nothing proven". */
export type AdapterLevel = "L0" | "L1" | "L2" | "L3" | "L4" | "L5";

/** Execution outcome of a sandboxed command. `not-run` is never decisive. */
export type ExecutionStatus = "completed" | "failed" | "timeout" | "refused" | "not-run";

/** The structured error the core raises instead of a stack trace. */
export interface ContractErrorPayload {
  readonly code: string;
  readonly message: string;
  readonly details?: Readonly<Record<string, unknown>>;
}

/** The envelope every Skill returns. */
export interface HandlerEnvelope {
  readonly skill: string;
  readonly status: Status;
  readonly output: Readonly<Record<string, unknown>>;
  readonly reasons: readonly string[];
  readonly canonical_owner: string;
  readonly risk_class: RiskClass;
  readonly failure_class: FailureClass | null;
  readonly side_effects_performed: boolean;
  readonly evidence: Readonly<Record<string, unknown>>;
}

/**
 * Host-owned authority.  Kept structurally separate from a task payload,
 * because everything in here widens what the runtime may reach: a policy, a
 * filesystem root, a set of recorded executions.  A payload can never grant
 * itself any of it.
 */
export interface TrustedContext {
  readonly policy?: Readonly<Record<string, unknown>>;
  readonly policy_ref?: string;
  readonly adapter_capabilities?: Readonly<Record<string, unknown>>;
  readonly recorded_executions?: readonly Readonly<Record<string, unknown>>[];
  /** Absolute path. The runtime refuses a workspace outside this root. */
  readonly workspace_root?: string;
  readonly journal_root?: string;
}

/** A file in an inline workspace snapshot. */
export interface WorkspaceFile {
  readonly path: string;
  readonly content?: string;
  /** Base64 for a file the core cannot decode as text; it counts as unscanned. */
  readonly content_base64?: string;
}

export interface WorkspacePayload {
  readonly source: "inline" | "directory";
  readonly repository_id: string;
  readonly revision: string;
  readonly files: readonly WorkspaceFile[];
}

/** Common shape of a planning-stage payload. */
export interface AnalysisPayload {
  readonly workspace: WorkspacePayload;
  readonly request?: Readonly<Record<string, unknown>>;
  readonly include?: readonly string[];
  readonly exclude?: readonly string[];
  readonly [key: string]: unknown;
}

/**
 * A gate result as the core reports it.
 *
 * `passed: null` means the gate was not decided — no executor, no evidence,
 * or an UNKNOWN predicate.  A blocking gate that is not decided fails.
 */
export interface GateResult {
  readonly gate: string;
  readonly passed: boolean | null;
  readonly blocking: boolean;
  readonly detail: string;
}

export const EXIT_CODES = {
  succeeded: 0,
  rejected: 2,
  blocked: 3,
  failed: 4,
  usage: 64,
} as const;

export type ExitCode = (typeof EXIT_CODES)[keyof typeof EXIT_CODES];

/** Map a process exit code back to a status, or `null` for a usage error. */
export function statusForExitCode(code: number): Status | null {
  switch (code) {
    case EXIT_CODES.succeeded:
      return "succeeded";
    case EXIT_CODES.rejected:
      return "rejected";
    case EXIT_CODES.blocked:
      return "blocked";
    case EXIT_CODES.failed:
      return "failed";
    default:
      return null;
  }
}
