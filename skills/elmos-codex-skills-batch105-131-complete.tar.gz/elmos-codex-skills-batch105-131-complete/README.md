# ELMOS Batch 105-131 — Polyglot Migration Assurance Skills

432 Skills across twenty-seven Batches (`B105-S01` through `B131-S16`) covering behavioural verification, shadow
running, progressive cutover, certification, the unified Semantic IR, all seventy-two directional language
paths, and the framework, persistence, messaging and security mapping layers.

## Batches

| Batch | Title | Skills |
|---|---|---|
| 105 | Source Baseline and Differential Verification Pack | 16 |
| 106 | Adversarial Verification and Shadow Enablement Pack | 16 |
| 107 | Progressive Traffic Migration and Rollback Pack | 16 |
| 108 | Certification Pipeline and Legacy Retirement Pack | 16 |
| 109 | Migration Governance and Semantic Inventory Pack | 16 |
| 110 | Semantic IR Core and Language Frontend Pack | 16 |
| 111 | Language Backend and Directional Path Pack | 16 |
| 112 | Type, Memory and Concurrency Mapping Pack | 16 |
| 113 | Dynamic Behavior, Framework and Normalization Pack | 16 |
| 114 | Specialized Testing, Mutation and IR Verification Pack | 16 |
| 115 | Directional Pack Foundations and Repair Agent Roles | 16 |
| 116 | Java and Python Source Directional Packs | 16 |
| 117 | Python, C# and Rust Source Directional Packs | 16 |
| 118 | Rust, Go and TypeScript Source Directional Packs | 16 |
| 119 | TypeScript, C++ and Objective-C Source Directional Packs | 16 |
| 120 | Apple Source Directional Packs and Framework Semantic Core | 16 |
| 121 | Framework Semantic Frontends Pack | 16 |
| 122 | Cross-Framework Mapping Pack | 16 |
| 123 | Persistence and Messaging Semantic Pack | 16 |
| 124 | Security, Lifecycle and Framework Test Pack | 16 |
| 125 | Framework Certification Gates and Dependency Discovery Pack | 16 |
| 126 | Dependency Closure and Ecosystem Pack | 16 |
| 127 | Standard Library Capability and Candidate Discovery Pack | 16 |
| 128 | Replacement Compatibility and Native Boundary Pack | 16 |
| 129 | Native Platform and Licence Governance Pack | 16 |
| 130 | Supply Chain Security Pack | 16 |
| 131 | Replacement Certification Pack | 16 |

## Open Batch

None. Every Batch from 105 through 131 holds exactly 16 Skills and the manifest declares
`"open_batch": null`. The validator enforces 16 for every Batch while that declaration is null.

## Identity policy

Batch-local IDs only. Global PG IDs remain `unassigned` to avoid collision with the installed Batch 1-104
packages. Use `scripts/remap_global_ids.py` after a namespace authority allocates a global range.

## Usage

```bash
./validate.sh                 # package, contract, schema and interface validation
./validate.sh --batch 105     # validate a single Batch
./install.sh ~/.codex/skills  # validate then install
```

Installed Skills are invoked as `$b105-source-system-freeze` through `$b131-http-client-candidate-matrix`.

## Directional paths

Batches 116 through 120 register all `9 x 8 = 72` directional paths as separate Skills. A language pair is not
a direction: `java-to-rust` and `rust-to-java` carry different rules, different mutation operators and
different certification ceilings. Each path Skill states its static, runtime-trace and production ceilings, and
several declare a hard cap that no approval can lift.

## Evidence boundary

Every Skill is fail-closed. Differential, mutation, concurrency, fault-injection, shadow, canary and
certification evidence remain `NOT_RUN` until an authorized runner executes against the frozen source baseline.
The local gate never returns `certified`.
