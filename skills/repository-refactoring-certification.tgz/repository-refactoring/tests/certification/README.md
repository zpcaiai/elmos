# Production certification suite

Three layers, each answering a different question.

| Layer | File | Question |
|---|---|---|
| Package invariants | `test_package_invariants.py` | Are the README's structural claims still true of the code? |
| Golden corpus | `test_golden_corpus.py` + `../golden/` | Did any Skill's behaviour change on a fixed repository? |
| Honesty invariants | `test_package_invariants.py::TestHonestyInvariants` | Do the three honesty rules still hold end to end? |

## Running

```bash
pytest tests/certification -q                 # the gate
ELMOS_UPDATE_GOLDEN=1 pytest tests/certification -q   # deliberate re-record
```

## Why re-recording is explicit

A corpus that re-baselines whenever the output moves can only *describe* a
regression, never detect one. `ELMOS_UPDATE_GOLDEN=1` is therefore required,
and a changed fixture is reported separately from a changed output: comparing
outputs across two different inputs could pass while the behaviour regressed.

The recorded observation is a digest **plus named projections**, so a failure
reads as `output.transformEvidence.changedPaths: was [4 files], now [1 file]`
rather than as two opaque hashes. A projection that resolves to nothing is
recorded as the string `<missing>` — never as `null` — so a field that
disappears cannot pass as a field that is empty. (That sentinel caught a bug
in this suite's own projection paths on the first run.)

## What the invariants actually check

- **Zero third-party imports**, enforced by parsing every module's AST. The
  zero-dependency claim is a security property — nothing to pin, nothing to
  audit — so it is checked, not asserted in prose.
- **Only `sandbox.py` imports `subprocess`**, so "no executor" stays a state
  the core can *report* rather than one it can route around.
- **No network-capable import anywhere**, including in a test helper.
- **No handler is a stub**: each is checked for size and for not delegating to
  the pending-skill path, so catalog coverage cannot be satisfied by 23
  functions that return `blocked`.
- **Unknown payload fields are rejected** for all 23 Skills: a typo'd key means
  the caller asked for something the handler is not doing.
- **A payload cannot grant itself filesystem reach** — `workspace_root` is
  trusted context, and a payload claiming one is refused.
- **A handler exception becomes a `failed` envelope**, never a traceback and
  never a partial success.
- **With no executor, blocking gates are undecided and the run does not pass.**
- **An undecodable source file lowers coverage** and appears in `unscanned`;
  a declared binary asset does neither. Conflating the two is how "we could not
  read it" becomes "there was nothing there".
- **A declared adapter level never exceeds the native engine level.** A
  descriptor claiming L4 for Python still resolves to L2, because a signature
  is not an implementation.
