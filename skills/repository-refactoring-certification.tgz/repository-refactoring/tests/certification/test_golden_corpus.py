"""Golden-corpus regression: the recorded behaviour of the whole runtime.

A failure here is a *behaviour change*.  It may be a fix — in which case the
right response is to read the reported difference, agree with it, and
re-record with ``ELMOS_UPDATE_GOLDEN=1`` — but it is never noise, and the
suite never re-records on its own.
"""

from __future__ import annotations

import pytest

from elmos_repository_refactoring.runtime import dispatch

from .cases import CASES
from .corpus import CorpusCase, describe_difference, load, observation, store, updating


@pytest.mark.parametrize("case", CASES, ids=[item.case_id for item in CASES])
def test_case_matches_its_recorded_behaviour(case: CorpusCase) -> None:
    envelope = dispatch(case.skill, case.payload, trusted_context=dict(case.trusted_context))
    actual = observation(case, envelope)
    expected = load(case)

    if expected is None:
        if not updating():
            pytest.fail(
                f"no golden record for '{case.case_id}'. Re-record deliberately with "
                f"ELMOS_UPDATE_GOLDEN=1; a suite that records on demand cannot detect a regression."
            )
        store(case, actual)
        return

    if expected["inputDigest"] != actual["inputDigest"]:
        #: The fixture itself moved.  Comparing outputs now would compare two
        #: different questions and could pass while the behaviour regressed.
        pytest.fail(
            f"the fixture for '{case.case_id}' changed (input digest "
            f"{expected['inputDigest'][:19]} -> {actual['inputDigest'][:19]}); "
            "re-record with ELMOS_UPDATE_GOLDEN=1 after confirming the new fixture is intended."
        )

    if expected != actual:
        if updating():
            store(case, actual)
            return
        pytest.fail(
            f"'{case.case_id}' ({case.description}) behaves differently:\n"
            + describe_difference(expected, actual)
        )


@pytest.mark.parametrize("case", CASES, ids=[item.case_id for item in CASES])
def test_case_is_deterministic(case: CorpusCase) -> None:
    """The same input twice must produce the same envelope, byte for byte."""

    first = dispatch(case.skill, case.payload, trusted_context=dict(case.trusted_context))
    second = dispatch(case.skill, case.payload, trusted_context=dict(case.trusted_context))
    assert first == second, f"'{case.case_id}' is not deterministic"


def test_every_case_has_a_recorded_baseline() -> None:
    missing = [case.case_id for case in CASES if load(case) is None]
    assert missing == [], f"cases with no golden record: {missing}"


def test_the_corpus_covers_the_load_bearing_skills() -> None:
    """A corpus that drifts away from the risky Skills stops being a guard."""

    covered = {case.skill for case in CASES}
    required = {
        "deterministic-transform-executor",
        "test-and-verification",
        "data-schema-refactor",
        "cross-language-contract-refactor",
        "distributed-system-refactor",
    }
    assert required <= covered, f"corpus is missing: {sorted(required - covered)}"
