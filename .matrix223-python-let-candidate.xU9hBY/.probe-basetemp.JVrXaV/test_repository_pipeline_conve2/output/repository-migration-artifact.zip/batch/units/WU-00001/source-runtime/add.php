<?php

declare(strict_types=1);

function add(int $left, int $right): int { return $left + $right; }
